"""Dormant two-candidate cache BUILD adapter; no action at import.

Reuses the closed CMS builders/clone/runtime supervision. No controller, RUN,
Rust rebuild, ABI/default change or native-main invocation is implemented.
"""
from pathlib import Path
import hashlib
import json
import re
import shlex
import types

SUB=Path('SubProcesses/P0_epem_mupmum')
PLAIN_TERMINAL='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
OBSERVED_TERMINAL='c04a37845f1e5fd9a02cea25375d4f6a8e523071829b19fcb853ae27c73025fd'
OBSERVED_COMPILED_SOURCE='2333cb5216b178da1d77083de30ee4c72226d2b82ec6753d0ddc1fd6459b9e29'
EB3_AUDIT='a94d65a6b62cdeab9ea92d09a5b80434736ddf65570e24e7e299ca71eb2282d8'
EB3='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9'
PRIVATE_MODULES=('invariant_bounds.f90','owned_snapshots.f90','owned_exact_geometry.f90',
                 'owned_certificate.f90','owned_math.f90','owned_route_data.f90','point_match.f90')
CHANGED={'loop_matrix.f','mp_compute_loop_coefs.f','helas_calls_ampb_1.f','mp_helas_calls_ampb_1.f',
         'loop_CT_calls_1.f','CT_interface.f','TIR_interface.f','TIRUST_interface.f'}


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):return {'bytes':Path(path).stat().st_size,'sha256':digest(path)}
def read(path):return json.loads(Path(path).read_text())


def references(b):
    """Read-only old BUILD/source/object/recipe/alias authentication."""
    old=b.cache_parent_module('observer_build')
    require(old.COMPILED_SOURCE_INDEX==OBSERVED_COMPILED_SOURCE and old.PLAIN_TERMINAL==PLAIN_TERMINAL,
            'wrong frozen observer-builder contract')
    proxy=types.SimpleNamespace(**vars(b));proxy.HERE=b.cache_parent_folder
    proxy.REVIEWED_BUILD=OBSERVED_TERMINAL
    observed=old.verified_build(proxy);plain=old.verified_plain(proxy)
    data=read(b.HERE/'input-pins.json');base=b.local('cms_build')
    original=read(b.ROOT/data['original_receipt']);recipes=base.compile_recipes(original)
    require(recipes['CT_interface.f'][0]==read(b.HERE/'toolchain-pins.json')['required_tools']['gfortran']['path'],
            'original compiler recipe changed')
    require(len(original['objects'])==19,'exact19 process objects required')
    audit_path=b.ROOT/'.tirust-build/eb3-cache-source-artifact-audit-1/receipt.json'
    require(digest(audit_path)==EB3_AUDIT,'recovered eb3 cache source/artifact audit changed')
    audit=read(audit_path)
    require(audit['artifact_sha256']['libmadloop_tirust.so']==EB3 and
            audit['recorded_build_provenance_not_cryptographic_or_clean_rebuild_attestation'] is True,
            'wrong recovered cache implementation scope')
    require(data['runtime'][data['native_path']]==EB3 and digest(data['native_path'])==EB3,
            'installed eb3 DSO changed')
    composition=read(b.cache_parent_folder/'composition-receipt.json')
    return {'plain':plain['variants']['candidate'],'observed':observed['variants']['candidate'],
            'recipes':recipes,'original_process_objects':[Path(name).name for name in original['objects']],
            'observed_externals':composition['lanes']['candidate']['defined_observed_externals'],
            'plain_reference_terminal':PLAIN_TERMINAL,'observed_reference_terminal':OBSERVED_TERMINAL,
            'observed_compiled_source':OBSERVED_COMPILED_SOURCE,
            'eb3_provenance':{'receipt_sha256':EB3_AUDIT,'artifact_sha256':EB3,
                'claim':'recorded source/artifact build provenance, not clean rebuild/compiler attestation'}}


def emission_contract(b):
    receipt=read(b.HERE/'composition-receipt.json');route=read(b.HERE/'cache-fortran-diff.json')
    require(receipt['parent_source']['sha256']=='1a1cebf262c5fe7767a1bf6db54591a3baae9d72326370524dc918a41fd69e5d',
            'wrong source2 parent')
    require(identity(b.HERE/'cache-fortran-diff.json')==receipt['route_diff'],'route diff changed')
    require(not receipt['Rust_C_ABI_changed'] and not receipt['Fortran_group_cache_applicable'] and
            not receipt['production_changed'],'unsupported cache emission scope')
    plain=route['lanes']['plain']['outputs']
    require(set(plain)=={'CT_interface.f','TIRUST_interface.f'},'exact plain two-file overlay required')
    observed={name:receipt['outputs']['emittedsrc/observed/'+name]
              for name in ('CT_interface.f','TIRUST_interface.f','observer.f90')}
    for lane,files in [('plain',plain),('observed',observed)]:
        root=b.HERE/'emittedsrc'/lane
        require({p.name for p in root.iterdir() if p.is_file()}==set(files),'unexpected cache overlay file')
        for name,pin in files.items():
            require(not (root/name).is_symlink() and identity(root/name)==pin,'changed cache overlay '+lane+'/'+name)
    return {'plain':plain,'observed':observed,'composition_sha256':digest(b.HERE/'composition-receipt.json'),
            'route_diff_sha256':digest(b.HERE/'cache-fortran-diff.json')}


def module_outputs(case,names):
    outputs={}
    for name in names:
        found=re.findall(r'^\s*module\s+([A-Za-z][A-Za-z0-9_]*)\s*$',(case/name).read_text(),re.M|re.I)
        require(len(found)==1,'exact private module definition required')
        output=case/(found[0].lower()+'.mod')
        require(output.is_file() and not output.is_symlink(),'private module output absent/aliased')
        outputs[output.name]=identity(output)
    return outputs


def build(b,directory):
    import clone_aliases
    before=b.protected();refs=references(b);emitted=emission_contract(b)
    data=read(b.HERE/'input-pins.json');base=b.local('cms_build');old=b.cache_parent_module('observer_build')
    recipes=refs['recipes'];fc=recipes['CT_interface.f'][0]
    flags=recipes['CT_interface.f'][1:recipes['CT_interface.f'].index('-c')]
    loader=b.support(b.LOADER_PATH);runtime=b.local('cms_runtime');results={}
    for lane in ('plain','observed'):
        reference=refs[lane];source=Path(reference['path']).parent.parent.parent;output=directory/lane
        clone_aliases.clone(source,output,data['donor'],data['shared_aliases'],data['original_links'])
        require(base.source_inventory(output)==reference['source_inventory'],'closed source copy changed before mutation')
        for name,pin in reference['objects'].items():require(identity(output/name)==pin,'closed object copy changed before mutation')
        case=output/SUB;logs=case/'owned-build-commands';logs.mkdir()
        for name,pin in emitted[lane].items():
            source_file=b.HERE/'emittedsrc'/lane/name
            require(identity(source_file)==pin,'cache source changed before overlay')
            base.replace_source(case/name,source_file.read_bytes(),output)
        require((case/'tir_cache_size.inc').read_bytes()==b'      PARAMETER(TIR_CACHE_SIZE=0)\n','Fortran cache must remain zero')
        for name,pin in {**data['libraries'],**data['module_inputs']}.items():base.check(output/name,pin)
        selected=sorted(CHANGED|{'check_sa.f'}) if lane=='observed' else ['CT_interface.f','TIRUST_interface.f']
        modules=(['observer.f90'] if lane=='observed' else [])+list(PRIVATE_MODULES)+(['observed_math.f90'] if lane=='observed' else [])
        rebuilt={str(SUB/Path(name).with_suffix('.o')) for name in selected+modules}
        preserved={name:pin for name,pin in reference['objects'].items() if name not in rebuilt}
        for name in selected:
            target=case/Path(name).with_suffix('.o')
            require(not target.is_symlink(),'aliased compile output');target.unlink(missing_ok=True)
        old.fresh_module_sources(base,case,modules,output)
        for name in modules:
            b.command(base.compile_argv(recipes['CT_interface.f'],name,str(Path(name).with_suffix('.o'))),case,logs,'module-'+Path(name).stem)
        regenerated={}
        for name in PRIVATE_MODULES:
            key=str(SUB/Path(name).with_suffix('.o'))
            regenerated[key]=identity(output/key)
            require(regenerated[key]==reference['objects'][key],'unchanged private module object differs')
        for name in selected:b.command(recipes[name],case,logs,'compile-'+Path(name).stem)
        require(all(identity(output/name)==pin for name,pin in preserved.items()),'unchanged authenticated object changed')
        extra=list(reference['extra_objects']);require(len(extra)==len(set(extra)),'duplicate extra object')
        (case/'owned-info.mk').write_text('include makefile\n.PHONY: owned-info\nowned-info:\n\t@$(info FC $(FC))$(info FFLAGS $(FFLAGS))$(info LINKLIBS $(LINKLIBS))$(info LDFLAGS $(LDFLAGS)) :\n')
        info=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['make']['path'],'-s','--no-print-directory','-f','owned-info.mk','owned-info'],case,logs,'make-link-info')
        fields={line.split()[0]:shlex.split(line)[1:] for line in info.splitlines() if line.strip()}
        require(set(fields)=={'FC','FFLAGS','LINKLIBS','LDFLAGS'} and fields['FC']==[fc] and fields['FFLAGS']==flags,'original scientific flags changed')
        require(fields['LDFLAGS']==data['original_LDFLAGS'] and fields['LINKLIBS'][-len(fields['LDFLAGS']):]==fields['LDFLAGS'],'original link policy changed')
        link=[fc,*flags,'-Wl,-Map,owned-link.map,--cref','-o','check',*refs['original_process_objects'],*extra,*fields['LINKLIBS']]
        callback=base.query_callback(b,case,logs,lane,link);pre=loader.prelink(link,case,b.environment(),callback)
        for name,wanted in data['runtime'].items():require(digest(name)==wanted and pre['bound'].get(name,wanted)==wanted,'provider changed before link')
        pre['bound'].update(data['runtime']);pre['explicit_CMS_runtime_before_link']=dict(data['runtime']);b.dump(case/'owned-prelink.json',pre)
        b.command(link,case,logs,'link');loads=loader.requireactualmap((case/'owned-link.map').read_text(),case,pre,case/'check')
        static=runtime.derive(case/'check',pre,data['runtime'],b.environment()['LD_LIBRARY_PATH'])
        require(static['files']==data['runtime'],'static15-provider closure changed')
        b.dump(case/'owned-static-runtime.json',static);observed=loader.query_runtime(case/'check',data['runtime'],pre,callback)
        nm=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['nm']['path'],'--defined-only','check'],case,logs,'symbols')
        names=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',nm,re.M)
        required=[name.lower()+'_' for name in refs['observed_externals']]
        require(all(names.count(name)==1 for name in data['candidate_symbols']),'original candidate symbol ownership differs')
        require(all(names.count(name)==1 for name in required) if lane=='observed' else not any(name in names for name in required),
                'plain/observed external ownership differs')
        require({name:names.count(name) for name in names if '__mtirust_MOD_' in name}=={name:1 for name in data['mtirust_symbols']},'MTIRUST ownership differs')
        require(all(identity(output/name)==pin for name,pin in preserved.items()),'link changed reused object')
        module_pins=module_outputs(case,modules)
        results[lane]={'path':str(case/'check'),'sha256':digest(case/'check'),'runtime':observed,
            'source_inventory':base.source_inventory(output),'objects':{str(p.relative_to(output)):identity(p) for p in output.rglob('*.o') if p.is_file()},
            'module_files':module_pins,'actual_link_loads':loads,'immutable_shared_aliases':clone_aliases.validate_shared(output,data['shared_aliases']),
            'preserved_authenticated_objects':preserved,'regenerated_private_objects_bit_identical':regenerated,
            'unchanged_observed_math_object_bit_identical':identity(case/'observed_math.o')==reference['objects'][str(SUB/'observed_math.o')] if lane=='observed' else None,
            'extra_objects':extra,'recompiled_units':selected,'module_compile_order':modules,
            'prelink_sha256':digest(case/'owned-prelink.json'),'link_map_sha256':digest(case/'owned-link.map'),
            'static_runtime_sha256':digest(case/'owned-static-runtime.json'),'link_command':link,'native_main_calls':0}
    require(b.protected()==before,'protected input changed');references(b)
    b.dump(directory/'result.json',{'status':'passed','source_index_sha256':b.EXPECTED_SOURCE,'variants':results,
        'reference_plain_BUILD_terminal':PLAIN_TERMINAL,'reference_observed_BUILD_terminal':OBSERVED_TERMINAL,
        'reference_observed_compiled_source':OBSERVED_COMPILED_SOURCE,'eb3_cache_source_provenance':refs['eb3_provenance'],
        'emission_composition_sha256':emitted['composition_sha256'],'native_main_calls':0,'model_calls':0,'reducer_calls':0,
        'runtime_cache_behavior_qualified':False,'plain_observer_parity_qualified':False,'full_caller_qualified':False,
        'scientific_dispatch_enabled':False,'performance_qualified':False})


def verified_build(b):
    references(b);emitted=emission_contract(b);folder=b.WORK/'build'
    require(b.REVIEWED_BUILD and digest(folder/'terminal.json')==b.REVIEWED_BUILD,'exact separately reviewed cache BUILD required')
    term=read(folder/'terminal.json')
    require(term['status']=='passed' and term['returncode']==0 and not term['cleanup']['survivors'],'cache BUILD not closed')
    require(digest(folder/'result.json')==term['result_sha256'],'cache BUILD result changed')
    result=read(folder/'result.json')
    require(result['source_index_sha256']==b.EXPECTED_SOURCE and set(result['variants'])=={'plain','observed'},'wrong cache BUILD source/lanes')
    require(result['emission_composition_sha256']==emitted['composition_sha256'],'cache BUILD overlay receipt changed')
    base=b.local('cms_build');data=read(b.HERE/'input-pins.json')
    import clone_aliases
    for lane,row in result['variants'].items():
        output=folder/lane;case=output/SUB
        require(row['path']==str(case/'check') and not (case/'check').is_symlink() and digest(case/'check')==row['sha256'],'cache ELF changed')
        require(base.source_inventory(output)==row['source_inventory'],'cache source/include changed')
        for name,pin in row['objects'].items():require(identity(output/name)==pin,'cache object changed')
        for name,pin in row['module_files'].items():require(not (case/name).is_symlink() and identity(case/name)==pin,'cache module changed')
        for name,sha in row['actual_link_loads'].items():require(digest(name)==sha,'cache link input changed')
        for name,key in (('owned-prelink.json','prelink_sha256'),('owned-link.map','link_map_sha256'),('owned-static-runtime.json','static_runtime_sha256')):
            require(digest(case/name)==row[key],'cache link/runtime proof changed')
        require(row['runtime']['files']==data['runtime'],'cache15-provider runtime changed')
        for name,sha in data['runtime'].items():require(digest(name)==sha,'cache provider changed')
        require(clone_aliases.validate_shared(output,data['shared_aliases'])==row['immutable_shared_aliases'],'cache aliases changed')
    return result
