"""Pure source transforms for bounded CMS cache observations. No native imports."""
import re


def require(ok, message='cache source contract'):
    if not ok:
        raise ValueError(message)

CACHE_DECL = r"""
  ! Integer-only observations. Getters are never called for an absent context.
  integer,parameter :: maxcache=16384,cache_absent=-777
  type cache_record
    integer :: event=0,source=0,group=0,consumer=0,boundary=0,width=0,n=0,rank=0
    integer :: mode=0,policy=0,status=0,poles=0,gen_before=-1,gen_after=-1
    integer :: before_status(2)=cache_absent,after_status(2)=cache_absent
    character(1024) :: error_prefix=''
    logical :: cache=.false.,check=.false.,finite=.false.
    integer(cache_i64) :: budget=0_cache_i64,before(15)=0_cache_i64,after(15)=0_cache_i64
  end type
  type(cache_record) :: cache_events(maxcache)
  integer :: ncache=0,pending_cache=0
  public :: OBS_CACHE_NATIVE_BEGIN,OBS_CACHE_BUDGET_BEGIN,OBS_CACHE_CLEAR_BEGIN,OBS_CACHE_EVENT_END
"""
CACHE_METHODS = r"""
  subroutine cache_snapshot(counts,status,generation)
    integer(cache_i64),intent(out)::counts(15)
    integer,intent(out)::status(2),generation
    counts=0_cache_i64;status=cache_absent
    generation=TIRUST_CONTEXT_GENERATION()
    ! Both statistics getters otherwise ensure/create the default context.
    if(generation<0)return
    call TIRUST_CACHE_STATISTICS(counts(1:9),status(1))
    call TIRUST_QP_CACHE_STATISTICS(counts(10:15),status(2))
    if(any(status/=0))call fault(21)
  end subroutine
  subroutine cache_begin(event,source)
    integer,intent(in)::event,source
    if(.not.enabled)return
    if(pending_cache/=0)then
      call fault(20);return
    endif
    if(ncache==maxcache)then
      call fault(19);return
    endif
    ncache=ncache+1;pending_cache=ncache;cache_events(ncache)=cache_record()
    associate(r=>cache_events(ncache))
      r%event=event;r%source=source;r%group=current_group;r%consumer=nc;r%boundary=nb
      call cache_snapshot(r%before,r%before_status,r%gen_before)
      if(event/=3.and.r%gen_before<0)call fault(21)
    end associate
  end subroutine
  subroutine OBS_CACHE_NATIVE_BEGIN(width,n,rank,mode,policy,finite,poles,budget,cache,source)
    integer,intent(in)::width,n,rank,mode,policy,poles,source
    integer(cache_i64),intent(in)::budget
    logical,intent(in)::finite,cache
    if(.not.enabled)return
    call cache_begin(1,source)
    if(pending_cache==0)return
    associate(r=>cache_events(pending_cache))
      r%width=width;r%n=n;r%rank=rank;r%mode=mode;r%policy=policy
      r%finite=finite;r%poles=poles;r%budget=budget;r%cache=cache
      r%check=mode==2.or.mode==5
    end associate
  end subroutine
  subroutine OBS_CACHE_BUDGET_BEGIN(budget,source)
    integer(cache_i64),intent(in)::budget
    integer,intent(in)::source
    if(.not.enabled)return
    call cache_begin(2,source)
    if(pending_cache/=0)cache_events(pending_cache)%budget=budget
  end subroutine
  subroutine OBS_CACHE_CLEAR_BEGIN()
    if(.not.enabled)return
    call cache_begin(3,0)
  end subroutine
  subroutine OBS_CACHE_EVENT_END(status)
    integer,intent(in)::status
    if(.not.enabled)return
    if(pending_cache==0)then
      call fault(20);return
    endif
    associate(r=>cache_events(pending_cache))
      r%status=status
      ! Getters clear MTIRUST local_error. Preserve its bounded byte prefix
      ! first; the plain scientific arm retains the original error API state.
      if(status/=0.and.TIRUST_CONTEXT_GENERATION()>=0)call TIRUST_ERROR_MESSAGE(r%error_prefix)
      call cache_snapshot(r%after,r%after_status,r%gen_after)
      if(r%event/=3.and.r%gen_after<0)call fault(21)
      if(r%gen_before/=r%gen_after)call fault(21)
    end associate
    pending_cache=0
  end subroutine
  subroutine cache_drain(lun)
    integer,intent(in)::lun
    integer::k,j,length
    character(4096)::line
    character(2048)::encoded
    call ints(lun,'OBS_CACHE_BEGIN',[ncache,pending_cache])
    do k=1,ncache
      associate(r=>cache_events(k))
        call ints(lun,'OBS_CACHE_EVENT',[k,r%event,r%source,r%group,r%consumer,r%boundary,r%width, &
            r%n,r%rank,r%mode,r%policy,merge(1,0,r%cache),merge(1,0,r%check),merge(1,0,r%finite), &
            r%poles,r%status,r%gen_before,r%gen_after,r%before_status,r%after_status])
        write(line,'(A,1X,I0,*(1X,Z16.16))')'OBS_CACHE_VALUES',k,r%budget,r%before,r%after
        call emit(lun,line)
        length=len_trim(r%error_prefix)
        ! The existing API does not expose required length. A failure prefix
        ! never claims to be the complete original message.
        call ints(lun,'OBS_CACHE_ERROR',[k,length,merge(1,0,r%status/=0)])
        if(length>0)then
          do j=1,length
            write(encoded(2*j-1:2*j),'(Z2.2)')iachar(r%error_prefix(j:j))
          enddo
          write(line,'(A,1X,I0,1X,A)')'OBS_CACHE_ERROR_BYTES',k,encoded(:2*length)
          call emit(lun,line)
        endif
      end associate
    enddo
  end subroutine
"""


def observer(text):
    require(text.count('module ML5_0_CMS_OBSERVER\n') == 2)  # module/end module
    require('OBS_CACHE_BEGIN' not in text)
    text = text.replace('module ML5_0_CMS_OBSERVER\n', 'module ML5_0_CMS_OBSERVER\n  use, intrinsic :: iso_c_binding, only: cache_i64=>c_int64_t\n  use MTIRUST, only: TIRUST_CACHE_STATISTICS,TIRUST_QP_CACHE_STATISTICS,TIRUST_CONTEXT_GENERATION, &\n      TIRUST_ERROR_MESSAGE\n', 1)
    text = text.replace('  public :: OBS_DRAIN_SUCCEEDED\n', '  public :: OBS_DRAIN_SUCCEEDED\n' + CACHE_DECL, 1)
    text = text.replace('    failed=0;last_commit=0;serialized=0_i64;serialization_full=.false.\n', '    failed=0;last_commit=0;serialized=0_i64;serialization_full=.false.\n    ncache=0;pending_cache=0\n', 1)
    text = text.replace('  subroutine fault(bit)\n', CACHE_METHODS + '\n  subroutine fault(bit)\n', 1)
    text = text.replace('    if(cf/=0.or.ci/=0.or.cj/=0)call fault(11)\n', '    if(cf/=0.or.ci/=0.or.cj/=0)call fault(11)\n    if(pending_cache/=0)call fault(20)\n', 1)
    text = text.replace('    ! Reserved4096 bytes ensure the terminal failure record fits the byte cap.\n', '    call cache_drain(lun)\n    ! Reserved4096 bytes ensure the terminal failure record fits the byte cap.\n', 1)
    return text


def tirust(text):
    # Scientific subroutines are fixed-form; unit boundaries are standalone END.
    units = re.split(r'(?m)(?<=\n)(?=      (?:SUBROUTINE|BLOCK DATA))', text)
    mapping = []
    for i, unit in enumerate(units):
        calls = list(re.finditer(r'(?m)^      CALL TIRUST_TENSOR_EVALUATE(_QP)?\(', unit))
        if not calls:
            continue
        require(len(calls) == 1)
        tag = len(mapping) + 1
        # MTIRUST resolves this generic from actual argument kinds. The public
        # procedure name is identical for DP/QP; bind to its actual PL view.
        dp_view = '      REAL*8 PL(0:3,NLOOPLINE)\n' in unit
        qp_view = '      REAL*16 PL(0:3,NLOOPLINE)\n' in unit
        require(dp_view != qp_view)
        width = 128 if qp_view else 64
        compact = ''.join(line[6:] for line in unit.splitlines()
                          if not line.startswith(('C', 'c', '!')))
        compact = re.sub(r'\s+', '', compact).upper()
        real_kind, complex_kind = ('16', '32') if qp_view else ('8', '16')
        # Bind every generic actual, not only PL or a procedure-name guess.
        require(f'REAL*{real_kind}SHIFTS(0:3,NLOOPLINE),P_S_MAT(NLOOPLINE,0:3)' in compact)
        require(f'REAL*{real_kind}PDEN_DUMMY(0:3,NLOOPLINE-1),INVARIANTS(NLOOPLINE,NLOOPLINE),SCALE' in compact)
        require(f'COMPLEX*{complex_kind}MASSES(NLOOPLINE),S_MAT(NLOOPLINE,NLOOPLINE)' in compact)
        require(f'COMPLEX*{complex_kind}RAW(LOOPMAXCOEFS,4)' in compact)
        require('CALLTIRUST_TENSOR_EVALUATE(NLOOPLINE,RANK,SHIFTS,INVARIANTS,MASSES,SCALE,RAW(1:NC,1:4),STATUS,' in compact)
        header = unit[:unit.find('\n      USE ')]
        mapping.append({'tag': tag, 'width': width, 'header': header.strip()})
        if '      USE ML5_0_CMS_OBSERVER\n' not in unit:
            at = unit.find('\n      USE ')
            require(at >= 0)
            unit = unit[:at] + '\n      USE ML5_0_CMS_OBSERVER,ONLY:\n     $ OBS_CACHE_BUDGET_BEGIN,OBS_CACHE_NATIVE_BEGIN,\n     $ OBS_CACHE_EVENT_END' + unit[at:]
        before = '      CALL TIRUST_SET_CACHE_BUDGET(INT(TIRUSTCACHEMAXBYTES,C_INT64_T)\n     $ ,STATUS)'
        require(unit.count(before) == 1)
        unit = unit.replace(before, f'      CALL OBS_CACHE_BUDGET_BEGIN(INT(TIRUSTCACHEMAXBYTES,C_INT64_T)\n     $ ,{tag})\n' + before + '\n      CALL OBS_CACHE_EVENT_END(STATUS)', 1)
        start = '      CALL TIRUST_TENSOR_EVALUATE' + (calls[0].group(1) or '') + '('
        prefix = f'''      CALL OBS_CACHE_NATIVE_BEGIN({width},NLOOPLINE,RANK,CTMODE,
     $ TIRUSTGLOBALCACHE,TIRUSTCOMPUTEFINITE,MAX(0,LOOPPOLEMODE),
     $ INT(TIRUSTCACHEMAXBYTES,C_INT64_T),CACHE_ENABLED,{tag})
'''
        require(unit.count(start) == 1)
        unit = unit.replace(start, prefix + start, 1)
        lines = unit.splitlines(keepends=True)
        out = []
        in_call = False
        for line in lines:
            if in_call and not line.startswith('     $'):
                out.append('      CALL OBS_CACHE_EVENT_END(STATUS)\n')
                in_call = False
            out.append(line)
            if line.startswith(start):
                in_call = True
        require(not in_call)
        units[i] = ''.join(out)
    text = ''.join(units)
    old = '''      SUBROUTINE ML5_0_CLEAR_TIRUST_CACHE()
      USE MTIRUST, ONLY: TIRUST_CLEAR_CACHE,
     $                  TIRUST_CONTEXT_GENERATION
C     The shared module context may belong to another subprocess.
C     Event clearing must not create it before any TIRust use.
      IF(TIRUST_CONTEXT_GENERATION().GE.0) THEN
        CALL TIRUST_CLEAR_CACHE()
      ENDIF
      END
'''
    new = '''      SUBROUTINE ML5_0_CLEAR_TIRUST_CACHE()
      USE ML5_0_CMS_OBSERVER,ONLY:OBS_CACHE_CLEAR_BEGIN,
     $ OBS_CACHE_EVENT_END
      USE MTIRUST, ONLY: TIRUST_CLEAR_CACHE,
     $                  TIRUST_CONTEXT_GENERATION
      IMPLICIT NONE
      INTEGER STATUS
C     Getters and clearing must not create an unused context.
      CALL OBS_CACHE_CLEAR_BEGIN()
      STATUS=0
      IF(TIRUST_CONTEXT_GENERATION().GE.0) THEN
        CALL TIRUST_CLEAR_CACHE(STATUS)
      ENDIF
      CALL OBS_CACHE_EVENT_END(STATUS)
      END
'''
    require(text.count(old) == 1)
    text = text.replace(old, new, 1)
    require(len(mapping) == 10)
    require([row['width'] for row in mapping] == [64, 128] * 5)
    return text, mapping
