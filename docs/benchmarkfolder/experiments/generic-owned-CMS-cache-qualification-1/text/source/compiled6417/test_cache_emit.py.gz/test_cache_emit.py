"""Pure string/policy regressions. No compilation or numerical evaluation."""
from pathlib import Path
from contextlib import ExitStack
import builtins
import io
import json
import types
import unittest

HERE=Path(__file__).resolve().parent
emitter=types.ModuleType('_private_CMS_cache_emit_test');emitter.__file__=str(HERE/'cache_emit.py')
exec(compile((HERE/'cache_emit.py').read_bytes(),emitter.__file__,'exec'),emitter.__dict__)


class CacheSource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source={n:(emitter.SOURCE/n).read_text() for n in emitter.PINS}
        cls.files,cls.report,cls.patch=emitter.render(cls.source)

    def test_exact_nine_route_and_six_cache_sites(self):
        changes=self.report['changes']
        self.assertEqual(len(changes),15)
        self.assertEqual({c['routine'] for c in changes if c['file']=='CT_interface.f'},emitter.ROUTE_NAMES)
        self.assertEqual({c['routine'] for c in changes if c['file']=='TIRUST_interface.f'},emitter.CACHE_NAMES)
        self.assertEqual(self.files['CT_interface.f'].count(emitter.NEW_ROUTE),9)
        self.assertNotIn(emitter.OLD_ROUTE,self.files['CT_interface.f'])

    def test_only_supported_integer_policy_domain_is_relaxed(self):
        # Pure integer truth table, not execution of the emitted Fortran.
        for policy,expected in [(-3,False),(-2,False),(-1,True),(0,True),(1,True),(4,True)]:
            self.assertEqual(policy>=-1,expected)
        self.assertIn('TIRUSTGLOBALCACHE.GE.-1',self.files['CT_interface.f'])

    def test_existing_public_topology_policy_is_copied_exactly(self):
        self.assertEqual(self.source['TIRUST_interface.f'].count(emitter.PUBLIC_CACHE),4)
        self.assertEqual(self.files['TIRUST_interface.f'].count(emitter.PUBLIC_CACHE),10)
        self.assertNotIn(emitter.OLD_CACHE,self.files['TIRUST_interface.f'])
        for limit,n,expected in [(-1,4,True),(0,4,False),(3,4,False),(4,4,True),(5,4,True)]:
            self.assertEqual(limit==-1 or n<=limit,expected)

    def test_check_modes_and_native_calls_are_unchanged(self):
        for name in emitter.PINS:
            for needle in ['CHECK_PASS=CTMODE.EQ.2.OR.CTMODE.EQ.5',
                           'CALL TIRUST_TENSOR_EVALUATE','CALL OBS_NATIVE_RETURN(STATUS)',
                           'IF(STATUS.NE.TIRUST_SUCCESS) RETURN']:
                self.assertEqual(self.source[name].count(needle),self.files[name].count(needle))
        for mode in (1,2,4,5):
            check=mode in (2,5)
            self.assertEqual(True and not check,mode in (1,4))

    def test_all_other_bytes_and_mathematical_guards_survive(self):
        self.assertEqual(self.files['CT_interface.f'].replace(emitter.NEW_ROUTE,emitter.OLD_ROUTE),
                         self.source['CT_interface.f'])
        before=self.source['TIRUST_interface.f'].splitlines(True)
        after=self.files['TIRUST_interface.f'].splitlines(True);offset=0
        for line in before:
            expected=emitter.PUBLIC_CACHE.splitlines(True) if line==emitter.OLD_CACHE else [line]
            self.assertEqual(after[offset:offset+len(expected)],expected);offset+=len(expected)
        self.assertEqual(offset,len(after))
        for needle in ['POINT_WORDS_MATCH','OWNED_RAW_EQUAL','CERTIFY_OWNED','OS_GENUINE_QP',
                       'OS_CURRENT_WORDS','OS_MASK','OS_USE(I,J)','IEEE_IS_FINITE']:
            self.assertEqual(sum(s.count(needle) for s in self.source.values()),
                             sum(s.count(needle) for s in self.files.values()))

    def test_public_prefixes_and_no_new_failure_clear_or_abi(self):
        for name,old_anchor in [('CT_interface.f',emitter.OLD_ROUTE),('TIRUST_interface.f',emitter.OLD_CACHE)]:
            prefix=self.source[name][:self.source[name].index(old_anchor)]
            self.assertTrue(self.files[name].startswith(prefix))
        self.assertFalse(self.report['finite_rejection_clear_helper_added'])
        self.assertFalse(self.report['Rust_source_ABI_DSO_changed'])
        self.assertFalse(self.report['Fortran_group_cache_applicable'])

    def test_wrong_or_changed_input_refuses(self):
        for name in self.source:
            changed=dict(self.source);changed[name]+='\n'
            with self.assertRaisesRegex(ValueError,'frozen source differs'):emitter.render(changed)
        with self.assertRaisesRegex(ValueError,'exact two-file'):emitter.render({'CT_interface.f':self.source['CT_interface.f']})

    def test_width_and_no_admission_or_default_change(self):
        self.assertTrue(all(len(line)<=132 for s in self.files.values() for line in s.splitlines()))
        self.assertEqual(self.patch.count('--- frozen-source2/'),2)
        for key in ('defaults_changed','telemetry_added','build_admitted','run_admitted',
                    'runtime_abi_qualified','full_caller_qualified','scientific_dispatch_enabled'):
            self.assertIs(self.report[key],False)
        for key in ('compiler_calls','loader_calls','native_calls'):self.assertEqual(self.report[key],0)

    def test_closed_plain_candidate_has_identical_shared_unit_delta(self):
        source={n:(emitter.PLAIN_SOURCE/n).read_text() for n in emitter.PLAIN_PINS}
        files,report,_=emitter.render(source,'plain')
        self.assertEqual(len(report['changes']),10)
        self.assertEqual(files['CT_interface.f'].count(emitter.NEW_ROUTE),6)
        self.assertEqual(files['TIRUST_interface.f'].count(emitter.PUBLIC_CACHE),6)
        # Frozen observed inputs append clones to these exact plain source
        # prefixes, so applying the same edits keeps prefix equality too.
        for name,value in files.items():self.assertTrue(self.files[name].startswith(value))


def main():
    # Optional harness-only imports stay outside test-module import so an
    # existing stricter combined source guard can load the test class.
    import ctypes
    import os
    import subprocess
    from unittest.mock import patch
    attempts=[]
    def deny(*args,**kwargs):attempts.append('process/native/write');raise RuntimeError('source-only boundary')
    original=builtins.open;original_io=io.open
    def reader(function):
        def opened(file,mode='r',*args,**kwargs):
            if isinstance(file,int) or any(c in mode for c in 'wax+'):return deny()
            return function(file,mode,*args,**kwargs)
        return opened
    log=io.StringIO()
    with ExitStack() as stack:
        for n in ('Popen','run','call','check_call','check_output'):stack.enter_context(patch.object(subprocess,n,deny))
        for n in ('system','popen','fork','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'):
            if hasattr(os,n):stack.enter_context(patch.object(os,n,deny))
        for n in ('CDLL','PyDLL'):stack.enter_context(patch.object(ctypes,n,deny))
        stack.enter_context(patch.object(ctypes.cdll,'LoadLibrary',deny))
        stack.enter_context(patch.object(builtins,'open',reader(original)))
        stack.enter_context(patch.object(io,'open',reader(original_io)))
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CacheSource))
    print(log.getvalue(),end='')
    print(json.dumps({'status':'pass' if result.wasSuccessful() and not attempts else 'fail','tests':result.testsRun,
        'forbidden_api_attempts':attempts,'compiler_calls':0,'loader_calls':0,'native_calls':0,
        'scientific_dispatch_enabled':False},sort_keys=True))
    return result.wasSuccessful() and not attempts


if __name__=='__main__':raise SystemExit(0 if main() else 1)
