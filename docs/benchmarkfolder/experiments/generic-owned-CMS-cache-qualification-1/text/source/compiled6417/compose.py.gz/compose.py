"""Private source composition only. Process/native operations are not imported."""
from pathlib import Path
import hashlib
import json
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
PARENT = ROOT / '.tirust-build/generic-owned-CMS-observer-qualification-proposal-2'
_namespace = {'__file__': str(HERE / 'cache_telemetry_render.py'), '__name__': 'cache_telemetry_render'}
exec(compile((HERE / 'cache_telemetry_render.py').read_text(), str(HERE / 'cache_telemetry_render.py'), 'exec'), _namespace)
telemetry = types.SimpleNamespace(**_namespace)


def require(ok, message='cache composition contract'):
    if not ok:
        raise ValueError(message)


def pin(path):
    body = path.read_bytes()
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def compose():
    route = HERE / 'emittedsrc/observed-base'
    target = HERE / 'emittedsrc/observed'
    target.mkdir(exist_ok=True)
    dispatch = (route / 'CT_interface.f').read_text()
    (target / 'CT_interface.f').write_text(dispatch)
    native, mapping = telemetry.tirust((route / 'TIRUST_interface.f').read_text())
    (target / 'TIRUST_interface.f').write_text(native)
    (target / 'observer.f90').write_text(telemetry.observer((PARENT / 'emittedsrc/candidate/observer.f90').read_text()))
    parser = (PARENT / 'observer_analysis.py').read_text()
    old_sha = '5dbe44e671be8e9bad32a6910b5ec9da18f0005e19bcdbf2cb1d19ff28501619'
    require(old_sha in parser)
    parser = parser.replace(old_sha, hashlib.sha256(dispatch.encode()).hexdigest())
    parser = parser.replace('def parse_journal(text, *, sequence,request,point_id,compiled_dispatch_source=None):',
                            'def parse_journal(text, *, sequence,request,point_id,compiled_dispatch_source=None,cache_policy=None,cache_budget=None):')
    parser = parser.replace("or f['cache_enabled']:r.fail('frame current mode/check/cache cohort')",
                            "or f['cache_enabled']!=(cache_policy==-1 or 4<=cache_policy):r.fail('frame current mode/check/cache cohort')")
    parser = parser.replace("    prior=''.join(text.splitlines(keepends=True)[:r.pos])",
        "    cache_observations=parse_cache_rows(r,policy=cache_policy,budget=cache_budget,consumers=consumers,frames=frames,boundaries=boundaries,source_widths=SOURCE_WIDTHS)\n    prior=''.join(text.splitlines(keepends=True)[:r.pos])")
    parser = parser.replace("'boundaries':boundaries,'producers':producers,'consumers':consumers,'frames':frames,",
                            "'boundaries':boundaries,'producers':producers,'consumers':consumers,'frames':frames,'cache_observations':cache_observations,")
    parser = parser.replace('expected_points=None,compiled_dispatch_source=None):',
                            'expected_points=None,compiled_dispatch_source=None,cache_policy=None,cache_budget=None):')
    parser = parser.replace('point_id=point,compiled_dispatch_source=compiled_dispatch_source) for index,',
                            'point_id=point,compiled_dispatch_source=compiled_dispatch_source,cache_policy=cache_policy,cache_budget=cache_budget) for index,')
    # Validate policy before any geometry branch compares it.
    needle = 'def parse_journal(text, *, sequence,request,point_id,compiled_dispatch_source=None,cache_policy=None,cache_budget=None):\n'
    require(parser.count(needle) == 1)
    parser = parser.replace(needle, needle + "    if type(cache_policy) is not int or cache_policy < -1 or type(cache_budget) is not int or cache_budget < 0:_fail('explicit cache policy/budget required',text)\n")
    parser += '\nSOURCE_WIDTHS=' + repr({row['tag']: row['width'] for row in mapping}) + '\n'
    parser += (HERE / 'cache_analysis.py').read_text()
    require('cache_observations=parse_cache_rows' in parser)
    require('or f[\'cache_enabled\']:r.fail' not in parser)
    (HERE / 'observer_analysis.py').write_text(parser)
    # Inherited source retains the original compiler's fixed-form policy.
    # Every newly injected cache API line also fits the stricter 72 columns.
    for name in ('TIRUST_interface.f',):
        for line in (target / name).read_text().splitlines():
            if 'OBS_CACHE' in line:
                require(len(line) <= 72, str((name, len(line), line)))
    require(all(len(line) <= 132 for line in (target / 'observer.f90').read_text().splitlines()))
    outputs = {str(p.relative_to(HERE)): pin(p) for p in [*(target.iterdir()), HERE / 'observer_analysis.py']}
    receipt = {'schema': 'private-CMS-cache-source-composition-v1', 'outputs': outputs,
        'native_call_sources': mapping, 'parent_source': pin(PARENT / 'source-index.json'),
        'route_diff': pin(HERE / 'cache-fortran-diff.json'),
        'native_commands': 0, 'Fortran_group_cache_applicable': False,
        'Rust_C_ABI_changed': False, 'production_changed': False,
        'BUILD_admitted': False, 'RUN_admitted': False, 'independent_truth': False}
    (HERE / 'composition-receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    return receipt


if __name__ == '__main__':
    print(json.dumps(compose(), sort_keys=True))
