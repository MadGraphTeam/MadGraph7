from pathlib import Path
import sys
import unittest

forbidden = []
def guard(event, args):
    if event.startswith(('subprocess.', 'ctypes.dlopen', 'os.system', 'os.exec', 'os.fork', 'os.posix_spawn')):
        forbidden.append(event)
        raise RuntimeError('forbidden process/native operation: '+event)
sys.addaudithook(guard)
path = Path(__file__).resolve().with_name('test_cache_source.py')
namespace = {'__file__':str(path),'__name__':'cache_source_checks'}
exec(compile(path.read_text(),str(path),'exec'),namespace)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(namespace['CacheSourceTests'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
print('forbidden process/native operations:',len(forbidden))
raise SystemExit(not result.wasSuccessful() or bool(forbidden))
