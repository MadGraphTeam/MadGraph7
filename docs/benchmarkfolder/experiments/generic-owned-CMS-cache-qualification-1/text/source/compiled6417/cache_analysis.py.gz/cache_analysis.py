"""Integer-only parsing of bounded cache observations, never a numerical oracle."""
import re

U64WORD = re.compile(r'[0-9A-F]{16}\Z')


def dp_component(snapshot):
    result = list(snapshot[:9])
    for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4)):
        result[i] -= snapshot[9+j]
    return result


def parse_cache_rows(r, *, policy, budget, consumers, frames, boundaries, source_widths):
    if type(policy) is not int or policy < -1 or type(budget) is not int or budget < 0:
        r.fail('undeclared cache policy/budget')
    count, pending = r.ints('OBS_CACHE_BEGIN', 2)
    if not 0 <= count <= 16384 or pending != 0:
        r.fail('cache count/pending bound')
    events = []
    last = None
    for index in range(1, count + 1):
        row = r.ints('OBS_CACHE_EVENT', 22)
        (key, kind, source, group, consumer, boundary, width, n, rank, mode,
         observed_policy, enabled, check, finite, poles, status, gen_before,
         gen_after, bstat, bqstat, astat, aqstat) = row
        if key != index or kind not in (1, 2, 3):
            r.fail('cache event key/kind')
        if not 0 <= group <= 26 or not 0 <= consumer <= len(consumers) or not 0 <= boundary <= len(boundaries):
            r.fail('cache context coordinate')
        values = r.row('OBS_CACHE_VALUES', 32)
        if r.integer(values[0]) != index or any(not U64WORD.fullmatch(w) for w in values[1:]):
            r.fail('cache uint64 key/word')
        words = [int(w, 16) for w in values[1:]]
        recorded_budget, before, after = words[0], words[1:16], words[16:31]
        error_key, error_length, prefix_extent_unknown = r.ints('OBS_CACHE_ERROR', 3)
        if error_key != index or not 0 <= error_length <= 1024 or prefix_extent_unknown != int(status != 0):
            r.fail('cache error-prefix extent')
        error_hex = ''
        if error_length:
            fields = r.row('OBS_CACHE_ERROR_BYTES', 2)
            if r.integer(fields[0]) != index or not re.fullmatch('[0-9A-F]{'+str(2*error_length)+'}',fields[1]):
                r.fail('cache error-prefix byte encoding')
            error_hex = fields[1]
        if status == 0 and error_length:
            r.fail('successful cache event has a stale failure prefix')
        if gen_before != gen_after or gen_before < -1:
            r.fail('cache context generation changed')
        if gen_before < 0:
            if kind != 3 or [bstat, bqstat, astat, aqstat] != [-777] * 4 or any(before + after):
                r.fail('unused cache context was probed/created')
        elif [bstat, bqstat, astat, aqstat] != [0] * 4:
            r.fail('cache statistics getter refused')
        # eb3 was built with poles-only support: DP and pole stores each get
        # total/4, QP gets total/2. This full-only campaign leaves pole store
        # empty; these are native accounted payload bytes, not an RSS claim.
        for snapshot in (before, after):
            q = snapshot[9:]
            if any(snapshot[i] < q[j] for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4))):
                r.fail('aggregate smaller than its QP component')
            if q[3] > budget//2 or snapshot[7]-q[3] > budget//4:
                r.fail('native cache accounted-byte budget exceeded')
        if last and last['gen_after'] == gen_before and last['after'] != before:
            r.fail('unobserved cache counter transition')
        if kind == 3:
            if source != 0 or any((width, n, rank, mode, observed_policy, enabled, check, finite, poles, recorded_budget)):
                r.fail('cache clear metadata')
            if status != 0 or any(after):
                r.fail('cache clear failed/not empty')
        else:
            if source not in source_widths or gen_before < 0 or recorded_budget != budget:
                r.fail('cache source/budget/context')
            if kind == 2:
                if any((width, n, rank, mode, observed_policy, enabled, check, finite, poles)):
                    r.fail('cache budget metadata')
                if status != 0:
                    r.fail('cache budget setter refused')
                # These workers keep one card/budget throughout normal
                # learning and measurement. A per-call repeat must not reset
                # counters; dynamic in-worker budget switching is unqualified.
                if after != before:
                    r.fail('fixed-budget setter reset/changed numerical cache')
                if budget == 0 and (any(after[6:8]) or any(after[11:13])):
                    r.fail('zero-budget store retained entries')
            else:
                if width != source_widths[source] or not 1 <= n <= 6 or not 0 <= rank <= 6:
                    r.fail('cache native width/topology/rank')
                if mode not in (1, 2, 4, 5) or width != (64 if mode in (1, 2) else 128):
                    r.fail('cache native mode/width')
                if not consumer or group == 0 or consumers[consumer - 1]['ctmode'] != mode:
                    r.fail('cache native consumer mode')
                if observed_policy != policy or enabled != int(policy == -1 or n <= policy):
                    r.fail('cache effective topology policy')
                if check != int(mode in (2, 5)) or finite != 1 or poles != 0:
                    r.fail('cache independent-check/full/pole policy')
                if not last or last['kind'] != 2 or last['source'] != source or last['group'] != group or last['consumer'] != consumer:
                    r.fail('native cache call lacks its successful budget event')
                qb, qa = before[9:], after[9:]
                failure_transition = None
                if width == 64:
                    if qa != qb:
                        r.fail('DP call changed QP cache')
                    if status == 0 and (check or not enabled) and after != before:
                        r.fail('DP independent/disabled call used primary tensor store')
                    if status == 0 and enabled and not check and any(a < b for a, b in zip(after[:9], before[:9])):
                        r.fail('successful DP primary call reset numerical cache')
                    if status != 0:
                        # dp_checked clears its full DP store on reduction
                        # failure, but earlier C/Fortran validation can return
                        # without entering it and preserve prior valid values.
                        if after == before:
                            failure_transition = 'DP_unchanged_or_already_empty'
                        elif not any(dp_component(after)):
                            failure_transition = 'DP_full_store_counters_cleared'
                        else:
                            r.fail('failed DP call neither preserved nor cleared its numerical store')
                elif status == 0 and (check or not enabled):
                    if qa[:5] != qb[:5] or qa[5] != qb[5] + 1 or after[:9] != before[:9]:
                        r.fail('QP independent/disabled call reused/inserted primary cache')
                elif status == 0:
                    delta = [a - b for a, b in zip(qa, qb)]
                    hit = delta == [1, 0, 0, 0, 0, 0]
                    stored = delta[0:3] == [0, 1, 1] and delta[3] > 0 and delta[4:] == [0, 0]
                    refused = delta == [0, 1, 0, 0, 1, 0]
                    if not (hit or stored or refused):
                        r.fail('QP primary call lacks one hit/miss')
                elif status != 0:
                    delta = [a-b for a,b in zip(qa,qb)]
                    before_native = delta == [0]*6
                    failed_miss = enabled and not check and delta == [0,1,0,0,0,0]
                    failed_bypass = (check or not enabled) and delta == [0,0,0,0,0,1]
                    if not any(after):
                        failure_transition = 'QP_all_counters_zero; decode_clear_or_already_empty_compatible'
                    elif dp_component(after) == dp_component(before) and (before_native or failed_miss or failed_bypass):
                        failure_transition = 'QP_no_insert_with_DP_store_unchanged; exact_failure_phase_not_inferred'
                    else:
                        r.fail('failed QP call inserted/altered an unrelated store')
                if width == 128 and status == 0:
                    if after[:4] != before[:4] or any(after[i] - before[i] != qa[j] - qb[j]
                            for i, j in ((4, 0), (5, 1), (6, 2), (7, 3), (8, 4))):
                        r.fail('QP/aggregate counter join')
                if budget == 0 and (any(after[6:8]) or any(after[11:13])):
                    r.fail('zero-budget native call retained entries')
        event = dict(index=index, kind=kind, source=source, group=group, consumer=consumer,
                     boundary=boundary, width=width, n=n, rank=rank, mode=mode,
                     policy=observed_policy, cache_enabled=bool(enabled), check_pass=bool(check),
                     status=status, gen_before=gen_before, gen_after=gen_after,
                     budget=recorded_budget, before=before, after=after,
                     error_prefix_hex=error_hex,error_prefix_extent_unknown=bool(prefix_extent_unknown))
        if kind == 1:
            event['failure_cache_transition'] = failure_transition
        events.append(event)
        last = event
    native = [e for e in events if e['kind'] == 1]
    # Geometry remains independently source/word validated. Join every group3
    # native frame to its exact telemetry policy/status, never infer a veto hit.
    selected = [e for e in native if e['group'] == 3]
    if len(selected) != len(frames):
        r.fail('group3 geometry/cache call count')
    for event, frame in zip(selected, frames):
        if (event['consumer'], event['mode'], event['width'], event['rank'], event['status'], event['check_pass'], event['cache_enabled']) != (
                frame['consumer'], frame['ctmode'], frame['width'], frame['rank'], frame['native_status'], frame['check_pass'], frame['cache_enabled']):
            r.fail('group3 geometry/cache policy/status join')
    return {'schema': 'cms-cache-integer-observations-v1', 'events': events,
            'native_calls': len(native), 'groups_seen': sorted({e['group'] for e in native}),
            'Fortran_group_cache_applicable': False, 'independent_truth': False,
            'positive_group3_hit_required': False, 'performance_qualified': False}
