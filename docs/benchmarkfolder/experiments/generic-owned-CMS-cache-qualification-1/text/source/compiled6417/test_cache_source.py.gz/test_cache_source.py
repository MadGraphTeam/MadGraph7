from pathlib import Path
import hashlib
import json
import re
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent


def load(name):
    ns = {'__name__': name, '__file__': str(HERE / (name + '.py'))}
    exec(compile((HERE / (name + '.py')).read_text(), ns['__file__'], 'exec'), ns)
    return ns


class Reader:
    def __init__(self, rows):
        self.rows = iter(rows)
    def fail(self, message):
        raise ValueError(message)
    def row(self, tag, n):
        got, values = next(self.rows)
        if got != tag or len(values) != n:
            self.fail('tag/cardinality')
        return [str(v) for v in values]
    def integer(self, value):
        if not re.fullmatch(r'-?(?:0|[1-9][0-9]*)', value):
            self.fail('integer')
        return int(value)
    def ints(self, tag, n):
        return [self.integer(v) for v in self.row(tag, n)]


def event(kind, *, source=1, mode=0, width=0, policy=0, enabled=0, check=0,
          status=0, before=None, after=None, generation=1, budget=268435456):
    if before is None: before = [0] * 15
    if after is None: after = list(before)
    meta = [kind, source, 3, 1, 0, width, 4 if kind == 1 else 0,
            2 if kind == 1 else 0, mode, policy, enabled, check,
            int(kind == 1), 0, status, generation, generation, 0, 0, 0, 0]
    return meta, [budget, *before, *after]


def rows(events):
    result = [('OBS_CACHE_BEGIN', [len(events), 0])]
    for index, (meta, values) in enumerate(events, 1):
        result += [('OBS_CACHE_EVENT', [index, *meta]),
                   ('OBS_CACHE_VALUES', [index, *[f'{v:016X}' for v in values]]),
                   ('OBS_CACHE_ERROR', [index,0,int(meta[14]!=0)])]
    return result


class CacheSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.render = load('cache_telemetry_render')
        cls.parse = staticmethod(load('cache_analysis')['parse_cache_rows'])
        cls.old = ROOT / '.tirust-build/generic-owned-CMS-observer-qualification-proposal-2'
    def parse_events(self, events, *, policy=-1, budget=268435456, frame=None, reader_rows=None):
        if frame is None:
            last = events[-1][0]
            frame = dict(consumer=1, ctmode=last[8], width=last[5], rank=2,
                         native_status=last[14], check_pass=bool(last[11]), cache_enabled=bool(last[10]))
        return self.parse(Reader(rows(events) if reader_rows is None else reader_rows),
            policy=policy, budget=budget, consumers=[{'ctmode': frame['ctmode']}],
            frames=[frame], boundaries=[], source_widths={1:64, 2:128})
    def qp(self, *, mode=4, policy=-1, enabled=1, status=0, after=None, budget=268435456):
        return [event(2, source=2, budget=budget), event(1, source=2, mode=mode,
            width=128, policy=policy, enabled=enabled, check=int(mode == 5), status=status,
            after=after, budget=budget)]
    def test_all_generic_actual_argument_widths(self):
        source = (HERE / 'emittedsrc/observed-base/TIRUST_interface.f').read_text()
        generated, mapping = self.render['tirust'](source)
        self.assertEqual([m['width'] for m in mapping], [64,128] * 5)
        self.assertEqual(generated.count('      CALL OBS_CACHE_NATIVE_BEGIN('), 10)
        self.assertEqual(generated.count('      CALL OBS_CACHE_EVENT_END(STATUS)'), 21)
        self.assertEqual(generated.count('      CALL TIRUST_TENSOR_EVALUATE('), 10)
    def test_scientific_tirust_bytes_recover_exactly(self):
        source = (HERE / 'emittedsrc/observed-base/TIRUST_interface.f').read_text()
        generated, _ = self.render['tirust'](source)
        clear = r'(?ms)^      SUBROUTINE ML5_0_CLEAR_TIRUST_CACHE\(\).*?^      END\n'
        old_clear = re.search(clear,source).group()
        generated = re.sub(clear,lambda _:old_clear,generated,count=1)
        generated = re.sub(r'(?m)^      CALL OBS_CACHE_NATIVE_BEGIN\([^\n]*\n(?:     \$[^\n]*\n){2}', '', generated)
        generated = re.sub(r'(?m)^      CALL OBS_CACHE_BUDGET_BEGIN\([^\n]*\n     \$[^\n]*\n', '', generated)
        generated = generated.replace('      CALL OBS_CACHE_EVENT_END(STATUS)\n','')
        generated = generated.replace('      USE ML5_0_CMS_OBSERVER,ONLY:\n     $ OBS_CACHE_BUDGET_BEGIN,OBS_CACHE_NATIVE_BEGIN,\n     $ OBS_CACHE_EVENT_END\n','')
        self.assertEqual(generated,source)
    def test_original_numeric_callers_do_not_read_error_api(self):
        for name in ('CT_interface.f','TIRUST_interface.f'):
            source=(HERE/'emittedsrc/observed-base'/name).read_text().upper()
            self.assertNotIn('TIRUST_ERROR_MESSAGE',source)
            self.assertNotIn('LOCAL_ERROR',source)
            self.assertNotIn('LAST_ERROR',source)
    def test_unknown_actual_kind_rejected(self):
        source = (HERE / 'emittedsrc/observed-base/TIRUST_interface.f').read_text()
        with self.assertRaises(ValueError):
            self.render['tirust'](source.replace('      REAL*16 PL(0:3,NLOOPLINE)', '      REAL*10 PL(0:3,NLOOPLINE)', 1))
    def test_generic_shift_kind_mismatch_rejected(self):
        source = (HERE / 'emittedsrc/observed-base/TIRUST_interface.f').read_text()
        with self.assertRaises(ValueError):
            self.render['tirust'](source.replace('REAL*16 SHIFTS', 'REAL*8 SHIFTS', 1))
    def test_doubled_observer_rejected(self):
        source = (self.old / 'emittedsrc/candidate/observer.f90').read_text()
        generated = self.render['observer'](source)
        with self.assertRaises(ValueError): self.render['observer'](generated)
    def test_unused_context_guard_precedes_both_getters(self):
        methods = self.render['CACHE_METHODS']
        snapshot = methods.split('  subroutine cache_snapshot',1)[1].split('  end subroutine',1)[0]
        guard = snapshot.index('if(generation<0)return')
        self.assertLess(guard, snapshot.index('call TIRUST_CACHE_STATISTICS'))
        self.assertLess(guard, snapshot.index('call TIRUST_QP_CACHE_STATISTICS'))
        self.assertNotIn('TIRUST_INITIALIZE', methods)
    def test_error_prefix_copied_before_statistics(self):
        body=self.render['CACHE_METHODS'].split('  subroutine OBS_CACHE_EVENT_END',1)[1].split('  end subroutine',1)[0]
        self.assertLess(body.index('call TIRUST_ERROR_MESSAGE'),body.index('call cache_snapshot'))
    def test_dp_check_primary_store_change_rejected(self):
        after = [0] * 15; after[0] = 1
        events = [event(2), event(1, mode=2, width=64, policy=-1, enabled=1, check=1, after=after)]
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_dp_failed_numerical_entries_rejected(self):
        after = [0] * 15; after[6] = 1
        events = [event(2), event(1, mode=1, width=64, policy=-1, enabled=1, status=1, after=after)]
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_dp_preentry_failure_preserves_prior_valid_store(self):
        previous = [0] * 15; previous[6] = 1; previous[7] = 512
        events = [event(2,before=previous),event(1,mode=1,width=64,policy=-1,enabled=1,
            status=1,before=previous,after=previous)]
        result=self.parse_events(events)
        self.assertEqual(result['events'][-1]['failure_cache_transition'],'DP_unchanged_or_already_empty')
    def test_dp_entered_failure_clears_all_dp_statistics(self):
        previous = [0] * 15; previous[0] = 3; previous[6] = 1; previous[7] = 512
        events = [event(2,before=previous),event(1,mode=1,width=64,policy=-1,enabled=1,
            status=1,before=previous,after=[0]*15)]
        result=self.parse_events(events)
        self.assertEqual(result['events'][-1]['failure_cache_transition'],'DP_full_store_counters_cleared')
    def test_qp_primary_hit(self):
        after = [0] * 15; after[4] = after[9] = 1
        result = self.parse_events(self.qp(after=after))
        self.assertEqual(result['native_calls'], 1)
        self.assertFalse(result['positive_group3_hit_required'])
    def test_qp_primary_miss(self):
        after = [0] * 15; after[5] = after[10] = after[6] = after[11] = 1
        after[7] = after[12] = 512
        self.parse_events(self.qp(after=after))
    def test_qp_hit_store_change_rejected(self):
        after = [0] * 15; after[4] = after[9] = after[6] = after[11] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(after=after))
    def test_qp_miss_without_insert_or_refusal_rejected(self):
        after = [0] * 15; after[5] = after[10] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(after=after))
    def test_qp_check_bypass(self):
        after = [0] * 15; after[14] = 1
        self.parse_events(self.qp(mode=5, after=after))
    def test_qp_disabled_bypass(self):
        after = [0] * 15; after[14] = 1
        self.parse_events(self.qp(policy=0, enabled=0, after=after), policy=0)
    def test_qp_check_hit_rejected(self):
        after = [0] * 15; after[4] = after[9] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(mode=5, after=after))
    def test_qp_failed_insert_rejected(self):
        after = [0] * 15; after[6] = after[11] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(status=1, after=after))
    def test_qp_failed_miss_preserves_prior_dp_store(self):
        previous=[0]*15;previous[6]=1;previous[7]=512
        after=list(previous);after[5]=after[10]=1
        events=[event(2,source=2,before=previous),event(1,source=2,mode=4,width=128,
            policy=-1,enabled=1,status=1,before=previous,after=after)]
        self.parse_events(events)
    def test_qp_failure_unrelated_dp_growth_rejected(self):
        after=[0]*15;after[0]=1;after[5]=after[10]=1
        with self.assertRaises(ValueError):self.parse_events(self.qp(status=1,after=after))
    def test_qp_transport_failure_clear_all_compatible(self):
        previous=[0]*15;previous[6]=1;previous[7]=512
        events=[event(2,source=2,before=previous),event(1,source=2,mode=4,width=128,
            policy=-1,enabled=1,status=1,before=previous,after=[0]*15)]
        self.parse_events(events)
    def test_qp_mixed_aggregate_rejected(self):
        after = [0] * 15; after[9] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(after=after))
    def test_qp_accounted_budget_excess_rejected(self):
        after = [0] * 15; after[5] = after[10] = after[6] = after[11] = 1
        after[7] = after[12] = 268435456
        with self.assertRaises(ValueError): self.parse_events(self.qp(after=after))
    def test_wrong_policy_rejected(self):
        after = [0] * 15; after[4] = after[9] = 1
        with self.assertRaises(ValueError): self.parse_events(self.qp(policy=0, after=after), policy=0)
    def test_topology_limited_qp_bypass(self):
        after = [0] * 15; after[14] = 1
        self.parse_events(self.qp(policy=3, enabled=0, after=after), policy=3)
    def test_zero_budget_refusal(self):
        after = [0] * 15; after[5] = after[10] = after[8] = after[13] = 1
        self.parse_events(self.qp(after=after, budget=0), budget=0)
    def test_counter_gap_rejected(self):
        events = self.qp();events[1][1][1] = 1
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_fixed_budget_setter_reset_rejected(self):
        before = [0] * 15; before[0] = 1
        events = [event(2,before=before,after=[0]*15), event(1,mode=1,width=64,policy=-1,enabled=1)]
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_dp_successful_primary_reset_rejected(self):
        before = [0] * 15; before[0] = 1
        events = [event(2,before=before), event(1,mode=1,width=64,policy=-1,enabled=1,before=before,after=[0]*15)]
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_missing_budget_event_rejected(self):
        with self.assertRaises(ValueError): self.parse_events(self.qp()[1:])
    def test_native_kind_mismatch_rejected(self):
        events = self.qp();events[1][0][5] = 64
        with self.assertRaises(ValueError): self.parse_events(events)
    def test_unused_context_clear(self):
        meta = [3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,-777,-777,-777,-777]
        result = self.parse(Reader(rows([(meta,[0]*31)])),policy=-1,budget=268435456,
            consumers=[],frames=[],boundaries=[],source_widths={1:64,2:128})
        self.assertEqual(result['native_calls'],0)
    def test_getter_on_unused_context_rejected(self):
        meta = [3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,0,0,0,0]
        with self.assertRaises(ValueError):
            self.parse(Reader(rows([(meta,[0]*31)])),policy=-1,budget=0,consumers=[],frames=[],boundaries=[],source_widths={})
    def test_clear_must_reset_all_counters(self):
        meta = [3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0]
        values=[0]*31;values[16]=1
        with self.assertRaises(ValueError):
            self.parse(Reader(rows([(meta,values)])),policy=-1,budget=268435456,consumers=[],frames=[],boundaries=[],source_widths={})
    def test_generated_parser_requires_explicit_policy(self):
        parser=load('observer_analysis')
        with self.assertRaises(parser['ObserverError']):
            parser['parse_journal']('',sequence=1,request=0,point_id=1)
    def test_only_declared_runtime_card_fields_change(self):
        contract=json.loads((HERE/'cache-policies.json').read_text())
        original=(HERE/'cards/MadLoopParams.dat').read_text()
        self.assertEqual(hashlib.sha256(original.encode()).hexdigest(),contract['base_card_sha256'])
        for row in contract['policies'].values():
            card=(HERE/row['runtime_card']).read_text()
            self.assertEqual(hashlib.sha256(card.encode()).hexdigest(),row['sha256'])
            restored=card.replace('#TIRustGlobalCache\n'+str(row['GlobalCache'])+'\n','#TIRustGlobalCache\n0\n')
            restored=restored.replace('#TIRustCacheMaxBytes\n'+str(row['CacheMaxBytes'])+'\n','#TIRustCacheMaxBytes\n268435456\n')
            self.assertEqual(restored,original)
        self.assertIn('#MLStabThres\n1.000000d-06\n',original)
        self.assertIn('#TIRustComputeFinite\n.TRUE.\n',original)
    def test_controller_build_only_caps_and_run_rejection(self):
        controller=load('controller');b=controller['configure']()
        self.assertEqual(b.CAPS,{'build':1800.})
        self.assertEqual(b.LIMITS,{'address_space_bytes':17179869184,'file_bytes':268435456,'core_bytes':0})
        b.PHASE='run'
        with self.assertRaises(ValueError):b.work_namespace()


if __name__ == '__main__': unittest.main()
