"""Exact two-file private Fortran cache-policy successor; SOURCE ONLY.

No Rust/default/ABI/library change, predicate/FP reevaluation or telemetry.
The parent supplies the separate observer, parser, controller and admission.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'generic-owned-CMS-observer-qualification-proposal-2/emittedsrc/candidate'
PINS={'CT_interface.f':'5dbe44e671be8e9bad32a6910b5ec9da18f0005e19bcdbf2cb1d19ff28501619',
      'TIRUST_interface.f':'5cc83fbb817fcf501b10d91a9d02fc9cad5408b5a45285e1f40e73d25427c16c'}
PLAIN_SOURCE=HERE.parent/'generic-owned-CMS-plain-build-work-2/build/candidate/SubProcesses/P0_epem_mupmum'
PLAIN_PINS={'CT_interface.f':'66b4110707080951b3893309cb8632c10fcb5aca8c4e119d4d19a688562751cc',
            'TIRUST_interface.f':'3533ce2de2a0aa01481cb402e2a3ad2b79d68eb24b7feb16b821bd1db311613d'}
OLD_ROUTE='      IF(TIRUSTGLOBALCACHE.EQ.0)THEN\n'
NEW_ROUTE='      IF(TIRUSTGLOBALCACHE.GE.-1)THEN\n'
OLD_CACHE='      CACHE_ENABLED=.FALSE.\n'
PUBLIC_CACHE=('      CACHE_ENABLED=TIRUSTGLOBALCACHE.EQ.\n'
              '     $ -1.OR.NLOOPLINE.LE.TIRUSTGLOBALCACHE\n')
ROUTE_NAMES={'ML5_0_'+prefix+'LOOP_'+str(n) for prefix in ('OWNED_','PM_','OBS_PM_') for n in (2,3,4)}
CACHE_NAMES={'ML5_0_'+prefix+precision+'TIRUST_TENSOR_DIAGNOSTIC'
             for prefix in ('OWNED_','PM_','OBS_PM_') for precision in ('','MP_')}


def need(condition,message):
    if not condition:raise ValueError(message)


def identity(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def locations(source,needle):
    """Coordinates only, on authenticated exact bytes; no control-flow parser."""
    routine=None;result=[]
    for number,line in enumerate(source.splitlines(True),1):
        match=re.match(r'      SUBROUTINE\s*([A-Z][A-Z0-9_]*)\(',line,re.I)
        if match:routine=match.group(1).upper()
        if line==needle:result.append({'line':number,'routine':routine})
    return result


def render(sources,lane='observed-base'):
    need(lane in ('observed-base','plain'),'exact cache source lane required')
    pins=PINS if lane=='observed-base' else PLAIN_PINS
    route_names=ROUTE_NAMES if lane=='observed-base' else {n for n in ROUTE_NAMES if not n.startswith('ML5_0_OBS_')}
    cache_names=CACHE_NAMES if lane=='observed-base' else {n for n in CACHE_NAMES if not n.startswith('ML5_0_OBS_')}
    need(set(sources)==set(pins),'exact two-file source family required')
    for name,source in sources.items():
        need(type(source) is str and identity(source.encode())['sha256']==pins[name],'frozen source differs: '+name)
    ct=sources['CT_interface.f'];tir=sources['TIRUST_interface.f']
    routes=locations(ct,OLD_ROUTE);caches=locations(tir,OLD_CACHE)
    need(len(routes)==len(route_names) and {r['routine'] for r in routes}==route_names,'route eligibility anchors changed')
    need(len(caches)==len(cache_names) and {r['routine'] for r in caches}==cache_names,'private cache anchors changed')
    need(tir.count(PUBLIC_CACHE)==(4 if lane=='observed-base' else 2),'existing public topology policy changed')
    files={'CT_interface.f':ct.replace(OLD_ROUTE,NEW_ROUTE),
           'TIRUST_interface.f':tir.replace(OLD_CACHE,PUBLIC_CACHE)}
    need(files['CT_interface.f'].replace(NEW_ROUTE,OLD_ROUTE)==ct,'unintended CT source delta')
    # There are four identical original public blocks: undo by original line
    # coordinates to distinguish them from the six deliberate private changes.
    old_lines=tir.splitlines(True);new_lines=files['TIRUST_interface.f'].splitlines(True)
    rebuilt=[];offset=0
    for line in old_lines:
        width=2 if line==OLD_CACHE else 1
        replacement=new_lines[offset:offset+width]
        need(replacement==PUBLIC_CACHE.splitlines(True) if width==2 else replacement==[line],
             'unintended native-interface source delta')
        rebuilt.append(line);offset+=width
    need(offset==len(new_lines) and ''.join(rebuilt)==tir,'native-interface reconstruction differs')
    need('TIR_DONE' not in ct and 'TIR_CACHE_INDEX' not in ct,'unexpected Fortran group-cache path')
    for name,source in files.items():need(all(len(s)<=132 for s in source.splitlines()),'fixed width exceeded: '+name)
    changes=[dict(file='CT_interface.f',kind='supported policy domain replaces zero-only restriction',
                  old=OLD_ROUTE.rstrip(),new=NEW_ROUTE.rstrip(),**row) for row in routes]
    changes += [dict(file='TIRUST_interface.f',kind='existing public topology policy for private numerical cache',
                     old=OLD_CACHE.rstrip(),new=PUBLIC_CACHE.rstrip(),**row) for row in caches]
    patch=''.join(''.join(difflib.unified_diff(sources[n].splitlines(True),files[n].splitlines(True),
                    fromfile='frozen-source2/'+n,tofile='private-cache-candidate/'+n)) for n in PINS)
    report={'schema':'private-CMS-Fortran-cache-policy-source-diff-v1',
       'lane':lane,
       'inputs':{n:identity(s.encode()) for n,s in sources.items()},
       'outputs':{n:identity(s.encode()) for n,s in files.items()},'changes':changes,
       'effective_native_policy':'CACHE_REQUEST=(GlobalCache==-1 OR NLOOPLINE<=GlobalCache); CHECK_PASS=(CTMODE==2 OR CTMODE==5); existing eb3 numerical cache is effective only when CACHE_REQUEST AND NOT CHECK_PASS.',
       'preserved':'All other bytes, route/library/source/current/ref/mask/genuine/point matcher/q/raw/equality/certificate/native calls and statuses; unsupported GlobalCache<-1 remains outside owned routes.',
       'failure_clear_change':'none: eb3 DP final failure/nonfinite clears relevant store/workspaces; existing MTIRUST QP decoding failure clears all numerical stores. Same-kind finite checks do not add a reachable new reject after these contracts. Outer contraction failure is not proof cached integral coefficients were invalid.',
       'stale_state_concerns':['A hit is not ownership/accuracy evidence; distinguish private corrected and public fallback entries and preserve all point/check journals.',
          'Older OWNED aliases have their original weaker snapshot-only interfaces and are not active from the current PM THRES chain; uniformly changing their cache policy does not activate or qualify those aliases.',
          'A changed actual native invariant has a changed full QP key; unchanged DP subintegrals may legitimately share.',
          'Budget/policy changes or event clears may reset counters without changing context generation; record the actual budget, generation and explicit clear observations.',
          'Fresh CT source hash must replace the old5dbe typed-parser binding only after this exact15-site delta is authenticated; DP sentinel and QP actual-flag call arguments are unchanged.'],
       'Fortran_group_cache_applicable':False,'finite_rejection_clear_helper_added':False,
       'Rust_source_ABI_DSO_changed':False,'defaults_changed':False,'telemetry_added':False,
       'compiler_calls':0,'loader_calls':0,'native_calls':0,'build_admitted':False,'run_admitted':False,
       'runtime_abi_qualified':False,'full_caller_qualified':False,'scientific_dispatch_enabled':False}
    return files,report,patch


def generate():
    lanes={};patches=[]
    for lane,root in [('observed-base',SOURCE),('plain',PLAIN_SOURCE)]:
        sources={n:(root/n).read_text() for n in PINS};files,report,patch=render(sources,lane)
        directory=HERE/'emittedsrc'/lane;directory.mkdir(parents=True,exist_ok=True)
        for name,source in files.items():
            with (directory/name).open('x') as stream:stream.write(source)
        lanes[lane]=report;patches.append('LANE '+lane+'\n'+patch)
    report={'schema':'private-CMS-paired-cache-route-source-emission-v1','lanes':lanes,
            'compiler_calls':0,'loader_calls':0,'native_calls':0,'scientific_dispatch_enabled':False}
    for name,data in [('cache-fortran-diff.json',json.dumps(report,indent=2,sort_keys=True)+'\n'),
                      ('cache-fortran.patch','\n'.join(patches))]:
        with (HERE/name).open('x') as stream:stream.write(data)
    return report


if __name__=='__main__':
    need(sys.argv[1:]==['--emit'],'only explicit --emit source operation is supported')
    r=generate();print(json.dumps({'status':'source-emitted',
        'changes':{lane:len(row['changes']) for lane,row in r['lanes'].items()},
        'compiler_calls':0,'native_calls':0,'outputs':{lane:row['outputs'] for lane,row in r['lanes'].items()}},sort_keys=True))
