"""Dormant cache-source BUILD only, reusing the closed CMS supervisor."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

START = time.monotonic()
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PARENT = ROOT / '.tirust-build/generic-owned-CMS-plain-run-proposal-4'
PARENT_INDEX = '7cc733efccfcfca4aa9a84a36ef3c64ea3cc4471f71e7a48bafaa16ebef3f925'
OBS_PARENT = ROOT / '.tirust-build/generic-owned-CMS-observer-qualification-proposal-2'
OBS_INDEX = '1a1cebf262c5fe7767a1bf6db54591a3baae9d72326370524dc918a41fd69e5d'


def require(ok, message):
    if not ok: raise ValueError(message)
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def load(name, path, sha):
    require(digest(path) == sha, 'changed frozen source '+str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
def parent_index(folder, sha):
    require(digest(folder/'source-index.json') == sha, 'changed parent index')
    index = read(folder/'source-index.json')
    require({str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()} == set(index['files'])|{'source-index.json'}, 'changed parent inventory')
    for name, pin in index['files'].items():
        p = folder/name
        require(not p.is_symlink() and p.stat().st_size == pin['bytes'] and digest(p) == pin['sha256'], 'changed parent '+name)
    return index


def configure():
    index = parent_index(PARENT, PARENT_INDEX)
    observed = parent_index(OBS_PARENT, OBS_INDEX)
    parent_index(ROOT/'.tirust-build/generic-owned-CMS-observer-qualification-proposal-1', '2333cb5216b178da1d77083de30ee4c72226d2b82ec6753d0ddc1fd6459b9e29')
    parent_index(ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2', 'fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb')
    parent = load('cache_closed_CMS_supervisor', PARENT/'controller.py', index['files']['controller.py']['sha256'])
    b = parent.configure()
    b.HERE = HERE; b.ROOT = ROOT
    b.WORK = ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-work-1'
    b.CAPS = {'build':1800.}; b.CLEANUP = 60.; b.CPU = 12
    b.BOOTSTRAP_STARTED = START; b.__file__ = str(Path(__file__).resolve())
    oldlocal = b.local
    def local(name):
        if name in ('cache_build','observer_analysis'):
            b.authenticate_source_index()
            pin = read(HERE/'source-index.json')['files'][name+'.py']
            return load('cache_CMS_'+name, HERE/(name+'.py'), pin['sha256'])
        return oldlocal(name)
    b.local = local
    b.cache_parent_folder = OBS_PARENT
    def parent_module(name):
        pin = observed['files'][name+'.py']
        return load('cache_closed_observer_'+name, OBS_PARENT/(name+'.py'), pin['sha256'])
    b.cache_parent_module = parent_module
    def work_namespace():
        require(b.PHASE == 'build' and b.WORK == ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-work-1', 'BUILD-only private namespace')
        require(not b.WORK.is_symlink() and b.WORK.resolve().is_relative_to(ROOT) and not (b.WORK/b.PHASE).is_symlink(), 'unsafe cache namespace')
    b.work_namespace = work_namespace
    def preflight(stage_created=False):
        b.verify_source(); work_namespace()
        local('cache_build').references(b)
        local('cache_build').emission_contract(b)
        require(12 in __import__('os').sched_getaffinity(0), 'CPU12 unavailable')
        if not stage_created: require(not (b.WORK/b.PHASE).exists(), 'retained cache BUILD exists; no retry')
        return {'status':'source-only-preflight-passed','phase':'build','compiler_queries':0,'loader_queries':0,
            'native_main_calls':0,'CPU':12,'CPU_reserved':False,'total_seconds':1800,'cleanup_seconds':60,
            'resource_limits':b.LIMITS,'Fortran_group_cache_applicable':False,'RUN_admitted':False}
    b.preflight = preflight
    b.build_locked = lambda directory: local('cache_build').build(b,directory)
    b.run_locked = lambda *unused: (_ for _ in ()).throw(ValueError('RUN requires a separate reviewed source/admission'))
    return b


if __name__ == '__main__': configure().main()
