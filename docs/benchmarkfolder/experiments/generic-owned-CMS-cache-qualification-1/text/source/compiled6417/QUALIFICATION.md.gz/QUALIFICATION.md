# Private CMS Rust-cache qualification

This is a dormant source successor. No BUILD or RUN is admitted by these files. Production, installed libraries, Rust sources, reference repositories and automatic backend defaults remain unchanged.

The starting numerical evidence is corrected observer source `1a1cebf…`, compiled source `2333cb…`, BUILD `c04a3784…`, RUN2 terminal `f6a77100…`, result `10db46c9…` and independent review `51d5c291…`. It establishes plain/observer history parity and local owned-input/veto provenance for ordinary controls 1/7/12 and CMS20/21. It establishes neither independent amplitude truth nor general caller/numerator validity.

The cache implementation is the existing `eb3d67fd…` shared library. Recovered audit `a94d65a6…` joins recorded bridge `455529b9…`, lock/manifest, patch, package and build history to that artifact. This is recorded build provenance, not a clean-cache compiler attestation. The artifact is not rebuilt or replaced here.

## Minimal scientific source change

`emittedsrc/plain` changes only six outer zero-cache route restrictions to the supported `GlobalCache >= -1` domain and four private `CACHE_ENABLED=false` assignments to the existing public topology policy. `emittedsrc/observed-base` applies the same changes to all nine corresponding routes and six diagnostics present in the observed source. All remaining bytes in those route-only files are preserved; `cache-fortran-diff.json` lists every change.

The actual source2 ownership/current/reference/mask/genuine-QP, route, materialized-q, original-raw agreement, mass precedence, equality and final-certificate predicates still execute before a tensor lookup. Enabling the Rust cache does not bypass them. A refused correction retains the legacy-built full native input. A cache hit is mathematical integral reuse, not evidence that a correction or ownership predicate passed.

That claim is scoped to the active PM/OBS_PM THRES entry chain. Older private OWNED aliases remain in the inherited source with their original snapshot-only interfaces; the uniform policy edit does not activate or qualify those weaker aliases for arbitrary callers. The source diff preserves their original predicates and the runtime gate authenticates the actual active dispatch and constructor/current-word joins.

Requested cache use is `GlobalCache==-1 OR NLOOPLINE<=GlobalCache`. Independent modes 2/5 retain `CHECK_PASS=true`; exact eb3 code excludes primary stores for those calls. DP direction workspaces remain separate. Failures after entry to `dp_checked` clear the full DP numerical store/workspaces; earlier API validation can return without touching prior successful entries. Successful-only QP insertion and existing QP decoding-failure clears are preserved. A QP refusal need not clear unrelated previously valid entries. No new all-store clear policy is added.

The exact NSQSO1 export contains no Fortran group-cache lookup. Its `CLEAR_TIR_CACHE` is a dummy and `TIR_CACHE_SIZE` remains zero. That cache layer is **not applicable** to this qualification.

## Bounded observations

`emittedsrc/observed` adds integer-only before/after snapshots around all ten actual generic tensor-call sites, their repeated budget setters, and the generated event clear wrapper. Widths bind every actual SHIFTS/INVARIANTS/MASSES/SCALE/RAW declaration and call expression, not a guessed procedure suffix. The existing group3 geometry journal stays intact. Cache records cover actual calls in all groups, including public fallback paths; they are joined to source tags, current group/consumer/boundary, requested/effective topology policy, check mode, full/pole policy, native status and context generation.

The existing nine aggregate counters and six QP counters suffice; no Rust/C ABI changes are introduced. Statistics getters are called only after the noncreating `TIRUST_CONTEXT_GENERATION()` reports an associated context. Clear observations on unused/non9 paths must remain context-free. These getter calls clear MTIRUST local error text: before a failed event is probed, the observer copies a 1024-byte prefix and records a possible-truncation flag. The plain ELF retains its original error-API state. Private Fortran observer interfaces are new and require compilation and numerical parity qualification.

At most 16384 events fit one journal; the inherited 64 MiB serialization cap and terminal failure gate remain active. Capacity, unpaired events, getter failures, missing native calls, source-policy mismatches and malformed journals fail closed. A failed evidence drain prevents later reset and prevents driver continuation. No observer state or counter is returned to scientific decisions.

`cache_analysis.py` validates exact integer records. It checks fixed-budget setters, all15 counters zero after a successful clear, independent-check bypasses, QP hit/miss/insertion/refusal transitions, aggregate/QP joins and native accounted-byte bounds. A failing DP event must either preserve its complete prior counter state or clear every DP component counter; the recorded transition does not infer the original failure phase when both are compatible. With the recorded poles-only build, each DP/pole store receives one quarter of the total and QP receives one half; this full-only campaign leaves the pole store unused. These bounds describe native accounting, not process RSS. Dynamic budget changes within a worker and poles-only cache behavior remain unqualified.

## Separate BUILD gate

The dormant BUILD controller reuses the previously reviewed CMS supervisor, immutable-alias policy, exact original recipes/flags and 15-provider runtime closure. Proposed caps are 1800 seconds total including 60 seconds cleanup, 16 GiB address space, 256 MiB file size, core0, nonexclusive CPU12 and the shared numerical mutex. Root must admit an exact sealed source identity before execution.

Build two new candidate ELFs: a plain cache-route ELF and an observed ELF with the same scientific delta plus telemetry. Clone only authenticated closed plain/observed candidate sources and objects. Preserve the exact large immutable dependency aliases rather than copying their archives. Regenerate private modules; recompile every changed source and all users of the changed observer module. Keep original flags and `eb3`, prebind the original 15 providers before linking, inspect actual link maps/static closure/symbol ownership, and retain every command/error. The old two plain and two observed ELFs and histories remain unchanged.

This controller is BUILD-only. It rejects RUN until a separate source/protocol and exact BUILD review is recorded. No model initializer, reducer or scientific main executes during BUILD.

## Proposed normal-reference RUN gate

After an independently closed BUILD, prepare a separately admitted RUN using fresh workers, exact own plain/observed histories and the existing normal driver. Keep 12-point normal learning/readiness, no restored filters, strict `MLStabThres=1e-6`, full finite terms, `LoopPoleMode=-1`, genuine QP policy and unchanged model/resources/rescue settings.

First use two fixed cards: `cache0` (GlobalCache=0, 268435456 bytes) and `cacheall` (-1, the same budget). Each plain/observed pair runs controls `[1,7,12]` and separate critical `[20]` and `[21]` histories: twelve fresh workers total. Authenticate actual ELF/provider maps and READY/DONE, preserve full raw/state/scale/point/numerical histories and compare own plain/observed streams. Cache0 must reproduce its closed reference. Cache-enabled values must be compared to cache0 with raw residuals and MadLoop's existing regression criterion; do not silently treat an altered rescue history as bit parity or independent accuracy.

All source-bound current/reference/mask/constructor/genuine-QP/q/raw/certificate/veto checks remain mandatory for observed group3 records. Check modes must not reuse primary tensors. Report all actual hit categories across all groups, not only group3. A genuine schedule with no group3 hit is a valid observation. Aggregate counters mix DP/pole and QP categories; separate them using the six QP counters before interpreting counts. Do not label workspace reuse as numerical cache hits.

Suggested separate RUN cap is 1800 seconds including 60 cleanup, per-reply 180, with the same memory/file/core/CPU/mutex/runtime policy. These are proposed bounds, not admission. Stop on unexpected candidate/infrastructure/parity/provenance failure, retain the first failure without retry, and retain old expected legacy failures as historical controls rather than rerunning them to manufacture truth.

## Later lifecycle/budget gate

After normal parity passes, prepare a fresh RUN source/admission with `cachelimit3` (GlobalCache=3) and `cachezero` (GlobalCache=-1, zero budget), fixed throughout normal learning and measurement. These cards differ from strict cache0 only in the declared cache fields; hashes and exact deltas are in `cache-policies.json`. The topology limit excludes the four-point group3 request while permitting smaller groups; the zero budget must refuse numerical insertions without changing results.

Add a plainly declared driver request history `[20,20,21,20]` in each arm under the ordinary full learning policy, preserving physical fixtures unchanged. Repeated points are driver controls, never point-ID branches in science. Observe each event clear, empty post-clear stores, generation continuity and reconstruction of masks/current references. Changed native matrix words must never retrieve a stale whole-tensor result; the two critical tuples retain identical shifts/masses/scale but different invariants. This tests actual event scheduling, not arbitrary unobserved one-word input mutations.

Rotation/MP boundaries present in the actual source/journal are observed, but unexecuted rotations, budget switching within one context, forced failures/recovery, context destruction/recreation, poles-only/full separation and new subprocess coexistence require their own reachable source/control gates. No such unexecuted case is declared qualified by this packet. The first native tests must retain both primary/check separation and the original independent MadLoop stability machinery.

No timing acceptance, default promotion, general topology claim, independent finite/pole truth or public source activation follows from a cache parity pass.
