"""Mutable, dormant RUN-only controller using the accepted real6417 BUILD."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

START=time.monotonic();HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-proposal-1'
COMPILED_SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
NAMES={'cache_run','cache_worker','cache_comparison','cache_metrics','protocol_parity','run_plan',
       'build_binding','closed_references','normal_run_analysis','observer_analysis','accuracy_policy'}


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def load(name,path,sha):
    require(digest(path)==sha,'changed pinned source '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def configure():
    require(digest(PARENT/'source-index.json')==COMPILED_SOURCE,'compiled-source package changed')
    index=read(PARENT/'source-index.json')
    parent=load('CMS_cache_compiled_controller',PARENT/'controller.py',index['files']['controller.py']['sha256'])
    parent.parent_index(PARENT,COMPILED_SOURCE)
    b=parent.configure()
    # Preserve the old compiled loader closure. Its code bytes stay source6417;
    # the RUN supervisor below always authenticates its own source identity.
    compiled=load('CMS_cache_compiled_build',PARENT/'cache_build.py',index['files']['cache_build.py']['sha256'])
    b.HERE=HERE;b.ROOT=ROOT;b.WORK=ROOT/'.tirust-build/generic-owned-CMS-cache-run-work-4'
    b.CAPS={'run':1800.};b.CLEANUP=60.;b.CPU=12;b.BOOTSTRAP_STARTED=START
    b.__file__=str(Path(__file__).resolve());oldlocal=b.local
    def local(name):
        if name in NAMES:
            b.authenticate_source_index();pin=read(HERE/'source-index.json')['files'][name+'.py']
            return load('CMS_cache_RUN_'+name,HERE/(name+'.py'),pin['sha256'])
        return oldlocal(name)
    b.local=local
    def work_namespace():
        require(b.PHASE=='run' and b.WORK==ROOT/'.tirust-build/generic-owned-CMS-cache-run-work-4','RUN-only fresh namespace')
        require(not b.WORK.is_symlink() and b.WORK.resolve().is_relative_to(ROOT)
                and not (b.WORK/b.PHASE).is_symlink(),'unsafe RUN work namespace')
    b.work_namespace=work_namespace
    def verify_live():return local('build_binding').verify_live(b,compiled)
    b.verify_build=verify_live
    def preflight(stage_created=False):
        b.verify_source();work_namespace()
        # This checks actual root gate/review/raw inventory before constructing
        # the compiled-source verification proxy; no guessed future file reads.
        binding=verify_live()
        local('run_plan').validate_requests(local('run_plan').requests())
        policies=read(HERE/'runtime-policies.json')['policies']
        worker=local('cache_worker')
        for request in local('run_plan').requests():
            policy=policies[request['policy']];worker.validate_policy(policy,request)
            worker.validate_runtime_card((HERE/'cards/original-MadLoopParams.dat').read_bytes(),
                                         (HERE/policy['runtime_card']).read_bytes(),policy)
        local('closed_references').load(b)
        require(12 in __import__('os').sched_getaffinity(0),'CPU12 unavailable')
        if not stage_created:require(not (b.WORK/b.PHASE).exists(),'retained RUN exists; no retry')
        return {'status':'source-only-preflight-passed','phase':'run','native_processes_to_execute':12,
            'compiled_source_index_sha256':COMPILED_SOURCE,'reviewed_BUILD_terminal_sha256':binding['terminal_sha256'],
            'root_BUILD_gate_sha256':binding['root_BUILD_gate_sha256'],'RUN_source_index_sha256':b.EXPECTED_SOURCE,
            'compiler_queries':0,'loader_queries':0,'native_main_calls':0,'CPU':12,'CPU_reserved':False,
            'total_seconds':1800,'cleanup_seconds':60,'per_reply_seconds':180,'resource_limits':b.LIMITS,
            'Fortran_group_cache_applicable':False,'RUN_admission_granted_by_BUILD_gate':False}
    b.preflight=preflight
    b.build_locked=lambda *unused:(_ for _ in ()).throw(ValueError('RUN-only source: no compiler/BUILD'))
    b.run_locked=lambda directory:local('cache_run').run(b,directory,verify_live=verify_live,
                                                     closed_plain_references=local('closed_references').load(b))
    return b


if __name__=='__main__':configure().main()
