"""Pure comparisons of already-parsed CMS evidence; no I/O or worker loading.

PID/header/driver/ELF/map/protocol identity belongs to the controller. Observer
error-API text and cache counters are not normal scientific RAW records.
Frozen normal-parser word decoding/ratio functions are supplied as callbacks.
"""
from copy import deepcopy
from fractions import Fraction
import re

COMPLETE={(1,7,12),(20,),(21,)}
PREFIXES=COMPLETE|{(),(1,),(1,7)}


def need(condition,message):
    if not condition:raise ValueError(message)


def differences(left,right,path='',out=None):
    """Keep every typed/key/list/value difference; never zip away a suffix."""
    if out is None:out=[]
    if type(left) is not type(right):
        out.append({'path':path,'kind':'type','reference':deepcopy(left),'candidate':deepcopy(right)})
    elif isinstance(left,dict):
        for key in sorted(set(left)|set(right),key=str):
            where=path+'.'+str(key) if path else str(key)
            if key not in left or key not in right:
                out.append({'path':where,'kind':'missing-key','reference_present':key in left,
                            'candidate_present':key in right,'reference':deepcopy(left.get(key)),
                            'candidate':deepcopy(right.get(key))})
            else:differences(left[key],right[key],where,out)
    elif isinstance(left,(list,tuple)):
        for index in range(max(len(left),len(right))):
            where=path+'['+str(index)+']'
            if index>=len(left) or index>=len(right):
                out.append({'path':where,'kind':'missing-index','reference_present':index<len(left),
                    'candidate_present':index<len(right),'reference':deepcopy(left[index]) if index<len(left) else None,
                    'candidate':deepcopy(right[index]) if index<len(right) else None})
            else:differences(left[index],right[index],where,out)
    elif left!=right:out.append({'path':path,'kind':'value','reference':deepcopy(left),'candidate':deepcopy(right)})
    return out


def _word(value):return type(value) is str and re.fullmatch(r'[0-9A-F]{16}',value) is not None


def _normal(analysis):
    need(type(analysis) is dict and analysis.get('schema')=='normal-cms-raw64-analysis-v1',
         'already-parsed frozen normal RAW analysis required')
    need(analysis.get('lane')=='candidate','cache comparisons require actual candidate analyses')
    ids=analysis.get('request_ids');learning=analysis.get('learning');runs=analysis.get('measurements')
    need(type(ids) is list and all(type(i) is int for i in ids) and tuple(ids) in PREFIXES,'known request prefix required')
    need(type(learning) is dict and type(learning.get('records')) is list and
         type(runs) is list and len(runs)==len(ids),'complete parsed record lists required')
    need(all(type(r) is dict for r in learning['records']+runs),'parsed record dictionaries required')
    need([r.get('point_id') for r in runs]==ids,'measurement coordinate order differs')
    need(1<=len(learning['records'])<=1013,'bounded parsed learning history required')
    for record in learning['records']+runs:
        need(type(record) is dict and all(key in record for key in
             ('phase','call_index','point_id','code','class','status','rawANS','rawACC','rawP','rawMUR','state_before','state_after')),
             'missing parsed scientific record field')
        need(type(record['status']) is dict,'parsed actual status required')
        for field in ('state_before','state_after'):
            value=record[field]
            need((field=='state_before' and value is None) or
                 (type(value) is list and len(value)==15 and all(type(i) is int for i in value)),
                 'all15 parsed software/IEEE state fields required')
        need(type(record['rawANS']) is list and len(record['rawANS'])==2 and
             all(type(row) is list and len(row)==4 and all(_word(w) for w in row) for row in record['rawANS']),
             'exact2x4 raw coefficient words required')
        need(type(record['rawACC']) is list and len(record['rawACC'])==2 and all(_word(w) for w in record['rawACC']),
             'both raw accuracy words required')
        need(type(record['rawP']) is list and len(record['rawP'])==4 and
             all(type(row) is list and len(row)==4 and all(_word(w) for w in row) for row in record['rawP']) and
             _word(record['rawMUR']),'actual input/scale words required')
    return analysis


def _core(analysis):
    a=_normal(analysis)
    return {'request_ids':a['request_ids'],'learning':a['learning'],'measurements':a['measurements']}


def _ready(analysis):
    return (tuple(analysis['request_ids']) in COMPLETE and analysis.get('accepted_for_continuation') is True and
            analysis['learning'].get('success') is True and analysis['learning'].get('ready') is True)


def compare_exact_histories(reference,candidate,*,label='fresh cache0 versus own closed plain candidate'):
    left=_core(reference);right=_core(candidate);delta=differences(left,right)
    valid=_ready(reference) and _ready(candidate)
    return {'schema':'cms-cache-exact-history-v1','label':label,'passed':not delta and valid,
        'histories_exact':not delta,'both_complete_valid_histories':valid,'difference_count':len(delta),
        'differences':delta,'all15_state_fields_compared':True,
        'identity_handled_separately':['PID','RAW header/digest','driver source','ELF/maps/providers','protocol READY/DONE'],
        'observer_error_API_text_compared':False,'independent_finite_truth':False,'scientifically_qualified':False}


def compare_exact_prefix(reference,candidate,*,complete_request_ids,prefix_request_ids,
                         label='exact accepted request prefix'):
    """Compare a flushed prefix without treating it as a complete history.

    The controller declares both the worker's complete request sequence and
    its current prefix. Parsed learning must already be complete and ready,
    including at the empty measurement prefix. No RAW parsing or identity
    verification is performed here. Complete prefixes also pass through the
    unchanged complete-history gate.
    """
    need(type(complete_request_ids) in (list,tuple) and
         all(type(i) is int for i in complete_request_ids) and
         tuple(complete_request_ids) in COMPLETE,'known complete request sequence required')
    need(type(prefix_request_ids) in (list,tuple) and
         all(type(i) is int for i in prefix_request_ids),'explicit request prefix required')
    complete=tuple(complete_request_ids);prefix=tuple(prefix_request_ids)
    need(prefix in {complete[:i] for i in range(len(complete)+1)},
         'declared prefix must be an initial segment of the complete request sequence')
    left=_core(reference);right=_core(candidate)
    need(left['request_ids']==list(prefix) and right['request_ids']==list(prefix),
         'both actual request IDs must equal the declared prefix')
    def readiness(analysis):
        learning=analysis['learning'];problems=[]
        for container,key in ((analysis,'accepted_for_continuation'),(learning,'success'),
                              (learning,'ready'),(learning,'status_learning_complete'),
                              (learning,'all_training_ids_seen')):
            if container.get(key) is not True:problems.append(key+' is not true')
        if type(learning.get('streak')) is not int or learning['streak']!=12:
            problems.append('learning streak is not integer 12')
        return problems
    readiness_issues={'reference':readiness(reference),'candidate':readiness(candidate)}
    ready=not any(readiness_issues.values());delta=differences(left,right)
    is_complete=prefix==complete
    full=compare_exact_histories(reference,candidate,label=label) if is_complete else None
    return {'schema':'cms-cache-exact-prefix-v1','label':label,
        'complete_request_ids':list(complete),'prefix_request_ids':list(prefix),'prefix_complete':is_complete,
        'passed':not delta and ready and (full is None or full['passed']),
        'histories_exact':not delta,'both_ready_complete_learning':ready,'readiness_issues':readiness_issues,
        'difference_count':len(delta),'differences':delta,'complete_history_comparison':full,
        'all15_state_fields_compared':True,
        'identity_handled_separately':['PID','RAW header/digest','driver source','ELF/maps/providers','protocol READY/DONE'],
        'observer_error_API_text_compared':False,'independent_finite_truth':False,'scientifically_qualified':False}


def compare_own_parity(plain_normal,observed_normal):
    return compare_exact_histories(plain_normal,observed_normal,label='own fixed-policy new plain versus observed')


def compare_native_journals(journals0,journals_all):
    """Recorded geometry frames only; cache telemetry/counters are separate."""
    if journals0 is None and journals_all is None:
        return {'provided':False,'matched':[],'unmatched':[],'scientific_differences':[],'policy_differences':[]}
    need(type(journals0) is list and type(journals_all) is list,'both already-parsed journal lists required')
    def indexed(journals):
        result={};counts={}
        for journal in journals:
            need(type(journal) is dict and type(journal.get('point_id')) is int and
                 type(journal.get('frames')) is list,'parsed point/frame journals required')
            for frame in journal['frames']:
                need(type(frame) is dict and all(k in frame for k in ('group','width','ctmode','rank','legacy')),
                     'actual native frame coordinates required')
                key=(journal['point_id'],frame['group'],frame['width'],frame['ctmode'],frame['rank'],frame['legacy'])
                count=counts.get(key,0);counts[key]=count+1
                result[key+(count,)]=frame
        return result
    left=indexed(journals0);right=indexed(journals_all);matched=[];unmatched=[];science=[];policy=[]
    for key in sorted(set(left)|set(right)):
        if key not in left or key not in right:
            unmatched.append({'context':list(key),'cache0':deepcopy(left.get(key)),'cacheall':deepcopy(right.get(key))})
            continue
        matched.append(list(key));a=left[key];b=right[key]
        need(all(k in a and k in b for k in ('native','shifts','masses','scale','native_status','check_pass')),
             'actual native word/status payload required')
        # Preserve every parsed geometry/status/provenance field. Cache error
        # API/counter events live outside these frame dictionaries in the
        # separately validated journal['cache'] payload and are not compared.
        acore={k:v for k,v in a.items() if k!='cache_enabled'}
        bcore={k:v for k,v in b.items() if k!='cache_enabled'}
        science.extend({'context':list(key),**row} for row in differences(acore,bcore))
        policy.extend({'context':list(key),**row} for row in differences(
            {'cache_enabled':a.get('cache_enabled')},{'cache_enabled':b.get('cache_enabled')}))
    return {'provided':True,'matched':matched,'unmatched':unmatched,'scientific_differences':science,
        'policy_differences':policy,'matching_scope':'actual point/group/width/mode/rank/entrykind plus occurrence; no input equality inferred',
        'scope':'only recorded geometry frames; all-group cache counters/error diagnostics are separately validated and retained by caller',
        'native_inputs_or_status_identical_on_matched_contexts':not science,'independent_finite_truth':False}


def _exact(value):return [value.numerator,value.denominator] if value is not None else None


def compare_policy_numerics(cache0,cacheall,*,word_value,ratio,journals0=None,journals_all=None):
    """Frozen3e-6 component criterion; never relabel points or claim bit parity.

    word_value and ratio are the controller-bound frozen normal parser's _value
    and _ratio callbacks. Inputs and callbacks are never loaded from a path.
    """
    left=_core(cache0);right=_core(cacheall)
    need(callable(word_value) and callable(ratio),'explicit frozen word/ratio callbacks required')
    history=differences(left,right);residuals=[];failures=[];unmatched=[]
    valid=_ready(cache0) and _ready(cacheall);tol=Fraction(3e-6);goal=Fraction(1e-8);target=True
    rows0=cache0['measurements'];rows1=cacheall['measurements']
    for index in range(max(len(rows0),len(rows1))):
        if index>=len(rows0) or index>=len(rows1):
            unmatched.append({'index':index,'cache0':deepcopy(rows0[index]) if index<len(rows0) else None,
                              'cacheall':deepcopy(rows1[index]) if index<len(rows1) else None});continue
        a=rows0[index];b=rows1[index]
        if (a['point_id'],a['call_index'],a['rawP'],a['rawMUR'])!=(b['point_id'],b['call_index'],b['rawP'],b['rawMUR']):
            failures.append({'index':index,'reason':'actual measurement coordinate/input/scale words differ',
                             'cache0':deepcopy(a),'cacheall':deepcopy(b)});continue
        for order in range(2):
            values=[]
            for row in (a,b):
                decoded=[]
                for word in row['rawANS'][order]:
                    finite=(int(word,16)>>52)&2047!=2047
                    value=word_value(word) if finite else None
                    decoded.append(Fraction(value) if value is not None else None)
                values.append(decoded)
            peak=max([abs(row[1]) for row in values if row[1] is not None]+[Fraction(1e-99)])
            for component,(x,y) in enumerate(zip(*values)):
                row={'point_id':a['point_id'],'order':order,'component':component,
                     'cache0_word':a['rawANS'][order][component],'cacheall_word':b['rawANS'][order][component],
                     'bitwise_equal':a['rawANS'][order][component]==b['rawANS'][order][component]}
                if x is None or y is None:
                    row.update(passed=False,reason='nonfinite coefficient word',symmetric_ratio_exact=None,
                               absolute_difference_exact=None);target=False
                else:
                    magnitude=max(abs(x),abs(y));denom=abs(x+y)
                    symmetric=abs(x-y)/denom if denom else Fraction(0) if not magnitude else None
                    pole=magnitude/peak if component>=2 else None
                    accepted=lambda bound:(symmetric is not None and symmetric<bound) or (pole is not None and pole<bound)
                    row.update(passed=accepted(tol),symmetric_ratio_defined=symmetric is not None,
                        symmetric_relative_error=ratio(symmetric) if symmetric is not None else None,
                        symmetric_ratio_exact=_exact(symmetric),pole_to_finite=ratio(pole) if pole is not None else None,
                        pole_to_finite_exact=_exact(pole),absolute_difference_exact=_exact(abs(x-y)),
                        relative_error=ratio(abs(x-y)/magnitude) if magnitude else 0.0)
                    target=target and accepted(goal)
                residuals.append(row)
                if not row['passed']:failures.append(deepcopy(row))
    native=compare_native_journals(journals0,journals_all)
    return {'schema':'cms-cache-policy-numerical-comparison-v1','passed':valid and not failures and not unmatched,
        'numerically_eligible_complete_histories':valid,'tolerance':3e-6,
        'criterion':'frozen LoopMEComparator abs(a-b)/abs(a+b)<tol OR pole magnitude/maxfinite<tol; exact rational binary64',
        'target_1e8_passed':target and valid and not unmatched and not failures,'residuals':residuals,'failures':failures,
        'unmatched_measurements':unmatched,'history_exact':not history,'history_differences':history,
        'actual_statuses':[{'point_id':a['point_id'],'cache0':deepcopy(a['status']),'cacheall':deepcopy(b['status'])}
                           for a,b in zip(rows0,rows1)],
        'accuracy_words':[{'point_id':a['point_id'],'cache0':deepcopy(a['rawACC']),'cacheall':deepcopy(b['rawACC'])}
                          for a,b in zip(rows0,rows1)],'native_journal_comparison':native,
        'callbacks_identity_requires_controller':True,'bit_parity_required':False,'independent_finite_truth':False,
        'accuracy_qualified':False,'scientifically_qualified':False,'performance_qualified':False}
