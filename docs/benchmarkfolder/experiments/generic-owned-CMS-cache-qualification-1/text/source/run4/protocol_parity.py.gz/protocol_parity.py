"""Pure identity-aware parity for retained READY/DONE and provider maps."""


def require(ok,message):
    if not ok:raise ValueError(message)


def learning_coordinate(learning):
    """Bind native K to the parsed raw records, including bootstrap index0.

    Actual check_sa.f traces bootstrap0 before DO K=1,MAXLEARN, then writes
    K to both raw and native LEARNED terminals. The raw parser retains that
    bootstrap in records/outer_calls; its terminal retains the normal index.
    """
    require(type(learning) is dict,'actual parsed learning required')
    for key in ('success','ready','status_learning_complete','all_training_ids_seen'):
        require(learning.get(key) is True,'learning is not complete/ready: '+key)
    require(type(learning.get('streak')) is int and learning['streak']==12,'learning terminal streak')
    records=learning.get('records')
    require(type(records) is list and 13<=len(records)<=1013 and
            all(type(row) is dict for row in records),'bounded complete learning records required')
    require(type(learning.get('outer_calls')) is int and learning['outer_calls']==len(records),
            'bootstrap-inclusive outer count differs from actual records')
    for index,row in enumerate(records):
        require(row.get('phase')=='LEARN' and type(row.get('call_index')) is int and
                row['call_index']==index,'bootstrap/normal learning index is not contiguous')
        require(type(row.get('point_id')) is int and row['point_id']==(1 if index==0 else 1+(index-1)%12),
                'learning point/index coordinate mismatch')
        require(type(row.get('code')) is int and type(row.get('streak')) is int,
                'actual integer learning code/streak required')
        if index==0:
            require('state_before' in row and row['state_before'] is None and row['streak']==0,
                    'strict bootstrap0 marker required')
        else:
            require(type(row.get('state_before')) is list and len(row['state_before'])==15,
                    'normal learning before-state marker required')
    last=records[-1]
    require(last['streak']==12,'last normal record has not earned streak12')
    require(type(learning.get('terminal')) is list and learning['terminal']==
            ['LEARNED','1',str(last['call_index']),'12',str(last['code'])],
            'raw learning terminal does not bind last normal index/code/streak')
    require(learning['outer_calls']==last['call_index']+1,'bootstrap/normal count relation differs')
    return last['call_index']


def protocol_core(transcript, *, pid, ids, measurements, learning):
    require(type(pid) is int and pid>0 and type(transcript) is list,'actual protocol/PID required')
    normal_index=learning_coordinate(learning)
    expected=[('RECV',['READY',str(pid)]),('SEND',['LEARN','1','0']),
              ('RECV',['LEARNED',str(pid),'1','1',str(normal_index),'12'])]
    for index,(point,row) in enumerate(zip(ids,measurements),1):
        seq=index+1
        require(row['point_id']==point,'protocol/analysis point order')
        expected += [('SEND',['RUN',str(seq),str(index)]),
                     ('RECV',['DONE',str(pid),str(seq),str(index),str(point),str(row['code']),str(row['class'])])]
    seq=len(ids)+2
    expected += [('SEND',['EXIT',str(seq),'0']),('RECV',['EXIT',str(pid),str(seq)])]
    require(len(ids)==len(measurements) and len(transcript)==len(expected),'protocol terminal/cardinality')
    normalized=[]
    for actual,(direction,fields) in zip(transcript,expected):
        require(actual=={'direction':direction,'fields':fields},'protocol message/coordinate mismatch')
        values=list(fields)
        if direction=='RECV':values[1]='ACTUAL_PID'
        normalized.append({'direction':direction,'fields':values})
    return normalized


def maps_core(maps, *, pid, executable_path, executable_sha256, runtime, ids):
    labels=['ready','learned',*['done-'+str(i) for i in range(1,len(ids)+1)]]
    require(type(maps) is dict and set(maps)==set(labels),'exact READY/LEARNED/DONE map set')
    result=[]
    for label in labels:
        proof=maps[label]
        require(proof['pid']==pid and proof['affinity']==[12] and proof['exclusive_CPU'] is False,'actual map PID/CPU policy')
        current=proof['identity'];started=proof['started_identity']
        for key in ('pid','parent_pid','process_group','session','start_time_ticks'):
            require(current[key]==started[key],'map process lifetime changed')
        require(current['pid']==pid and current['start_time_ticks']>0,'map native identity')
        require(current['process_group']==current['session']==current['parent_pid'],'native left owned supervisor group')
        require(current['state'] not in ('Z','X','x') and started['state'] not in ('Z','X','x'),'mapped dead process')
        expected={**runtime,executable_path:executable_sha256}
        require(len(runtime)==15 and proof['ELF']==expected,'actual executable/provider inventory')
        require(type(proof['raw']) is str and bool(proof['raw']),'raw process maps absent')
        result.append({'phase':label,'providers':dict(runtime),'data':proof['data'],
                       'affinity':proof['affinity'],'exclusive_CPU':False})
    return result


def own_runtime_parity(plain,observed, *, runtime):
    """Compare declared observable state, never live MTIRUST error API text."""
    for row in (plain,observed):
        require(row['returncode']==0 and row['orchestration_closed'] and row['no_retry'],'worker not closed')
        require(row['analysis']['accepted_for_continuation'],'numerical worker not accepted')
        require(row['request']['lane']=='candidate','foreign numerical lane')
    require(plain['request']['arm']=='plain' and observed['request']['arm']=='observed','plain/observed pair required')
    require(plain['stderr_sha256']==observed['stderr_sha256'],'own plain/observed retained stdout/stderr differs')
    for key in ('policy','cohort','ids'):
        require(plain['request'][key]==observed['request'][key],'runtime pair cohort/policy mismatch')
    ids=plain['request']['ids'];cores=[]
    for row in (plain,observed):
        normal=row['analysis'].get('normal_analysis',row['analysis'])
        cores.append({'protocol':protocol_core(row['protocol'],pid=row['pid'],ids=ids,
                        measurements=normal['measurements'],learning=normal['learning']),
                      'maps':maps_core(row['maps'],pid=row['pid'],executable_path=row['executable_path'],
                        executable_sha256=row['executable_sha256'],runtime=runtime,ids=ids)})
    require(cores[0]==cores[1],'own plain/observed protocol/provider/data/affinity parity')
    return {'passed':True,'protocol_and_maps_compared':True,'retained_stdout_stderr_equal':True,'actual_PID_self_ELF_ASLR_excluded_only_after_authentication':True,
            'live_error_API_state_compared':False,'unobserved_software_state_equivalence':False,
            'independent_physical_truth':False,'performance_qualified':False}
