"""Exact historical cache0 plaintext references, loaded explicitly after gates."""
from pathlib import Path
import hashlib
import json

FOLDER='.tirust-build/generic-owned-CMS-plain-run-work-4/run'
TERMINAL='182714a03f54cea2ea344e92bb31922a86cb603615176fb5aef8b060eda041bc'
RESULT='b0a3eb3596a8c183775d37a1a791a2aee3e3ca671958f8e2884776d79cb042eb'
SOURCE='7cc733efccfcfca4aa9a84a36ef3c64ea3cc4471f71e7a48bafaa16ebef3f925'
REVIEW='.tirust-build/generic-owned-CMS-plain-run-independent-review-4/receipt.json'
REVIEW_SHA='efb558d49c9050c33c7755915a689db699178d0f6fdf68183298a2cbe1c4b692'


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())


def load(b):
    root=Path(b.ROOT);folder=root/FOLDER
    require(digest(folder/'terminal.json')==TERMINAL and digest(folder/'result.json')==RESULT
            and digest(root/REVIEW)==REVIEW_SHA,'historical normal reference/review changed')
    terminal=read(folder/'terminal.json');recorded=read(folder/'result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and terminal['result_sha256']==RESULT
            and not terminal['cleanup']['events'] and not terminal['cleanup']['survivors'],'historical reference not closed')
    require(recorded['source_index_sha256']==SOURCE and len(recorded['requests'])==6,'wrong historical normal RUN')
    normal=b.local('normal_run_analysis');worker=b.local('cache_worker');compare=b.local('cache_comparison')
    references={}
    for cohort,ids in (('controls',[1,7,12]),('critical20',[20]),('critical21',[21])):
        request=recorded['requests']['candidate-'+cohort];raw=folder/'evidence'/('candidate-'+cohort)/'driver.raw64'
        require(request['request']['lane']=='candidate' and request['request']['ids']==ids
                and request['returncode']==0 and request['orchestration_closed'] and request['no_retry'],'historical plaintext request not closed')
        require(digest(raw)==request['raw_sha256'],'historical plaintext raw changed')
        text=raw.read_text();require('OBS_' not in text,'historical plaintext has observer records')
        points=worker.point_words(b.HERE/'inputs/training.dat',b.HERE/('inputs/'+cohort+'.dat'))
        parsed=normal.parse_raw(text,lane='candidate',request_ids=ids,expected_points=points)
        require(parsed['pid']==request['pid'] and parsed['accepted_for_continuation'],'historical plaintext parser/PID refusal')
        b.local('accuracy_policy').enforce(parsed,word_value=normal._value)
        replay=compare.compare_exact_histories(request['analysis'],parsed,label='closed original cache0 plaintext replay')
        require(replay['passed'],'historical plaintext replay changed')
        references[cohort]={'raw_path':str(raw),'raw_sha256':request['raw_sha256'],'analysis':parsed,'pid':request['pid'],
            'source_index_sha256':SOURCE,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'independent_review_sha256':REVIEW_SHA}
    return references
