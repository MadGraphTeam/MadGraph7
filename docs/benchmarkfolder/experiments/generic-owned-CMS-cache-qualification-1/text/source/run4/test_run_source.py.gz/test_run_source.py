from pathlib import Path
from types import SimpleNamespace
import copy
import hashlib
import json
import struct
import unittest

HERE=Path(__file__).resolve().parent


def load(name):
    path=HERE/(name+'.py');namespace={'__file__':str(path),'__name__':'draft_'+name}
    exec(compile(path.read_text(),str(path),'exec'),namespace)
    return namespace


def documents(m):
    variants={'plain':{'sha256':'A'*64},'observed':{'sha256':'B'*64}}
    gate={'schema':'root-reviewed-CMS-cache-build-v1','build_accepted':True,'independent_review_accepted':True,
          'compiled_source_index_sha256':m['COMPILED_SOURCE'],'build_terminal_sha256':m['BUILD_TERMINAL'],
          'build_result_sha256':m['BUILD_RESULT'],'independent_review_sha256':m['REVIEW_SHA'],
          'raw_command_inventory_sha256':m['INVENTORY_SHA'],'RUN_admitted':False,
          'runtime_cache_qualified':False,'amplitude_parity_qualified':False,'independent_physical_truth':False,
          'production_promoted':False}
    terminal={'phase':'build','status':'passed','returncode':0,'result_sha256':m['BUILD_RESULT'],
              'cleanup':{'events':[],'survivors':[]},'cap_seconds':1800,'cleanup_reserve_seconds':60}
    result={'status':'passed','source_index_sha256':m['COMPILED_SOURCE'],'variants':variants,
            'native_main_calls':0,'model_calls':0,'reducer_calls':0}
    review={'status':'passed-closed-BUILD-only','source_index_sha256':m['COMPILED_SOURCE'],
            'build_terminal_sha256':m['BUILD_TERMINAL'],'build_result_sha256':m['BUILD_RESULT'],
            'new_native_queries_or_execution_by_reviewer':0,'blockers':[],
            'artifacts':{'raw-command-inventory.json':{'sha256':m['INVENTORY_SHA']}},
            'variants':{key:{'ELF_sha256':value['sha256'],'providers':15} for key,value in variants.items()}}
    return gate,terminal,result,review


def learning(last=15,code=323):
    records=[{'phase':'LEARN','call_index':0,'point_id':1,'code':239,'streak':0,'state_before':None}]
    for index in range(1,last+1):
        records.append({'phase':'LEARN','call_index':index,'point_id':1+(index-1)%12,'code':code,
                        'streak':max(0,index-(last-12)),'state_before':[0,1]+[0]*13})
    return {'success':True,'ready':True,'status_learning_complete':True,'all_training_ids_seen':True,
            'streak':12,'outer_calls':len(records),'records':records,
            'terminal':['LEARNED','1',str(last),'12',str(code)]}


def protocol(pid=123,code=323,last=15):
    return [{'direction':direction,'fields':fields} for direction,fields in [
        ('RECV',['READY',str(pid)]),('SEND',['LEARN','1','0']),
        ('RECV',['LEARNED',str(pid),'1','1',str(last),'12']),('SEND',['RUN','2','1']),
        ('RECV',['DONE',str(pid),'2','1','20',str(code),'2']),
        ('SEND',['EXIT','3','0']),('RECV',['EXIT',str(pid),'3'])]]


def map_proof(pid,runtime,executable):
    identity={'pid':pid,'parent_pid':100,'process_group':100,'session':100,'start_time_ticks':pid+1,'state':'S'}
    return {'pid':pid,'ELF':{**runtime,executable:'C'*64},'data':{},'affinity':[12],'exclusive_CPU':False,
            'identity':dict(identity),'started_identity':dict(identity),'raw':'synthetic process maps\n'}


class RunSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.binding=load('build_binding');cls.parity=load('protocol_parity');cls.worker=load('cache_worker')
    def validate(self,docs=None,**overrides):
        m=self.binding;values=documents(m) if docs is None else docs
        kwargs={'gate_sha':m['GATE_SHA'],'terminal_sha':m['BUILD_TERMINAL'],'result_sha':m['BUILD_RESULT'],
                'review_sha':m['REVIEW_SHA'],'inventory_sha':m['INVENTORY_SHA']}
        kwargs.update(overrides);return m['validate_review_documents'](*values,**kwargs)
    def test_exact_twelve_matrix(self):
        plan=load('run_plan');rows=plan['requests']();self.assertEqual(len(rows),12)
        self.assertTrue(plan['validate_requests'](rows))
        with self.assertRaises(ValueError):plan['validate_requests'](rows[:-1])
    def test_protocol_preserves_CMS_EXIT(self):
        value=self.parity['protocol_core'](protocol(),pid=123,ids=[20],measurements=[{'point_id':20,'code':323,'class':2}],learning=learning())
        self.assertEqual(value[-1]['fields'],['EXIT','ACTUAL_PID','3'])
        self.assertEqual(value[2]['fields'],['LEARNED','ACTUAL_PID','1','1','15','12'])
    def test_STOP_BYE_rejected(self):
        transcript=protocol();transcript[-2]['fields'][0]='STOP';transcript[-1]['fields'][0]='BYE'
        with self.assertRaises(ValueError):self.parity['protocol_core'](transcript,pid=123,ids=[20],measurements=[{'point_id':20,'code':323,'class':2}],learning=learning())
    def test_spoofed_protocol_PID_rejected(self):
        with self.assertRaises(ValueError):self.parity['protocol_core'](protocol(124),pid=123,ids=[20],measurements=[{'point_id':20,'code':323,'class':2}],learning=learning())
    def test_extra_protocol_tail_rejected(self):
        with self.assertRaises(ValueError):self.parity['protocol_core'](protocol()+[{'direction':'RECV','fields':['EXTRA']}],pid=123,ids=[20],measurements=[{'point_id':20,'code':323,'class':2}],learning=learning())
    def test_learning_native_count_is_source_bound_normal_index_not_outer_count(self):
        for last in (12,15,24,1012):
            data=learning(last)
            self.assertEqual(data['outer_calls'],last+1)
            self.assertEqual(self.parity['learning_coordinate'](data),last)
            self.parity['protocol_core'](protocol(last=last),pid=123,ids=[20],
                measurements=[{'point_id':20,'code':323,'class':2}],learning=data)
    def test_native_bootstrap_inclusive_or_changed_normal_counter_is_rejected(self):
        for native_count in (14,16):
            with self.subTest(native_count=native_count),self.assertRaises(ValueError):
                self.parity['protocol_core'](protocol(last=native_count),pid=123,ids=[20],
                    measurements=[{'point_id':20,'code':323,'class':2}],learning=learning(15))
    def test_learning_bootstrap_normal_indices_outer_count_and_terminal_are_all_bound(self):
        cases=[]
        def changed(edit):
            data=learning();edit(data);cases.append(data)
        changed(lambda x:x.update(outer_calls=15))
        changed(lambda x:x.update(outer_calls=17))
        changed(lambda x:x.update(outer_calls=True))
        changed(lambda x:x['records'][0].update(call_index=1))
        changed(lambda x:x['records'][0].update(call_index=False))
        changed(lambda x:x['records'][0].update(phase='RUN'))
        changed(lambda x:x['records'][0].update(point_id=2))
        changed(lambda x:x['records'][0].update(streak=1))
        changed(lambda x:x['records'][0].update(state_before=[0]*15))
        changed(lambda x:x['records'][7].update(call_index=8))
        changed(lambda x:x['records'][7].update(point_id=8))
        changed(lambda x:x['records'][7].update(phase='RUN'))
        changed(lambda x:x['records'][7].update(state_before=None))
        changed(lambda x:x['records'][-1].update(streak=11))
        changed(lambda x:x['records'][-1].update(code=219))
        changed(lambda x:x['records'].pop(7))
        for index,replacement in ((0,'LEARNING_FAILED'),(1,'2'),(2,'16'),(3,'11'),(4,'219')):
            changed(lambda x,i=index,r=replacement:x['terminal'].__setitem__(i,r))
        changed(lambda x:x.update(terminal=['LEARNED',1,15,12,323]))
        changed(lambda x:x.update(streak=11))
        for key in ('success','ready','status_learning_complete','all_training_ids_seen'):
            changed(lambda x,k=key:x.update({k:False}))
        for index,data in enumerate(cases):
            with self.subTest(case=index),self.assertRaises(ValueError):self.parity['learning_coordinate'](data)
    def test_maps_require_exact_provider_and_self_ELF(self):
        runtime={'provider'+str(i):'A'*64 for i in range(15)}
        maps={key:map_proof(123,runtime,'/synthetic/check') for key in ('ready','learned','done-1')}
        self.parity['maps_core'](maps,pid=123,executable_path='/synthetic/check',executable_sha256='C'*64,runtime=runtime,ids=[20])
        maps['done-1']['ELF']['foreign']='D'*64
        with self.assertRaises(ValueError):self.parity['maps_core'](maps,pid=123,executable_path='/synthetic/check',executable_sha256='C'*64,runtime=runtime,ids=[20])
    def test_maps_changed_identity_rejected(self):
        runtime={'provider'+str(i):'A'*64 for i in range(15)}
        maps={key:map_proof(123,runtime,'/synthetic/check') for key in ('ready','learned','done-1')}
        maps['ready']['identity']['start_time_ticks']+=1
        with self.assertRaises(ValueError):self.parity['maps_core'](maps,pid=123,executable_path='/synthetic/check',executable_sha256='C'*64,runtime=runtime,ids=[20])
    def test_own_runtime_parity_keeps_retained_output(self):
        runtime={'provider'+str(i):'A'*64 for i in range(15)};rows=[]
        for arm,pid in (('plain',123),('observed',124)):
            executable='/synthetic/'+arm
            rows.append({'request':{'lane':'candidate','arm':arm,'policy':'cache0','cohort':'critical20','ids':[20]},
                'pid':pid,'returncode':0,'orchestration_closed':True,'no_retry':True,'stderr_sha256':'E'*64,
                'analysis':{'accepted_for_continuation':True,'learning':learning(),
                            'measurements':[{'point_id':20,'code':323,'class':2}]},
                'protocol':protocol(pid),'maps':{key:map_proof(pid,runtime,executable) for key in ('ready','learned','done-1')},
                'executable_path':executable,'executable_sha256':'C'*64})
        self.assertTrue(self.parity['own_runtime_parity'](*rows,runtime=runtime)['passed'])
        rows[1]['stderr_sha256']='F'*64
        with self.assertRaises(ValueError):self.parity['own_runtime_parity'](*rows,runtime=runtime)
    def test_unaccepted_BUILD_gate_rejected(self):
        docs=list(documents(self.binding));docs[0]['build_accepted']=False
        with self.assertRaises(ValueError):self.validate(docs)
    def test_BUILD_gate_does_not_grant_RUN(self):
        self.assertTrue(self.validate())
        docs=list(documents(self.binding));docs[0]['RUN_admitted']=True
        with self.assertRaises(ValueError):self.validate(docs)
    def test_review_raw_inventory_mismatch_rejected(self):
        with self.assertRaises(ValueError):self.validate(inventory_sha='0'*64)
    def test_incomplete_BUILD_cleanup_rejected(self):
        docs=list(documents(self.binding));docs[1]['cleanup']['survivors']=[{'pid':1}]
        with self.assertRaises(ValueError):self.validate(docs)
    def test_wrong_compiled_source_rejected(self):
        docs=list(documents(self.binding));docs[2]['source_index_sha256']='D'*64
        with self.assertRaises(ValueError):self.validate(docs)
    def test_compiled_proxy_preserves_RUN_identity(self):
        m=dict(self.binding);trace=[];gate,_,result,_=documents(m)
        m['verify_live'].__globals__['accepted_gate']=lambda root:(trace.append('gate') or gate,result)
        b=SimpleNamespace(ROOT=Path('/synthetic/root'),HERE=Path('/synthetic/RUN'),WORK=Path('/synthetic/RUN-work'),
                          EXPECTED_SOURCE='D'*64,REVIEWED_BUILD=m['BUILD_TERMINAL'])
        old=(b.HERE,b.WORK,b.EXPECTED_SOURCE,b.REVIEWED_BUILD)
        def compiled(proxy):
            trace.append('compiled')
            self.assertEqual(proxy.HERE,b.ROOT/m['COMPILED_HERE'])
            self.assertEqual(proxy.WORK,b.ROOT/m['COMPILED_WORK'])
            self.assertEqual(proxy.EXPECTED_SOURCE,m['COMPILED_SOURCE'])
            self.assertEqual((b.HERE,b.WORK,b.EXPECTED_SOURCE,b.REVIEWED_BUILD),old)
            return result
        value=m['verify_live'](b,SimpleNamespace(verified_build=compiled))
        self.assertEqual(trace,['gate','compiled']);self.assertEqual((b.HERE,b.WORK,b.EXPECTED_SOURCE,b.REVIEWED_BUILD),old)
        self.assertFalse(value['RUN_admission_granted_by_BUILD_gate'])
    def test_failed_gate_prevents_live_compiled_read(self):
        m=load('build_binding');trace=[]
        def refuse(root):trace.append('gate');raise ValueError('synthetic refusal')
        m['verify_live'].__globals__['accepted_gate']=refuse
        with self.assertRaises(ValueError):m['verify_live'](SimpleNamespace(ROOT=Path('/synthetic')),SimpleNamespace(verified_build=lambda b:trace.append('forbidden')))
        self.assertEqual(trace,['gate'])
    def test_cache_cards_have_only_declared_deltas(self):
        policies=json.loads((HERE/'runtime-policies.json').read_text())['policies'];original=(HERE/'cards/original-MadLoopParams.dat').read_bytes()
        for name,policy in policies.items():
            self.worker['validate_policy'](policy,{'policy':name})
            self.assertTrue(self.worker['validate_runtime_card'](original,(HERE/policy['runtime_card']).read_bytes(),policy))
            changed=(HERE/policy['runtime_card']).read_bytes().replace(b'#TIRustComputeFinite\n.TRUE.',b'#TIRustComputeFinite\n.FALSE.')
            with self.assertRaises(ValueError):self.worker['validate_runtime_card'](original,changed,policy)
    def test_card_path_escape_rejected(self):
        policy=json.loads((HERE/'runtime-policies.json').read_text())['policies']['cacheall'];policy['runtime_card']='../outside.dat'
        with self.assertRaises(ValueError):self.worker['validate_policy'](policy,{'policy':'cacheall'})
    def test_worker_retains_exit_and_empty_tail_helpers(self):
        source=(HERE/'cache_worker.py').read_text()
        self.assertIn("seq=protocol.send('EXIT',0);exit_reply",source)
        self.assertIn("process.returncode==0",source)
        self.assertIn("protocol.terminal_empty()",source)
        self.assertNotIn("protocol.send('STOP'",source)
        self.assertIn("'compiled_source_index_sha256':binding['compiled_source_sha256']",source)
        self.assertNotIn("parsed['accepted_for_continuation'] or parsed['expected_legacy_critical_failure']",source)
    def accuracy_fixture(self,value=0.0):
        word=lambda x:struct.pack('>d',x).hex().upper()
        state=[0,1,0,0]+[0]*11
        bootstrap={'phase':'LEARN','call_index':0,'point_id':1,'class':1,'state_before':None,'state_after':list(state),'rawACC':[word(-1.)]*2}
        steady={'phase':'LEARN','call_index':2,'point_id':2,'class':2,'state_before':list(state),'state_after':list(state),'rawACC':[word(value)]*2}
        measured={'phase':'RUN','call_index':1,'point_id':20,'class':2,'state_before':list(state),'state_after':list(state),'rawACC':[word(value)]*2}
        return {'lane':'candidate','expected_legacy_critical_failure':False,'learning':{'records':[bootstrap,steady]},'measurements':[measured]}
    def test_strict_accuracy_measurement_and_steady_learning(self):
        accuracy=load('accuracy_policy');normal=load('normal_run_analysis')
        report=accuracy['enforce'](self.accuracy_fixture(1e-6),word_value=normal['_value'])
        self.assertEqual(len(report['checked']),4);self.assertEqual(len(report['unqualified']),1)
    def test_accuracy_above_threshold_rejected(self):
        accuracy=load('accuracy_policy');normal=load('normal_run_analysis')
        with self.assertRaises(ValueError):accuracy['enforce'](self.accuracy_fixture(1.001e-6),word_value=normal['_value'])
    def test_nonfinite_accuracy_rejected(self):
        accuracy=load('accuracy_policy');normal=load('normal_run_analysis')
        with self.assertRaises(ValueError):accuracy['enforce'](self.accuracy_fixture(float('inf')),word_value=normal['_value'])
    def test_legacy_exception_flag_rejected(self):
        accuracy=load('accuracy_policy');normal=load('normal_run_analysis');data=self.accuracy_fixture();data['expected_legacy_critical_failure']=True
        with self.assertRaises(ValueError):accuracy['enforce'](data,word_value=normal['_value'])
    def test_observed_wrapper_is_explicitly_unwrapped(self):
        run=load('cache_run')
        normal={'schema':'normal-cms-raw64-analysis-v1','lane':'candidate','pid':1,'request_ids':[],
                'learning':{},'measurements':[],'accepted_for_continuation':True}
        wrapper={**normal,'schema':'cms-observer-run-analysis-v1','normal_analysis':normal}
        self.assertIs(run['normal_view'](wrapper),normal)
        wrapper['measurements']=[{'invented':True}]
        with self.assertRaises(ValueError):run['normal_view'](wrapper)


if __name__=='__main__':unittest.main()
