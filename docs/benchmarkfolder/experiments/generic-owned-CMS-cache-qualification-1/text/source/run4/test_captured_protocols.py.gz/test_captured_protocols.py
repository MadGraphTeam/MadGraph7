"""File-only captured RUN3 parser summaries; no native rerun or stage adoption."""
from pathlib import Path
import copy
import json
import unittest

HERE=Path(__file__).resolve().parent


class CapturedProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=HERE/'protocol_parity.py';ns={'__file__':str(path),'__name__':'captured_protocol'}
        exec(compile(path.read_text(),str(path),'exec'),ns)
        cls.core=staticmethod(ns['protocol_core']);cls.coordinate=staticmethod(ns['learning_coordinate'])
        cls.fixture=json.loads((HERE/'captured-protocol-fixtures.json').read_text())
    def check(self,case):
        return self.core(case['protocol'],pid=case['pid'],ids=case['ids'],
                         measurements=case['measurements'],learning=case['learning'])
    def test_all_four_actual_transcripts_and_actual_normal_summaries(self):
        self.assertTrue(self.fixture['actual_normal_parser_replayed'])
        self.assertEqual(len(self.fixture['cases']),4)
        for case in self.fixture['cases']:
            self.assertEqual(self.coordinate(case['learning']),15)
            self.assertEqual(case['learning']['outer_calls'],16)
            self.assertEqual(self.check(case),case['normalized_protocol'])
    def test_native_bootstrap_inclusive16_is_rejected(self):
        for original in self.fixture['cases']:
            case=copy.deepcopy(original)
            row=next(x for x in case['protocol'] if x['direction']=='RECV' and x['fields'][0]=='LEARNED')
            row['fields'][4]='16'
            with self.assertRaises(ValueError):self.check(case)
    def test_ready_streak12_is_not_normal_index15(self):
        for original in self.fixture['cases']:
            case=copy.deepcopy(original)
            row=next(x for x in case['protocol'] if x['direction']=='RECV' and x['fields'][0]=='LEARNED')
            row['fields'][4]='12'
            with self.assertRaises(ValueError):self.check(case)
    def test_changed_bootstrap_marker_is_rejected(self):
        case=copy.deepcopy(self.fixture['cases'][0]);case['learning']['records'][0]['call_index']=1
        with self.assertRaises(ValueError):self.check(case)
    def test_changed_normal_record_counter_is_rejected(self):
        case=copy.deepcopy(self.fixture['cases'][0]);case['learning']['records'][-1]['call_index']=14
        with self.assertRaises(ValueError):self.check(case)
    def test_dropping_postbootstrap_init_records_is_rejected(self):
        case=copy.deepcopy(self.fixture['cases'][0]);case['learning']['records']=case['learning']['records'][:1]+case['learning']['records'][4:]
        case['learning']['outer_calls']=len(case['learning']['records'])
        with self.assertRaises(ValueError):self.check(case)


if __name__=='__main__':unittest.main()
