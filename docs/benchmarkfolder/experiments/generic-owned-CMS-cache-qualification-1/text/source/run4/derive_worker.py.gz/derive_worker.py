"""Pure adaptation of the closed normal worker; no import or process execution."""
from pathlib import Path
import ast
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-plain-run-proposal-4'


def require(ok,message):
    if not ok:raise ValueError(message)


def derive():
    original=(PARENT/'cms_run.py').read_text()
    parent_index=json.loads((PARENT/'source-index.json').read_text())
    require(hashlib.sha256(original.encode()).hexdigest()==parent_index['files']['cms_run.py']['sha256'],'closed worker source changed')
    tree=ast.parse(original)
    names=('require','read','digest','identity','point_words','ready_reply','learned_reply','done_reply','exit_reply',
           'Protocol','checked_copy','resource_layout','worker_failure','one')
    sections={node.name:ast.get_source_segment(original,node)+'\n' for node in tree.body
              if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names}
    require(set(sections)==set(names),'closed worker helper inventory changed')
    worker=sections['one']
    changes=[
      ('def one(b,directory,request,row):','def one(b,directory,request,row,binding,policy):'),
      ("    data=read(b.HERE/'input-pins.json');source=Path(row['path']).parent.parent.parent", "    require(binding['compiled_source_sha256']==COMPILED_SOURCE and binding['terminal_sha256']==BUILD_TERMINAL and binding['result_sha256']==BUILD_RESULT,'actual closed BUILD binding required')\n    require(request['arm'] in ('plain','observed') and row==binding['variants'][request['arm']],'worker/ELF arm binding')\n    validate_policy(policy,request)\n    data=read(b.HERE/'input-pins.json');source=Path(row['path']).parent.parent.parent"),
      ('    policy=runtime_policy(b)','    runtime_card=b.HERE/policy[\'runtime_card\']\n    validate_runtime_card((b.HERE/\'cards/original-MadLoopParams.dat\').read_bytes(),runtime_card.read_bytes(),policy)'),
      ("checked_copy(b.HERE/'cards/MadLoopParams.dat',target,output,policy['runtime_sha256'],b.LIMITS['file_bytes'])", "checked_copy(runtime_card,target,output,policy['runtime_sha256'],b.LIMITS['file_bytes'])"),
      ('    # All other card bytes remain exact; full normal/cache0 policy is unchanged.', '    # Only strict stability and the declared per-worker cache field differ.'),
      ("want=digest(b.HERE/'cards'/name)","want=policy['runtime_sha256'] if name=='MadLoopParams.dat' else digest(b.HERE/'cards'/name)"),
      ("'reviewed_build':TERMINAL,'request':request,'new_session':False", "'reviewed_build':binding['terminal_sha256'],'compiled_source_index_sha256':binding['compiled_source_sha256'],'compiled_result_sha256':binding['result_sha256'],'ELF_sha256':row['sha256'],'runtime_card_sha256':policy['runtime_sha256'],'request':request,'new_session':False"),
      ("require(parsed['accepted_for_continuation'] or parsed['expected_legacy_critical_failure'],'unexpected candidate/control numerical failure; no further calls')", "require(parsed['accepted_for_continuation'] and parsed['expected_legacy_critical_failure'] is False,'unexpected new candidate numerical failure; no legacy allowance')"),
      ("require(all(digest(p)==digest(b.HERE/'cards'/name) and p.resolve().is_relative_to(output.resolve()) for p in output.rglob(name)),'worker changed physical/numerical cards')", "want=policy['runtime_sha256'] if name=='MadLoopParams.dat' else digest(b.HERE/'cards'/name)\n            require(all(digest(p)==want and p.resolve().is_relative_to(output.resolve()) for p in output.rglob(name)),'worker changed physical/numerical cards')")]
    for old,new in changes:
        require(worker.count(old)==1,'worker adaptation anchor missing/duplicated: '+old)
        worker=worker.replace(old,new,1)
    header='''"""Dormant strict worker adaptation. No action at import; no retry."""
from pathlib import Path
import hashlib,json,os,selectors,shutil,struct,subprocess,time
SUB=Path('SubProcesses/P0_epem_mupmum')
COMPILED_SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
BUILD_TERMINAL='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44'
BUILD_RESULT='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137'
ORIGINAL_CARD_SHA='8b8f556a4d52f570a4f80d81d105bb1b4636badd232f097ec8afe19a923ef969'

def validate_policy(policy,request):
    require(policy['name']==request['policy'] and policy['name'] in ('cache0','cacheall'),'undeclared fixed worker policy')
    require(policy['GlobalCache']==(0 if policy['name']=='cache0' else -1) and policy['CacheMaxBytes']==268435456,'undeclared cache/budget delta')
    require(policy['runtime_card']=='cards/'+policy['name']+'.dat','runtime card path escape/policy mismatch')

def validate_runtime_card(original,runtime,policy):
    require(hashlib.sha256(original).hexdigest()==ORIGINAL_CARD_SHA,'original compiled card changed')
    old=b'#MLStabThres\\n1.000000d-03\\n';new=b'#MLStabThres\\n1.000000d-06\\n'
    require(original.count(old)==1,'strict stability source anchor')
    expected=original.replace(old,new)
    cache=b'#TIRustGlobalCache\\n0\\n'
    require(expected.count(cache)==1,'cache source anchor')
    expected=expected.replace(cache,b'#TIRustGlobalCache\\n'+str(policy['GlobalCache']).encode()+b'\\n')
    require(runtime==expected and hashlib.sha256(runtime).hexdigest()==policy['runtime_sha256'],'extra/incorrect runtime card delta')
    return True

'''
    source=header+'\n'.join(sections[name] for name in names if name!='one')+'\n'+worker
    compile(source,str(HERE/'cache_worker.py'),'exec')
    (HERE/'cache_worker.py').write_text(source)
    receipt={'schema':'mutable-cache-RUN-worker-source-derivation-v1','parent_source_sha256':hashlib.sha256(original.encode()).hexdigest(),
      'unchanged_helpers':{name:hashlib.sha256(sections[name].encode()).hexdigest() for name in names if name!='one'},
      'declared_worker_changes':[{'old':a,'new':b} for a,b in changes],
      'derived_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'native_calls':0,'source_sealed':False,
      'RUN_admitted':False,'actual_independent_BUILD_review_required_before_operational_wiring':True}
    (HERE/'worker-derivation.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    return receipt


if __name__=='__main__':print(json.dumps(derive(),sort_keys=True))
