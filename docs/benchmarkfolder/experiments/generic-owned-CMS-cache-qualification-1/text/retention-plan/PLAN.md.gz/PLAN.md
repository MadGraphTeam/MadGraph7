# Portable cache RUN4 retention proposal

Preserve the successful twelve-worker source4 run as a separate private capsule. Final collection/sealing depends on the actual independent closed RUN4 receipt; this proposal does not import a future receipt or authorize execution/publication. The exact current evidence pins and replay/negative-test requirements are in `plan.json`.

Retain the complete raw normal/protocol/maps/geometry/cache records for all twelve workers, exact source/parser/card/compiled-identity joins, and the blocked source1 plus failed RUN2/RUN3 histories. Preserve native artifact identities, never native binaries. A publication map must bind every original input to an owned member with exact bytes/hash; portable replay must work relocated with outside filesystem/process/loader/network effects rejected.

Replay all six own plain/observed parity gates, all six cache policy comparisons, and all recorded event/lifecycle/failure counter gates from raw evidence. Keep normal learning bootstrap index0 distinct from native last normal K15. The thirty-two recorded veto decisions and two group19 QP cache hits are observations, not independent amplitude truth. Failed/reset intervals cannot form lifetime hit totals or rates.

Scope remains the tested NSQSO1 Rust cache path. Fortran group cache is inapplicable. General caller/numerator proof, independent finite/pole truth, performance acceptance, production promotion, hidden software/error API state parity remain unqualified. The canonical report and production files are untouched.
