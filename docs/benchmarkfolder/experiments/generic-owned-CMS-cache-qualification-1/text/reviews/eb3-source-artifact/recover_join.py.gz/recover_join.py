from pathlib import Path
import json,hashlib,re,tomllib
root=Path.cwd();work=root/'.tirust-build/qp-transport-install';mg=work/'mg';prefix=mg/'HEPTools/tirust';lib=prefix/'lib';out=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
cfg=read(lib/'tirust-config.json');source=read(work/'source-inventory.json');start=read(work/'install-start.json');package=read(work/'package-result.json');events=[json.loads(x) for x in (work/'execution-observer.jsonl').read_text().splitlines()]
assert sha(lib/'libmadloop_tirust.so')==cfg['artifact_sha256']['libmadloop_tirust.so']=='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9'
for n in cfg['artifact_sha256']:assert sha(lib/n)==cfg['artifact_sha256'][n]==package['native_artifacts'][n]['sha256']
for n in ('Cargo.toml','Cargo.lock'):assert sha(prefix/n)==cfg['build_provenance']['manifest_sha256' if n.endswith('toml') else 'lock_sha256']
selected=['vendor/tirust/src/lib.rs','vendor/tirust/Cargo.toml','vendor/tirust/Cargo.lock','vendor/tirust/Makefile','vendor/tirust/mtirust.f90','vendor/tirust/patches/0001-direct-poles-only.patch','vendor/tirust/patches/manifest.json','madgraph/various/tirust_install.py']
for n in selected:assert sha(mg/n)==source[n]
assert start['bridge_sha256']==package['bridge_source_sha256']==source['vendor/tirust/src/lib.rs']=='455529b929b725e8fe2d7337ab4a41fa3de9dee1b3a953afe6dc032cf99e5a4c'
assert sha(prefix/'include/mtirust.f90')==start['fortran_source_sha256']==source['vendor/tirust/mtirust.f90']
patch=mg/'vendor/tirust/patches/0001-direct-poles-only.patch';assert sha(patch)==start['patch_sha256']==cfg['local_sources']['tirust']['patch_sha256']
assert all(x['returncode']==0 for x in events if x['event']=='completed')
ref=root.parent/'references/TIRust';ignore={'.git','target','references','__pycache__','.direnv'};data={};stack=[ref]
while stack:
 directory=stack.pop()
 for p in directory.iterdir():
  if p.name in ignore:continue
  if p.is_dir():stack.append(p)
  elif p.is_file():data[p.relative_to(ref).as_posix()]=p.read_bytes()
files={n:hashlib.sha256(v).hexdigest() for n,v in data.items()};tree=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(files)==cfg['local_sources']['tirust']['source_files']==463 and tree==cfg['local_sources']['tirust']['source_tree_sha256']=='5b60209fe4a66cc32b7b228afc46c9d0a42cd095d2ca904dd8dd2285bc4b263a'
# Strict in-memory unified-patch reconstruction; source/reference files are never written.
lines=patch.read_text().splitlines(keepends=True);i=0;patched={};hunks=0
while i<len(lines):
 if not lines[i].startswith('--- '):i+=1;continue
 old=lines[i][4:].strip();new=lines[i+1][4:].strip();i+=2;name=new.removeprefix('b/');old_lines=[] if old=='/dev/null' else data[old.removeprefix('a/')].decode().splitlines(keepends=True);cursor=0;result=[]
 while i<len(lines) and not lines[i].startswith('--- '):
  if not lines[i].startswith('@@ '):i+=1;continue
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert match
  position=max(int(match[1])-1,0);old_count=int(match[2] or 1);new_count=int(match[4] or 1);assert position>=cursor;result.extend(old_lines[cursor:position]);cursor=position;i+=1;a=b=0
  while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
   line=lines[i]
   if line.startswith('\\ No newline'):raise AssertionError('Unexpected no-newline marker')
   if not line.startswith((' ','+','-')):break
   if line[0] in (' ','-'):assert cursor<len(old_lines) and old_lines[cursor]==line[1:],(name,cursor);cursor+=1;a+=1
   if line[0] in (' ','+'):result.append(line[1:]);b+=1
   i+=1
  assert (a,b)==(old_count,new_count),(name,a,b,old_count,new_count);hunks+=1
 result.extend(old_lines[cursor:]);patched[name]=''.join(result).encode()
kernels={n.removeprefix('vendor/tirust/pole-kernels/'):h for n,h in source.items() if n.startswith('vendor/tirust/pole-kernels/')}
for n,h in kernels.items():assert sha(mg/'vendor/tirust/pole-kernels'/n)==h
kerneltree=hashlib.sha256(json.dumps(kernels,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert len(kernels)==cfg['local_sources']['pole_kernels']['source_files']==14 and kerneltree==cfg['local_sources']['pole_kernels']['source_tree_sha256']
prov=read(lib/'tirust-dependency-provenance.json');assert prov['cargo_lock_sha256']==sha(prefix/'Cargo.lock')
for package_record in prov['packages']:
 if package_record['name'] in ('iregi-rust','iregi-masters'):
  name='crates/'+package_record['name']+'/Cargo.toml';assert hashlib.sha256(patched.get(name,data[name])).hexdigest()==package_record['manifest_sha256']
log=(prefix/'install.log').read_text();metadata=[json.loads(line) for line in log.splitlines() if line.startswith('{"packages":')];assert len(metadata)==1
command='cargo rustc --release --locked --lib --features poles-only -- -C link-arg=-Wl,-soname,libmadloop_tirust.so -C link-arg=-Wl,--exclude-libs,ALL';assert command in log
assert 'Compiling madloop-tirust v0.1.0' in log and 'Finished `release` profile' in log and 'TIRust ABI1: DP, binary128 input, UV/IR poles and cache checks passed' in log
assert sha(root/'.tirust-build/target/release/libmadloop_tirust.so')==cfg['artifact_sha256']['libmadloop_tirust.so']
for name in ('crates/iregi-rust/src/store.rs','crates/iregi-rust/src/direct/shared.rs'):assert name not in patched
cache_sources=['crates/iregi-rust/src/store.rs','crates/iregi-rust/src/direct/shared.rs','crates/iregi-rust/src/direct/exec.rs','crates/iregi-rust/src/direct/poles.rs']
reconstructed={n:hashlib.sha256(patched[n] if n in patched else data[n]).hexdigest() for n in cache_sources}
(out/'recovered-source-files.json').write_text(json.dumps({'schema':'eb3-recovered-build-source-identities-v1','upstream_prepatch_files':files,'upstream_prepatch_tree_sha256':tree,'patched_files_sha256':{n:hashlib.sha256(v).hexdigest() for n,v in patched.items()},'strict_hunks_applied_in_memory':hunks,'bundled_pole_kernel_files':kernels,'bundled_pole_kernel_tree_sha256':kerneltree,'cache_implementation_files_sha256':reconstructed},indent=2,sort_keys=True)+'\n')
inputs=[work/n for n in ('source-inventory.json','source-revision.json','install-start.json','execution.json','execution-observer.jsonl','package-result.json','prepare_snapshot.py','package_evidence.py','run.sh')]+[lib/'tirust-config.json',prefix/'Cargo.toml',prefix/'Cargo.lock',prefix/'install.log',lib/'tirust-dependency-provenance.json']+[mg/n for n in selected]
receipt={'schema':'eb3-cache-source-artifact-join-audit-v1','status':'recorded_source_artifact_join_recovered_CMS_cache_execution_unqualified','artifact_sha256':cfg['artifact_sha256'],'artifact_bytes':(lib/'libmadloop_tirust.so').stat().st_size,'recorded_source_revision':read(work/'source-revision.json')['revision'],'bridge_src_sha256':source['vendor/tirust/src/lib.rs'],'manifest_sha256':sha(prefix/'Cargo.toml'),'resolved_lock_sha256':sha(prefix/'Cargo.lock'),'upstream_revision':cfg['local_sources']['tirust']['revision'],'upstream_prepatch_tree_sha256':tree,'upstream_source_files':len(files),'patch_sha256':sha(patch),'strict_patch_hunks_reconstructed_in_memory':hunks,'pole_kernel_tree_sha256':kerneltree,'cache_implementation_sources':reconstructed,'archived_make_command':command,'installed_target_DSO_hashes_equal':True,'all_observed_installer_subprocesses_succeeded':True,'temporary_staging_exists':False,'dependency_notices_are_full_source_archive':False,'recorded_build_provenance_not_cryptographic_or_clean_rebuild_attestation':True,'later_mutable_Cargo_fingerprint_not_used_as_source_attestation':True,'new_build_install_native_library_query_test_Git_actions':0,'production_install_configuration_reference_public_changes':False,'new_CMS_cache_qualification_or_execution_admitted':False,'inputs':{str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in inputs},'recovered_source_inventory_sha256':sha(out/'recovered-source-files.json')}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(out/'receipt.json'),'sha256':sha(out/'receipt.json'),'recovered_inventory_sha256':sha(out/'recovered-source-files.json'),'cache_sources':reconstructed,'hunks':hunks,'status':receipt['status']},indent=2))
