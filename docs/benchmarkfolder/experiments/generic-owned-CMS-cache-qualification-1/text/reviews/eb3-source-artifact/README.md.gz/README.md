# Exact eb3 cache implementation and build provenance

The existing installation supplies a recoverable recorded source/artifact join.
A new build is not necessary merely to identify its cache implementation.
This does not qualify cache-enabled CMS behavior or independently attest a
compiler's output. No build, install, native/library query, numerical test,
Git action or production/configuration/reference/public change was performed.

The physical installed DSO and the recorded target release DSO both hash
`eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9`.
Installed `tirust-config.json` and the earlier package receipt bind that DSO,
Fortran archive `0c86349a…` and module `d7838e75…` to manifest `20686c31…`,
resolved lock `c4f59f29…`, TIRust854b79dc and oneloopmasterbd703d09.
The isolated installation was built from MadGraph059bb9c9, whose retained
source inventory and install-start/package receipts independently pin:

- Bridge `src/lib.rs`: `455529b929b725e8fe2d7337ab4a41fa3de9dee1b3a953afe6dc032cf99e5a4c`.
- Installer: `352052637afbd82ab84f27508eda1bdfd9abc6115409adc23f8262e94c38d370`.
- Makefile: `70950cda5b23f22255085a49f637c22fec5286d8d2504c3219c98e9d005d4f5d`.
- Pole patch: `80ef17b367511419e734f760edca4593f15a324996c4830b815c03cf884cbab5`.

The original temporary staging directory has been removed. However, the supplied
reference TIRust tree reproduces exactly the installer's full463-file prepatch
inventory digest `5b60209f…`, under its documented exclusion policy. The bundled
14 pole-kernel source files reproduce tree digest `2d449d05…`. All61 patch hunks
apply exactly in memory, with full old-line/count checks and no filesystem source
edits. Reconstructed iregi-rust/iregi-masters manifests match the installed Cargo
dependency provenance. The cache implementation's exact postpatch hashes are
in recovered-source-files.json. In particular, store.rs and direct/shared.rs
are unchanged by the patch; direct/exec.rs and new direct/poles.rs are identified
by their reconstructed hashes rather than the unpatched current reference text.

The retained observer records successful fetch/checkout, patch, metadata and
make/install commands. The actual install log records:

```
cargo rustc --release --locked --lib --features poles-only -- -C link-arg=-Wl,-soname,libmadloop_tirust.so -C link-arg=-Wl,--exclude-libs,ALL
```

It identifies the private bridge compilation and successful release completion,
then copies the release DSO into the installed prefix. Its captured Cargo
metadata resolves both TIRust crates and the pole kernels into that same staged
source, and its locked git dependencies bind oneloopmaster independently of
NinjaRS. The manifest selects thin LTO and one codegen unit. The observed build
uses shared Cargo caches; this is not clean-cache reproducibility evidence.
The later mutable Cargo fingerprint directory also contains shadow-build files
and is deliberately not used to attest the old source. Dependency notices retain
licenses/manifests, not a complete source archive; they alone are insufficient.

## Exact cache semantics of that source

| Store or boundary | Recorded implementation |
|---|---|
| Full DP | An upstream TensorStore for binary64 scalar masters, subintegrals and moments. Scalar master keys contain family and exact argument bits, including supplied invariants, squared masses and mu². Subset keys add method/configuration, size/rank/value count, exact shifts/masses, supplied distances and scale. Gather keys include the used Laurent slots, coefficient words, geometry/origin and scale. Hash collisions are resolved by complete key equality. |
| Full versus poles DP | Distinct TensorStore and PoleTensorStore objects. The latter cannot attach to a full workspace; its compile-time pole executor uses separate active-slot arithmetic. |
| QP | A bridge-owned whole-tensor cache. The key contains N/rank, pole selection, finite/partial flag,113 input bits,256 arithmetic bits and every fixed-width record byte of shifts, full invariant array, complex masses and mu². These fixed dimensions make concatenation unambiguous. Raw record identity is stricter than numeric equality and preserves transport distinctions, including signed-zero spelling. DD upstream internals are not advertised as QP. |
| Independent checks | DP/check workspaces are structurally distinct for full evaluation; primary tensor stores are detached for every check. QP check requests bypass whole-tensor lookup and insertion. Poles DP also detaches its primary store. No check result is served from the primary tensor cache. |
| Failures | QP whole tensors insert only after successful reduction and packing. DP upstream stores may temporarily include subintegral refusal records or intermediates; they are not successful tensors. The bridge clears the relevant DP store/workspaces after final failure or nonfinite output. A Fortran QP decode failure clears all numerical stores after native insertion. Invalid requests do not become successful cache entries. |
| Budget | With poles-only support, the default256MiB is partitioned as64MiB full DP,64MiB poles DP and128MiB QP. Admission stops insertion at estimated accounting limits; there is no eviction. A budget change clears/repartitions stores. This bounds accounted cache entries, not total process memory, plans or scratch workspaces. |
| Event clear | There is no separate native `clear_event` symbol. The generated CLEAR_TIRUST_CACHE/Fortran tirust_clear_cache route calls ml_tirust_clear_cache, which clears all three numerical stores and counters while preserving plan registrations/structural workspaces. The generated context-generation guard avoids creating an absent context. Each explicit opaque native context owns a Mutex<State>; the default Fortran module shares one context across subprocess prefixes, so subprocess/event lifecycle still depends on the existing caller protocol. |

Fortran already exports both nine-counter aggregate statistics and six-counter
QP hit/miss/entry/byte/refusal/bypass statistics. Aggregate slots5/6 combine DP
moments with QP whole tensors and include pole-store contributions; they cannot
be labelled pure QP counts. A logger can use the dedicated QP statistics without
a Rust ABI change. Statistics calls ensure a context, so instrumentation must
respect context-presence ordering and avoid creating one before the real call.

## Consequence for the next CMS cache gate

The missing source-identification premise can be replaced by this recovered
join. It remains recorded build provenance, not cryptographic/reproducible
compiler attestation: old staging had no retained complete postpatch per-file
snapshot plus independently verified compiler/dependency-object transcript.
If that stronger assurance is required, the smallest additional step is a new
private locked build from these exact reconstructed sources/configuration,
with pre/post source inventories, complete tool/environment/flags and artifact
receipts. Preserve staging/source or a content-addressed source archive, use a
fresh target directory to avoid ambiguous cache ancestry, and smoke/qualify the
new artifact separately. Do not replace active eb3 or pretend rebuilt bytes are
identical without a measured hash match.

No rebuild is indicated solely by the recovered cache code. The actual required
next work remains a separately reviewed private Fortran source successor: the
current corrected CMS route requires cache0 and hardcodes cache disabled.
Eligibility/current-point/reference/mask/q/raw guards must run before its native
call, including a possible QP cache hit. This NSQSO1 process has no Fortran group
cache; that layer is N/A. Keep the cache-off result/provenance reference and
observe actual counters on repeats, changed invariant words, primary/check,
full/partial, precision, failure/recovery, budget and event/prefix boundaries.
The CMS legacy/candidate requests share shifts/masses/scale but differ in an
invariant: whole-QP keys must differ; unchanged DP pinches may legitimately hit.
Cache parity does not supply independent finite truth, and a workload without
natural repeated exact keys does not demonstrate acceleration.
