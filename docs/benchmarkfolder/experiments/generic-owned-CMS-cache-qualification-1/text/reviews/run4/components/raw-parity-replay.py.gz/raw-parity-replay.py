from pathlib import Path
from collections import Counter
import hashlib,json,struct,sys,types

SOURCE=Path('.tirust-build/generic-owned-CMS-cache-run-proposal-4')
BASE=Path('.tirust-build/generic-owned-CMS-cache-run-work-4/run')
COMPILED=Path('.tirust-build/generic-owned-CMS-cache-qualification-proposal-1')
BUILD=Path('.tirust-build/generic-owned-CMS-cache-qualification-work-1/build')
HIST=Path('.tirust-build/generic-owned-CMS-plain-run-work-4/run')
EXPECTED='fca076eeb821a457f13f971a3ae8bc0568022db7eb6622a7c645b08c527c9554'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def canonical(value):return json.loads(json.dumps(value,sort_keys=True,allow_nan=False))
need(digest(SOURCE/'source-index.json')==EXPECTED,'changed source4')
index=read(SOURCE/'source-index.json');modules={};used={}
for name in ('normal_run_analysis','observer_analysis','cache_comparison','accuracy_policy','run_plan'):
    p=SOURCE/(name+'.py');data=p.read_bytes();pin=index['files'][name+'.py'];need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'changed parser helper');used[name+'.py']=pin
    m=types.ModuleType(name);exec(compile(data,str(p),'exec'),m.__dict__);modules[name]=m
for name in ('input-pins.json','runtime-policies.json','inputs/training.dat','inputs/controls.dat','inputs/critical20.dat','inputs/critical21.dat'):
    p=SOURCE/name;pin=index['files'][name];need(p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'],'changed parser input');used[name]=pin
inputs=read(SOURCE/'input-pins.json');policies=read(SOURCE/'runtime-policies.json')['policies'];streams={name:(SOURCE/('inputs/'+name+'.dat')).read_text() for name in ('training','controls','critical20','critical21')}
need(digest(BASE/'terminal.json')=='83034229e1377efc0d2ec2c6ab400065b11a0c2bc778aa5421c8e2970ae7a719','changed RUN4 terminal')
need(digest(BASE/'result.json')=='ee95d391ecf7dc9cf2a7b28cf8ed349e0869c58da22d384632c33f4d2fc41325','changed RUN4 result')
need(digest(BASE/'cache-observations.json')=='82b80686d5206c94c5a7ead314aa63b9756e7588961d135eb6a94998b766128d','changed cache observations')
terminal=read(BASE/'terminal.json');result=read(BASE/'result.json')
need(result['RUN_source_index_sha256']==EXPECTED and result['compiled_source_index_sha256']=='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93','wrong closed source identities')
need(digest(COMPILED/'source-index.json')=='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93','changed compiled source index')
need(digest(BUILD/'result.json')=='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137','changed closed BUILD metadata')
built=read(BUILD/'result.json');dispatch_path=Path(built['variants']['observed']['path']).parent/'CT_interface.f';dispatch=dispatch_path.read_bytes();dispatch_pin=built['variants']['observed']['source_inventory']['SubProcesses/P0_epem_mupmum/CT_interface.f']
need(len(dispatch)==dispatch_pin['bytes'] and hashlib.sha256(dispatch).hexdigest()==dispatch_pin['sha256'],'changed selected compiled dispatch')
need(dispatch_pin==read(COMPILED/'source-index.json')['files']['emittedsrc/observed/CT_interface.f'],'dispatch not tied to compiled6417')
driver=Path(built['variants']['plain']['path']).parent/'check_sa.f';driver_pin=built['variants']['plain']['source_inventory']['SubProcesses/P0_epem_mupmum/check_sa.f'];driver_text=driver.read_text();need(driver.stat().st_size==driver_pin['bytes'] and digest(driver)==driver_pin['sha256'],'changed closed fenv driver')
state_block=driver_text[driver_text.index('      SUBROUTINE DRIVER_READ_STATE(STATE)'):];state_block=state_block[:state_block.index('\n      END\n')+len('\n      END\n')]
need(digest(HIST/'result.json')=='b0a3eb3596a8c183775d37a1a791a2aee3e3ca671958f8e2884776d79cb042eb','changed historical normal result')
historical=read(HIST/'result.json');references={}
for cohort in ('controls','critical20','critical21'):
    row=historical['requests']['candidate-'+cohort];p=HIST/'evidence'/('candidate-'+cohort)/'driver.raw64';need(digest(p)==row['raw_sha256'],'changed historical reference');references[cohort]={'raw':p.read_text(),'raw_sha256':row['raw_sha256']}
plan=modules['run_plan'];requests=plan.requests();plan.validate_requests(requests);need(set(result['worker_results'])=={r['id'] for r in requests} and len(requests)==12,'incomplete worker result set')
records={};input_pins={}
for request in requests:
    key=request['id'];phase=result['worker_results'][key];vp=Path(phase['validated_path']);need(vp.resolve()==(BASE/('validated-'+key+'.json')).resolve() and digest(vp)==phase['validated_sha256'],'changed validated path/record')
    v=read(vp);folder=BASE/'evidence'/key;wp=folder/'result.json';rp=folder/'driver.raw64';need(digest(wp)==v['worker_result_sha256'],'changed worker result');worker=read(wp)
    need(digest(rp)==phase['raw_sha256']==v['raw_sha256']==worker['raw_sha256'],'changed RAW identity')
    need(v['analysis']==worker['analysis'] and v['request']==worker['request']==request and worker['returncode']==v['returncode']==phase['returncode']==0 and worker['orchestration_closed'] is True and worker['no_retry'] is True,'worker/validated closure mismatch')
    records[key]={'request':request,'validated':v,'worker':worker,'raw':rp.read_text()}
    input_pins[key]={'validated':{'path':str(vp),'bytes':vp.stat().st_size,'sha256':phase['validated_sha256']},'worker_result':{'path':str(wp),'bytes':wp.stat().st_size,'sha256':digest(wp)},'raw':{'path':str(rp),'bytes':rp.stat().st_size,'sha256':phase['raw_sha256']}}
comparison_files={}
for key in result['own_plain_observed_parity']:
    p=BASE/('own-parity-'+key+'.json');comparison_files['own:'+key]={'json':read(p),'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
for key in result['cache_policy_numerical_comparisons']:
    p=BASE/('policy-comparison-'+key+'.json');comparison_files['policy:'+key]={'json':read(p),'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
active=[False];attempts=[]
def guard(event,args):
    if active[0] and (event=='open' or event.startswith(('subprocess.','ctypes.','socket.')) or event in ('os.listdir','os.scandir','os.system','os.exec','os.fork','os.posix_spawn','pty.spawn','os.mkdir','os.remove','os.rename','os.rmdir','os.symlink','os.chmod','os.truncate')):
        attempts.append(event);raise RuntimeError('forbidden bounded RUN4 RAW replay effect '+event)
sys.addaudithook(guard)
normal=modules['normal_run_analysis'];observer=modules['observer_analysis'];compare=modules['cache_comparison'];accuracy=modules['accuracy_policy']
def point_words(*texts):
    found={}
    for text in texts:
        lines=text.splitlines();n=int(lines[0]);need(n>0 and len(lines)==1+5*n,'point stream shape')
        for i in range(n):
            point=int(lines[1+5*i]);words=[]
            for line in lines[2+5*i:6+5*i]:
                fields=line.split();need(len(fields)==4,'point component shape');words.append([struct.pack('>d',float(x.replace('D','E').replace('d','e'))).hex().upper() for x in fields])
            need(point not in found or found[point]==words,'inconsistent duplicate point');found[point]=words
    return found
state_names=['CHECKPHASE','HELDOUBLECHECKED','FPE_DP','FPE_QP','IEEE_INVALID','IEEE_DIVIDE_BY_ZERO','IEEE_OVERFLOW','IEEE_UNDERFLOW','IEEE_INEXACT','HALT_INVALID','HALT_DIVIDE_BY_ZERO','HALT_OVERFLOW','HALT_UNDERFLOW','HALT_INEXACT','ROUNDING_MODE']
def state_summary(rows):
    before=[r['state_before'] for r in rows if r['state_before'] is not None];after=[r['state_after'] for r in rows]
    return {'records':len(rows),'before_absent':len(rows)-len(before),'before':{name:dict(sorted(Counter(str(s[i]) for s in before).items())) for i,name in enumerate(state_names)},'after':{name:dict(sorted(Counter(str(s[i]) for s in after).items())) for i,name in enumerate(state_names)},'changes':[{'phase':r['phase'],'call_index':r['call_index'],'point_id':r['point_id'],'columns':[state_names[i] for i,(a,b) in enumerate(zip(r['state_before'],r['state_after'])) if a!=b]} for r in rows if r['state_before'] is not None and r['state_before']!=r['state_after']]}
parsed={};worker_summaries={};own_summaries={};policy_summaries={};all_learning=[];all_measurements=[];all_native=[];all_frames=[]
try:
    active[0]=True
    for request in requests:
        key=request['id'];data=records[key];cohort=request['cohort'];ids=request['ids'];policy=policies[request['policy']];points=point_words(streams['training'],streams[cohort]);pid=data['worker']['pid'];historical_parity=None
        if request['arm']=='plain':
            a=normal.parse_raw(data['raw'],lane='candidate',request_ids=ids,expected_points=points)
            if request['policy']=='cache0':
                old=normal.parse_raw(references[cohort]['raw'],lane='candidate',request_ids=ids,expected_points=points);historical_parity=compare.compare_exact_histories(old,a)
                need(historical_parity['passed'] and historical_parity['histories_exact'],'cache0 historical exact parity failed')
                a['closed_cache0_plain_reference_parity']=compare.compare_exact_prefix(old,a,complete_request_ids=ids,prefix_request_ids=ids)
        else:
            plain_key=request['policy']+'-plain-'+cohort
            a=observer.analyze_observed(data['raw'],records[plain_key]['raw'],lane='candidate',request_ids=ids,observed_pid=pid,plain_pid=records[plain_key]['worker']['pid'],parse_normal=normal.parse_raw,expected_points=points,compiled_dispatch_source=dispatch,cache_policy=policy['GlobalCache'],cache_budget=policy['CacheMaxBytes'])
            need(a['parity']['passed'] and a['journal_schema_complete'] and a['journal_provenance_complete'] is bool(a['observed_veto_count']),'observer parity/schema/scope mismatch')
        need(a['pid']==pid and a['accepted_for_continuation'] is True and a['expected_legacy_critical_failure'] is False,'parsed candidate not accepted')
        a['strict_recorded_accuracy']=accuracy.enforce(a,word_value=normal._value)
        a['driver_identity_verified_by_parser']=False;a['driver_source_sha256_externally_bound']=built['variants'][request['arm']]['source_inventory']['SubProcesses/P0_epem_mupmum/check_sa.f']['sha256'];a['actual_ELF_and_driver_identity_bound_at_READY']=True;a['live_error_API_state_compared']=False
        need(canonical(a)==data['worker']['analysis']==data['validated']['analysis'],'full stored analysis does not exactly replay')
        parsed[key]=a;n=a.get('normal_analysis',a);learning=n['learning']['records'];measurements=n['measurements'];all_learning.extend(learning);all_measurements.extend(measurements)
        qualified=[normal._value(r['word']) for r in a['strict_recorded_accuracy']['checked']]
        summary={'request':request,'pid':pid,'raw_sha256':input_pins[key]['raw']['sha256'],'worker_result_sha256':input_pins[key]['worker_result']['sha256'],'validated_sha256':input_pins[key]['validated']['sha256'],'full_stored_analysis_exactly_reparsed':True,'learning_outer_calls':n['learning']['outer_calls'],'learning_status_counts':dict(sorted(Counter(str(r['code']) for r in learning).items())),'measured':[{'point_id':r['point_id'],'code':r['code'],'class':r['class'],'reported_backend':r['status']['actual_backend'],'reported_precision':r['status']['actual_precision'],'rawANS':r['rawANS'],'rawACC':r['rawACC']} for r in measurements],'strict_accuracy_checked_slots':len(qualified),'maximum_qualified_recorded_accuracy':max(qualified),'unqualified_accuracy_records':a['strict_recorded_accuracy']['unqualified'],'measured_fenv':state_summary(measurements),'learning_fenv':state_summary(learning)}
        if historical_parity is not None:summary['cache0_historical_exact_parity']=historical_parity['passed'];summary['historical_raw_sha256']=references[cohort]['raw_sha256']
        if request['arm']=='observed':
            journals=a['journals'];frames=[f for j in journals for f in j['frames']];native=[e for j in journals for e in j['cache_observations']['events'] if e['kind']==1];all_frames.extend(frames);all_native.extend(native)
            summary['observed']={'journals':len(journals),'owned_frames':sum(j['owned_frames'] for j in journals),'public_fallback_frames':sum(j['public_fallback_frames'] for j in journals),'frame_count':len(frames),'producer_records':sum(len(j['producers']) for j in journals),'consumer_records':sum(len(j['consumers']) for j in journals),'veto_records':a['observed_veto_count'],'journal_provenance_complete':a['journal_provenance_complete'],'group3_frame_mode_width_counts':dict(sorted(Counter(str(f['ctmode'])+':'+str(f['width']) for f in frames).items())),'group3_QP_owned_genuine_true':sum(f['width']==128 and not f['legacy'] and f['observed_genuine_QP'] is True and f['actual_consumer_MP_genuine'] is True for f in frames),'DP_eligibility_true_with_actual_MP_false':sum(f['width']==64 and f['raw_precision_eligibility_flag'] is True and f['actual_consumer_MP_genuine'] is False for f in frames),'native_API_mode_width_counts':dict(sorted(Counter(str(e['mode'])+':'+str(e['width']) for e in native).items())),'native_API_status_counts':dict(sorted(Counter(str(e['status']) for e in native).items())),'native_groups_seen':sorted({e['group'] for e in native}),'executed_word_geometry_cache_schema_checks_passed':True,'counter_metrics_aggregation_not_repeated':True}
            plain=parsed[request['policy']+'-plain-'+cohort];pn=plain.get('normal_analysis',plain);exact=compare.compare_own_parity(pn,n)
            need(exact['passed'] and canonical(exact)==result['own_plain_observed_parity'][key]['normal']==comparison_files['own:'+key]['json']['normal'],'stored own numerical parity mismatch')
            own_summaries[key]={'passed':exact['passed'],'histories_exact':exact['histories_exact'],'difference_count':exact['difference_count'],'all15_states_compared':exact['all15_state_fields_compared'],'report_path':comparison_files['own:'+key]['path'],'report_sha256':comparison_files['own:'+key]['sha256']}
        if request['policy']=='cacheall':
            zero=parsed['cache0-'+request['arm']+'-'+cohort];zn=zero.get('normal_analysis',zero)
            cmp=compare.compare_policy_numerics(zn,n,word_value=normal._value,ratio=normal._ratio,journals0=zero.get('journals'),journals_all=a.get('journals'))
            need(cmp['passed'] and canonical(cmp)==result['cache_policy_numerical_comparisons'][key]==comparison_files['policy:'+key]['json'],'stored cross-policy numerical comparison mismatch')
            finite_errors=[r['relative_error'] for r in cmp['residuals'] if r.get('relative_error') is not None];native_cmp=cmp['native_journal_comparison']
            policy_summaries[key]={'passed':cmp['passed'],'target_1e8_passed':cmp['target_1e8_passed'],'history_exact':cmp['history_exact'],'history_difference_count':len(cmp['history_differences']),'maximum_component_relative_error':max(finite_errors),'all_coefficient_words_bitwise_equal':all(r['bitwise_equal'] for r in cmp['residuals']),'native_journal_provided':native_cmp['provided'],'native_matched_contexts':len(native_cmp['matched']),'native_unmatched_contexts':len(native_cmp['unmatched']),'native_scientific_difference_count':len(native_cmp['scientific_differences']),'native_policy_difference_count':len(native_cmp['policy_differences']),'report_path':comparison_files['policy:'+key]['path'],'report_sha256':comparison_files['policy:'+key]['sha256']}
        worker_summaries[key]=summary
    need(len(parsed)==12 and len(own_summaries)==6 and len(policy_summaries)==6,'incomplete numerical matrix')
    need(terminal['status']=='passed' and terminal['returncode']==0 and result['status']=='passed' and not terminal['cleanup']['survivors'],'closed phase not passed')
    summary={'learning_outer_records':len(all_learning),'measured_outer_calls':len(all_measurements),'total_outer_records':len(all_learning)+len(all_measurements),'measured_reported_status_counts':dict(sorted(Counter(str(r['code']) for r in all_measurements).items())),'measured_reported_precision_counts':dict(sorted(Counter(str(r['status']['actual_backend'])+':'+str(r['status']['actual_precision']) for r in all_measurements).items())),'strict_accuracy_checked_slots':sum(v['strict_accuracy_checked_slots'] for v in worker_summaries.values()),'maximum_qualified_recorded_accuracy':max(v['maximum_qualified_recorded_accuracy'] for v in worker_summaries.values()),'maximum_measured_accuracy':max(normal._value(w) for r in all_measurements for w in r['rawACC']),'recorded_measured_fenv':state_summary(all_measurements),'recorded_learning_fenv':state_summary(all_learning),'observed_group3_frame_count':len(all_frames),'observed_owned_group3_QP_genuine_true':sum(f['width']==128 and not f['legacy'] and f['observed_genuine_QP'] is True and f['actual_consumer_MP_genuine'] is True for f in all_frames),'observed_veto_records':sum(v.get('observed',{}).get('veto_records',0) for v in worker_summaries.values()),'observed_native_API_mode_width_counts':dict(sorted(Counter(str(e['mode'])+':'+str(e['width']) for e in all_native).items())),'observed_native_API_status_counts':dict(sorted(Counter(str(e['status']) for e in all_native).items())),'own_parities':len(own_summaries),'crosspolicy_comparisons':len(policy_summaries),'all_six_policy_targets_1e8':all(v['target_1e8_passed'] for v in policy_summaries.values()),'all_six_policy_histories_exact':all(v['history_exact'] for v in policy_summaries.values())}
finally:active[0]=False
need(not attempts,'forbidden RAW audit effects')
print(json.dumps({'schema':'independent-CMS-cache-RUN4-actual-RAW-parity-v1','source_index_sha256':EXPECTED,'compiled_source_index_sha256':'6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93','terminal_sha256':'83034229e1377efc0d2ec2c6ab400065b11a0c2bc778aa5421c8e2970ae7a719','result_sha256':'ee95d391ecf7dc9cf2a7b28cf8ed349e0869c58da22d384632c33f4d2fc41325','cache_observation_sha256':'82b80686d5206c94c5a7ead314aa63b9756e7588961d135eb6a94998b766128d','pure_modules_and_inputs':used,'selected_actual_dispatch':{'path':str(dispatch_path),**dispatch_pin},'fenv_driver_source':{'path':str(driver),**driver_pin,'state_routine_sha256':hashlib.sha256(state_block.encode()).hexdigest(),'columns':state_names},'input_pins':input_pins,'workers':worker_summaries,'own_numeric_parities':own_summaries,'crosspolicy_numeric_parities':policy_summaries,'summary':summary,'forbidden_API_attempts':attempts,'native_worker_compiler_loader_library_model_queries':0,'preflight_calls':0,'full_BUILD_or_source_reaudit':False,'scope':'Exact actual RAW/journal data replay and same-source numerical/cache-policy agreement only; observed group3 flags/veto branches are source-bound but do not qualify general callers/numerator lifetime, independent physical truth, FP trap freedom or performance. Counter metrics are independently audited elsewhere.','independent_physical_truth':False,'unobserved_FP_or_API_state_equivalence':False,'performance_qualified':False},indent=2,sort_keys=True))
