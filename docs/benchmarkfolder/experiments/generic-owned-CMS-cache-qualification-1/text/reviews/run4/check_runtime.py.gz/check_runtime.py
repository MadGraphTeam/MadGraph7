from pathlib import Path
import hashlib,json,sys,datetime
ROOT=Path.cwd();BASE=ROOT/'.tirust-build/generic-owned-CMS-cache-run-work-4/run';HERE=ROOT/'.tirust-build/generic-owned-CMS-cache-run-proposal-4';OUT=ROOT/'.tirust-build/generic-owned-CMS-cache-run-independent-review-4'
def require(ok,message):
 if not ok:raise ValueError(message)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
SRC='fca076eeb821a457f13f971a3ae8bc0568022db7eb6622a7c645b08c527c9554'
require(digest(HERE/'source-index.json')==SRC,'changed source4 seal')
index=read(HERE/'source-index.json')['files']
for n,pin in index.items():require((HERE/n).stat().st_size==pin['bytes'] and digest(HERE/n)==pin['sha256'],'changed source4 payload '+n)
for n,h in [('terminal.json','83034229e1377efc0d2ec2c6ab400065b11a0c2bc778aa5421c8e2970ae7a719'),('result.json','ee95d391ecf7dc9cf2a7b28cf8ed349e0869c58da22d384632c33f4d2fc41325'),('cache-observations.json','82b80686d5206c94c5a7ead314aa63b9756e7588961d135eb6a94998b766128d')]:require(digest(BASE/n)==h,'changed closed RUN4 '+n)
terminal=read(BASE/'terminal.json');result=read(BASE/'result.json');admission=read(BASE/'admission.json');started=read(BASE/'started.json');limits=read(BASE/'limits.json');lock=read(BASE/'lock.json')
rootad=ROOT/'.tirust-build/generic-owned-CMS-cache-run-root-admission-4.json';require(digest(rootad)=='e93e2472136ad789d3c0256a561ef08ef12086db428383d003c7fa0e2c9b433e','root admission changed');rootad=read(rootad)
require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['events'] and not terminal['cleanup']['survivors'],'RUN4 not cleanly closed')
require(terminal['result_sha256']==digest(BASE/'result.json') and result['status']=='passed' and result['native_processes']==12,'wrong result')
require(admission['source_index_sha256']==SRC==result['RUN_source_index_sha256'],'RUN source join')
require(result['compiled_source_index_sha256']=='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93' and result['compiled_result_sha256']=='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137','compiled source/result join')
require(result['reviewed_BUILD_terminal_sha256']==admission['reviewed_build_sha256']=='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44','reviewed BUILD join')
require(terminal['cap_seconds']==1800 and terminal['cleanup_reserve_seconds']==60 and terminal['original_end_monotonic']==terminal['deadline_monotonic'] and terminal['original_end_monotonic']-terminal['original_start_monotonic']==1800,'absolute bound')
require(started['child_pid']==terminal['child_pid']==limits['pid']==limits['session']==limits['process_group'],'stage ownership/limit PID')
require(admission['command']==started['command']==terminal['command'],'stage argv join')
identity=admission['supervisor_identity'];require(identity['pid']>0 and identity['pid']==identity['process_group']==identity['session'],'recorded supervisor session')
expected_limits={'address_space_bytes':[17179869184]*2,'file_bytes':[268435456]*2,'core_bytes':[0,0]}
require(limits['actual']==expected_limits and admission['resource_limits']=={k:v[0] for k,v in expected_limits.items()},'resource bounds')
require(lock['path']==str(ROOT/'.tirust-build/numerical-tests.lock'),'shared lock path')
require(result['compiler_calls']==result['loader_queries']==0 and (BASE/'console.log').stat().st_size==0,'unadvertised tooling/stage console')
inputs=read(HERE/'input-pins.json');runtime=inputs['runtime'];policies=read(HERE/'runtime-policies.json')['policies'];plan=[]
for policy in ('cache0','cacheall'):
 for arm in ('plain','observed'):
  for cohort,ids in [('controls',[1,7,12]),('critical20',[20]),('critical21',[21])]:plan.append({'id':policy+'-'+arm+'-'+cohort,'lane':'candidate','arm':arm,'policy':policy,'cohort':cohort,'ids':ids,'measurement':'inputs/'+cohort+'.dat','expected_legacy_critical_failure_allowed':False})
keys=[r['id'] for r in plan]
require(set(result['worker_results'])==set(keys) and sorted(p.name for p in (BASE/'evidence').iterdir())==sorted(keys) and sorted(p.name for p in (BASE/'workers').iterdir())==sorted(keys),'exact twelve workers')
require(set(p.name for p in BASE.glob('progress-*.json'))=={'progress-'+r['id']+'-'+s+'.json' for r in plan for s in ('starting','closed')},'24 progress filenames')
validated={};input_bindings={};source_dict={};allmapfiles=0;allprotorecords=0
built=read(ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-work-1/build/result.json')
require(digest(ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-work-1/build/result.json')=='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137','accepted compiled result changed')
for i,r in enumerate(plan):
 name=r['id'];record=result['worker_results'][name];vp=BASE/('validated-'+name+'.json');require(record['validated_path']==str(vp) and digest(vp)==record['validated_sha256'],'validated row binding');v=read(vp);folder=BASE/'evidence'/name;worker=BASE/'workers'/name;case=worker/'SubProcesses/P0_epem_mupmum'
 require(v['request']==r and v['returncode']==0 and v['no_retry'] is True and v['orchestration_closed'] is True,'request/closed result')
 require(v['pid']==record['pid'] and v['raw_sha256']==record['raw_sha256']==digest(folder/'driver.raw64'),'actual RAW/PID binding')
 require(v['worker_result_path']==str(folder/'result.json') and v['worker_result_sha256']==digest(folder/'result.json'),'worker result binding')
 full=read(folder/'result.json');require(all(v[k]==x for k,x in full.items()),'validated wrapper/core mismatch')
 require(digest(folder/'stderr.txt')==v['stderr_sha256'],'diagnostic binding')
 require(v['protocol']==read(folder/'protocol.json'),'transcript binding');allprotorecords+=len(v['protocol'])
 expected_labels=['ready','learned',*['done-'+str(j) for j in range(1,len(r['ids'])+1)]]
 require(set(v['maps'])==set(expected_labels),'map cardinality')
 for label in expected_labels:
  m=read(folder/('maps-'+label+'.json'));require(m==v['maps'][label],'retained map binding');allmapfiles+=1
  paths=set()
  for line in m['raw'].splitlines():
   parts=line.split(None,5)
   if len(parts)==6 and parts[5].startswith('/'):
    require(not parts[5].endswith(' (deleted)'),'deleted raw map');paths.add(str(Path(parts[5]).resolve()))
  require(paths==set(m['ELF'])|set(m['data']),'raw map paths/claimed objects differ')
  require(m['identity']['parent_pid']==terminal['child_pid'],'native worker left admitted stage')
 require(v['maps']['ready']['started_identity']==read(folder/'started.json')['identity'],'worker start/lifetime join')
 expectedelf=built['variants'][r['arm']]['sha256'];require(v['executable_sha256']==expectedelf and v['executable_path']==str(case/'check') and digest(case/'check')==expectedelf,'private ELF exact copy')
 command=read(folder/'command.json');require(command['argv']==[str(case/'check'),str(case/'training.dat'),str(case/'measurement.dat'),str(case/'native-protocol.fifo'),str(folder/'driver.raw64')] and command['cwd']==str(case) and command['request']==r and command['source_index_sha256']==SRC and command['ELF_sha256']==expectedelf and command['new_session'] is False,'native launch argv/provenance')
 require(not (case/'native-protocol.fifo').exists(),'FIFO retained after closed worker')
 bindings={}
 for p,target in [(case/'training.dat',HERE/'inputs/training.dat'),(case/'measurement.dat',HERE/r['measurement'])]:require(digest(p)==digest(target),'frozen point copy differs');bindings[str(p.relative_to(worker))]=digest(p)
 for basename,target in [('MadLoopParams.dat',HERE/policies[r['policy']]['runtime_card']),('param_card.dat',HERE/'cards/param_card.dat')]:
  paths=list(worker.rglob(basename));require(paths,'missing runtime card')
  for p in paths:require(p.resolve().is_relative_to(worker.resolve()) and digest(p)==digest(target),'runtime card escape/delta');bindings[str(p.relative_to(worker))]=digest(p)
 for rel,pin in inputs['resources'].items():
  for p in (worker/rel,case/Path(rel).name):require(p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'],'static resource copy differs');bindings[str(p.relative_to(worker))]=pin['sha256']
 require(command['runtime_card_sha256']==policies[r['policy']]['runtime_sha256'],'runtime card command pin')
 input_bindings[name]=bindings;validated[name]=v
 for state,complete in [('starting',keys[:i]),('closed',keys[:i+1])]:require(read(BASE/('progress-'+name+'-'+state+'.json'))=={'request':name,'state':state,'completed':complete,'compiled_source_index_sha256':result['compiled_source_index_sha256'],'RUN_source_index_sha256':SRC},'progress content/order')
 expected_files={'command.json','driver.raw64','learning-analysis.json','protocol.json','result.json','started.json','stderr.txt','maps-ready.json','maps-learned.json'}|{'measurement-'+str(j)+'.json' for j in range(1,len(r['ids'])+1)}|{'maps-done-'+str(j)+'.json' for j in range(1,len(r['ids'])+1)}
 if r['policy']=='cache0' and r['arm']=='plain':expected_files|={'closed-cache0-reference-prefix-'+str(j)+'.json' for j in range(len(r['ids'])+1)}
 require({p.name for p in folder.iterdir() if p.is_file()}==expected_files and not any(p.is_symlink() for p in folder.iterdir()),'unexpected evidence inventory')
require(len({v['pid'] for v in validated.values()})==12,'reused PID')
protocol_source=(HERE/'protocol_parity.py').read_text();write_handles={name:(OUT/name).open('x') for name in ('runtime-checks.json','runtime-input-bindings.json')};forbidden=[]
def guard(event,args):
 if event=='open' or event.startswith(('subprocess.','ctypes.','socket.','os.system','os.exec','os.fork','os.posix_spawn','os.scandir','os.listdir','os.remove','os.rename','os.mkdir','os.rmdir')):forbidden.append(event);raise RuntimeError('forbidden pure runtime gate '+event)
sys.addaudithook(guard)
ns={'__name__':'authenticated_source4_protocol'};exec(compile(protocol_source,'<authenticated-source4-protocol>','exec'),ns);pair_results={}
for policy in ('cache0','cacheall'):
 for cohort in ('controls','critical20','critical21'):
  key=policy+'-observed-'+cohort;p=validated[policy+'-plain-'+cohort];o=validated[key];replay=ns['own_runtime_parity'](p,o,runtime=runtime);require(replay==result['own_plain_observed_parity'][key]['protocol_maps'],'stored runtime parity differs');pair_results[key]=replay
proof={'schema':'RUN4-independent-runtime-gates-v1','passed':True,'RUN_source_sha256':SRC,'worker_count':12,'native_protocol_records':allprotorecords,'retained_maps':allmapfiles,'all_raw_map_path_sets_match_recorded_objects':True,'actual_private_ELF_hashes_match_compiled_arms':True,'runtime_input_copies_checked':sum(len(v) for v in input_bindings.values()),'actual_private_cards_streams_resources_match':True,'six_actual_runtime_parity_helpers_reproduced':pair_results,'limits':expected_limits,'CPU':12,'CPU_reserved':False,'no_owned_survivors':True,'absolute_stage_bound_seconds':1800,'cleanup_reserve_seconds':60,'reply_bound_seconds':180,'raw_protocol_tail_empty_asserted_by_verified_closed_worker':True,'stage_console_empty':True,'forbidden_API_attempts':forbidden,'new_native_or_compiler_loader_queries':0,'old_BUILD_reaudit':False,'independent_physical_truth':False,'performance_qualified':False}
json.dump(proof,write_handles['runtime-checks.json'],indent=2,sort_keys=True);write_handles['runtime-checks.json'].write('\n');write_handles['runtime-checks.json'].close()
json.dump({'worker_inputs':input_bindings,'native_binaries_not_packaged':True},write_handles['runtime-input-bindings.json'],indent=2,sort_keys=True);write_handles['runtime-input-bindings.json'].write('\n');write_handles['runtime-input-bindings.json'].close();print(json.dumps({'passed':True,'workers':12,'maps':allmapfiles,'protocol_records':allprotorecords,'inputs':sum(len(v) for v in input_bindings.values()),'forbidden_API_attempts':len(forbidden)}))
