"""Closed cache BUILD file-only audit. Never imports operational controllers."""
from pathlib import Path
from collections import Counter, deque
import ast, hashlib, json, os, re, shlex, struct, sys, types
ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
PACK=ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-proposal-1'
BUILD=ROOT/'.tirust-build/generic-owned-CMS-cache-qualification-work-1/build'
OUT=Path(__file__).resolve().parent
SUB=Path('SubProcesses/P0_epem_mupmum')
SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
TERMINAL='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44'
RESULT='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137'
REVIEW='595e59d42a374be3393fa4c9ee61e94fbb924efb30682eefe66595a4a082e551'
ADMISSION='15d2cc90e39ed8dec89761a6f5a219824d6587304a7a849ed803e7a4f74204c1'
PRIVATE=['invariant_bounds.f90','owned_snapshots.f90','owned_exact_geometry.f90','owned_certificate.f90','owned_math.f90','owned_route_data.f90','point_match.f90']
CHANGED={'loop_matrix.f','mp_compute_loop_coefs.f','helas_calls_ampb_1.f','mp_helas_calls_ampb_1.f','loop_CT_calls_1.f','CT_interface.f','TIR_interface.f','TIRUST_interface.f'}
CHECKS=[]; HASHES={}; RAW={}; EFFECTS=[]; GUARDED=False
def require(ok,message):
    if not ok:raise ValueError(message)
def check(ok,message):require(ok,message);CHECKS.append(message)
def sha(p):
    p=Path(p);key=str(p.resolve())
    if key not in HASHES:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
        HASHES[key]=h.hexdigest()
    return HASHES[key]
def ident(p):
    require(Path(p).is_file() and not Path(p).is_symlink(),'nonregular/aliased exact input: '+str(p))
    return {'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def read(p):return json.loads(Path(p).read_text())
def pin(p,wanted):require(sha(p)==wanted,'exact pin changed: '+str(p))
def guard(event,args):
    if not GUARDED:return
    forbidden=event.startswith(('subprocess.','ctypes.','socket.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.kill','os.killpg','os.posix_spawn','fcntl.flock','resource.setrlimit','os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.symlink','os.link','os.truncate')
    if event=='open':
        mode,flags=args[1:3]
        forbidden=forbidden or isinstance(mode,str) and any(x in mode for x in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if forbidden:EFFECTS.append(event);raise RuntimeError('file-only review denied '+event)
sys.addaudithook(guard)
def pure_functions(path,names,namespace):
    tree=ast.parse(Path(path).read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    require({n.name for n in nodes}==set(names),'pure function extraction mismatch')
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
def elf_symbols(blob):
    require(blob[:7]==b'\x7fELF\x02\x01\x01','ELF class')
    h=struct.unpack_from('<HHIQQQIHHHHHH',blob,16);require(h[1]==62 and h[10]==64,'ELF sections')
    sections=[struct.unpack_from('<IIQQQQIIQQ',blob,h[5]+i*h[10]) for i in range(h[11])];names=[]
    for sec in sections:
        if sec[1]!=2:continue
        strings=sections[sec[6]];table=blob[strings[4]:strings[4]+strings[5]];require(sec[9]==24,'ELF symbol size')
        for off in range(sec[4],sec[4]+sec[5],24):
            name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',blob,off)
            if index and name:
                end=table.find(b'\0',name);require(end>=name,'ELF symbol name');names.append(table[name:end].decode())
    return names
def main():
    global GUARDED
    GUARDED=True
    pin(PACK/'source-index.json',SOURCE);index=read(PACK/'source-index.json')
    for name,wanted in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and not (PACK/name).is_symlink(),'unsafe packet path')
        require(ident(PACK/name)==wanted,'source payload changed: '+name)
    check(len(index['files'])==50,'exact50 frozen BUILD source payloads')
    pin(ROOT/'.tirust-build/generic-owned-CMS-cache-source-independent-review-1/receipt.json',REVIEW)
    pin(ROOT/'.tirust-build/generic-owned-CMS-cache-root-admission-1.json',ADMISSION)
    pin(BUILD/'terminal.json',TERMINAL);pin(BUILD/'result.json',RESULT)
    terminal,result=read(BUILD/'terminal.json'),read(BUILD/'result.json');ip=read(PACK/'input-pins.json')
    admission=read(ROOT/'.tirust-build/generic-owned-CMS-cache-root-admission-1.json')
    require(admission['source_index_sha256']==SOURCE and admission['independent_source_review_sha256']==REVIEW and not admission['RUN_admitted'],'wrong source/root admission')
    require(terminal['status']==result['status']=='passed' and terminal['returncode']==0 and terminal['result_sha256']==RESULT and result['source_index_sha256']==SOURCE,'closed BUILD identity failed')
    require(terminal['cap_seconds']==1800 and terminal['cleanup_reserve_seconds']==60 and terminal['original_end_monotonic']==terminal['deadline_monotonic']==terminal['original_start_monotonic']+1800,'absolute budget changed')
    require(not terminal['cleanup']['events'] and not terminal['cleanup']['survivors'] and (BUILD/'console.log').stat().st_size==0,'cleanup/console failure')
    start,admit,limits,lock=(read(BUILD/n) for n in ('started.json','admission.json','limits.json','lock.json'))
    for k,v in start.items():
        if k!='status':require(terminal[k]==v,'started/terminal mismatch')
    require(admit['command']==terminal['command'] and admit['phase']=='build' and admit['source_index_sha256']==SOURCE and admit['reviewed_build_sha256'] is None and admit['deadline_monotonic']==terminal['deadline_monotonic'],'command admission changed')
    require(terminal['command']==['/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset','-c','12','/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3','-B','-I','.tirust-build/generic-owned-CMS-cache-qualification-proposal-1/controller.py','--child','--phase','build','--source',SOURCE],'exact BUILD-only argv')
    require(admit['resource_limits']=={'address_space_bytes':17179869184,'file_bytes':268435456,'core_bytes':0} and limits['actual']=={k:[v,v] for k,v in admit['resource_limits'].items()},'actual resource limits')
    require(limits['pid']==limits['process_group']==limits['session']==terminal['child_pid'] and lock['path']==str(ROOT/'.tirust-build/numerical-tests.lock'),'owned session/shared mutex')
    check(True,'exact source/admission/closed result, absolute1800/60 cap, resource/session/mutex and clean shutdown')
    def pinned_input(path):
        key=str(path.relative_to(ROOT));require(key in ip['files'] and ident(path)==ip['files'][key],'accepted parent metadata changed: '+key)
    original_path=ROOT/ip['original_receipt'];pinned_input(original_path);original=read(original_path)
    refs={}
    for lane,folder in (('plain','generic-owned-CMS-plain-build-work-2'),('observed','generic-owned-CMS-observer-qualification-work-1')):
        parent=ROOT/'.tirust-build'/folder/'build'
        for n in ('terminal.json','result.json'):pinned_input(parent/n)
        refs[lane]=read(parent/'result.json')['variants']['candidate']
        for row in read(parent/'result.json')['variants'].values():pin(Path(row['path']),row['sha256'])
    check(True,'protected original recipes and both accepted parent BUILD metadata/four historical ELFs unchanged; no blanket parent object rehash')
    helper=ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2'
    helper_index=read(helper/'source-index.json')
    pin(helper/'source-index.json','fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb')
    for name in ('cms_build.py','cms_runtime.py'):require(ident(helper/name)==helper_index['files'][name],'pure helper changed')
    recipe_ns={'Path':Path,'shlex':shlex,'require':require};pure_functions(helper/'cms_build.py',('compile_recipes','compile_argv'),recipe_ns)
    recipes=recipe_ns['compile_recipes'](original);fc=recipes['CT_interface.f'][0];flags=recipes['CT_interface.f'][1:recipes['CT_interface.f'].index('-c')]
    parser_path=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/unit_runtime.py';pin(parser_path,'4552d6b3bcd8d37a11f2eba81f505e71769010314246c4382e20d15fd441b0b5')
    parser_ns={'Path':Path,'hashlib':hashlib,'struct':struct,'require':require};pure_functions(parser_path,('describe',),parser_ns)
    runtime_ns={'Path':Path,'deque':deque,'require':require,'digest':sha,'load_parser':lambda:types.SimpleNamespace(describe=parser_ns['describe'])}
    pure_functions(helper/'cms_runtime.py',('absolute_paths','derive'),runtime_ns)
    composition=read(PACK/'composition-receipt.json');route=read(PACK/'cache-fortran-diff.json')
    observed_parent=ROOT/'.tirust-build/generic-owned-CMS-observer-qualification-proposal-2'
    pin(observed_parent/'source-index.json','1a1cebf262c5fe7767a1bf6db54591a3baae9d72326370524dc918a41fd69e5d')
    oldcomp=read(observed_parent/'composition-receipt.json');observed_externals=[n.lower()+'_' for n in oldcomp['lanes']['candidate']['defined_observed_externals']]
    require(result['emission_composition_sha256']==sha(PACK/'composition-receipt.json'),'emission changed')
    audit_path=ROOT/'.tirust-build/eb3-cache-source-artifact-audit-1/receipt.json'
    pin(audit_path,'a94d65a6b62cdeab9ea92d09a5b80434736ddf65570e24e7e299ca71eb2282d8')
    require(result['eb3_cache_source_provenance']=={'artifact_sha256':'eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9','claim':'recorded source/artifact build provenance, not clean rebuild/compiler attestation','receipt_sha256':sha(audit_path)},'cache source/artifact claim changed')
    totals=Counter();summaries={};raw_command_inventory={};alias_cache={};source_count=0;object_count=0
    for lane in ('plain','observed'):
        row=result['variants'][lane];output=BUILD/lane;case=output/SUB;logs=case/'owned-build-commands';reference=refs[lane]
        require(row['path']==str(case/'check') and not (case/'check').is_symlink(),'private output/ELF path')
        expected_sha={'plain':'ff68f3c3d744cc22a2b1ff9d47cd52a5b035bb5ad2285fad95fc6a5bd00f64c9','observed':'b07f541bc870c7d35490c0ded59e6f9112b2e6a175d814ab677f60b9222069ac'}[lane]
        require(row['sha256']==sha(case/'check')==expected_sha,'current ELF changed')
        overlays=route['lanes']['plain']['outputs'] if lane=='plain' else {n:composition['outputs']['emittedsrc/observed/'+n] for n in ('CT_interface.f','TIRUST_interface.f','observer.f90')}
        expected_sources=dict(reference['source_inventory']);expected_sources.update({str(SUB/n):v for n,v in overlays.items()})
        require(row['source_inventory']==expected_sources,'overlay-only source inventory mismatch')
        for name,wanted in row['source_inventory'].items():require(ident(output/name)==wanted,'current source/include changed: '+name);source_count+=1
        selected=['CT_interface.f','TIRUST_interface.f'] if lane=='plain' else sorted(CHANGED|{'check_sa.f'})
        modules=(['observer.f90'] if lane=='observed' else [])+PRIVATE+(['observed_math.f90'] if lane=='observed' else [])
        require(row['recompiled_units']==selected and row['module_compile_order']==modules,'compile closure differs')
        rebuilt={str(SUB/Path(n).with_suffix('.o')) for n in selected+modules}
        preserved={n:v for n,v in reference['objects'].items() if n not in rebuilt}
        require(row['preserved_authenticated_objects']==preserved,'reused object metadata differs')
        require(set(row['objects'])==set(reference['objects']),'object inventory differs')
        for name,wanted in row['objects'].items():
            require(ident(output/name)==wanted,'current object changed: '+name);object_count+=1
            if name in preserved:require(wanted==preserved[name],'reused object changed')
        require(row['regenerated_private_objects_bit_identical']=={str(SUB/Path(n).with_suffix('.o')):reference['objects'][str(SUB/Path(n).with_suffix('.o'))] for n in PRIVATE},'private regenerated object identity differs')
        expected_mods={}
        for name in modules:
            names=re.findall(r'^\s*module\s+([A-Za-z][A-Za-z0-9_]*)\s*$',(case/name).read_text(),re.M|re.I);require(len(names)==1,'private module declaration')
            expected_mods[names[0].lower()+'.mod']=ident(case/(names[0].lower()+'.mod'))
        require(expected_mods==row['module_files'],'fresh module outputs differ')
        require({q.name for q in case.glob('*.mod')}==set(expected_mods)|{'mpmodule.mod','ml5_0_polynomial_constants.mod'},'unbound local module shadow')
        if lane=='observed':require(row['unchanged_observed_math_object_bit_identical'] is True and row['objects'][str(SUB/'observed_math.o')]==reference['objects'][str(SUB/'observed_math.o')],'observed_math object changed')
        require((case/'tir_cache_size.inc').read_bytes()==b'      PARAMETER(TIR_CACHE_SIZE=0)\n','Fortran group cache changed')
        for name,wanted in {**ip['libraries'],**ip['module_inputs']}.items():require(ident(output/name)==wanted,'canonical library/module changed')
        for alias,wanted in ip['shared_aliases'].items():
            q=output/alias;require(q.is_symlink() and str(q.readlink())==wanted['canonical_target'],'shared alias target differs')
            target=q.resolve();leaves={n.name:n for n in target.iterdir()};require(set(leaves)==set(wanted['exact_regular_leaf_inventory']),'shared alias inventory differs')
            for n,pinvalue in wanted['exact_regular_leaf_inventory'].items():
                require(not leaves[n].is_symlink() and leaves[n].is_file(),'shared alias nonregular leaf')
                if str(leaves[n]) not in alias_cache:alias_cache[str(leaves[n])]=ident(leaves[n])
                require(alias_cache[str(leaves[n])]==pinvalue,'shared alias leaf changed')
        require(row['immutable_shared_aliases']==ip['shared_aliases'],'retained alias closure differs')
        commands={};command_terms={}
        for path in sorted(logs.glob('*.command.json')):
            stem=path.name[:-len('.command.json')];cmd=read(path);termfile=logs/(stem+'.terminal.json');out=logs/(stem+'.stdout.txt');term=read(termfile)
            require(term['returncode']==0 and term['stdout_sha256']==sha(out),'command failed/raw stdout changed')
            require(cmd['cwd']==str(case) and cmd['controller_pid']==cmd['session']==cmd['process_group']==terminal['child_pid'],'command ownership changed')
            for f in (path,termfile,out):raw_command_inventory[str(f.relative_to(BUILD))]=ident(f)
            category='compile' if stem.startswith('compile-') else 'module' if stem.startswith('module-') else 'prelink_query' if '-prelink-query-' in stem else 'runtime_list' if stem==lane+'-actual-pt-interp-runtime' else stem
            require(category in ('compile','module','prelink_query','runtime_list','make-link-info','link','symbols'),'unexpected command type')
            totals[category]+=1;commands[stem]=cmd;command_terms[stem]=term
        require(len(commands)==(64 if lane=='plain' else 73) and {f.name for f in logs.iterdir()}=={n+s for n in commands for s in ('.command.json','.terminal.json','.stdout.txt')},'command triple inventory differs')
        for name in modules:
            argv=recipe_ns['compile_argv'](recipes['CT_interface.f'],name,str(Path(name).with_suffix('.o')))
            require(commands['module-'+Path(name).stem]['argv']==argv,'module recipe differs')
        for name in selected:require(commands['compile-'+Path(name).stem]['argv']==recipes[name],'original process compile recipe differs')
        module_ends=[command_terms['module-'+Path(n).stem]['finished_utc'] for n in modules]
        require(all(module_ends[i]<=commands['module-'+Path(modules[i+1]).stem]['started_utc'] for i in range(len(modules)-1)),'module compile order not actual')
        require(all(module_ends[-1]<=commands['compile-'+Path(n).stem]['started_utc'] for n in selected),'process compiled before modules complete')
        all_units=modules+selected;declared={}
        for n in modules:
            for module in re.findall(r'^\s*module\s+([A-Za-z][A-Za-z0-9_]*)\s*$',(case/n).read_text(),re.I|re.M):declared[module.lower()]=n
        edges=[]
        for n in all_units:
            text=(case/n).read_text()
            for used in re.findall(r'^\s*(?:\d+\s+)?use\s+(?:,\s*non_intrinsic\s*::\s*)?([A-Za-z][A-Za-z0-9_]*)',text,re.I|re.M):
                if used.lower() in declared:
                    provider=declared[used.lower()];require(all_units.index(provider)<all_units.index(n),'module USER before provider');edges.append([provider,n,used.lower()])
        if lane=='observed':
            direct=[]
            for n in row['source_inventory']:
                if str(Path(n).parent)==str(SUB) and Path(n).suffix.lower() in ('.f','.f90') and re.search(r'^\s*use\s+ML5_0_CMS_OBSERVER\b',(output/n).read_text(),re.I|re.M):direct.append(Path(n).name)
            require(set(direct)<=(set(all_units)-{'observer.f90'}),'unrecompiled observer user')
        info={line.split()[0]:shlex.split(line)[1:] for line in (logs/'make-link-info.stdout.txt').read_text().splitlines() if line.strip()}
        require(set(info)=={'FC','FFLAGS','LINKLIBS','LDFLAGS'} and info['FC']==[fc] and info['FFLAGS']==flags and info['LDFLAGS']==ip['original_LDFLAGS'],'original effective scientific flags differ')
        link=[fc,*flags,'-Wl,-Map,owned-link.map,--cref','-o','check',*[Path(n).name for n in original['objects']],*row['extra_objects'],*info['LINKLIBS']]
        require(row['extra_objects']==reference['extra_objects'] and link==row['link_command']==commands['link']['argv'],'actual original object/link order differs')
        require(commands['make-link-info']['argv']==[read(PACK/'toolchain-pins.json')['required_tools']['make']['path'],'-s','--no-print-directory','-f','owned-info.mk','owned-info'],'make info is not metadata-only')
        pre=read(case/'owned-prelink.json');static=read(case/'owned-static-runtime.json')
        for n,k in (('owned-prelink.json','prelink_sha256'),('owned-link.map','link_map_sha256'),('owned-static-runtime.json','static_runtime_sha256')):pin(case/n,row[k])
        require(pre['completed_before_link'] and pre['command']==link and pre['cwd']==str(case) and pre['explicit_CMS_runtime_before_link']==ip['runtime'],'prelink identity differs')
        for q in pre['queries']:
            name=lane+'-'+q['label'];require(commands[name]['argv']==q['argv'],'prelink query argv differs')
            require(command_terms[name]['finished_utc']<=commands['link']['started_utc'],'link preceded required query')
        require(len(pre['queries'])==51,'query closure differs')
        rawloads=re.findall(r'^LOAD\s+(.+)$',(case/'owned-link.map').read_text(),re.M)
        loads={str((case/n).resolve()):pre['bound'][str((case/n).resolve())] for n in rawloads}
        require(loads==row['actual_link_loads'] and len(loads)==(60 if lane=='plain' else 62),'actual LOAD/prebound closure differs')
        for path,wanted in pre['bound'].items():pin(path,wanted)
        runtime=row['runtime'];require(runtime['files']==ip['runtime'] and len(runtime['files'])==15,'15-provider runtime differs')
        derived=runtime_ns['derive'](case/'check',pre,ip['runtime'],':'.join(static['controlled_LD_LIBRARY_PATH']))
        require(derived==static,'independent static ELF closure replay differs')
        require(parser_ns['describe'](case/'check')['interpreter']==runtime['loader']==ip['interpreter'] and pre['bound'][runtime['loader']]==runtime['loader_sha256']==runtime['files'][runtime['loader']],'PT_INTERP not prebound')
        require(commands[lane+'-actual-pt-interp-runtime']['argv']==[runtime['loader'],'--list',str(case/'check')] and (logs/(lane+'-actual-pt-interp-runtime.stdout.txt')).read_text()==runtime['listing'],'retained loader-list invocation differs')
        listed=[]
        for line in runtime['listing'].splitlines():
            if 'linux-vdso.so.1' in line:continue
            match=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line.strip());require(match is not None,'loader-list parse failed');listed.append(str(Path(match[1]).resolve()))
        require(set(listed)|{runtime['loader']}==set(ip['runtime']),'actual loader provider set differs')
        symbols=elf_symbols((case/'check').read_bytes());nm=[line.split()[-1] for line in (logs/'symbols.stdout.txt').read_text().splitlines() if len(line.split())>=3]
        require(commands['symbols']['argv']==[read(PACK/'toolchain-pins.json')['required_tools']['nm']['path'],'--defined-only','check'],'symbol-only argv differs')
        for names in (symbols,nm):
            require(all(names.count(n)==1 for n in ip['candidate_symbols']),'candidate symbol ownership differs')
            require({n:names.count(n) for n in names if '__mtirust_MOD_' in n}=={n:1 for n in ip['mtirust_symbols']},'MTIRUST symbol ownership differs')
            require(all(names.count(n)==1 for n in observed_externals) if lane=='observed' else not any(n in names for n in observed_externals),'plain/observed symbol ownership differs')
        summaries[lane]={'ELF_sha256':row['sha256'],'raw_command_triples':len(commands),'process_compiles':len(selected),'module_compiles':len(modules),'module_files':len(row['module_files']),'USE_provider_edges':edges,'reused_objects':len(preserved),'all_current_objects':len(row['objects']),'all_current_sources':len(row['source_inventory']),'actual_LOADs':len(loads),'prebound_files':len(pre['bound']),'providers':15,'static_objects':len(static['objects']),'static_resolution_edges':len(static['resolutions']),'MTIRUST_symbols':len(ip['mtirust_symbols']),'candidate_symbols':len(ip['candidate_symbols']),'observed_externals':len(observed_externals) if lane=='observed' else 0}
        check(True,lane+': exact overlay/object/module/recipe/USE/link/prebind/runtime/ELF/symbol closure')
    require(totals==Counter({'compile':11,'module':16,'prelink_query':102,'runtime_list':2,'make-link-info':2,'link':2,'symbols':2}),'all137 command scope differs')
    require(result['native_main_calls']==result['model_calls']==result['reducer_calls']==0 and all(result[k] is False for k in ('runtime_cache_behavior_qualified','plain_observer_parity_qualified','full_caller_qualified','scientific_dispatch_enabled','performance_qualified')),'scientific execution/qualification scope changed')
    remaining=[]
    for row in terminal['cleanup']['observed_owned_processes']:
        path=Path('/proc')/str(row['pid'])/'stat'
        try:fields=path.read_text().rsplit(') ',1)[1].split()
        except FileNotFoundError:continue
        if int(fields[2])==row['process_group'] and int(fields[3])==row['session'] and int(fields[19])==row['start_time_ticks']:remaining.append(row['pid'])
    check(not remaining and not EFFECTS,'no surviving owned process identity or forbidden review effect')
    GUARDED=False
    summary={'status':'passed-closed-BUILD-only','source_index_sha256':SOURCE,'source_review_sha256':REVIEW,'root_admission_sha256':ADMISSION,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'checks':CHECKS,'variants':summaries,'command_counts':dict(totals),'raw_command_files':len(raw_command_inventory),'current_sources_hashed':source_count,'current_objects_hashed':object_count,'shared_alias_unique_leaves_hashed':len(alias_cache),'unique_files_hashed':len(HASHES),'new_compiler_loader_make_library_queries':0,'native_scientific_calls':0,'public_Git_effects':False,'forbidden_review_effects':EFFECTS,'matching_owned_identities_remaining':remaining,'scope':'Closed private cache BUILD and ABI/runtime closure only. No cache behavior, diagnostic API preservation, plain/observer amplitude parity, full caller, independent numerical accuracy, performance or source promotion qualification. Future RUN requires separate source and admission.'}
    target=OUT/('checks-optimized.json' if sys.flags.optimize else 'checks.json');target.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    inv=OUT/('raw-command-inventory-optimized.json' if sys.flags.optimize else 'raw-command-inventory.json');inv.write_text(json.dumps(raw_command_inventory,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':summary['status'],'checks':len(CHECKS),'command_triples':sum(totals.values()),'raw_files':len(raw_command_inventory),'source_files':source_count,'objects':object_count,'checks_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
