from pathlib import Path
from collections import Counter
import hashlib,json,struct,sys,types

SOURCE=Path('.tirust-build/generic-owned-CMS-cache-run-proposal-4')
BASE=Path('.tirust-build/generic-owned-CMS-cache-run-work-3/run')
COMPILED=Path('.tirust-build/generic-owned-CMS-cache-qualification-proposal-1')
BUILD=Path('.tirust-build/generic-owned-CMS-cache-qualification-work-1/build')
HIST=Path('.tirust-build/generic-owned-CMS-plain-run-work-4/run')
EXPECTED='fca076eeb821a457f13f971a3ae8bc0568022db7eb6622a7c645b08c527c9554'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
need(digest(SOURCE/'source-index.json')==EXPECTED,'changed source3')
index=read(SOURCE/'source-index.json');modules={};used={}
for name in ('normal_run_analysis','observer_analysis','cache_comparison','accuracy_policy','run_plan'):
    p=SOURCE/(name+'.py');data=p.read_bytes();pin=index['files'][name+'.py'];need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'changed pure module');used[name+'.py']=pin
    m=types.ModuleType(name);exec(compile(data,str(p),'exec'),m.__dict__);modules[name]=m
for name in ('input-pins.json','runtime-policies.json','inputs/training.dat','inputs/controls.dat','inputs/critical20.dat','inputs/critical21.dat'):
    p=SOURCE/name;pin=index['files'][name];need(p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'],'changed pure input');used[name]=pin
inputs=read(SOURCE/'input-pins.json');policies=read(SOURCE/'runtime-policies.json');streams={name:(SOURCE/('inputs/'+name+'.dat')).read_text() for name in ('training','controls','critical20','critical21')}
need(digest(BASE/'terminal.json')=='02b53e803756f53e356326068895145b29be640696bc9dbbc70bfb42b9d87cdc','changed failed terminal')
need(digest(BASE/'console.log')=='a899c21a4ef955bd03e56d0255fa9b09700e24471c1397608e5fe58dc3bde3f0','changed failure console')
terminal=read(BASE/'terminal.json')
need(digest(COMPILED/'source-index.json')=='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93','changed compiled source index')
need(digest(BUILD/'result.json')=='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137','changed closed BUILD metadata')
built=read(BUILD/'result.json');dispatch=Path(built['variants']['observed']['path']).parent/'CT_interface.f';dispatch_bytes=dispatch.read_bytes();dispatch_pin=built['variants']['observed']['source_inventory']['SubProcesses/P0_epem_mupmum/CT_interface.f']
need(len(dispatch_bytes)==dispatch_pin['bytes'] and hashlib.sha256(dispatch_bytes).hexdigest()==dispatch_pin['sha256'],'actual compiled dispatch changed')
need(dispatch_pin==read(COMPILED/'source-index.json')['files']['emittedsrc/observed/CT_interface.f'],'dispatch not joined to compiled6417 overlay')
need(digest(HIST/'result.json')=='b0a3eb3596a8c183775d37a1a791a2aee3e3ca671958f8e2884776d79cb042eb','changed historical normal result')
historical=read(HIST/'result.json');references={}
for cohort in ('controls','critical20','critical21'):
    row=historical['requests']['candidate-'+cohort];p=HIST/'evidence'/('candidate-'+cohort)/'driver.raw64';need(digest(p)==row['raw_sha256'],'changed historical raw');references[cohort]={'raw':p.read_text(),'raw_sha256':row['raw_sha256']}
pins={
'cache0-plain-controls':('edcf146f7bb825dbb67452a4fb0d425ebb45b12557acaea489e4d2e73c6a153f','1750f4015b9666c65686336c165e9a0c1d91823a0997f80cfa464907f8bdb2d3','c1b268a5a0160a6606b00718d6d62624051831c01e081d489e1e6699efbbee87'),
'cache0-plain-critical20':('a0235c49685b840e1354b6d87488d969f02f71f2fbc1eea04f8ce23cffd1fc3b','1a232f2e737066ee6df54714f5fd8a90fb089c3285599438ccf73cb8ca92886e','394111e9e7dc8341f0440fc7293a45a029118827124d0242f0bee54fbc3bc153'),
'cache0-plain-critical21':('95429e5112ddc151dc38c8858c17b44179ede6bef434c069cb4d89516c4ed157','ac134975725a1bcf6c69e4bf0c522d5a63dd40b55c50b27a220b3acac34a06b9','35ece0aceab90ffe64b903b04fe3aaab4c7d083322cf9681142bcda290526c81'),
'cache0-observed-controls':('9f4ac63ee7d0a0caef68f26a07e79e27c7a3f25bc433ba3fef65c45cf9fb669a','8988377a13f6de49dbe2af22ede2852cd4e3431df4f863616649cd660b44fdde',None)}
records={};evidence_inventory={}
for key,(result_sha,raw_sha,validated_sha) in pins.items():
    folder=BASE/'evidence'/key;need(digest(folder/'result.json')==result_sha and digest(folder/'driver.raw64')==raw_sha,'changed closed worker')
    validation=BASE/('validated-'+key+'.json')
    need((digest(validation)==validated_sha) if validated_sha else not validation.exists(),'validated scope mismatch')
    records[key]={'worker':read(folder/'result.json'),'raw':(folder/'driver.raw64').read_text(),'validated':read(validation) if validated_sha else None,'protocol':read(folder/'protocol.json'),'maps':{p.name:read(p) for p in folder.glob('maps-*.json')},'started':read(folder/'started.json'),'stderr':(folder/'stderr.txt').read_bytes()}
    evidence_inventory[key]={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in folder.iterdir() if p.is_file()}
    if validated_sha:evidence_inventory[key]['_validated']={'bytes':validation.stat().st_size,'sha256':validated_sha}
scope={'attempted':sorted(p.name for p in (BASE/'evidence').iterdir() if p.is_dir()),'validated':sorted(p.name[len('validated-'):-len('.json')] for p in BASE.glob('validated-*.json')),'overall_result_exists':(BASE/'result.json').exists(),'own_runtime_parity_receipt_exists':(BASE/'own-parity-cache0-observed-controls.json').exists()}
active=[False];attempts=[]
def guard(event,args):
    if active[0] and (event=='open' or event.startswith(('subprocess.','ctypes.','socket.')) or event in ('os.listdir','os.scandir','os.system','os.exec','os.fork','os.posix_spawn','pty.spawn','os.mkdir','os.remove','os.rename','os.rmdir','os.symlink','os.chmod','os.truncate')):
        attempts.append(event);raise RuntimeError('forbidden closed worker replay effect '+event)
sys.addaudithook(guard)
normal=modules['normal_run_analysis'];observer=modules['observer_analysis'];compare=modules['cache_comparison'];accuracy=modules['accuracy_policy'];plan=modules['run_plan']
def point_words(*texts):
    found={}
    for text in texts:
        lines=text.splitlines();n=int(lines[0]);need(n>0 and len(lines)==1+5*n,'point stream shape')
        for i in range(n):
            point=int(lines[1+5*i]);words=[]
            for line in lines[2+5*i:6+5*i]:
                fields=line.split();need(len(fields)==4,'point component shape');words.append([struct.pack('>d',float(x.replace('D','E').replace('d','e'))).hex().upper() for x in fields])
            need(point not in found or found[point]==words,'inconsistent duplicate point');found[point]=words
    return found
summaries={};parsed={};observer_summary=None
try:
    active[0]=True
    requests={r['id']:r for r in plan.requests()};need(len(requests)==12,'declared schedule changed')
    for key,data in records.items():
        worker=data['worker'];request=requests[key];ids=request['ids'];cohort=request['cohort'];points=point_words(streams['training'],streams[cohort]);pid=worker['pid']
        need(worker['request']==request and worker['returncode']==0 and worker['orchestration_closed'] is True and worker['no_retry'] is True,'worker request/exit incomplete')
        if request['arm']=='plain':
            result=normal.parse_raw(data['raw'],lane='candidate',request_ids=ids,expected_points=points)
            gold=normal.parse_raw(references[cohort]['raw'],lane='candidate',request_ids=ids,expected_points=points)
            parity=compare.compare_exact_histories(gold,result)
            need(parity['passed'] and parity['histories_exact'],'plain historical exact parity failed')
            result['closed_cache0_plain_reference_parity']=compare.compare_exact_prefix(gold,result,complete_request_ids=ids,prefix_request_ids=ids)
        else:
            plain=records['cache0-plain-controls'];policy=policies['policies']['cache0']
            result=observer.analyze_observed(data['raw'],plain['raw'],lane='candidate',request_ids=ids,observed_pid=pid,plain_pid=plain['worker']['pid'],parse_normal=normal.parse_raw,expected_points=points,compiled_dispatch_source=dispatch_bytes,cache_policy=policy['GlobalCache'],cache_budget=policy['CacheMaxBytes'])
            need(result['parity']['passed'] and result['journal_schema_complete'],'observed normal/geometry/cache parity refused')
            need(result['journal_provenance_complete'] is bool(result['observed_veto_count']),'observed veto provenance flag differs from actual coverage')
        result['strict_recorded_accuracy']=accuracy.enforce(result,word_value=normal._value)
        result['driver_identity_verified_by_parser']=False
        result['driver_source_sha256_externally_bound']=built['variants'][request['arm']]['source_inventory']['SubProcesses/P0_epem_mupmum/check_sa.f']['sha256']
        result['actual_ELF_and_driver_identity_bound_at_READY']=True;result['live_error_API_state_compared']=False
        need(json.loads(json.dumps(result,sort_keys=True,allow_nan=False))==worker['analysis'],'full retained JSON analysis does not exactly replay')
        need(worker['raw_sha256']==hashlib.sha256(data['raw'].encode()).hexdigest() and worker['stderr_sha256']==hashlib.sha256(data['stderr']).hexdigest(),'raw/diagnostic binding mismatch')
        if data['validated'] is not None:need(data['validated']['analysis']==result and data['validated']['returncode']==0,'validated plain analysis mismatch')
        plain_normal=result.get('normal_analysis',result);parsed[key]=result;last=plain_normal['learning']['records'][-1]
        expected=[{'direction':'RECV','fields':['READY',str(pid)]},{'direction':'SEND','fields':['LEARN','1','0']},{'direction':'RECV','fields':['LEARNED',str(pid),'1','1',str(last['call_index']),'12']}]
        for i,row in enumerate(plain_normal['measurements'],1):expected.extend([{'direction':'SEND','fields':['RUN',str(i+1),str(i)]},{'direction':'RECV','fields':['DONE',str(pid),str(i+1),str(i),str(row['point_id']),str(row['code']),str(row['class'])]}])
        expected.extend([{'direction':'SEND','fields':['EXIT',str(len(ids)+2),'0']},{'direction':'RECV','fields':['EXIT',str(pid),str(len(ids)+2)]}]);need(data['protocol']==expected,'retained protocol differs from RAW call-index semantics')
        need(plain_normal['learning']['outer_calls']==last['call_index']+1,'bootstrap counter relationship invalid')
        identity={k:data['started']['identity'][k] for k in ('pid','parent_pid','process_group','session','start_time_ticks')}
        need(identity['pid']==pid,'started PID mismatch')
        for name,m in data['maps'].items():
            need(m['pid']==pid and m['affinity']==[12] and m['exclusive_CPU'] is False,'map CPU/PID mismatch')
            need({k:m['identity'][k] for k in identity}==identity=={k:m['started_identity'][k] for k in identity},'map start identity mismatch')
            providers={p:h for p,h in m['ELF'].items() if p not in inputs['runtime']};need(len(providers)==1 and list(providers.values())==[built['variants'][request['arm']]['sha256']],'map ELF identity mismatch')
            need({p:h for p,h in m['ELF'].items() if p in inputs['runtime']}==inputs['runtime'],'recorded15 providers mismatch')
        summary={'arm':request['arm'],'policy':request['policy'],'cohort':cohort,'pid':pid,'worker_returncode':0,'orchestration_closed':True,'learning_outer_calls':plain_normal['learning']['outer_calls'],'LEARNED_call_index_excluding_bootstrap':last['call_index'],'bootstrap_plus_call_index_equals_outer_count':True,'learning_status_counts':dict(sorted(Counter(str(r['code']) for r in plain_normal['learning']['records']).items())),'measured':[{'point_id':r['point_id'],'code':r['code'],'reported_backend':r['status']['actual_backend'],'reported_precision':r['status']['actual_precision'],'rawACC':r['rawACC']} for r in plain_normal['measurements']],'raw_sha256':worker['raw_sha256'],'result_sha256':pins[key][0],'validated_sha256':pins[key][2],'full_recorded_analysis_exact_replay':True,'all_learning_measurement_word_state_parity':True,'strict_accuracy_checked_slots':len(result['strict_recorded_accuracy']['checked']),'maximum_qualified_recorded_accuracy':max(normal._value(r['word']) for r in result['strict_recorded_accuracy']['checked']),'map_snapshots':len(data['maps']),'stderr_bytes':len(data['stderr'])}
        if request['arm']=='plain':summary['historical_reference_raw_sha256']=references[cohort]['raw_sha256']
        summaries[key]=summary
    observed=parsed['cache0-observed-controls'];journals=observed['journals'];events=[e for j in journals for e in j['cache_observations']['events']];native=[e for e in events if e['kind']==1];frames=[f for j in journals for f in j['frames']]
    observer_summary={'measured_physical_points':3,'normal_word_status_15state_parity_against_NEW_own_plain':True,'journal_schema_complete':observed['journal_schema_complete'],'journal_provenance_complete':observed['journal_provenance_complete'],'observed_veto_branch_qualified':bool(observed['observed_veto_count']),'geometry_native_word_checks_passed':True,'journals':len(journals),'frame_count':len(frames),'owned_frames':sum(j['owned_frames'] for j in journals),'public_fallback_frames':sum(j['public_fallback_frames'] for j in journals),'producer_count':sum(len(j['producers']) for j in journals),'consumer_count':sum(len(j['consumers']) for j in journals),'observed_veto_count':observed['observed_veto_count'],'cache_event_count':len(events),'native_event_count':len(native),'native_groups_seen':sorted({e['group'] for e in native}),'native_modes_width_counts':dict(sorted(Counter(str(e['mode'])+':'+str(e['width']) for e in native).items())),'native_status_counts':dict(sorted(Counter(str(e['status']) for e in native).items())),'explicit_all15_clear_events':sum(e['kind']==3 for e in events),'budget_events':sum(e['kind']==2 for e in events),'native_cache_enabled_flags':sorted({e['cache_enabled'] for e in native}),'independent_check_events':sum(e['check_pass'] for e in native),'failed_native_intervals':sum(e['status']!=0 for e in native),'counter_words_all_zero':all(not any(e['before']+e['after']) for e in events),'accounted_bytes_peak':max([s[7] for e in events for s in (e['before'],e['after'])]+[0]),'Fortran_group_cache':'N/A','live_error_API_equivalence_qualified':False,'standalone_Journal_gates_pass_do_not_pass_final_own_runtime_gate':True,'cacheall_coverage':False,'independent_physical_truth':False}
    need(scope['attempted']==sorted(records) and scope['validated']==sorted(k for k in records if '-plain-' in k) and not scope['overall_result_exists'] and not scope['own_runtime_parity_receipt_exists'],'partial coverage scope changed')
    scope['unattempted']=sorted(set(requests)-set(records));need(len(scope['unattempted'])==8,'unattempted scope mismatch')
    need(terminal['status']=='failed' and terminal['returncode']==1 and not terminal['cleanup']['survivors'],'overall failure status changed')
finally:active[0]=False
need(not attempts,'forbidden replay effects')

import copy
counter_path=SOURCE/'protocol_parity.py';counter_code=counter_path.read_bytes();counter_pin=index['files']['protocol_parity.py'];need(len(counter_code)==counter_pin['bytes'] and hashlib.sha256(counter_code).hexdigest()==counter_pin['sha256'],'changed counter helper')
parity=types.ModuleType('source4_actual_protocol_parity');exec(compile(counter_code,str(counter_path),'exec'),parity.__dict__)
fixture_path=SOURCE/'captured-protocol-fixtures.json';fixture_pin=index['files']['captured-protocol-fixtures.json'];need(fixture_path.stat().st_size==fixture_pin['bytes'] and digest(fixture_path)==fixture_pin['sha256'],'changed captured fixture');fixture=read(fixture_path)
source3_index=read(Path('.tirust-build/generic-owned-CMS-cache-run-proposal-3/source-index.json'))
for name in ('normal_run_analysis.py','observer_analysis.py','cache_comparison.py','accuracy_policy.py','run_plan.py'):
    need(index['files'][name]==source3_index['files'][name],'numeric/parser helper changed')
driver_contract={}
markers={
'bootstrap_trace':"CALL DRIVER_TRACE(75,'LEARN',0,TRAIN_ID(1)",
'normal_loop':'DO K=1,MAXLEARN',
'normal_trace':"CALL DRIVER_TRACE(75,'LEARN',K,TRAIN_ID(POINT)",
'raw_terminal':"WRITE(75,'(A,4I12)') 'LEARNED ',SEQ,K,STREAK,CODE",
'native_terminal':"WRITE(74,'(A,5(I0,1X))') 'LEARNED ',PID,SEQ,1,K,STREAK"}
for arm in ('plain','observed'):
    path=Path(built['variants'][arm]['path']).parent/'check_sa.f';pin=built['variants'][arm]['source_inventory']['SubProcesses/P0_epem_mupmum/check_sa.f'];text=path.read_text()
    need(path.stat().st_size==pin['bytes'] and digest(path)==pin['sha256'],'changed actual compiled driver')
    locations={name:[i for i,line in enumerate(text.splitlines(),1) if marker in line] for name,marker in markers.items()}
    need(all(len(lines)==1 for lines in locations.values()),'ambiguous driver counter markers')
    driver_contract[arm]={'path':str(path),'bytes':pin['bytes'],'sha256':pin['sha256'],'source_lines':locations,'source_markers':markers}
corrected_rows={}
for key in ('cache0-plain-controls','cache0-observed-controls'):
    data=records[key];row=copy.deepcopy(data['worker']);arm=row['request']['arm']
    row.update(analysis=parsed[key],raw_path=str(BASE/'evidence'/key/'driver.raw64'),protocol=data['protocol'],
        maps={name.removeprefix('maps-').removesuffix('.json'):value for name,value in data['maps'].items()},
        executable_path=str(Path.cwd()/BASE/'workers'/key/'SubProcesses/P0_epem_mupmum/check'),
        executable_sha256=built['variants'][arm]['sha256'],worker_result_path=str(BASE/'evidence'/key/'result.json'),worker_result_sha256=pins[key][0])
    corrected_rows[key]=row
cases=[];negatives=[]
def rejection(label,fn):
    rejected=False
    try:fn()
    except ValueError:rejected=True
    need(rejected,'invalid learning counter accepted '+label);negatives.append({'case':label,'rejected':True})
try:
    active[0]=True
    fixture_cases={case['worker_id']:case for case in fixture['cases']};need(set(fixture_cases)==set(records),'captured fixture coverage differs')
    for key,result in parsed.items():
        normal_result=result.get('normal_analysis',result);learning=normal_result['learning'];measurements=normal_result['measurements'];ids=normal_result['request_ids'];pid=normal_result['pid'];transcript=records[key]['protocol']
        k=parity.learning_coordinate(learning);need(k==learning['records'][-1]['call_index'] and len(learning['records'])==k+1,'source-derived K mismatch')
        core=parity.protocol_core(transcript,pid=pid,ids=ids,measurements=measurements,learning=learning)
        captured=fixture_cases[key]
        need(captured['learning']==learning and captured['measurements']==measurements and captured['protocol']==transcript and captured['normalized_protocol']==core,'sealed captured summaries differ from fresh actual RAW/observer parse')
        need(captured['normal_index_K']==k and captured['raw_outer_calls']==len(learning['records']) and captured['pid']==pid and captured['ids']==ids,'captured coordinate metadata differs')
        for path,pin in captured['inputs'].items():
            p=Path(path);need(p.parent==BASE/'evidence'/key,'captured input path differs');need(evidence_inventory[key][p.name]==pin,'captured input hash differs')
        wire=next(item['fields'][4] for item in transcript if item['direction']=='RECV' and item['fields'][0]=='LEARNED')
        need(wire==str(k),'native WRITE K not matched')
        cases.append({'worker':key,'derived_K':k,'raw_records_with_bootstrap':len(learning['records']),'ready_streak':learning['streak'],'native_wire_K':int(wire),'actual_RAW_and_fixture_summary_equal':True,'protocol_core_passed':True})
        for bad in sorted({learning['outer_calls'],learning['streak'],k-1,k+1,0,-1,1013} - {k}):
            changed=copy.deepcopy(transcript);next(item for item in changed if item['direction']=='RECV' and item['fields'][0]=='LEARNED')['fields'][4]=str(bad)
            rejection(key+':wire_'+str(bad),lambda changed=changed,pid=pid,ids=ids,measurements=measurements,learning=learning:parity.protocol_core(changed,pid=pid,ids=ids,measurements=measurements,learning=learning))
    base_learning=parsed['cache0-plain-controls']['learning']
    mutations=[]
    m=copy.deepcopy(base_learning);m['records'][0]['call_index']=1;mutations.append(('bootstrap_index',m))
    m=copy.deepcopy(base_learning);m['records'][0]['streak']=1;mutations.append(('bootstrap_streak',m))
    m=copy.deepcopy(base_learning);m['records'][0]['state_before']=[0]*15;mutations.append(('bootstrap_marker',m))
    m=copy.deepcopy(base_learning);m['records']=m['records'][1:];m['outer_calls']=len(m['records']);mutations.append(('missing_bootstrap',m))
    m=copy.deepcopy(base_learning);m['records']=m['records'][:1]+m['records'][4:];m['outer_calls']=len(m['records']);mutations.append(('dropped_init_records',m))
    m=copy.deepcopy(base_learning);m['records'][5]['call_index']=4;mutations.append(('noncontiguous_index',m))
    m=copy.deepcopy(base_learning);m['outer_calls']-=1;mutations.append(('wrong_outer_total',m))
    m=copy.deepcopy(base_learning);m['outer_calls']=True;mutations.append(('boolean_outer',m))
    m=copy.deepcopy(base_learning);m['terminal'][2]='16';mutations.append(('wrong_RAW_terminal_index',m))
    m=copy.deepcopy(base_learning);m['terminal'][-1]='239';mutations.append(('wrong_RAW_terminal_code',m))
    m=copy.deepcopy(base_learning);m['records'][-1]['streak']=11;mutations.append(('last_streak',m))
    m=copy.deepcopy(base_learning);m['records'][5]['point_id']=9;mutations.append(('wrong_point_index',m))
    for label,mutated in mutations:rejection(label,lambda mutated=mutated:parity.learning_coordinate(mutated))
    own=parity.own_runtime_parity(corrected_rows['cache0-plain-controls'],corrected_rows['cache0-observed-controls'],runtime=inputs['runtime']);need(own['passed'],'actual corrected full runtime helper failed')
    changed=copy.deepcopy(corrected_rows['cache0-plain-controls']);next(x for x in changed['protocol'] if x['direction']=='RECV' and x['fields'][0]=='LEARNED')['fields'][4]='16'
    rejection('own_runtime_wrong_wire_total16',lambda:parity.own_runtime_parity(changed,corrected_rows['cache0-observed-controls'],runtime=inputs['runtime']))
    changed=copy.deepcopy(corrected_rows['cache0-plain-controls']);changed['stderr_sha256']='0'*64
    rejection('own_runtime_wrong_diagnostic_hash',lambda:parity.own_runtime_parity(changed,corrected_rows['cache0-observed-controls'],runtime=inputs['runtime']))
    changed=copy.deepcopy(corrected_rows['cache0-plain-controls']);changed['maps']['ready']['affinity']=[13]
    rejection('own_runtime_wrong_map_CPU',lambda:parity.own_runtime_parity(changed,corrected_rows['cache0-observed-controls'],runtime=inputs['runtime']))
finally:active[0]=False
need(not attempts,'forbidden counter replay effects')
print(json.dumps({'schema':'independent-source4-actual-learning-counter-and-runtime-replay-v1','source_index_sha256':EXPECTED,'counter_helper_sha256':counter_pin['sha256'],'captured_fixture_sha256':fixture_pin['sha256'],'source3_numeric_parsers_unchanged':True,'actual_driver_counter_source':driver_contract,'fresh_actual_RAW_and_observer_parser_cases':cases,'strict_negative_controls':negatives,'retrospective_corrected_full_own_runtime_helper':own,'actual_pair_metadata':{key:{'pid':row['pid'],'worker_result_sha256':row['worker_result_sha256'],'raw_sha256':row['raw_sha256'],'stderr_sha256':row['stderr_sha256'],'executable_sha256':row['executable_sha256'],'map_count':len(row['maps'])} for key,row in corrected_rows.items()},'actual_dispatch_sha256':dispatch_pin['sha256'],'closed_RUN3_terminal_sha256':'02b53e803756f53e356326068895145b29be640696bc9dbbc70bfb42b9d87cdc','failed_RUN3_adopted_or_reclassified':False,'coverage':scope,'data_reparse_scope':'Fresh immutable source4 normal/observer/geometry/cache parsing of the same4 closed RAWs precedes the new counter and full runtime checks; no boolean fixture claim is trusted.','input_pins':{'workers':pins,'dispatch':dispatch_pin,'pure_modules_and_inputs':used},'forbidden_API_attempts':attempts,'new_native_worker_compiler_loader_model_calls':0,'preflight_calls':0,'RUN_admitted_by_reproduction':False,'cacheall_or_new_runtime_coverage':False,'independent_physical_truth':False},indent=2,sort_keys=True))
