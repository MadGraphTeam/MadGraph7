from pathlib import Path
from collections import Counter
import hashlib,json,struct,sys,types

SOURCE=Path('.tirust-build/generic-owned-CMS-cache-run-proposal-2')
BASE=Path('.tirust-build/generic-owned-CMS-cache-run-work-2/run')
EVIDENCE=BASE/'evidence/cache0-plain-controls'
HIST=Path('.tirust-build/generic-owned-CMS-plain-run-work-4/run')
def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def loadjson(p):return json.loads(p.read_text())
need(digest(SOURCE/'source-index.json')=='eaabd097a22861e40270b30dfc8c93ac398002e71206324c7edf78f50ef43dc2','changed source2 index')
index=loadjson(SOURCE/'source-index.json');modules={}
used={}
for name in ('normal_run_analysis','cache_comparison','accuracy_policy'):
    p=SOURCE/(name+'.py');data=p.read_bytes();pin=index['files'][name+'.py']
    need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'changed pure parser module')
    used[name+'.py']=pin;m=types.ModuleType(name);exec(compile(data,str(p),'exec'),m.__dict__);modules[name]=m
for name in ('input-pins.json','inputs/training.dat','inputs/controls.dat'):
    p=SOURCE/name;pin=index['files'][name];need(p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'],'changed input metadata');used[name]=pin
inputs=loadjson(SOURCE/'input-pins.json');training=(SOURCE/'inputs/training.dat').read_text();controls=(SOURCE/'inputs/controls.dat').read_text()
need(digest(BASE/'terminal.json')=='d48625b5591ec24bd01d6596d9910db83b507d5373b70d07685fd1c89630867f','changed failed stage terminal')
need(digest(BASE/'validated-cache0-plain-controls.json')=='1222cd23d3959b46f4ccfc223c635c344121a2349121998553d409f2c1718197','changed validated first worker')
need(digest(EVIDENCE/'result.json')=='1801b844593dd5d81302acd381e7c40bf09ccbd719ce3ff0f75745d9a10aa99e','changed worker result')
need(digest(EVIDENCE/'driver.raw64')=='21eb71c88901fac24db2b83903d743a468b043dca9b487c140e02a690876d77e','changed current RAW')
need(digest(HIST/'result.json')=='b0a3eb3596a8c183775d37a1a791a2aee3e3ca671958f8e2884776d79cb042eb','changed historical result')
historical_record=loadjson(HIST/'result.json')['requests']['candidate-controls'];historical_path=HIST/'evidence/candidate-controls/driver.raw64'
need(digest(historical_path)=='a3ffaa934a84158ab2c3f4cb22c9e9037a3e78233133e3e9a24131fd96d89559'==historical_record['raw_sha256'],'changed historical RAW')
terminal=loadjson(BASE/'terminal.json');validated=loadjson(BASE/'validated-cache0-plain-controls.json');worker=loadjson(EVIDENCE/'result.json');raw=(EVIDENCE/'driver.raw64').read_text();oldraw=historical_path.read_text()
protocol=loadjson(EVIDENCE/'protocol.json');command=loadjson(EVIDENCE/'command.json');started=loadjson(EVIDENCE/'started.json')
map_labels=['ready','learned','done-1','done-2','done-3'];maps={label:loadjson(EVIDENCE/('maps-'+label+'.json')) for label in map_labels}
prefix_reports=[loadjson(EVIDENCE/('closed-cache0-reference-prefix-'+str(i)+'.json')) for i in range(4)]
measurement_reports=[loadjson(EVIDENCE/('measurement-'+str(i)+'.json')) for i in range(1,4)]
learning_report=loadjson(EVIDENCE/'learning-analysis.json');stderr=(EVIDENCE/'stderr.txt').read_bytes()
evidence_inventory={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in EVIDENCE.iterdir() if p.is_file()}
rootscope={'evidence_directories':sorted(p.name for p in (BASE/'evidence').iterdir() if p.is_dir()),'validated_files':sorted(p.name for p in BASE.glob('validated-*')),'overall_result_exists':(BASE/'result.json').exists()}
active=[False];attempts=[]
def guard(event,args):
    if active[0] and (event=='open' or event.startswith(('subprocess.','ctypes.','socket.')) or event in ('os.listdir','os.scandir','os.system','os.exec','os.fork','os.posix_spawn','pty.spawn','os.mkdir','os.remove','os.rename','os.rmdir','os.symlink','os.chmod','os.truncate')):
        attempts.append(event);raise RuntimeError('forbidden first-worker replay effect '+event)
sys.addaudithook(guard)
normal=modules['normal_run_analysis'];compare=modules['cache_comparison'];accuracy=modules['accuracy_policy']
def point_words(*streams):
    points={}
    for text in streams:
        rows=text.splitlines();n=int(rows[0]);need(n>0 and len(rows)==1+5*n,'point stream shape')
        for i in range(n):
            key=int(rows[1+5*i]);words=[]
            for line in rows[2+5*i:6+5*i]:
                f=line.split();need(len(f)==4,'four-vector shape');words.append([struct.pack('>d',float(x.replace('D','E').replace('d','e'))).hex().upper() for x in f])
            need(key not in points or points[key]==words,'inconsistent duplicate point');points[key]=words
    return points
try:
    active[0]=True
    points=point_words(training,controls)
    fresh=normal.parse_raw(raw,lane='candidate',request_ids=[1,7,12],expected_points=points)
    historical=normal.parse_raw(oldraw,lane='candidate',request_ids=[1,7,12],expected_points=points)
    parity=compare.compare_exact_histories(historical,fresh,label='independent first completed cache0/plain controls against historical candidate')
    need(parity['passed'] and parity['histories_exact'] and not parity['differences'],'historical raw parity failed')
    need(compare.compare_exact_histories(worker['analysis'],fresh)['passed'],'retained worker analysis differs')
    need(compare.compare_exact_histories(validated['analysis'],fresh)['passed'],'validated analysis differs')
    strict=accuracy.enforce(fresh,word_value=normal._value)
    need(strict==worker['analysis']['strict_recorded_accuracy']==validated['analysis']['strict_recorded_accuracy'],'strict accuracy report differs')
    def prefixes(text):
        lines=text.splitlines(keepends=True);positions=[i for i,line in enumerate(lines) if line.startswith('CALL RUN ')];need(len(positions)==3,'control RAW count')
        return [''.join(lines[:positions[i]]) if i<3 else text for i in range(4)]
    oldprefix=prefixes(oldraw);newprefix=prefixes(raw);prefix_summary=[]
    for i in range(4):
        ids=[1,7,12][:i]
        a=normal.parse_raw(oldprefix[i],lane='candidate',request_ids=ids,expected_points=points)
        b=normal.parse_raw(newprefix[i],lane='candidate',request_ids=ids,expected_points=points)
        report=compare.compare_exact_prefix(a,b,complete_request_ids=[1,7,12],prefix_request_ids=ids)
        need(report==prefix_reports[i] and report['passed'],'stored prefix parity differs')
        saved=learning_report if i==0 else measurement_reports[i-1]
        need(saved['learning']==b['learning'] and saved['measurements']==b['measurements'],'stored incremental RAW analysis differs')
        prefix_summary.append({'ids':ids,'passed':True,'prefix_complete':report['prefix_complete'],'differences':report['difference_count']})
    pid=fresh['pid'];need(pid==worker['pid']==validated['pid']==started['pid'],'worker identity mismatch')
    need(worker['analysis']==validated['analysis'] and worker['request']==validated['request'],'retained worker/validated result mismatch')
    need(worker['returncode']==validated['returncode']==0 and worker['orchestration_closed'] is True and validated['orchestration_closed'] is True and worker['no_retry'] is True,'worker exit/closure not clean')
    need(worker['raw_sha256']==validated['raw_sha256']==hashlib.sha256(raw.encode()).hexdigest(),'RAW identity mismatch')
    need(worker['stderr_sha256']==validated['stderr_sha256']==hashlib.sha256(stderr).hexdigest(),'diagnostic output identity mismatch')
    need(validated['worker_result_sha256']=='1801b844593dd5d81302acd381e7c40bf09ccbd719ce3ff0f75745d9a10aa99e','worker result binding mismatch')
    need(validated['executable_sha256']=='ff68f3c3d744cc22a2b1ff9d47cd52a5b035bb5ad2285fad95fc6a5bd00f64c9','wrong plain compiled ELF identity')
    need(validated['protocol']==protocol,'validated protocol mismatch')
    last=fresh['learning']['records'][-1]
    expected=[{'direction':'RECV','fields':['READY',str(pid)]},{'direction':'SEND','fields':['LEARN','1','0']},{'direction':'RECV','fields':['LEARNED',str(pid),'1','1',str(last['call_index']),'12']}]
    for i,row in enumerate(fresh['measurements'],1):
        expected.extend([{'direction':'SEND','fields':['RUN',str(i+1),str(i)]},{'direction':'RECV','fields':['DONE',str(pid),str(i+1),str(i),str(row['point_id']),str(row['code']),str(row['class'])]}])
    expected.extend([{'direction':'SEND','fields':['EXIT','5','0']},{'direction':'RECV','fields':['EXIT',str(pid),'5']}]);need(protocol==expected,'protocol point/status/order differs')
    identity_keys=('pid','parent_pid','process_group','session','start_time_ticks');stable={k:started['identity'][k] for k in identity_keys}
    for label,m in maps.items():
        need(m==validated['maps'][label] and m['pid']==pid and m['affinity']==[12] and m['exclusive_CPU'] is False,'map/CPU binding differs')
        need({k:m['identity'][k] for k in identity_keys}==stable=={k:m['started_identity'][k] for k in identity_keys},'map process-start identity differs')
        need(m['ELF'].get(validated['executable_path'])==validated['executable_sha256'],'mapped private ELF mismatch')
        providers={k:v for k,v in m['ELF'].items() if k!=validated['executable_path']};need(providers==inputs['runtime'] and len(providers)==15,'recorded provider set differs')
        need(all(path in m['raw'] for path in m['ELF']),'raw maps lack recorded mapped filename')
    need(terminal['status']=='failed' and terminal['returncode']==1 and not terminal['cleanup']['survivors'],'overall failure status changed')
    need(rootscope=={'evidence_directories':['cache0-plain-controls'],'validated_files':['validated-cache0-plain-controls.json'],'overall_result_exists':False},'first-only scope changed')
    measurement_accuracy=[normal._value(w) for row in fresh['measurements'] for w in row['rawACC']]
    qualified_accuracy=[normal._value(row['word']) for row in strict['checked']]
    report={'schema':'independent-CMS-cache-first-worker-RAW-replay-v1','overall_status':'failed','overall_terminal_sha256':'d48625b5591ec24bd01d6596d9910db83b507d5373b70d07685fd1c89630867f','first_worker_only':True,'source_index_sha256':'eaabd097a22861e40270b30dfc8c93ac398002e71206324c7edf78f50ef43dc2','pure_modules':used,'raw_sha256':worker['raw_sha256'],'historical_raw_sha256':historical_record['raw_sha256'],'pid':pid,'worker_returncode':0,'worker_orchestration_closed':True,'learning':{'outer_calls':fresh['learning']['outer_calls'],'last_call_index':last['call_index'],'streak':fresh['learning']['streak'],'ready':fresh['learning']['ready'],'status_learning_complete':fresh['learning']['status_learning_complete'],'all_training_ids_seen':fresh['learning']['all_training_ids_seen'],'status_counts':dict(sorted(Counter(str(r['code']) for r in fresh['learning']['records']).items())),'unqualified_accuracy_records':strict['unqualified']},'measurements':[{'point_id':r['point_id'],'code':r['code'],'class':r['class'],'status':r['status'],'rawANS':r['rawANS'],'rawACC':r['rawACC']} for r in fresh['measurements']],'physical_measured_points':3,'returned_order_rows':6,'coefficient_slots':24,'accuracy_slots':6,'maximum_measured_accuracy':max(measurement_accuracy),'maximum_qualified_recorded_accuracy':max(qualified_accuracy),'strict_accuracy_checked_slots':len(strict['checked']),'exact_learning_measurement_words_status_state_parity':True,'all15_recorded_states_compared':True,'prefix_parity':prefix_summary,'protocol_complete_in_order':True,'zero_tail_scope':'Authenticated worker source enforces FIFO empty-tail before writing orchestration_closed; no retrospective FIFO query in this component.','maps':{'snapshots':len(maps),'same_PID_start_session':stable,'affinity':[12],'exclusive_CPU':False,'recorded_providers_each':15,'ELF_sha256':validated['executable_sha256'],'physical_ELF_or_provider_rehash_by_this_component':False},'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'diagnostic_scope':'Retained banner/card info; nonempty stdout/stderr is not labelled warning-free execution.','coverage':rootscope,'forbidden_API_attempts':attempts,'new_native_or_worker_calls':0,'preflight_calls':0,'full_BUILD_reaudit':False,'cache_enabled_or_observed_arm_coverage':False,'independent_physical_truth':False,'overall_pass':False,'evidence_inventory':evidence_inventory}
finally:active[0]=False
need(not attempts,'forbidden replay effects attempted')
print(json.dumps(report,indent=2,sort_keys=True))
