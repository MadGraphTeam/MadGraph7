from pathlib import Path
import ast,copy,hashlib,json,re,struct,sys,types
from fractions import Fraction

PACKET=Path('.tirust-build/generic-owned-CMS-cache-run-draft-1')
EXPECTED='0e0ab73117f97bc79477478664825c36bf81b61ce13ba2d2eb037f489929faba'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    need(digest(PACKET/'source-index.json')==EXPECTED,'changed source index')
    index=json.loads((PACKET/'source-index.json').read_text());total=0;found=set()
    for p in PACKET.rglob('*'):
        need(not p.is_symlink(),'source alias')
        if p.is_file():found.add(str(p.relative_to(PACKET)))
    need(found==set(index['files'])|{'source-index.json'},'source inventory')
    for name,pin in index['files'].items():
        data=(PACKET/name).read_bytes();data.decode('utf-8')
        need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'changed source '+name);total+=len(data)
    need(len(index['files'])==47 and total==798322,'source payload totals')
    return index
index=verify()
source={name:(PACKET/name).read_bytes() for name in ('cache_comparison.py','accuracy_policy.py','cache_run.py','test_cache_comparison.py')}
modules={}
for name in ('cache_comparison','accuracy_policy'):
    m=types.ModuleType(name);exec(compile(source[name+'.py'],name+'.py','exec'),m.__dict__);modules[name]=m
fixtures={'struct':struct,'deepcopy':copy.deepcopy}
tree=ast.parse(source['test_cache_comparison.py'])
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in ('word','value','ratio','record','analysis'):
        exec(compile(ast.Module(body=[node],type_ignores=[]),'synthetic-fixture','exec'),fixtures)
fixture=fixtures['analysis'];word=fixtures['word'];value=fixtures['value']
adapter_ns={'Path':Path,'hashlib':hashlib,'json':json,'types':types}
tree=ast.parse(source['cache_run.py'])
for node in tree.body:
    if (isinstance(node,ast.FunctionDef) and node.name=='require') or (isinstance(node,ast.ClassDef) and node.name in ('PrefixRefusal','AnalysisAdapter')):
        exec(compile(ast.Module(body=[node],type_ignores=[]),'authenticated-adapter-definitions','exec'),adapter_ns)
active=[False];attempts=[]
def guard(event,args):
    if not active[0]:return
    if event=='open' or event.startswith(('subprocess.','ctypes.','socket.')) or event in ('os.listdir','os.scandir','os.system','os.exec','os.fork','os.posix_spawn','pty.spawn','os.mkdir','os.remove','os.rename','os.rmdir','os.symlink','os.chmod','os.truncate'):
        attempts.append(event);raise RuntimeError('forbidden source-reproduction effect '+event)
sys.addaudithook(guard)
comp=modules['cache_comparison'];accuracy=modules['accuracy_policy'];prefix_cases=[];adapter_cases=[];accuracy_cases=[]
def parsed(ids):
    d=fixture(tuple(ids));d['expected_legacy_critical_failure']=False;return d
try:
    active[0]=True
    for ids in ([],[1],[1,7],[1,7,12],[20],[21]):
        a=parsed(ids);r=comp.compare_exact_histories(a,copy.deepcopy(a))
        expected=bool(tuple(ids) in comp.COMPLETE)
        need(r['histories_exact'] is True and r['passed'] is expected,'unexpected exact-prefix behavior')
        prefix_cases.append({'ids':ids,'histories_exact':r['histories_exact'],'passed':r['passed'],'both_complete_valid_histories':r['both_complete_valid_histories']})
    for ids in ([],[1],[1,7],[1,7,12]):
        saved=[]
        b=types.SimpleNamespace(CACHE_RUN_STAGE=Path('/synthetic/stage'),dump=lambda p,v:saved.append((str(p),v)),local=lambda name:accuracy)
        normal=types.SimpleNamespace(parse_raw=lambda text,**kw:parsed(kw['request_ids']),_value=value)
        a=object.__new__(adapter_ns['AnalysisAdapter']);a.b=b;a.normal=normal;a.compare=comp;a.pid=123
        a.request={'arm':'plain','policy':'cache0','ids':[1,7,12],'id':'cache0-plain-controls'}
        a.prefixes=['empty','one','two','complete'];a.driver_sha='0'*64
        refused=False
        try:a.parse_raw('synthetic-normal-raw',lane='candidate',request_ids=ids)
        except adapter_ns['PrefixRefusal'] as e:
            refused=True;need(e.evidence['histories_exact'] is True and e.evidence['passed'] is False,'unexpected adapter refusal evidence')
        need(refused is (len(ids)<3),'adapter prefix outcome changed')
        adapter_cases.append({'ids':ids,'PrefixRefusal':refused,'comparison_saved':len(saved)==1,'source_file_IO_or_worker_execution':False})
    def check_acc(label,raw_word,should_pass):
        a=parsed([20]);a['learning']['records'][0]['rawACC']=[word(-1.)]*2
        for row in a['learning']['records'][1:]+a['measurements']:row['rawACC']=[raw_word]*2
        ok=True
        try:r=accuracy.enforce(a,word_value=value)
        except ValueError:ok=False
        need(ok is should_pass,'unexpected accuracy acceptance '+label)
        if ok:need(len(r['unqualified'])==1 and r['unqualified'][0]['call_index']==0,'bootstrap qualification changed')
        accuracy_cases.append({'label':label,'word':raw_word,'passed':ok,'expected':should_pass})
    bound=word(1e-6)
    for label,w,yes in [('exact_card_bound',bound,True),('one_ULP_above',f'{int(bound,16)+1:016X}',False),('positive_zero',word(0.),True),('negative_zero',word(-0.),True),('negative_min_subnormal','8000000000000001',False),('positive_infinity','7FF0000000000000',False),('quiet_NaN','7FF8000000000001',False),('signaling_NaN_bits','7FF0000000000001',False)]:check_acc(label,w,yes)
    bad=parsed([20]);bad['expected_legacy_critical_failure']=True
    refused=False
    try:accuracy.enforce(bad,word_value=value)
    except ValueError:refused=True
    need(refused,'legacy exception accepted')
    accuracy_cases.append({'label':'legacy_allowance_flag','rejected':refused})
finally:active[0]=False
verify();need(not attempts,'forbidden effects attempted')
print(json.dumps({'schema':'independent-cache-accuracy-metrics-focused-reproduction-v1','source_index_sha256':EXPECTED,'source_inventory_unchanged':True,'payloads':47,'UTF8_bytes':798322,'prefix_helper_cases':prefix_cases,'actual_adapter_parse_raw_cases':adapter_cases,'expected_first_empty_prefix_refusal_reproduced':adapter_cases[0]['PrefixRefusal'],'accuracy_cases':accuracy_cases,'forbidden_API_attempts':attempts,'native_or_worker_calls':0,'preflight_or_live_BUILD_reads':0,'conclusion':'BLOCKED: first identical accepted cache0 learning prefix refuses because full-history comparison requires complete measurement ids.'},indent=2,sort_keys=True))
