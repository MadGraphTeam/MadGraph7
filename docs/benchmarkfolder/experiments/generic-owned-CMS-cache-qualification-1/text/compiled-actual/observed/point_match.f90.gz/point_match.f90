! PRIVATE SOURCE ONLY. No compiler, ABI, caller, or scientific qualification.
! Caller owns separate retained/current DP/QP buffers and direct canonical P.
! Call-site guards must precede argument evaluation; entry guards alone cannot
! authenticate source origin or suppress caller-created argument temporaries.
module ML5_0_POINT_MATCH
  implicit none
  private
  integer, parameter, public :: point_ik=selected_int_kind(33)
  integer, parameter, public :: point_dp=kind(0.0d0)
  integer, parameter, public :: point_qp=selected_real_kind(33,4931)
  integer, parameter, public :: point_max_external=64
  integer, parameter :: point_i64=selected_int_kind(18)
  integer, parameter :: format_assert=1/merge(1,0, &
      bit_size(0_point_ik)==128.and.bit_size(0_point_i64)==64.and.bit_size(0)==32.and. &
      storage_size(0.0_point_dp)==64.and.radix(0.0_point_dp)==2.and. &
      digits(0.0_point_dp)==53.and.maxexponent(0.0_point_dp)==1024.and. &
      minexponent(0.0_point_dp)==-1021.and. &
      storage_size(0.0_point_qp)==128.and.radix(0.0_point_qp)==2.and. &
      digits(0.0_point_qp)==113.and.maxexponent(0.0_point_qp)==16384.and. &
      minexponent(0.0_point_qp)==-16381)
  integer(point_ik), parameter :: low64_mask=int(z'FFFFFFFFFFFFFFFF',point_ik)
  logical, parameter, public :: point_match_runtime_qualified=.false.
  logical, parameter, public :: point_match_full_caller_qualified=.false.
  logical, parameter, public :: point_match_scientific_dispatch_enabled=.false.
  public :: capture_point_dp,capture_point_qp,point_words_match
contains
  pure logical function finite_real_word(word,width) result(ok)
    integer(point_ik), intent(in) :: word
    integer, intent(in) :: width
    ok=.false.
    select case(width)
    case(64)
      if(ishft(word,-64)/=0_point_ik) return
      if(ibits(word,52,11)==2047_point_ik) return
    case(128)
      if(ibits(word,112,15)==32767_point_ik) return
    case default
      return
    end select
    ok=.true.
  end function finite_real_word

  recursive subroutine capture_point_dp(p,view_ready,words,source_ok)
    real(point_dp), intent(in) :: p(0:,:)
    logical, intent(in) :: view_ready
    integer(point_ik), intent(out) :: words(:,0:,:)
    logical, intent(out) :: source_ok
    integer(point_ik) :: staged(2,0:3,point_max_external),word
    integer(point_i64) :: native_word
    integer :: n,leg,mu
    words=0_point_ik
    source_ok=.false.
    if(.not.view_ready) return
    n=size(words,3)
    if(n<1) return
    if(n>point_max_external) return
    if(size(words,1)/=2) return
    if(size(words,2)/=4) return
    if(size(p,1)/=4) return
    if(size(p,2)/=n) return
    if(.not.is_contiguous(words)) return
    if(.not.is_contiguous(p)) return
    staged=0_point_ik
    do leg=1,n
      do mu=0,3
        native_word=transfer(p(mu,leg),0_point_i64)
        word=iand(int(native_word,point_ik),low64_mask)
        if(.not.finite_real_word(word,64)) return
        staged(1,mu,leg)=word
      enddo
    enddo
    words=staged(:,:,:n)
    source_ok=.true.
  end subroutine capture_point_dp

  recursive subroutine capture_point_qp(p,genuine_qp,view_ready,words,source_ok)
    real(point_qp), intent(in) :: p(0:,:)
    logical, intent(in) :: genuine_qp,view_ready
    integer(point_ik), intent(out) :: words(:,0:,:)
    logical, intent(out) :: source_ok
    integer(point_ik) :: staged(2,0:3,point_max_external),word
    integer :: n,leg,mu
    words=0_point_ik
    source_ok=.false.
    ! Separate guards: Fortran does not promise .AND. short circuiting.
    if(.not.genuine_qp) return
    if(.not.view_ready) return
    n=size(words,3)
    if(n<1) return
    if(n>point_max_external) return
    if(size(words,1)/=2) return
    if(size(words,2)/=4) return
    if(size(p,1)/=4) return
    if(size(p,2)/=n) return
    if(.not.is_contiguous(words)) return
    if(.not.is_contiguous(p)) return
    staged=0_point_ik
    do leg=1,n
      do mu=0,3
        word=transfer(p(mu,leg),0_point_ik)
        if(.not.finite_real_word(word,128)) return
        staged(1,mu,leg)=word
      enddo
    enddo
    words=staged(:,:,:n)
    source_ok=.true.
  end subroutine capture_point_qp

  pure logical function point_words_match(expected_width,reference_width,reference, &
      fresh,valid,current_ok,current_genuine_qp,policy_ready) result(ok)
    integer, intent(in) :: expected_width,reference_width
    integer(point_ik), intent(in) :: reference(:,0:,:),fresh(:,0:,:)
    logical, intent(in) :: valid(:),current_ok,current_genuine_qp,policy_ready
    integer :: n,leg,mu
    ok=.false.
    if(.not.current_ok) return
    if(.not.policy_ready) return
    if(expected_width/=64.and.expected_width/=128) return
    if(reference_width/=expected_width) return
    if(expected_width==128) then
      if(.not.current_genuine_qp) return
    endif
    n=size(valid)
    if(n<1) return
    if(n>point_max_external) return
    if(size(reference,1)/=2) return
    if(size(reference,2)/=4) return
    if(size(reference,3)/=n) return
    if(size(fresh,1)/=2) return
    if(size(fresh,2)/=4) return
    if(size(fresh,3)/=n) return
    if(.not.all(valid)) return
    if(.not.is_contiguous(reference)) return
    if(.not.is_contiguous(fresh)) return
    if(.not.is_contiguous(valid)) return
    do leg=1,n
      do mu=0,3
        if(reference(2,mu,leg)/=0_point_ik) return
        if(fresh(2,mu,leg)/=0_point_ik) return
        if(.not.finite_real_word(reference(1,mu,leg),expected_width)) return
        if(.not.finite_real_word(fresh(1,mu,leg),expected_width)) return
        if(reference(1,mu,leg)/=fresh(1,mu,leg)) return
      enddo
    enddo
    ok=.true.
  end function point_words_match
end module ML5_0_POINT_MATCH
