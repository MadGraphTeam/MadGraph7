! PRIVATE SOURCE ONLY. Not compiled, linked, or runtime/scientific qualified.
! Caller must prove current owned snapshots, exact route and numerator lifetime.
! This module neither captures an environment nor infers one from endpoints.
! It consumes the same q/raw objects observed by the candidate raw-dot region.
module ML5_0_OBS_OWNED_MATH
  use ML5_0_OWNED_EXACT_GEOMETRY, only: geometry_ik, exact_geometry_difference
  use ML5_0_OWNED_SPACELIKE_CERTIFICATE, only: certificate_ik=>ik, zero_bound, certified_spacelike
  use ML5_0_CMS_OBSERVER, only: OBS_CONSUMED,OBS_MARK,OBS_FINAL_RETURN
  implicit none
  private
  integer, parameter, public :: owned_math_ik=geometry_ik
  integer, parameter :: native_i64=selected_int_kind(18)
  integer, parameter :: dp=kind(0.0d0), qp=selected_real_kind(33,4931)
  integer(owned_math_ik), parameter :: low64_mask=int(z'FFFFFFFFFFFFFFFF',owned_math_ik)
  integer, parameter :: format_assert=1/merge(1,0, &
      owned_math_ik==certificate_ik.and.bit_size(0_owned_math_ik)==128.and. &
      bit_size(0_native_i64)==64.and.bit_size(0)==32.and. &
      storage_size(0.0_dp)==64.and.digits(0.0_dp)==53.and.radix(0.0_dp)==2.and. &
      storage_size(cmplx(0.0_dp,0.0_dp,kind=dp))==128.and. &
      storage_size(0.0_qp)==128.and.digits(0.0_qp)==113.and.radix(0.0_qp)==2.and. &
      storage_size(cmplx(0.0_qp,0.0_qp,kind=qp))==256)
  logical, parameter, public :: owned_math_runtime_abi_qualified=.false.
  logical, parameter, public :: owned_math_scientific_dispatch_enabled=.false.
  public :: certify_owned_dp,certify_owned_qp,owned_raw_equal_dp,owned_raw_equal_qp
  public :: owned_negative_finite_real_dp,owned_negative_finite_real_qp
contains
  pure subroutine complex_dp_words(value,words)
    complex(dp), intent(in) :: value
    integer(owned_math_ik), intent(out) :: words(2)
    integer(native_i64) :: native(2)
    ! Match the complete complex representation, then zero-extend each DP word.
    ! Direct REAL*8/COMPLEX*16 -> larger INTEGER128 molds are not permitted.
    native=transfer(value,[0_native_i64,0_native_i64])
    words=iand(int(native,owned_math_ik),low64_mask)
  end subroutine

  pure subroutine complex_qp_words(value,words)
    complex(qp), intent(in) :: value
    integer(owned_math_ik), intent(out) :: words(2)
    ! The two matching128-bit words preserve the complete QP complex payload.
    words=transfer(value,[0_owned_math_ik,0_owned_math_ik])
  end subroutine

  pure logical function owned_raw_equal_dp(candidate,legacy) result(ok)
    complex(dp), intent(in) :: candidate,legacy
    integer(owned_math_ik) :: candidate_words(2),legacy_words(2)
    call complex_dp_words(candidate,candidate_words)
    call complex_dp_words(legacy,legacy_words)
    ok=all(candidate_words==legacy_words)
  end function

  pure logical function owned_raw_equal_qp(candidate,legacy) result(ok)
    complex(qp), intent(in) :: candidate,legacy
    integer(owned_math_ik) :: candidate_words(2),legacy_words(2)
    call complex_qp_words(candidate,candidate_words)
    call complex_qp_words(legacy,legacy_words)
    ok=all(candidate_words==legacy_words)
  end function

  pure logical function owned_negative_finite_real_dp(raw) result(ok)
    complex(dp), intent(in) :: raw
    integer(owned_math_ik) :: words(2)
    call complex_dp_words(raw,words)
    ok=.false.
    if(iand(words(2),maskr(63,owned_math_ik))/=0_owned_math_ik) return
    if(ibits(words(1),52,11)==2047_owned_math_ik) return
    if(iand(words(1),maskr(63,owned_math_ik))==0_owned_math_ik) return
    ok=btest(words(1),63)
  end function

  pure logical function owned_negative_finite_real_qp(raw) result(ok)
    complex(qp), intent(in) :: raw
    integer(owned_math_ik) :: words(2)
    call complex_qp_words(raw,words)
    ok=.false.
    if(iand(words(2),maskr(127,owned_math_ik))/=0_owned_math_ik) return
    if(ibits(words(1),112,15)==32767_owned_math_ik) return
    if(iand(words(1),maskr(127,owned_math_ik))==0_owned_math_ik) return
    ok=btest(words(1),127)
  end function

  logical function certify_owned_dp(q,raw,reference,coefficients,reference_width, &
      pair_class,mass_snap,ready,genuine_qp,environment_valid) result(ok)
    complex(dp), intent(in) :: q(0:3),raw
    integer(owned_math_ik), intent(in) :: reference(:,0:,:)
    integer, intent(in) :: coefficients(:),reference_width,pair_class
    logical, intent(in) :: mass_snap,ready,genuine_qp,environment_valid
    integer(owned_math_ik) :: q_words(2,0:3),raw_words(2)
    integer :: mu,error_exp(0:3)
    ok=.false.
    if(.not.ready.or.reference_width/=64.or.pair_class/=2.or.mass_snap) return
    if(.not.environment_valid) return
    ! genuine_qp is deliberately irrelevant for a native-DP typed entry.
    do mu=0,3
      call complex_dp_words(q(mu),q_words(:,mu))
    enddo
    call complex_dp_words(raw,raw_words)
    call OBS_CONSUMED(q_words,raw_words)
    if(iand(raw_words(2),maskr(63,owned_math_ik))/=0_owned_math_ik) return
    call OBS_MARK(9)
    if(.not.exact_geometry_difference(64,reference_width,reference,coefficients,q_words)) return
    call OBS_MARK(10)
    ! Equality alone is never a zero veto. Preserve the final-dot certificate.
    error_exp=zero_bound
    call OBS_MARK(11)
    ok=certified_spacelike(q_words(1,:),raw_words(1),error_exp,64, &
        pair_class,mass_snap,.true.,environment_valid)
    call OBS_FINAL_RETURN(ok)
  end function

  logical function certify_owned_qp(q,raw,reference,coefficients,reference_width, &
      pair_class,mass_snap,ready,genuine_qp,environment_valid) result(ok)
    complex(qp), intent(in) :: q(0:3),raw
    integer(owned_math_ik), intent(in) :: reference(:,0:,:)
    integer, intent(in) :: coefficients(:),reference_width,pair_class
    logical, intent(in) :: mass_snap,ready,genuine_qp,environment_valid
    integer(owned_math_ik) :: q_words(2,0:3),raw_words(2)
    integer :: mu,error_exp(0:3)
    ok=.false.
    if(.not.ready.or..not.genuine_qp.or.reference_width/=128.or.pair_class/=2.or.mass_snap) return
    if(.not.environment_valid) return
    do mu=0,3
      call complex_qp_words(q(mu),q_words(:,mu))
    enddo
    call complex_qp_words(raw,raw_words)
    call OBS_CONSUMED(q_words,raw_words)
    if(iand(raw_words(2),maskr(127,owned_math_ik))/=0_owned_math_ik) return
    call OBS_MARK(9)
    if(.not.exact_geometry_difference(128,reference_width,reference,coefficients,q_words)) return
    call OBS_MARK(10)
    error_exp=zero_bound
    call OBS_MARK(11)
    ok=certified_spacelike(q_words(1,:),raw_words(1),error_exp,128, &
        pair_class,mass_snap,.true.,environment_valid)
    call OBS_FINAL_RETURN(ok)
  end function
end module
