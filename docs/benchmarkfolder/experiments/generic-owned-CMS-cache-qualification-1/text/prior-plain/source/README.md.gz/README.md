# Dormant plain CMS normal RUN

This packet runs only the two existing plain executables from successful BUILD2 (`fb735463…`, terminal `be89129b…`, result `a3085e4d…`). There is no Fortran compilation, linker query, loader query, observer, source generation, model change, or scientific-dispatch activation in this stage. The exact independently reviewed source/build/object/runtime pins are rechecked before and after execution.

## Requests and learning

Six independent private workers run in declared order: legacy controls 1/7/12, legacy critical 20, legacy critical 21, candidate controls 1/7/12, candidate critical 20, candidate critical 21. Each starts from a fresh qualified clone without restored helicity/loop filters. The exact two immutable NinjaRS directory aliases are preserved; the 298 MB archive is never copied or rewritten. All cards, filters, inputs, FIFO and outputs belong to the worker or its evidence directory.

After READY and actual mapping inspection, each worker receives LEARN once. It makes one normal bootstrap call, then at most 1012 cyclic calls over the twelve original ordinary points. It requires twelve consecutive steady backend-9 return classifications and actual INIT readiness (`CHECKPHASE=.FALSE.`, `HELDOUBLECHECKED=.TRUE.`). Normal FORCE stability/rescue remains enabled. One outer THRES call may internally evaluate twice; these counts are not conflated. No INIT, filter, software FPE, or IEEE state is restored or forced by this controller.

Only completed and semantically checked learning permits measured RUN commands. Each DONE binds sequence, request, point ID, return code/class, actual PID/start/session/parent, single-CPU affinity, the exact ELF and all fifteen runtime providers. Full raw point/scale, Born/finite/poles, accuracy, backend/precision aliases, software flags and IEEE state histories are retained. Point words must also match the supplied private decimal streams; a conversion/echo difference is a refusal, never an accuracy result. Native Fortran list-directed reads and Python binary64 conversion are required to agree for this narrow echo gate.

## Stop policy

All incomplete learning, infrastructure failures, ordinary-control failures, candidate failures, malformed/unsupported evidence, input/mapping changes and timeouts stop immediately without retry. Only a measured legacy critical 20/21 numerical refusal or invalid result after successful ordinary learning is retained as an expected per-request legacy failure; it is never qualified as agreement. Ordinary candidate versus legacy coefficients must satisfy the existing `3e-6` comparison before candidate critical requests are allowed. This comparison is a consistency gate; independent truth is not established.

The worker starts in the authenticated stage group. If Popen is interrupted after child creation but before handle assignment, the failure path unconditionally stops that owned group, even if evidence recording fails. Known worker handles use the reviewed bounded close-first cleanup. Failures/raw evidence remain in the fresh work namespace and cannot be overwritten by a retry.

## Bounds and separation

RUN has an original 1800-second all-in deadline, including 60 seconds reserved for cleanup; each protocol response has at most 180 seconds and cannot exceed the original work cutoff. Limits are 16 GiB address space, 256 MiB per file, core size zero, and nonexclusive CPU 12. The existing numerical mutex serializes the stage. Both Fortran group caching and Rust caching remain disabled, full finite evaluation is selected, and genuine QP is requested through normal MadLoop rescue.

The controller reuses the already reviewed standalone supervisor/ownership/cleanup and successful CMS environment/clone policy. Pure preflight reads authenticated bytes only; it does not query tools or load executables. `guarded_preflight.py` further blocks process/native/tool actions and writes. The initial failed pure bootstrap log is retained alongside successful normal/optimized checks.

## Admission and open claims

This source packet is dormant until the root independently reviews and admits one exact RUN source hash and closed BUILD2 terminal. No numerical RUN has been performed by preparation or pure tests. Constructor ownership, materialized-q lowering, original-raw agreement, equality/certifier/veto observations, final-dot/IEEE lowering, full caller/numerator lifetime, independent finite truth, broad numerical accuracy, and performance remain unqualified. Four-ELF plain/observer parity and detailed geometry journals are a later stage; they do not delay this plain normal physics observation.

Run from the working MadGraph repository with pinned Python using separate `--preflight` and, only after exact root admission, `--execute --phase run --source <sealed-index-sha> --reviewed-build be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2`. No new Fortran build is part of this command.

## Retained predecessor

Source1 (`060b86fe…`) and its successful pure preflight are preserved without numerical execution. Final independent review identified that it did not reject FIFO bytes after EXIT. This successor rejects both buffered and unread terminal bytes after successful native exit and requires the final raw hash to equal the last analyzed DONE prefix; the correction is covered by focused pure controls. This was a source contract gap, not observed native misbehavior.

## Retained initialization failure and resource correction

The one admitted source2 RUN closed after its first legacy worker sent READY and received LEARN. SETMADLOOPPATH auto selected './' because the frozen normal card is in cwd; color/hel files existed only in the resource subdirectories. Fortran STOP returned zero before a completed bootstrap, so the controller refused the missing LEARNED response and retained the raw header/dimensions, stderr, mappings and empty-survivor cleanup. One SLOOP entry was attempted; no bootstrap, learning or measurement result completed. This is resource-path configuration, not an accuracy failure. Source2/work2 remain unchanged.

This source3 changes only private staging: the four already authenticated original color/hel/ident resource files are copied into each fresh cwd next to the unchanged card, with exact before/after hash and size checks. Existing unknown targets, extra/missing/renamed resources or other source paths refuse. The card, compiled driver, both ELFs, science, runtime, normal-learning policy and all caps are unchanged. A fresh work3 would require a separate exact root RUN admission; there is no automatic retry.

## Predeclared 1e-6 runtime stability policy

Before any completed numerical sample, root corrected the intended physical gate to MLStabThres=1e-6 for both runtime arms. The compiled driver passes -1D0 to THRES and therefore uses this card value. This source4 requires the exact closed BUILD card hash, then permits only the bytes `#MLStabThres` followed by `1.000000d-03` to change to `1.000000d-06`; every other byte stays identical. Every private numerical-card copy is verified against the original BUILD hash before staging the runtime card and is then checked against the runtime hash before and after execution. The original BUILD/source card bytes, model card, two ELFs, source, resources, learning/stop policy and caps remain unchanged. Sources2/3 and failed work2 are preserved; source3 never ran. Fresh work4 requires separate exact RUN admission.
