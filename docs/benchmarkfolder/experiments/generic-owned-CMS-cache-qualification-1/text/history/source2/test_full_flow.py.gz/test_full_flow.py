"""Synthetic integration of the actual twelve-request runner and prefix gate.

All workers, PIDs, provider maps, source files and coefficient records below
are fixtures. No BUILD is read and no process/native program is started.
"""
from pathlib import Path
from types import SimpleNamespace
import copy
import hashlib
import json
import struct
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
FORBIDDEN=[]


def _guard(event,args):
    if event.startswith(('subprocess.','ctypes.','os.system','os.exec','os.fork',
                         'os.posix_spawn','socket.','pty.spawn')):
        FORBIDDEN.append(event)
        raise RuntimeError('full-flow test forbids process/native action '+event)


sys.addaudithook(_guard)


def load(name):
    path=HERE/(name+'.py')
    namespace={'__file__':str(path),'__name__':'synthetic_full_flow_'+name}
    exec(compile(path.read_text(),str(path),'exec'),namespace)
    return SimpleNamespace(**namespace)


def sha(data):return hashlib.sha256(data).hexdigest()


def word(value):return struct.pack('>d',value).hex().upper()


def record(phase,index,point):
    state=[0,1]+[0]*13
    return {'phase':phase,'call_index':index,'point_id':point,'code':323,'class':2,
            'status_class':2,'status':{'H':3,'T':2,'U':3,'class':2},
            'rawANS':[[word(1.0)]*4 for _ in range(2)],'rawACC':[word(0.0)]*2,
            'rawP':[[word(float(leg+component)) for component in range(4)] for leg in range(4)],
            'rawMUR':word(91.0),'state_before':None if phase=='LEARN' and index==0 else list(state),
            'state_after':list(state),'finite':True,'finite_outputs':True,'nonfinite':[]}


def raw_text(pid,ids):
    return ('SYNTHETIC_PID '+str(pid)+'\nLEARNING COMPLETE 12\n'+
            ''.join('CALL RUN '+str(index)+' '+str(point)+' 323 2 12 4 T\n'
                    for index,point in enumerate(ids,1)))


class FakeNormal:
    def __init__(self):self.calls=[]
    @staticmethod
    def _value(value):return struct.unpack('>d',bytes.fromhex(value))[0]
    @staticmethod
    def _ratio(value):return float(value)
    def parse_raw(self,text,*,lane,request_ids,expected_points=None):
        lines=text.splitlines()
        if lane!='candidate' or not lines or not lines[0].startswith('SYNTHETIC_PID '):
            raise ValueError('synthetic normal fixture header/lane')
        pid=int(lines[0].split()[1]);ids=[]
        for line in lines:
            if line.startswith('CALL RUN '):
                fields=line.split()
                if len(fields)!=9 or fields[2]!=str(len(ids)+1):
                    raise ValueError('synthetic RAW request coordinate')
                ids.append(int(fields[3]))
        if ids!=list(request_ids):raise ValueError('synthetic RAW prefix differs')
        self.calls.append((pid,tuple(ids),expected_points))
        learning={'success':True,'ready':True,'status_learning_complete':True,
                  'streak':12,'all_training_ids_seen':True,'outer_calls':13,
                  'records':[record('LEARN',0,1)]+[record('LEARN',i,i) for i in range(1,13)]}
        return {'schema':'normal-cms-raw64-analysis-v1','lane':lane,'pid':pid,
                'request_ids':ids,'learning':learning,
                'measurements':[record('RUN',i,point) for i,point in enumerate(ids,1)],
                'accepted_for_continuation':True,'expected_legacy_critical_failure':False,
                'raw_sha256':sha(text.encode()),'independent_physical_truth':False}


class Fixture:
    SUB=Path('SubProcesses/P0_epem_mupmum')
    def __init__(self,root,mode='normal'):
        self.root=root;self.mode=mode;self.plan=load('run_plan');self.runner=load('cache_run')
        self.compare=load('cache_comparison');self.normal=FakeNormal()
        self.trace=[];self.callbacks=[];self.finished=[];self.verifications=0;self.metrics_calls=[]
        self.runtime={'/synthetic/provider-'+str(i):sha(str(i).encode()) for i in range(15)}
        self.inputs=root/'inputs';self.inputs.mkdir()
        for name in ('training','controls','critical20','critical21'):
            (self.inputs/(name+'.dat')).write_text('synthetic input '+name+'\n')
        self.dump(root/'runtime-policies.json',{'policies':{
            'cache0':{'GlobalCache':0,'CacheMaxBytes':268435456},
            'cacheall':{'GlobalCache':-1,'CacheMaxBytes':268435456}}})
        self.dump(root/'input-pins.json',{'runtime':self.runtime})
        self.variants={}
        for arm in ('plain','observed'):
            source=root/'synthetic-compiled'/arm/self.SUB;source.mkdir(parents=True)
            driver=b'synthetic driver '+arm.encode();dispatch=b'synthetic dispatch '+arm.encode()
            (source/'check_sa.f').write_bytes(driver);(source/'CT_interface.f').write_bytes(dispatch)
            (source/'check').write_bytes(b'SYNTHETIC NOT AN ELF')
            self.variants[arm]={'path':str(source/'check'),'sha256':sha(b'SYNTHETIC NOT AN ELF'),
                'source_inventory':{str(self.SUB/'check_sa.f'):{'sha256':sha(driver)},
                                    str(self.SUB/'CT_interface.f'):{'sha256':sha(dispatch)}}}
        self.binding={'compiled_source_sha256':self.plan.COMPILED_SOURCE,
                      'terminal_sha256':self.plan.BUILD_TERMINAL,'result_sha256':self.plan.BUILD_RESULT,
                      'variants':self.variants}
        self.stage=root/'stage';self.stage.mkdir()
        self.references={}
        for cohort,ids in (('controls',[1,7,12]),('critical20',[20]),('critical21',[21])):
            text=raw_text(900+len(self.references),ids);path=root/('closed-'+cohort+'.raw64');path.write_text(text)
            analysis=self.normal.parse_raw(text,lane='candidate',request_ids=ids)
            self.references[cohort]={'raw_path':str(path),'raw_sha256':sha(text.encode()),
                                     'pid':analysis['pid'],'analysis':analysis}
        self.modules={'run_plan':self.plan,'normal_run_analysis':self.normal,'cache_comparison':self.compare,
                      'accuracy_policy':load('accuracy_policy'),'protocol_parity':load('protocol_parity'),
                      'cache_worker':SimpleNamespace(SUB=self.SUB,point_words=self.point_words,one=self.one),
                      'observer_analysis':SimpleNamespace(analyze_observed=self.observe),
                      'cache_metrics':SimpleNamespace(summarize_cache_observations=self.metrics)}
        self.b=SimpleNamespace(HERE=root,EXPECTED_SOURCE='SYNTHETIC-SOURCE-ONLY',
            local=lambda name:self.modules[name],protected=lambda:{'synthetic':True},
            require_supervisor=lambda:self.trace.append('supervisor'),dump=self.dump,
            mapped=lambda process,mapping,started:{'pid':process.pid,'synthetic':True})
    @staticmethod
    def dump(path,value):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    @staticmethod
    def point_words(training,measurement):
        if not Path(training).is_file() or not Path(measurement).is_file():
            raise ValueError('private synthetic input missing')
        return {'synthetic_expected_points':True}
    def verify(self):self.verifications+=1;return copy.deepcopy(self.binding)
    def observe(self,text,plain_text,**kwargs):
        ids=kwargs['request_ids'];normal=kwargs['parse_normal']
        actual=normal(text,lane=kwargs['lane'],request_ids=ids,expected_points=kwargs['expected_points'])
        reference=normal(plain_text,lane='candidate',request_ids=ids,expected_points=kwargs['expected_points'])
        if actual['pid']!=kwargs['observed_pid'] or reference['pid']!=kwargs['plain_pid']:
            raise ValueError('synthetic observed identity')
        if kwargs['compiled_dispatch_source']!=b'synthetic dispatch observed':
            raise ValueError('synthetic dispatch source not forwarded')
        if kwargs['cache_policy'] not in (0,-1) or kwargs['cache_budget']!=268435456:
            raise ValueError('synthetic observer policy not forwarded')
        parity=self.compare.compare_exact_prefix(reference,actual,
            complete_request_ids=self.active_request['ids'],prefix_request_ids=ids)
        if not parity['passed']:raise ValueError('synthetic own normal parity')
        return {**actual,'schema':'synthetic-observer-analysis-v1',
                'normal_analysis':copy.deepcopy(actual),'journals':[],
                'synthetic_own_normal_parity':parity}
    def metrics(self,samples):
        if len(samples)!=12 or len({row['worker_id'] for row in samples})!=12:
            raise ValueError('synthetic metrics requires all12 requests')
        if {row['arm'] for row in samples}!={'plain','observed'}:
            raise ValueError('synthetic metrics arms')
        self.metrics_calls.append(copy.deepcopy(samples))
        return {'schema':'synthetic-metrics-stub','workers':12,'accuracy_accepted':False,
                'native_execution_performed':False}
    def one(self,proxy,directory,request,row,binding,policy):
        self.active_request=request;self.trace.append(request['id'])
        pid=1000+len(self.finished);proxy.mapped(SimpleNamespace(pid=pid),{},0)
        adapter=proxy.local('normal_run_analysis');ids=request['ids']
        schedule=[ids[:i] for i in range(len(ids)+1)]
        if not self.finished:
            if self.mode=='wrong':schedule[0]=[999]
            elif self.mode=='out-of-order':schedule[0],schedule[1]=schedule[1],schedule[0]
            elif self.mode=='duplicate':schedule.insert(1,[])
            elif self.mode=='extra':schedule.append(ids+[999])
            elif self.mode=='missing':schedule=schedule[:-1]
        analysis=None
        for prefix in schedule:
            self.callbacks.append((request['id'],tuple(prefix)))
            analysis=adapter.parse_raw(raw_text(pid,prefix),lane='candidate',request_ids=prefix,
                expected_points=self.point_words(self.inputs/'training.dat',self.root/request['measurement']))
        evidence=directory/'evidence'/request['id'];evidence.mkdir(parents=True,exist_ok=True)
        text=raw_text(pid,ids);(evidence/'driver.raw64').write_text(text)
        executable=directory/'workers'/request['id']/self.SUB/'check'
        executable.parent.mkdir(parents=True);executable.write_bytes(b'SYNTHETIC NOT AN ELF')
        identity={'pid':pid,'parent_pid':10,'process_group':10,'session':10,'start_time_ticks':pid+1,'state':'S'}
        for label in ['ready','learned',*['done-'+str(i) for i in range(1,len(ids)+1)]]:
            self.dump(evidence/('maps-'+label+'.json'),{'pid':pid,'affinity':[12],'exclusive_CPU':False,
                'identity':identity,'started_identity':dict(identity),'ELF':{**self.runtime,str(executable):row['sha256']},
                'raw':'synthetic maps only','data':{}})
        protocol=[{'direction':'RECV','fields':['READY',str(pid)]},
                  {'direction':'SEND','fields':['LEARN','1','0']},
                  {'direction':'RECV','fields':['LEARNED',str(pid),'1','1','13','12']}]
        for i,point in enumerate(ids,1):
            protocol.extend([{'direction':'SEND','fields':['RUN',str(i+1),str(i)]},
                {'direction':'RECV','fields':['DONE',str(pid),str(i+1),str(i),str(point),'323','2']}])
        protocol.extend([{'direction':'SEND','fields':['EXIT',str(len(ids)+2),'0']},
                         {'direction':'RECV','fields':['EXIT',str(pid),str(len(ids)+2)]}])
        self.dump(evidence/'protocol.json',protocol)
        result={'request':copy.deepcopy(request),'analysis':analysis,'pid':pid,'returncode':0,
                'orchestration_closed':True,'no_retry':True,'stderr_sha256':sha(b''),
                'raw_path':str(evidence/'driver.raw64'),'raw_sha256':sha(text.encode())}
        self.dump(evidence/'result.json',result);self.finished.append(request['id']);return result
    def run(self):
        self.runner.run(self.b,self.stage,verify_live=self.verify,closed_plain_references=self.references)


class FullFlowTests(unittest.TestCase):
    def test_complete_twelve_actual_runner_adapter_and_prefix_flow(self):
        with tempfile.TemporaryDirectory(prefix='cache-full-flow-') as temp:
            fixture=Fixture(Path(temp));fixture.run()
            requests=fixture.plan.requests()
            self.assertEqual(fixture.finished,[r['id'] for r in requests])
            self.assertEqual(fixture.callbacks,[(r['id'],tuple(r['ids'][:i]))
                for r in requests for i in range(len(r['ids'])+1)])
            self.assertEqual(len(fixture.callbacks),32)
            self.assertEqual(fixture.verifications,2)
            self.assertEqual(len(fixture.metrics_calls),1)
            report=json.loads((fixture.stage/'result.json').read_text())
            self.assertEqual(report['status'],'passed')
            self.assertEqual(len(report['worker_results']),12)
            self.assertEqual(len(report['own_plain_observed_parity']),6)
            self.assertEqual(len(report['cache_policy_numerical_comparisons']),6)
            self.assertTrue(all(row['normal']['passed'] and row['protocol_maps']['passed']
                                for row in report['own_plain_observed_parity'].values()))
            self.assertTrue(all(row['passed'] for row in report['cache_policy_numerical_comparisons'].values()))
            self.assertFalse(report['independent_physical_truth'])
            self.assertFalse(report['full_caller_qualified'])
            self.assertFalse(report['performance_qualified'])
            # Cache0 plaintext is exercised at empty/partial/full prefixes.
            for cohort,expected in (('controls',4),('critical20',2),('critical21',2)):
                paths=list((fixture.stage/'evidence'/('cache0-plain-'+cohort)).glob('closed-cache0-reference-prefix-*.json'))
                self.assertEqual(len(paths),expected)
                self.assertTrue(all(json.loads(path.read_text())['passed'] for path in paths))
            self.assertEqual(FORBIDDEN,[])
    def assert_refused(self,mode,message):
        with tempfile.TemporaryDirectory(prefix='cache-full-flow-negative-') as temp:
            fixture=Fixture(Path(temp),mode)
            with self.assertRaisesRegex(ValueError,message):fixture.run()
            self.assertEqual(len(fixture.metrics_calls),0)
            self.assertFalse((fixture.stage/'result.json').exists())
            self.assertEqual(len([s for s in fixture.trace if s=='supervisor']),1)
            self.assertEqual(FORBIDDEN,[])
    def test_wrong_request_prefix_stops(self):self.assert_refused('wrong','unexpected worker request prefix')
    def test_out_of_order_callback_stops(self):self.assert_refused('out-of-order','missing/extra/out-of-order worker prefix callback')
    def test_duplicate_callback_stops(self):self.assert_refused('duplicate','missing/extra/out-of-order worker prefix callback')
    def test_extra_callback_stops(self):self.assert_refused('extra','unexpected worker request prefix')
    def test_missing_callback_stops_at_actual_finish(self):self.assert_refused('missing','worker ended without every required prefix callback')


if __name__=='__main__':unittest.main(verbosity=2)
