"""Mutable, data-only twelve-worker request plan. No build or runtime reads."""

COMPILED_SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
BUILD_TERMINAL='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44'
BUILD_RESULT='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137'


def requests():
    # Complete each plaintext policy first so its matching observed arm can be
    # checked incrementally against real, closed own-plain prefixes.
    return [{'id':policy+'-'+arm+'-'+cohort,'lane':'candidate','arm':arm,'policy':policy,
             'cohort':cohort,'ids':ids,'measurement':'inputs/'+cohort+'.dat',
             'expected_legacy_critical_failure_allowed':False}
            for policy in ('cache0','cacheall') for arm in ('plain','observed')
            for cohort,ids in (('controls',[1,7,12]),('critical20',[20]),('critical21',[21]))]


def validate_requests(rows):
    if rows!=requests() or len({row['id'] for row in rows})!=12:
        raise ValueError('exact twelve fresh predeclared worker requests required')
    return True
