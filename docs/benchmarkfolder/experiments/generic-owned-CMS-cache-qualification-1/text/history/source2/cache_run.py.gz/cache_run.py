"""Mutable RUN orchestration draft. No actions at import and no CLI admission.

The eventual controller must authenticate its own RUN source and the real
independent BUILD review/root gate before providing verify_live below.
"""
from pathlib import Path
import hashlib
import json
import types


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())


def normal_view(analysis):
    normal=analysis.get('normal_analysis',analysis)
    require(normal.get('schema')=='normal-cms-raw64-analysis-v1' and normal.get('lane')=='candidate','strict candidate normal analysis required')
    if normal is not analysis:
        for key in ('pid','lane','request_ids','learning','measurements','accepted_for_continuation'):
            require(analysis[key]==normal[key],'observer wrapper/normal core disagreement')
    return normal


def reference_prefixes(text,ids):
    # The complete reference is parsed and authenticated before prefix cuts.
    lines=text.splitlines(keepends=True)
    starts=[i for i,line in enumerate(lines) if line.startswith('CALL RUN ')]
    require(len(starts)==len(ids) and bool(ids),'plain reference request count')
    for number,(line,point) in enumerate(zip(starts,ids),1):
        fields=lines[line].split()
        require(len(fields)==9 and fields[:2]==['CALL','RUN'] and fields[2:4]==[str(number),str(point)],'plain reference request coordinates')
    return [''.join(lines[:starts[i]]) if i<len(ids) else text for i in range(len(ids)+1)]


class PrefixRefusal(ValueError):
    def __init__(self,message,text,evidence):
        super().__init__(message);self.raw_text=text;self.evidence=evidence
        self.records=evidence.get('measurements',[])


class AnalysisAdapter:
    def __init__(self,b,request,row,policy,reference):
        self.b=b;self.request=request;self.row=row;self.policy=policy;self.pid=None
        self.next_prefix_length=0;self.last_analysis=None
        self.normal=b.local('normal_run_analysis');self.observer=b.local('observer_analysis')
        self.compare=b.local('cache_comparison');self.worker=b.local('cache_worker')
        self.prefixes=None;self.reference=reference
        if reference is not None:
            raw=Path(reference['raw_path'])
            require(digest(raw)==reference['raw_sha256'],'own plaintext reference changed')
            text=raw.read_text()
            expected=self.worker.point_words(b.HERE/'inputs/training.dat',b.HERE/request['measurement'])
            parsed=self.normal.parse_raw(text,lane='candidate',request_ids=request['ids'],expected_points=expected)
            stored=normal_view(reference['analysis'])
            joined=self.compare.compare_exact_histories(stored,parsed,label='immutable own plaintext reference replay')
            require(joined['passed'],'own plaintext reference analysis does not replay')
            self.prefixes=reference_prefixes(text,request['ids'])
        source=Path(row['path']).parent
        self.driver_source=source/'check_sa.f'
        self.driver_sha=row['source_inventory'][str(self.worker.SUB/'check_sa.f')]['sha256']
        require(digest(self.driver_source)==self.driver_sha,'actual compiled driver source changed')
        self.dispatch=(source/'CT_interface.f').read_bytes() if request['arm']=='observed' else None
        if self.dispatch is not None:
            require(hashlib.sha256(self.dispatch).hexdigest()==row['source_inventory'][str(self.worker.SUB/'CT_interface.f')]['sha256'],'actual compiled dispatch source changed')
    def bind(self,pid):
        require(type(pid) is int and pid>0 and (self.pid is None or self.pid==pid),'actual READY mapping/PID changed')
        self.pid=pid
    def parse_raw(self,text,*,lane,request_ids,expected_points=None):
        require(self.pid is not None and lane=='candidate','actual READY mapping must precede parsing')
        ids=list(request_ids)
        require(ids==self.request['ids'][:len(ids)] and len(ids)<=len(self.request['ids']),'unexpected worker request prefix')
        require(len(ids)==self.next_prefix_length,'missing/extra/out-of-order worker prefix callback')
        if self.request['arm']=='observed':
            require(self.prefixes is not None,'observed worker lacks closed own-policy plaintext reference')
            parsed=self.observer.analyze_observed(text,self.prefixes[len(ids)],lane='candidate',request_ids=ids,
                observed_pid=self.pid,plain_pid=self.reference['pid'],parse_normal=self.normal.parse_raw,
                expected_points=expected_points,compiled_dispatch_source=self.dispatch,
                cache_policy=self.policy['GlobalCache'],cache_budget=self.policy['CacheMaxBytes'])
        else:
            parsed=self.normal.parse_raw(text,lane='candidate',request_ids=ids,expected_points=expected_points)
            require(parsed['pid']==self.pid,'plaintext native PID/raw mismatch')
            if self.request['policy']=='cache0':
                require(self.prefixes is not None,'fresh cache0 plaintext lacks own closed reference')
                old=self.normal.parse_raw(self.prefixes[len(ids)],lane='candidate',request_ids=ids,expected_points=expected_points)
                comparison=self.compare.compare_exact_prefix(old,parsed,complete_request_ids=self.request['ids'],prefix_request_ids=ids)
                folder=self.b.CACHE_RUN_STAGE/'evidence'/self.request['id']
                self.b.dump(folder/('closed-cache0-reference-prefix-'+str(len(ids))+'.json'),comparison)
                if not comparison['passed']:
                    raise PrefixRefusal('fresh cache0 did not reproduce its own closed plaintext history',text,comparison)
                parsed['closed_cache0_plain_reference_parity']=comparison
        require(parsed['pid']==self.pid,'raw/PID changed after parsing')
        require(parsed['expected_legacy_critical_failure'] is False,'new candidate inherited a legacy numerical-refusal allowance')
        require(parsed['accepted_for_continuation'] is True and parsed['learning']['ready'] is True,'worker prefix lacks accepted normal ready learning')
        parsed['strict_recorded_accuracy']=self.b.local('accuracy_policy').enforce(parsed,word_value=self.normal._value)
        parsed['driver_identity_verified_by_parser']=False
        parsed['driver_source_sha256_externally_bound']=self.driver_sha
        parsed['actual_ELF_and_driver_identity_bound_at_READY']=True
        parsed['live_error_API_state_compared']=False
        self.next_prefix_length+=1;self.last_analysis=parsed
        return parsed
    def finish(self,analysis):
        require(self.next_prefix_length==len(self.request['ids'])+1 and self.last_analysis is not None,'worker ended without every required prefix callback')
        require(analysis==self.last_analysis and normal_view(analysis)['request_ids']==self.request['ids'],'worker returned an incomplete/different final history')
        return True


def attach_runtime_evidence(stage,request,result,row):
    folder=stage/'evidence'/request['id']
    maps={label:read(folder/('maps-'+label+'.json'))
          for label in ['ready','learned',*['done-'+str(i) for i in range(1,len(request['ids'])+1)]]}
    return {**result,'raw_path':str(folder/'driver.raw64'),'protocol':read(folder/'protocol.json'),
            'maps':maps,'executable_path':str(stage/'workers'/request['id']/'SubProcesses/P0_epem_mupmum/check'),
            'executable_sha256':row['sha256'],'worker_result_path':str(folder/'result.json'),
            'worker_result_sha256':digest(folder/'result.json')}


def run(b,directory,*,verify_live,closed_plain_references):
    """Call only from a separately authenticated RUN supervisor after review.

    verify_live must first authenticate the real root gate and independent
    BUILD review, then call frozen6417 verified_build through an isolated
    compiled-source proxy; it returns actual closed rows and fixed identities.
    """
    require(callable(verify_live),'real reviewed BUILD/root-gate verifier required')
    binding=verify_live()
    plan=b.local('run_plan');worker=b.local('cache_worker');compare=b.local('cache_comparison')
    parity=b.local('protocol_parity');metrics=b.local('cache_metrics');normal=b.local('normal_run_analysis')
    require(binding['compiled_source_sha256']==plan.COMPILED_SOURCE and binding['terminal_sha256']==plan.BUILD_TERMINAL
            and binding['result_sha256']==plan.BUILD_RESULT,'wrong actual closed compiled identity')
    require(set(binding['variants'])=={'plain','observed'},'exact two compiled arms')
    requests=plan.requests();plan.validate_requests(requests)
    policies=read(b.HERE/'runtime-policies.json')['policies']
    before=b.protected();b.CACHE_RUN_STAGE=directory;results={};policy_comparisons={};own_parities={}
    for request in requests:
        b.require_supervisor()
        b.dump(directory/'progress.json',{'request':request['id'],'state':'starting','completed':list(results),
            'compiled_source_index_sha256':plan.COMPILED_SOURCE,'RUN_source_index_sha256':b.EXPECTED_SOURCE})
        row=binding['variants'][request['arm']];policy=policies[request['policy']]
        reference=None
        if request['arm']=='observed':
            reference=results[request['policy']+'-plain-'+request['cohort']]
        elif request['policy']=='cache0':
            reference=closed_plain_references[request['cohort']]
        adapter=AnalysisAdapter(b,request,row,policy,reference)
        proxy=types.SimpleNamespace(**vars(b));oldlocal=b.local
        proxy.local=lambda name:adapter if name=='normal_run_analysis' else oldlocal(name)
        def mapped(process,mapping,started):
            evidence=b.mapped(process,mapping,started);adapter.bind(process.pid);return evidence
        proxy.mapped=mapped
        full=worker.one(proxy,directory,request,row,binding,policy)
        adapter.finish(full['analysis'])
        result=attach_runtime_evidence(directory,request,full,row)
        results[request['id']]=result
        if request['arm']=='observed':
            plain=results[request['policy']+'-plain-'+request['cohort']]
            plain_normal=normal_view(plain['analysis'])
            observed_normal=normal_view(result['analysis'])
            exact=compare.compare_own_parity(plain_normal,observed_normal)
            runtime=parity.own_runtime_parity(plain,result,runtime=read(b.HERE/'input-pins.json')['runtime'])
            own_parities[request['id']]={'normal':exact,'protocol_maps':runtime}
            b.dump(directory/('own-parity-'+request['id']+'.json'),own_parities[request['id']])
            require(exact['passed'] and runtime['passed'],'own plain/observed observable parity failed')
        if request['policy']=='cacheall':
            zero=results['cache0-'+request['arm']+'-'+request['cohort']]
            zero_normal=normal_view(zero['analysis'])
            current_normal=normal_view(result['analysis'])
            comparison=compare.compare_policy_numerics(zero_normal,current_normal,word_value=normal._value,ratio=normal._ratio,
                journals0=zero['analysis'].get('journals'),journals_all=result['analysis'].get('journals'))
            policy_comparisons[request['id']]=comparison
            b.dump(directory/('policy-comparison-'+request['id']+'.json'),comparison)
            require(comparison['passed'],'cacheall/cache0 numerical regression criterion failed')
        b.dump(directory/('validated-'+request['id']+'.json'),result)
        b.dump(directory/'progress.json',{'request':request['id'],'state':'closed','completed':list(results),
            'compiled_source_index_sha256':plan.COMPILED_SOURCE,'RUN_source_index_sha256':b.EXPECTED_SOURCE})
    require(len(results)==12 and len(own_parities)==6 and len(policy_comparisons)==6,'incomplete declared RUN matrix')
    require(b.protected()==before,'protected input/provider changed')
    final=verify_live();require(final==binding,'closed BUILD/root-gate identity changed during RUN')
    samples=[{'worker_id':key,'arm':row['request']['arm'],'policy_label':row['request']['policy'],
              'policy':policies[row['request']['policy']]['GlobalCache'],'budget':268435456,'analysis':row['analysis']}
             for key,row in results.items()]
    counter_summary=metrics.summarize_cache_observations(samples)
    b.dump(directory/'cache-observations.json',counter_summary)
    b.dump(directory/'result.json',{'status':'passed','RUN_source_index_sha256':b.EXPECTED_SOURCE,
        'compiled_source_index_sha256':plan.COMPILED_SOURCE,'reviewed_BUILD_terminal_sha256':plan.BUILD_TERMINAL,
        'compiled_result_sha256':plan.BUILD_RESULT,'worker_results':{
          key:{'validated_path':str(directory/('validated-'+key+'.json')),'validated_sha256':digest(directory/('validated-'+key+'.json')),
               'raw_sha256':row['raw_sha256'],'pid':row['pid'],'returncode':row['returncode']} for key,row in results.items()},
        'native_processes':12,'normal_learning_required':True,'own_plain_observed_parity':own_parities,
        'cache_policy_numerical_comparisons':policy_comparisons,'cache_observations_sha256':digest(directory/'cache-observations.json'),
        'compiler_calls':0,'loader_queries':0,'Fortran_group_cache_applicable':False,
        'live_error_API_state_compared':False,'unobserved_software_state_equivalence':False,
        'independent_physical_truth':False,'full_caller_qualified':False,'performance_qualified':False,
        'production_dispatch_enabled':False,'scope':'Twelve declared normal-learning parity/cache observations only.'})
