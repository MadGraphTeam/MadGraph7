"""Strict offline parser for the frozen normal CMS RAW64 driver.

No I/O, project imports or executable actions. Source/ELF/protocol identity joins
belong to the external controller. All full-caller/scientific claims stay false.
"""
import hashlib
import re
import struct
from fractions import Fraction

DRIVER_SHA256={
 'legacy':'cb380ec3993a0fd3badd776d119710bbd8ef329197b2258263de43d79526a3f9',
 'candidate':'36f9057bde1a9b97e3c299af28db989faf1583c73611866ed77691504b291cc4'}
ALIASES={(2,1):(1,'DP'),(3,9):(1,'QP'),(2,6):(6,'DP'),(3,8):(6,'QP'),
         (2,7):(7,'DP'),(2,8):(8,'DP'),(3,2):(8,'QP'),(2,9):(9,'DP'),(3,3):(9,'QP')}
REQUESTS={() ,(1,),(1,7),(1,7,12),(20,),(21,)}
INT=re.compile(r'-?(?:0|[1-9][0-9]*)\Z')
HEX=re.compile(r'[0-9A-F]{16}\Z')

class AnalysisError(ValueError):
    def __init__(self,message,raw_text='',records=None):
        super().__init__(message)
        self.raw_text=raw_text
        self.records=list(records or ())
        self.raw_sha256=hashlib.sha256(raw_text.encode('utf-8',errors='surrogatepass')).hexdigest()


def decode_status(code):
    """Actual H/U alias only; H1/H4 or foreign/unknown codes invent no precision."""
    if type(code) is not int:raise ValueError('integer code required')
    valid=0<=code<=499
    h,t,u=(code//100,(code%100)//10,code%10) if valid else (None,None,None)
    alias=ALIASES.get((h,u)) if valid else None
    selected=(h==2 and u==9) or (h==3 and u==3)
    cls=2 if selected and t in (1,2) else 1 if t==3 and (selected or (h==1 and u==9)) else 0
    return {'code':code,'H':h,'T':t,'U':u,'class':cls,'valid_range':valid,
            'actual_backend':alias[0] if alias else None,
            'actual_precision':alias[1] if alias else None,
            'actual_alias':list(alias) if alias else None}


def _int(token):
    if not INT.fullmatch(token):raise ValueError('noncanonical integer')
    value=int(token)
    if not -2147483648<=value<=2147483647:raise ValueError('default integer overflow')
    return value


def _word(token):
    if not HEX.fullmatch(token):raise ValueError('raw64 word must be16 uppercase hex digits')
    return token


def _finite(word):return int(word,16)&0x7FF0000000000000 != 0x7FF0000000000000

def _value(word):
    if not _finite(word):return None
    return struct.unpack('>d',bytes.fromhex(word))[0]


def _nonfinite(word):
    return 'NaN' if int(word,16)&0x000FFFFFFFFFFFFF else '-Infinity' if int(word,16)>>63 else 'Infinity'


def _quality(record):
    nonfinite=[]
    for name,items in [('P',[(f'{mu},{leg+1}',w) for leg,col in enumerate(record['rawP']) for mu,w in enumerate(col)]),
                       ('ANS',[(f'{mu},{order}',w) for order,col in enumerate(record['rawANS']) for mu,w in enumerate(col)]),
                       ('ACC',[(str(order),w) for order,w in enumerate(record['rawACC'])]),
                       ('MUR',[('',record['rawMUR'])])]:
        for coordinate,word in items:
            if not _finite(word):nonfinite.append({'field':name,'coordinate':coordinate,'word':word,'kind':_nonfinite(word)})
    negative=[{'order':i,'word':word,'value':_value(word)} for i,word in enumerate(record['rawACC'])
              if _finite(word) and _value(word)<0]
    unknown=[]
    for label in ('state_before','state_after'):
        state=record[label]
        if state is not None:
            unknown.extend({'snapshot':label,'column':i+1,'value':v} for i,v in enumerate(state) if v==-1)
    record.update(nonfinite=nonfinite,negative_accuracy=negative,unsupported_state=unknown,
                  finite=not nonfinite,finite_outputs=not any(x['field'] in ('ANS','ACC') for x in nonfinite),
                  accuracy_available=not negative and all(_finite(w) for w in record['rawACC']))
    return record


class _Reader:
    def __init__(self,text):
        self.text=text;self.lines=text.splitlines();self.pos=0;self.records=[]
    def fail(self,message):raise AnalysisError(f'line {self.pos+1}: {message}',self.text,self.records)
    def take(self):
        if self.pos>=len(self.lines):self.fail('truncated raw record')
        line=self.lines[self.pos];self.pos+=1
        if not line or line.strip()!=line.lstrip() or not line.isascii():self.fail('blank/noncanonical raw line')
        return line.split()
    def ints(self,tokens):
        try:return [_int(t) for t in tokens]
        except ValueError as error:self.fail(str(error))
    def word(self,token):
        try:return _word(token)
        except ValueError as error:self.fail(str(error))
    def state(self,label):
        fields=self.take()
        if len(fields)!=16 or fields[0]!=label:self.fail('expected full15-state '+label)
        values=self.ints(fields[1:])
        if any(v not in (0,1) for v in values[:4]):self.fail('invalid software-state domain')
        if any(v not in (-1,0,1) for v in values[4:14]) or values[14] not in (-1,0,1,2,3):self.fail('invalid IEEE-state domain')
        return values
    def call(self):
        fields=self.take()
        if len(fields)!=9 or fields[0]!='CALL' or fields[1] not in ('LEARN','RUN') or fields[8] not in ('T','F'):
            self.fail('invalid CALL header')
        index,point,code,cls,streak,ne=self.ints(fields[2:8])
        if ne!=4 or index<0:self.fail('wrong shape/call index')
        status=decode_status(code)
        if cls!=status['class']:self.fail('spoofed status class')
        before=self.state('BEFORE') if fields[8]=='T' else None
        after=self.state('AFTER')
        mur=self.take()
        if len(mur)!=2 or mur[0]!='MUR':self.fail('missing MUR word')
        rawmur=self.word(mur[1]);points=[];answers=[];accuracies=[]
        for label,outer,inner,destination in [('P',range(1,5),range(4),points),('ANS',range(2),range(4),answers)]:
            for j in outer:
                col=[]
                for i in inner:
                    row=self.take()
                    if len(row)!=4 or row[0]!=label or self.ints(row[1:3])!=[i,j]:self.fail('missing/duplicate/reordered '+label+' word')
                    col.append(self.word(row[3]))
                destination.append(col)
        for j in range(2):
            row=self.take()
            if len(row)!=3 or row[0]!='ACC' or self.ints(row[1:2])!=[j]:self.fail('missing/duplicate/reordered ACC word')
            accuracies.append(self.word(row[2]))
        if self.take()!=['CALL_END']:self.fail('missing CALL_END')
        result=_quality({'phase':fields[1],'call_index':index,'point_id':point,'code':code,'class':cls,
                         'status':status,'status_class':cls,'streak':streak,'state_before':before,'state_after':after,
                         'rawMUR':rawmur,'rawP':points,'rawANS':answers,'rawACC':accuracies})
        self.records.append(result)
        return result


def _ready(state):return state is not None and state[0:2]==[0,1]

def _semantic_issues(record, *, initializing=False):
    issues=[]
    if record['nonfinite']:issues.append('nonfinite-values')
    if record['negative_accuracy'] and not initializing:issues.append('negative/unavailable-accuracy')
    if record['unsupported_state']:issues.append('unsupported-state-channel')
    return issues


def parse_raw(text, *, lane, request_ids, expected_points=None):
    """Parse a flushed DONE prefix. Valid numerical failures remain data.

    request_ids must be an actual request prefix: (),1,1/7,1/7/12,20 or21.
    Optional expected_points binds point IDs to exact leg-major rawP arrays.
    Otherwise input-file/source/ELF binding is explicitly a controller duty.
    """
    if lane not in ('legacy','candidate'):raise AnalysisError('unknown lane',text if isinstance(text,str) else '')
    if not isinstance(text,str) or not text.isascii() or not text.endswith('\n') or len(text)>8*1024*1024:
        raise AnalysisError('raw must be complete bounded ASCII newline text',text if isinstance(text,str) else '')
    try:requests=tuple(request_ids)
    except TypeError:raise AnalysisError('request ID prefix required',text)
    if any(type(i) is not int for i in requests) or requests not in REQUESTS:raise AnalysisError('unsupported request ID prefix',text)
    r=_Reader(text)
    header=r.take()
    if len(header)!=3 or header[:2]!=['CMS_DRIVER_RAW64_V1','PID']:r.fail('wrong raw version/header')
    pid=r.ints(header[2:])[0]
    if pid<=0:r.fail('invalid native PID')
    dimension=r.take()
    if dimension[0:1]!=['DIMENSIONS'] or len(dimension)!=6 or r.ints(dimension[1:])!=[4,1,1,1,9]:r.fail('exact CMS dimensions/backend required')
    bootstrap=r.call()
    if bootstrap['phase']!='LEARN' or bootstrap['call_index']!=0 or bootstrap['point_id']!=1 or bootstrap['streak']!=0 or bootstrap['state_before'] is not None:
        r.fail('invalid bootstrap')
    training=[bootstrap];point_words={};streak=0;stop=None;last=bootstrap;issues=[]
    def echo(row):
        key=row['point_id'];value=(row['rawP'],row['rawMUR'])
        if row['phase']=='LEARN':
            if key in point_words and point_words[key]!=value:r.fail('changed frozen training point/scale echo')
            point_words[key]=value
        elif key in point_words and point_words[key]!=value:r.fail('control point differs from its frozen training echo')
        if expected_points is not None:
            if key not in expected_points or row['rawP']!=expected_points[key]:r.fail('external frozen point-word mismatch')
    echo(bootstrap)
    for index in range(1,1013):
        if r.pos>=len(r.lines):r.fail('missing learning terminal')
        if not r.lines[r.pos].startswith('CALL '):break
        row=r.call()
        if row['phase']!='LEARN' or row['call_index']!=index or row['point_id']!=1+(index-1)%12 or row['state_before'] is None:
            r.fail('invalid cyclic learning coordinates')
        if row['state_before'][:4]!=last['state_after'][:4]:r.fail('software state changed between normal calls')
        streak=streak+1 if row['class']==2 and _ready(row['state_after']) else 0
        if row['streak']!=streak:r.fail('wrong learning streak')
        echo(row);training.append(row);last=row
        current=_semantic_issues(row,initializing=row['class']==1)
        if current:issues.append({'call_index':index,'point_id':row['point_id'],'issues':current})
        if row['class']==0:stop='learning-status';break
        if streak==12:stop='success';break
    else:stop='learning-limit'
    terminal=r.take()
    success=False;reason=None
    if terminal[0:1]==['LEARNED']:
        if len(terminal)!=5 or r.ints(terminal[1:])!=[1,last['call_index'],12,last['code']] or stop!='success':r.fail('unearned/spoofed LEARNED')
        success=not issues
        reason=None if success else 'learning-numerical/state-evidence-failure'
    elif terminal[0:1]==['LEARNING_FAILED']:
        if len(terminal)!=2 or terminal[1] not in ('learning-status','learning-limit') or terminal[1]!=stop:r.fail('invalid learning failure terminal')
        reason=terminal[1]
    else:r.fail('missing learning terminal')
    learning={'success':success,'ready':success and _ready(last['state_after']),'status_learning_complete':stop=='success','reason':reason,
              'outer_calls':len(training),'maximum_outer_calls':1013,'maximum_possible_inner_calls':2*len(training),
              'streak':streak,'terminal':terminal,'issues':issues,'records':training,
              'all_training_ids_seen':sorted(point_words)==list(range(1,13))}
    if stop=='success' and not learning['all_training_ids_seen']:r.fail('incomplete frozen training cycle')
    measurements=[]
    for index,point_id in enumerate(requests,1):
        if stop!='success':r.fail('measurement after failed learning')
        row=r.call()
        if row['phase']!='RUN' or row['call_index']!=index or row['point_id']!=point_id or row['streak']!=0 or row['state_before'] is None:
            r.fail('wrong measured request/point/streak')
        if row['state_before'][:4]!=last['state_after'][:4]:r.fail('measurement software-state discontinuity')
        echo(row)
        problems=_semantic_issues(row)
        if row['class']!=2:problems.append('nonsteady-status')
        if not _ready(row['state_before']) or not _ready(row['state_after']):problems.append('normal-INIT-not-ready')
        input_bad=any(x['field'] in ('P','MUR') for x in row['nonfinite'])
        numeric_bad=any(x['field'] in ('ANS','ACC') for x in row['nonfinite']) or bool(row['negative_accuracy'])
        status=row['status']
        numeric_refusal=(status['H']==4 and status['T'] in (1,2,3,4)) or (
            status['actual_backend']==9 and status['T']==4)
        expected=(lane=='legacy' and point_id in (20,21) and success and _ready(row['state_before'])
                  and not input_bad and not row['unsupported_state'] and (numeric_refusal or (row['class']==2 and numeric_bad)))
        row.update(issues=problems,expected_legacy_critical_failure=expected,
                   accepted_for_continuation=success and (not problems or expected))
        measurements.append(row);last=row
    if r.pos!=len(r.lines):r.fail('extra/truncated/request-prefix-mismatched raw records')
    accepted=success and all(x['accepted_for_continuation'] for x in measurements)
    return {'schema':'normal-cms-raw64-analysis-v1','lane':lane,'pid':pid,
            'raw_sha256':hashlib.sha256(text.encode()).hexdigest(),'raw_bytes':len(text),
            'driver_sha256_required':DRIVER_SHA256[lane],'driver_identity_verified_by_parser':False,
            'request_ids':list(requests),'learning':learning,'measurements':measurements,
            'accepted_for_continuation':accepted,
            'expected_legacy_critical_failure':any(x['expected_legacy_critical_failure'] for x in measurements),
            'external_input_echo_verified':expected_points is not None,
            'full_caller_qualified':False,'numerator_qualified':False,'scientifically_qualified':False,
            'independent_finite_truth':False,'accuracy_qualified':False,'performance_qualified':False}


def _ratio(number):
    try:return float(number)
    except OverflowError:return None


def compare_ordinary(legacy,candidate,tolerance=3e-6):
    """Report only: exact-rational form of the existing LoopMEComparator rule."""
    if tolerance!=3e-6:raise ValueError('this frozen report uses declared3e-6 tolerance')
    if legacy.get('lane')!='legacy' or candidate.get('lane')!='candidate':raise ValueError('legacy/candidate pair required')
    if legacy.get('request_ids')!=[1,7,12] or candidate.get('request_ids')!=[1,7,12]:raise ValueError('complete ordinary controls required')
    if not legacy['accepted_for_continuation'] or not candidate['accepted_for_continuation']:raise ValueError('failed ordinary worker cannot be numerically compared')
    for evidence in (legacy,candidate):
        rows=evidence.get('measurements')
        if type(rows) is not list or len(rows)!=3 or any(type(row) is not dict for row in rows) or [row.get('point_id') for row in rows]!=[1,7,12]:
            raise ValueError('exact three ordinary measurement rows in1/7/12 order required')
    residuals=[];failures=[];target=True;tol=Fraction(tolerance);goal=Fraction(1e-8)
    for left,right in zip(legacy['measurements'],candidate['measurements']):
        if left['rawP']!=right['rawP'] or left['rawMUR']!=right['rawMUR']:raise ValueError('ordinary point/scale words differ')
        for order in range(2):
            lv=[Fraction(_value(w)) for w in left['rawANS'][order]]
            rv=[Fraction(_value(w)) for w in right['rawANS'][order]]
            finite=max(abs(lv[1]),abs(rv[1]),Fraction(1e-99))
            for component,(a,b) in enumerate(zip(lv,rv)):
                magnitude=max(abs(a),abs(b));denom=abs(a+b)
                symmetric=abs(a-b)/denom if denom else Fraction(0) if not magnitude else None
                pole=magnitude/finite if component>=2 else None
                accepted=lambda bound:(symmetric is not None and symmetric<bound) or (pole is not None and pole<bound)
                passed=accepted(tol);target=target and accepted(goal)
                row={'point_id':left['point_id'],'order':order,'component':component,
                     'legacy_word':left['rawANS'][order][component],'candidate_word':right['rawANS'][order][component],
                     'bitwise_equal':left['rawANS'][order][component]==right['rawANS'][order][component],
                     'symmetric_relative_error':_ratio(symmetric) if symmetric is not None else None,
                     'symmetric_ratio_defined':symmetric is not None,'pole_to_finite':_ratio(pole) if pole is not None else None,
                     'relative_error':_ratio(abs(a-b)/magnitude) if magnitude else 0.0,'passed':passed}
                residuals.append(row)
                if not passed:failures.append(row)
    return {'schema':'ordinary-cms-comparison-v1','report_only':True,'passed':not failures,
            'criterion':'LoopMEComparator abs(a-b)/abs(a+b)<tolerance OR pole magnitude/finite maximum<tolerance; exact rational binary64 arithmetic',
            'tolerance':tolerance,'ordinary_target_tolerance':1e-8,'ordinary_target_passed':target,
            'residuals':residuals,'failures':failures,
            'accuracy_words':[{'point_id':a['point_id'],'legacy':a['rawACC'],'candidate':b['rawACC']} for a,b in zip(legacy['measurements'],candidate['measurements'])],
            'actual_statuses':[{'point_id':a['point_id'],'legacy':a['status'],'candidate':b['status']} for a,b in zip(legacy['measurements'],candidate['measurements'])],
            'independent_finite_truth':False,'full_caller_qualified':False,'scientifically_qualified':False,
            'accuracy_qualified':False,'performance_qualified':False}
