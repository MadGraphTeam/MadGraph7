"""Real closed BUILD binding; file reads occur only when explicitly called."""
from pathlib import Path
import hashlib
import json
import types

COMPILED_SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
BUILD_TERMINAL='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44'
BUILD_RESULT='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137'
GATE='.tirust-build/generic-owned-CMS-cache-root-reviewed-build-1.json'
GATE_SHA='c379a5e6f61d5464c786b327c3e99b2f0101a729b22a6ae5849957542dbdfbc5'
REVIEW_SHA='c88fe3bb30543c01c77d5d6d4b4af3b82a14944a5814b39d790a26522e4c1238'
INVENTORY_SHA='2d1b38cf2de4b661d47d1e610a7a0c84a762511c9aab0582ff0a8f987bbace13'
COMPILED_HERE='.tirust-build/generic-owned-CMS-cache-qualification-proposal-1'
COMPILED_WORK='.tirust-build/generic-owned-CMS-cache-qualification-work-1'


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())


def validate_review_documents(gate,terminal,result,review,*,gate_sha,terminal_sha,result_sha,review_sha,inventory_sha):
    """Pure negative-testable checks; no invented future review or admission."""
    require((gate_sha,terminal_sha,result_sha,review_sha,inventory_sha)==
            (GATE_SHA,BUILD_TERMINAL,BUILD_RESULT,REVIEW_SHA,INVENTORY_SHA),'closed gate/BUILD/review/inventory bytes changed')
    require(gate['schema']=='root-reviewed-CMS-cache-build-v1' and gate['build_accepted'] is True
            and gate['independent_review_accepted'] is True,'root has not accepted this closed BUILD')
    require(gate['compiled_source_index_sha256']==COMPILED_SOURCE and gate['build_terminal_sha256']==BUILD_TERMINAL
            and gate['build_result_sha256']==BUILD_RESULT and gate['independent_review_sha256']==REVIEW_SHA
            and gate['raw_command_inventory_sha256']==INVENTORY_SHA,'root gate joins wrong evidence')
    require(gate['RUN_admitted'] is False and not gate['runtime_cache_qualified'] and not gate['amplitude_parity_qualified']
            and not gate['independent_physical_truth'] and not gate['production_promoted'],'BUILD gate must not invent runtime qualification')
    require(terminal['phase']=='build' and terminal['status']=='passed' and terminal['returncode']==0
            and terminal['result_sha256']==BUILD_RESULT and not terminal['cleanup']['survivors']
            and not terminal['cleanup']['events'],'BUILD terminal not cleanly closed')
    require(terminal['cap_seconds']==1800 and terminal['cleanup_reserve_seconds']==60,'BUILD bounds changed')
    require(result['status']=='passed' and result['source_index_sha256']==COMPILED_SOURCE
            and set(result['variants'])=={'plain','observed'},'wrong actual compiled source/arms')
    require(all(result[key]==0 for key in ('native_main_calls','model_calls','reducer_calls')),'scientific execution hidden in BUILD')
    require(review['status']=='passed-closed-BUILD-only' and review['source_index_sha256']==COMPILED_SOURCE
            and review['build_terminal_sha256']==BUILD_TERMINAL and review['build_result_sha256']==BUILD_RESULT
            and review['new_native_queries_or_execution_by_reviewer']==0 and not review['blockers'],'independent BUILD review not closed/clear')
    require(review['artifacts']['raw-command-inventory.json']['sha256']==INVENTORY_SHA,'review/raw command inventory mismatch')
    for arm,row in result['variants'].items():
        require(review['variants'][arm]['ELF_sha256']==row['sha256'] and review['variants'][arm]['providers']==15,'actual ELF/provider review mismatch')
    return True


def accepted_gate(root):
    """Read only actual, existing root-specified gate and closed evidence."""
    root=Path(root);gatepath=root/GATE
    require(not gatepath.is_symlink() and digest(gatepath)==GATE_SHA,'changed actual root BUILD gate')
    gate=read(gatepath);documents={}
    for key,sha in (('build_terminal',BUILD_TERMINAL),('build_result',BUILD_RESULT),
                    ('independent_review',REVIEW_SHA),('raw_command_inventory',INVENTORY_SHA)):
        relative=Path(gate[key])
        require(not relative.is_absolute() and '..' not in relative.parts,'gate path escape')
        path=root/relative
        require(not path.is_symlink() and path.is_file() and digest(path)==sha,'closed gate evidence changed '+key)
        documents[key]=read(path)
    validate_review_documents(gate,documents['build_terminal'],documents['build_result'],documents['independent_review'],
        gate_sha=GATE_SHA,terminal_sha=BUILD_TERMINAL,result_sha=BUILD_RESULT,review_sha=REVIEW_SHA,inventory_sha=INVENTORY_SHA)
    return gate,documents['build_result']


def verify_live(b,compiled_module):
    # Authenticate root acceptance and independent raw inventory BEFORE the
    # frozen verifier is allowed to inspect the real compiled family.
    gate,recorded=accepted_gate(b.ROOT)
    run_identity=(b.HERE,b.WORK,b.EXPECTED_SOURCE,b.REVIEWED_BUILD)
    require(b.REVIEWED_BUILD==BUILD_TERMINAL,'exact separately reviewed BUILD terminal required')
    proxy=types.SimpleNamespace(**vars(b))
    proxy.HERE=b.ROOT/COMPILED_HERE;proxy.WORK=b.ROOT/COMPILED_WORK
    proxy.EXPECTED_SOURCE=COMPILED_SOURCE;proxy.REVIEWED_BUILD=BUILD_TERMINAL
    actual=compiled_module.verified_build(proxy)
    require(actual==recorded,'current compiled artifacts differ from accepted closed result')
    require((b.HERE,b.WORK,b.EXPECTED_SOURCE,b.REVIEWED_BUILD)==run_identity,'RUN identity was replaced by compiled identity')
    return {'compiled_source_sha256':COMPILED_SOURCE,'terminal_sha256':BUILD_TERMINAL,'result_sha256':BUILD_RESULT,
            'root_BUILD_gate_sha256':GATE_SHA,'independent_BUILD_review_sha256':REVIEW_SHA,
            'raw_command_inventory_sha256':INVENTORY_SHA,'variants':actual['variants'],
            'RUN_admission_granted_by_BUILD_gate':False,'independent_physical_truth':False}
