"""Synthetic-only comparisons. No worker/parser/model/build paths are loaded."""
from copy import deepcopy
from pathlib import Path
from contextlib import ExitStack
import builtins
from fractions import Fraction
import io
import json
import struct
import types
import unittest

HERE=Path(__file__).resolve().parent
c=types.ModuleType('_cache_comparison_synthetic');c.__file__=str(HERE/'cache_comparison.py')
exec(compile((HERE/'cache_comparison.py').read_bytes(),c.__file__,'exec'),c.__dict__)


def word(value):return struct.pack('>d',value).hex().upper()
def value(token):
    if (int(token,16)>>52)&2047==2047:return None
    return struct.unpack('>d',bytes.fromhex(token))[0]
def ratio(number):
    try:return float(number)
    except OverflowError:return None


def record(phase,index,pid,bootstrap=False):
    state=[0,1]+[0]*13;code=239 if bootstrap else 219
    return {'phase':phase,'call_index':index,'point_id':pid,'code':code,'class':1 if bootstrap else 2,
        'status':{'code':code,'H':2,'T':3 if bootstrap else 1,'U':9,'actual_backend':9,
                  'actual_precision':'DP','actual_alias':[9,'DP'],'valid_range':True},
        'rawP':[[word(float(pid+leg+mu)) for mu in range(4)] for leg in range(4)],'rawMUR':word(1000.),
        'rawANS':[[word(v) for v in (1.,2.,.2,.1)] for _ in range(2)],'rawACC':[word(1e-9)]*2,
        'state_before':None if bootstrap else state.copy(),'state_after':state.copy(),
        'streak':0 if bootstrap or phase=='RUN' else index,'finite_outputs':True,'accuracy_available':True,
        'unsupported_state':[],'nonfinite':[],'negative_accuracy':[],'issues':[],
        'accepted_for_continuation':True}


def analysis(ids=(1,7,12)):
    records=[record('LEARN',0,1,True)]+[record('LEARN',i,i) for i in range(1,13)]
    return {'schema':'normal-cms-raw64-analysis-v1','lane':'candidate','pid':123,'raw_sha256':'old',
        'driver_sha256_required':'driver','request_ids':list(ids),'accepted_for_continuation':True,
        'learning':{'success':True,'ready':True,'streak':12,'outer_calls':13,'terminal':['LEARNED',1,12,12,219],
                    'issues':[],'all_training_ids_seen':True,'records':records},
        'measurements':[record('RUN',i,p) for i,p in enumerate(ids,1)]}


def journal(point=20,mode=1):
    frame={'group':3,'width':64 if mode<4 else 128,'ctmode':mode,'rank':2,'legacy':False,
        'native':[[['0'*32]*4 for _ in range(4)] for _ in range(3)],
        'shifts':[['0'*32]*4 for _ in range(4)],'masses':[['0'*32]*2 for _ in range(4)],
        'scale':'0'*32,'native_status':0,'check_pass':mode in (2,5),'cache_enabled':False,
        'matrix_done':True,'native_returned':True,'pairs':[],'boundary':17,'consumer':2}
    return [{'point_id':point,'frames':[frame],'cache':{'events':[{'error_API_text':'diagnostic only'}]}}]


class Comparison(unittest.TestCase):
    def numeric(self,a=None,b=None,**kw):
        return c.compare_policy_numerics(analysis() if a is None else a,analysis() if b is None else b,
                                         word_value=value,ratio=ratio,**kw)

    def test_exact_cache0_and_own_parity_compare_full_history(self):
        for ids in ((1,7,12),(20,),(21,)):
            self.assertTrue(c.compare_exact_histories(analysis(ids),analysis(ids))['passed'])
            self.assertTrue(c.compare_own_parity(analysis(ids),analysis(ids))['passed'])

    def test_only_external_identity_and_observer_error_text_are_outside_normal_core(self):
        a=analysis();b=deepcopy(a);b.update(pid=456,raw_sha256='new',driver_sha256_required='other',
            ELF_maps={'handled':'separately'},observer_error_API_text='not a science record')
        result=c.compare_own_parity(a,b)
        self.assertTrue(result['passed']);self.assertFalse(result['observer_error_API_text_compared'])

    def test_every_own_coefficient_accuracy_status_and_all15_states_are_exact(self):
        base=analysis()
        changed=[]
        b=deepcopy(base);b['learning']['records'][0]['rawANS'][0][1]=word(3.);changed.append(b)
        b=deepcopy(base);b['measurements'][0]['rawACC'][1]=word(2e-9);changed.append(b)
        b=deepcopy(base);b['learning']['terminal'][-1]=323;changed.append(b)
        b=deepcopy(base);b['measurements'][0]['status']['actual_precision']='QP';changed.append(b)
        for i in range(15):
            b=deepcopy(base);b['measurements'][0]['state_after'][i]^=1;changed.append(b)
            b=deepcopy(base);b['learning']['records'][1]['state_before'][i]^=1;changed.append(b)
        for b in changed:
            with self.subTest(change=b):
                result=c.compare_own_parity(base,b)
                self.assertFalse(result['passed']);self.assertTrue(result['differences'])

    def test_missing_suffix_never_disappears_via_zip(self):
        a=analysis();b=analysis((1,))
        result=c.compare_exact_histories(a,b)
        self.assertFalse(result['passed'])
        self.assertTrue(any(d['kind']=='missing-index' for d in result['differences']))
        numeric=self.numeric(a,b)
        self.assertFalse(numeric['passed']);self.assertEqual(len(numeric['unmatched_measurements']),2)
        self.assertFalse(c.compare_own_parity(b,b)['passed'])

    def test_crosspolicy_small_nonbitwise_difference_uses_exact_residual(self):
        a=analysis();b=deepcopy(a)
        old=b['measurements'][0]['rawANS'][0][1]
        b['measurements'][0]['rawANS'][0][1]=f'{int(old,16)+1:016X}'
        result=self.numeric(a,b)
        self.assertTrue(result['passed']);self.assertFalse(result['history_exact'])
        row=next(r for r in result['residuals'] if not r['bitwise_equal'])
        self.assertGreater(Fraction(*row['absolute_difference_exact']),0)
        self.assertEqual(row['cache0_word'],old);self.assertFalse(result['bit_parity_required'])

    def test_status_rescue_accuracy_and_IEEE_differences_are_retained_not_forced_equal(self):
        a=analysis((20,));b=deepcopy(a);row=b['measurements'][0]
        row['code']=323;row['status'].update(code=323,H=3,T=2,U=3,actual_precision='QP',actual_alias=[9,'QP'])
        row['rawACC'][0]=word(2e-9);row['state_after'][14]=1
        result=self.numeric(a,b)
        self.assertTrue(result['passed']);self.assertFalse(result['history_exact'])
        paths=[d['path'] for d in result['history_differences']]
        self.assertTrue(any('actual_precision' in p for p in paths))
        self.assertTrue(any('rawACC' in p for p in paths));self.assertTrue(any('state_after[14]' in p for p in paths))
        self.assertEqual(result['actual_statuses'][0]['cacheall']['code'],323)
        self.assertEqual(result['accuracy_words'][0]['cacheall'][0],word(2e-9))

    def test_large_error_failed_worker_and_nonfinite_do_not_pass(self):
        for change in ('large','failed','nan'):
            a=analysis((21,));b=deepcopy(a)
            if change=='large':b['measurements'][0]['rawANS'][0][1]=word(3.)
            elif change=='failed':b['accepted_for_continuation']=False
            else:b['measurements'][0]['rawANS'][1][1]='7FF8000000000001'
            result=self.numeric(a,b)
            self.assertFalse(result['passed'])
            if change!='failed':self.assertTrue(result['failures'])

    def test_small_poles_and_zero_denominator_match_frozen_component_rule(self):
        a=analysis((20,));b=deepcopy(a)
        a['measurements'][0]['rawANS'][0][2]=word(1e-20)
        b['measurements'][0]['rawANS'][0][2]=word(-1e-20)
        result=self.numeric(a,b);pole=result['residuals'][2]
        self.assertTrue(pole['passed']);self.assertFalse(pole['symmetric_ratio_defined'])
        a['measurements'][0]['rawANS'][0][1]=word(2.)
        b['measurements'][0]['rawANS'][0][1]=word(-2.)
        self.assertFalse(self.numeric(a,b)['passed'])

    def test_different_actual_input_or_scale_is_not_numerical_agreement(self):
        for field in ('rawP','rawMUR'):
            a=analysis();b=deepcopy(a)
            if field=='rawP':b['measurements'][0][field][0][0]=word(99.)
            else:b['measurements'][0][field]=word(2000.)
            result=self.numeric(a,b)
            self.assertFalse(result['passed']);self.assertFalse(result['target_1e8_passed'])
            self.assertIn('input/scale',result['failures'][0]['reason'])

    def test_native_contexts_words_status_and_unmatched_frames_are_retained(self):
        a=journal();b=deepcopy(a);b[0]['frames'][0]['cache_enabled']=True
        b[0]['cache']['events'][0]['error_API_text']='changed diagnostic'
        native=c.compare_native_journals(a,b)
        self.assertFalse(native['scientific_differences']);self.assertTrue(native['policy_differences'])
        b[0]['frames'][0]['native'][2][1][3]='0'*31+'1'
        b[0]['frames'][0]['native_status']=1;b[0]['frames'][0]['boundary']=18
        native=c.compare_native_journals(a,b)
        paths=[d['path'] for d in native['scientific_differences']]
        self.assertTrue(any('native[2][1][3]' in p for p in paths))
        self.assertIn('native_status',paths);self.assertIn('boundary',paths)
        b[0]['frames'].append(journal(mode=4)[0]['frames'][0])
        self.assertEqual(len(c.compare_native_journals(a,b)['unmatched']),1)

    def test_invalid_shapes_and_missing_callbacks_refuse(self):
        a=analysis();b=deepcopy(a);b['measurements'][0]['state_after'].pop()
        with self.assertRaises(ValueError):c.compare_own_parity(a,b)
        b=deepcopy(a);b['measurements'][0]['rawANS'][0][0]='nothex'
        with self.assertRaises(ValueError):self.numeric(a,b)
        with self.assertRaises(ValueError):c.compare_policy_numerics(a,a,word_value=None,ratio=ratio)
        with self.assertRaises(ValueError):c.compare_native_journals(journal(),None)

    def test_inputs_not_mutated_and_no_accuracy_or_truth_promotion(self):
        a=analysis((21,));b=deepcopy(a);saved=deepcopy((a,b))
        result=self.numeric(a,b,journals0=journal(21),journals_all=journal(21))
        self.assertEqual((a,b),saved)
        for key in ('independent_finite_truth','accuracy_qualified','scientifically_qualified','performance_qualified'):
            self.assertIs(result[key],False)


def main():
    import ctypes
    import os
    import subprocess
    from unittest.mock import patch
    attempts=[]
    def deny(*args,**kwargs):attempts.append('process/native/file');raise RuntimeError('synthetic-only comparison boundary')
    log=io.StringIO()
    with ExitStack() as stack:
        for name in ('Popen','run','call','check_call','check_output'):stack.enter_context(patch.object(subprocess,name,deny))
        for name in ('system','popen','fork','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'):
            if hasattr(os,name):stack.enter_context(patch.object(os,name,deny))
        for name in ('CDLL','PyDLL'):stack.enter_context(patch.object(ctypes,name,deny))
        stack.enter_context(patch.object(ctypes.cdll,'LoadLibrary',deny))
        # Fixtures and module are in memory before this guard; even reads are forbidden.
        stack.enter_context(patch.object(builtins,'open',deny));stack.enter_context(patch.object(io,'open',deny))
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Comparison))
    print(log.getvalue(),end='')
    print(json.dumps({'status':'pass' if result.wasSuccessful() and not attempts else 'fail','tests':result.testsRun,
        'forbidden_api_attempts':attempts,'native_calls':0,'model_calls':0,'future_build_reads':0,
        'scientific_dispatch_enabled':False},sort_keys=True))
    return result.wasSuccessful() and not attempts


if __name__=='__main__':raise SystemExit(0 if main() else 1)
