"""Bounded integer-only observer journal and same-lane plain parity analysis.

No FP diagnostic reevaluation, I/O or project imports. Controller injects the
unchanged frozen normal RAW64 parser and authenticates source/ELF/protocol/DONE.
"""
import hashlib
import re

OBSERVER_PARENT_SHA='64a490c1a21f84669ee617dc2351a4f04662654f5dc7cad6c9023c0d67410f9a'
WIRE_PARENT_SHA='9fad9574ced2ca9df36e59638118358095fc3b1564318e4c34dd2ec49dce87eb'
COMPILED_DISPATCH_SHA='9d9bb443b8b10724811d92c19e83653df475721fadcfbb770aa7412cc23cb612'
DP_RESETS={10476,10925,10967,10978,10987,11030,11168,11513,11529,11541,11800,30109}
QP_RESETS={10478,10927,10969,10980,10989,11032,11170,11175,11515,11531,11543,11802,10179,30095}
BOTH_RESETS={1,205,208,20932,20994}
NO_RESET={300}
KNOWN_BOUNDARIES=DP_RESETS|QP_RESETS|BOTH_RESETS|NO_RESET|{2}
STAGES=['original','match_attempt','match_pass','built','raw_attempt','raw_pass',
        'cert_attempt','cert_return','exact_attempt','exact_pass','final_attempt',
        'final_return','direct_assigned','pair_complete']
INTEGER=re.compile(r'-?(?:0|[1-9][0-9]*)\Z')
WORD=re.compile(r'[0-9A-F]{32}\Z')

class ObserverError(ValueError):
    def __init__(self,message,raw_text='',evidence=None):
        super().__init__(message)
        self.raw_text=raw_text;self.evidence=evidence
        self.raw_sha256=hashlib.sha256(raw_text.encode('utf-8',errors='surrogatepass')).hexdigest()


def _fail(message,raw,evidence=None):raise ObserverError(message,raw,evidence)

def _require_compiled_dispatch(source,raw):
    # Immutable BYTES, never a path/boolean claim. ELF/source join is external.
    if type(source) is not bytes or hashlib.sha256(source).hexdigest()!=COMPILED_DISPATCH_SHA:
        _fail('owned frame requires exact pinned compiled dispatch-source bytes',raw)
    return COMPILED_DISPATCH_SHA


def _finite(word,width):
    return ((int(word,16)>>(52 if width==64 else 112)) & (2047 if width==64 else 32767)) != (2047 if width==64 else 32767)

def _zero(word,width):return int(word,16)&((1<<(width-1))-1)==0

def _point_valid(words,width):
    return all(int(pair[1],16)==0 and _finite(pair[0],width) and
               (width==128 or all(int(w,16)<1<<64 for w in pair)) for leg in words for pair in leg)

class _Reader:
    def __init__(self,text):self.text=text;self.lines=text.splitlines();self.pos=0
    def fail(self,message):_fail(f'journal line{self.pos+1}: {message}',self.text)
    def row(self,tag,n):
        if self.pos>=len(self.lines):self.fail('truncated '+tag)
        line=self.lines[self.pos];self.pos+=1
        fields=line.split()
        if len(fields)!=n+1 or not fields or fields[0]!=tag or line.strip()!=line:self.fail('wrong tag/cardinality '+tag)
        return fields[1:]
    def integer(self,token):
        if not INTEGER.fullmatch(token):self.fail('noncanonical integer')
        result=int(token)
        if not -(1<<31)<=result<1<<31:self.fail('default INTEGER overflow')
        return result
    def ints(self,tag,n):return [self.integer(x) for x in self.row(tag,n)]
    def words(self,tag,keys,n,width=128):
        fields=self.row(tag,len(keys)+n)
        if [self.integer(x) for x in fields[:len(keys)]]!=list(keys):self.fail('wrong/duplicate/reordered keys '+tag)
        result=fields[len(keys):]
        if any(not WORD.fullmatch(x) for x in result):self.fail('noncanonical raw128 word '+tag)
        if width==64 and any(int(x,16)>=1<<64 for x in result):self.fail('DP word not zero extended '+tag)
        return result
    def flags(self,values):
        if any(x not in (0,1) for x in values):self.fail('logical not0/1')
        return [bool(x) for x in values]
    def points(self,tag,index,width):
        return [[self.words(tag,[index,leg,mu],2,width) for mu in range(4)] for leg in range(1,5)]


def _pair_checks(pair,frame,raw):
    bit=pair['stage'];has=lambda n:bit[n-1]
    def need(condition,message):
        if not condition:_fail('pair provenance: '+message,raw,{'frame':frame['index'],'pair':[pair['i'],pair['j']]})
    need(has(14),'pair completion absent')
    diagonal=pair['i']==pair['j']
    need(has(1)==(not diagonal),'original raw presence does not match diagonal')
    need(pair['mass_present']==(not diagonal),'mass-snap observation presence')
    if diagonal:need(not any(bit[:13]),'candidate stage on diagonal')
    if frame['legacy']:
        need(not any(bit[1:13]),'owned stages on public fallback')
        need(not pair['used'] and not pair['built_present'] and not pair['consumed_present'] and not pair['env_present'] and not pair['cert_ok'] and not pair['final_ok'],'legacy inferred owned payload')
        return
    for later,earlier in [(3,2),(4,3),(5,4),(6,5),(7,6),(9,7),(10,9),(11,10)]:
        need(not has(later) or has(earlier),f'stage{later} lacks{earlier}')
    need(has(8)==has(7),'certifier attempt/normal return mismatch')
    need(has(12)==has(11),'final attempt/normal return mismatch')
    need(pair['built_present']==has(4)==pair['env_present'],'built/environment presence mismatch')
    need(not pair['consumed_present'] or (has(7) and has(8) and pair['built_present']),'consumed payload without certifier path')
    need(not has(9) or pair['consumed_present'],'exact attempt without consumed words')
    need(not pair['cert_ok'] or has(8),'cert result without return')
    need(not pair['final_ok'] or has(12),'final result without return')
    need(pair['cert_ok']==pair['final_ok']==pair['used']==has(13),'actual success/veto flags disagree')
    if has(2):
        need(frame['ready'] and frame['refwidth']==frame['width'] and pair['class']==2 and not pair['mass_snap'],'matcher preconditions')
        real,imag=pair['original'];width=frame['width']
        need(_finite(real,width) and _zero(imag,width) and not _zero(real,width) and int(real,16)>>(width-1)==1,'original is not negative finite real')
    if has(3):
        need(frame['current_ok'] and all(frame['mask']) and frame['reference']==frame['current'],'point-match words/masks')
        need(_point_valid(frame['reference'],frame['width']) and _point_valid(frame['current'],frame['width']),'point-match canonical finite leaves')
        need(frame['width']==64 or frame['genuine'],'QP point match without actual genuine flag')
    if has(5):need(pair['env_ok'] and pair['env'][0]==pair['env'][1],'raw attempt without observed valid stable environment')
    if has(6):need(pair['built_raw']==pair['original'],'raw-pass bit contradicts complete raw words')
    if pair['consumed_present']:
        need(pair['consumed_q']==pair['built_q'] and pair['consumed_raw']==pair['built_raw'],'consumed materialization changed')
    if pair['used']:
        need(all(has(n) for n in range(2,14)),'veto missing success path')
        need(pair['direct']==pair['built_raw'][0]==pair['consumed_raw'][0],'direct not exact consumed real raw')


def _validate_native(frame,raw):
    first,second,third=frame['native']
    if second!=third:_fail('native stages2/3 differ',raw,{'frame':frame['index']})
    all_finite=all(_finite(w,frame['width']) for row in first for w in row)
    for j in range(4):
        for i in range(4):
            expected=first[j][i]
            if i>j and all_finite:
                upper=first[i][j]
                if expected!=upper and not (_zero(expected,frame['width']) and _zero(upper,frame['width'])):expected=upper
            if second[j][i]!=expected:_fail('native symmetry copy contradicts observed words',raw,{'frame':frame['index'],'i':i+1,'j':j+1})
            pair=frame['pairs'][j*4+i]
            if pair['used'] and first[j][i]!=pair['direct']:_fail('native direct selection contradicts recorded direct word',raw)
    if frame['ploop']!=frame['shifts']:_fail('actual PLOOP/SHIFT views differ',raw)


def parse_journal(text, *, sequence,request,point_id,compiled_dispatch_source=None,cache_policy=None,cache_budget=None):
    if type(cache_policy) is not int or cache_policy < -1 or type(cache_budget) is not int or cache_budget < 0:_fail('explicit cache policy/budget required',text)
    """Strict complete group3 drain. Faults/partial/unknown payload refuse."""
    if not isinstance(text,str) or not text.isascii() or not text.endswith('\n') or len(text)>64*1024*1024:_fail('bounded complete ASCII journal required',text if isinstance(text,str) else '')
    r=_Reader(text);begin=r.ints('OBS_BEGIN',8)
    seq,req,point,fault,np,nc,nf,nb=begin
    if [seq,req,point]!=[sequence,request,point_id] or not (0<=np<=4096 and 0<=nc<=128 and 0<=nf<=128 and 0<=nb<=256):r.fail('journal cohort/count bounds')
    if fault:r.fail('observer already faulted')
    boundaries=[]
    for index in range(1,nb+1):
        row=r.ints('OBS_BOUNDARY',2)
        if row[0]!=index:r.fail('boundary order')
        boundaries.append(row[1])
    producers=[]
    for index in range(1,np+1):
        row=r.ints('OBS_PRODUCER',16)
        if row[0]!=index or row[1] not in (1,2,3) or row[2] not in (64,128) or row[4] not in range(1,5) or not 0<=row[5]<=nb:r.fail('producer coordinates')
        flags=r.flags(row[6:]);width=row[2]
        producers.append({'index':index,'stage':row[1],'width':width,'h':row[3],'leg':row[4],'boundary':row[5],
                          'ok':flags[0],'genuine':flags[1],'valid':flags[2:6],'pending_valid':flags[6:10],
                          'reference':[], 'pending':[]})
        p=producers[-1]
        for leg in range(1,5):
            refs=[];pending=[]
            for mu in range(4):
                refs.append(r.words('OBS_PREF',[index,leg,mu],2,width));pending.append(r.words('OBS_PENDING',[index,leg,mu],2,width))
            p['reference'].append(refs);p['pending'].append(pending)
    if np%3:r.fail('incomplete producer triplet')
    for offset in range(0,np,3):
        a,b,c=producers[offset:offset+3]
        if [p['stage'] for p in (a,b,c)]!=[1,2,3] or any([p[k] for k in ('width','h','leg','boundary','genuine')]!=[a[k] for k in ('width','h','leg','boundary','genuine')] for p in (b,c)):r.fail('not one actual prepare/normal-return/commit triplet')
        if any(a[k]!=b[k] for k in ('ok','reference','pending','valid','pending_valid')):r.fail('constructor changed owned integer buffers')
        leg=c['leg']-1
        if c['ok'] and (not a['ok'] or not a['pending_valid'][leg] or a['valid'][leg] or not _point_valid([a['pending'][leg]],c['width']) or not c['valid'][leg] or c['pending_valid'][leg] or any(int(w,16) for pair in c['pending'][leg] for w in pair) or c['reference'][leg]!=a['pending'][leg] or (c['width']==128 and not c['genuine'])):r.fail('successful commit contradicts recorded pending/reference')
        entries=[i+1 for i,code in enumerate(boundaries[:c['boundary']]) if code==1]
        entry=entries[-1] if entries else 0
        batch=c['boundary']>0 and boundaries[c['boundary']-1]==(30109 if c['width']==64 else 30095)
        mp=[i+1 for i,code in enumerate(boundaries[:c['boundary']]) if code==2 and i+1>entry]
        c['capture_control_complete']=bool(entry and batch and all(code in KNOWN_BOUNDARIES for code in boundaries[entry-1:c['boundary']]) and (c['width']==64 or mp))
        c['entry_boundary']=entry;c['mp_entry_boundary']=mp[-1] if mp else None
    consumers=[]
    for index in range(1,nc+1):
        row=r.ints('OBS_CONSUMER',17)
        if row[0]!=index or not 0<=row[4]<=nb:r.fail('consumer order/boundary')
        flags=r.flags(row[5:]);c={'index':index,'h':row[1],'so':row[2],'ctmode':row[3],'boundary':row[4],
              'snapshot':flags[0],'genuine':flags[1],'ok':{64:flags[2],128:flags[3]},'masks':{64:flags[4:8],128:flags[8:12]},
              'joins':[],'reference':{64:[],128:[]},'current':{64:[],128:[]},'provenance':{64:[],128:[]}}
        for leg in range(1,5):
            join=r.ints('OBS_COMMIT_JOIN',4)
            if join[:2]!=[index,leg]:r.fail('commit join keys')
            c['joins'].append(join[2:])
            if not c['snapshot']:continue
            cols={64:[],128:[]};cur={64:[],128:[]}
            for mu in range(4):
                cols[64].append(r.words('OBS_CREF_DP',[index,leg,mu],2,64));cols[128].append(r.words('OBS_CREF_QP',[index,leg,mu],2))
                cur[64].append(r.words('OBS_CURRENT_DP',[index,leg,mu],2,64));cur[128].append(r.words('OBS_CURRENT_QP',[index,leg,mu],2))
            for width in (64,128):c['reference'][width].append(cols[width]);c['current'][width].append(cur[width])
        for width in (64,128):
            for leg in range(4):
                join=c['joins'][leg][0 if width==64 else 1]
                if not 0<=join<=np:r.fail('commit index outside recorded producers')
                p=producers[join-1] if join else None
                if p and (p['stage']!=3 or not p['ok'] or p['width']!=width or p['leg']!=leg+1 or p['boundary']>c['boundary']):r.fail('commit join is not correct successful prior producer')
                if not c['snapshot'] or not c['masks'][width][leg]:continue
                if not p or c['reference'][width][leg]!=p['reference'][leg]:r.fail('valid reference not bound to actual commit')
                interval=boundaries[p['boundary']:c['boundary']]
                reset=DP_RESETS if width==64 else QP_RESETS|{2}
                clean=not any(code in BOTH_RESETS or code in reset for code in interval) and all(code in KNOWN_BOUNDARIES for code in interval)
                entry=any(code==1 for code in boundaries[:p['boundary']])
                c['provenance'][width].append({'leg':leg+1,'commit':join,'producer_h':p['h'],'consumer_h':c['h'],'lifetime_complete':clean and entry and p['capture_control_complete'],
                                                  'entry_boundary':p['entry_boundary'],'mp_entry_boundary':p['mp_entry_boundary']})
        consumers.append(c)
    frames=[]
    for index in range(1,nf+1):
        row=r.ints('OBS_FRAME',24)
        if row[0]!=index or row[1]!=3 or row[2] not in (64,128) or not 1<=row[3]<=nc or not 0<=row[4]<=nb or row[5] not in (0,64,128):r.fail('frame identity/scope')
        flags=r.flags(row[8:19]+row[20:24]);width=row[2]
        f={'index':index,'group':3,'width':width,'consumer':row[3],'boundary':row[4],'refwidth':row[5],'ctmode':row[6],'rank':row[7],
           'legacy':flags[0],'ready':flags[1],'current_ok':flags[2],'genuine':flags[3],'mask':flags[4:8],
           'native_present':flags[8:11],'native_status':row[19],'check_pass':flags[11],'cache_enabled':flags[12],'matrix_done':flags[13],'native_returned':flags[14],
           'reference':[],'current':[],'ploop':[],'shifts':[],'masses':[],'pairs':[],'native':[[[None]*4 for _ in range(4)] for _ in range(3)]}
        if not all(f['native_present']) or not f['matrix_done'] or not f['native_returned']:r.fail('incomplete actual native frame')
        if (f['width']==64 and f['ctmode'] not in (1,2)) or (f['width']==128 and f['ctmode'] not in (4,5)):r.fail('unsupported/mismatched actual mode/precision dispatch')
        c=consumers[f['consumer']-1]
        if f['ctmode']!=c['ctmode'] or f['boundary']<c['boundary'] or f['check_pass']!=(f['ctmode'] in (2,5)) or f['cache_enabled']!=(cache_policy==-1 or 4<=cache_policy):r.fail('frame current mode/check/cache cohort')
        for leg in range(1,5):
            refs=[];current=[];pl=[];shift=[]
            for mu in range(4):
                refs.append(r.words('OBS_FRAME_REF',[index,leg,mu],2,f['refwidth'] if f['refwidth'] else 128))
                current.append(r.words('OBS_FRAME_CURRENT',[index,leg,mu],2,width))
                pl.append(r.words('OBS_PLOOP',[index,leg,mu],1,width)[0]);shift.append(r.words('OBS_SHIFT',[index,leg,mu],1,width)[0])
            f['reference'].append(refs);f['current'].append(current);f['ploop'].append(pl);f['shifts'].append(shift)
            f['masses'].append(r.words('OBS_MASS',[index,leg],2,width))
        f['scale']=r.words('OBS_SCALE',[index],1,width)[0]
        f['raw_precision_eligibility_flag']=f['genuine']
        f['actual_consumer_MP_genuine']=c['genuine'] if c['snapshot'] else None
        f['observed_genuine_QP']=None
        f['precision_eligibility_semantics']='public fallback; no owned eligibility evidence'
        f['compiled_dispatch_source_sha256']=None
        if not f['legacy']:
            f['compiled_dispatch_source_sha256']=_require_compiled_dispatch(compiled_dispatch_source,text)
            if not c['snapshot'] or f['reference']!=c['reference'][width] or f['current']!=c['current'][width] or f['mask']!=c['masks'][width] or f['current_ok']!=c['ok'][width]:r.fail('owned frame not bound to actual width-selected consumer')
            if width==64:
                f['precision_eligibility_semantics']='typed DP caller constant TRUE; not current-QP evidence'
                if not f['genuine']:r.fail('owned DP frame lacks pinned caller TRUE eligibility sentinel')
            else:
                f['precision_eligibility_semantics']='actual current-QP flag forwarded from consumer'
                if f['genuine']!=c['genuine']:r.fail('owned QP flag not bound to actual consumer MP genuine flag')
                f['observed_genuine_QP']=c['genuine']
        for j in range(1,5):
            for i in range(1,5):
                pair=r.ints('OBS_PAIR',18)
                if pair[:3]!=[index,i,j] or not 0<=pair[8]<1<<14:r.fail('pair keys/stage mask')
                fl=r.flags(pair[9:]);bits=pair[8]
                a={'i':i,'j':j,'class':pair[3],'coeff':pair[4:8],'stage_bits':bits,'stage':[bool(bits&(1<<s)) for s in range(14)],
                   'mass_present':fl[0],'mass_snap':fl[1],'cert_ok':fl[2],'final_ok':fl[3],'used':fl[4],'env_present':fl[5],'env_ok':fl[6],'built_present':fl[7],'consumed_present':fl[8]}
                a['original']=r.words('OBS_ORIGINAL_RAW',[index,i,j],2,width) if a['stage'][0] else None
                a['env']=r.words('OBS_ENV',[index,i,j],2,64) if a['env_present'] else None
                bq=[];cq=[]
                for mu in range(4):
                    if a['built_present']:bq.append(r.words('OBS_BUILT_Q',[index,i,j,mu],2,width))
                    if a['consumed_present']:cq.append(r.words('OBS_CONSUMED_Q',[index,i,j,mu],2,width))
                a['built_q']=bq if a['built_present'] else None;a['consumed_q']=cq if a['consumed_present'] else None
                a['built_raw']=r.words('OBS_BUILT_RAW',[index,i,j],2,width) if a['built_present'] else None
                a['consumed_raw']=r.words('OBS_CONSUMED_RAW',[index,i,j],2,width) if a['consumed_present'] else None
                a['smat']=r.words('OBS_SMAT',[index,i,j],2,width) if a['stage'][13] else None
                a['direct']=r.words('OBS_DIRECT',[index,i,j],1,width)[0] if a['stage'][12] else None
                for stage in range(1,4):f['native'][stage-1][j-1][i-1]=r.words('OBS_NATIVE',[index,stage,i,j],1,width)[0]
                _pair_checks(a,f,text);f['pairs'].append(a)
        _validate_native(f,text)
        f['producer_lifetime_complete']=(not f['legacy'] and len(c['provenance'][width])==4 and all(x['lifetime_complete'] for x in c['provenance'][width]))
        for pair in f['pairs']:
            st=pair['stage']
            pair['decisions']={'match':None if not st[1] else st[2],'raw_equal':None if not st[4] else st[5],
                               'exact_equal':None if not st[8] else st[9],'certifier':None if not st[7] else pair['cert_ok'],
                               'final_certificate':None if not st[11] else pair['final_ok']}
        if any(p['used'] for p in f['pairs']):
            joined=c['provenance'][width]
            if len(joined)!=4 or not all(j['lifetime_complete'] for j in joined):r.fail('observed veto has unknown/stale producer lifetime')
        frames.append(f)
    cache_observations=parse_cache_rows(r,policy=cache_policy,budget=cache_budget,consumers=consumers,frames=frames,boundaries=boundaries,source_widths=SOURCE_WIDTHS)
    prior=''.join(text.splitlines(keepends=True)[:r.pos])
    footer=r.ints('OBS_END',7)
    if footer[:6]!=[seq,0,np,nc,nf,nb] or footer[6]!=len(prior.encode('ascii')) or r.pos!=len(r.lines):r.fail('footer fault/count/byte coverage mismatch')
    return {'schema':'cms-observer-journal-v1','sequence':seq,'request':req,'point_id':point,
            'raw_sha256':hashlib.sha256(text.encode()).hexdigest(),'raw_bytes':len(text),
            'boundaries':boundaries,'producers':producers,'consumers':consumers,'frames':frames,'cache_observations':cache_observations,
            'coverage_complete':bool(frames),'owned_frames':sum(not f['legacy'] for f in frames),
            'public_fallback_frames':sum(f['legacy'] for f in frames),
            'observed_veto_count':sum(p['used'] for f in frames for p in f['pairs']),
            'drain_success_requires_external_DONE_join':True,'full_caller_qualified':False,'scientifically_qualified':False}


def _split(raw):
    if not isinstance(raw,str) or not raw.isascii() or not raw.endswith('\n'):_fail('complete ASCII RAW required',raw if isinstance(raw,str) else '')
    lines=raw.splitlines(keepends=True);normal=[];journals=[];i=0
    while i<len(lines):
        line=lines[i]
        if line.startswith('OBS_BEGIN '):
            if not any(x.startswith('LEARNED ') for x in normal):_fail('journal enabled during learning',raw)
            start=i
            while i<len(lines) and not lines[i].startswith('OBS_END '):
                if i>start and lines[i].startswith('OBS_BEGIN '):_fail('nested journal',raw)
                i+=1
            if i>=len(lines):_fail('missing journal footer',raw)
            i+=1
            if i>=len(lines) or not lines[i].startswith('CALL RUN '):_fail('drain lacks immediate RAW_RUN/DONE cohort',raw)
            journals.append(''.join(lines[start:i]));continue
        if line.startswith('OBS_'):_fail('orphan observer record',raw)
        normal.append(line);i+=1
    return ''.join(normal),journals


def _differences(left,right,path='',out=None):
    if out is None:out=[]
    if type(left) is not type(right):out.append({'path':path,'plain':left,'observed':right});return out
    if isinstance(left,dict):
        for key in sorted(set(left)|set(right)):
            if key not in left or key not in right:out.append({'path':path+'/'+str(key),'plain':left.get(key),'observed':right.get(key)})
            else:_differences(left[key],right[key],path+'/'+str(key),out)
    elif isinstance(left,list):
        if len(left)!=len(right):out.append({'path':path+'/length','plain':len(left),'observed':len(right)})
        for index,(a,b) in enumerate(zip(left,right)):_differences(a,b,path+'/'+str(index),out)
    elif left!=right:out.append({'path':path,'plain':left,'observed':right})
    return out


def analyze_observed(observed_raw,plain_raw, *,lane,request_ids,observed_pid,plain_pid,parse_normal,expected_points=None,compiled_dispatch_source=None,cache_policy=None,cache_budget=None):
    """Strict adapter; any parity/schema/journal refusal raises with evidence."""
    normalized,blocks=_split(observed_raw)
    if 'OBS_' in plain_raw:_fail('plain parity reference contains journal',plain_raw)
    try:
        observed=parse_normal(normalized,lane=lane,request_ids=request_ids,expected_points=expected_points)
        plain=parse_normal(plain_raw,lane=lane,request_ids=request_ids,expected_points=expected_points)
    except Exception as error:
        _fail('frozen normal RAW parser refused: '+str(error),observed_raw,{'normalized_raw':normalized,'underlying_records':getattr(error,'records',None)})
    if type(observed_pid) is not int or type(plain_pid) is not int or observed_pid<=0 or plain_pid<=0:_fail('positive authenticated PID arguments required',observed_raw)
    if observed['pid']!=observed_pid or plain['pid']!=plain_pid:_fail('RAW/native PID join mismatch',observed_raw)
    evidence={'observed_normal':observed,'plain_normal':plain,'normalized_raw':normalized}
    core=lambda a:{'request_ids':a['request_ids'],'learning':a['learning'],'measurements':a['measurements']}
    differences=_differences(core(plain),core(observed))
    if differences:_fail('plain/observed semantic RAW parity failed',observed_raw,{**evidence,'parity_differences':differences})
    if not observed['accepted_for_continuation']:_fail('unexpected normal RAW failure',observed_raw,evidence)
    if len(blocks)!=len(request_ids):_fail('exact one journal per requested measurement required',observed_raw,evidence)
    journals=[parse_journal(block,sequence=index+1,request=index,point_id=point,compiled_dispatch_source=compiled_dispatch_source,cache_policy=cache_policy,cache_budget=cache_budget) for index,(point,block) in enumerate(zip(request_ids,blocks),1)]
    if any(not j['coverage_complete'] for j in journals):_fail('actual group3 native coverage absent',observed_raw,{**evidence,'journals':journals})
    result=dict(observed)
    result.pop('driver_sha256_required',None)
    veto_count=sum(j['observed_veto_count'] for j in journals)
    result.update(schema='cms-observer-run-analysis-v1',raw_sha256=hashlib.sha256(observed_raw.encode()).hexdigest(),raw_bytes=len(observed_raw),
                  normalized_raw=normalized,normalized_raw_sha256=observed['raw_sha256'],
                  normal_analysis=observed,plain_analysis=plain,journals=journals,
                  parity={'passed':True,'difference_count':0,'all15_state_fields_compared':True,'PID_header_digest_excluded':True},
                  journal_schema_complete=True,journal_provenance_complete=bool(veto_count),
                  observed_veto_count=veto_count,provenance_scope='observed veto branches only; unexecuted/refused/public fallback are unqualified',
                  actual_observed_driver_identity_requires_controller=True,protocol_DONE_join_required=True,
                  full_caller_qualified=False,numerator_qualified=False,scientifically_qualified=False,
                  independent_finite_truth=False,accuracy_qualified=False,performance_qualified=False)
    return result


def compare_native(legacy,candidate):
    """Observed word deltas only; no q/dot/certificate reevaluation."""
    if legacy['lane']!='legacy' or candidate['lane']!='candidate' or legacy['request_ids']!=candidate['request_ids']:raise ValueError('matching legacy/candidate cohorts required')
    ids=legacy['request_ids']
    for evidence in (legacy,candidate):
        journals=evidence.get('journals');rows=evidence.get('measurements')
        if type(journals) is not list or len(journals)!=len(ids) or any(type(j) is not dict for j in journals) or [j.get('point_id') for j in journals]!=ids:
            raise ValueError('exact journal count/point order required')
        if type(rows) is not list or len(rows)!=len(ids) or [row.get('point_id') for row in rows]!=ids:
            raise ValueError('exact normal measurement count/point order required')
    for left,right in zip(legacy['measurements'],candidate['measurements']):
        if left['rawP']!=right['rawP'] or left['rawMUR']!=right['rawMUR']:raise ValueError('native comparison input point/scale differ')
    changes=[];unmatched=[]
    for left,right in zip(legacy['journals'],candidate['journals']):
        def keyed(journal):
            counts={};out={}
            for frame in journal['frames']:
                consumer=journal['consumers'][frame['consumer']-1]
                base=(frame['width'],frame['ctmode'],frame['rank'],frame['check_pass'],consumer['so'],consumer['h'])
                counts[base]=counts.get(base,0)+1;out[base+(counts[base],)]=frame
            return out
        lmap,rmap=keyed(left),keyed(right)
        for key in sorted(set(lmap)|set(rmap)):
            if key not in lmap or key not in rmap:unmatched.append({'point_id':left['point_id'],'key':list(key),'legacy_present':key in lmap,'candidate_present':key in rmap});continue
            a,b=lmap[key],rmap[key]
            for j in range(4):
                for i in range(4):
                    if a['native'][2][j][i]!=b['native'][2][j][i]:
                        pair=b['pairs'][j*4+i]
                        changes.append({'point_id':left['point_id'],'key':list(key),'i':i+1,'j':j+1,'upper_native_consumed':i<j,
                                        'legacy_word':a['native'][2][j][i],'candidate_word':b['native'][2][j][i],
                                        'candidate_veto_observed':pair['used'],'candidate_pair_class':pair['class'],
                                        'candidate_source_upper_veto_observed':b['pairs'][i*4+j]['used'] if i>j else pair['used'],
                                        'candidate_coefficients':pair['coeff'],
                                        'candidate_frame_public_fallback':b['legacy']})
    return {'schema':'cms-observed-native-delta-v1','changes':changes,'unmatched_frames':unmatched,
            'comparison_complete':not unmatched,'report_only':True,'independent_finite_truth':False,
            'full_caller_qualified':False,'scientifically_qualified':False,'accuracy_qualified':False,'performance_qualified':False}

SOURCE_WIDTHS={1: 64, 2: 128, 3: 64, 4: 128, 5: 64, 6: 128, 7: 64, 8: 128, 9: 64, 10: 128}
"""Integer-only parsing of bounded cache observations, never a numerical oracle."""
import re

U64WORD = re.compile(r'[0-9A-F]{16}\Z')


def dp_component(snapshot):
    result = list(snapshot[:9])
    for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4)):
        result[i] -= snapshot[9+j]
    return result


def parse_cache_rows(r, *, policy, budget, consumers, frames, boundaries, source_widths):
    if type(policy) is not int or policy < -1 or type(budget) is not int or budget < 0:
        r.fail('undeclared cache policy/budget')
    count, pending = r.ints('OBS_CACHE_BEGIN', 2)
    if not 0 <= count <= 16384 or pending != 0:
        r.fail('cache count/pending bound')
    events = []
    last = None
    for index in range(1, count + 1):
        row = r.ints('OBS_CACHE_EVENT', 22)
        (key, kind, source, group, consumer, boundary, width, n, rank, mode,
         observed_policy, enabled, check, finite, poles, status, gen_before,
         gen_after, bstat, bqstat, astat, aqstat) = row
        if key != index or kind not in (1, 2, 3):
            r.fail('cache event key/kind')
        if not 0 <= group <= 26 or not 0 <= consumer <= len(consumers) or not 0 <= boundary <= len(boundaries):
            r.fail('cache context coordinate')
        values = r.row('OBS_CACHE_VALUES', 32)
        if r.integer(values[0]) != index or any(not U64WORD.fullmatch(w) for w in values[1:]):
            r.fail('cache uint64 key/word')
        words = [int(w, 16) for w in values[1:]]
        recorded_budget, before, after = words[0], words[1:16], words[16:31]
        error_key, error_length, prefix_extent_unknown = r.ints('OBS_CACHE_ERROR', 3)
        if error_key != index or not 0 <= error_length <= 1024 or prefix_extent_unknown != int(status != 0):
            r.fail('cache error-prefix extent')
        error_hex = ''
        if error_length:
            fields = r.row('OBS_CACHE_ERROR_BYTES', 2)
            if r.integer(fields[0]) != index or not re.fullmatch('[0-9A-F]{'+str(2*error_length)+'}',fields[1]):
                r.fail('cache error-prefix byte encoding')
            error_hex = fields[1]
        if status == 0 and error_length:
            r.fail('successful cache event has a stale failure prefix')
        if gen_before != gen_after or gen_before < -1:
            r.fail('cache context generation changed')
        if gen_before < 0:
            if kind != 3 or [bstat, bqstat, astat, aqstat] != [-777] * 4 or any(before + after):
                r.fail('unused cache context was probed/created')
        elif [bstat, bqstat, astat, aqstat] != [0] * 4:
            r.fail('cache statistics getter refused')
        # eb3 was built with poles-only support: DP and pole stores each get
        # total/4, QP gets total/2. This full-only campaign leaves pole store
        # empty; these are native accounted payload bytes, not an RSS claim.
        for snapshot in (before, after):
            q = snapshot[9:]
            if any(snapshot[i] < q[j] for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4))):
                r.fail('aggregate smaller than its QP component')
            if q[3] > budget//2 or snapshot[7]-q[3] > budget//4:
                r.fail('native cache accounted-byte budget exceeded')
        if last and last['gen_after'] == gen_before and last['after'] != before:
            r.fail('unobserved cache counter transition')
        if kind == 3:
            if source != 0 or any((width, n, rank, mode, observed_policy, enabled, check, finite, poles, recorded_budget)):
                r.fail('cache clear metadata')
            if status != 0 or any(after):
                r.fail('cache clear failed/not empty')
        else:
            if source not in source_widths or gen_before < 0 or recorded_budget != budget:
                r.fail('cache source/budget/context')
            if kind == 2:
                if any((width, n, rank, mode, observed_policy, enabled, check, finite, poles)):
                    r.fail('cache budget metadata')
                if status != 0:
                    r.fail('cache budget setter refused')
                # These workers keep one card/budget throughout normal
                # learning and measurement. A per-call repeat must not reset
                # counters; dynamic in-worker budget switching is unqualified.
                if after != before:
                    r.fail('fixed-budget setter reset/changed numerical cache')
                if budget == 0 and (any(after[6:8]) or any(after[11:13])):
                    r.fail('zero-budget store retained entries')
            else:
                if width != source_widths[source] or not 1 <= n <= 6 or not 0 <= rank <= 6:
                    r.fail('cache native width/topology/rank')
                if mode not in (1, 2, 4, 5) or width != (64 if mode in (1, 2) else 128):
                    r.fail('cache native mode/width')
                if not consumer or group == 0 or consumers[consumer - 1]['ctmode'] != mode:
                    r.fail('cache native consumer mode')
                if observed_policy != policy or enabled != int(policy == -1 or n <= policy):
                    r.fail('cache effective topology policy')
                if check != int(mode in (2, 5)) or finite != 1 or poles != 0:
                    r.fail('cache independent-check/full/pole policy')
                if not last or last['kind'] != 2 or last['source'] != source or last['group'] != group or last['consumer'] != consumer:
                    r.fail('native cache call lacks its successful budget event')
                qb, qa = before[9:], after[9:]
                failure_transition = None
                if width == 64:
                    if qa != qb:
                        r.fail('DP call changed QP cache')
                    if status == 0 and (check or not enabled) and after != before:
                        r.fail('DP independent/disabled call used primary tensor store')
                    if status == 0 and enabled and not check and any(a < b for a, b in zip(after[:9], before[:9])):
                        r.fail('successful DP primary call reset numerical cache')
                    if status != 0:
                        # dp_checked clears its full DP store on reduction
                        # failure, but earlier C/Fortran validation can return
                        # without entering it and preserve prior valid values.
                        if after == before:
                            failure_transition = 'DP_unchanged_or_already_empty'
                        elif not any(dp_component(after)):
                            failure_transition = 'DP_full_store_counters_cleared'
                        else:
                            r.fail('failed DP call neither preserved nor cleared its numerical store')
                elif status == 0 and (check or not enabled):
                    if qa[:5] != qb[:5] or qa[5] != qb[5] + 1 or after[:9] != before[:9]:
                        r.fail('QP independent/disabled call reused/inserted primary cache')
                elif status == 0:
                    delta = [a - b for a, b in zip(qa, qb)]
                    hit = delta == [1, 0, 0, 0, 0, 0]
                    stored = delta[0:3] == [0, 1, 1] and delta[3] > 0 and delta[4:] == [0, 0]
                    refused = delta == [0, 1, 0, 0, 1, 0]
                    if not (hit or stored or refused):
                        r.fail('QP primary call lacks one hit/miss')
                elif status != 0:
                    delta = [a-b for a,b in zip(qa,qb)]
                    before_native = delta == [0]*6
                    failed_miss = enabled and not check and delta == [0,1,0,0,0,0]
                    failed_bypass = (check or not enabled) and delta == [0,0,0,0,0,1]
                    if not any(after):
                        failure_transition = 'QP_all_counters_zero; decode_clear_or_already_empty_compatible'
                    elif dp_component(after) == dp_component(before) and (before_native or failed_miss or failed_bypass):
                        failure_transition = 'QP_no_insert_with_DP_store_unchanged; exact_failure_phase_not_inferred'
                    else:
                        r.fail('failed QP call inserted/altered an unrelated store')
                if width == 128 and status == 0:
                    if after[:4] != before[:4] or any(after[i] - before[i] != qa[j] - qb[j]
                            for i, j in ((4, 0), (5, 1), (6, 2), (7, 3), (8, 4))):
                        r.fail('QP/aggregate counter join')
                if budget == 0 and (any(after[6:8]) or any(after[11:13])):
                    r.fail('zero-budget native call retained entries')
        event = dict(index=index, kind=kind, source=source, group=group, consumer=consumer,
                     boundary=boundary, width=width, n=n, rank=rank, mode=mode,
                     policy=observed_policy, cache_enabled=bool(enabled), check_pass=bool(check),
                     status=status, gen_before=gen_before, gen_after=gen_after,
                     budget=recorded_budget, before=before, after=after,
                     error_prefix_hex=error_hex,error_prefix_extent_unknown=bool(prefix_extent_unknown))
        if kind == 1:
            event['failure_cache_transition'] = failure_transition
        events.append(event)
        last = event
    native = [e for e in events if e['kind'] == 1]
    # Geometry remains independently source/word validated. Join every group3
    # native frame to its exact telemetry policy/status, never infer a veto hit.
    selected = [e for e in native if e['group'] == 3]
    if len(selected) != len(frames):
        r.fail('group3 geometry/cache call count')
    for event, frame in zip(selected, frames):
        if (event['consumer'], event['mode'], event['width'], event['rank'], event['status'], event['check_pass'], event['cache_enabled']) != (
                frame['consumer'], frame['ctmode'], frame['width'], frame['rank'], frame['native_status'], frame['check_pass'], frame['cache_enabled']):
            r.fail('group3 geometry/cache policy/status join')
    return {'schema': 'cms-cache-integer-observations-v1', 'events': events,
            'native_calls': len(native), 'groups_seen': sorted({e['group'] for e in native}),
            'Fortran_group_cache_applicable': False, 'independent_truth': False,
            'positive_group3_hit_required': False, 'performance_qualified': False}
