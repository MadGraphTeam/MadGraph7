"""Data-only cache metrics for final6417 parsed observations.

Input: [{worker_id, arm, policy_label, policy, budget, analysis}]. arm is plain
or observed; analysis is the already-parsed normal/observer result. No I/O,
project imports, parser invocation, future BUILD access or accuracy acceptance.
Counter sums describe successful visible local intervals, not lifetime work.
"""
INPUT_CONTRACT='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
U64_MAX=(1<<64)-1

class MetricsError(ValueError):pass

def need(condition,message):
    if not condition:raise MetricsError(message)

def integer(value,label,minimum=None,maximum=None):
    need(type(value) is int,label+' must be an integer')
    need((minimum is None or value>=minimum) and (maximum is None or value<=maximum),label+' out of range')
    return value

def boolean(value,label):
    need(type(value) is bool,label+' must be a boolean')
    return value

def snapshot(value,label):
    need(type(value) is list and len(value)==15,label+' requires15 counters')
    return [integer(v,label,0,U64_MAX) for v in value]

def subtract_qp(aggregate,qp):
    need(len(aggregate)==9 and len(qp)==6,'nine+six counter shape')
    result=list(aggregate)
    for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4)):result[i]-=qp[j]
    need(all(v>=0 for v in result),'aggregate below its QP component')
    return result

def _sum(rows):
    if not rows:return None
    return {'aggregate9':[sum(r['aggregate9'][i] for r in rows) for i in range(9)],
            'QP6':[sum(r['QP6'][i] for r in rows) for i in range(6)],
            'DP_component9':[sum(r['DP_component9'][i] for r in rows) for i in range(9)]}

def _delta(event):
    before,after=event['before'],event['after']
    aggregate=[a-b for a,b in zip(after[:9],before[:9])]
    qp=[a-b for a,b in zip(after[9:],before[9:])]
    dp=[a-b for a,b in zip(subtract_qp(after[:9],after[9:]),subtract_qp(before[:9],before[9:]))]
    need(all(v>=0 for v in aggregate+qp+dp),'successful visible interval decreased/reset counters')
    width=event['width'];independent=event['check_pass'];enabled=event['cache_enabled']
    if width==64:
        need(qp==[0]*6,'DP interval changed QP cache')
        if independent or not enabled:need(aggregate==[0]*9,'DP check/disabled interval touched primary store')
    elif independent or not enabled:
        need(aggregate==[0]*9 and qp==[0,0,0,0,0,1] and dp==[0]*9,'QP check/disabled interval lacks pure bypass')
    else:
        hit=qp==[1,0,0,0,0,0]
        stored=qp[:3]==[0,1,1] and qp[3]>0 and qp[4:]==[0,0]
        refused=qp==[0,1,0,0,1,0]
        need((hit or stored or refused) and dp==[0]*9,'QP primary interval contradicts final parsed counter contract')
    return {'aggregate9':aggregate,'QP6':qp,'DP_component9':dp}

def _provenance(event,journal,frame):
    consumers=journal['consumers'];index=event['consumer']
    need(1<=index<=len(consumers),'native event consumer absent')
    consumer=consumers[index-1]
    need(type(consumer) is dict and consumer.get('index')==index,'consumer coordinate')
    need(consumer.get('ctmode')==event['mode'],'consumer/native mode mismatch')
    present=boolean(consumer.get('snapshot'),'consumer snapshot')
    actual=boolean(consumer.get('genuine'),'consumer MP flag') if present else None
    result={'consumer_snapshot_present':present,'actual_consumer_MP_genuine':actual,
            'consumer_H':consumer.get('h'),'consumer_split_order':consumer.get('so'),
            'consumer_boundary':consumer.get('boundary'),'cache_boundary':event['boundary'],
            'group3_frame_index':None,'frame_boundary':None,'frame_public_fallback':None,
            'raw_precision_eligibility_flag':None,'observed_genuine_QP':None,
            'genuine_scope':'consumer context only; no per-native owned frame witness'}
    if frame is None:return result
    need(frame.get('consumer')==index and frame.get('ctmode')==event['mode'] and frame.get('width')==event['width'] and frame.get('rank')==event['rank'] and frame.get('native_status')==event['status'],'ordered group3 native/frame mismatch')
    need(frame.get('check_pass')==event['check_pass'] and frame.get('cache_enabled')==event['cache_enabled'],'group3 native/frame cache/check mismatch')
    legacy=boolean(frame.get('legacy'),'frame public fallback')
    need(frame.get('actual_consumer_MP_genuine') is actual,'frame/consumer actual MP provenance mismatch')
    eligibility=boolean(frame.get('raw_precision_eligibility_flag'),'raw precision eligibility')
    observed=frame.get('observed_genuine_QP')
    if event['width']==64:
        need(observed is None,'DP eligibility cannot become genuine QP')
        if not legacy:need(eligibility,'owned DP typed eligibility sentinel missing')
    elif not legacy:
        need(present and type(observed) is bool and observed==actual and eligibility==actual,'actual owned QP provenance mismatch')
    else:need(observed is None,'public fallback has no owned genuine QP witness')
    result.update(group3_frame_index=frame.get('index'),frame_boundary=frame.get('boundary'),
                  frame_public_fallback=legacy,raw_precision_eligibility_flag=eligibility,
                  observed_genuine_QP=observed,
                  genuine_scope='public fallback; no owned witness' if legacy else 'owned group3 observed source flag; no whole-caller qualification')
    return result

def summarize_cache_observations(workers):
    """Return observations only. Missing/censored intervals are never zeros."""
    need(type(workers) is list,'worker records must be a list')
    worker_rows=[];intervals=[];lifecycle=[];censored=[];seen=set();all_success=[];strata={}
    for worker in workers:
        need(type(worker) is dict,'worker wrapper required')
        ident=worker.get('worker_id');need(type(ident) is str and ident and ident not in seen,'nonempty unique worker_id required');seen.add(ident)
        arm=worker.get('arm');need(arm in ('plain','observed'),'plain/observed arm required')
        label=worker.get('policy_label');need(type(label) is str and label,'policy label required')
        policy=integer(worker.get('policy'),'declared policy',-1)
        budget=integer(worker.get('budget'),'declared budget',0,U64_MAX)
        analysis=worker.get('analysis');need(type(analysis) is dict,'parsed analysis required')
        lane=analysis.get('lane');need(type(lane) is str and lane,'parsed lane required')
        journals=analysis.get('journals',[]);need(type(journals) is list,'journal list required')
        pid=integer(analysis.get('pid'),'parsed PID',1)
        identity={'pid':pid,'worker_id':ident,'arm':arm,'lane':lane,'policy_label':label,'policy':policy,'budget':budget}
        if arm=='plain':
            need(not journals,'plain arm unexpectedly contains observation journals')
            worker_rows.append({**identity,'telemetry_present':False,'observed_native_event_count':None,
                                'successful_visible_interval_count':None,'successful_visible_counter_sums':None,
                                'initial_and_unobserved_work_unknown':True,'first_observed_context_generation':None,
                                'initial_creation_observed':False,'journal_summaries':[]})
            continue
        requests=analysis.get('request_ids');need(type(requests) is list and len(requests)==len(journals),'journal/request count mismatch')
        need(all(type(j) is dict for j in journals),'journal object required')
        for value in requests:integer(value,'request point ID',1)
        need([j.get('point_id') for j in journals]==requests,'journal/request point order mismatch')
        if not journals:
            worker_rows.append({**identity,'telemetry_present':False,'observed_native_event_count':None,
                                'successful_visible_interval_count':None,'successful_visible_counter_sums':None,
                                'initial_and_unobserved_work_unknown':True,'first_observed_context_generation':None,
                                'initial_creation_observed':False,'journal_summaries':[],
                                'telemetry_absence_reason':'no measured journal in supplied prefix'})
            continue
        local_success=[];native_count=0;failure_count=0;clear_count=0;worker_first_generation=None;journal_summaries=[]
        measurements=analysis.get('measurements')
        need(type(measurements) is list and len(measurements)==len(requests) and all(type(m) is dict for m in measurements),'normal measurement context required')
        need([m.get('point_id') for m in measurements]==requests,'normal measurement point order mismatch')
        for journal_index,journal in enumerate(journals,1):
            need(type(journal) is dict,'journal object required')
            for key in ('sequence','request','point_id'):integer(journal.get(key),'journal '+key,1)
            need(journal['request']==journal_index and journal['sequence']==journal_index+1,'journal request/sequence cohort')
            need(type(journal.get('consumers')) is list and type(journal.get('frames')) is list and type(journal.get('boundaries')) is list,'journal provenance arrays required')
            observations=journal.get('cache_observations');need(type(observations) is dict and observations.get('schema')=='cms-cache-integer-observations-v1','final6417 cache observations required')
            events=observations.get('events');need(type(events) is list and all(type(e) is dict for e in events),'cache event objects required')
            first_generation=integer(events[0].get('gen_before'),'first observed generation',-1) if events else None
            if worker_first_generation is None and first_generation is not None:worker_first_generation=first_generation
            measurement=measurements[journal_index-1]
            normal_code=integer(measurement.get('code'),'normal return code',-(1<<31),(1<<31)-1)
            normal_status=measurement.get('status')
            need(type(normal_status) is dict,'normal status metadata required')
            status_keys=('code','H','T','U','class','valid_range','actual_backend','actual_precision','actual_alias')
            normal_status={key:(list(normal_status[key]) if type(normal_status[key]) is list else normal_status[key]) for key in status_keys if key in normal_status}
            context={**identity,'sequence':journal['sequence'],'request':journal['request'],'point_id':journal['point_id'],
                     'first_observed_context_generation':first_generation,'initial_creation_observed':False,
                     'normal_return_code':normal_code,'normal_return_status':normal_status}
            journal_summaries.append({**context,'observed_event_count':len(events),'initial_and_unobserved_work_unknown':True})
            selected=[e for e in events if e.get('kind')==1 and e.get('group')==3]
            need(len(selected)==len(journal['frames']),'group3 frame coverage mismatch')
            group3={e['index']:f for e,f in zip(selected,journal['frames'])}
            native_events=[e for e in events if e.get('kind')==1]
            need(observations.get('native_calls')==len(native_events),'native event count mismatch')
            need(observations.get('groups_seen')==sorted({e['group'] for e in native_events}),'native groups summary mismatch')
            last=None;epoch=0
            for index,event in enumerate(events,1):
                need(type(event) is dict and event.get('index')==index,'cache event order')
                kind=integer(event.get('kind'),'cache kind',1,3)
                before=snapshot(event.get('before'),'before');after=snapshot(event.get('after'),'after')
                subtract_qp(before[:9],before[9:]);subtract_qp(after[:9],after[9:])
                source=integer(event.get('source'),'source',0);group=integer(event.get('group'),'group',0,26)
                consumer=integer(event.get('consumer'),'consumer',0,len(journal['consumers']))
                boundary=integer(event.get('boundary'),'boundary',0,len(journal['boundaries']))
                status=integer(event.get('status'),'native/API status',-(1<<31),(1<<31)-1)
                generation=integer(event.get('gen_before'),'generation before',-1)
                need(integer(event.get('gen_after'),'generation after',-1)==generation,'generation changed within event')
                extent=boolean(event.get('error_prefix_extent_unknown'),'error prefix extent')
                need(extent==(status!=0),'failure error-prefix extent contract')
                if last is not None and last['gen_after']==generation:need(last['after']==before,'unobserved within-journal transition')
                base={**context,'event_index':index,'kind':kind,'source':source,'group':group,'consumer':consumer,
                      'cache_boundary':boundary,'gen_before':generation,'gen_after':generation,
                      'status':status,'before15':list(before),'after15':list(after),'local_counter_epoch':epoch,
                      'event_recorded_budget':event.get('budget'),'error_prefix_extent_unknown':extent,
                      'error_API_text_excluded':True}
                if kind==3:
                    need(status==0 and after==[0]*15 and source==0,'explicit full15 clear malformed')
                    record={**base,'lifecycle':'explicit_all15_clear','censored_for_work_metrics':True,
                            'counter_delta':None,'reason':'reset is observed; discarded within-epoch work cannot be reconstructed'}
                    lifecycle.append(record);censored.append(record);clear_count+=1;epoch+=1
                elif kind==2:
                    need(event.get('budget')==budget and status==0 and before==after,'fixed-budget setter must be a no-op')
                    lifecycle.append({**base,'lifecycle':'fixed_budget_setter','censored_for_work_metrics':False,'counter_delta':None})
                else:
                    width=integer(event.get('width'),'actual kind width');mode=integer(event.get('mode'),'mode')
                    need(width in (64,128) and mode in (1,2,4,5) and width==(64 if mode in (1,2) else 128),'typed width/mode mismatch')
                    need(generation>=0 and source>0 and group>0,'native context/source/group missing')
                    n=integer(event.get('n'),'propagators',1,6);rank=integer(event.get('rank'),'rank',0,6)
                    need(event.get('policy')==policy and event.get('budget')==budget,'native declared policy/budget mismatch')
                    enabled=boolean(event.get('cache_enabled'),'cache request');check=boolean(event.get('check_pass'),'independent check path')
                    need(enabled==(policy==-1 or n<=policy) and check==(mode in (2,5)),'topology/check policy mismatch')
                    provenance=_provenance(event,journal,group3.get(index))
                    record={**base,'width':width,'typed_precision_kind':'DP64' if width==64 else 'QP128_Fortran_kind',
                            'mode':mode,'n':n,'rank':rank,'cache_enabled':enabled,'check_pass':check,
                            'independent_check_path':check,'provenance':provenance,'censored_for_work_metrics':status!=0,
                            'successful_visible_delta':None,'failure_cache_transition':event.get('failure_cache_transition')}
                    native_count+=1
                    if status!=0:
                        need(type(record['failure_cache_transition']) is str,'failed interval transition label missing')
                        record['censorship_reason']='failed interval may be partial or reset; not zero work or a lifetime hit count'
                        censored.append(record);failure_count+=1;epoch+=1
                    else:
                        delta=_delta(event);record['successful_visible_delta']=delta
                        local_success.append(delta);all_success.append(delta)
                        key=(ident,arm,lane,label,policy,budget,source,group,width,mode,check,enabled,
                             provenance['consumer_snapshot_present'],provenance['actual_consumer_MP_genuine'],
                             provenance['frame_public_fallback'],provenance['observed_genuine_QP'])
                        bucket=strata.setdefault(key,{'context':{**identity,'source':source,'group':group,'width':width,'mode':mode,
                                              'independent_check_path':check,'cache_enabled':enabled,
                                              'consumer_snapshot_present':provenance['consumer_snapshot_present'],
                                              'actual_consumer_MP_genuine':provenance['actual_consumer_MP_genuine'],
                                              'frame_public_fallback':provenance['frame_public_fallback'],
                                              'observed_genuine_QP':provenance['observed_genuine_QP']},'deltas':[]})
                        bucket['deltas'].append(delta)
                    intervals.append(record)
                last=event
        worker_rows.append({**identity,'telemetry_present':bool(journals),'observed_native_event_count':native_count,
                            'successful_visible_interval_count':len(local_success),'failed_native_intervals_censored':failure_count,
                            'explicit_full15_clears':clear_count,'successful_visible_counter_sums':_sum(local_success),
                            'initial_and_unobserved_work_unknown':True,
                            'first_observed_context_generation':worker_first_generation,'initial_creation_observed':False,
                            'journal_summaries':journal_summaries})
    strata_rows=[{**bucket['context'],'successful_visible_interval_count':len(bucket['deltas']),
                  'successful_visible_counter_sums':_sum(bucket['deltas'])} for bucket in strata.values()]
    return {'schema':'CMS-cache-visible-interval-metrics-v1','input_contract_source_index':INPUT_CONTRACT,
            'workers':worker_rows,'intervals':intervals,'lifecycle_events':lifecycle,'censored_intervals':censored,
            'strata':strata_rows,'successful_visible_counter_sums':_sum(all_success),
            'successful_visible_interval_count':len(all_success) if any(w['telemetry_present'] for w in worker_rows) else None,'lifetime_totals':None,'hit_rates':None,
            'sums_scope':'successful measured visible per-event deltas only; no learning, failed, reset or unobserved work totals',
            'counter_order':{'aggregate9':'unchanged pinned API order; last5 include QP first5',
                             'QP6':['whole_tensor_hits','whole_tensor_misses','retained_entries','accounted_bytes','refused_insertions','bypasses'],
                             'DP_component9':'aggregate9 minus QPfirst5 at aggregate slots4..8; QPbypass has no aggregate counterpart'},
            'initial_creation_observed':False,'work_before_first_snapshot_and_journal_gaps_unobserved':True,'failed_interval_hit_counts_censored':True,
            'entries_bytes_are_accounted_store_deltas_not_work_or_RSS':True,
            'Fortran_group_cache':'N/A','forced_group3_hit_requirement':False,'error_API_text_included':False,
            'live_error_API_state_equal':False,'failure_prefix_extent_known':False,
            'accuracy_qualified':False,'independent_truth':False,'runtime_cache_behavior_qualified':False,
            'full_caller_qualified':False,'performance_qualified':False}
