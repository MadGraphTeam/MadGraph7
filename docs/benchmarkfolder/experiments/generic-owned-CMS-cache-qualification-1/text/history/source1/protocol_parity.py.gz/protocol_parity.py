"""Pure identity-aware parity for retained READY/DONE and provider maps."""


def require(ok,message):
    if not ok:raise ValueError(message)


def protocol_core(transcript, *, pid, ids, measurements, learning_outer_calls):
    require(type(pid) is int and pid>0 and type(transcript) is list,'actual protocol/PID required')
    expected=[('RECV',['READY',str(pid)]),('SEND',['LEARN','1','0']),
              ('RECV',['LEARNED',str(pid),'1','1',str(learning_outer_calls),'12'])]
    for index,(point,row) in enumerate(zip(ids,measurements),1):
        seq=index+1
        require(row['point_id']==point,'protocol/analysis point order')
        expected += [('SEND',['RUN',str(seq),str(index)]),
                     ('RECV',['DONE',str(pid),str(seq),str(index),str(point),str(row['code']),str(row['class'])])]
    seq=len(ids)+2
    expected += [('SEND',['EXIT',str(seq),'0']),('RECV',['EXIT',str(pid),str(seq)])]
    require(len(ids)==len(measurements) and len(transcript)==len(expected),'protocol terminal/cardinality')
    normalized=[]
    for actual,(direction,fields) in zip(transcript,expected):
        require(actual=={'direction':direction,'fields':fields},'protocol message/coordinate mismatch')
        values=list(fields)
        if direction=='RECV':values[1]='ACTUAL_PID'
        normalized.append({'direction':direction,'fields':values})
    return normalized


def maps_core(maps, *, pid, executable_path, executable_sha256, runtime, ids):
    labels=['ready','learned',*['done-'+str(i) for i in range(1,len(ids)+1)]]
    require(type(maps) is dict and set(maps)==set(labels),'exact READY/LEARNED/DONE map set')
    result=[]
    for label in labels:
        proof=maps[label]
        require(proof['pid']==pid and proof['affinity']==[12] and proof['exclusive_CPU'] is False,'actual map PID/CPU policy')
        current=proof['identity'];started=proof['started_identity']
        for key in ('pid','parent_pid','process_group','session','start_time_ticks'):
            require(current[key]==started[key],'map process lifetime changed')
        require(current['pid']==pid and current['start_time_ticks']>0,'map native identity')
        require(current['process_group']==current['session']==current['parent_pid'],'native left owned supervisor group')
        require(current['state'] not in ('Z','X','x') and started['state'] not in ('Z','X','x'),'mapped dead process')
        expected={**runtime,executable_path:executable_sha256}
        require(len(runtime)==15 and proof['ELF']==expected,'actual executable/provider inventory')
        require(type(proof['raw']) is str and bool(proof['raw']),'raw process maps absent')
        result.append({'phase':label,'providers':dict(runtime),'data':proof['data'],
                       'affinity':proof['affinity'],'exclusive_CPU':False})
    return result


def own_runtime_parity(plain,observed, *, runtime):
    """Compare declared observable state, never live MTIRUST error API text."""
    for row in (plain,observed):
        require(row['returncode']==0 and row['orchestration_closed'] and row['no_retry'],'worker not closed')
        require(row['analysis']['accepted_for_continuation'],'numerical worker not accepted')
        require(row['request']['lane']=='candidate','foreign numerical lane')
    require(plain['request']['arm']=='plain' and observed['request']['arm']=='observed','plain/observed pair required')
    require(plain['stderr_sha256']==observed['stderr_sha256'],'own plain/observed retained stdout/stderr differs')
    for key in ('policy','cohort','ids'):
        require(plain['request'][key]==observed['request'][key],'runtime pair cohort/policy mismatch')
    ids=plain['request']['ids'];cores=[]
    for row in (plain,observed):
        normal=row['analysis'].get('normal_analysis',row['analysis'])
        cores.append({'protocol':protocol_core(row['protocol'],pid=row['pid'],ids=ids,
                        measurements=normal['measurements'],learning_outer_calls=normal['learning']['outer_calls']),
                      'maps':maps_core(row['maps'],pid=row['pid'],executable_path=row['executable_path'],
                        executable_sha256=row['executable_sha256'],runtime=runtime,ids=ids)})
    require(cores[0]==cores[1],'own plain/observed protocol/provider/data/affinity parity')
    return {'passed':True,'protocol_and_maps_compared':True,'retained_stdout_stderr_equal':True,'actual_PID_self_ELF_ASLR_excluded_only_after_authentication':True,
            'live_error_API_state_compared':False,'unobserved_software_state_equivalence':False,
            'independent_physical_truth':False,'performance_qualified':False}
