"""Guarded synthetic/source checks only: no model/worker/native/tool queries."""
from pathlib import Path
import sys
import unittest

forbidden=[]
def guard(event,args):
    if event.startswith(('subprocess.','ctypes.dlopen','os.system','os.exec','os.fork','os.posix_spawn')):
        forbidden.append(event);raise RuntimeError('forbidden process/native action '+event)
sys.addaudithook(guard)
here=Path(__file__).resolve().parent;suite=unittest.TestSuite()
for filename in ('test_run_source.py','test_cache_comparison.py','test_cache_metrics.py'):
    path=here/filename;ns={'__file__':str(path),'__name__':'cache_RUN_'+path.stem}
    exec(compile(path.read_text(),str(path),'exec'),ns)
    for value in ns.values():
        if isinstance(value,type) and issubclass(value,unittest.TestCase) and value is not unittest.TestCase:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
result=unittest.TextTestRunner(verbosity=2).run(suite)
print('forbidden process/native operations:',len(forbidden))
raise SystemExit(not result.wasSuccessful() or bool(forbidden))
