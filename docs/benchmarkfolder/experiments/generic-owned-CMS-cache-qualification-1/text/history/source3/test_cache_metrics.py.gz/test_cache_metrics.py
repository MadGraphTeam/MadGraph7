"""Pure synthetic data/negative contracts; never reads any BUILD artifacts."""
from pathlib import Path
import copy
import importlib.util
import json
import sys
import unittest
FORBIDDEN=[]
def deny(event,args):
    if event.startswith(('subprocess.','ctypes.','socket.')) or event in {'os.system','os.exec','os.posix_spawn','os.fork','pty.spawn'}:
        FORBIDDEN.append(event);raise RuntimeError('forbidden native/process/network')
sys.addaudithook(deny)
spec=importlib.util.spec_from_file_location('draft_cache_metrics',Path(__file__).with_name('cache_metrics.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BUDGET=1024

def vec(dp=None,qp=None):
    dp=list(dp or [0]*9);qp=list(qp or [0]*6);aggregate=dp[:]
    for i,j in ((4,0),(5,1),(6,2),(7,3),(8,4)):aggregate[i]+=qp[j]
    return aggregate+qp

def add_dp(before,delta):
    dp=m.subtract_qp(before[:9],before[9:])
    return vec([a+b for a,b in zip(dp,delta)],before[9:])

def add_qp(before,delta):
    return vec(m.subtract_qp(before[:9],before[9:]),[a+b for a,b in zip(before[9:],delta)])

def native(before,after,*,width=64,mode=1,group=1,source=None,status=0,policy=-1,n=4,transition=None,legacy=False,generation=1):
    consumer={1:1,2:2,4:3,5:4}[mode]
    return {'kind':1,'source':source or (7 if width==64 else 8),'group':group,'consumer':consumer,'boundary':2,
            'width':width,'n':n,'rank':2,'mode':mode,'policy':policy,'cache_enabled':policy==-1 or n<=policy,
            'check_pass':mode in (2,5),'status':status,'gen_before':generation,'gen_after':generation,
            'budget':BUDGET,'before':list(before),'after':list(after),'error_prefix_hex':'','error_prefix_extent_unknown':status!=0,
            'failure_cache_transition':transition,'fixture_legacy':legacy}

def clear(before,generation=1):
    return {'kind':3,'source':0,'group':0,'consumer':0,'boundary':0,'width':0,'n':0,'rank':0,'mode':0,'policy':0,
            'cache_enabled':False,'check_pass':False,'status':0,'gen_before':generation,'gen_after':generation,
            'budget':0,'before':list(before),'after':[0]*15,'error_prefix_hex':'','error_prefix_extent_unknown':False}

def journal(native_and_clear,point=20,request=1):
    consumers=[{'index':i,'h':17,'so':1,'ctmode':mode,'boundary':1,'snapshot':True,'genuine':mode>=4}
               for i,mode in enumerate((1,2,4,5),1)]
    events=[];frames=[]
    for given in native_and_clear:
        event=copy.deepcopy(given);legacy=event.pop('fixture_legacy',False)
        if event['kind']==1:
            budget=copy.deepcopy(event);budget.update(kind=2,width=0,n=0,rank=0,mode=0,policy=0,
                    cache_enabled=False,check_pass=False,status=0,after=event['before'][:],error_prefix_extent_unknown=False)
            budget.pop('failure_cache_transition',None);budget['index']=len(events)+1;events.append(budget)
        event['index']=len(events)+1;events.append(event)
        if event['kind']==1 and event['group']==3:
            consumer=consumers[event['consumer']-1]
            frames.append({'index':len(frames)+1,'consumer':event['consumer'],'ctmode':event['mode'],
                           'width':event['width'],'rank':event['rank'],'native_status':event['status'],
                           'check_pass':event['check_pass'],'cache_enabled':event['cache_enabled'],'boundary':1,
                           'legacy':legacy,'raw_precision_eligibility_flag':not legacy,
                           'actual_consumer_MP_genuine':consumer['genuine'],
                           'observed_genuine_QP':consumer['genuine'] if event['width']==128 and not legacy else None})
    natives=[e for e in events if e['kind']==1]
    return {'sequence':request+1,'request':request,'point_id':point,'consumers':consumers,'frames':frames,'boundaries':[1,300,208],
            'cache_observations':{'schema':'cms-cache-integer-observations-v1','events':events,'native_calls':len(natives),
                                  'groups_seen':sorted({e['group'] for e in natives})}}

def worker(journals,*,ident='observed/cacheall',arm='observed',policy=-1,pid=12345):
    analysis={'lane':'candidate','pid':pid,'request_ids':[j['point_id'] for j in journals],
              'measurements':[{'point_id':j['point_id'],'code':323,'status':{'code':323,'H':3,'T':2,'U':3,
                                'actual_backend':9,'actual_precision':'QP','actual_alias':[9,'QP']}} for j in journals]}
    if arm=='observed':analysis['journals']=copy.deepcopy(journals)
    return {'worker_id':ident,'arm':arm,'policy_label':'cacheall' if policy==-1 else 'cache0','policy':policy,'budget':BUDGET,'analysis':analysis}

def successful_pair():
    before=vec([100,200,300,400,10,20,2,30,1],[7,8,1,16,0,2])
    delta=[1,2,3,4,5,6,1,8,1];middle=add_dp(before,delta);after=add_qp(middle,[1,0,0,0,0,0])
    return before,delta,middle,after

class Metrics(unittest.TestCase):
    def summary(self,events,**kwargs):return m.summarize_cache_observations([worker([journal(events)],**kwargs)])
    def test_success_deltas_subtract_qp_without_initial_snapshot_or_double_count(self):
        before,dp,middle,after=successful_pair()
        report=self.summary([native(before,middle),native(middle,after,width=128,mode=4,group=3)])
        sums=report['successful_visible_counter_sums']
        self.assertEqual(sums['DP_component9'],dp)
        self.assertEqual(sums['QP6'],[1,0,0,0,0,0])
        expected=dp[:];expected[4]+=1;self.assertEqual(sums['aggregate9'],expected)
        self.assertIsNone(report['lifetime_totals']);self.assertIsNone(report['hit_rates'])
        self.assertEqual(report['successful_visible_interval_count'],2)
    def test_first_observed_generation_is_not_creation(self):
        before,dp,middle,after=successful_pair();report=self.summary([native(before,middle,generation=7)])
        row=report['workers'][0]
        self.assertEqual(row['first_observed_context_generation'],7)
        self.assertEqual(row['journal_summaries'][0]['first_observed_context_generation'],7)
        self.assertFalse(row['initial_creation_observed']);self.assertFalse(report['initial_creation_observed'])
    def test_checks_are_bypass_paths_not_accuracy_passes(self):
        before=vec();after=add_qp(before,[0,0,0,0,0,1])
        report=self.summary([native(before,before,mode=2),native(before,after,width=128,mode=5,group=3)])
        self.assertEqual(report['successful_visible_counter_sums']['QP6'],[0,0,0,0,0,1])
        self.assertTrue(all(row['independent_check_path'] for row in report['intervals']))
        self.assertFalse(report['accuracy_qualified']);self.assertFalse(report['runtime_cache_behavior_qualified'])
    def test_disabled_paths_count_no_primary_cache_reuse(self):
        before=vec();after=add_qp(before,[0,0,0,0,0,1])
        report=self.summary([native(before,before,policy=0),native(before,after,width=128,mode=4,policy=0)],policy=0)
        self.assertEqual(report['successful_visible_counter_sums']['aggregate9'],[0]*9)
        self.assertEqual(report['successful_visible_counter_sums']['QP6'],[0,0,0,0,0,1])
    def test_failed_intervals_are_censored_even_when_unchanged(self):
        before=vec([4]*9,[1,1,0,0,0,0])
        report=self.summary([native(before,before,status=2,transition='DP_unchanged_or_already_empty')])
        self.assertIsNone(report['successful_visible_counter_sums'])
        interval=report['intervals'][0]
        self.assertIsNone(interval['successful_visible_delta']);self.assertTrue(interval['censored_for_work_metrics'])
        self.assertEqual(interval['status'],2);self.assertTrue(interval['error_prefix_extent_unknown'])
    def test_failure_clear_cannot_become_negative_work_or_zero_hit_claim(self):
        before=vec([5]*9,[2,3,0,0,0,4]);after=vec([0]*9,before[9:])
        report=self.summary([native(before,after,status=1,transition='DP_full_store_counters_cleared')])
        self.assertIsNone(report['successful_visible_counter_sums'])
        self.assertEqual(len(report['censored_intervals']),1)
        self.assertTrue(report['failed_interval_hit_counts_censored'])
    def test_explicit_full15_clear_preserves_earlier_successful_visible_delta(self):
        before,dp,middle,after=successful_pair();again=add_dp([0]*15,dp)
        report=self.summary([native(before,middle),clear(middle),native([0]*15,again)])
        self.assertEqual(report['successful_visible_counter_sums']['DP_component9'],[2*x for x in dp])
        clears=[e for e in report['lifecycle_events'] if e['kind']==3]
        self.assertEqual(clears[0]['after15'],[0]*15);self.assertIsNone(clears[0]['counter_delta'])
        self.assertTrue(clears[0]['censored_for_work_metrics'])
    def test_plain_arm_absence_is_unknown_not_zero(self):
        w=worker([],arm='plain',ident='plain/cacheall')
        report=m.summarize_cache_observations([w]);row=report['workers'][0]
        self.assertFalse(row['telemetry_present']);self.assertIsNone(row['observed_native_event_count'])
        self.assertIsNone(row['successful_visible_counter_sums']);self.assertIsNone(report['successful_visible_counter_sums'])
    def test_no_qp_observation_is_not_invented_from_configuration_or_final_code(self):
        before,dp,middle,_=successful_pair();w=worker([journal([native(before,middle,group=3)])])
        w['analysis']['UseQPIntegrandForTIRust']=True
        report=m.summarize_cache_observations([w]);row=report['intervals'][0]
        self.assertEqual(row['width'],64);self.assertIsNone(row['provenance']['observed_genuine_QP'])
        self.assertFalse(any(s['width']==128 for s in report['strata']))
    def test_allgroups_provenance_remains_typed_when_no_owned_frame(self):
        before=vec();after=add_qp(before,[1,0,0,0,0,0])
        report=self.summary([native(before,after,width=128,mode=4,group=26)])
        p=report['intervals'][0]['provenance']
        self.assertTrue(p['actual_consumer_MP_genuine']);self.assertIsNone(p['observed_genuine_QP'])
        self.assertIsNone(p['group3_frame_index']);self.assertEqual(report['strata'][0]['group'],26)
    def test_source_group_mode_policy_and_boundary_facts_preserved(self):
        before=vec();after=add_qp(before,[1,0,0,0,0,0])
        report=self.summary([native(before,after,width=128,mode=4,group=3,source=8)])
        row=report['intervals'][0]
        self.assertEqual((row['source'],row['group'],row['mode'],row['width'],row['policy']),(8,3,4,128,-1))
        self.assertEqual(row['provenance']['cache_boundary'],2);self.assertEqual(row['provenance']['frame_boundary'],1)
        self.assertTrue(row['provenance']['observed_genuine_QP'])
    def test_public_fallback_unknown_is_not_false_owned_qp(self):
        before=vec();after=add_qp(before,[1,0,0,0,0,0])
        report=self.summary([native(before,after,width=128,mode=4,group=3,legacy=True,source=10)])
        p=report['intervals'][0]['provenance']
        self.assertTrue(p['frame_public_fallback']);self.assertIsNone(p['observed_genuine_QP'])
    def test_cross_journal_gaps_do_not_splice_endpoints(self):
        before,dp,middle,_=successful_pair();other=vec([1000]*9,[30,40,0,0,0,9]);other_after=add_dp(other,dp)
        w=worker([journal([native(before,middle)],point=1),journal([native(other,other_after)],point=7,request=2)])
        report=m.summarize_cache_observations([w])
        self.assertEqual(report['successful_visible_counter_sums']['DP_component9'],[2*x for x in dp])
        self.assertTrue(report['work_before_first_snapshot_and_journal_gaps_unobserved'])
    def test_worker_contexts_do_not_merge_by_generation(self):
        before,dp,middle,_=successful_pair();w1=worker([journal([native(before,middle)])],ident='first')
        w2=worker([journal([native(before,middle)])],ident='second',pid=54321)
        report=m.summarize_cache_observations([w1,w2])
        self.assertEqual(len(report['strata']),2);self.assertEqual({x['pid'] for x in report['intervals']},{12345,54321})
        with self.assertRaises(m.MetricsError):m.summarize_cache_observations([w1,w1])
    def test_counter_shape_underflow_reset_and_boolean_spoofs_reject(self):
        before,dp,middle,_=successful_pair()
        good=worker([journal([native(before,middle)])])
        mutations=[]
        for field,value in [('before',[0]*14),('after',[0]*15),('status',True),('gen_after',True)]:
            bad=copy.deepcopy(good);bad['analysis']['journals'][0]['cache_observations']['events'][1][field]=value;mutations.append(bad)
        bad=copy.deepcopy(good);bad['analysis']['journals'][0]['cache_observations']['events'][1]['after'][14]=-1;mutations.append(bad)
        for bad in mutations:
            with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
    def test_no_primary_reuse_from_disabled_or_check_events(self):
        before=vec();after=add_qp(before,[1,0,0,0,0,0])
        for policy,mode in [(0,4),(-1,5)]:
            with self.assertRaises(m.MetricsError):self.summary([native(before,after,width=128,mode=mode,policy=policy)],policy=policy)
    def test_group3_join_or_genuine_spoof_rejects(self):
        before=vec();after=add_qp(before,[1,0,0,0,0,0]);good=worker([journal([native(before,after,width=128,mode=4,group=3)])])
        for field,value in [('consumer',1),('observed_genuine_QP',False),('actual_consumer_MP_genuine',False),('raw_precision_eligibility_flag',False),('cache_enabled',False)]:
            bad=copy.deepcopy(good);bad['analysis']['journals'][0]['frames'][0][field]=value
            with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
        bad=copy.deepcopy(good);bad['analysis']['journals'][0]['frames']=[]
        with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
    def test_error_api_bytes_excluded_but_failure_extent_and_status_kept(self):
        before=vec();event=native(before,before,status=2,transition='DP_unchanged_or_already_empty');event['error_prefix_hex']='736563726574'
        data=worker([journal([event])]);data['analysis']['measurements'][0]['status']['error_message']='unobserved-private-text'
        report=m.summarize_cache_observations([data]);text=json.dumps(report)
        self.assertNotIn('unobserved-private-text',text)
        self.assertNotIn('736563726574',text);self.assertTrue(report['intervals'][0]['error_prefix_extent_unknown'])
        self.assertFalse(report['live_error_API_state_equal']);self.assertFalse(report['failure_prefix_extent_known'])
    def test_malformed_clear_budget_request_and_event_counts_reject(self):
        before,dp,middle,_=successful_pair();good=worker([journal([native(before,middle)])])
        bad=copy.deepcopy(good);bad['analysis']['journals'][0]['cache_observations']['events'][0]['after']=middle
        with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
        bad=worker([journal([clear(before)])]);bad['analysis']['journals'][0]['cache_observations']['events'][0]['after'][0]=1
        with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
        for field,value in [('request_ids',[]),('journals',[])]:
            bad=copy.deepcopy(good);bad['analysis'][field]=value
            with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
        bad=copy.deepcopy(good);bad['analysis']['journals'][0]['cache_observations']['native_calls']=99
        with self.assertRaises(m.MetricsError):m.summarize_cache_observations([bad])
    def test_input_unchanged_and_no_accuracy_acceptance_fields(self):
        before,dp,middle,_=successful_pair();data=[worker([journal([native(before,middle)])])];original=copy.deepcopy(data)
        report=m.summarize_cache_observations(data)
        self.assertEqual(data,original);self.assertNotIn('accepted',report);self.assertNotIn('passed',report)
        for key in ('accuracy_qualified','independent_truth','full_caller_qualified','performance_qualified','forced_group3_hit_requirement'):self.assertFalse(report[key])
        self.assertEqual(report['Fortran_group_cache'],'N/A');json.dumps(report,allow_nan=False)
    def test_empty_observed_prefix_is_absent_not_zero(self):
        report=m.summarize_cache_observations([worker([])])
        row=report['workers'][0]
        self.assertFalse(row['telemetry_present']);self.assertIsNone(row['observed_native_event_count'])
        self.assertIsNone(row['successful_visible_interval_count']);self.assertIsNone(report['successful_visible_interval_count'])
        self.assertIsNone(report['successful_visible_counter_sums'])
        # Explicitly observed empty events are distinct from an absent journal.
        seen=m.summarize_cache_observations([worker([journal([])])])
        self.assertTrue(seen['workers'][0]['telemetry_present'])
        self.assertEqual(seen['workers'][0]['observed_native_event_count'],0)
    def test_no_forbidden_events(self):self.assertEqual(FORBIDDEN,[])

if __name__=='__main__':
    result=unittest.main(exit=False,verbosity=2).result
    print('FORBIDDEN_ATTEMPTS',len(FORBIDDEN))
    raise SystemExit(not result.wasSuccessful() or bool(FORBIDDEN))
