"""Dormant strict worker adaptation. No action at import; no retry."""
from pathlib import Path
import hashlib,json,os,selectors,shutil,struct,subprocess,time
SUB=Path('SubProcesses/P0_epem_mupmum')
COMPILED_SOURCE='6417ad4e1905765b3e2ae17fd67cc4aa01ac7dfe4b93ec75318c7558e02b5f93'
BUILD_TERMINAL='4110ed1280ce47cf55a93fd45cc4b848b84906411b255a7c2f0a41090260eb44'
BUILD_RESULT='cb9b8ff22f9ceacc60d66b908a060b90e4a6d3322d514955224c31b3ee993137'
ORIGINAL_CARD_SHA='8b8f556a4d52f570a4f80d81d105bb1b4636badd232f097ec8afe19a923ef969'

def validate_policy(policy,request):
    require(policy['name']==request['policy'] and policy['name'] in ('cache0','cacheall'),'undeclared fixed worker policy')
    require(policy['GlobalCache']==(0 if policy['name']=='cache0' else -1) and policy['CacheMaxBytes']==268435456,'undeclared cache/budget delta')
    require(policy['runtime_card']=='cards/'+policy['name']+'.dat','runtime card path escape/policy mismatch')

def validate_runtime_card(original,runtime,policy):
    require(hashlib.sha256(original).hexdigest()==ORIGINAL_CARD_SHA,'original compiled card changed')
    old=b'#MLStabThres\n1.000000d-03\n';new=b'#MLStabThres\n1.000000d-06\n'
    require(original.count(old)==1,'strict stability source anchor')
    expected=original.replace(old,new)
    cache=b'#TIRustGlobalCache\n0\n'
    require(expected.count(cache)==1,'cache source anchor')
    expected=expected.replace(cache,b'#TIRustGlobalCache\n'+str(policy['GlobalCache']).encode()+b'\n')
    require(runtime==expected and hashlib.sha256(runtime).hexdigest()==policy['runtime_sha256'],'extra/incorrect runtime card delta')
    return True

def require(ok,message):
    if not ok:raise ValueError(message)

def read(p):return json.loads(Path(p).read_text())

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def identity(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}

def point_words(*streams):
    """Source-bound decimal input echoes; any native conversion mismatch refuses."""
    found={}
    for stream in streams:
        rows=Path(stream).read_text().splitlines();n=int(rows[0])
        require(n>0 and len(rows)==1+5*n,'input stream shape')
        for i in range(n):
            key=int(rows[1+5*i]);words=[]
            for line in rows[2+5*i:6+5*i]:
                fields=line.split();require(len(fields)==4,'input four-vector shape')
                words.append([struct.pack('>d',float(x.replace('D','E').replace('d','e'))).hex().upper() for x in fields])
            require(key not in found or found[key]==words,'duplicate input point differs')
            found[key]=words
    return found

def ready_reply(fields,pid):
    require(fields==['READY',str(pid)],'wrong native READY')

def learned_reply(fields,pid,seq):
    require(len(fields)>=4 and fields[:3]==['LEARNED',str(pid),str(seq)],'wrong LEARNED identity/sequence')
    if fields[3]=='0':
        require(len(fields)==5 and fields[4] in ('training-input','measurement-input','dimensions','real64-format','learning-status','learning-limit'),'unknown learning failure')
        return False
    require(len(fields)==6 and fields[3]=='1' and 1<=int(fields[4])<=1012 and fields[5]=='12','invalid completed learning bounds/readiness')
    return True

def done_reply(fields,pid,seq,index,point):
    require(len(fields)==7 and fields[:5]==['DONE',str(pid),str(seq),str(index),str(point)],'wrong DONE identity/sequence/point')
    require(fields[6] in ('0','1','2'),'unknown driver numerical class')
    return int(fields[5]),int(fields[6])

def exit_reply(fields,pid,seq):
    require(fields==['EXIT',str(pid),str(seq)],'wrong native EXIT')

class Protocol:
    def __init__(self,b,process,fd,folder):
        self.b,self.process,self.fd,self.folder=b,process,fd,folder;self.buffer=bytearray();self.seq=0
        self.selector=selectors.DefaultSelector();self.selector.register(fd,selectors.EVENT_READ)
        self.transcript=[]
    def message(self):
        end=min(time.monotonic()+180.,self.b.ABSOLUTE_END-self.b.CLEANUP)
        while True:
            self.b.require_supervisor()
            if b'\n' in self.buffer:
                line,_,remaining=self.buffer.partition(b'\n');self.buffer=bytearray(remaining)
                fields=line.decode('ascii').split();require(fields,'empty driver protocol')
                self.transcript.append({'direction':'RECV','fields':fields});self.save();return fields
            require(time.monotonic()<end,'native driver protocol180s/original cutoff')
            if self.selector.select(min(.1,max(0.,end-time.monotonic()))):
                self.buffer.extend(os.read(self.fd,4096));require(len(self.buffer)<=4096,'oversize native protocol')
            else:require(self.process.poll() is None,'native driver exited before protocol response')
    def send(self,command,request):
        self.b.require_supervisor();self.seq+=1;fields=[command,str(self.seq),str(request)]
        self.transcript.append({'direction':'SEND','fields':fields});self.save()
        self.process.stdin.write(' '.join(fields)+'\n');self.process.stdin.flush();return self.seq
    def save(self):
        # Rewrite only this owned evidence file; failed transcripts are retained.
        (self.folder/'protocol.json').write_text(json.dumps(self.transcript,indent=2,sort_keys=True)+'\n')
    def terminal_empty(self):
        # Called only after the retained native process has exited successfully.
        require(not self.buffer,'trailing buffered native protocol evidence')
        try:tail=os.read(self.fd,4096)
        except BlockingIOError:tail=b''
        require(not tail,'trailing unread native protocol evidence')
    def close(self):self.selector.close()

def checked_copy(source,target,root,sha,cap):
    import clone_aliases
    clone_aliases.writable_relative(target.relative_to(root))
    require(target.parent.resolve().is_relative_to(root.resolve()) and source.stat().st_size<=cap,'ELF/input copy escapes or exceeds cap')
    shutil.copy2(source,target);require(digest(target)==sha,'private ELF/input copy differs')

def resource_layout(resources):
    # SETMADLOOPPATH auto chooses './' because the frozen card lives in cwd.
    # Make that exact private directory self-contained without a driver rebuild.
    names={'ML5_0_ColorNumFactors.dat','ML5_0_ColorDenomFactors.dat','ML5_0_HelConfigs.dat','ident_card.dat'}
    require(len(resources)==4 and {Path(n).name for n in resources}==names,'exact four original resources required')
    require(all(Path(n).parent==Path('SubProcesses/MadLoop5_resources') for n in resources),'unexpected resource source path')
    return [(Path(n),SUB/Path(n).name,pin) for n,pin in sorted(resources.items())]

def worker_failure(b,folder,error,process,started,raw,launch_attempted):
    # Popen can create the OS child before its Python handle is assigned.
    # The failure-only authenticated stage group fallback covers that gap.
    if launch_attempted and process is None:
        try:b.record_worker_failure(folder,error,process,started,raw)
        finally:b.stop_owned_group()
    else:b.record_worker_failure(folder,error,process,started,raw)

def one(b,directory,request,row,binding,policy):
    import clone_aliases
    require(binding['compiled_source_sha256']==COMPILED_SOURCE and binding['terminal_sha256']==BUILD_TERMINAL and binding['result_sha256']==BUILD_RESULT,'actual closed BUILD binding required')
    require(request['arm'] in ('plain','observed') and row==binding['variants'][request['arm']],'worker/ELF arm binding')
    validate_policy(policy,request)
    data=read(b.HERE/'input-pins.json');source=Path(row['path']).parent.parent.parent
    output=directory/'workers'/request['id'];output.parent.mkdir(exist_ok=True)
    clone_aliases.clone(source,output,data['donor'],data['shared_aliases'],data['original_links'])
    case=output/SUB;folder=directory/'evidence'/request['id'];folder.mkdir(parents=True)
    checked_copy(Path(row['path']),case/'check',output,row['sha256'],b.LIMITS['file_bytes'])
    require(b.local('cms_build').source_inventory(output)==row['source_inventory'],'private RUN source/include copy changed')
    for name,pin in data['resources'].items():require(identity(output/name)==pin,'private resource copy differs')
    for source_name,dest_name,pin in resource_layout(data['resources']):
        target=output/dest_name
        require(not target.is_symlink() and (not target.exists() or identity(target)==pin),'unexpected existing cwd resource')
        checked_copy(output/source_name,target,output,pin['sha256'],b.LIMITS['file_bytes'])
        require(identity(target)==pin,'cwd resource copy differs')
    require(not any(output.rglob('*HelFilter.dat')) and not any(output.rglob('*LoopFilter.dat')),'fresh worker inherited filters')
    # Verify each original copy before the sole predeclared runtime stability delta.
    runtime_card=b.HERE/policy['runtime_card']
    validate_runtime_card((b.HERE/'cards/original-MadLoopParams.dat').read_bytes(),runtime_card.read_bytes(),policy)
    originals=list(output.rglob('MadLoopParams.dat'));require(originals,'missing original private numerical card')
    for target in originals:
        require(not target.is_symlink() and target.resolve().is_relative_to(output.resolve()) and digest(target)==ORIGINAL_CARD_SHA,'private original BUILD card differs/escapes')
        checked_copy(runtime_card,target,output,policy['runtime_sha256'],b.LIMITS['file_bytes'])
    # Only strict stability and the declared per-worker cache field differ.
    for name in ('param_card.dat','MadLoopParams.dat'):
        want=policy['runtime_sha256'] if name=='MadLoopParams.dat' else digest(b.HERE/'cards'/name)
        paths=list(output.rglob(name));require(paths,'missing private card '+name)
        for p in paths:require(p.resolve().is_relative_to(output.resolve()) and digest(p)==want,'private card differs/escapes')
    training=case/'training.dat';measurement=case/'measurement.dat'
    for src,target in ((b.HERE/'inputs/training.dat',training),(b.HERE/request['measurement'],measurement)):
        checked_copy(src,target,output,digest(src),b.LIMITS['file_bytes'])
    pipe=case/'native-protocol.fifo';os.mkfifo(pipe,0o600);fd=os.open(pipe,os.O_RDWR|os.O_NONBLOCK)
    expected_points=point_words(training,measurement)
    raw=folder/'driver.raw64';process=started=protocol=None;launch_attempted=False
    argv=[str(case/'check'),str(training),str(measurement),str(pipe),str(raw)]
    b.dump(folder/'command.json',{'argv':argv,'cwd':str(case),'source_index_sha256':b.EXPECTED_SOURCE,'reviewed_build':binding['terminal_sha256'],'compiled_source_index_sha256':binding['compiled_source_sha256'],'compiled_result_sha256':binding['result_sha256'],'ELF_sha256':row['sha256'],'runtime_card_sha256':policy['runtime_sha256'],'request':request,'new_session':False})
    try:
        with (folder/'stderr.txt').open('xb') as error:
            launch_environment=b.environment();b.require_supervisor()
            launch_attempted=True
            process=subprocess.Popen(argv,cwd=case,env=launch_environment,stdin=subprocess.PIPE,stdout=error,stderr=subprocess.STDOUT,text=True,bufsize=1)
            started=b.support(b.CLEANUP_PATH).identity(process.pid);require(started is not None,'native worker identity unavailable')
            b.dump(folder/'started.json',{'pid':process.pid,'identity':started,'source_executable_sha256':row['sha256']})
            protocol=Protocol(b,process,fd,folder);reply=protocol.message();ready_reply(reply,process.pid)
            runtime_row={'path':str(case/'check'),'sha256':row['sha256'],'runtime':row['runtime']}
            b.dump(folder/'maps-ready.json',b.mapped(process,runtime_row,started))
            seq=protocol.send('LEARN',0);reply=protocol.message()
            learned_ok=learned_reply(reply,process.pid,seq)
            if not learned_ok:
                try:
                    failed=b.local('normal_run_analysis').parse_raw(raw.read_text(),lane=request['lane'],request_ids=[],expected_points=expected_points)
                    b.dump(folder/'learning-failure.json',failed)
                finally:raise ValueError('normal ordinary learning failed; raw/protocol retained')
            b.dump(folder/'maps-learned.json',b.mapped(process,runtime_row,started))
            analysis=b.local('normal_run_analysis')
            learned=analysis.parse_raw(raw.read_text(),lane=request['lane'],request_ids=[],expected_points=expected_points)
            b.dump(folder/'learning-analysis.json',learned)
            require(learned['pid']==process.pid and learned['learning']['ready'] and learned['accepted_for_continuation'],'semantic ordinary learning failed; no measurement permitted')
            parsed=None
            for i,point_id in enumerate(request['ids'],1):
                seq=protocol.send('RUN',i);reply=protocol.message()
                code,status_class=done_reply(reply,process.pid,seq,i,point_id)
                parsed=analysis.parse_raw(raw.read_text(),lane=request['lane'],request_ids=request['ids'][:i],expected_points=expected_points)
                require(parsed['pid']==process.pid and parsed['learning']['ready'],'raw PID/normal readiness differs')
                rec=parsed['measurements'][-1]
                require(rec['code']==code and rec['class']==status_class,'raw/protocol numerical status differs')
                b.dump(folder/('measurement-'+str(i)+'.json'),parsed)
                b.dump(folder/('maps-done-'+str(i)+'.json'),b.mapped(process,runtime_row,started))
                require(parsed['accepted_for_continuation'] and parsed['expected_legacy_critical_failure'] is False,'unexpected new candidate numerical failure; no legacy allowance')
            seq=protocol.send('EXIT',0);exit_reply(protocol.message(),process.pid,seq)
            process.stdin.close();process.wait(timeout=min(10.,max(.001,b.ABSOLUTE_END-b.CLEANUP-time.monotonic())))
            require(process.returncode==0,'native worker exit failed');protocol.terminal_empty()
            require(digest(raw)==parsed['raw_sha256'],'raw evidence changed after final DONE')
        require(b.local('cms_build').source_inventory(output)==row['source_inventory'],'worker changed source/include inputs')
        require(digest(case/'check')==row['sha256'],'worker ELF changed')
        clone_aliases.validate_shared(output,data['shared_aliases'])
        for name,pin in data['resources'].items():require(identity(output/name)==pin,'worker changed input resource')
        for source_name,dest_name,pin in resource_layout(data['resources']):require(identity(output/dest_name)==pin,'worker changed cwd resource')
        for name in ('param_card.dat','MadLoopParams.dat'):
            want=policy['runtime_sha256'] if name=='MadLoopParams.dat' else digest(b.HERE/'cards'/name)
            require(all(digest(p)==want and p.resolve().is_relative_to(output.resolve()) for p in output.rglob(name)),'worker changed physical/numerical cards')
        result={'request':request,'pid':process.pid,'returncode':process.returncode,'raw_sha256':digest(raw),
                'stderr_sha256':digest(folder/'stderr.txt'),'analysis':parsed,'no_retry':True,'orchestration_closed':True}
        b.dump(folder/'result.json',result);return result
    except BaseException as exc:
        worker_failure(b,folder,exc,process,started,raw,launch_attempted);raise
    finally:
        if protocol is not None:protocol.close()
        os.close(fd)
        if pipe.exists():pipe.unlink()
