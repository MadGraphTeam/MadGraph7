"""Pure strict1e-6 checks on recorded accuracy estimates, not external truth."""
from fractions import Fraction


def require(ok,message):
    if not ok:raise ValueError(message)


def enforce(analysis,*,word_value):
    normal=analysis.get('normal_analysis',analysis)
    require(normal['lane']=='candidate' and normal['expected_legacy_critical_failure'] is False,'new candidate cannot inherit legacy diagnostics allowance')
    limit=Fraction(1e-6);checked=[];unqualified=[];failures=[]
    rows=[*normal['learning']['records'],*normal['measurements']]
    for row in rows:
        initializing=row['phase']=='LEARN' and (row['call_index']==0 or row['class']!=2
                         or row['state_before'] is None or row['state_before'][:2]!=[0,1]
                         or row['state_after'][:2]!=[0,1])
        if initializing:
            unqualified.append({'phase':row['phase'],'call_index':row['call_index'],'point_id':row['point_id'],
                                'reason':'bootstrap/init/not-steady-ready learning record'})
            continue
        require(row['phase'] in ('LEARN','RUN') and len(row['rawACC'])==2,'accuracy record shape')
        if row['phase']=='RUN':
            require(row['class']==2 and row['state_before'] is not None and row['state_before'][:2]==[0,1]
                    and row['state_after'][:2]==[0,1],'measurement accuracy lacks steady-ready status')
        values=[]
        for order,word in enumerate(row['rawACC']):
            value=word_value(word)
            accepted=value is not None and Fraction(value)>=0 and Fraction(value)<=limit
            record={'phase':row['phase'],'call_index':row['call_index'],'point_id':row['point_id'],
                    'order':order,'word':word,'finite_nonnegative_below_strict_threshold':accepted}
            checked.append(record);values.append(record)
            if not accepted:failures.append(record)
    report={'schema':'strict-CMS-recorded-accuracy-v1','passed':not failures,'threshold':1e-6,
            'threshold_is_binary64_card_value':True,'checked':checked,'unqualified':unqualified,'failures':failures,
            'independent_physical_truth':False}
    if failures:
        error=ValueError('recorded candidate accuracy estimate outside0..1e-6')
        error.evidence=report;error.records=failures;raise error
    return report
