#!/usr/bin/env python3
"""Separate bounded BUILD/PARITY/PROFILE admissions; default is pure preflight."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
REPORT=ROOT/'.tirust-build/fortran-host-repair-profile-execution-1'
WORK=ROOT/'.tirust-build/fortran-host-repair-profile-work-1'
PROC_NAME='P0_uux_z'
CPU=12
CAPS={'build':600.,'parity':300.,'profile':600.}
CLEANUP=60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
LOOPS=128
CYCLES=7
LANES=('baseline','observed-0','observed-1','observed-2')
LOADER='docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py'
CLEANUP_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'
DEADLINE_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/run.py'
EXPECTED_SOURCE=None
REVIEWED_BUILD=None
REVIEWED_PARITY=None


def require(value,message):
    if not value:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def load(name,path):
    path=Path(path)
    if path.is_relative_to(ROOT) and not path.is_relative_to(HERE):
        require(digest(path)==read(HERE/'source-index.json')['support'][str(path.relative_to(ROOT))],
                'Pinned helper changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module


def modules():
    sys.path.insert(0,str(ROOT/'tools'))
    import tirust_benchmark as bench
    import tirust_benchmark_compiler as compiler
    from tirust_benchmark_worker import Worker,parse_outputs
    from tirust_benchmark_warmup import parse_warmup
    return bench,compiler,Worker,parse_outputs,parse_warmup


def verify_source():
    require(Path.cwd()==ROOT,'Run only from the MadGraph working repository')
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source-index hash required')
    seal=read(HERE/'source-index.json')
    actual={str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual==set(seal['files'])|{'source-index.json'},'Source packet exact inventory changed')
    for name,row in seal['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and not (HERE/name).is_symlink(),'Unsafe source path')
        require(digest(HERE/name)==row['sha256'] and (HERE/name).stat().st_size==row['bytes'],'Changed source packet bytes: '+name)
    for name,checksum in seal['support'].items():
        require(digest(ROOT/name)==checksum,'Changed pinned helper/support: '+name)


def protected():
    """Pure original-source/object/card/provider checks; no native query."""
    pin=read(HERE/'input-pins.json');bench=modules()[0];case=Path(pin['output'])
    for name,row in pin['files'].items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        require(path.is_file() and digest(path)==row['sha256'] and path.stat().st_size==row['bytes'],
                'Protected input changed:'+name)
    require(bench.generated_sources(case)==pin['generated_sources'],'Original source inventory changed')
    require(bench.numerical_objects(case)==pin['numerical_objects'],'Original object inventory changed')
    links={str(p.relative_to(case)):{'target':str(p.readlink()),'resolved':str(p.resolve())}
           for p in sorted(case.rglob('*')) if p.is_symlink()}
    require(links==pin['links'],'Original resource alias changed')
    require(not (case/'SubProcesses'/PROC_NAME/'worker-protocol.fifo').exists(),'Original worker is active')
    predecessor=read(HERE/'predecessor.json');base=ROOT/predecessor['donor_proposal']
    require({str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}==set(predecessor['donor_proposal_files']),
            'Closed successful scaffold inventory changed')
    for name,wanted in predecessor['donor_proposal_files'].items():require(digest(base/name)==wanted,'Scaffold source changed:'+name)
    closed=predecessor['closed_profile_capsule_index'];require(digest(ROOT/closed['path'])==closed['sha256'],'Closed profile lineage changed')
    for name,wanted in read(HERE/'toolchain-pins.json')['donor_lineage'].items():require(digest(ROOT/name)==wanted,'Tool environment lineage changed:'+name)
    tools=load('repair_tool_environment',HERE/'tool_environment.py').validate(read(HERE/'toolchain-pins.json'),environment())
    derivation=load('repair_preparation',HERE/'prepare.py').verify_materialized()
    return {'input_pins_sha256':digest(HERE/'input-pins.json'),'toolchain_pins_sha256':digest(HERE/'toolchain-pins.json'),
            'tool_admission':tools,'source_derivation':derivation,'native_executions':0,'compiler_invocations':0}


def environment():
    _,compiler,*_=modules();pin=read(HERE/'input-pins.json')
    native=[Path(p).parent for p in pin['runtime']['libraries'] if Path(p).name=='libmadloop_tirust.so']
    require(len(native)==1,'Ambiguous pinned TIRust provider')
    libraries=[ROOT/'HEPTools/ninja/lib',ROOT/'HEPTools/collier',ROOT/'HEPTools/ninjars/lib',native[0]]
    return load('repair_reconstruct_environment',HERE/'tool_environment.py').reconstruct(
        read(HERE/'toolchain-pins.json'),compiler.COMPILER_ENVIRONMENT,pin['compiler_flags']['environment'],libraries)


def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']


def expected_runtime():
    # This helper reads ELF bytes only; native loader queries are admitted later.
    loader=load('repair_loader',ROOT/LOADER);pin=read(HERE/'input-pins.json')
    exe=Path(pin['output'])/'SubProcesses'/PROC_NAME/'check'
    actual=loader._support('run.py',{'interpreter'}).interpreter(exe)
    files={str(Path(p).resolve()):h for p,h in pin['runtime']['libraries'].items()};aliases={}
    for left,right in re.findall(r'^\s*(/[^\s]+)\s*=>\s*(/[^\s]+)\s*\(',pin['runtime']['ldd'],re.M):
        if Path(left).resolve()==actual and Path(right).resolve()!=actual:
            name=str(Path(right).resolve());require('ld-linux' in Path(name).name and name in files,'Unknown old loader alias')
            aliases[name]=files.pop(name)
    require(str(actual) in files,'Actual PT_INTERP absent from closed runtime identity')
    return {'files':files,'actual_interpreter':str(actual),'historical_ldd_only_aliases':aliases}


def preflight():
    verify_source();before=protected();expected=expected_runtime()
    require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    return {'status':'source-only-preflight-passed','source_index_sha256':EXPECTED_SOURCE,
            'protected':before,'runtime':expected,'caps_seconds':CAPS,'cleanup_reserve_seconds':CLEANUP,
            'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,
            'native_executions':0,'compiler_invocations':0,'performance_acceptance':False}


def clone(source,destination):
    source=Path(source);destination=Path(destination)
    observations={'worker-protocol.fifo','worker-raw','warmup.dat','dimensions.dat','values.dat','timing.dat','timed_status.dat'}
    def ignore(directory,names):
        excluded={n for n in names if n in observations or n.endswith(('HelFilter.dat','LoopFilter.dat')) or n.startswith('dp-')}
        if Path(directory)==source:excluded.add('lib')
        return excluded
    shutil.copytree(source,destination,symlinks=False,ignore=ignore)
    original=Path(read(HERE/'input-pins.json')['output'])
    (destination/'lib').symlink_to((original/'lib').resolve(),target_is_directory=True)
    require(all(not p.is_symlink() or p==destination/'lib' for p in destination.rglob('*')),'Unexpected private mutable symlink')
    require(not any(destination.rglob('*HelFilter.dat')) and not any(destination.rglob('*LoopFilter.dat')),'Fresh learning filters remain')


def command(argv,cwd,logs,name):
    logs.mkdir(parents=True,exist_ok=True);env=environment();env['PWD']=str(cwd)
    argv=list(map(str,argv));dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd),
          'owned_controller_pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp(),
          'subprocess_new_session':False})
    with (logs/(name+'.stdout.txt')).open('xb') as out:
        done=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))})
    require(done.returncode==0,'Selected admitted command failed: '+name)
    return (logs/(name+'.stdout.txt')).read_text()


def query_runtime(directory,prebound,logs,label):
    loader=load('repair_runtime_loader',ROOT/LOADER);expected=expected_runtime()
    callback=lambda argv,name:command(argv,directory,logs,label+'-'+name)
    return loader.query_runtime(directory/'check',expected['files'],prebound,callback)


def maps(worker):
    raw=Path(f'/proc/{worker.process.pid}/maps').read_text();files={}
    for line in raw.splitlines():
        f=line.split(None,5)
        if len(f)==6 and f[-1].startswith('/'):
            require(not f[-1].endswith(' (deleted)'),'Deleted live provider')
            path=Path(f[-1]).resolve();files[str(path)]=digest(path)
    expected=expected_runtime()['files'];exe=(worker.directory/'check').resolve()
    require(all(files.get(p)==h for p,h in expected.items()) and files.get(str(exe))==digest(exe),
            'Expected provider/executable absent from actual maps')
    # Permit only the already frozen locale archive beyond ELF providers.
    extra=read(HERE/'source-index.json')['allowed_extra_mappings']
    allowed={**expected,**extra,str(exe):digest(exe)}
    require(all(allowed.get(p)==h for p,h in files.items()),'Unbound mapped provider')
    return {'pid':worker.process.pid,'maps':raw,'files':files}


def module_symbols(text):
    result={}
    for line in text.splitlines():
        words=line.split()
        if len(words)>=3 and words[-1].startswith('__mtirust_MOD_'):
            result[words[-1]]=result.get(words[-1],0)+1
    return result


def canonical_objects(output,profile_added=True):
    """Join the five mandatory direct lib aliases omitted by Path.rglob."""
    pin=read(HERE/'input-pins.json');output=Path(output);library=output/'lib'
    intended=(Path(pin['output'])/'lib').resolve()
    require(library.is_symlink() and str(library.readlink())==str(intended) and library.resolve()==intended,'Private lib alias target changed')
    require(all(not p.is_symlink() or p==library for p in output.rglob('*')),'Unexpected private alias')
    aliases=('libcts.a','libdhelas.a','libiregi.a','libmodel.a','mpmodule.mod')
    expected_library={'lib/'+name for name in aliases}
    require({name for name in pin['numerical_objects'] if name.startswith('lib/')}==expected_library,'Frozen lib inventory differs')
    actual=modules()[0].numerical_objects(output)
    require(not any(name.startswith('lib/') for name in actual),'Directory enumeration policy changed')
    for relative in expected_library:
        path=output/relative;target=pin['links'].get(relative,{}).get('resolved',str((Path(pin['output'])/relative).resolve()))
        require(path.is_file() and str(path.resolve())==target and digest(path)==pin['numerical_objects'][relative],
                'Required original library/module missing, retargeted or changed:'+relative)
        actual[relative]=digest(path)
    prefix='SubProcesses/'+PROC_NAME+'/'
    added={prefix+'repair_profile.o',prefix+'host_repair_profile_state.mod'} if profile_added else set()
    require(set(actual)==set(pin['numerical_objects'])|added,'Unexpected private object/module inventory')
    return actual


def capture_policy(directory,logs,label):
    import types
    compiler=modules()[1];real=compiler.subprocess;sequence=0
    def recorded_run(argv,**kwargs):
        nonlocal sequence
        sequence+=1;name=label+'-'+str(sequence).zfill(2);logs.mkdir(parents=True,exist_ok=True)
        dump(logs/(name+'.command.json'),{'argv':list(map(str,argv)),'cwd':str(kwargs.get('cwd',directory)),
             'scope':'Compiler-policy helper; make-internal child queries not individually traced'})
        done=real.run(argv,**kwargs);stdout=done.stdout or '';stderr=done.stderr or ''
        require(isinstance(stdout,str) and isinstance(stderr,str),'Policy captures require text')
        (logs/(name+'.stdout.txt')).write_text(stdout);(logs/(name+'.stderr.txt')).write_text(stderr)
        dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt')),'stderr_sha256':digest(logs/(name+'.stderr.txt'))})
        return done
    def recorded_output(argv,**kwargs):
        done=recorded_run(argv,stdout=real.PIPE,**kwargs)
        if done.returncode:raise real.CalledProcessError(done.returncode,argv,output=done.stdout,stderr=done.stderr)
        return done.stdout
    compiler.subprocess=types.SimpleNamespace(run=recorded_run,check_output=recorded_output,PIPE=real.PIPE,STDOUT=real.STDOUT,CalledProcessError=real.CalledProcessError)
    try:return compiler.capture_effective_flags(directory,env=environment())
    finally:compiler.subprocess=real


def build():
    bench,compiler,*_=modules();policy=load('repair_policy',HERE/'policy.py')
    pin=read(HERE/'input-pins.json');before=protected();results={}
    original_nm=command([tool('nm'),'--defined-only',str(Path(pin['output'])/'SubProcesses'/PROC_NAME/'check')],
                        ROOT,REPORT/'build'/'original-symbols','original-symbols')
    expected_module=module_symbols(original_nm)
    require(len(expected_module)==23 and all(n==1 for n in expected_module.values()),'Unexpected original MTIRUST ownership')
    for variant in ('baseline','observed'):
        output=WORK/'build'/variant;clone(Path(pin['output']),output)
        directory=output/'SubProcesses'/PROC_NAME;logs=REPORT/'build'/variant/'commands'
        for name in ('check_sa.f','improve_ps.f'):(directory/name).write_bytes((HERE/(variant+'-source')/name).read_bytes())
        shutil.copyfile(HERE/'repair_profile.f90',directory/'repair_profile.f90')
        (directory/'makefile').write_text(policy.private_makefile((directory/'makefile').read_text()))
        actual=capture_policy(directory,logs,'policy-before');policy.verify_policy(pin['compiler_flags'],actual,compiler)
        compiler_path=pin['compiler_flags']['scopes']['process']['recipes']['improve_ps.f']['compiler'][0]['path']
        expanded=command([tool('make'),'--no-print-directory','--dry-run','--always-make','SHELL='+tool('bash'),'check'],directory,logs,'expanded-check')
        recipes,link=policy.select_commands(expanded,compiler_path,environment())
        original_objects=canonical_objects(output,False)
        for index,(name,argv) in enumerate(recipes):command(argv,directory,logs,f'{index:02d}-compile-'+name)
        loader=load('repair_build_loader',ROOT/LOADER)
        prebound=loader.prelink(link,directory,environment(),lambda a,n:command(a,directory,logs,n))
        for path,wanted in expected_runtime()['files'].items():
            require(path not in prebound['bound'] or prebound['bound'][path]==wanted,'Prelink/runtime conflict')
            prebound['bound'][path]=wanted
        dump(REPORT/'build'/variant/'prelink.json',prebound)
        command(link,directory,logs,'link')
        loads=loader.requireactualmap((directory/'private-link.map').read_text(),directory,prebound,directory/'check')
        after=capture_policy(directory,logs,'policy-after');policy.verify_policy(pin['compiler_flags'],after,compiler)
        require(bench.same_compiler_policy(actual,after),'Compiler policy drift during build')
        prefix='SubProcesses/'+PROC_NAME+'/'
        changed={prefix+'check_sa.o',prefix+'improve_ps.o'}
        added={prefix+'repair_profile.o',prefix+'host_repair_profile_state.mod'}
        objects=canonical_objects(output)
        require({k:v for k,v in original_objects.items() if k not in changed}=={k:v for k,v in objects.items() if k not in changed|added},'Unselected physics object changed')
        if variant=='baseline':require(objects[prefix+'improve_ps.o']==pin['numerical_objects'][prefix+'improve_ps.o'],'Uninstrumented repair recompilation differs')
        linked=command([tool('nm'),'--defined-only','check'],directory,logs,'linked-symbols')
        require(module_symbols(linked)==expected_module,'Installed MTIRUST ownership changed')
        names=[line.split()[-1] for line in linked.splitlines() if len(line.split())>=3]
        for name in ('ml5_0_improve_ps_point_precision_','ml5_0_mp_improve_ps_point_precision_'):
            require(names.count(name)==1,'Public repair ABI missing or duplicated')
        private={name for name in names if name.startswith('ml5_0_host_repair_')}
        expected_private={'ml5_0_host_repair_dp_body_','ml5_0_host_repair_mp_body_'} if variant=='observed' else set()
        require(private==expected_private and all(names.count(name)==1 for name in private),'Private repair body ownership differs')
        require('libtirust.a(' in (directory/'private-link.map').read_text() and not (directory/'mtirust.o').exists(),'Installed tensor wrapper archive must remain unchanged')
        runtime=query_runtime(directory,prebound,logs,'build')
        results[variant]={'output':str(output),'sources':bench.generated_sources(output),'objects':objects,
            'executable_sha256':digest(directory/'check'),'compiler_flags':after,'policy':policy.verify_policy(pin['compiler_flags'],after,compiler),
            'prelink_sha256':digest(REPORT/'build'/variant/'prelink.json'),'actual_link_loads':loads,
            'link_map_sha256':digest(directory/'private-link.map'),'MTIRUST_definitions':expected_module,'private_repair_definitions':sorted(private),'runtime':runtime}
    require(protected()==before,'Original changed during build')
    dump(REPORT/'build/result.json',{'status':'passed','variants':results,'protected':before,
        'source_index_sha256':EXPECTED_SOURCE,'native_model_calls':0,'recording_program_calls':0,
        'compiler_invocations_scope':'Two three-unit compile/link builds; all original scientific flags preserved.'})


def receipt(stage,reviewed):
    require(reviewed and digest(REPORT/stage/'terminal.json')==reviewed,'Separately reviewed '+stage+' terminal hash required')
    terminal=read(REPORT/stage/'terminal.json');result=read(REPORT/stage/'result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],
            'Predecessor stage did not close successfully')
    require(terminal['result_sha256']==digest(REPORT/stage/'result.json') and result['status']=='passed'
            and result['source_index_sha256']==EXPECTED_SOURCE,'Predecessor result/source binding changed')
    return result


def verified_build():
    bench=modules()[0];built=receipt('build',REVIEWED_BUILD);loader=load('repair_verify_loader',ROOT/LOADER)
    for variant,row in built['variants'].items():
        output=Path(row['output']);directory=output/'SubProcesses'/PROC_NAME
        require(bench.generated_sources(output)==row['sources'] and canonical_objects(output)==row['objects']
                and digest(directory/'check')==row['executable_sha256'],'Reviewed private build changed')
        require(digest(directory/'private-link.map')==row['link_map_sha256'],'Private link map changed')
        prelink=REPORT/'build'/variant/'prelink.json'
        require(digest(prelink)==row['prelink_sha256'],'Reviewed prelink binding changed')
        require(loader.requireactualmap((directory/'private-link.map').read_text(),directory,read(prelink),directory/'check')
                ==row['actual_link_loads'],'Actual LOAD binding changed')
    return built


def private_binding(output,built):
    bench=modules()[0];directory=output/'SubProcesses'/PROC_NAME;pin=read(HERE/'input-pins.json')
    require(bench.generated_sources(output)==built['sources'] and canonical_objects(output)==built['objects']
            and digest(directory/'check')==built['executable_sha256'],'Execution copy changed')
    cards=bench.numerical_card_inputs(output)
    alias='SubProcesses/'+PROC_NAME+'/MadLoop5_resources/MadLoopParams.dat'
    expected={**pin['numerical_cards'],alias:next(iter(pin['numerical_cards'].values()))}
    require(cards==expected,'Private four-card inventory differs')
    physical=bench.resolved_parameter_card(directory)
    lane=read(pin['closed_input'])
    require(physical is not None and digest(physical)==lane['param_card_sha256']
            ==digest(output/'Cards/param_card.dat'),'Private physical card changed')
    for name in cards:
        require((output/name).resolve().is_relative_to(output.resolve()),'Mutable card alias escapes private export')
    return {'cards':cards,'physical_sha256':digest(physical),'executable_sha256':built['executable_sha256']}


def exact_command(worker,mode,destination,observed):
    analysis=load('repair_analysis',HERE/'analyze.py')
    worker.sequence+=1;worker._send(f'DPTEST {worker.sequence} {mode}')
    require(worker._message()==['DPTESTED',str(worker.sequence),str(mode)],'Full100 exact command failed')
    destination.mkdir(parents=True,exist_ok=False)
    for name in ('dp-exact.dat','dp-ieee.dat','dp-parity-timers.tsv','dp-probe.tsv'):
        shutil.copyfile(worker.directory/name,destination/name)
    return {'rows':analysis.exact((destination/'dp-exact.dat').read_text()),
            'ieee':analysis.ieee((destination/'dp-ieee.dat').read_text()),
            'profile':analysis.profile((destination/'dp-parity-timers.tsv').read_text(),mode,100,observed),
            'probe':analysis.probe((destination/'dp-probe.tsv').read_text())}


def start_worker(output,variant,built,report,stack):
    bench,_,Worker,_,parse_warmup=modules();directory=output/'SubProcesses'/PROC_NAME
    before=private_binding(output,built)
    runtime=query_runtime(directory,read(REPORT/'build'/variant/'prelink.json'),report/'commands','before')
    pin=read(HERE/'input-pins.json')
    worker=stack.enter_context(Worker([tool('taskset'),'-c',str(CPU),str(directory/'check'),pin['points']],
             directory,report/'worker.log',env=environment(),timeout=210.))
    ready={k:getattr(worker,k) for k in ('points','ndim','nso','nborn','cold_seconds')}
    require([ready[k] for k in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong n1 worker dimensions')
    warmup=parse_warmup(directory,9,100,ready);closed=read(pin['closed_observation'])
    require(warmup['rows']==closed['rows'],'Unchanged full100 learning differs from closed current n1')
    # Retain and compare every learning row, including bootstrap call0.
    reference=Path(pin['closed_observation']).with_name('warmup.dat')
    require((directory/'warmup.dat').read_bytes()==reference.read_bytes(),'Complete bootstrap/learning trace changed')
    dump(report/'ready.json',ready);dump(report/'warmup.json',warmup)
    dump(report/'maps-before.json',maps(worker));dump(report/'private-before.json',before)
    return worker,{'before':before,'runtime':runtime,'ready':ready}


def finish_worker(worker,output,variant,built,report,before):
    dump(report/'maps-after.json',maps(worker));after=private_binding(output,built)
    require(after==before['before'],'Private inputs changed during execution')
    runtime=query_runtime(worker.directory,read(REPORT/'build'/variant/'prelink.json'),report/'commands','after')
    require(all(runtime[k]==before['runtime'][k] for k in ('loader','loader_sha256','files')),
            'Runtime changed during worker execution')
    dump(report/'private-after.json',after)


def parity():
    from contextlib import ExitStack
    built=verified_build();before=protected();rows={}
    for lane in LANES:
        variant='baseline' if lane=='baseline' else 'observed';mode=0 if lane=='baseline' else int(lane[-1])
        report=REPORT/'parity'/lane;output=WORK/'parity'/lane
        clone(Path(built['variants'][variant]['output']),output)
        with ExitStack() as stack:
            worker,binding=start_worker(output,variant,built['variants'][variant],report,stack)
            rows[lane]=exact_command(worker,mode,report/'exact',variant=='observed')
            if lane!='baseline':
                require(rows[lane]['rows']==rows['baseline']['rows'] and rows[lane]['ieee']==rows['baseline']['ieee'],
                        'Full100 exact coefficient/status/accuracy/IEEE parity failed')
            finish_worker(worker,output,variant,built['variants'][variant],report,binding)
    require(protected()==before,'Original changed during parity')
    dump(REPORT/'parity/result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,
          'build_terminal_sha256':REVIEWED_BUILD,'lanes':rows,'warmup_points':100,
          'parity_scope':'All100 points, both total/split columns, exact binary64 words, status and IEEE pre/post',
          'timers_from_parity_are_qualification_only':True,'performance_acceptance':False})


def profile():
    from contextlib import ExitStack
    built=verified_build();par=receipt('parity',REVIEWED_PARITY)
    require(par['build_terminal_sha256']==REVIEWED_BUILD,'Parity belongs to another private build')
    analysis=load('repair_profile_analysis',HERE/'analyze.py');before=protected();cycles=[]
    workers={};bindings={}
    with ExitStack() as stack:
        for lane in LANES:
            variant='baseline' if lane=='baseline' else 'observed';mode=0 if lane=='baseline' else int(lane[-1])
            output=WORK/'profile'/lane;report=REPORT/'profile'/lane
            clone(Path(built['variants'][variant]['output']),output)
            worker,binding=start_worker(output,variant,built['variants'][variant],report,stack)
            exact=exact_command(worker,mode,report/'exact-before-timing',variant=='observed')
            require(exact['rows']==par['lanes']['baseline']['rows'] and exact['ieee']==par['lanes']['baseline']['ieee'],
                    'Fresh profile worker failed full100 exact/IEEE parity before timing')
            workers[lane]=worker;bindings[lane]=(output,variant,binding)
        for cycle in range(1,CYCLES+1):
            # Alternate order, with fixed cyclic rotations among the overhead controls.
            order=list(LANES);shift=(cycle-1)%len(order);order=order[shift:]+order[:shift]
            if cycle%2==0:order.reverse()
            result={'cycle':cycle,'order':order,'lanes':{}};timed_ieee=None
            for lane in order:
                worker=workers[lane];variant=bindings[lane][1];mode=2 if lane=='baseline' else int(lane[-1])
                worker.sequence+=1;worker._send(f'DPRUN{mode} {worker.sequence} {LOOPS}')
                require(worker._message()==['DONE',str(worker.sequence),str(LOOPS)],'Fixed full-amplitude profile batch failed')
                raw=REPORT/'profile'/lane/f'cycle-{cycle}';raw.mkdir(exist_ok=False)
                for name in ('timing.dat','values.dat','timed_status.dat','dp-timed-exact.dat','dp-timed-ieee.dat','dp-timers.tsv'):
                    shutil.copyfile(worker.directory/name,raw/name)
                observation=modules()[3](worker.directory,9,100,LOOPS)
                require(observation['timed_status_counts']=={'219':100*LOOPS},'A timed amplitude failed or rescued')
                exact=analysis.exact((raw/'dp-timed-exact.dat').read_text())
                require(exact==par['lanes']['baseline']['rows'],'Timed final full100 exact outputs changed')
                flags=analysis.ieee((raw/'dp-timed-ieee.dat').read_text(),timed=True)
                if timed_ieee is None:timed_ieee=flags
                require(flags==timed_ieee,'Timed-batch actual IEEE states differ')
                result['lanes'][lane]={'seconds':observation['seconds'],'timed_status_counts':observation['timed_status_counts'],
                    'ieee':flags,'profile':analysis.profile((raw/'dp-timers.tsv').read_text(),mode,100*LOOPS,variant=='observed')}
            cycles.append(result);dump(REPORT/'profile'/f'cycle-{cycle}.json',result)
        for lane,worker in workers.items():
            output,variant,binding=bindings[lane]
            finish_worker(worker,output,variant,built['variants'][variant],REPORT/'profile'/lane,binding)
    require(protected()==before,'Original changed during profile')
    dump(REPORT/'profile/result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,
          'build_terminal_sha256':REVIEWED_BUILD,'parity_terminal_sha256':REVIEWED_PARITY,
          'loops_per_batch':LOOPS,'points_per_traversal':100,'cycles':cycles,'summary':analysis.summary(cycles),
          'cpu':CPU,'cpu_reservation':False,'performance_acceptance':False,'optimized':False,
          'limitations':['Shared-host instrumentation attribution, not local runtime acceptance.',
             'DP wrapper time includes its nested MP call and hook overhead; no intervals are probe-corrected.',
             'Counters/clocks measure actual phase-space repair bodies, not the complete unaccounted host interval.',
             'No speedup claim; common repair code affects all reducers but this diagnostic measures backend9 only.']})


def require_admission(stage):
    admission=read(REPORT/stage/'admission.json')
    require(admission['stage']==stage and admission['source_index_sha256']==EXPECTED_SOURCE
            and admission['reviewed_build_sha256']==REVIEWED_BUILD and admission['reviewed_parity_sha256']==REVIEWED_PARITY
            and admission['cap_seconds']==CAPS[stage] and admission['resource_limits']==LIMITS
            and admission['parent_pid']==os.getppid(),'Missing or mismatched separate supervisor admission')
    actual={name:list(resource.getrlimit(kind)) for kind,name in
            ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}
    require(actual=={k:[v,v] for k,v in LIMITS.items()},'Actual child resource limits differ')
    require(os.sched_getaffinity(0)=={CPU},'Actual child affinity differs from nonexclusive CPU12')
    dump(REPORT/stage/'actual-limits.json',{'actual':actual,'pid':os.getpid(),'session':os.getsid(0)})


def cleanup_owned(owned,end):
    budget=min(55.,max(0.,end-time.monotonic()))
    result=owned.stop(cooperative_seconds=budget*45/55,terminate_seconds=budget*5/55,kill_seconds=budget*5/55)
    require(not result['survivors'],'Owned descendant cleanup unresolved')
    return result


def stage(name):
    cleanup=load('repair_cleanup',ROOT/CLEANUP_HELPER);deadline_support=load('repair_deadline',ROOT/DEADLINE_HELPER)
    deadline_support.STAGE_SECONDS=CAPS[name];deadline_support.CLEANUP_RESERVE=CLEANUP
    directory=REPORT/name;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':name,'source_index_sha256':EXPECTED_SOURCE,'cap_seconds':CAPS[name],
           'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running'}
    ownership=load('repair_raw_ownership',HERE/'ownership.py')
    owned=None;process=None;raw_record=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,deadline_support.StageDeadline() as deadline:
            entry['deadline_monotonic']=deadline.end;requests.check();verify_source();protected()
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(Path(__file__).relative_to(ROOT)),
                  '--child',name,'--source',EXPECTED_SOURCE]
            if REVIEWED_BUILD:argv+=['--reviewed-build',REVIEWED_BUILD]
            if REVIEWED_PARITY:argv+=['--reviewed-parity',REVIEWED_PARITY]
            dump(directory/'admission.json',{**entry,'command':argv,'parent_pid':os.getpid(),
                 'reviewed_build_sha256':REVIEWED_BUILD,'reviewed_parity_sha256':REVIEWED_PARITY})
            with (directory/'console.log').open('xb') as out:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid)
                    owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Admitted stage failed; no automatic retry')
            protected();verify_source();requests.check()
            entry.update(status='passed',result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:
                entry['cleanup']=cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error),publication_scope='Failure retained; no measurement pass')
        dump(directory/'terminal.json',entry)
        raise


def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard resource limit too small')
        resource.setrlimit(kind,(value,value))


def main():
    global EXPECTED_SOURCE,REVIEWED_BUILD,REVIEWED_PARITY
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group()
    group.add_argument('--stage',choices=tuple(CAPS));group.add_argument('--child',choices=tuple(CAPS))
    parser.add_argument('--execute',action='store_true');parser.add_argument('--source',required=True)
    parser.add_argument('--reviewed-build');parser.add_argument('--reviewed-parity')
    args=parser.parse_args();EXPECTED_SOURCE=args.source;REVIEWED_BUILD=args.reviewed_build;REVIEWED_PARITY=args.reviewed_parity
    for value in (EXPECTED_SOURCE,REVIEWED_BUILD,REVIEWED_PARITY):
        if value is not None and not re.fullmatch('[0-9a-f]{64}',value):parser.error('Expected exact SHA256 receipt')
    selected=args.stage or args.child
    if selected in ('parity','profile') and not REVIEWED_BUILD:parser.error('Separate reviewed BUILD terminal hash required')
    if selected=='profile' and not REVIEWED_PARITY:parser.error('Separate reviewed PARITY terminal hash required')
    if selected=='build' and (REVIEWED_BUILD or REVIEWED_PARITY):parser.error('BUILD cannot borrow later-stage receipts')
    if selected=='parity' and REVIEWED_PARITY:parser.error('PARITY cannot borrow a PROFILE admission')
    if args.child:
        limits();require_admission(args.child);verify_source();protected()
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX)
            {'build':build,'parity':parity,'profile':profile}[args.child]()
        return
    result=preflight()
    if not args.stage:
        require(not args.execute,'--execute needs one explicit stage');print(json.dumps(result,indent=2));return
    require(args.execute,'A real stage needs --execute after separate source review')
    if args.stage in ('parity','profile'):verified_build()
    if args.stage=='profile':receipt('parity',REVIEWED_PARITY)
    stage(args.stage)


if __name__=='__main__':main()
