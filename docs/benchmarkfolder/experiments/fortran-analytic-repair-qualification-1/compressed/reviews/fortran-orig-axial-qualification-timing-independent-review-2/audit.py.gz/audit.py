from pathlib import Path
import json,hashlib,ast,types,sys,math,re,statistics,struct,collections,collections.abc
from collections import Counter
root=Path.cwd();source=root/'.tirust-build/fortran-orig-axial-qualification-proposal-2';run=root/'.tirust-build/fortran-orig-axial-qualification-execution-2/timing';read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_sha='bac02ef904383e8215e40c6e8306f00b0b3ca46f9ea5233e94b4ac0e76e125cf';assert sha(source/'source-index.json')==source_sha
pins=read(source/'input-pins.json');assert sha(source/'input-pins.json')==read(source/'source-index.json')['files']['input-pins.json']['sha256'];assert pins['cycles']==7 and pins['traversals_per_batch']==128
terminal=read(run/'terminal.json');result=read(run/'result.json');assert sha(run/'terminal.json')=='46b5b2fa0fef80b785b11e068c17c73d1716a3e2861add4fe80a5e4ac55187c1';assert sha(run/'result.json')==terminal['result_sha256']=='323e8ffaaf4b70a1419c46f31ee305f85bb7ec4701495a8cc87be186dea4f18d'
assert terminal['status']==result['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['events'] and not terminal['cleanup']['survivors'] and terminal['cap_seconds']==300 and terminal['cleanup_reserve_seconds']==60
assert result['source_index_sha256']==terminal['source_index_sha256']==source_sha and result['calls_per_batch']==12800 and not result['performance_acceptance'] and not result['candidate_promoted']
predecessors={'build':'79443cd96935e9b0f0768a07870e0d5d5d0805a08a675c67a45aaa7cb2ef3a44','repair':'e153961127a0d4ee8a5ca4f2345a0ef273b9f18b0e2720dcb4641ff60532a6f9','amplitude':'82446c2e6a2ccc46ca16b42c7b4c44c42cbc04fa21b5115141f1c0d09db8f286'}
for k,h in predecessors.items():assert terminal['reviewed'][k]==result[k+'_terminal_sha256']==sha(run.parent/k/'terminal.json')==h
reviews={'repair':'c6e47819bca4ebf4f013cee10d050641c1f5449b4ad3579a893630932306a23c','amplitude':'81535b9f4a09c18fa3e99d7233acae62943c747b8d0c0dcaacb7e300691e26ab'}
for k,h in reviews.items():assert sha(root/f'.tirust-build/fortran-orig-axial-qualification-{k}-independent-review-2/receipt.json')==h
build=read(run.parent/'build/result.json');amplitude=read(run.parent/'amplitude/result.json')
for k in ('build','amplitude'):assert sha(run.parent/k/'result.json')==read(run.parent/k/'terminal.json')['result_sha256']
owner_path=root/'.tirust-build/fortran-orig-axial-qualification-timing-owner-readout-2.json';assert sha(owner_path)=='485c86738d7ba1bd7213abd2f74d455c17ed4cd4fe5c4de4f4d82e4f150f2d21';owner=read(owner_path)
parent=Path(pins['profile_parent']);parentpins=read(parent/'input-pins.json');parentindex=read(parent/'source-index.json')
for n in ('input-pins.json','source-index.json'):assert sha(parent/n)==pins['external_files'][str(parent/n)]['sha256']
raw={str(p.relative_to(run)):p.read_text() for p in run.rglob('*.dat')};saved={str(p.relative_to(run)):read(p) for p in run.rglob('*.json')};identities={str(p.relative_to(run)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in run.rglob('*') if p.is_file()}
maps={};input_checks=0
for role in ('original','candidate'):
 output=root/'.tirust-build/fortran-orig-axial-qualification-work-2/timing'/role;private=saved[role+'/private-before.json'];wanted={**parentpins['numerical_cards'],'SubProcesses/P0_uux_z/MadLoop5_resources/MadLoopParams.dat':next(iter(parentpins['numerical_cards'].values()))};assert private['cards']==wanted
 for n,h in wanted.items():assert sha(output/n)==h;input_checks+=1
 assert sha(output/'Cards/param_card.dat')==private['physical_sha256']==read(Path(parentpins['closed_input']))['param_card_sha256'];input_checks+=1
 b=build['variants'][role]['amplitude'];exe=str(output/'SubProcesses/P0_uux_z/check');assert sha(Path(exe))==b['executable_sha256'];input_checks+=1
 before=saved[role+'/maps-before.json'];after=saved[role+'/maps-after.json'];assert before['files']==after['files'] and before['pid']==after['pid']
 providers=b['runtime']['files'];assert len(providers)==15;allowed={**providers,**parentindex['allowed_extra_mappings'],exe:b['executable_sha256']}
 for record in (before,after):
  assert len(record['files'])==16 and all(record['files'].get(k)==v for k,v in providers.items()) and record['files'][exe]==b['executable_sha256'] and all(allowed.get(k)==v for k,v in record['files'].items())
  names={f[-1] for line in record['maps'].splitlines() if len(f:=line.split(None,5))==6 and f[-1].startswith('/')};assert names==set(record['files']) and not any(n.endswith(' (deleted)') for n in names)
 assert any(x['pid']==before['pid'] and x['session']==before['pid'] for x in terminal['cleanup']['observed_owned_processes']);maps[role]={'pid':before['pid'],'provider_count':15,'ELF_sha256':b['executable_sha256'],'before_after_file_closure_equal':True,'raw_map_text_equal':before['maps']==after['maps'],'saved_snapshots_checked':2}
point=Path(pins['points']);pointsha=parentpins['files'][str(point.relative_to(root))]['sha256'];assert sha(point)==pointsha
texts={k:Path(pins[k]).read_text() for k in ('analysis','collector')}
for k in texts:assert sha(Path(pins[k]))==pins['external_files'][pins[k]]['sha256']
bench=root/'tools/tirust_benchmark.py';assert sha(bench)==parentindex['support']['tools/tirust_benchmark.py'];bt=bench.read_text();node=next(n for n in ast.parse(bt).body if isinstance(n,ast.FunctionDef) and n.name=='compare_rows');comparator=ast.get_source_segment(bt,node)
blocked=[];pure=False

def guard(event,args):
 if pure and (event=='open' or event.startswith(('subprocess.','ctypes.','socket.')) or event in ('os.system','os.fork','os.exec','os.posix_spawn','os.kill','os.killpg','os.remove','os.rename','os.mkdir','os.rmdir','os.symlink','os.link')):blocked.append(event);raise RuntimeError(event)
sys.addaudithook(guard);mods={k:types.ModuleType('offline_'+k) for k in texts};scope={};fresh={};pairs=[];durations=[];statuses=Counter();cold={};codes={i:219 for i in range(1,101)}
pure=True
try:
 for k in texts:exec(compile(texts[k],pins[k],'exec'),mods[k].__dict__)
 exec(compile(comparator,str(bench),'exec'),scope);a=mods['analysis'];c=mods['collector'];compare=scope['compare_rows']
 for role in ('original','candidate'):
  fresh[role]={'learning':c.learning(raw[role+'/warmup.dat']),'rows':a.exact(raw[role+'/exact/exact-words.dat'],codes),'ieee':a.ieee(raw[role+'/exact/exact-ieee.dat'])}
  own=a.compare_own(amplitude['variants'][role]['exact']['rows'],fresh[role]['rows']);assert own==saved[role+'/own-qualification-comparison.json']==owner['fresh_own_comparisons'][role] and own['passed'] and own['accuracy_drift_count']==0
  assert fresh[role]['learning']['history']==amplitude['variants'][role]['learning']['history'] and fresh[role]['ieee']==amplitude['variants'][role]['exact']['ieee'] and a.compare_variants(fresh[role]['learning']['rows'],fresh[role]['rows'],compare)['passed']
 for i in range(1,8):
  record={'pair':i,'order':['original','candidate'] if i%2 else ['candidate','original']}
  for role in record['order']:
   prefix=f'{role}/pair-{i}/';rows=a.exact(raw[prefix+'timed-exact-words.dat'],codes);assert a.decimal_exact(raw[prefix+'values.dat'],codes)==rows
   own=a.compare_own(fresh[role]['rows'],rows);assert own==saved[prefix+'own-comparison.json'] and own['passed'] and own['accuracy_drift_count']==0
   state=a.ieee(raw[prefix+'timed-ieee.dat'],[0]);assert state[0][2:]==fresh[role]['ieee'][0][2:] and state[1][2:]==fresh[role]['ieee'][-1][2:]
   counts=a.status_histogram(raw[prefix+'timed_status.dat'],codes,128);assert counts=={'219':12800};statuses[role+':219']+=12800
   fields=raw[prefix+'timing.dat'].split();assert len(fields)==2;first,seconds=map(float,fields);assert math.isfinite(first) and first>0 and math.isfinite(seconds) and seconds>0
   assert role not in cold or cold[role]==first;cold[role]=first;durations.append(seconds)
   record[role]={'seconds':seconds,'rows':rows,'ieee':state,'timed_status_counts':counts,'own_comparison':own}
  record['comparison']=a.compare_variants(record['original']['rows'],record['candidate']['rows'],compare);assert record['comparison']['passed'] and record['comparison']['coefficient_word_difference_count']==record['comparison']['accuracy_difference_count']==0
  assert record==saved[f'pair-{i}.json'];pairs.append(record)
 summary=a.timing_summary(pairs)
finally:pure=False
assert not blocked and pairs==result['pairs'] and summary==result['summary']==owner['summary'] and len(durations)==14 and min(durations)>=1
assert dict(statuses)==owner['timed_statuses']=={'original:219':89600,'candidate:219':89600} and sum(statuses.values())==179200 and cold==owner['cold_first_amplitude_seconds']
assert summary['median_ratio']==statistics.median(x['candidate']['seconds']/x['original']['seconds'] for x in pairs)==0.952790310414709
for role in ('original','candidate'):
 ready=saved[role+'/ready.json'];assert ready==result['initialization'][role] and [ready[k] for k in ('points','ndim','nso','nborn')]==[100,1,1,1] and ready['cold_seconds']==cold[role]
folder=Path(__file__).parent
report='''# Independent closed TIMING2 audit\n\nPASS as a descriptive shared-host N1 result. Pure sealed parsers and original comparator reproduce all7 alternating pairs,14 durations and complete stored result. Each batch repeats100 saved points128 times:12800 accepted219 calls,179200 total. Status histograms cover every timed call. Coefficient/accuracy words are retained only for each batch's final100-point traversal:200 overall/sole-order duplicate rows and800 coefficient words per batch. This is neither179200 independent points nor coefficient observation at every timed call. All decimal/raw, own-variant, cross-arm, history and observed-state gates pass with zero retained coefficient/accuracy-word differences.\n\nBatch durations are1.119885975–1.231192552 seconds. Median candidate/original paired ratio is0.952790310414709, with median candidate/original durations1.154541714/1.220571141 seconds. This compares the private analytic candidate with its pinned original repair variant. It is not the9228 baseline default-chain comparison, eight-process acceptance or a confidence-bound performance result. No promotion follows. Cold timings describe the first amplitude clock, not total program/model/library startup.\n\nAll4 saved maps bind15 providers plus correct own ELF, with unchanged file closures/PIDs. Anonymous mapping text changes during timing; full raw-map identity was an overly strict audit assertion and was corrected without changing evidence. Frozen private cards, physical cards,ELFs and saved points rehash. Retained cleanup events[]/survivors[] do not re-observe historical absence. IEEE parity is observational, not trap freedom or internal software-latch/precision evidence. No native program, tool/library query, test or public/production/Git/PDF action occurred.\n'''
(folder/'report.md').write_text(report)
receipt={'schema':'analytic-orig-closed-timing-independent-review-v1','status':'passed_descriptive_shared_host_N1_only','source_index_sha256':source_sha,'terminal_sha256':sha(run/'terminal.json'),'result_sha256':sha(run/'result.json'),'owner_readout_sha256':sha(owner_path),'predecessor_terminals':predecessors,'accepted_reviews':reviews,'pure_parsers_sha256':{k:sha(Path(pins[k])) for k in texts},'comparator_file_sha256':sha(bench),'all_recorded_pairs_and_summary_reproduced':True,'pairs':7,'batches':14,'traversals_per_batch':128,'calls_per_batch':12800,'accepted_statuses':dict(statuses),'total_timed_calls':179200,'retained_batch_final_points':100,'retained_duplicate_order_rows_per_batch':200,'retained_coefficient_words_per_batch':800,'coefficients_observed_at_all_timed_calls':False,'retained_coefficient_word_differences':0,'accuracy_word_drift':0,'own_history_word_observed_state_gates_passed':True,'decimal_raw_joins_passed':True,'minimum_batch_seconds':min(durations),'maximum_batch_seconds':max(durations),'summary':summary,'cold_first_amplitude_seconds':cold,'runtime_maps':maps,'private_card_physical_card_ELF_checks':input_checks,'saved_points_sha256':pointsha,'raw_file_identities':identities,'forbidden_parser_effect_attempts':blocked,'audit_script_correction':'Full raw maps differ through anonymous mappings; exact file closures and PIDs remain fixed and both snapshots are independently checked.','new_native_programs_tools_library_queries_tests':0,'formal_baseline_default_chain_or_eight_process_acceptance':False,'performance_acceptance':False,'production_promotion':False,'public_production_Git_PDF_changes':False,'cleanup':'Retained successful terminal events[]/survivors[] only.','report_sha256':sha(folder/'report.md')}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(folder/'receipt.json'),'sha256':sha(folder/'receipt.json'),'report_sha256':sha(folder/'report.md'),'median_ratio':summary['median_ratio'],'batch_seconds':[min(durations),max(durations)],'accepted_statuses':dict(statuses),'forbidden_effect_attempts':blocked},indent=2))
