#!/usr/bin/env python3
"""Only file/pure tests; outer process/library/network/signal effects blocked."""
import argparse
import contextlib
import ctypes
import fcntl
import importlib.util
import io
import json
import os
from pathlib import Path
import resource
import signal
import socket
import subprocess
import sys
import unittest
import unittest.mock

HERE=Path(__file__).resolve().parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source');parser.add_argument('--log',type=Path);args=parser.parse_args()
    attempts=[]
    def blocked(*unused,**kwargs):attempts.append('forbidden external effect');raise AssertionError('Pure tests forbid external effects')
    for name in ('Popen','run','call','check_call','check_output'):setattr(subprocess,name,blocked)
    for name in ('CDLL','PyDLL'):setattr(ctypes,name,blocked)
    for name in ('system','fork','forkpty','posix_spawn','posix_spawnp','kill','killpg','sched_setaffinity'):
        if hasattr(os,name):setattr(os,name,blocked)
    for name in dir(os):
        if name.startswith(('execl','execv','spawn')):setattr(os,name,blocked)
    socket.socket=blocked;signal.signal=blocked;signal.setitimer=blocked;resource.setrlimit=blocked;fcntl.flock=blocked
    out=io.StringIO()
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):
        tests=module('axial_dormant_tests',HERE/'test_proposal.py')
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
        preflight=None
        if args.source:
            controller=module('axial_dormant_preflight',HERE/'controller.py');controller.SOURCE=args.source
            preflight=controller.preflight()
        summary={'tests':result.testsRun,'passed':result.wasSuccessful(),'optimized_python':not __debug__,
            'blocked_effect_attempts':attempts,'preflight':preflight,'native_calls':0,'compiler_invocations':0}
        print(json.dumps(summary,sort_keys=True,allow_nan=False))
    text=out.getvalue()
    if args.log:
        if not args.log.resolve().is_relative_to(HERE.parent) or args.log.resolve().is_relative_to(HERE):raise ValueError('Logs must be outside frozen source')
        args.log.parent.mkdir(parents=True,exist_ok=True)
        with args.log.open('x') as stream:stream.write(text)
    print(text,end='');return 0 if result.wasSuccessful() and not attempts else 1
if __name__=='__main__':raise SystemExit(main())
