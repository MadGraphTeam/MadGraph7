"""Pure raw-word standalone repair journal qualification. No file/tool effects."""
from fractions import Fraction as Q
import re

def require(ok,message):
    if not ok:raise ValueError(message)

def number(word):
    require(isinstance(word,str) and re.fullmatch('[0-9A-F]{16}|[0-9A-F]{32}',word),'Invalid IEEE word')
    width=len(word)*4;precision,bias=(53,1023) if width==64 else (113,16383)
    bits=int(word,16);exponent=(bits>>(precision-1))&((1<<(width-precision))-1)
    if exponent==(1<<(width-precision))-1:return None
    fraction=bits&((1<<(precision-1))-1)
    result=Q(fraction if exponent==0 else fraction+(1<<(precision-1))) * Q(2)**((1-bias if exponent==0 else exponent-bias)-precision+1)
    return -result if bits>>(width-1) else result

def journal(text,corpus):
    lines=[line.split() for line in text.splitlines() if line.strip()];position=0
    def take(prefix,length=None):
        nonlocal position
        require(position<len(lines),'Truncated repair journal');row=lines[position];position+=1
        require(row[:len(prefix)]==prefix and (length is None or len(row)==length),'Unexpected repair record: '+str(row))
        return row
    count=len(corpus['cases']);take(['META','AXIAL_REPAIR_UNIT_V1',str(count)],3)
    mass=take(['MASS_Z'],2)[1];require(len(mass)==32 and number(mass) is not None,'Bad model mass')
    initial=take(['ENV','INITIAL','0','0'],15)
    def env(row):
        values=list(map(int,row[4:]));require(values[0] in range(-1,4) and all(v in (0,1) for v in values[1:]),'Invalid IEEE state')
        return values
    initial=env(initial);rows=[]
    for case in corpus['cases']:
        for precision in (1,2):
            key=[str(case['id']),str(precision)]
            take(['CASE',*key,str(int(case['legacy_identity_required'])),case['tag']],5)
            def vectors(label):
                result=[]
                for leg in range(1,4):
                    for component in range(4):
                        row=take([label,*key,str(leg),str(component)],6);word=row[-1]
                        require(len(word)==(16 if precision==1 else 32),'Wrong precision width');number(word);result.append(word)
                return result
            before=vectors('IN');require(before==[pair[precision-1] for pair in case['words']],'Input fixture words changed')
            fpbefore=env(take(['ENV','BEFORE',*key],15));fpafter=env(take(['ENV','AFTER',*key],15))
            after=vectors('OUT');take(['ENDCASE',*key],3)
            rows.append({**{k:case[k] for k in ('id','tag','refused','path_expected_from_source',
                'physical_projection_required','legacy_identity_required')},'precision':precision,
                'input':before,'output':after,'ieee_before':fpbefore,'ieee_after':fpafter})
    take(['END',str(count)],2);require(position==len(lines),'Extra journal records')
    return {'mass_word':mass,'initial_ieee':initial,'rows':rows}

def diagnostics(text,corpus):
    rows=[];outside=[];current=None
    for line in text.splitlines():
        fields=line.split()
        if fields and fields[0]=='CASE_BEGIN':
            require(current is None and len(fields)==4,'Bad diagnostic begin')
            current={'id':int(fields[1]),'precision':int(fields[2]),'tag':fields[3],'lines':[]}
        elif fields and fields[0]=='CASE_END':
            require(current is not None and fields==['CASE_END',str(current['id']),str(current['precision'])],'Bad diagnostic end')
            rows.append(current);current=None
        elif current is None:outside.append(line)
        else:current['lines'].append(line)
    require(current is None,'Unclosed diagnostic case')
    require([(r['id'],r['precision'],r['tag']) for r in rows]==[(c['id'],p,c['tag']) for c in corpus['cases'] for p in (1,2)],'Diagnostic case coverage differs')
    return {'outside':outside,'rows':rows}

def residual(row,mass_word):
    values=[number(word) for word in row['output']];inputs=[number(word) for word in row['input']]
    if any(value is None for value in values+inputs):return {'finite':False}
    mass=number(mass_word);vectors=[values[i:i+4] for i in range(0,12,4)]
    scale=max([abs(v) for v in values]+[abs(mass)])
    if not scale:return {'finite':True,'zero_scale':True}
    shell=[abs(v[0]**2-sum(x*x for x in v[1:])-m*m)/scale**2 for v,m in zip(vectors,(Q(0),Q(0),mass))]
    conservation=max(abs(vectors[0][c]+vectors[1][c]-vectors[2][c]) for c in range(4))/scale
    denominator=sum(abs(v) for v in inputs)
    close=sum(abs(a-b) for a,b in zip(values,inputs))/denominator if denominator else Q(0)
    return {'finite':True,'zero_scale':False,'shell':[str(v) for v in shell],
        'conservation':str(conservation),'relative_change':str(close),'positive_energies':all(v[0]>0 for v in vectors)}

def compare(left,right,leftdiag,rightdiag,pins):
    require(left['mass_word']==right['mass_word'] and left['initial_ieee']==right['initial_ieee'],'Model mass/default IEEE differs')
    require(left['mass_word']==pins['model_initialization']['expected_mp_MZ_word']
        and number(left['mass_word'])>0,'Standalone initialized Z mass differs from the pinned amplitude model')
    require(leftdiag['outside']==rightdiag['outside'],'Initialization diagnostics differ')
    changes=[];results=[]
    for a,b,ad,bd in zip(left['rows'],right['rows'],leftdiag['rows'],rightdiag['rows'],strict=True):
        keys=('id','tag','precision','refused','path_expected_from_source','physical_projection_required','legacy_identity_required','input')
        require({k:a[k] for k in keys}=={k:b[k] for k in keys},'Fixture identity differs')
        require(a['ieee_before']==b['ieee_before'] and a['ieee_after']==b['ieee_after'],'Observed IEEE differs')
        require(ad==bd,'Repair diagnostics/safeguard path differs')
        delta=[i for i,(x,y) in enumerate(zip(a['output'],b['output'])) if x!=y]
        if delta:changes.append({'id':a['id'],'precision':a['precision'],'components':delta,'original':a['output'],'candidate':b['output']})
        if a['legacy_identity_required']:require(not delta,'Refused/safeguard fixture changed legacy output words')
        if a['path_expected_from_source']=='caller_sanity_refusal':
            require(a['output']==a['input'] and b['output']==b['input'],'Public rejection did not retain input words')
        ar=residual(a,left['mass_word']);br=residual(b,right['mass_word'])
        if a['physical_projection_required']:
            limit=Q(pins['physical_DP_residual_limit'] if a['precision']==1 else pins['physical_QP_residual_limit'])
            for r in (ar,br):
                require(r['finite'] and not r['zero_scale'] and r['positive_energies'],'Eligible repair is nonphysical')
                require(max(map(Q,r['shell']))<=limit and Q(r['conservation'])<=limit,'Eligible physical residual fails')
                require(Q(r['relative_change'])<=Q(pins['close_limit']),'Eligible close safeguard fails')
        results.append({'id':a['id'],'precision':a['precision'],'path_expected_from_source':a['path_expected_from_source'],
            'original_residual':ar,'candidate_residual':br})
    return {'passed':True,'cases':len(left['rows'])//2,'DP_and_QP_calls':len(left['rows'])*2,
        'word_differences':changes,'residuals':results,'observed_IEEE_equal':True,
        'limitations':['Observed IEEE is a raw state comparison, not trap freedom or proof no flags were raised internally.',
            'The measured model declares massless incoming legs; massive-vector refusal is not a massive-model qualification.',
            'No independent amplitude finite oracle or performance result is established by this standalone repair check.']}
