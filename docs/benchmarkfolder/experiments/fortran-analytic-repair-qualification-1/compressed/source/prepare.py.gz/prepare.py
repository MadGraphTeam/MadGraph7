"""Materialize fixed text inputs/recipes only. No compiler or scientific call."""
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import struct

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROFILE=ROOT/'.tirust-build/fortran-host-repair-profile-proposal-1'
AXIAL=ROOT/'.tirust-build/fortran-orig-axial-proposal-2'
PLAIN=ROOT/'.tirust-build/fortran-tirust-interface-o3-work-2/build/n1/original/SubProcesses/P0_uux_z'
FLAGS=['-w','-fPIC','-ffixed-line-length-132']

def require(value,message):
    if not value:raise ValueError(message)
def identity(path):
    raw=Path(path).read_bytes();return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def read(path):return json.loads(Path(path).read_bytes())
def encode(value,precision):
    """Round a rational to finite normal IEEE, ties even; fixtures are normal."""
    width,bias=(64,1023) if precision==53 else (128,16383)
    value=Q(value);sign=int(value<0);value=abs(value)
    if not value:return sign<<(width-1)
    e=value.numerator.bit_length()-value.denominator.bit_length()
    if value<Q(2)**e:e-=1
    scaled=value/Q(2)**(e-precision+1);q,r=divmod(scaled.numerator,scaled.denominator)
    if 2*r>scaled.denominator or (2*r==scaled.denominator and q%2):q+=1
    if q==(1<<precision):q>>=1;e+=1
    require(0<e+bias<(1<<(width-precision))-1,'Fixture outside finite normals')
    return (sign<<(width-1))|((e+bias)<<(precision-1))|(q-(1<<(precision-1)))

def corpus(points):
    lines=Path(points).read_text().splitlines();require(int(lines[0])==100 and len(lines)==301,'Wrong saved point layout')
    values=[[Q.from_float(float(v)) for v in row.split()] for row in lines[1:]]
    saved=[values[i:i+3] for i in range(0,300,3)];cases=[]
    def add(tag,p,refused=False,path=None):
        path=path or ('local_guard_predicate_refusal' if refused else 'eligible_physical')
        physical=path=='eligible_physical'
        cases.append({'id':len(cases)+1,'tag':tag,'refused':refused,'path_expected_from_source':path,
            'physical_projection_required':physical,'legacy_identity_required':not physical,'vectors':p})
    for i,p in enumerate(saved,1):add('SAVED_'+str(i).zfill(3),p)
    for i in (0,1):add('BEAM_SWAP_'+str(i+1),[saved[i][1],saved[i][0],saved[i][2]])
    for i in (0,1):
        for rotation in (1,2):
            rotated=[]
            for e,x,y,z in saved[i]:
                rotated.append([e,z,-x,-y] if rotation==1 else [e,-z,y,x])
            add('ROTATED_'+str(i+1)+'_'+str(rotation),rotated,True)
    p=saved[1]
    add('TRANSVERSE_BOOST',[[Q(5,4)*e+Q(3,4)*x,Q(3,4)*e+Q(5,4)*x,y,z] for e,x,y,z in p],True)
    for factor in (Q(8),Q(1,8)):
        a=p[0][0]*factor;b=p[1][0]/factor
        add('HIGH_BOOST_'+('PLUS' if factor>1 else 'MINUS'),[[a,Q(0),Q(0),a],[b,Q(0),Q(0),-b],[a+b,Q(0),Q(0),a-b]])
    p=[row.copy() for row in saved[1]];p[0][0]+=Q(1,1<<100);add('QP_LAST_BITS',p)
    p=[row.copy() for row in saved[1]];p[0][0]*=1+Q(1,1<<30);add('OFFSHELL_AXIAL_WITHIN_CALLER_TOLERANCE',p)
    p=[row.copy() for row in saved[0]];p[2][1]+=Q(1,1<<30);add('TRANSVERSE_RESIDUAL',p,True)
    p=[row.copy() for row in saved[0]];p[0][0]*=2;add('DECLARED_MASSLESS_OFFSHELL_INPUT',p,True,'caller_sanity_refusal')
    p=[row.copy() for row in saved[0]];p[0][0]=-p[0][0];add('NEGATIVE_ENERGY',p,True,'caller_sanity_refusal')
    p=[row.copy() for row in saved[0]];p[2][3]=2*p[2][0];add('SPACELIKE_FINAL',p,True,'caller_sanity_refusal')
    add('ZERO_POINT',[[Q(0)]*4 for _ in range(3)],True,'caller_sanity_refusal')
    bad=[(0x7ff0000000000000,0x7fff<<112),(0xfff0000000000000,(0x7fff<<112)|(1<<127)),
         (0x7ff8000000000001,(0x7fff<<112)|(1<<111)|1),
         (0x7ff0000000000001,(0x7fff<<112)|1),
         (0xfff0000000000001,(0x7fff<<112)|(1<<127)|1)]
    for slot,(leg,component) in enumerate(((0,0),(1,0),(0,3),(1,3)),1):
        for kind,words in enumerate(bad,1):
            p=[row.copy() for row in saved[1]];p[leg][component]={'raw_words':list(words)}
            add('NONFINITE_INCOMING_'+str(slot)+'_'+str(kind),p,True)
    rows=[str(len(cases))];metadata=[]
    for case in cases:
        rows.append(case['tag']+' '+str(int(case['legacy_identity_required'])));words=[]
        for vector in case['vectors']:
            for value in vector:
                d,q=value['raw_words'] if isinstance(value,dict) else (encode(value,53),encode(value,113))
                rows.append(f'{d:016X} {q:032X}');words.append([f'{d:016X}',f'{q:032X}'])
        metadata.append({k:case[k] for k in ('id','tag','refused','path_expected_from_source',
            'physical_projection_required','legacy_identity_required')}|{'words':words})
    return '\n'.join(rows)+'\n',{'schema':'analytic-orig-repair-corpus-v1','cases':metadata,
        'saved_points':100,'scope':'Raw binary64/binary128 fixture words; no compiled repair evaluated',
        'massive_fixture_scope':'Off-shell incoming vectors against the measured massless model; no massive incoming model.'}

def derive():
    pin=read(PROFILE/'input-pins.json');compiler=pin['compiler_flags']['scopes']['process']['recipes']['improve_ps.f']['compiler'][0]['path']
    donor=Path(pin['output']);model=donor/'Source/MODEL';card=donor/'Cards/param_card.dat';mass_tokens=[];block=None
    for line in card.read_text().splitlines():
        fields=line.split('#',1)[0].split()
        if not fields:continue
        if fields[0].lower()=='block':block=fields[1].lower()
        elif fields[0].lower()=='decay':block=None
        elif block=='mass' and fields[0]=='23':mass_tokens.append(fields[1])
    require(len(mass_tokens)==1,'Unique physical Z mass required')
    token=mass_tokens[0];mass_dp=float(token.replace('D','E').replace('d','e'))
    mass=Q.from_float(mass_dp);require(mass>0,'Positive initialized model Z mass required')
    # The pinned model deliberately reads MP_LHA_GET_REAL through a REAL*8
    # buffer. Preserve that existing model precision rather than assuming a
    # direct binary128 decimal parse.
    real_source=(model/'lha_read.f').read_text()
    mp_getter=real_source.split('subroutine MP_LHA_get_real_silent(',1)[1].split('end',1)[0]
    require('real*8 buff' in mp_getter and 'read(value(i),*) buff' in mp_getter and 'var=buff' in mp_getter,'Pinned MP parameter read policy changed')
    require("call LHA_loadcard(param_name,npara,param,value)" in (model/'rw_para.f').read_text()
        and "include 'param_read.inc'" in (model/'rw_para.f').read_text(),'SETPARA chain changed')
    require('CALL MP_LHA_GET_REAL(NPARA,PARAM,VALUE,\'mdl_MZ\',MP__MDL_MZ' in (model/'param_read.inc').read_text(),'Model MP Z-mass assignment changed')
    require('mass 23 mdl_MZ' in (donor/'Cards/ident_card.dat').read_text(),'Mass23 identifier changed')
    for source in (PLAIN/'check_sa.f',HERE/'repair_driver.f90'):
        require("call setpara('param_card.dat')" in source.read_text().lower(),'Standalone/amplitude model initialization differs')
    require(identity(AXIAL/'candidate-improve_ps.f')['sha256']=='84e8caf51078c3fb5817582e94e9a6a62f1ad22fc4bf7909f5034fce23dbc31c','Candidate changed')
    require(identity(PLAIN/'check_sa.f')['sha256']=='ed0a5ffffde6c1098799a52d09b0622cbfbb4954d5048551d2457c7f85df39bb','Shared plain driver changed')
    require(identity(PLAIN/'check_sa.o')['sha256']=='c9644a5625793349d136f1eb66d387b670552f37e107efb47ddf6af9ba48c7f9','Shared plain driver object changed')
    command_root=ROOT/'.tirust-build/fortran-host-repair-profile-execution-1/build/baseline/commands'
    compile_command=read(command_root/'01-compile-improve_ps.f.command.json')['argv']
    link_command=read(command_root/'link.command.json')['argv']
    require(link_command.count('repair_profile.o')==1,'Closed diagnostic link layout changed')
    link_command=[x for x in link_command if x!='repair_profile.o']
    source_paths=[PROFILE/name for name in ('controller.py','source-index.json','input-pins.json','toolchain-pins.json','tool_environment.py','predecessor.json')]
    source_paths += [AXIAL/name for name in ('prepare.py','original-improve_ps.f','candidate-improve_ps.f','analytic-axial.patch','pure-results.json')]
    source_paths += [PLAIN/'check_sa.f',PLAIN/'check_sa.o',command_root/'01-compile-improve_ps.f.command.json',command_root/'link.command.json',
        ROOT/'.tirust-build/fortran-tirust-interface-o3-execution-2/build/result.json',
        ROOT/'.tirust-build/fortran-tirust-interface-o3-execution-2/build/terminal.json',
        ROOT/'.tirust-build/fortran-tirust-interface-o3-proposal-2/analysis.py',
        ROOT/'.tirust-build/qp-mass-false-integrand-qualification-proposal-1/collector.py',
        ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/ownership.py',
        ROOT/'.tirust-build/fortran-orig-axial-source-independent-review-2/receipt.json',
        ROOT/'.tirust-build/fortran-orig-axial-qualification-proposal-1/source-index.json',
        ROOT/'.tirust-build/fortran-orig-axial-qualification-source-independent-review-1/receipt.json',
        card,donor/'Cards/ident_card.dat',model/'rw_para.f',model/'param_read.inc',model/'lha_read.f',
        ROOT/'docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py']
    inputs={'schema':'analytic-orig-qualification-inputs-v1','profile_parent':str(PROFILE),'donor':pin['output'],
        'source2':str(AXIAL),'plain_driver_source':str(PLAIN/'check_sa.f'),'plain_driver_object':str(PLAIN/'check_sa.o'),
        'points':pin['points'],'compiler':compiler,'flags':FLAGS,
        'source_history':{'source1_seal':'f41765c3546a3e73561966e9c0dd46e1236edf29178cfb680d2d32c5eb8d361b',
            'source1_native_stages_executed':False,'source2_delta':'ZERO_POINT caller sanity refusal plus explicit initialized positive model mass binding'},
        'model_initialization':{'setpara_argument':'param_card.dat','physical_card':str(card),'mass23_card_token':token,
            'parameter_read_policy':'Pinned MP_LHA_GET_REAL reads REAL*8 buff then assigns REAL*16 var',
            'expected_mp_MZ_word':f'{encode(mass,113):032X}','expected_dp_MZ_word':f'{encode(mass,53):016X}'},
        'compile_repair':compile_command,'link_amplitude':link_command,
        'old_link_output':str(ROOT/'.tirust-build/fortran-host-repair-profile-work-1/build/baseline'),
        'external_files':{str(p):identity(p) for p in source_paths},
        'analysis':str(ROOT/'.tirust-build/fortran-tirust-interface-o3-proposal-2/analysis.py'),
        'collector':str(ROOT/'.tirust-build/qp-mass-false-integrand-qualification-proposal-1/collector.py'),
        'ownership':str(ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/ownership.py'),
        'cleanup':str(ROOT/'docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'),
        'physical_DP_residual_limit':'1e-12','physical_QP_residual_limit':'1e-25',
        'close_limit':'1e-2','cycles':7,'traversals_per_batch':128}
    raw,fixtures=corpus(pin['points'])
    fixed=[];continued=False
    for line in (HERE/'repair_driver.f90').read_text().splitlines():
        text=line.rstrip();more=text.endswith('&')
        if more:text=text[:-1].rstrip()
        fixed.append(('     &' if continued else '      ')+text.lstrip());continued=more
    require(not continued and all(len(line)<=132 for line in fixed),'Fixed driver conversion exceeds original line policy')
    return {'input-pins.json':json.dumps(inputs,indent=2,sort_keys=True)+'\n','repair-corpus.dat':raw,
        'repair-corpus.json':json.dumps(fixtures,indent=2,sort_keys=True)+'\n','repair_driver.f':'\n'.join(fixed)+'\n'}

def verify():
    for name,text in derive().items():require((HERE/name).read_text()==text,'Prepared text changed: '+name)
    return {'prepared_files':4,'native_calls':0}

if __name__=='__main__':
    for name,text in derive().items():
        with (HERE/name).open('x') as stream:stream.write(text)
    print(json.dumps(verify(),sort_keys=True))
