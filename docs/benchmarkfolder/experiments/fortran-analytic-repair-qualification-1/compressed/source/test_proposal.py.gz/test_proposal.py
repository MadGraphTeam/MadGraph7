"""Pure source/fixture/parser/ownership tests. No external program is invoked."""
import copy
from fractions import Fraction as Q
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
prep=load('axial_test_preparation',HERE/'prepare.py')
a=load('axial_test_analysis',HERE/'analyze.py')
c=load('axial_test_controller',HERE/'controller.py')

def sample():
    p=[[Q(1),Q(0),Q(0),Q(1)],[Q(1),Q(0),Q(0),Q(-1)],[Q(2),Q(0),Q(0),Q(0)]]
    words=[[f'{prep.encode(v,53):016X}',f'{prep.encode(v,113):032X}'] for row in p for v in row]
    return {'cases':[{'id':1,'tag':'ELIGIBLE','refused':False,'words':words,'path_expected_from_source':'eligible_physical',
                         'physical_projection_required':True,'legacy_identity_required':False},
                     {'id':2,'tag':'REFUSED','refused':True,'words':words,'path_expected_from_source':'local_guard_refusal',
                         'physical_projection_required':False,'legacy_identity_required':True}]}

def raw(corpus):
    rows=['META AXIAL_REPAIR_UNIT_V1 '+str(len(corpus['cases'])),'MASS_Z '+f'{prep.encode(Q(2),113):032X}',
          'ENV INITIAL 0 0 '+' '.join(['0']*11)];stdout=[]
    for case in corpus['cases']:
        for precision in (1,2):
            key=f'{case["id"]} {precision}'
            rows.append('CASE '+key+' '+str(int(case['legacy_identity_required']))+' '+case['tag'])
            stdout.append('CASE_BEGIN '+key+' '+case['tag'])
            for label in ('IN','OUT'):
                if label=='OUT':
                    rows.extend(['ENV BEFORE '+key+' '+' '.join(['0']*11),'ENV AFTER '+key+' '+' '.join(['0']*11)])
                for i,pair in enumerate(case['words']):rows.append(f'{label} {key} {1+i//4} {i%4} '+pair[precision-1])
            rows.append('ENDCASE '+key);stdout.append('CASE_END '+key)
    rows.append('END '+str(len(corpus['cases'])))
    return '\n'.join(rows)+'\n','\n'.join(stdout)+'\n'

def comparison_pins():
    pins=prep.read(HERE/'input-pins.json')
    pins['model_initialization']['expected_mp_MZ_word']=f'{prep.encode(Q(2),113):032X}'
    return pins

class PureTests(unittest.TestCase):
    def test_prepared_derivation(self):self.assertEqual(prep.verify()['prepared_files'],4)
    def test_fixtures(self):
        cases=json.loads((HERE/'repair-corpus.json').read_text())['cases']
        self.assertEqual(len(cases),136);self.assertEqual(sum(x['tag'].startswith('NONFINITE_') for x in cases),20)
        self.assertEqual(sum(x['tag'].startswith('SAVED_') for x in cases),100)
        self.assertTrue(all(x['refused'] for x in cases if x['tag'].startswith(('NONFINITE_','ROTATED_','TRANSVERSE_'))))
        self.assertEqual(sum(x['refused'] for x in cases),30)
        zero=next(x for x in cases if x['tag']=='ZERO_POINT');self.assertTrue(zero['refused']);self.assertTrue(zero['legacy_identity_required'])
        small=next(x for x in cases if x['tag']=='OFFSHELL_AXIAL_WITHIN_CALLER_TOLERANCE')
        self.assertTrue(small['physical_projection_required']);self.assertFalse(small['legacy_identity_required'])
    def test_saved_words(self):
        points=Path(prep.read(HERE/'input-pins.json')['points']).read_text().splitlines()[1:]
        cases=prep.read(HERE/'repair-corpus.json')['cases'][:100]
        expected=[struct.pack('>d',float(v)).hex().upper() for line in points for v in line.split()]
        self.assertEqual([p[0] for case in cases for p in case['words']],expected)
    def test_offshell_source_classification_margin(self):
        cases={case['tag']:case for case in prep.read(HERE/'repair-corpus.json')['cases']}
        for tag,rejected in (('DECLARED_MASSLESS_OFFSHELL_INPUT',True),('OFFSHELL_AXIAL_WITHIN_CALLER_TOLERANCE',False)):
            words=cases[tag]['words'];energy=a.number(words[0][1]);pz=a.number(words[3][1])
            ratio_squared=abs(energy**2-pz**2)/(abs(energy)+abs(pz))**2
            self.assertEqual(ratio_squared>Q(1,10000),rejected)
        self.assertEqual(cases['ZERO_POINT']['path_expected_from_source'],'caller_sanity_refusal')
    def test_positive_model_zero_reference_caller_rejection(self):
        pins=prep.read(HERE/'input-pins.json');mass=a.number(pins['model_initialization']['expected_mp_MZ_word'])
        self.assertGreater(mass,0)
        # Exact numerator of the caller's final-Z on-shell test is MZ>0,
        # denominator is zero. Under the pinned default nonhalting GNU IEEE
        # policy this is positive infinity, whose ordered .GT..01 is true.
        self.assertGreater(mass**2,0);reference=Q(0);self.assertEqual(reference,0)
        self.assertGreater(float('inf'),1e-2)
        corpus=sample();case=corpus['cases'][1];case.update(tag='ZERO_POINT',path_expected_from_source='caller_sanity_refusal')
        case['words']=[['0000000000000000','00000000000000000000000000000000'] for _ in range(12)]
        text,stdout=raw(corpus);left=a.journal(text,corpus);diag=a.diagnostics(stdout,corpus)
        self.assertTrue(a.compare(left,left,diag,diag,comparison_pins())['passed'])
        changed=copy.deepcopy(left);changed['rows'][2]['output'][0]='3FF0000000000000'
        with self.assertRaisesRegex(ValueError,'Public rejection'):a.compare(changed,changed,diag,diag,comparison_pins())
    def test_exact_pinned_model_initialization(self):
        pins=prep.read(HERE/'input-pins.json');model=pins['model_initialization']
        expected=Q.from_float(float(model['mass23_card_token']))
        self.assertEqual(a.number(model['expected_mp_MZ_word']),expected)
        self.assertNotEqual(expected,Q(model['mass23_card_token']))
        corpus=sample();text,stdout=raw(corpus);left=a.journal(text,corpus);diag=a.diagnostics(stdout,corpus)
        with self.assertRaisesRegex(ValueError,'initialized Z mass'):a.compare(left,left,diag,diag,pins)
    def test_ieee_integer_transport(self):
        for value in (Q(0),Q(1),Q(-1),Q(1,3),Q(2)**100,Q(2)**-100):
            d=prep.encode(value,53);q=prep.encode(value,113)
            self.assertEqual(a.number(f'{d:016X}'),Q.from_float(float(value)))
            self.assertLessEqual(abs(a.number(f'{q:032X}')-value),abs(value)*Q(2)**-112)
        for word in ('7FF0000000000000','FFF0000000000001','7FFF0000000000000000000000000000','FFFF8000000000000000000000000001'):
            self.assertIsNone(a.number(word))
    def test_journal_positive(self):
        corpus=sample();text,stdout=raw(corpus);parsed=a.journal(text,corpus);diag=a.diagnostics(stdout,corpus)
        result=a.compare(parsed,parsed,diag,diag,comparison_pins())
        self.assertTrue(result['passed']);self.assertEqual(result['DP_and_QP_calls'],8)
    def test_journal_strict(self):
        corpus=sample();text,_=raw(corpus)
        for bad in (text+'EXTRA\n',text.replace('IN 1 1 1 0','IN 1 1 2 0',1),text.replace('META AXIAL_REPAIR_UNIT_V1 2','META AXIAL_REPAIR_UNIT_V1 3',1)):
            with self.assertRaises(ValueError):a.journal(bad,corpus)
    def test_input_word_join(self):
        corpus=sample();text,_=raw(corpus)
        with self.assertRaises(ValueError):a.journal(text.replace('IN 1 1 1 0 3FF0000000000000','IN 1 1 1 0 4000000000000000',1),corpus)
    def test_finite_rounding_difference_diagnostic(self):
        corpus=sample();text,stdout=raw(corpus);left=a.journal(text,corpus);right=copy.deepcopy(left);diag=a.diagnostics(stdout,corpus)
        right['rows'][1]['output'][1]='80000000000000000000000000000000'
        self.assertEqual(len(a.compare(left,right,diag,diag,comparison_pins())['word_differences']),1)
    def test_refused_word_change_rejected(self):
        corpus=sample();text,stdout=raw(corpus);left=a.journal(text,corpus);right=copy.deepcopy(left);diag=a.diagnostics(stdout,corpus)
        right['rows'][2]['output'][1]='8000000000000000'
        with self.assertRaisesRegex(ValueError,'Refused'):a.compare(left,right,diag,diag,comparison_pins())
    def test_residual_and_ieee_rejected(self):
        corpus=sample();text,stdout=raw(corpus);left=a.journal(text,corpus);diag=a.diagnostics(stdout,corpus)
        for field,value in (('output','4000000000000000'),('ieee_after',1)):
            right=copy.deepcopy(left)
            if field=='output':right['rows'][0][field][0]=value
            else:right['rows'][0][field][1]=value
            with self.assertRaises(ValueError):a.compare(left,right,diag,diag,comparison_pins())
    def test_diagnostic_framing(self):
        corpus=sample();_,stdout=raw(corpus)
        with self.assertRaises(ValueError):a.diagnostics(stdout.replace('CASE_END 1 1','CASE_END 9 1'),corpus)
    def test_source_scope(self):
        driver=(HERE/'repair_driver.f90').read_text().lower();controller=(HERE/'controller.py').read_text()
        self.assertNotIn('ieee_set_',driver);self.assertNotIn('sloopmatrix',driver)
        self.assertIn("fcntl.LOCK_EX|fcntl.LOCK_NB",controller)
        self.assertLess(controller.index('env=b.environment() # Reconstruct'),controller.index('deadline.handoff=True'))
        self.assertNotIn('DPTEST',controller);self.assertNotIn('DPRUN',controller)
        self.assertEqual(c.CAPS,{'build':600.,'repair':300.,'amplitude':300.,'timing':300.})
    def test_plain_driver_and_source_flags(self):
        pin=prep.read(HERE/'input-pins.json');source=Path(pin['plain_driver_source']).read_text()
        self.assertIn("'EXACT'",source);self.assertIn("'TIMED'",source)
        self.assertNotIn('HOST_REPAIR',source);self.assertNotIn('DP_PROFILE',source)
        self.assertEqual(pin['flags'],['-w','-fPIC','-ffixed-line-length-132'])
        self.assertNotIn('repair_profile.o',pin['link_amplitude'])
    def test_own_accuracy_drift_is_diagnostic(self):
        m=c.analysis();zero='0000000000000000';one='3FF0000000000000'
        rows=[{'point':p,'order':o,'status':219,'words':[one]*4+[zero]} for p in range(1,101) for o in (0,1)]
        changed=copy.deepcopy(rows);changed[0]['words'][-1]=one
        result=m.compare_own(rows,changed);self.assertTrue(result['passed']);self.assertTrue(result['accuracy_drift'])
        changed[0]['words'][0]=zero;self.assertFalse(m.compare_own(rows,changed)['passed'])
    def test_owned_constructor_failure_cleanup(self):
        events=[];record={'pid':123,'process_group':123,'session':123};process=types.SimpleNamespace(pid=123)
        class Deadline:
            def __init__(self,cap):self.end=999.;self.handoff=False;self.deferred=False
            def __enter__(self):return self
            def __exit__(self,*args):pass
        class Requests:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def check(self):pass
        def fail_owned(p):events.append('owned');raise RuntimeError('constructor failed')
        def raw_cleanup(p,r,cleanup,end):
            self.assertIs(p,process);self.assertIs(r,record);self.assertEqual(end,999.);events.append('cleanup')
            return {'failure_only':True,'uncertainty_blocks_later_stages':True}
        cleanup=types.SimpleNamespace(SignalRequests=Requests,identity=lambda pid:record,OwnedChild=fail_owned)
        own=types.SimpleNamespace(StageDeadline=Deadline,raw_cleanup=raw_cleanup)
        b=types.SimpleNamespace(tool=lambda name:name,environment=lambda:events.append('environment') or {})
        real_load=c.load
        def modules(name,path):return cleanup if name=='_axial_cleanup' else own if name=='_axial_ownership' else real_load(name,path)
        with tempfile.TemporaryDirectory(dir='/tmp') as temp,patch.object(c,'REPORT',Path(temp)),patch.object(c,'base',lambda:b),patch.object(c,'load',modules),patch.object(c,'preflight',lambda:None),patch.object(c,'verified_build',lambda:None),patch.object(c,'verify_source',lambda:None),patch.object(c,'protected',lambda:None),patch.object(c.subprocess,'Popen',lambda *args,**kwargs:process):
            with self.assertRaisesRegex(RuntimeError,'constructor failed'):c.stage('repair')
            terminal=json.loads((Path(temp)/'repair/terminal.json').read_text())
            self.assertEqual(terminal['status'],'failed');self.assertTrue(terminal['cleanup']['uncertainty_blocks_later_stages'])
        self.assertEqual(events,['environment','owned','cleanup'])
    def test_raw_mismatched_identity_no_signal(self):
        own=load('axial_ownership_test',prep.read(HERE/'input-pins.json')['ownership'])
        process=types.SimpleNamespace(pid=123,poll=lambda:None)
        cleanup=types.SimpleNamespace(matches=lambda record:False)
        with patch.object(own.os,'killpg',side_effect=AssertionError('must not signal')):
            with self.assertRaisesRegex(ValueError,'identity'):own.raw_cleanup(process,{'pid':123,'process_group':123,'session':123},cleanup,999.)
    def test_deadline_handoff_absolute_end(self):
        own=load('axial_deadline_test',prep.read(HERE/'input-pins.json')['ownership']);events=[]
        deadline=own.StageDeadline(300.);deadline.end=400.;deadline.handoff=True;deadline.deferred=False
        with patch.object(own.time,'monotonic',lambda:350.),patch.object(own.signal,'setitimer',lambda *args:events.append(args)):
            deadline.expired(None,None)
        self.assertTrue(deadline.deferred);self.assertEqual(events[0][1],50.)
        with patch.object(own.time,'monotonic',lambda:400.):
            with self.assertRaises(TimeoutError):deadline.expired(None,None)

if __name__=='__main__':unittest.main()
