This qualification successor retains f417 source1 unexecuted and corrects only
its ZERO_POINT caller classification plus the explicit positive initialized
model-mass pin/test. The new work/report destinations end in2. The standalone
driver, scientific candidate, other object bindings/flags/actions are unchanged.

The unapplied scientific candidate remains source2 `84e8caf5...`, already
source/math reviewed at receipt `48484632...`; this proposal changes no
scientific source. It prepares only two isolated same-flag links whose sole
scientific-object difference is the original/candidate `improve_ps.o`.

The closed repair-profile scaffold is reused for frozen donor inputs, compiler
environment, actual LOAD/provider checks, object inventory and worker APIs.
Its instrumented driver/module, stage dispatcher and timer commands are not
used. Its unsafe older handoff clock is replaced by the already qualified
absolute-end ownership helper `51ca38f0...`; environment reconstruction and
all real-stage preflight/predecessor verification precede process handoff
inside the all-in stage clock. Raw identity is retained before OwnedChild.

The common plain driver is the old study's closed original-control object
`c9644a56...`, identical in both arms and without O3 flags or hooks. The new
standalone main reads fixed raw words and calls only the public DP/QP repair
entries. It observes default IEEE state without setters. It is linked to the
same original object/provider closure, so no separate guessed model-library
closure or extra numerical compile is needed.

Fixture classes distinguish local guard refusal from caller sanity refusal.
An off-shell axial vector within tolerance is eligible. The invalid all-zero
input is rejected by the caller before ORIG because initialized MZ>0 makes
its final-Z on-shell ratio positive infinity. It must return input words.
The26 local-predicate refusals cannot enter the analytic branch if reached;
nonfinite rows can instead be refused earlier by a caller predicate.
The measured model always declares incoming masses0; no massive-model or
broader Standard Model qualification is asserted. All native stages remain
dormant until separately reviewed/admitted by root.

SETPARA is identical in the two mains. The pinned rw_para/param_read/identifier
chain initializes MP__MDL_MZ through the existing REAL*8 buffer in
MP_LHA_GET_REAL; the positive expected binary128 lifted word is checked
against the standalone journal. A focused pure test covers MZ>0/reference0
and proves that equal-but-mutated original/candidate rejection outputs still
fail the mandatory output==input gate.
