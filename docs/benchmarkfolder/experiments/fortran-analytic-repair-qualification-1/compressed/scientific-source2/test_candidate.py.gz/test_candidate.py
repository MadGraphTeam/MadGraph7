"""Pure rational identities/guard corpus; no compiled repair is evaluated."""
from fractions import Fraction as Q
from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('analytic_axial_preparation', HERE / 'prepare.py')
prep = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prep)
SIGN = 1 << 127
MAG = SIGN - 1
EXP = ((1 << 15) - 1) << 112


def word_zero(bits):
    return bits & MAG == 0


def word_finite(bits):
    return bits & EXP != EXP


def word_positive(bits):
    return word_finite(bits) and not bits & SIGN and not word_zero(bits)


def guarded(total, masses=(Q(0), Q(0)), transverse=(Q(0),) * 4,
            preceding_checks=True):
    """Exact-real model of the new guard after the unchanged earlier checks.

    Nonfinite encodings are covered separately by the integer-word tests. This
    is not a binary128 evaluator or a prediction of the final-leg square root.
    """
    if not preceding_checks or any(masses) or any(transverse):
        return False
    e, x, y, z = total
    if x or y:
        return False
    discr = abs(-e * e + x * x + y * y + z * z)
    if discr <= 0 or e <= abs(z):
        return False
    if e + z <= 0:
        return False
    return e - z > 0


def expanded(total, e1, z1, e2, z2):
    """Literal exact-rational evaluation of the four existing shift formulas."""
    e, x, y, z = total
    d = abs(-e ** 2 + x ** 2 + y ** 2 + z ** 2)
    de = 2 * (e - z) * (e + z)
    dz = 2 * (e ** 2 - z ** 2)
    se1 = (e * (-2 * e1 * e + e ** 2 + x ** 2 + y ** 2)
           + (2 * e1 - e) * z ** 2 + z * d) / de
    se2 = -(e * (2 * e2 * e - e ** 2 + x ** 2 + y ** 2)
            + (-2 * e2 + e) * z ** 2 + z * d) / de
    sz1 = (-2 * z1 * (e ** 2 - z ** 2)
           + z * (e ** 2 + x ** 2 + y ** 2 - z ** 2) + e * d) / dz
    sz2 = -(2 * z2 * (e ** 2 - z ** 2)
            + z * (-e ** 2 + x ** 2 + y ** 2 + z ** 2) + e * d) / dz
    return e1 + se1, z1 + sz1, e2 + se2, z2 + sz2


def analytic(total):
    e, _, _, z = total
    plus, minus = (e + z) / 2, (e - z) / 2
    return plus, plus, minus, -minus


def points():
    raw = prep.POINTS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != prep.POINTS_SHA:
        raise ValueError('Saved input changed')
    rows = raw.decode().splitlines()
    count = int(rows[0])
    if count != 100 or len(rows) != 1 + 3 * count:
        raise ValueError('Unexpected saved point layout')
    # Parse the saved DP words first; all subsequent algebra uses integers.
    data = [[Q.from_float(float(x)) for x in row.split()] for row in rows[1:]]
    return [data[i:i + 3] for i in range(0, len(data), 3)]


def integer_word(value):
    """Exact binary128 fixture encoder for small signed integers."""
    sign = SIGN if value < 0 else 0
    value = abs(value)
    if value == 0:
        return sign
    exponent = value.bit_length() - 1
    return sign | ((16383 + exponent) << 112) | ((value - (1 << exponent)) << (112 - exponent))


def finite_fraction(bits):
    if not word_finite(bits):
        raise ValueError('Nonfinite word must be refused before exact arithmetic')
    exponent = (bits >> 112) & ((1 << 15) - 1)
    mantissa = bits & ((1 << 112) - 1)
    significand = mantissa if exponent == 0 else (1 << 112) | mantissa
    power = (1 if exponent == 0 else exponent) - 16383 - 112
    return (-1 if bits & SIGN else 1) * Q(significand) * Q(2) ** power


def guarded_word_path(incoming, trace):
    """Whole new guard path, with finite total/discriminant fixture words.

    Incoming order exactly follows Fortran slots4:7: E1,E2,pz1,pz2. No
    floating-point operation or decoded arithmetic is reached on their poison.
    This models control flow; it is not a compiled binary128 repair evaluator.
    """
    zero = [0] * 8
    totals = [integer_word(10), integer_word(2), integer_word(96)]
    trace.append('zero-geometry')
    if not all(word_zero(w) for w in zero):
        return False
    trace.append('finite-inputs')
    if not all(word_finite(w) for w in totals + list(incoming)):
        return False
    trace.append('physical-branch')
    e, z, discr = map(finite_fraction, totals)
    if discr <= 0 or e <= abs(z):
        return False
    trace.append('analytic-sums')
    ep, em = e + z, e - z
    if ep <= 0:
        return False
    if em <= 0:
        return False
    trace.append('analytic-reconstruction')
    return True


class Candidate(unittest.TestCase):
    def test_exact_measured_source_and_reversible_insertions(self):
        result = prep.verify()
        self.assertTrue(result['original_bytes_reconstructed'])
        self.assertEqual(result['native_executions'], 0)

    def test_all100_saved_points_exact_rational_identity_and_geometry(self):
        for index, (p1, p2, final) in enumerate(points()):
            with self.subTest(point=index):
                self.assertTrue(guarded(final, transverse=(p1[1], p1[2], p2[1], p2[2])))
                positive, negative = (p1, p2) if p1[3] > 0 else (p2, p1)
                self.assertEqual(expanded(final, positive[0], positive[3], negative[0], negative[3]),
                                 analytic(final))
                plus, zp, minus, zm = analytic(final)
                self.assertEqual(plus + minus, final[0])
                self.assertEqual(zp + zm, final[3])
                self.assertEqual(plus ** 2 - zp ** 2, 0)
                self.assertEqual(minus ** 2 - zm ** 2, 0)

    def test_boosted_rational_sweep_and_old_incoming_cancellation(self):
        for e in (Q(1), Q(31, 8), Q(2) ** 100, Q(2) ** -100):
            for ratio in (Q(0), Q(1, 2), Q(-1, 2), Q(999, 1000), Q(-999, 1000)):
                total = (e, Q(0), Q(0), e * ratio)
                self.assertTrue(guarded(total))
                for old in ((e / 2, e / 2, e / 2, -e / 2),
                            (e / 3, e / 7, e / 5, -e / 11)):
                    self.assertEqual(expanded(total, *old), analytic(total))

    def test_final_multiplicity_enters_only_through_unchanged_total(self):
        finals = ((Q(5), Q(1), Q(2), Q(1)), (Q(7), Q(-1), Q(-2), Q(2)))
        total = tuple(sum((p[k] for p in finals), Q(0)) for k in range(4))
        self.assertTrue(guarded(total))
        self.assertEqual(expanded(total, Q(6), Q(6), Q(6), Q(-6)), analytic(total))

    def test_nonzero_final_transverse_is_refused_and_really_changes_projection(self):
        total = (Q(10), Q(1, 16), Q(0), Q(2))
        self.assertFalse(guarded(total))
        self.assertNotEqual(expanded(total, Q(6), Q(6), Q(4), Q(-4)), analytic(total))

    def test_transverse_massive_rotated_and_prior_invalid_refusals(self):
        good = (Q(10), Q(0), Q(0), Q(2))
        self.assertFalse(guarded(good, masses=(Q(1), Q(0))))
        self.assertFalse(guarded(good, masses=(Q(0), Q(1))))
        for axis in range(4):
            transverse = [Q(0)] * 4
            transverse[axis] = Q(1, 1 << 100)
            self.assertFalse(guarded(good, transverse=transverse))
        self.assertFalse(guarded(good, transverse=(Q(6), Q(0), Q(-6), Q(0))))
        self.assertFalse(guarded(good, preceding_checks=False))
        for bad in ((Q(0), Q(0), Q(0), Q(0)), (Q(1), Q(0), Q(0), Q(1)),
                    (Q(1), Q(0), Q(0), Q(2)), (Q(-10), Q(0), Q(0), Q(2))):
            self.assertFalse(guarded(bad))

    def test_binary128_integer_classification_refuses_nonfinite_without_FP(self):
        one = 16383 << 112
        self.assertTrue(word_zero(0))
        self.assertTrue(word_zero(SIGN))
        self.assertTrue(word_positive(one))
        self.assertFalse(word_positive(one | SIGN))
        self.assertFalse(word_positive(0))
        for nonfinite in (EXP, EXP | SIGN, EXP | (1 << 111), EXP | 1, EXP | SIGN | 1):
            self.assertFalse(word_zero(nonfinite))
            self.assertFalse(word_finite(nonfinite))
            self.assertFalse(word_positive(nonfinite))

    def test_all_four_incoming_nonfinite_words_refused_before_analytic_math(self):
        clean = [integer_word(x) for x in (6, 4, 6, -4)]
        trace = []
        self.assertTrue(guarded_word_path(clean, trace))
        self.assertEqual(trace[-1], 'analytic-reconstruction')
        poisons = (EXP, EXP | SIGN, EXP | (1 << 111), EXP | 1, EXP | SIGN | 1)
        for slot in range(4):
            for poison in poisons:
                with self.subTest(incoming_slot=slot, word=hex(poison)):
                    values = clean.copy()
                    values[slot] = poison
                    trace = []
                    self.assertFalse(guarded_word_path(values, trace))
                    self.assertEqual(trace, ['zero-geometry', 'finite-inputs'])

    def test_actual_guard_covers_incoming_words_before_first_new_FP_comparison(self):
        self.assertIn('AXIAL_CLASS_BITS(7)', prep.DECL)
        for slot, formal in ((4, 'P(0,1)'), (5, 'P(0,2)'), (6, 'P(3,1)'), (7, 'P(3,2)')):
            statement = f'AXIAL_CLASS_BITS({slot})=TRANSFER({formal},INT(0,KIND=AXIAL_IK))'
            self.assertIn(statement, prep.GUARD)
            self.assertLess(prep.GUARD.index(statement), prep.GUARD.index('IF(ALL(IAND(AXIAL_CLASS_BITS,AXIAL_EXP_MASK)'))
        self.assertLess(prep.GUARD.index('IF(ALL(IAND(AXIAL_CLASS_BITS,AXIAL_EXP_MASK)'),
                        prep.GUARD.index('IF(DISCR.GT.ZERO)'))

    def test_fallback_diagnostics_and_PSMC_bytes_remain_exact(self):
        original = (HERE / 'original-improve_ps.f').read_bytes()
        candidate = (HERE / 'candidate-improve_ps.f').read_bytes()
        self.assertEqual(prep.reconstruct(candidate), original)
        marker = b'      SUBROUTINE ML5_0_MP_PSMC_IMPROVE_PS_POINT_PRECISION('
        self.assertEqual(candidate[candidate.index(marker):], original[original.index(marker):])
        text = candidate.decode()
        self.assertLess(text.index('GOTO 90'), text.index(' 90   CONTINUE'))
        self.assertIn(' 90   CONTINUE\n      NEWP(1,P2) = P(1,P2)', text)
        self.assertNotIn('IEEE_', prep.DECL + prep.GUARD)
        self.assertNotIn('SAVE', prep.DECL + prep.GUARD)
        self.assertNotIn('.AND.', prep.GUARD)
        self.assertLess(prep.GUARD.index('IF(PT(0).GT.ABS(PT(3)))'),
                        prep.GUARD.index('AXIAL_EP=PT(0)+PT(3)'))
        self.assertLess(prep.GUARD.index('IF(AXIAL_EP.GT.ZERO)'),
                        prep.GUARD.index('IF(AXIAL_EM.GT.ZERO)'))


def denied(*args, **kwargs):
    raise RuntimeError('Native/process/library/network/signal access forbidden in pure tests')


if __name__ == '__main__':
    with mock.patch.object(subprocess, 'Popen', denied), mock.patch.object(subprocess, 'run', denied), \
         mock.patch.object(ctypes, 'CDLL', denied), mock.patch.object(socket, 'socket', denied), \
         mock.patch.object(os, 'system', denied), mock.patch.object(os, 'killpg', denied):
        unittest.main(verbosity=2)
