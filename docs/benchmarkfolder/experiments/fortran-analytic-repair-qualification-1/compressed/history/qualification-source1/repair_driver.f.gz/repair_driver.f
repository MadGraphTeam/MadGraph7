      program axial_repair_unit
      use, intrinsic :: iso_fortran_env, only: int64,real64,real128
      use, intrinsic :: ieee_arithmetic
      use, intrinsic :: ieee_exceptions
      implicit none
      integer,parameter :: ik=selected_int_kind(33)
      include 'mp_coupl.inc'
      include 'MadLoopParams.inc'
      integer :: ncases,ic,prec,i,j,legacy_identity
      integer(int64) :: dbits
      integer(ik) :: qbits
      real(real64) :: pd(0:3,3),din(0:3,3)
      real(real128) :: pq(0:3,3),qin(0:3,3)
      logical :: keep(3)
      character(512) :: input
      character(80) :: tag
      call get_command_argument(1,input)
      if (len_trim(input)==0) error stop 'Missing fixed repair corpus'
      call setpara('param_card.dat')
      ImprovePSPoint=2
      keep=.false.
      open(71,file=trim(input),status='old',action='read')
      open(75,file='repair-journal.dat',status='new',action='write')
      read(71,*) ncases
      write(75,'(A,1X,I0)') 'META AXIAL_REPAIR_UNIT_V1',ncases
      qbits=transfer(MP__MDL_MZ,qbits)
      write(75,'(A,1X,Z32.32)') 'MASS_Z',qbits
      call observe('INITIAL',0,0)
      do ic=1,ncases
      read(71,*) tag,legacy_identity
      do i=1,3
      do j=0,3
      read(71,'(Z16,1X,Z32)') dbits,qbits
      din(j,i)=transfer(dbits,din(j,i))
      qin(j,i)=transfer(qbits,qin(j,i))
      end do
      end do
      do prec=1,2
      pd=din
      pq=qin
      write(*,'(A,2(1X,I0),1X,A)') 'CASE_BEGIN',ic,prec,trim(tag)
      flush(6)
      write(75,'(A,3(1X,I0),1X,A)') 'CASE',ic,prec,legacy_identity,trim(tag)
      call vectors('IN')
      call observe('BEFORE',ic,prec)
      if (prec==1) then
      call ML5_0_IMPROVE_PS_POINT_PRECISION(keep,pd)
      else
      call ML5_0_MP_IMPROVE_PS_POINT_PRECISION(keep,pq)
      end if
      call observe('AFTER',ic,prec)
      call vectors('OUT')
      write(75,'(A,2(1X,I0))') 'ENDCASE',ic,prec
      write(*,'(A,2(1X,I0))') 'CASE_END',ic,prec
      flush(6)
      end do
      end do
      write(75,'(A,1X,I0)') 'END',ncases
      close(71)
      close(75)
      contains
      subroutine vectors(label)
      character(*),intent(in) :: label
      do i=1,3
      do j=0,3
      if (prec==1) then
      dbits=transfer(pd(j,i),dbits)
      write(75,'(A,4(1X,I0),1X,Z16.16)') label,ic,prec,i,j,dbits
      else
      qbits=transfer(pq(j,i),qbits)
      write(75,'(A,4(1X,I0),1X,Z32.32)') label,ic,prec,i,j,qbits
      end if
      end do
      end do
      end subroutine
      subroutine observe(label,point,precision)
      character(*),intent(in) :: label
      integer,intent(in) :: point,precision
      type(ieee_round_type) :: mode
      logical :: flags(5),halts(5)
      integer :: code
      call ieee_get_rounding_mode(mode)
      code=-1
      if (mode==ieee_nearest) code=0
      if (mode==ieee_up) code=1
      if (mode==ieee_down) code=2
      if (mode==ieee_to_zero) code=3
      call ieee_get_flag(ieee_invalid,flags(1))
      call ieee_get_flag(ieee_divide_by_zero,flags(2))
      call ieee_get_flag(ieee_overflow,flags(3))
      call ieee_get_flag(ieee_underflow,flags(4))
      call ieee_get_flag(ieee_inexact,flags(5))
      call ieee_get_halting_mode(ieee_invalid,halts(1))
      call ieee_get_halting_mode(ieee_divide_by_zero,halts(2))
      call ieee_get_halting_mode(ieee_overflow,halts(3))
      call ieee_get_halting_mode(ieee_underflow,halts(4))
      call ieee_get_halting_mode(ieee_inexact,halts(5))
      write(75,'(A,1X,A,2(1X,I0),11(1X,I0))') 'ENV',label,point,precision,
     &code,merge(1,0,flags),merge(1,0,halts)
      end subroutine
      end program
