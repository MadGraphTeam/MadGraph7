#!/usr/bin/env python3
"""Dormant, separately admitted same-flag BUILD / REPAIR / AMPLITUDE / TIMING."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/fortran-orig-axial-qualification-work-1'
REPORT=ROOT/'.tirust-build/fortran-orig-axial-qualification-execution-1'
CAPS={'build':600.,'repair':300.,'amplitude':300.,'timing':300.}
CLEANUP=60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
CPU=12
PROC='SubProcesses/P0_uux_z'
ROLES=('original','candidate')
SOURCE=None
REVIEW={}

def require(value,message):
    if not value:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as out:json.dump(value,out,indent=2,sort_keys=True,allow_nan=False);out.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module
def pins():return read(HERE/'input-pins.json')
def base():
    if '_axial_parent' not in sys.modules:
        module=load('_axial_parent',Path(pins()['profile_parent'])/'controller.py')
        module.EXPECTED_SOURCE=digest(module.HERE/'source-index.json')
    return sys.modules['_axial_parent']
def analysis():return load('_axial_analysis',pins()['analysis'])
def collect():return load('_axial_collector',pins()['collector'])
def local_analysis():return load('_axial_repair_analysis',HERE/'analyze.py')

def verify_source():
    require(Path.cwd()==ROOT,'Run only from the MadGraph repository')
    require(SOURCE and digest(HERE/'source-index.json')==SOURCE,'Exact reviewed source seal required')
    seal=read(HERE/'source-index.json');actual=set()
    for path in HERE.rglob('*'):
        require(not path.is_symlink(),'Source symlink forbidden')
        if path.is_file():actual.add(str(path.relative_to(HERE)))
    require(actual==set(seal['files'])|{'source-index.json'},'Source payload inventory changed')
    for name,row in seal['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe payload name')
        require(digest(HERE/name)==row['sha256'] and (HERE/name).stat().st_size==row['bytes'],'Changed source: '+name)
    for name,row in pins()['external_files'].items():
        require(digest(name)==row['sha256'] and Path(name).stat().st_size==row['bytes'],'Changed external input: '+name)
    require(load('_axial_preparation',HERE/'prepare.py').verify()['native_calls']==0,'Input derivation failed')

def protected():
    b=base();b.verify_source();return b.protected()
def preflight():
    verify_source();before=protected();runtime=base().expected_runtime()
    require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    return {'status':'source-only-preflight-passed','source_index_sha256':SOURCE,'protected':before,
        'expected_runtime':runtime,'caps_seconds':CAPS,'cleanup_reserve_inside_cap':CLEANUP,
        'limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'native_calls':0,'compiler_invocations':0}

def receipt(stage):
    wanted=REVIEW.get(stage);path=REPORT/stage/'terminal.json'
    require(wanted and digest(path)==wanted,'Separate reviewed '+stage+' terminal required')
    terminal=read(path);result=read(REPORT/stage/'result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],'Predecessor cleanup/final status failed')
    require(terminal['result_sha256']==digest(REPORT/stage/'result.json') and result['status']=='passed'
        and result['source_index_sha256']==SOURCE,'Predecessor source/result mismatch')
    return result

def object_inventory(output):return base().canonical_objects(output,False)
def original_objects():return read(Path(pins()['profile_parent'])/'input-pins.json')['numerical_objects']
def check_selected_objects(output):
    actual=object_inventory(output);original=original_objects();changed={PROC+'/check_sa.o',PROC+'/improve_ps.o'}
    require({k:v for k,v in actual.items() if k not in changed}=={k:v for k,v in original.items() if k not in changed},'Unselected original object changed')
    require(actual[PROC+'/check_sa.o']==digest(pins()['plain_driver_object']),'Shared plain driver object changed')
    return actual

def remap_link(output,unit=False):
    argv=list(pins()['link_amplitude']);directory=output/PROC
    argv=[item.replace(pins()['old_link_output'],str(output)) for item in argv]
    require(argv.count('check_sa.o')==1 and argv.count('check')==1,'Closed link layout changed')
    if unit:
        argv[argv.index('check_sa.o')]=str(WORK/'build/common/repair_driver.o')
        argv[argv.index('check')]='repair-check'
        argv=[item.replace('private-link.map','repair-link.map') for item in argv]
    return argv

def link(output,unit,logs):
    b=base();directory=output/PROC;loader=b.load('axial_build_loader',ROOT/b.LOADER)
    argv=remap_link(output,unit);name='repair' if unit else 'amplitude'
    callback=lambda a,n:b.command(a,directory,logs,name+'-'+n)
    prebound=loader.prelink(argv,directory,b.environment(),callback)
    # The exact existing linked process retains all15 original providers even
    # when the standalone main invokes only model initialization and repair.
    for path,wanted in b.expected_runtime()['files'].items():
        require(path not in prebound['bound'] or prebound['bound'][path]==wanted,'Prelink provider conflict')
        prebound['bound'][path]=wanted
    dump(logs.parent/(name+'-prelink.json'),prebound)
    b.command(argv,directory,logs,name+'-link')
    executable=directory/('repair-check' if unit else 'check');mapfile=directory/('repair-link.map' if unit else 'private-link.map')
    loads=loader.requireactualmap(mapfile.read_text(),directory,prebound,executable)
    runtime=loader.query_runtime(executable,b.expected_runtime()['files'],prebound,callback)
    symbols=b.command([b.tool('nm'),'--defined-only',str(executable)],directory,logs,name+'-symbols')
    names=[line.split()[-1] for line in symbols.splitlines() if len(line.split())>=3]
    for symbol in ('ml5_0_improve_ps_point_precision_','ml5_0_mp_improve_ps_point_precision_'):
        require(names.count(symbol)==1,'Public repair ABI missing or duplicated')
    require(len(b.module_symbols(symbols))==23 and all(n==1 for n in b.module_symbols(symbols).values()),'MTIRUST ownership changed')
    return {'executable':str(executable),'executable_sha256':digest(executable),'map_sha256':digest(mapfile),
        'prelink_sha256':digest(logs.parent/(name+'-prelink.json')),'actual_link_loads':loads,'runtime':runtime}

def build():
    b=base();bench=b.modules()[0];before=protected();p=pins();results={}
    common=WORK/'build/common';common.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(HERE/'repair_driver.f',common/'repair_driver.f')
    donor=Path(p['donor']);donorproc=donor/PROC
    # Use original fixed-form flags, with original include search directories
    # made absolute for the common driver outside the process directory.
    driverargv=[p['compiler'],*p['flags'],'-I'+str(donorproc),'-I'+str(donor/'Source/MODEL'),
        '-I'+str(donor/'Source/DHELAS'),'-c','repair_driver.f','-o','repair_driver.o']
    b.command(driverargv,common,REPORT/'build/common/commands','compile-standalone-driver')
    for role in ROLES:
        output=WORK/'build'/role;b.clone(donor,output);directory=output/PROC;logs=REPORT/'build'/role/'commands'
        shutil.copyfile(p['plain_driver_source'],directory/'check_sa.f');shutil.copyfile(p['plain_driver_object'],directory/'check_sa.o')
        initial=check_selected_objects(output)
        if role=='candidate':
            shutil.copyfile(Path(p['source2'])/'candidate-improve_ps.f',directory/'improve_ps.f')
            b.command(p['compile_repair'],directory,logs,'compile-only-candidate-improve-ps')
        else:
            require(digest(directory/'improve_ps.f')=='d511a2b32b286067c387fc2fc9b1e3d53600f8f7aaf107a53b98e18ec9a53260','Original measured repair source changed')
        actual=check_selected_objects(output)
        if role=='original':require(actual==initial,'Original repair object changed')
        # No makefile, compiler policy, numerical card or other source changes.
        sources=bench.generated_sources(output);wanted=dict(read(Path(p['profile_parent'])/'input-pins.json')['generated_sources'])
        wanted[PROC+'/check_sa.f']=digest(p['plain_driver_source'])
        if role=='candidate':wanted[PROC+'/improve_ps.f']=digest(Path(p['source2'])/'candidate-improve_ps.f')
        require(sources==wanted,'Unselected generated source changed')
        results[role]={'output':str(output),'sources':sources,'objects':actual,
            'amplitude':link(output,False,logs),'repair':link(output,True,logs)}
    require(protected()==before,'Protected donor changed')
    dump(REPORT/'build/result.json',{'status':'passed','source_index_sha256':SOURCE,'variants':results,
        'driver_object_sha256':digest(common/'repair_driver.o'),'driver_source_sha256':digest(common/'repair_driver.f'),
        'compiler_flags':p['flags'],'compiler_invocations':2,'amplitude_or_model_calls':0,'protected':before})

def verified_build():
    built=receipt('build');b=base();bench=b.modules()[0];loader=b.load('axial_verify_loader',ROOT/b.LOADER)
    require(digest(WORK/'build/common/repair_driver.o')==built['driver_object_sha256'],'Standalone driver object changed')
    for role,row in built['variants'].items():
        output=Path(row['output']);directory=output/PROC
        require(bench.generated_sources(output)==row['sources'] and check_selected_objects(output)==row['objects'],'Reviewed private source/object changed')
        for name,filename,mapname in (('amplitude','check','private-link.map'),('repair','repair-check','repair-link.map')):
            item=row[name];prelink=REPORT/'build'/role/(name+'-prelink.json')
            require(digest(directory/filename)==item['executable_sha256'] and digest(directory/mapname)==item['map_sha256']
                and digest(prelink)==item['prelink_sha256'],'Reviewed executable/link identity changed')
            require(loader.requireactualmap((directory/mapname).read_text(),directory,read(prelink),directory/filename)==item['actual_link_loads'],'Actual LOAD binding changed')
    return built

def private_binding(output,row):
    b=base();bench=b.modules()[0];directory=output/PROC;parent=read(Path(pins()['profile_parent'])/'input-pins.json')
    require(bench.generated_sources(output)==row['sources'] and check_selected_objects(output)==row['objects'],'Execution source/object changed')
    for name,filename in (('amplitude','check'),('repair','repair-check')):require(digest(directory/filename)==row[name]['executable_sha256'],'Execution ELF changed')
    cards=bench.numerical_card_inputs(output);alias=PROC+'/MadLoop5_resources/MadLoopParams.dat'
    expected={**parent['numerical_cards'],alias:next(iter(parent['numerical_cards'].values()))}
    require(cards==expected,'Private numerical card inventory changed')
    card=bench.resolved_parameter_card(directory);closed=read(parent['closed_input'])
    require(card is not None and digest(card)==closed['param_card_sha256']==digest(output/'Cards/param_card.dat'),'Physical model card changed')
    require(all((output/name).resolve().is_relative_to(output.resolve()) for name in cards),'Mutable card escapes private clone')
    return {'cards':cards,'physical_sha256':digest(card)}

def repair():
    built=verified_build();before=protected();p=pins();rows={};diags={};corpus=read(HERE/'repair-corpus.json')
    for role in ROLES:
        output=WORK/'repair'/role;base().clone(Path(built['variants'][role]['output']),output);directory=output/PROC
        binding=private_binding(output,built['variants'][role]);logs=REPORT/'repair'/role/'commands'
        stdout=base().command([str(directory/'repair-check'),str(HERE/'repair-corpus.dat')],directory,logs,'standalone-repair')
        shutil.copyfile(directory/'repair-journal.dat',REPORT/'repair'/role/'repair-journal.dat')
        rows[role]=local_analysis().journal((directory/'repair-journal.dat').read_text(),corpus)
        diags[role]=local_analysis().diagnostics(stdout,corpus)
        require(private_binding(output,built['variants'][role])==binding,'Private repair inputs changed')
    for role in ROLES:
        dump(REPORT/'repair'/role/'parsed-journal.json',rows[role]);dump(REPORT/'repair'/role/'parsed-diagnostics.json',diags[role])
    result=local_analysis().compare(rows['original'],rows['candidate'],diags['original'],diags['candidate'],p)
    require(protected()==before,'Protected donor changed')
    dump(REPORT/'repair/result.json',{'status':'passed','source_index_sha256':SOURCE,'build_terminal_sha256':REVIEW['build'],
        'comparison':result,'journals':rows,'diagnostics':diags,'performance_acceptance':False})

def expected_codes():
    parent=read(Path(pins()['profile_parent'])/'input-pins.json');closed=read(parent['closed_observation'])
    result={int(row['point']):int(row['status']) for row in closed['rows']}
    require(set(result)==set(range(1,101)) and set(result.values())=={219},'Closed n1 DP cohort changed')
    return result

def exact(worker,destination):
    worker.sequence+=1;worker._send(f'EXACT {worker.sequence} 0')
    require(worker._message()==['EXACTED',str(worker.sequence)],'Plain exact command failed')
    destination.mkdir(parents=True,exist_ok=False)
    for name in ('exact-words.dat','exact-ieee.dat'):shutil.copyfile(worker.directory/name,destination/name)
    return {'rows':analysis().exact((destination/'exact-words.dat').read_text(),expected_codes()),
        'ieee':analysis().ieee((destination/'exact-ieee.dat').read_text())}

def start_worker(role,stage,built,stack):
    b=base();output=WORK/stage/role;b.clone(Path(built['variants'][role]['output']),output);directory=output/PROC
    report=REPORT/stage/role;binding=private_binding(output,built['variants'][role]);_,_,Worker,*_=b.modules()
    report.mkdir(parents=True,exist_ok=True)
    worker=stack.enter_context(Worker([b.tool('taskset'),'-c',str(CPU),str(directory/'check'),pins()['points']],
        directory,report/'worker.log',env=b.environment(),timeout=210.))
    ready={k:getattr(worker,k) for k in ('points','ndim','nso','nborn','cold_seconds')}
    require([ready[k] for k in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong n1 worker dimensions')
    shutil.copyfile(directory/'warmup.dat',report/'warmup.dat')
    learned=collect().learning((directory/'warmup.dat').read_text());qualified=exact(worker,report/'exact')
    dump(report/'ready.json',ready);dump(report/'maps-before.json',b.maps(worker));dump(report/'private-before.json',binding)
    require(analysis().compare_variants(learned['rows'],qualified['rows'],b.modules()[0].compare_rows)['passed'],'Learning/final physics differs')
    return worker,{'output':output,'binding':binding,'learning':learned,'exact':qualified,'ready':ready}

def finish_worker(role,stage,worker,info,built):
    dump(REPORT/stage/role/'maps-after.json',base().maps(worker))
    require(private_binding(info['output'],built['variants'][role])==info['binding'],'Worker inputs changed')

def amplitude():
    built=verified_build();repaired=receipt('repair');require(repaired['build_terminal_sha256']==REVIEW['build'],'Repair build mismatch')
    before=protected();observed={}
    with ExitStack() as stack:
        for role in ROLES:
            worker,info=start_worker(role,'amplitude',built,stack);observed[role]=info
            finish_worker(role,'amplitude',worker,info,built)
    a,c=(observed[role] for role in ROLES);compare=analysis().compare_variants(a['exact']['rows'],c['exact']['rows'],base().modules()[0].compare_rows)
    learned=analysis().compare_variants(a['learning']['rows'],c['learning']['rows'],base().modules()[0].compare_rows)
    dump(REPORT/'amplitude/comparisons.json',{'final':compare,'learning':learned})
    require(compare['passed'] and learned['passed'],'Amplitude scientific gate failed')
    require(a['learning']['history']==c['learning']['history'] and a['exact']['ieee']==c['exact']['ieee'],'Accepted history/observed IEEE differs')
    require(protected()==before,'Protected donor changed')
    dump(REPORT/'amplitude/result.json',{'status':'passed','source_index_sha256':SOURCE,'build_terminal_sha256':REVIEW['build'],
        'repair_terminal_sha256':REVIEW['repair'],'variants':{role:{k:v for k,v in info.items() if k not in ('output','binding')} for role,info in observed.items()},
        'final_comparison':compare,'learning_comparison':learned,'history_equal':True,'observed_IEEE_equal':True,
        'software_latch_scope':'No internal software latch observer is added to the unchanged plain driver.',
        'performance_acceptance':False})

def timing():
    built=verified_build();qualified=receipt('amplitude');receipt('repair')
    require(qualified['build_terminal_sha256']==REVIEW['build'] and qualified['repair_terminal_sha256']==REVIEW['repair'],'Amplitude predecessor mismatch')
    before=protected();pairs=[];workers={};infos={};b=base();p=pins()
    with ExitStack() as stack:
        for role in ROLES:
            worker,info=start_worker(role,'timing',built,stack);workers[role]=worker;infos[role]=info
            own=analysis().compare_own(qualified['variants'][role]['exact']['rows'],info['exact']['rows'])
            dump(REPORT/'timing'/role/'own-qualification-comparison.json',own)
            require(own['passed'],'Fresh own-variant exact words/status changed')
            require(info['exact']['ieee']==qualified['variants'][role]['exact']['ieee'],'Fresh own IEEE differs')
            require(info['learning']['history']==qualified['variants'][role]['learning']['history'],'Fresh own learning history differs')
        for pair in range(1,p['cycles']+1):
            order=list(ROLES) if pair%2 else list(reversed(ROLES));record={'pair':pair,'order':order}
            for role in order:
                worker=workers[role];worker.sequence+=1;worker._send(f'TIMED {worker.sequence} {p["traversals_per_batch"]}')
                require(worker._message()==['DONE',str(worker.sequence),str(p['traversals_per_batch'])],'Timed command failed')
                raw=REPORT/'timing'/role/f'pair-{pair}';raw.mkdir(parents=True,exist_ok=False)
                for name in ('timing.dat','values.dat','timed_status.dat','timed-exact-words.dat','timed-ieee.dat'):shutil.copyfile(worker.directory/name,raw/name)
                rows=analysis().exact((raw/'timed-exact-words.dat').read_text(),expected_codes())
                require(analysis().decimal_exact((raw/'values.dat').read_text(),expected_codes())==rows,'Timed decimal/raw joins differ')
                own=analysis().compare_own(infos[role]['exact']['rows'],rows)
                dump(raw/'own-comparison.json',own);require(own['passed'],'Timed own coefficient/status changed')
                states=analysis().ieee((raw/'timed-ieee.dat').read_text(),[0]);expected=infos[role]['exact']['ieee']
                require(states[0][2:]==expected[0][2:] and states[1][2:]==expected[-1][2:],'Timed observed IEEE differs')
                status=analysis().status_histogram((raw/'timed_status.dat').read_text(),expected_codes(),p['traversals_per_batch'])
                parsed=b.modules()[3](worker.directory,9,100,p['traversals_per_batch'])
                require(parsed['seconds']>0,'Nonpositive measured time retained as failure')
                record[role]={'seconds':parsed['seconds'],'rows':rows,'ieee':states,'timed_status_counts':status,'own_comparison':own}
            scientific=analysis().compare_variants(record['original']['rows'],record['candidate']['rows'],b.modules()[0].compare_rows)
            require(scientific['passed'],'Timed cross-variant scientific gate failed');record['comparison']=scientific
            pairs.append(record);dump(REPORT/'timing'/f'pair-{pair}.json',record)
        for role in ROLES:finish_worker(role,'timing',workers[role],infos[role],built)
    require(protected()==before,'Protected donor changed')
    dump(REPORT/'timing/result.json',{'status':'passed','source_index_sha256':SOURCE,'build_terminal_sha256':REVIEW['build'],
        'repair_terminal_sha256':REVIEW['repair'],'amplitude_terminal_sha256':REVIEW['amplitude'],'pairs':pairs,
        'summary':analysis().timing_summary(pairs),'calls_per_batch':100*p['traversals_per_batch'],
        'initialization':{role:info['ready'] for role,info in infos.items()},'performance_acceptance':False,'candidate_promoted':False})

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited resource cap too small');resource.setrlimit(kind,(value,value))

def require_admission(stage):
    row=read(REPORT/stage/'admission.json')
    require(row['stage']==stage and row['source_index_sha256']==SOURCE and row['reviewed']==REVIEW
        and row['cap_seconds']==CAPS[stage] and row['resource_limits']==LIMITS and row['parent_pid']==os.getppid(),'Missing exact supervisor admission')
    require(os.sched_getaffinity(0)=={CPU},'Child affinity differs')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limits differ')
    dump(REPORT/stage/'actual-limits.json',{'pid':os.getpid(),'session':os.getsid(0),'resource_limits':LIMITS,'cpu':CPU})

def stage(name):
    b=base();p=pins();cleanup=load('_axial_cleanup',p['cleanup']);ownership=load('_axial_ownership',p['ownership'])
    directory=REPORT/name;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':name,'source_index_sha256':SOURCE,'reviewed':REVIEW,'cap_seconds':CAPS[name],
        'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running'}
    owned=None;process=None;raw_record=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAPS[name]) as deadline:
            entry['deadline_monotonic']=deadline.end;requests.check();preflight()
            if name!='build':verified_build()
            required={'build':(),'repair':(),'amplitude':('repair',),'timing':('repair','amplitude')}
            for predecessor in required[name]:receipt(predecessor)
            argv=[b.tool('taskset'),'-c',str(CPU),b.tool('python3'),'-B',str(Path(__file__).relative_to(ROOT)),'--child',name,'--source',SOURCE]
            for phase,checksum in REVIEW.items():argv+=['--reviewed-'+phase,checksum]
            env=b.environment() # Reconstruct before the narrow process-identity handoff.
            dump(directory/'admission.json',{**entry,'command':argv,'parent_pid':os.getpid()})
            with (directory/'console.log').open('xb') as out:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Stage failed; no retry')
            protected();verify_source();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=ownership.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error),publication_scope='First failure retained; no pass or automatic retry')
        dump(directory/'terminal.json',entry);raise

def main():
    global SOURCE,REVIEW
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group()
    group.add_argument('--stage',choices=CAPS);group.add_argument('--child',choices=CAPS)
    parser.add_argument('--source',required=True);parser.add_argument('--execute',action='store_true')
    for name in ('build','repair','amplitude'):parser.add_argument('--reviewed-'+name)
    args=parser.parse_args();SOURCE=args.source;selected=args.stage or args.child
    REVIEW={name:getattr(args,'reviewed_'+name) for name in ('build','repair','amplitude') if getattr(args,'reviewed_'+name)}
    for value in (SOURCE,*REVIEW.values()):require(re.fullmatch('[0-9a-f]{64}',value),'Expected exact SHA256')
    predecessors={'build':set(),'repair':{'build'},'amplitude':{'build','repair'},'timing':{'build','repair','amplitude'}}
    if selected:require(set(REVIEW)==predecessors[selected],'Separate exact predecessor admissions required')
    if args.child:
        require(not args.execute,'Child is supervisor-only');limits();require_admission(args.child);verify_source();protected()
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB)
            {'build':build,'repair':repair,'amplitude':amplitude,'timing':timing}[args.child]()
        return
    if not selected:
        require(not args.execute,'Execute requires one explicit stage');print(json.dumps(preflight(),indent=2));return
    require(args.execute,'Dormant stage requires separate root admission and --execute')
    stage(selected)

if __name__=='__main__':main()
