# Dormant analytic ORIG qualification

This is a source-only native-qualification proposal for the unapplied analytic
repair candidate84e8caf5 from `fortran-orig-axial-proposal-2`. No native stage is
admitted by preparation, tests, preflight or this README. Production and the
original/source1/source2 candidates remain unchanged.

The controller reuses the closed same-flag N1 repair-profile donor bindings,
tool environment, loader/map parser and owned-descendant cleanup primitives.
It uses the newer qualified absolute-end/handoff helper, with environment
reconstruction outside the handoff. Each stage needs separate root admission
and an exact reviewed predecessor terminal. CPU12 is nonexclusive; the shared
numerical mutex fails if busy. All stages reserve60s inside their original cap,
use16GiB address-space/512MiB-file/core0 limits and single-thread libraries.

The scientific flags stay `-w -fPIC -ffixed-line-length-132`. Only one candidate
`improve_ps.f` and the standalone test driver are compiled. The original repair
object and every other original numerical object/archive/module are reused
under exact source/object/recipe/runtime bindings. Two plain amplitude ELFs are
linked with the same original objects/link recipe, differing only in the repair
object. No profile module, profiling hook, O3 flag, Rust source or reducer
setting is added. The raw campaign driver has only RUN: the exact/timed plain
driver source/object is the already closed **original-control** N1 driver from
the earlier O3 study (source ed0a5fff / object c9644a56), shared by both arms.
Its name O3_CAPTURE_FP is retained; that helper only reads IEEE state. No O3
candidate object or compiler option is reused. The standalone main is linked
to the same original process object/provider closure, but calls no amplitude
or reducer entrypoint.

Stages are separate: BUILD (compiles/links and metadata only), REPAIR (one small
standalone process per arm), AMPLITUDE (one fresh full100-learning/final100
worker per arm), then optional TIMING only after separate parity review.
No stage retries or extends its deadline.

The standalone driver initializes the same model/card, uses ImprovePSPoint2 and
journals raw DP/QP input/output words, diagnostics and default observed IEEE
state. It does not change rounding, flags or halting modes. Fixtures include
all100 saved N1 points, beam-label swaps, exact rotations, a transverse boost,
finite transverse residuals, off-shell incoming vectors, high boosts and
nonfinite/refusal cases. The measured source hardcodes zero incoming model
masses: the massive-vector fixture tests rejection of input inconsistent with
that massless model, not a genuinely massive incoming model.

There are136 fixed fixtures:100 saved,2 beam swaps,4 rotations,1 transverse
boost,2 larger longitudinal boosts,1 genuine QP last-bit perturbation,1 small
axial off-shell perturbation,4 finite refusals,1 invalid zero point and20
incoming E/pz nonfinite poisons. The saved DP words are checked
against the original point file; QP words are exact binary64 lifts except for
the explicitly generated rational fixtures. Fixed-form driver text is derived
from the readable free-form template before sealing, so original fixed-form
includes and compile flags are retained.

Fixture source-path classes are explicit rather than inferred from names.
The small off-shell axial perturbation is within the unchanged caller's sanity
tolerance and satisfies the analytic local guard: it is eligible and receives
the finite-projection rules. Doubling that incoming energy fails the caller's
on-shell sanity predicate; it does not establish a massive-model local guard.
The zero point is also locally eligible after final-leg energy repair, because
the caller's ordered NaN comparisons can allow its0/0 ratios. ORIG's unchanged
close test then refuses that large repair and invokes unchanged legacy rescue.
This invalid input is checked for preserved public diagnostics/output/IEEE,
without requiring a physical repaired point or claiming local guard refusal.
The other29 refusal cases are26 local guard refusals (rotations/transverse/
nonfinite) and3 caller sanity refusals (large off-shell/negative/spacelike).
These classes are source expectations, not instrumented branch observations.

Finite eligible QP differences are diagnostic. Qualification checks physical
residuals and the preserved safeguards, while refused guards require unchanged
legacy output words/diagnostics/observed state. The later ordinary amplitude
pair must pass the existing3e-6 criterion and hard1e-8 target for all Born/Laurent
coefficients, preserve accepted public backend/precision/status histories and
observed IEEE controls, and retain accuracy/word differences. The unchanged
plain driver has no internal software-latch observer; no such evidence is
claimed. Before execution, normalized max shell/conservation residual limits
are frozen at1e-12 for returned DP and1e-25 for QP, positive energies are
required, and normalized input/output L1 change must stay within1e-2 for every
finite eligible case in both arms. Refused cases retain residual diagnostics
without imposing a new projection rule on the unchanged legacy branches.

Only after those reviews may seven alternating matched-history pairs of about
one second per full100 batch measure runtime. Timed calls must match their own
qualified variant's coefficient/status words; accuracy drift is retained.
Initialization and shared-host scatter are separate. No formal performance
acceptance, broader-model qualification or promotion is implied; Hua-Sheng's
local paired campaign remains the formal timing TODO.

BUILD is600s total; REPAIR/AMPLITUDE/TIMING are each300s total, including the60s
cleanup reserve. BUILD performs exactly two compiles (candidate repair and
test main), four links, pre-link/compiler metadata queries, nm and actual
PT_INTERP provider listings. REPAIR runs two standalone mains. AMPLITUDE runs
two fresh full100-learning/final100 workers, checked against the frozen all219
N1 DP cohort. TIMING starts two new qualified workers, then exactly seven
alternating pairs of128 full100 traversals, retaining179200 timed statuses.
Accuracy drift is diagnostic; within-record decimal/raw joins still include
all five words. Fresh/timed own-variant coefficient/status words remain exact.

After separate source review the default command is the pinned Python with
`-B controller.py --source SOURCE_SHA256`; it is file-only preflight. Each real
stage additionally requires `--stage build|repair|amplitude|timing --execute`
and every earlier stage's separately reviewed terminal as
`--reviewed-build HASH`, then `--reviewed-repair HASH`, then
`--reviewed-amplitude HASH` as applicable. Preparation, tests or preflight
authorize no compiler, linker, loader, model, repair or amplitude invocation.
