"""Pure rational identities/guard corpus; no compiled repair is evaluated."""
from fractions import Fraction as Q
from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('analytic_axial_preparation', HERE / 'prepare.py')
prep = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prep)
SIGN = 1 << 127
MAG = SIGN - 1
EXP = ((1 << 15) - 1) << 112


def word_zero(bits):
    return bits & MAG == 0


def word_finite(bits):
    return bits & EXP != EXP


def word_positive(bits):
    return word_finite(bits) and not bits & SIGN and not word_zero(bits)


def guarded(total, masses=(Q(0), Q(0)), transverse=(Q(0),) * 4,
            preceding_checks=True):
    """Exact-real model of the new guard after the unchanged earlier checks.

    Nonfinite encodings are covered separately by the integer-word tests. This
    is not a binary128 evaluator or a prediction of the final-leg square root.
    """
    if not preceding_checks or any(masses) or any(transverse):
        return False
    e, x, y, z = total
    if x or y:
        return False
    discr = abs(-e * e + x * x + y * y + z * z)
    if discr <= 0 or e <= abs(z):
        return False
    if e + z <= 0:
        return False
    return e - z > 0


def expanded(total, e1, z1, e2, z2):
    """Literal exact-rational evaluation of the four existing shift formulas."""
    e, x, y, z = total
    d = abs(-e ** 2 + x ** 2 + y ** 2 + z ** 2)
    de = 2 * (e - z) * (e + z)
    dz = 2 * (e ** 2 - z ** 2)
    se1 = (e * (-2 * e1 * e + e ** 2 + x ** 2 + y ** 2)
           + (2 * e1 - e) * z ** 2 + z * d) / de
    se2 = -(e * (2 * e2 * e - e ** 2 + x ** 2 + y ** 2)
            + (-2 * e2 + e) * z ** 2 + z * d) / de
    sz1 = (-2 * z1 * (e ** 2 - z ** 2)
           + z * (e ** 2 + x ** 2 + y ** 2 - z ** 2) + e * d) / dz
    sz2 = -(2 * z2 * (e ** 2 - z ** 2)
            + z * (-e ** 2 + x ** 2 + y ** 2 + z ** 2) + e * d) / dz
    return e1 + se1, z1 + sz1, e2 + se2, z2 + sz2


def analytic(total):
    e, _, _, z = total
    plus, minus = (e + z) / 2, (e - z) / 2
    return plus, plus, minus, -minus


def points():
    raw = prep.POINTS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != prep.POINTS_SHA:
        raise ValueError('Saved input changed')
    rows = raw.decode().splitlines()
    count = int(rows[0])
    if count != 100 or len(rows) != 1 + 3 * count:
        raise ValueError('Unexpected saved point layout')
    # Parse the saved DP words first; all subsequent algebra uses integers.
    data = [[Q.from_float(float(x)) for x in row.split()] for row in rows[1:]]
    return [data[i:i + 3] for i in range(0, len(data), 3)]


class Candidate(unittest.TestCase):
    def test_exact_measured_source_and_reversible_insertions(self):
        result = prep.verify()
        self.assertTrue(result['original_bytes_reconstructed'])
        self.assertEqual(result['native_executions'], 0)

    def test_all100_saved_points_exact_rational_identity_and_geometry(self):
        for index, (p1, p2, final) in enumerate(points()):
            with self.subTest(point=index):
                self.assertTrue(guarded(final, transverse=(p1[1], p1[2], p2[1], p2[2])))
                positive, negative = (p1, p2) if p1[3] > 0 else (p2, p1)
                self.assertEqual(expanded(final, positive[0], positive[3], negative[0], negative[3]),
                                 analytic(final))
                plus, zp, minus, zm = analytic(final)
                self.assertEqual(plus + minus, final[0])
                self.assertEqual(zp + zm, final[3])
                self.assertEqual(plus ** 2 - zp ** 2, 0)
                self.assertEqual(minus ** 2 - zm ** 2, 0)

    def test_boosted_rational_sweep_and_old_incoming_cancellation(self):
        for e in (Q(1), Q(31, 8), Q(2) ** 100, Q(2) ** -100):
            for ratio in (Q(0), Q(1, 2), Q(-1, 2), Q(999, 1000), Q(-999, 1000)):
                total = (e, Q(0), Q(0), e * ratio)
                self.assertTrue(guarded(total))
                for old in ((e / 2, e / 2, e / 2, -e / 2),
                            (e / 3, e / 7, e / 5, -e / 11)):
                    self.assertEqual(expanded(total, *old), analytic(total))

    def test_final_multiplicity_enters_only_through_unchanged_total(self):
        finals = ((Q(5), Q(1), Q(2), Q(1)), (Q(7), Q(-1), Q(-2), Q(2)))
        total = tuple(sum((p[k] for p in finals), Q(0)) for k in range(4))
        self.assertTrue(guarded(total))
        self.assertEqual(expanded(total, Q(6), Q(6), Q(6), Q(-6)), analytic(total))

    def test_nonzero_final_transverse_is_refused_and_really_changes_projection(self):
        total = (Q(10), Q(1, 16), Q(0), Q(2))
        self.assertFalse(guarded(total))
        self.assertNotEqual(expanded(total, Q(6), Q(6), Q(4), Q(-4)), analytic(total))

    def test_transverse_massive_rotated_and_prior_invalid_refusals(self):
        good = (Q(10), Q(0), Q(0), Q(2))
        self.assertFalse(guarded(good, masses=(Q(1), Q(0))))
        self.assertFalse(guarded(good, masses=(Q(0), Q(1))))
        for axis in range(4):
            transverse = [Q(0)] * 4
            transverse[axis] = Q(1, 1 << 100)
            self.assertFalse(guarded(good, transverse=transverse))
        self.assertFalse(guarded(good, transverse=(Q(6), Q(0), Q(-6), Q(0))))
        self.assertFalse(guarded(good, preceding_checks=False))
        for bad in ((Q(0), Q(0), Q(0), Q(0)), (Q(1), Q(0), Q(0), Q(1)),
                    (Q(1), Q(0), Q(0), Q(2)), (Q(-10), Q(0), Q(0), Q(2))):
            self.assertFalse(guarded(bad))

    def test_binary128_integer_classification_refuses_nonfinite_without_FP(self):
        one = 16383 << 112
        self.assertTrue(word_zero(0))
        self.assertTrue(word_zero(SIGN))
        self.assertTrue(word_positive(one))
        self.assertFalse(word_positive(one | SIGN))
        self.assertFalse(word_positive(0))
        for nonfinite in (EXP, EXP | SIGN, EXP | (1 << 111), EXP | 1, EXP | SIGN | 1):
            self.assertFalse(word_zero(nonfinite))
            self.assertFalse(word_finite(nonfinite))
            self.assertFalse(word_positive(nonfinite))

    def test_fallback_diagnostics_and_PSMC_bytes_remain_exact(self):
        original = (HERE / 'original-improve_ps.f').read_bytes()
        candidate = (HERE / 'candidate-improve_ps.f').read_bytes()
        self.assertEqual(prep.reconstruct(candidate), original)
        marker = b'      SUBROUTINE ML5_0_MP_PSMC_IMPROVE_PS_POINT_PRECISION('
        self.assertEqual(candidate[candidate.index(marker):], original[original.index(marker):])
        text = candidate.decode()
        self.assertLess(text.index('GOTO 90'), text.index(' 90   CONTINUE'))
        self.assertIn(' 90   CONTINUE\n      NEWP(1,P2) = P(1,P2)', text)
        self.assertNotIn('IEEE_', prep.DECL + prep.GUARD)
        self.assertNotIn('SAVE', prep.DECL + prep.GUARD)
        self.assertNotIn('.AND.', prep.GUARD)
        self.assertLess(prep.GUARD.index('IF(PT(0).GT.ABS(PT(3)))'),
                        prep.GUARD.index('AXIAL_EP=PT(0)+PT(3)'))
        self.assertLess(prep.GUARD.index('IF(AXIAL_EP.GT.ZERO)'),
                        prep.GUARD.index('IF(AXIAL_EM.GT.ZERO)'))


def denied(*args, **kwargs):
    raise RuntimeError('Native/process/library/network/signal access forbidden in pure tests')


if __name__ == '__main__':
    with mock.patch.object(subprocess, 'Popen', denied), mock.patch.object(subprocess, 'run', denied), \
         mock.patch.object(ctypes, 'CDLL', denied), mock.patch.object(socket, 'socket', denied), \
         mock.patch.object(os, 'system', denied), mock.patch.object(os, 'killpg', denied):
        unittest.main(verbosity=2)
