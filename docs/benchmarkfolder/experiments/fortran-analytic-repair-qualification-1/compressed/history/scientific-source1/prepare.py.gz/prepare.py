"""Prepare one unapplied, same-flag Fortran candidate; never invoke a tool."""
from pathlib import Path
import difflib
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGIN = ROOT / '.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n1_uux_z/SubProcesses/P0_uux_z/improve_ps.f'
SOURCE_SHA = 'd511a2b32b286067c387fc2fc9b1e3d53600f8f7aaf107a53b98e18ec9a53260'
POINTS = ROOT / 'docs/benchmarkfolder/campaigns/entry-latch-cache-guard-1/points/qcd_n1_uux_z.dat'
POINTS_SHA = '2ed64c5cba477ce0e7ed3a7bbd642521061b251573ed20957f8e3bc396fa5b35'

DECL = '''C     Private analytic ORIG candidate: qualified GNU binary128 guard.
      INTEGER,PARAMETER :: AXIAL_IK=SELECTED_INT_KIND(33)
      INTEGER(AXIAL_IK),PARAMETER :: AXIAL_MAG_MASK=
     $ INT(Z'7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF',AXIAL_IK)
      INTEGER(AXIAL_IK),PARAMETER :: AXIAL_EXP_MASK=
     $ INT(Z'7FFF0000000000000000000000000000',AXIAL_IK)
      INTEGER,PARAMETER :: AXIAL_FORMAT_ASSERT=1/MERGE(1,0,
     $ STORAGE_SIZE(0.0E0_16).EQ.128.AND.DIGITS(0.0E0_16).EQ.113.AND.
     $ RADIX(0.0E0_16).EQ.2.AND.
     $ STORAGE_SIZE(INT(0,KIND=AXIAL_IK)).EQ.128.AND.
     $ BIT_SIZE(INT(0,KIND=AXIAL_IK)).EQ.128)
      INTEGER(AXIAL_IK) AXIAL_ZERO_BITS(8),AXIAL_CLASS_BITS(3)
      REAL*16 AXIAL_EP,AXIAL_EM
'''

GUARD = '''C     Axial, massless incoming beams and exactly zero final transverse
C     sum have the same physical ORIG projection E+=(E+z)/2, E-=(E-z)/2.
C     Keep the original transverse assignments and all acceptance checks.
C     Classify through integers before any new floating-point comparison.
      AXIAL_ZERO_BITS(1)=TRANSFER(MASSES(1),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(2)=TRANSFER(MASSES(2),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(3)=TRANSFER(P(1,1),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(4)=TRANSFER(P(2,1),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(5)=TRANSFER(P(1,2),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(6)=TRANSFER(P(2,2),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(7)=TRANSFER(PT(1),INT(0,KIND=AXIAL_IK))
      AXIAL_ZERO_BITS(8)=TRANSFER(PT(2),INT(0,KIND=AXIAL_IK))
      IF(ALL(IAND(AXIAL_ZERO_BITS,AXIAL_MAG_MASK).EQ.
     $ INT(0,KIND=AXIAL_IK))) THEN
        AXIAL_CLASS_BITS(1)=TRANSFER(PT(0),INT(0,KIND=AXIAL_IK))
        AXIAL_CLASS_BITS(2)=TRANSFER(PT(3),INT(0,KIND=AXIAL_IK))
        AXIAL_CLASS_BITS(3)=TRANSFER(DISCR,INT(0,KIND=AXIAL_IK))
        IF(ALL(IAND(AXIAL_CLASS_BITS,AXIAL_EXP_MASK).NE.
     $   AXIAL_EXP_MASK)) THEN
C         Sequential guards: reject the spacelike absolute-value branch
C         before evaluating E+/-z or the analytic reconstruction.
          IF(DISCR.GT.ZERO) THEN
          IF(PT(0).GT.ABS(PT(3))) THEN
            AXIAL_EP=PT(0)+PT(3)
            AXIAL_EM=PT(0)-PT(3)
            AXIAL_CLASS_BITS(1)=TRANSFER(AXIAL_EP,
     $        INT(0,KIND=AXIAL_IK))
            AXIAL_CLASS_BITS(2)=TRANSFER(AXIAL_EM,
     $        INT(0,KIND=AXIAL_IK))
            IF(ALL(IAND(AXIAL_CLASS_BITS(1:2),AXIAL_EXP_MASK).NE.
     $       AXIAL_EXP_MASK)) THEN
              IF(AXIAL_EP.GT.ZERO) THEN
              IF(AXIAL_EM.GT.ZERO) THEN
                NEWP(0,P1)=AXIAL_EP/TWO
                NEWP(3,P1)=NEWP(0,P1)
                NEWP(0,P2)=AXIAL_EM/TWO
                NEWP(3,P2)=-NEWP(0,P2)
                GOTO 90
              ENDIF
              ENDIF
            ENDIF
          ENDIF
          ENDIF
        ENDIF
      ENDIF
'''

LABEL = ' 90   CONTINUE\n'


def require(value, message):
    if not value:
        raise ValueError(message)


def transform(original):
    require(hashlib.sha256(original).hexdigest() == SOURCE_SHA, 'Exact measured source required')
    text = original.decode()
    start = text.index('      SUBROUTINE ML5_0_MP_ORIG_IMPROVE_PS_POINT_PRECISION(')
    end = text.index('      SUBROUTINE ML5_0_MP_PSMC_IMPROVE_PS_POINT_PRECISION(', start)
    body = text[start:end]
    require(not re.search(r'^\s*90\s', body, re.M), 'Label90 already used')
    anchors = (
        ('      REAL*16 SHIFTE(2),SHIFTZ(2)\n', DECL),
        ('      IF (DISCR.LT.ZERO) DISCR = -DISCR\n', GUARD),
    )
    for anchor, addition in anchors:
        require(body.count(anchor) == 1, 'Unique insertion anchor required')
        body = body.replace(anchor, anchor + addition, 1)
    anchor = '      NEWP(1,P2) = P(1,P2)\n'
    require(body.count(anchor) == 1, 'Unique unchanged transverse assignment required')
    body = body.replace(anchor, LABEL + anchor, 1)
    candidate = text[:start] + body + text[end:]
    require(reconstruct(candidate.encode()) == original, 'Existing scientific bytes changed')
    return candidate.encode()


def reconstruct(candidate):
    text = candidate.decode()
    for addition in (DECL, GUARD, LABEL):
        require(text.count(addition) == 1, 'Unique inserted region required')
        text = text.replace(addition, '', 1)
    return text.encode()


def verify():
    original = (HERE / 'original-improve_ps.f').read_bytes()
    candidate = (HERE / 'candidate-improve_ps.f').read_bytes()
    require(original == ORIGIN.read_bytes(), 'Measured source changed')
    require(candidate == transform(original), 'Candidate differs from exact transform')
    require(hashlib.sha256(POINTS.read_bytes()).hexdigest() == POINTS_SHA, 'Saved points changed')
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(True),
        candidate.decode().splitlines(True), fromfile='a/improve_ps.f', tofile='b/improve_ps.f'))
    require((HERE / 'analytic-axial.patch').read_text() == diff, 'Unapplied patch differs')
    require(all(len(row.expandtabs(8)) <= 132 for row in candidate.decode().splitlines()), 'Fixed-form width exceeded')
    return {'source_sha256': SOURCE_SHA, 'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
        'patch_sha256': hashlib.sha256(diff.encode()).hexdigest(), 'original_bytes_reconstructed': True,
        'source_flags': ['-w', '-fPIC', '-ffixed-line-length-132'], 'native_executions': 0}


if __name__ == '__main__':
    original = ORIGIN.read_bytes()
    candidate = transform(original)
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(True),
        candidate.decode().splitlines(True), fromfile='a/improve_ps.f', tofile='b/improve_ps.f'))
    for name, raw in [('original-improve_ps.f', original), ('candidate-improve_ps.f', candidate),
                      ('analytic-axial.patch', diff.encode())]:
        with (HERE / name).open('xb') as stream:
            stream.write(raw)
    print(json.dumps(verify(), sort_keys=True))
