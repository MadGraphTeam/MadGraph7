# Unapplied analytic ORIG repair candidate

This small source proposal changes only a private copy of the measured n1
`improve_ps.f`, SHA256
`d511a2b32b286067c387fc2fc9b1e3d53600f8f7aaf107a53b98e18ec9a53260`.
Production, templates, generated campaign inputs and all frozen evidence remain
unchanged. No compiler, linker, loader, repair routine or amplitude has run.
There is no speedup or numerical qualification claim.

`analytic-axial.patch` is unapplied to production. The private candidate adds a
GNU binary128 format assertion and integer classification; it adds no IEEE
module, floating environment setter, cache, persistent state or ABI. Original
flags remain `-w -fPIC -ffixed-line-length-132`; this is not the dormant O3
proposal. Removing the three inserted regions reconstructs every original byte.

## What changes

The existing ORIG path retains its final-leg on-shell repair, ordered total
momentum accumulation and choice of the positive-pz incoming leg. After the
original discriminant calculation, the candidate requires exactly zero incoming
masses, exactly axial incoming beams, exactly zero summed final transverse
momentum, a finite positive discriminant, `E>abs(z)` and finite positive `E+z`
and `E-z`. Sequential integer word checks precede every new floating comparison;
the physical-branch guard precedes computing `E+z` and `E-z`, and their positivity
checks are nested rather than relying on logical short-circuit evaluation. Both signed zeros
count as zero. All other inputs flow through the unchanged expanded formulas.

The accepted path reconstructs incoming values as
`Eplus=(E+z)/2`, `pzplus=Eplus`, `Eminus=(E-z)/2`, `pzminus=-Eminus`.
It jumps to the original transverse assignments, retaining their ordered sums
and signed-zero behavior. `IS_PHYSICAL`, final-leg square roots, `IS_CLOSE`,
error codes, warnings, diagnostics, alternative-method handling and all PSMC
source bytes are unchanged. Nonaxial rotations/transverse boosts, massive
incoming legs and nonzero transverse residuals retain legacy behavior.

## Exact-real identity and limits

Let `T=PTx^2+PTy^2`, `A=E^2-z^2`. On the physical branch the old discriminant is
`A-T`. Its expanded formulas simplify exactly to

```
Eplus  = (E+z)/2 + T/(2*(E+z))
pzplus = (E+z)/2 - T/(2*(E+z))
Eminus = (E-z)/2 - T/(2*(E+z))
pzminus = -Eminus
```

Thus the proposed expressions give the same mathematical projection for `T=0`.
Axial incoming beams alone are insufficient: the legacy routine accepts small
transverse residuals and assigns them to the positive-pz leg. This proposal
requires the final transverse sum to be exactly zero. With these zero tests and
positive `E+z`, `E-z`, the positive original absolute discriminant is the
timelike branch. The identity depends only on the unchanged final total and
therefore holds for any final multiplicity; native qualification is still absent.

The original block contains 28 syntactically repeated total-component squares
and four general MP divisions. The candidate avoids that block on eligible
inputs. It retains the sanity tests, final-leg repair and closeness tests, so
their costs remain. Exact-real equivalence does not imply bitwise binary128
equivalence: the candidate removes cancellation against the old incoming values.
Floating rounding, observed exception state, diagnostics, stability/rescue
cohort and the final public amplitude must be qualified before timing or use.

## Pure corpus and reproduction

From the repository root, the pinned Python interpreter may run:

```
python3 -B .tirust-build/fortran-orig-axial-proposal-1/test_candidate.py
python3 -B -O .tirust-build/fortran-orig-axial-proposal-1/test_candidate.py
```

The tests block process/library/network/signal APIs. They verify the reversible
source transform, exact-rational algebra, signed-zero/nonfinite integer-word
guards, transverse/massive/rotated/spacelike/zero-denominator/prior-invalid
refusals and unchanged fallback/PSMC bytes. They also check all 100 saved n1
input geometries and exact-rational formula identities. The saved decimal text
is parsed as binary64, then all algebra uses `Fraction` integers. These are input
geometry/algebra tests; they do not simulate the final-leg binary128 square root
or attest that the compiled candidate actually takes its branch.

The saved points remain in
`docs/benchmarkfolder/campaigns/entry-latch-cache-guard-1/points/qcd_n1_uux_z.dat`,
SHA256 `2ed64c5cba477ce0e7ed3a7bbd642521061b251573ed20957f8e3bc396fa5b35`.
All 100 input geometries have axial beams and zero final transverse components.

## Minimal later native gate; not admitted here

Reuse the closed same-flag repair-profile donor process, pinned compiler/runtime
and benchmark driver. Make two isolated uninstrumented copies and replace only
the candidate's `improve_ps.f`; preserve all other objects, sources, cards and
compiler recipes. Recompile that one unit and relink each required executable
under the existing mutex/CPU12/resource/absolute-deadline supervisor. Do not
reuse the older c91 native bridge profiler or change O3 flags.

First compare original/candidate repair outputs and diagnostics for the saved
100 points, longitudinal boosts and exact axis rotations, reversed beam labels,
off-shell policy cases, transverse residuals, massive/nonaxial refusals and
invalid/nonfinite boundary fixtures. Keep MP word differences as diagnostics;
check physical projection, acceptance/error behavior, warning state and observed
IEEE controls explicitly. Preserve the legacy path for every refused guard.
Then run fresh full100 learning and final100 ordinary amplitudes with normal
independent stability checks. Apply the existing `3e-6` criterion and hard
`1e-8` ordinary candidate/original target; timing requires the same accepted
backend/precision/status cohort. Do not weaken a gate after observing outcomes.

Only after parity review, use at least seven alternating matched-history paired
batches of about one second, with identical saved points, flags and rescue
policy. Report initialization separately and keep raw scatter/accuracy/word
differences. The shared-host result is descriptive; Hua-Sheng's local paired
campaign remains the formal performance acceptance TODO. Any later template
change also needs the other process/backend regression gates.
