"""Dormant observed BUILD/RUN: retain exact closed plain references."""
from pathlib import Path
import hashlib,importlib.util,json,sys,time
START=time.monotonic();HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-plain-run-proposal-4'
PARENT_INDEX='7cc733efccfcfca4aa9a84a36ef3c64ea3cc4471f71e7a48bafaa16ebef3f925'
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def load(name,p,sha):
    require(digest(p)==sha,'changed source '+str(p));spec=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def parent_index(folder,sha):
    require(digest(folder/'source-index.json')==sha,'closed parent index changed')
    index=read(folder/'source-index.json')
    require({str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()}==set(index['files'])|{'source-index.json'},'unexpected parent source inventory')
    for name,pin in index['files'].items():
        p=folder/name;require(not p.is_symlink() and p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'],'changed closed parent source '+name)
    return index

def configure():
    index=parent_index(PARENT,PARENT_INDEX)
    parent_index(ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2','fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb')
    parent_index(ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2','41797bbf9e25eb1836932307f66ad74f413714dd38cf1485e07cc8f2d74160d9')
    parent=load('observed_CMS_closed_plain',PARENT/'controller.py',index['files']['controller.py']['sha256'])
    b=parent.configure();b.HERE=HERE;b.ROOT=ROOT;b.WORK=ROOT/'.tirust-build/generic-owned-CMS-observer-qualification-work-1'
    b.CAPS={'build':1800.,'run':1800.};b.CLEANUP=60.;b.CPU=12;b.BOOTSTRAP_STARTED=START;b.__file__=str(Path(__file__).resolve())
    oldlocal=b.local
    def local(name):
        if name in ('observer_build','observer_run','observer_analysis','observer_render'):
            b.authenticate_source_index();pin=read(HERE/'source-index.json')['files'][name+'.py']
            return load('observed_CMS_'+name,HERE/(name+'.py'),pin['sha256'])
        return oldlocal(name)
    b.local=local
    def work_namespace():
        require(b.PHASE in ('build','run') and b.WORK==ROOT/'.tirust-build/generic-owned-CMS-observer-qualification-work-1','wrong observed namespace')
        require(not b.WORK.is_symlink() and b.WORK.resolve().is_relative_to(ROOT) and not (b.WORK/b.PHASE).is_symlink(),'unsafe observed namespace')
    b.work_namespace=work_namespace
    b.verify_build=lambda:local('observer_build').verified_build(b)
    def preflight(stage_created=False):
        b.verify_source();work_namespace();local('observer_build').verified_plain(b);local('observer_build').emission_contract(b)
        require(12 in __import__('os').sched_getaffinity(0),'CPU12 unavailable')
        if b.PHASE=='run':b.verify_build()
        if not stage_created:require(not (b.WORK/b.PHASE).exists(),'retained observed stage exists; no retry')
        return {'status':'source-only-preflight-passed','phase':b.PHASE,'compiler_queries':0,'loader_queries':0,'native_main_calls':0,
            'MLStabThres':1e-6,'runtime_card_sha256':digest(HERE/'cards/MadLoopParams.dat'),'plain_ELFs_retained':2,'observed_ELFs_to_build':2,
            'total_seconds':1800,'cleanup_seconds':60,'per_protocol_call_seconds':180,'CPU':12,'CPU_reserved':False,'resource_limits':b.LIMITS}
    b.preflight=preflight;b.build_locked=lambda directory:local('observer_build').build(b,directory)
    b.run_locked=lambda directory:local('observer_run').run(b,directory)
    return b
if __name__=='__main__':configure().main()
