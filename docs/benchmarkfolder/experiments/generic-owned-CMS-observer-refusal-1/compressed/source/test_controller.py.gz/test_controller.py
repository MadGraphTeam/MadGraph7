"""Pure observed compile-recipe and supervision contract checks."""
from pathlib import Path
import ast,hashlib,json,re,types,unittest
import observer_build as b
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
class ObserverController(unittest.TestCase):
    def test_actual_emission_has_exact_two_lanes_and_source_payloads(self):
        value=b.emission_contract(types.SimpleNamespace(HERE=HERE))
        self.assertEqual(set(value['lanes']),{'legacy','candidate'})
        self.assertEqual(len(value['lanes']['legacy']['files']),10)
        self.assertEqual(len(value['lanes']['candidate']['files']),11)
        for lane,row in value['lanes'].items():
            for name,pin in row['files'].items():
                raw=(HERE/'emittedsrc'/lane/name).read_bytes()
                self.assertEqual({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},pin)
    def test_actual_new_and_original_private_module_dependencies_are_ordered(self):
        origin=ROOT/'.tirust-build/generic-owned-CMS-plain-build-work-2/build/candidate'/b.SUB
        sources=[('observer.f90',HERE/'emittedsrc/candidate/observer.f90')]+[(n,origin/n) for n in b.MODULES]+[('observed_math.f90',HERE/'emittedsrc/candidate/observed_math.f90')]
        modules=[];dependencies=[]
        for name,path in sources:
            text=path.read_text();names=re.findall(r'^\s*module\s+([A-Za-z][A-Za-z0-9_]*)\s*$',text,re.M|re.I)
            self.assertEqual(len(names),1,name);modules.append(names[0].lower())
            dependencies.append([x.lower() for x in re.findall(r'^\s*use\s+([A-Za-z][A-Za-z0-9_]*)',text,re.M|re.I)])
        self.assertEqual(len(modules),len(set(modules)))
        seen=set()
        for module,deps in zip(modules,dependencies):
            self.assertLessEqual(set(deps)&set(modules),seen,module);seen.add(module)
    def test_regenerates_private_mods_before_changed_carrier_compile(self):
        text=(HERE/'observer_build.py').read_text()
        self.assertLess(text.index('fresh_module_sources(base,case,new_modules+regenerated,output)'),text.index('for name in module_order:'))
        self.assertLess(text.index('for name in module_order:'),text.index('for name in selected:b.command'))
        self.assertIn("target.unlink(missing_ok=True)",text)
    def test_make_info_literal_has_real_lines_and_tab(self):
        tree=ast.parse((HERE/'observer_build.py').read_text());values=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='write_text' and node.args and isinstance(node.args[0],ast.Constant):values.append(node.args[0].value)
        recipe=next(x for x in values if 'include makefile' in x)
        self.assertTrue(recipe.startswith('include makefile\n.PHONY:'))
        self.assertIn('\n\t@$(info FC',recipe);self.assertNotIn(chr(92)+'n',recipe)
    def test_unchanged_ELFs_and_full_card_policy_are_references(self):
        text=(HERE/'observer_build.py').read_text()
        self.assertIn('verified_plain(b)',text);self.assertIn('PLAIN_RUN_TERMINAL',text)
        self.assertIn("case/'check'",text)
        self.assertNotIn('chmod(',text)
        old=ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2/cards/MadLoopParams.dat'
        now=HERE/'cards/MadLoopParams.dat'
        self.assertEqual(now.read_bytes(),old.read_bytes().replace(b'#MLStabThres\n1.000000d-03\n',b'#MLStabThres\n1.000000d-06\n'))
        self.assertEqual(hashlib.sha256(now.read_bytes()).hexdigest(),'01db62b7a861aa832063c5216473aafb8adff0a44bffc2956fd7b684452093e0')
    def test_build_has_no_native_main_or_raw_subprocess_launcher(self):
        tree=ast.parse((HERE/'observer_build.py').read_text())
        imports=[n for node in tree.body if isinstance(node,ast.Import) for n in node.names]
        self.assertNotIn('subprocess',{n.name for n in imports})
        text=(HERE/'observer_build.py').read_text()
        self.assertIn('loader.prelink(',text);self.assertIn('loader.requireactualmap(',text)
        self.assertLess(text.index("pre['bound'].update(data['runtime'])"),text.index("b.command(link,"))
        self.assertLess(text.index('runtime.derive('),text.index('loader.query_runtime('))
    def test_shared_caps_and_separate_stages_stay_declared(self):
        text=(HERE/'controller.py').read_text()
        self.assertIn("b.CAPS={'build':1800.,'run':1800.}",text)
        self.assertIn('b.CLEANUP=60.;b.CPU=12',text)
        self.assertIn('no retry',text)
        self.assertIn("b.PHASE=='run':b.verify_build()",text)
