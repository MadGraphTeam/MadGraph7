! DORMANT SOURCE ONLY: no native/compiler/ABI/scientific qualification.
! Fixed CMS group3 journal. All data flow is FROM science TO this module.
! No point identifier, counter, stage or failure flag returns to science.
module ML5_0_CMS_OBSERVER
  implicit none
  private
  integer,parameter :: ik=selected_int_kind(33),i64=selected_int_kind(18)
  integer,parameter :: dp=kind(0.0d0),qp=selected_real_kind(33,4931)
  integer,parameter :: format_assert=1/merge(1,0,bit_size(0_ik)==128.and.bit_size(0_i64)==64.and. &
      bit_size(0)==32.and.storage_size(0.0_dp)==64.and.storage_size(0.0_qp)==128.and. &
      storage_size(cmplx(0.0_dp,0.0_dp,kind=dp))==128.and. &
      storage_size(cmplx(0.0_qp,0.0_qp,kind=qp))==256)
  integer,parameter :: maxf=128,maxp=4096,maxc=128,maxb=256,maxbytes=64*1024*1024
  integer(ik),parameter :: low64=int(z'FFFFFFFFFFFFFFFF',ik)
  type producer_record
    integer :: stage=0,width=0,h=0,leg=0,boundary=0
    logical :: ok=.false.,genuine=.false.,valid(4)=.false.,pv(4)=.false.
    integer(ik) :: ref(2,0:3,4)=0_ik,pending(2,0:3,4)=0_ik
  end type
  type consumer_record
    integer :: h=0,so=0,ctmode=0,boundary=0,last_commit(2,4)=0
    logical :: snapshot=.false.,genuine=.false.,okdp=.false.,okqp=.false.
    logical :: vdp(4)=.false.,vqp(4)=.false.
    integer(ik) :: rdp(2,0:3,4)=0_ik,rqp(2,0:3,4)=0_ik
    integer(ik) :: cdp(2,0:3,4)=0_ik,cqp(2,0:3,4)=0_ik
  end type
  type pair_record
    ! stage1 legacy,2/3 match attempt/pass,4 built,5/6 raw attempt/pass,
    ! 7/8 certify attempt/return,9/10 exact attempt/pass,11/12 final attempt/return,
    ! 13 direct assigned,14 pair complete. Non-reached is never false.
    logical :: stage(14)=.false.,mass_present=.false.,mass_snap=.false.
    logical :: cert_ok=.false.,final_ok=.false.,use_direct=.false.,env_present=.false.
    logical :: built_present=.false.,consumed_present=.false.
    integer(i64) :: env_before=0_i64,env_after=0_i64
    logical :: env_ok=.false.
    integer(ik) :: legacy(2)=0_ik,built_q(2,0:3)=0_ik,built_raw(2)=0_ik
    integer(ik) :: consumed_q(2,0:3)=0_ik,consumed_raw(2)=0_ik
    integer(ik) :: smat(2)=0_ik,direct=0_ik
  end type
  type frame_record
    integer :: width=0,group=0,consumer=0,boundary=0,refwidth=0,ctmode=0,rank=0,native_status=0
    logical :: legacy=.false.,ready=.false.,current_ok=.false.,genuine=.false.,mask(4)=.false.
    logical :: matrix_done=.false.,native_present(3)=.false.,native_returned=.false.
    logical :: check_pass=.false.,cache_enabled=.false.
    integer :: coeff(4,4,4)=0,classes(4,4)=0
    integer(ik) :: ref(2,0:3,4)=0_ik,current(2,0:3,4)=0_ik,ploop(4,0:3)=0_ik,masses(2,4)=0_ik
    integer(ik) :: native(4,4,3)=0_ik,shifts(0:3,4)=0_ik,scale=0_ik
    type(pair_record) :: pair(4,4)
  end type
  type(producer_record) :: producers(maxp)
  type(consumer_record) :: consumers(maxc)
  type(frame_record) :: frames(maxf)
  integer :: boundaries(maxb)=0,np=0,nc=0,nf=0,nb=0,cf=0,ci=0,cj=0,current_group=0
  integer :: seq=0,request=0,point_id=0,failed=0,last_commit(2,4)=0
  integer(i64) :: serialized=0_i64
  logical :: enabled=.false.,undrained=.false.,serialization_full=.false.
  public :: OBS_DISABLE,OBS_RESET_ENABLE,OBS_DISABLE_DRAIN,OBS_BOUNDARY,OBS_PRODUCER
  public :: OBS_CONTEXT,OBS_CONSUMER,OBS_GROUP,OBS_PAIR_BEGIN,OBS_MARK,OBS_MASS
  public :: OBS_CONSUMED,OBS_CERT_RETURN,OBS_FINAL_RETURN,OBS_MATRIX_DONE,OBS_NATIVE_RETURN
  public :: OBS_BEGIN_LEGACY_DP,OBS_BEGIN_LEGACY_QP,OBS_BEGIN_OWNED_DP,OBS_BEGIN_OWNED_QP
  public :: OBS_LEGACY_DP,OBS_LEGACY_QP,OBS_BUILT_DP,OBS_BUILT_QP,OBS_ENV
  public :: OBS_PAIR_END_DP,OBS_PAIR_END_QP,OBS_LEGACY_PAIR_END_DP,OBS_LEGACY_PAIR_END_QP
  public :: OBS_MATRIX_DP,OBS_MATRIX_QP,OBS_NATIVE_DP,OBS_NATIVE_QP
  public :: OBS_DRAIN_SUCCEEDED
contains
  subroutine fault(bit)
    integer,intent(in)::bit
    failed=ibset(failed,bit)
  end subroutine
  subroutine OBS_DISABLE()
    enabled=.false.
  end subroutine
  subroutine OBS_RESET_ENABLE(measurement,req,point)
    integer,intent(in)::measurement,req,point
    if(undrained)then
      call fault(0);enabled=.false.;return
    endif
    seq=measurement;request=req;point_id=point
    np=0;nc=0;nf=0;nb=0;cf=0;ci=0;cj=0;current_group=0
    failed=0;last_commit=0;serialized=0_i64;serialization_full=.false.
    enabled=.true.;undrained=.true.
  end subroutine
  subroutine OBS_BOUNDARY(code)
    integer,intent(in)::code
    if(.not.enabled)return
    if(nb==maxb)then
      call fault(1);return
    endif
    nb=nb+1;boundaries(nb)=code
  end subroutine
  subroutine OBS_PRODUCER(stage,width,h,leg,ok,reference,valid,pending,pending_valid,genuine)
    integer,intent(in)::stage,width,h,leg
    integer(ik),intent(in)::reference(2,0:3,4),pending(2,0:3,4)
    logical,intent(in)::ok,valid(4),pending_valid(4),genuine
    integer::kind_index
    if(.not.enabled)return
    if(np==maxp)then
      call fault(2);return
    endif
    if(stage<1.or.stage>3.or.(width/=64.and.width/=128).or.leg<1.or.leg>4)then
      call fault(3);return
    endif
    np=np+1;producers(np)=producer_record()
    producers(np)%stage=stage;producers(np)%width=width;producers(np)%h=h
    producers(np)%leg=leg;producers(np)%ok=ok;producers(np)%genuine=genuine
    producers(np)%ref=reference;producers(np)%pending=pending
    producers(np)%valid=valid;producers(np)%pv=pending_valid;producers(np)%boundary=nb
    if(stage==3.and.ok)then
      kind_index=1;if(width==128)kind_index=2
      last_commit(kind_index,leg)=np
    endif
  end subroutine
  subroutine OBS_CONTEXT(h,so,ctmode)
    integer,intent(in)::h,so,ctmode
    if(.not.enabled)return
    if(nc==maxc)then
      call fault(4);return
    endif
    nc=nc+1;consumers(nc)=consumer_record()
    consumers(nc)%h=h;consumers(nc)%so=so;consumers(nc)%ctmode=ctmode
    consumers(nc)%boundary=nb;consumers(nc)%last_commit=last_commit
  end subroutine
  subroutine OBS_CONSUMER(h,so,ctmode,rdp,vdp,rqp,vqp,cdp,cqp,okdp,okqp,genuine)
    integer,intent(in)::h,so,ctmode
    integer(ik),intent(in)::rdp(2,0:3,4),rqp(2,0:3,4),cdp(2,0:3,4),cqp(2,0:3,4)
    logical,intent(in)::vdp(4),vqp(4),okdp,okqp,genuine
    integer::old
    if(.not.enabled)return
    old=nc;call OBS_CONTEXT(h,so,ctmode)
    if(nc==old)return
    consumers(nc)%snapshot=.true.;consumers(nc)%rdp=rdp;consumers(nc)%rqp=rqp
    consumers(nc)%cdp=cdp;consumers(nc)%cqp=cqp;consumers(nc)%vdp=vdp;consumers(nc)%vqp=vqp
    consumers(nc)%okdp=okdp;consumers(nc)%okqp=okqp;consumers(nc)%genuine=genuine
  end subroutine
  subroutine OBS_GROUP(group)
    integer,intent(in)::group
    if(enabled)current_group=group
  end subroutine
  logical function begin_frame(width,n,legacy) result(ok)
    integer,intent(in)::width,n
    logical,intent(in)::legacy
    ok=.false.
    if(.not.enabled.or.current_group/=3)return
    if(cf/=0.or.n/=4.or.nc<1)then
      call fault(5);return
    endif
    if(nf==maxf)then
      call fault(6);return
    endif
    nf=nf+1;cf=nf;ci=0;cj=0;frames(cf)=frame_record()
    frames(cf)%width=width;frames(cf)%group=current_group;frames(cf)%consumer=nc
    frames(cf)%boundary=nb;frames(cf)%legacy=legacy;ok=.true.
  end function
  logical function pair_active() result(ok)
    ok=.false.
    if(.not.enabled.or.current_group/=3)return
    if(cf<1.or.ci<1.or.cj<1)then
      call fault(7);return
    endif
    ok=.true.
  end function
  subroutine OBS_PAIR_BEGIN(i,j)
    integer,intent(in)::i,j
    if(.not.enabled.or.current_group/=3)return
    if(cf<1.or.i<1.or.i>4.or.j<1.or.j>4)then
      call fault(7);return
    endif
    if(ci/=0.or.cj/=0.or.frames(cf)%pair(i,j)%stage(14))then
      call fault(8);return
    endif
    ci=i;cj=j
  end subroutine
  subroutine OBS_MARK(code)
    integer,intent(in)::code
    if(.not.pair_active())return
    if(code<1.or.code>14)then
      call fault(9);return
    endif
    if(frames(cf)%pair(ci,cj)%stage(code))then
      call fault(10);return
    endif
    frames(cf)%pair(ci,cj)%stage(code)=.true.
  end subroutine
  subroutine OBS_MASS(snap)
    logical,intent(in)::snap
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%mass_present)then
      call fault(10);return
    endif
    frames(cf)%pair(ci,cj)%mass_present=.true.;frames(cf)%pair(ci,cj)%mass_snap=snap
  end subroutine
  subroutine OBS_ENV(before,after,ok)
    integer(i64),intent(in)::before,after
    logical,intent(in)::ok
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%env_present)then
      call fault(10);return
    endif
    frames(cf)%pair(ci,cj)%env_present=.true.;frames(cf)%pair(ci,cj)%env_before=before
    frames(cf)%pair(ci,cj)%env_after=after;frames(cf)%pair(ci,cj)%env_ok=ok
  end subroutine
  subroutine OBS_CONSUMED(qwords,rawwords)
    integer(ik),intent(in)::qwords(2,0:3),rawwords(2)
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%consumed_present)then
      call fault(10);return
    endif
    frames(cf)%pair(ci,cj)%consumed_present=.true.
    frames(cf)%pair(ci,cj)%consumed_q=qwords;frames(cf)%pair(ci,cj)%consumed_raw=rawwords
  end subroutine
  subroutine OBS_CERT_RETURN(ok)
    logical,intent(in)::ok
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%stage(8))then
      call fault(10);return
    endif
    call OBS_MARK(8);frames(cf)%pair(ci,cj)%cert_ok=ok
  end subroutine
  subroutine OBS_FINAL_RETURN(ok)
    logical,intent(in)::ok
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%stage(12))then
      call fault(10);return
    endif
    call OBS_MARK(12);frames(cf)%pair(ci,cj)%final_ok=ok
  end subroutine
  subroutine OBS_MATRIX_DONE()
    integer::i,j
    if(.not.enabled.or.current_group/=3)return
    if(cf<1.or.ci/=0.or.cj/=0)then
      call fault(11);return
    endif
    do j=1,4
      do i=1,4
        if(.not.frames(cf)%pair(i,j)%stage(14))call fault(11)
      enddo
    enddo
    frames(cf)%matrix_done=.true.
  end subroutine
  subroutine OBS_NATIVE_RETURN(status)
    integer,intent(in)::status
    if(.not.enabled.or.current_group/=3)return
    if(cf<1)then
      call fault(12);return
    endif
    frames(cf)%native_status=status;frames(cf)%native_returned=.true.
    cf=0;ci=0;cj=0
  end subroutine

  pure function scalar_dp(value) result(word)
    real(dp),intent(in)::value
    integer(ik)::word
    word=iand(int(transfer(value,0_i64),ik),low64)
  end function
  pure function complex_dp(value) result(words)
    complex(dp),intent(in)::value
    integer(ik)::words(2)
    words=iand(int(transfer(value,[0_i64,0_i64]),ik),low64)
  end function
  subroutine OBS_BEGIN_LEGACY_DP(n,p,m)
    integer,intent(in)::n
    real(dp),intent(in)::p(:,0:)
    complex(dp),intent(in)::m(:)
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(size(p,1)/=4.or.size(p,2)/=4.or.size(m)/=4)then
      call fault(13);return
    endif
    if(.not.begin_frame(64,n,.true.))return
    do i=1,4
      frames(cf)%masses(:,i)=complex_dp(m(i))
      do mu=0,3
        frames(cf)%ploop(i,mu)=scalar_dp(p(i,mu))
      enddo
    enddo
  end subroutine
  subroutine OBS_BEGIN_OWNED_DP(n,next,p,m,rwidth,reference,current,mask,coeff,classes,ready,current_ok,genuine)
    integer,intent(in)::n,next,rwidth,coeff(:,:,:),classes(:,:)
    real(dp),intent(in)::p(:,0:)
    complex(dp),intent(in)::m(:)
    integer(ik),intent(in)::reference(:,0:,:),current(:,0:,:)
    logical,intent(in)::mask(:),ready,current_ok,genuine
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(next/=4.or.any(shape(reference)/=[2,4,4]).or.any(shape(current)/=[2,4,4]).or.size(mask)/=4)then
      call fault(13);return
    endif
    if(any(shape(coeff)/=[4,4,4]).or.any(shape(classes)/=[4,4]))then
      call fault(13);return
    endif
    if(size(p,1)/=4.or.size(p,2)/=4.or.size(m)/=4)then
      call fault(13);return
    endif
    if(.not.begin_frame(64,n,.false.))return
    frames(cf)%refwidth=rwidth;frames(cf)%ref=reference;frames(cf)%current=current
    frames(cf)%mask=mask;frames(cf)%coeff=coeff;frames(cf)%classes=classes
    frames(cf)%ready=ready;frames(cf)%current_ok=current_ok;frames(cf)%genuine=genuine
    do i=1,4
      frames(cf)%masses(:,i)=complex_dp(m(i))
      do mu=0,3
        frames(cf)%ploop(i,mu)=scalar_dp(p(i,mu))
      enddo
    enddo
  end subroutine
  subroutine OBS_LEGACY_DP(value)
    complex(dp),intent(in)::value
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%stage(1))then
      call fault(10);return
    endif
    call OBS_MARK(1);frames(cf)%pair(ci,cj)%legacy=complex_dp(value)
  end subroutine
  subroutine OBS_BUILT_DP(q,raw)
    complex(dp),intent(in)::q(0:3),raw
    integer::mu
    if(.not.pair_active())return
    if(.not.frames(cf)%pair(ci,cj)%stage(4).or.frames(cf)%pair(ci,cj)%built_present)then
      call fault(14);return
    endif
    do mu=0,3
      frames(cf)%pair(ci,cj)%built_q(:,mu)=complex_dp(q(mu))
    enddo
    frames(cf)%pair(ci,cj)%built_raw=complex_dp(raw)
    frames(cf)%pair(ci,cj)%built_present=.true.
  end subroutine
  subroutine OBS_PAIR_END_DP(smat,use_direct,direct)
    complex(dp),intent(in)::smat
    real(dp),intent(in)::direct
    logical,intent(in)::use_direct
    if(.not.pair_active())return
    frames(cf)%pair(ci,cj)%smat=complex_dp(smat)
    frames(cf)%pair(ci,cj)%use_direct=use_direct
    if(use_direct)frames(cf)%pair(ci,cj)%direct=scalar_dp(direct)
    call OBS_MARK(14);ci=0;cj=0
  end subroutine
  subroutine OBS_LEGACY_PAIR_END_DP(smat)
    complex(dp),intent(in)::smat
    if(.not.pair_active())return
    frames(cf)%pair(ci,cj)%smat=complex_dp(smat)
    call OBS_MARK(14);ci=0;cj=0
  end subroutine
  subroutine OBS_MATRIX_DP(stage,values)
    integer,intent(in)::stage
    real(dp),intent(in)::values(:,:)
    integer::i,j
    if(.not.enabled.or.current_group/=3)return
    if(cf<1.or.stage<1.or.stage>3)then
      call fault(15);return
    endif
    if(any(shape(values)/=[4,4]))then
      call fault(13);return
    endif
    if(frames(cf)%native_present(stage))then
      call fault(10);return
    endif
    do j=1,4
      do i=1,4
        frames(cf)%native(i,j,stage)=scalar_dp(values(i,j))
      enddo
    enddo
    frames(cf)%native_present(stage)=.true.
  end subroutine
  subroutine OBS_NATIVE_DP(values,shifts,masses,scale,check_pass,cache_enabled,ctmode,rank)
    real(dp),intent(in)::values(:,:),shifts(0:,:),scale
    complex(dp),intent(in)::masses(:)
    logical,intent(in)::check_pass,cache_enabled
    integer,intent(in)::ctmode,rank
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(cf<1)then
      call fault(15);return
    endif
    if(any(shape(shifts)/=[4,4]).or.size(masses)/=4)then
      call fault(13);return
    endif
    if(frames(cf)%native_present(3))then
      call fault(10);return
    endif
    call OBS_MATRIX_DP(3,values)
    frames(cf)%ctmode=ctmode;frames(cf)%rank=rank
    frames(cf)%check_pass=check_pass;frames(cf)%cache_enabled=cache_enabled
    frames(cf)%scale=scalar_dp(scale)
    do i=1,4
      frames(cf)%masses(:,i)=complex_dp(masses(i))
      do mu=0,3
        frames(cf)%shifts(mu,i)=scalar_dp(shifts(mu,i))
      enddo
    enddo
  end subroutine
  pure function scalar_qp(value) result(word)
    real(qp),intent(in)::value
    integer(ik)::word
    word=transfer(value,0_ik)
  end function
  pure function complex_qp(value) result(words)
    complex(qp),intent(in)::value
    integer(ik)::words(2)
    words=transfer(value,[0_ik,0_ik])
  end function
  subroutine OBS_BEGIN_LEGACY_QP(n,p,m)
    integer,intent(in)::n
    real(qp),intent(in)::p(:,0:)
    complex(qp),intent(in)::m(:)
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(size(p,1)/=4.or.size(p,2)/=4.or.size(m)/=4)then
      call fault(13);return
    endif
    if(.not.begin_frame(128,n,.true.))return
    do i=1,4
      frames(cf)%masses(:,i)=complex_qp(m(i))
      do mu=0,3
        frames(cf)%ploop(i,mu)=scalar_qp(p(i,mu))
      enddo
    enddo
  end subroutine
  subroutine OBS_BEGIN_OWNED_QP(n,next,p,m,rwidth,reference,current,mask,coeff,classes,ready,current_ok,genuine)
    integer,intent(in)::n,next,rwidth,coeff(:,:,:),classes(:,:)
    real(qp),intent(in)::p(:,0:)
    complex(qp),intent(in)::m(:)
    integer(ik),intent(in)::reference(:,0:,:),current(:,0:,:)
    logical,intent(in)::mask(:),ready,current_ok,genuine
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(next/=4.or.any(shape(reference)/=[2,4,4]).or.any(shape(current)/=[2,4,4]).or.size(mask)/=4)then
      call fault(13);return
    endif
    if(any(shape(coeff)/=[4,4,4]).or.any(shape(classes)/=[4,4]))then
      call fault(13);return
    endif
    if(size(p,1)/=4.or.size(p,2)/=4.or.size(m)/=4)then
      call fault(13);return
    endif
    if(.not.begin_frame(128,n,.false.))return
    frames(cf)%refwidth=rwidth;frames(cf)%ref=reference;frames(cf)%current=current
    frames(cf)%mask=mask;frames(cf)%coeff=coeff;frames(cf)%classes=classes
    frames(cf)%ready=ready;frames(cf)%current_ok=current_ok;frames(cf)%genuine=genuine
    do i=1,4
      frames(cf)%masses(:,i)=complex_qp(m(i))
      do mu=0,3
        frames(cf)%ploop(i,mu)=scalar_qp(p(i,mu))
      enddo
    enddo
  end subroutine
  subroutine OBS_LEGACY_QP(value)
    complex(qp),intent(in)::value
    if(.not.pair_active())return
    if(frames(cf)%pair(ci,cj)%stage(1))then
      call fault(10);return
    endif
    call OBS_MARK(1);frames(cf)%pair(ci,cj)%legacy=complex_qp(value)
  end subroutine
  subroutine OBS_BUILT_QP(q,raw)
    complex(qp),intent(in)::q(0:3),raw
    integer::mu
    if(.not.pair_active())return
    if(.not.frames(cf)%pair(ci,cj)%stage(4).or.frames(cf)%pair(ci,cj)%built_present)then
      call fault(14);return
    endif
    do mu=0,3
      frames(cf)%pair(ci,cj)%built_q(:,mu)=complex_qp(q(mu))
    enddo
    frames(cf)%pair(ci,cj)%built_raw=complex_qp(raw)
    frames(cf)%pair(ci,cj)%built_present=.true.
  end subroutine
  subroutine OBS_PAIR_END_QP(smat,use_direct,direct)
    complex(qp),intent(in)::smat
    real(qp),intent(in)::direct
    logical,intent(in)::use_direct
    if(.not.pair_active())return
    frames(cf)%pair(ci,cj)%smat=complex_qp(smat)
    frames(cf)%pair(ci,cj)%use_direct=use_direct
    if(use_direct)frames(cf)%pair(ci,cj)%direct=scalar_qp(direct)
    call OBS_MARK(14);ci=0;cj=0
  end subroutine
  subroutine OBS_LEGACY_PAIR_END_QP(smat)
    complex(qp),intent(in)::smat
    if(.not.pair_active())return
    frames(cf)%pair(ci,cj)%smat=complex_qp(smat)
    call OBS_MARK(14);ci=0;cj=0
  end subroutine
  subroutine OBS_MATRIX_QP(stage,values)
    integer,intent(in)::stage
    real(qp),intent(in)::values(:,:)
    integer::i,j
    if(.not.enabled.or.current_group/=3)return
    if(cf<1.or.stage<1.or.stage>3)then
      call fault(15);return
    endif
    if(any(shape(values)/=[4,4]))then
      call fault(13);return
    endif
    if(frames(cf)%native_present(stage))then
      call fault(10);return
    endif
    do j=1,4
      do i=1,4
        frames(cf)%native(i,j,stage)=scalar_qp(values(i,j))
      enddo
    enddo
    frames(cf)%native_present(stage)=.true.
  end subroutine
  subroutine OBS_NATIVE_QP(values,shifts,masses,scale,check_pass,cache_enabled,ctmode,rank)
    real(qp),intent(in)::values(:,:),shifts(0:,:),scale
    complex(qp),intent(in)::masses(:)
    logical,intent(in)::check_pass,cache_enabled
    integer,intent(in)::ctmode,rank
    integer::i,mu
    if(.not.enabled.or.current_group/=3)return
    if(cf<1)then
      call fault(15);return
    endif
    if(any(shape(shifts)/=[4,4]).or.size(masses)/=4)then
      call fault(13);return
    endif
    if(frames(cf)%native_present(3))then
      call fault(10);return
    endif
    call OBS_MATRIX_QP(3,values)
    frames(cf)%ctmode=ctmode;frames(cf)%rank=rank
    frames(cf)%check_pass=check_pass;frames(cf)%cache_enabled=cache_enabled
    frames(cf)%scale=scalar_qp(scale)
    do i=1,4
      frames(cf)%masses(:,i)=complex_qp(masses(i))
      do mu=0,3
        frames(cf)%shifts(mu,i)=scalar_qp(shifts(mu,i))
      enddo
    enddo
  end subroutine
  subroutine emit(lun,line)
    integer,intent(in)::lun
    character(*),intent(in)::line
    integer::ios
    if(serialization_full)return
    if(serialized+len_trim(line)+1>maxbytes-4096)then
      call fault(16);serialization_full=.true.;return
    endif
    write(lun,'(A)',iostat=ios)trim(line)
    if(ios/=0)call fault(17)
    serialized=serialized+len_trim(line)+1
  end subroutine
  subroutine ints(lun,tag,values)
    integer,intent(in)::lun,values(:)
    character(*),intent(in)::tag
    character(4096)::line
    write(line,'(A,*(1X,I0))')tag,values
    call emit(lun,line)
  end subroutine
  subroutine words(lun,tag,keys,values)
    integer,intent(in)::lun,keys(:)
    integer(ik),intent(in)::values(:)
    character(*),intent(in)::tag
    character(2048)::left,right
    write(left,'(A,*(1X,I0))')tag,keys
    write(right,'(*(1X,Z32.32))')values
    call emit(lun,trim(left)//trim(right))
  end subroutine
  subroutine OBS_DISABLE_DRAIN(lun)
    integer,intent(in)::lun
    integer::p,c,f,i,j,leg,mu,stage,bits,k,ios
    character(4096)::line
    enabled=.false.
    if(.not.undrained)call fault(18)
    if(cf/=0.or.ci/=0.or.cj/=0)call fault(11)
    call ints(lun,'OBS_BEGIN',[seq,request,point_id,failed,np,nc,nf,nb])
    do k=1,nb
      call ints(lun,'OBS_BOUNDARY',[k,boundaries(k)])
    enddo
    do p=1,np
      associate(r=>producers(p))
        call ints(lun,'OBS_PRODUCER',[p,r%stage,r%width,r%h,r%leg,r%boundary,merge(1,0,r%ok), &
            merge(1,0,r%genuine),merge(1,0,r%valid),merge(1,0,r%pv)])
        do leg=1,4
          do mu=0,3
            call words(lun,'OBS_PREF',[p,leg,mu],r%ref(:,mu,leg))
            call words(lun,'OBS_PENDING',[p,leg,mu],r%pending(:,mu,leg))
          enddo
        enddo
      end associate
    enddo
    do c=1,nc
      associate(r=>consumers(c))
        call ints(lun,'OBS_CONSUMER',[c,r%h,r%so,r%ctmode,r%boundary,merge(1,0,r%snapshot), &
            merge(1,0,r%genuine),merge(1,0,r%okdp),merge(1,0,r%okqp),merge(1,0,r%vdp),merge(1,0,r%vqp)])
        do leg=1,4
          call ints(lun,'OBS_COMMIT_JOIN',[c,leg,r%last_commit(:,leg)])
          if(.not.r%snapshot)cycle
          do mu=0,3
            call words(lun,'OBS_CREF_DP',[c,leg,mu],r%rdp(:,mu,leg))
            call words(lun,'OBS_CREF_QP',[c,leg,mu],r%rqp(:,mu,leg))
            call words(lun,'OBS_CURRENT_DP',[c,leg,mu],r%cdp(:,mu,leg))
            call words(lun,'OBS_CURRENT_QP',[c,leg,mu],r%cqp(:,mu,leg))
          enddo
        enddo
      end associate
    enddo
    do f=1,nf
      associate(r=>frames(f))
        if(.not.r%matrix_done.or..not.r%native_returned.or..not.all(r%native_present))call fault(11)
        call ints(lun,'OBS_FRAME',[f,r%group,r%width,r%consumer,r%boundary,r%refwidth,r%ctmode,r%rank, &
            merge(1,0,r%legacy),merge(1,0,r%ready),merge(1,0,r%current_ok),merge(1,0,r%genuine), &
            merge(1,0,r%mask),merge(1,0,r%native_present),r%native_status,merge(1,0,r%check_pass), &
            merge(1,0,r%cache_enabled),merge(1,0,r%matrix_done),merge(1,0,r%native_returned)])
        do leg=1,4
          do mu=0,3
            call words(lun,'OBS_FRAME_REF',[f,leg,mu],r%ref(:,mu,leg))
            call words(lun,'OBS_FRAME_CURRENT',[f,leg,mu],r%current(:,mu,leg))
            call words(lun,'OBS_PLOOP',[f,leg,mu],[r%ploop(leg,mu)])
            call words(lun,'OBS_SHIFT',[f,leg,mu],[r%shifts(mu,leg)])
          enddo
          call words(lun,'OBS_MASS',[f,leg],r%masses(:,leg))
        enddo
        call words(lun,'OBS_SCALE',[f],[r%scale])
        do j=1,4
          do i=1,4
            associate(a=>r%pair(i,j))
              bits=0
              do stage=1,14
                if(a%stage(stage))bits=ibset(bits,stage-1)
              enddo
              call ints(lun,'OBS_PAIR',[f,i,j,r%classes(i,j),r%coeff(:,i,j),bits, &
                  merge(1,0,a%mass_present),merge(1,0,a%mass_snap),merge(1,0,a%cert_ok), &
                  merge(1,0,a%final_ok),merge(1,0,a%use_direct),merge(1,0,a%env_present), &
                  merge(1,0,a%env_ok),merge(1,0,a%built_present),merge(1,0,a%consumed_present)])
              if(a%stage(1))call words(lun,'OBS_ORIGINAL_RAW',[f,i,j],a%legacy)
              if(a%env_present)call words(lun,'OBS_ENV',[f,i,j], &
                  [iand(int(a%env_before,ik),low64),iand(int(a%env_after,ik),low64)])
              do mu=0,3
                if(a%built_present)call words(lun,'OBS_BUILT_Q',[f,i,j,mu],a%built_q(:,mu))
                if(a%consumed_present)call words(lun,'OBS_CONSUMED_Q',[f,i,j,mu],a%consumed_q(:,mu))
              enddo
              if(a%built_present)call words(lun,'OBS_BUILT_RAW',[f,i,j],a%built_raw)
              if(a%consumed_present)call words(lun,'OBS_CONSUMED_RAW',[f,i,j],a%consumed_raw)
              if(a%stage(14))call words(lun,'OBS_SMAT',[f,i,j],a%smat)
              if(a%stage(13))call words(lun,'OBS_DIRECT',[f,i,j],[a%direct])
              do stage=1,3
                if(r%native_present(stage))call words(lun,'OBS_NATIVE',[f,stage,i,j],[r%native(i,j,stage)])
              enddo
            end associate
          enddo
        enddo
      end associate
    enddo
    ! Reserved4096 bytes ensure the terminal failure record fits the byte cap.
    write(line,'(A,*(1X,I0))')'OBS_END',seq,failed,np,nc,nf,nb,serialized
    write(lun,'(A)',iostat=ios)trim(line)
    if(ios/=0)call fault(17)
    flush(lun,iostat=ios)
    if(ios/=0)call fault(17)
    ! Failed evidence stays undrained, so a later reset cannot erase it.
    undrained=(failed/=0);cf=0;ci=0;cj=0
  end subroutine

  logical function OBS_DRAIN_SUCCEEDED() result(ok)
    ok=.not.enabled.and..not.undrained.and.failed==0
  end function OBS_DRAIN_SUCCEEDED
end module ML5_0_CMS_OBSERVER
