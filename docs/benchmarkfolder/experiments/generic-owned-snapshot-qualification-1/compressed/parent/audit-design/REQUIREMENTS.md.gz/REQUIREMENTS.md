# Dormant snapshot transport unit: source-read requirements

This document prepares no executable and authorizes no compiler, native driver,
ABI controller, scientific call, generation, or production edit. The frozen
snapshot-source-1 and CMS composite packets are unchanged. Source inspection
finds a small standalone lane feasible, subject to the limits below.

The unit should link only the exact frozen `owned_snapshots.f90`, a private
Fortran driver, and the existing qualification-only C environment observer.
No ALOHA object, external wavefunction constructor, model, geometry/certificate
helper, numerator, reducer, or amplitude is needed. Exercise only the six public
reset/prepare/commit routines with their module-provided explicit interfaces.
The module has source format assertions for INTEGER64/128 and IEEE binary64/128;
no actual compiler format/ABI observation exists for this module yet.

Use separate caller-owned DP and QP contexts with disjoint reference/pending
arrays `(2,0:3,2)` and separate two-element masks. Distinct integer objects must
also separate reference from pending within each precision. The driver should
demonstrate that operations on one precision/leg leave the other untouched.
No aliased INTENT(INOUT) argument experiment can establish safe behavior under
Fortran's argument-association rules.

## Raw-word transport and test interval

Read native-width integer hex fixtures directly into matching INTEGER64
(`Z16`) or INTEGER128 (`Z32`) carriers, without an overflowing narrowing INT
conversion from an unsigned128 representation. Allocate/initialize fixed storage
outside the altered environment. Inside each cohort, construct DP columns by
matching-size scalar INTEGER64-to-REAL(DP) TRANSFER and QP columns by scalar
INTEGER128-to-REAL(QP) TRANSFER. Do not replace these with REAL conversion,
DP-to-QP widening, floating literals representing fixtures, negation, complex
construction, floating comparisons, or arithmetic. Loading and passing a
signaling NaN is itself a compiler/lowering question to be tested; moving these
operations outside the cohort would hide part of the requested transport check.

Snapshot all public operation outcomes using integer/logical assignment only.
Echo every raw input and each observed reference/pending word, mask and OK value
after restoring and observing the original environment. Use integer/hex output;
no formatted Fortran I/O, decimal conversion, runtime error reporting, or FP
output may occur in the active test interval. A trapping signal, unexpected
flag/control change, or malformed/partial transcript is a retained failure.

Reuse the exact existing observer's twenty cohorts and observed fields:

| Modes | Requested environment |
| --- | --- |
| 0 | Untouched original-state control |
| 1–4 | Nearest, downward, upward, toward zero |
| 5–9 | Each of invalid, divide-by-zero, overflow, underflow, inexact sticky |
| 10 | Union of the five sticky flags |
| 11–15 | Each corresponding enabled halt mask, with no pending flags |
| 16–18 | FTZ only, DAZ only, both |
| 19 | Union of the five enabled halt masks, with no pending flags |

Its C save/setup/observe/restore boundary records rounding, sticky flags,
enabled halts, MXCSR controls/raw word, and x87 control/status. It masks all six
hardware exception classes before clearing, never unmasks pending flags, and
restores before normal I/O. Retain its integer-only raw-write/_exit failure
path before any Fortran reporting if restoration is not observed. Only optional
FTZ/DAZ modes may be explicitly unsupported; that does not qualify them. Every
other setup/observe/restore failure fails the lane. Passing these seven fields
does not prove preservation of unobserved floating registers or platform ABIs.

## Small useful corpus and operation script

A two-leg operation script can cover the common protocol without a model:

* Prepare finite vectors containing +0, −0, minimum signed subnormals, maximum
  finite values, ±1 and minimum normal values. Include QP +1 and its next
  representable value to distinguish the 113th significant bit. Before commit,
  validity must remain false and only complete pending storage may publish.
  After commit, the reference words must equal the native input words exactly,
  DP words must have zero high64 bits, imaginary channels must be integer zero,
  and pending storage/mask must be cleared.
* Stage and commit different legs independently. Re-prepare a valid leg,
  prepare without commit, commit without prepare, double commit, and reset
  between prepare and commit. Record every state transition rather than only a
  final checksum. A missing commit models a skipped constructor; it does not
  execute or qualify an actual generated cache guard/constructor.
* Put ±infinity, quiet NaN and signaling NaN in the final component after three
  finite components. Prepare must refuse without partial pending/reference
  publication. Observe exception state and trap outcome around the complete
  transfer/prepare path.
* Apply false genuine-QP during prepare and commit after previously valid or
  staged QP state. Both must invalidate the entire supplied QP context and
  leave the separate DP context untouched.
* If shape/refusal coverage is claimed, explicitly exercise actual Fortran
  size/stride descriptors and invalid leg/count boundaries. Record the exact
  passed sections and observed compiler behavior. Corrupt pending integer words
  separately to test nonfinite/imaginary/DP-high-bit commit guards; a REAL(DP)
  input cannot carry forbidden high64 bits, so do not label that corruption as
  a native DP input refusal.

The independent oracle should compute expected words/masks using integers only.
Two standalone build variants (checked O0, strict O3 module with checked O0
driver) can reuse the existing bounded standalone tool/link/runtime ownership
pattern. Build and run remain separate future admissions; preparation does not
start either stage or borrow a successful mathematical-helper run as proof.

## Essential scope limits

The module buffers have **no runtime precision tag**. A DP prepare followed by
QP commit with `genuine_qp=.TRUE.` on the same buffers can accept the low64 DP
payload as a finite binary128 subnormal. Conversely, a QP minimum subnormal
raw word 1 can pass DP commit. These are expected misuse controls if included,
not expected refusals or evidence of genuine QP. Separate storage and matching
named APIs are source-level caller obligations. Python `SnapshotState.width`
enforces a stronger type discipline than the bare integer Fortran storage.

Prepare also cannot identify the canonical source P column, its originating
lower bound, an expression temporary, current point/helicity, or a genuine
constructor return. It observes only values, sizes, contiguity and the supplied
QP Boolean. Python `ColumnView` provenance/width/lower-bound refusals must not be
reported as observed checks of this Fortran API. Commit validates finite staged
words, not their authorship. The standalone driver supplies canonical-shaped
columns and calls commit directly; that proves neither generated caller wiring
nor normal constructor completion.

Even a completely passing native unit would qualify only the exact standalone
transport/protocol calls, executed compiler variants, and observed environments.
It would not qualify source ownership/current-point lifetime, genuine QP
integrand construction, ALOHA signs or constructors, composite route selection,
geometry/final-dot arithmetic, amplitude accuracy, runtime performance, a full
build recipe, scientific dispatch, or the broader integration goal.
