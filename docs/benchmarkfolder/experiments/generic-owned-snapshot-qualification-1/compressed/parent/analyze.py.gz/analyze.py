"""Pure strict replay of dormant snapshot-unit hex/state/fenv observations."""
import re


def need(value,reason):
    if not value:raise ValueError(reason)


def request_for(mode,constants):
    if mode==0:return [-1]*5
    rounds=constants[:4];flags=constants[4:9]
    rounding=rounds[mode-1] if 1<=mode<=4 else rounds[0]
    sticky=flags[mode-5] if 5<=mode<=9 else constants[9] if mode==10 else 0
    halts=flags[mode-11] if 11<=mode<=15 else constants[9] if mode==19 else 0
    ftz,daz={16:(1,0),17:(0,1),18:(1,1)}.get(mode,(-1,-1))
    return [rounding,sticky,halts,ftz,daz]


def analyze(text,expected):
    records=[line.split() for line in text.splitlines() if line.strip()];cursor=0
    def take(tag,length=None):
        nonlocal cursor
        need(cursor<len(records),'truncated observation before '+tag)
        row=records[cursor];cursor+=1
        need(row[0]==tag and (length is None or len(row)==length),'unexpected observation record '+tag)
        return row[1:]
    need(take('SCHEMA',2)==['owned-snapshot-fenv-v1'],'wrong unit observation schema')
    constants=list(map(int,take('CONSTANTS',11)))
    need(constants==[0,1024,2048,3072,1,4,8,16,32,61],'unsupported pinned GNU/x86_64 constants')
    count=int(take('NCASES',2)[0]);modes=int(take('MODES',2)[0])
    need(count==expected['case_count'] and modes==expected['mode_count']==20,'wrong case/cohort coverage')
    need(take('SNAPSHOT_FIELDS')==['round','sticky','halts','mxcsr_control','x87cw','mxcsr_raw','x87sw'],'wrong fenv layout')
    need(take('CASE_FIELDS')==['id','mode','scenario','status','observe_before','observe_after','restore_ok',
        'requests(5)','baseline(7)','before(7)','after(7)','restored(7)'],'wrong cohort record layout')
    need(take('STATUS_FIELDS')==['id','mode','ncall','returned_ok(1:ncall)'],'wrong status record layout')
    need(take('MASK_FIELDS')==['id','mode','width','valid(1:2)','pending_valid(1:2)'],'wrong mask record layout')
    need(take('WORD_FIELDS')==['id','mode','width','leg','component','real_word','imaginary_word'],'wrong word layout')
    observations=0;calls=0;state_words=0
    for identifier in range(1,count+1):
        row=expected['cases'][str(identifier)];scenario=row['scenario']
        for mode in range(20):
            if mode==0:
                need(list(map(int,take('INPUT',3)))==[identifier,scenario],'wrong input case identity')
                for mu in range(4):
                    for tag,key,digits in (('DPWORD','dp_words',16),('QPWORD','qp_words',32)):
                        value=take(tag,4)
                        need(list(map(int,value[:2]))==[identifier,mu],'wrong raw input echo ordering')
                        need(re.fullmatch('[0-9A-Fa-f]{'+str(digits)+'}',value[2]) is not None and
                             value[2].upper()==row[key][mu],'raw native input echo differs from frozen fixture')
            values=list(map(int,take('CASE',41)))
            need(values[:3]==[identifier,mode,scenario],'wrong cohort identity or order')
            status,observed_before,observed_after,restore_ok=values[3:7]
            request=values[7:12];baseline=values[12:19];before=values[19:26];after=values[26:33];restored=values[33:40]
            need(status==0,'mandatory cohort did not execute; SKIP/failure cannot qualify transport')
            need(observed_before==observed_after==0,'environment observation failed')
            need(restore_ok==1 and restored==baseline,'environment restoration failed')
            need(before==after,'snapshot transport changed environment/sticky status')
            need(request==request_for(mode,constants),'requested environment differs from cohort')
            for snapshot in (baseline,before,after,restored):
                rounding,sticky,halts,control,cw,csr,sw=snapshot
                need(rounding in constants[:4] and sticky&~61==0 and halts&~61==0 and sticky>=0 and halts>=0,
                     'malformed environment API fields')
                need(0<=csr<2**32 and 0<=cw<2**16 and 0<=sw<2**16 and control==(csr&~63),
                     'malformed hardware environment fields')
                need(sticky==((csr|sw)&61),'API/hardware sticky fields disagree')
                need(cw&0x0c00==rounding and (csr>>3)&0x0c00==rounding,
                     'API/x87/SSE rounding fields disagree')
                need((~cw)&61==halts and (~(csr>>7))&61==halts,
                     'API/x87/SSE halting fields disagree')
            if mode==0:need(before==baseline,'untouched control cohort changed environment')
            else:
                need(before[:3]==request[:3],'observed environment differs from request')
                need(before[4]&0x0c00==request[0] and (before[5]>>3)&0x0c00==request[0],'x87/SSE rounding mismatch')
                need((~before[4])&61==request[2] and (~(before[5]>>7))&61==request[2],'x87/SSE halting mismatch')
                if request[3]>=0:
                    need((before[5]>>15)&1==request[3] and (before[5]>>6)&1==request[4],'FTZ/DAZ mismatch')
            statuses=list(map(int,take('STATUS')))
            want=row['expected']['status']
            need(statuses==[identifier,mode,len(want),*want],'native module-call statuses differ from independent expectations')
            for width,key in ((64,'dp'),(128,'qp')):
                masks=list(map(int,take('MASK',8)))
                state=row['expected'][key]
                need(masks==[identifier,mode,width,*state['valid'],*state['pending_valid']],'native validity masks differ')
            for leg in range(1,3):
                for mu in range(4):
                    for width,key in ((64,'dp'),(128,'qp')):
                        for tag,field in (('REF','reference'),('PENDING','pending')):
                            value=take(tag,8)
                            need(list(map(int,value[:5]))==[identifier,mode,width,leg,mu],'native state ordering differs')
                            words=value[5:]
                            need(all(re.fullmatch('[0-9A-Fa-f]{32}',word) is not None for word in words),'malformed INTEGER128 output')
                            need([word.upper() for word in words]==row['expected'][key][field][leg-1][mu],
                                 'native state word differs: '+str((identifier,mode,width,leg,mu,field)))
                            state_words+=2
            observations+=1;calls+=len(want)
    need(take('DONE',2)==[str(count)] and cursor==len(records),'incomplete/extra unit observations')
    return dict(status='pass',analysis_only=True,case_count=count,cohorts=20,observations=observations,
        module_calls=calls,complete_integer_state_words=state_words,execution_authorization_checked=False,
        native_snapshot_transport_qualified=False,canonical_column_origin_qualified=False,
        actual_constructor_completion_qualified=False,q_at_use_lowering_qualified=False,
        final_dot_runtime_qualified=False,full_caller_qualified=False,scientific_dispatch_enabled=False)
