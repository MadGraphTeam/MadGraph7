# Dormant standalone owned-snapshot qualification

This small source proposal prepares qualification of the **unchanged**
`owned_snapshots.f90` module. No compiler, loader or native program has run.
BUILD and RUN are separate, unadmitted JSON plans. The future unit links only
that module, the private 271-line Fortran driver and the existing byte-identical
20-cohort environment observer. It contains no ALOHA, constructor, reducer,
geometry/equality helper, certificate, amplitude, q or dot-product call.

The corpus has 37 raw-word cases covering 27 bounded scenarios. DP input is read
directly into matching signed INTEGER64 carriers using Z16; QP uses INTEGER128
and Z32. Matching-width scalar TRANSFER into real columns runs inside each test
cohort, followed by the actual module calls. This exercises the module's DP
zero extension and complete 128-bit QP transport without real conversion or
arithmetic. Values include signed zero, subnormals, minimal normal values,
maximal finite values, low 113th-bit QP information, infinities and NaNs.
Nonfinite columns are expected to be refused atomically, without a trap or an
environment change; nonfinite payload preservation is not an API output.

Scenarios cover reset, prepare-only pending state, prepare/commit, duplicate
commit, commit/reset, false genuine-QP selection, invalid legs, short/strided
columns, four malformed storage views, malformed pending words/imaginary parts,
and separation of two caller-owned precision contexts. Normal operations target
leg 1; leg 2's persistence is observed. The unit records final complete integer
reference/pending arrays, all masks, and every module-call status. Prepare-only
cases expose staging separately. It does not record every intermediate array
state, exercise a second valid leg's construction, repeated prepare, or
prepare→reset→commit. Native behavior of the strided view is qualified only for
the admitted compiler/flags if the unit later passes.

The four deliberately dirty initial arrays have distinct exact integer patterns,
and both precision masks start true. This makes unintended writes to the opposite
context and inaccessible malformed-view regions visible. Partial reset
expectations describe only the actual slices passed to Fortran; they do not
claim that storage outside a supplied view gets invalidated. Those expectations
were independently source-reviewed. Other expected states reuse the frozen
integer Python specification with independent raw words.

The module stores no runtime precision tag in its integer buffers. Mixing DP
preparation with QP commit on the same buffers can accept a reinterpreted finite
word. Distinct buffers and matching setter/consumer APIs remain explicit caller
obligations. Fortran also cannot identify a canonical P origin, the actual
column's originating lower bound, an expression temporary, disjoint ownership,
or a completed physical constructor. The Python specification's metadata
refusals are stronger caller assumptions and are not claimed as native checks.

The reused observer supplies untouched control, four rounding modes, individual
and combined sticky flags, individual and combined halting modes, and FTZ/DAZ
cohorts. Its setters are confined to the standalone driver. Matching TRANSFER,
integer/logical work and the module calls run inside the altered interval.
All explicit formatted I/O follows successful observed restoration; a failed restoration
uses the existing nonreturning integer-only C reporter. A trap, changed observed
state, unsupported/skipped cohort, incomplete output or failed restoration is a
retained failure. All 20 cohorts must execute for every case in both variants.

The expected future variants are checked module compilation
`-O0 -fcheck=all -ftrapv` and optimized `-O3 -fno-fast-math`; the driver remains
`-O0 -fcheck=all -frounding-math` in both. `build-plan.json` lists the seven exact
compiler/link commands and source/toolchain pins. `run-plan.json` remains dormant
with null executable/runtime hashes until an independently reviewed actual
BUILD receipt exists. The existing root admission workflow must supply fresh
private ownership, prebound linker/runtime closure, exact live child/map checks,
READY/GO and DONE/EXIT handshakes, deadlines and separate RUN approval. The plans
do not execute commands by themselves.

`analyze.py` strictly checks complete raw input echoes, every call status, every
mask and all 64 INTEGER128 state words per case/cohort, requested/observed
environment agreement, no state changes and exact restoration. Pure tests use
explicitly synthetic observations to exercise this parser and reject mutations,
truncation, extra records, SKIP and failed restoration. These are source/parser
tests; their modeled call counts are not native evidence. Twelve tests pass in
normal and optimized Python under process/native guards.

Independent source reviews are in `audit-driver`, `audit-math-transport`,
`audit-design` and `audit-parser`. Runtime transport, constructor completion,
canonical-column provenance, q-at-use lowering, final-dot/physical IEEE behavior,
full caller/numerator lifetime, performance and scientific qualification remain
false. A future successful standalone RUN would qualify only this module's
observed transport/lifecycle cases under the admitted compiler and cohorts.

Read-only/source-only checks from the repository directory:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/generic-owned-snapshot-qualification-proposal-1/run_source_tests.py
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -O -B .tirust-build/generic-owned-snapshot-qualification-proposal-1/run_source_tests.py
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/generic-owned-snapshot-qualification-proposal-1/verify_source.py
```

Preserve this source packet unchanged. Future admitted BUILD/RUN outputs belong
in its separate private work directory; this source proposal grants no execution
admission.
