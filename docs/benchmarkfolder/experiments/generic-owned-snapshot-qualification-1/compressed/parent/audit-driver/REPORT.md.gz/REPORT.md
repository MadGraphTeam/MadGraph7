# Independent dormant driver and corpus source review

No blocking source inconsistency was found between driver `a7b9bcd6`, corpus
`27667aa1`, and expectations `283239e8` within the declared standalone scope.
This is source/data inspection only: no proposal Python was imported or run,
no tests or fixtures were regenerated, and no compiler, native driver, reducer,
ABI controller, or production code was executed or edited.

The driver imports the exact module's six public reset/prepare/commit routines
with module interfaces and uses distinct DP/QP reference, pending and mask
objects. Raw DP fixtures are read directly into matching INTEGER64 carriers
using Z16; QP fixtures use matching INTEGER128 and Z32. Both scalar TRANSFER
directions into typed real columns occur inside each active cohort. The QP
strided-view staging adds real copies, not floating arithmetic or conversion.
The active Fortran source path contains no floating comparison, arithmetic,
negation, constructor, formatted input/output, or error reporter. Its numerical
questions remain actual compiler behavior for these bit moves and module calls,
especially signaling NaNs, subnormals and traps.

Dirty integer/logical setup and fixture parsing precede `qualifier_begin`.
The scenario executes only when setup and the before-observer succeed. The
after-observer and restore execute for normal setup/skip/error returns. If
restoration is not observed, the exact pinned C reporter formats integers into
a bounded buffer, calls raw write and `_exit(86)`, and cannot return to Fortran
output. All normal state emission and explicit Fortran error reporting follow
observed restoration. A runtime trap or compiler-inserted fatal check would
still be a failed native attempt, not a successful restoration observation.

Twenty cohorts retain the prior observer's rounding/sticky/halt/FTZ/DAZ contract
and seven observed fields. Explicit optional-mode skips receive no execution
qualification. The future analyzer must reject nonoptional skips and setup,
observation or restoration errors; a skip's dirty state is not a module result.

For each case/cohort, the driver emits all module-call OK values, all four
two-element validity/pending masks, and every reference/pending real/imaginary
INTEGER128 word in both contexts. It echoes input words once and includes
before/after/restored environment fields. This is complete final context state
for each declarative scenario, rather than a checksum; intermediate stage
publication is distinguished by separate prepare-only scenarios. It is not a
per-operation state trace within multi-call scenarios.

The 37-case corpus and stored expectations agree with the 27 scenario action
branches on source inspection. The independent delegated review also checked
the partial malformed views: scenario 18 clears only reference real channels;
19 clears only pending leg 1; 20 leaves reference component 3 dirty; 21 leaves
the inaccessible second valid mask dirty/true. All other supplied regions clear
and the malformed operations return false. These partial effects match actual
Fortran argument sections and the module's whole-dummy assignment semantics.

Scenarios 22–25 are deliberately corrupted pending INTEGER data, not malformed
native REAL inputs. Scenarios 26/27 test opposite-precision context independence.
They do not test cross-API misuse refusal. Scenario 17 concerns the exact
compiled noncontiguous descriptor; it cannot qualify arbitrary canonical view
provenance or rule out all compiler-created temporaries.

Coverage does not include repeated prepare, prepare→reset→commit (8/9 are
commit→reset), replacing one leg while another valid leg is retained, or mixing
DP prepare with QP commit. Do not claim these paths qualified by this corpus.
The module has no runtime precision tag, canonical-column identity, originating
lower-bound proof, or constructor-completion receipt; all remain source-level
caller conditions. No full-caller lifetime, geometry/final-dot behavior,
genuine QP integrand construction, ABI, amplitude, performance or scientific
qualification follows from this source review or from hypothetical unit success.
