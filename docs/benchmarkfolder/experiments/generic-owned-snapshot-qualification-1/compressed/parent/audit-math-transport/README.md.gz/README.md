# Independent transport and expectation source read

Narrow result: **CLEAR** for the proposed standalone source unit's typed word
transport, declared precision separation, and expected protocol states. No
compiler, native driver, project module, corpus generator, ABI controller,
physical-math helper, reducer, or amplitude was executed by this audit.

The exact module is the unchanged sealed `owned_snapshots.f90`, SHA-256
`307b8f7615b3c83c8ca15713b180d8cd70013f441ca0598f466efd6386966706`.
The DP driver reads Z16 directly into a matching INTEGER64 carrier and uses
matching-width INTEGER64-to-REAL(DP) TRANSFER inside each requested cohort. The
module performs the reverse matching-width TRANSFER, then explicitly masks
the widened INTEGER128 word to 64 bits. Negative DP carriers therefore do not
leave sign-extended high bits. QP input is Z32 in INTEGER128 with matching
INTEGER128/REAL(QP) TRANSFER. There is no DP-to-QP widening, DD substitution,
floating negation, or numerical conversion of the fixture payloads.

All normal calls use matching named APIs and disjoint DP/QP reference, pending,
valid, and pending-valid objects. The driver captures both complete final
contexts plus every returned OK status. The low QP fraction bit in the finite
corpus must survive exactly; merely widening a binary64 value cannot satisfy
that expected word. These are prospective assertions, not native observations.

The source expectation model matches the declared bounded cases. Prepare clears
the target leg before checking all four finite real words and publishes only
after complete success. Commit rechecks pending validity, finite words, zero
imaginary channels, and DP high bits, then consumes pending storage. Invalid
legs, false genuine-QP gates, and malformed storage reset only the storage
actually supplied to the API. In particular, the explicit slice expectations
for cases 18–21 preserve inaccessible dirty elements correctly; they do not
assume that an invalid section gives the callee access to the entire object.

The nonfinite fixtures use integer exponent classification for infinities,
quiet NaNs, and signaling NaNs. Separate pending corruption covers DP high64
bits, imaginary words, and QP infinity. A REAL(DP) input cannot itself carry
forbidden high64 bits; the corpus accurately labels that case as pending-buffer
corruption. Whether loading/passing a signaling NaN traps, quiets it, or changes
an observed environment field is still a compiler/lowering question for a
separately admitted run.

There are **no runtime precision tags** in the INTEGER128 buffers. The Python
state's width and ColumnView provenance checks are stronger caller metadata,
not observable native buffer checks. The corpus correctly does not expect
cross-API misuse rejection and declares canonical P origin, actual lower-bound
provenance, constructor completion, ownership, and lifetime as unresolved caller
obligations. A future passing unit would qualify only the exact standalone
transport/protocol calls and executed compiler/environment variants.

Coverage is intentionally bounded: normal prepare/commit calls stage leg 1;
leg 2 persistence is observed but leg 2 is not independently staged. Storage is
recorded after the scenario, with per-call statuses, rather than after every
call. The four nonfinite classes occupy components 0, 1, 2, and 3 respectively,
so not every class is tested in the final component. Valid-leg reprepare and a
reset strictly between prepare and commit are not separate current scenarios.
These limits must accompany later results; this is not an exhaustive protocol
or malformed-descriptor qualification.

The separate FENV/IO/restore audit owns the environment controller boundary.
This report does not claim that its source has executed safely. Native transport,
canonical source ownership, generated caller lifetime, genuine QP construction,
geometry/final-dot arithmetic, scientific dispatch, amplitude accuracy, and
performance all remain unqualified.
