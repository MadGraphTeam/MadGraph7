! DORMANT PRIVATE SOURCE ONLY. No compiler, loader, or native execution admitted.
! Uses the unchanged ml_private_owned_snapshots module. No new physical math.
! Observer ABI is the unchanged exact-geometry qualifier fenv_observer.c ABI.
! Fixture: NCASES; then ID SCENARIO, four Z16 DP words, four Z32 QP words.
! All input words are raw signed matching-width carriers, not REAL conversions.
! Cases always have two disjoint caller-owned DP/QP contexts. The module has
! no buffer precision tag; cross-API misuse rejection is NOT a tested contract.
! Canonical P origin, actual lower-bound provenance, normal constructor return,
! disjointness, full-caller lifetime and scientific admission remain unproved.
program qualify_owned_snapshots
  use, intrinsic :: iso_c_binding, only: c_int,c_int64_t
  use, intrinsic :: iso_fortran_env, only: input_unit,output_unit
  use ml_private_owned_snapshots, only: snapshot_ik,snapshot_dp,snapshot_qp, &
      owned_reset_dp,owned_reset_qp,owned_prepare_dp,owned_prepare_qp, &
      owned_commit_dp,owned_commit_qp
  implicit none
  interface
    function qualifier_pid() result(pid) bind(C,name='ml_geom_qual_pid')
      import c_int
      integer(c_int) :: pid
    end function
    subroutine qualifier_constants(values) bind(C,name='ml_geom_qual_constants')
      import c_int64_t
      integer(c_int64_t), intent(out) :: values(10)
    end subroutine
    function qualifier_observe(values) result(status) bind(C,name='ml_geom_qual_observe')
      import c_int,c_int64_t
      integer(c_int64_t), intent(out) :: values(7)
      integer(c_int) :: status
    end function
    function qualifier_begin(mode,requests,baseline) result(status) bind(C,name='ml_geom_qual_begin')
      import c_int,c_int64_t
      integer(c_int), value :: mode
      integer(c_int64_t), intent(out) :: requests(5),baseline(7)
      integer(c_int) :: status
    end function
    function qualifier_restore(restored) result(status) bind(C,name='ml_geom_qual_restore')
      import c_int,c_int64_t
      integer(c_int64_t), intent(out) :: restored(7)
      integer(c_int) :: status
    end function
    subroutine qualifier_raw_restore_failure(id,mode,status,restore_result) &
        bind(C,name='ml_geom_qual_raw_restore_failure')
      import c_int
      integer(c_int), value :: id,mode,status,restore_result
    end subroutine
  end interface
  integer, parameter :: mode_count=20,scenario_count=27,max_cases=10000,max_calls=4
  integer, parameter :: native_i64=selected_int_kind(18)
  integer(snapshot_ik), parameter :: dp_dirty_ref=int(z'11111111111111111111111111111111',snapshot_ik)
  integer(snapshot_ik), parameter :: dp_dirty_pending=int(z'22222222222222222222222222222222',snapshot_ik)
  integer(snapshot_ik), parameter :: qp_dirty_ref=int(z'33333333333333333333333333333333',snapshot_ik)
  integer(snapshot_ik), parameter :: qp_dirty_pending=int(z'44444444444444444444444444444444',snapshot_ik)
  integer(snapshot_ik) :: dp_ref(2,0:3,2),dp_pending(2,0:3,2)
  integer(snapshot_ik) :: qp_ref(2,0:3,2),qp_pending(2,0:3,2),qp_words(0:3)
  integer(native_i64) :: dp_words(0:3)
  integer(c_int64_t) :: constants(10),requests(5),baseline(7),before(7),after(7),restored(7)
  logical :: dp_valid(2),dp_pending_valid(2),qp_valid(2),qp_pending_valid(2),call_ok(max_calls)
  real(snapshot_dp) :: dp_column(0:3)
  real(snapshot_qp) :: qp_column(0:3),qp_wide(0:6)
  integer(c_int) :: status,observed_before,observed_after,restore_ok
  integer :: iu,ou,ios,ncases,case_number,id,scenario,mode,mu,leg,ncall
  character(len=4096) :: fixture_path,observation_path,line
  character(len=32) :: command

  if(command_argument_count()/=2) error stop 'Expected fixtures.hex observations.txt'
  call get_command_argument(1,fixture_path,status=ios)
  if(ios/=0) error stop 'Invalid fixture path'
  call get_command_argument(2,observation_path,status=ios)
  if(ios/=0) error stop 'Invalid observation path'
  write(output_unit,'(A,1X,I0)') 'READY',qualifier_pid()
  flush(output_unit)
  read(input_unit,'(A)',iostat=ios) command
  if(ios/=0.or.trim(command)/='GO') error stop 'GO handshake required'
  open(newunit=iu,file=trim(fixture_path),status='old',action='read',iostat=ios)
  if(ios/=0) error stop 'Cannot open fixtures'
  open(newunit=ou,file=trim(observation_path),status='new',action='write',iostat=ios)
  if(ios/=0) error stop 'Cannot create fresh observations'
  read(iu,*,iostat=ios) ncases
  if(ios/=0) error stop 'Missing fixture count'
  if(ncases<1.or.ncases>max_cases) error stop 'Fixture count out of bounds'
  call qualifier_constants(constants)
  write(ou,'(A)') 'SCHEMA owned-snapshot-fenv-v1'
  write(ou,'(A,*(1X,I0))') 'CONSTANTS',constants
  write(ou,'(A,1X,I0)') 'NCASES',ncases
  write(ou,'(A,1X,I0)') 'MODES',mode_count
  write(ou,'(A)') 'SNAPSHOT_FIELDS round sticky halts mxcsr_control x87cw mxcsr_raw x87sw'
  write(ou,'(A)') 'CASE_FIELDS id mode scenario status observe_before observe_after restore_ok '// &
      'requests(5) baseline(7) before(7) after(7) restored(7)'
  write(ou,'(A)') 'STATUS_FIELDS id mode ncall returned_ok(1:ncall)'
  write(ou,'(A)') 'MASK_FIELDS id mode width valid(1:2) pending_valid(1:2)'
  write(ou,'(A)') 'WORD_FIELDS id mode width leg component real_word imaginary_word'
  do case_number=1,ncases
    read(iu,*,iostat=ios) id,scenario
    if(ios/=0) error stop 'Malformed fixture header'
    if(id<1.or.scenario<1.or.scenario>scenario_count) error stop 'Invalid fixture id or scenario'
    do mu=0,3
      read(iu,'(A)',iostat=ios) line
      if(ios/=0) error stop 'Missing DP fixture word'
      if(len_trim(line)/=16.or.verify(trim(line),'0123456789abcdefABCDEF')/=0) &
          error stop 'Malformed DP fixture word'
      read(line,'(Z16)',iostat=ios) dp_words(mu)
      if(ios/=0) error stop 'Invalid DP fixture word'
    enddo
    do mu=0,3
      read(iu,'(A)',iostat=ios) line
      if(ios/=0) error stop 'Missing QP fixture word'
      if(len_trim(line)/=32.or.verify(trim(line),'0123456789abcdefABCDEF')/=0) &
          error stop 'Malformed QP fixture word'
      read(line,'(Z32)',iostat=ios) qp_words(mu)
      if(ios/=0) error stop 'Invalid QP fixture word'
    enddo
    do mode=0,mode_count-1
      ! Integer-only dirty setup before the altered environment. Precision
      ! preservation is observable even when only one context is exercised.
      dp_ref=dp_dirty_ref;dp_pending=dp_dirty_pending
      qp_ref=qp_dirty_ref;qp_pending=qp_dirty_pending
      dp_valid=.true.;dp_pending_valid=.true.
      qp_valid=.true.;qp_pending_valid=.true.
      ncall=0;call_ok=.false.
      status=qualifier_begin(int(mode,c_int),requests,baseline)
      observed_before=qualifier_observe(before)
      if(status==0.and.observed_before==0) then
        ! Equal-width bit transport deliberately runs under the requested
        ! controls, including subnormal/sNaN inputs under enabled traps.
        ! No real conversion, sign operation, arithmetic or comparison occurs.
        do mu=0,3
          dp_column(mu)=transfer(dp_words(mu),0.0_snapshot_dp)
          qp_column(mu)=transfer(qp_words(mu),0.0_snapshot_qp)
        enddo
        qp_wide=transfer(0_snapshot_ik,0.0_snapshot_qp)
        do mu=0,3
          qp_wide(2*mu)=qp_column(mu)
        enddo
        call run_scenario()
      endif
      observed_after=qualifier_observe(after)
      restore_ok=qualifier_restore(restored)
      if(restore_ok/=1) then
        ! Unchanged C reporter formats integers and _exit(86); it never returns.
        ! Failed restoration must not reach any Fortran formatted I/O.
        call qualifier_raw_restore_failure(int(id,c_int),int(mode,c_int),status,restore_ok)
      endif
      ! All record emission and logical-to-integer formatting follows restore.
      if(mode==0) then
        write(ou,'(A,2(1X,I0))') 'INPUT',id,scenario
        do mu=0,3
          write(ou,'(A,2(1X,I0),1X,Z16.16)') 'DPWORD',id,mu,dp_words(mu)
          write(ou,'(A,2(1X,I0),1X,Z32.32)') 'QPWORD',id,mu,qp_words(mu)
        enddo
      endif
      write(ou,'(A,*(1X,I0))') 'CASE',id,mode,scenario,status,observed_before,observed_after,restore_ok, &
          requests,baseline,before,after,restored
      write(ou,'(A,*(1X,I0))') 'STATUS',id,mode,ncall,merge(1,0,call_ok(:ncall))
      write(ou,'(A,*(1X,I0))') 'MASK',id,mode,64,merge(1,0,dp_valid),merge(1,0,dp_pending_valid)
      write(ou,'(A,*(1X,I0))') 'MASK',id,mode,128,merge(1,0,qp_valid),merge(1,0,qp_pending_valid)
      do leg=1,2
        do mu=0,3
          write(ou,'(A,5(1X,I0),2(1X,Z32.32))') 'REF',id,mode,64,leg,mu,dp_ref(:,mu,leg)
          write(ou,'(A,5(1X,I0),2(1X,Z32.32))') 'PENDING',id,mode,64,leg,mu,dp_pending(:,mu,leg)
          write(ou,'(A,5(1X,I0),2(1X,Z32.32))') 'REF',id,mode,128,leg,mu,qp_ref(:,mu,leg)
          write(ou,'(A,5(1X,I0),2(1X,Z32.32))') 'PENDING',id,mode,128,leg,mu,qp_pending(:,mu,leg)
        enddo
      enddo
      if(status==2.or.observed_before/=0.or.observed_after/=0) then
        flush(ou)
        error stop 'Environment setup/observation/restoration failure'
      endif
    enddo
    flush(ou)
  enddo
  read(iu,'(A)',iostat=ios) line
  if(ios>=0) error stop 'Unexpected extra fixture record'
  close(iu)
  write(ou,'(A,1X,I0)') 'DONE',ncases
  close(ou)
  write(output_unit,'(A,1X,I0)') 'DONE',qualifier_pid()
  flush(output_unit)
  read(input_unit,'(A)',iostat=ios) command
  if(ios/=0.or.trim(command)/='EXIT') error stop 'EXIT handshake required'
contains
  subroutine run_scenario()
    ! Declarative bounded cases, not an operation VM. Dirty initial values are
    ! specified above. Every normal prepare/commit uses leg1 and genuine QP.
    ! Module call statuses are recorded; inserted test corruption is integer-only.
    select case(scenario)
    case(1) ! RESET_BOTH
      ncall=2
      call owned_reset_dp(dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(1))
      call owned_reset_qp(qp_ref,qp_valid,qp_pending,qp_pending_valid,call_ok(2))
    case(2,3,6,8,22,23,26) ! DP prepare-only, commit, duplicate, reset, corruption, precision separation
      ncall=2
      call owned_reset_dp(dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(1))
      call owned_prepare_dp(1,dp_column,dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(2))
      if(scenario==22) dp_pending(1,0,1)=ibset(dp_pending(1,0,1),64)
      if(scenario==23) dp_pending(2,0,1)=1_snapshot_ik
      if(scenario/=2) then
        ncall=3
        call owned_commit_dp(1,dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(3))
      endif
      if(scenario==6) then
        ncall=4
        call owned_commit_dp(1,dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(4))
      elseif(scenario==8) then
        ncall=4
        call owned_reset_dp(dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(4))
      elseif(scenario==26) then
        ncall=4
        call owned_reset_qp(qp_ref,qp_valid,qp_pending,qp_pending_valid,call_ok(4))
      endif
    case(4,5,7,9,24,25,27) ! Matching genuine-QP cases
      ncall=2
      call owned_reset_qp(qp_ref,qp_valid,qp_pending,qp_pending_valid,call_ok(1))
      call owned_prepare_qp(1,qp_column,qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(2))
      if(scenario==24) qp_pending(1,0,1)=int(z'7FFF0000000000000000000000000000',snapshot_ik)
      if(scenario==25) qp_pending(2,0,1)=1_snapshot_ik
      if(scenario/=4) then
        ncall=3
        call owned_commit_qp(1,qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(3))
      endif
      if(scenario==7) then
        ncall=4
        call owned_commit_qp(1,qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(4))
      elseif(scenario==9) then
        ncall=4
        call owned_reset_qp(qp_ref,qp_valid,qp_pending,qp_pending_valid,call_ok(4))
      elseif(scenario==27) then
        ncall=4
        call owned_reset_dp(dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(4))
      endif
    case(10) ! QP_PREPARE_NOT_GENUINE: invalidates the entire QP context
      ncall=1
      call owned_prepare_qp(1,qp_column,qp_ref,qp_valid,qp_pending,qp_pending_valid,.false.,call_ok(1))
    case(11) ! QP_COMMIT_NOT_GENUINE
      ncall=1
      call owned_commit_qp(1,qp_ref,qp_valid,qp_pending,qp_pending_valid,.false.,call_ok(1))
    case(12) ! DP_PREPARE_LEG_ZERO
      ncall=1
      call owned_prepare_dp(0,dp_column,dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(1))
    case(13) ! QP_PREPARE_LEG_THREE
      ncall=1
      call owned_prepare_qp(3,qp_column,qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(1))
    case(14) ! DP_COMMIT_LEG_THREE
      ncall=1
      call owned_commit_dp(3,dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(1))
    case(15) ! QP_COMMIT_LEG_ZERO
      ncall=1
      call owned_commit_qp(0,qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(1))
    case(16) ! DP_SHORT_COLUMN: reference validity remains false after rejection
      ncall=2
      call owned_reset_dp(dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(1))
      call owned_prepare_dp(1,dp_column(0:2),dp_ref,dp_valid,dp_pending,dp_pending_valid,call_ok(2))
    case(17) ! QP_STRIDED_COLUMN: shape4 but noncontiguous view
      ncall=2
      call owned_reset_qp(qp_ref,qp_valid,qp_pending,qp_pending_valid,call_ok(1))
      call owned_prepare_qp(1,qp_wide(0:6:2),qp_ref,qp_valid,qp_pending,qp_pending_valid,.true.,call_ok(2))
    case(18) ! DP_PREPARE_MALFORMED_REFERENCE_FIRST_EXTENT
      ncall=1
      call owned_prepare_dp(1,dp_column,dp_ref(1:1,:,:),dp_valid,dp_pending,dp_pending_valid,call_ok(1))
    case(19) ! QP_COMMIT_MALFORMED_PENDING_LEG_EXTENT
      ncall=1
      call owned_commit_qp(1,qp_ref,qp_valid,qp_pending(:,:,1:1),qp_pending_valid,.true.,call_ok(1))
    case(20) ! DP_RESET_MALFORMED_REFERENCE_COMPONENT_EXTENT
      ncall=1
      call owned_reset_dp(dp_ref(:,0:2,:),dp_valid,dp_pending,dp_pending_valid,call_ok(1))
    case(21) ! QP_RESET_MALFORMED_VALID_EXTENT
      ncall=1
      call owned_reset_qp(qp_ref,qp_valid(1:1),qp_pending,qp_pending_valid,call_ok(1))
    end select
  end subroutine run_scenario
end program qualify_owned_snapshots
