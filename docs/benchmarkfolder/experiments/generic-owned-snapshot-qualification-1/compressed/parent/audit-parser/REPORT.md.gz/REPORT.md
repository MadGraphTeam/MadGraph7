# Independent strict replay and dormant-plan source review

No blocking source issue remains in the final parser/test/plan inputs bound by
this receipt. This review read source and JSON only. It did not import or run
proposal code, run tests, regenerate fixtures, compile/link, launch a native
driver or controller, or edit the reviewed inputs.

`analyze.py` consumes the fixed schema in exact order, including every raw DP/QP
input echo, case/cohort identity, module-call status, both complete mask records,
and every reference/pending word. Fixed record lengths and explicit ordering
reject missing, duplicate, reordered, extra or malformed records. Expected
native input echoes are compared to the externally frozen expectations; the
RUN plan pins both fixture and expectations. For this corpus, replay requires
37×20 = 740 observations and 47,360 INTEGER128 state words per variant. No SKIP
or nonzero observation/setup result can count as transport qualification. The
final DONE record and end of input must agree exactly.

Each cohort requires successful restoration with restored==baseline and exact
before==after equality across all seven fields. The final source additionally
checks API rounding and halt masks against x87/SSE hardware words in every
baseline/before/after/restored snapshot. Sticky/API/raw control consistency and
range checks also apply to every snapshot; modified cohorts separately match
their actual requests, including FTZ/DAZ where requested. Thus equal but
self-contradictory original/restored snapshots cannot pass merely by agreeing
with one another. These observed fields do not imply full FPU-register or
unobserved runtime preservation.

The initial review found that the API↔hardware round/halt checks applied only to
modified-mode `before`, and that the no-I/O source test omitted the called
`run_scenario` body. Both narrow corrections are present in the final source;
the prior inputs are retained under `history/parser-attempt-1`. New synthetic
mutations change all four API round/halt fields together while keeping equality
guards true, and the I/O scan now includes both the outer active region and the
contained scenario body. The current body was already free of such I/O. This
is a source check of the correction and regression definitions, not a claim
that this reviewer executed them.

Other source tests define corruption checks for input echoes, state words,
masks, statuses, truncation, extra terminal records, setup skips, environment
deltas and failed restoration. Synthetic transcripts remain explicitly
non-native evidence. A successful replay returns analysis_only=true and leaves
execution authorization, native transport, canonical origin, constructor,
q/final-dot, full-caller and scientific-dispatch qualification false.

BUILD and RUN are separate unadmitted declarative plans. They list future
commands and prerequisite ownership/toolchain/runtime evidence, retain zero
performed compiler/native calls, and leave actual executable/runtime hashes
null. RUN requires a separately accepted actual BUILD receipt and explicit
admission; it cannot infer binaries from source-only hashes. The exact snapshot
and observer source copies match their frozen ancestors. No executable native
controller/executor is present in this packet. Actual execution ownership,
binary/provider binding, native results and any later qualification remain the
responsibility of a separately reviewed admission and evidence chain.

The earlier driver/corpus coverage limits remain: no repeated prepare,
prepare→reset→commit, replacement with another valid leg retained, or mixed
precision API misuse is exercised. Canonical-column metadata, disjointness,
precision separation and real constructor completion remain caller conditions.
This source review grants no native, compiler ABI, full-caller, performance or
scientific qualification.
