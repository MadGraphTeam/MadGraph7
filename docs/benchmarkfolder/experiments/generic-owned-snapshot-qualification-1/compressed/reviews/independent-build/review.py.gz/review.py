from pathlib import Path
import collections,ctypes,datetime,hashlib,importlib.util,json,os,re,subprocess,sys,time
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2';BUILD=ROOT/'.tirust-build/generic-owned-snapshot-qualification-work-2/build';OUT=ROOT/'.tirust-build/generic-owned-snapshot-build2-independent-audit-1'
SOURCE='41797bbf9e25eb1836932307f66ad74f413714dd38cf1485e07cc8f2d74160d9'
TERMINAL='cb09bd997719180a66ad18d157d7d0830876ff12611621abeae97537fd342ec1'
RESULT='0a6737daa72d18f9031aa53e7a4c7d8df8f7b967dddf86372f432d34e6c344a4'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
start=time.monotonic();assert digest(SRC/'source-index.json')==SOURCE and digest(BUILD/'terminal.json')==TERMINAL and digest(BUILD/'result.json')==RESULT
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('Audit forbids child/native execution')
def patch(o,n):
 if hasattr(o,n):saved.append((o,n,getattr(o,n)));setattr(o,n,deny)
try:
 for n in ('Popen','run','call','check_call','check_output'):patch(subprocess,n)
 for n in ('system','popen','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe','fork','forkpty'):patch(os,n)
 for n in ('CDLL','PyDLL','_dlopen'):patch(ctypes,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 controller=load('snapshot_build_independent_controller',SRC/'controller.py')
 controller.EXPECTED_SOURCE=SOURCE;controller.REVIEWED_BUILD=TERMINAL;controller.PHASE='build'
 protected=controller.verify_source();built=controller.verify_build();assert built==read(BUILD/'result.json')
 corpus=load('snapshot_build_independent_corpus',SRC/'corpus.py');cases=corpus.cases();expected=read(SRC/'expectations.json')
 assert len(cases)==37 and corpus.render(cases)==(SRC/'fixtures.hex').read_text()
 assert {str(x['id']):x for x in cases}==expected['cases']
 assert expected['input_sha256']==digest(SRC/'fixtures.hex') and expected['mode_count']==20
 assert sum(len(x['expected']['status']) for x in cases)*20==1840
 loader=controller.support(controller.LOADER_PATH)
 for name,row in built['variants'].items():
  case=BUILD/name;bound=read(case/'prelink.json')
  assert loader.requireactualmap((case/'link.map').read_text(),case,bound,case/'check')==row['actual_link_loads']
finally:
 for o,n,v in reversed(saved):setattr(o,n,v)
assert not attempts
terminal=read(BUILD/'terminal.json');assert terminal['status']=='passed' and terminal['returncode']==0 and terminal['result_sha256']==RESULT and not terminal['cleanup']['survivors']
elapsed=(datetime.datetime.fromisoformat(terminal['finished_utc'])-datetime.datetime.fromisoformat(terminal['started_utc'])).total_seconds()
assert 0<elapsed<terminal['cap_seconds']==180 and terminal['cleanup_reserve_seconds']==60
assert terminal['deadline_monotonic']==terminal['original_end_monotonic']==terminal['original_start_monotonic']+180
limit_record=read(BUILD/'limits.json');assert limit_record['pid']==limit_record['session']==limit_record['process_group']==terminal['child_pid'];limits=limit_record['actual'];assert limits=={'address_space_bytes':[4294967296,4294967296],'core_bytes':[0,0],'file_bytes':[268435456,268435456]}
assert built['snapshot_main_calls']==built['scientific_reducer_calls']==0
commands={}
for p in sorted((BUILD/'commands').glob('*.command.json')):
 name=p.name[:-len('.command.json')];command=read(p);closed=read(p.with_name(name+'.terminal.json'));raw=p.with_name(name+'.stdout.txt')
 assert closed['returncode']==0 and closed['stdout_sha256']==digest(raw)
 assert datetime.datetime.fromisoformat(command['started_utc'])<=datetime.datetime.fromisoformat(closed['finished_utc'])
 assert command['session']==command['process_group']==terminal['child_pid'];commands[name]=command
assert len(commands)==57
tools={k:v['path'] for k,v in read(SRC/'toolchain-pins.json')['required_tools'].items()}
assert commands['fenv-observer-compile']['argv']==[tools['cc'],'-std=c11','-O0','-fPIC','-frounding-math','-c',str(SRC/'fenv_observer.c'),'-o','fenv_observer.o']
assert digest(SRC/'owned_snapshots.f90')=='307b8f7615b3c83c8ca15713b180d8cd70013f441ca0598f466efd6386966706'
assert digest(SRC/'fenv_observer.c')=='ed3c9f705398c4d008dae7ae055732420b8b0b11d39faa6f5dc1d04aa058c6f7'
apis={'__ml_private_owned_snapshots_MOD_owned_'+op+'_'+precision for op in ('reset','prepare','commit') for precision in ('dp','qp')}
details={}
for name,row in built['variants'].items():
 case=BUILD/name;flags=['-O0','-fcheck=all','-ftrapv'] if name=='checked' else ['-O3','-fno-fast-math']
 assert commands[name+'-module-compile']['argv']==[tools['gfortran'],*flags,'-fPIC','-c',str(SRC/'owned_snapshots.f90'),'-o','owned_snapshots.o']
 assert commands[name+'-driver-compile']['argv']==[tools['gfortran'],'-O0','-fPIC','-fcheck=all','-frounding-math','-c',str(SRC/'driver.f90'),'-o','driver.o']
 assert commands[name+'-link']['argv']==[tools['gfortran'],'-fPIC','-Wl,-Map,link.map,--cref','-o','check','driver.o','owned_snapshots.o',str(BUILD/'fenv_observer.o'),'-lm']
 assert all(commands[name+suffix]['cwd']==str(case) for suffix in ('-module-compile','-driver-compile','-link'))
 symbols=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',(BUILD/'commands'/ (name+'-symbols.stdout.txt')).read_text(),re.M)
 assert all(symbols.count(x)==1 for x in apis) and not any('ml_private_exact_geometry' in x for x in symbols)
 undefined=re.findall(r'\bU\s+(\S+)',(BUILD/'commands'/(name+'-module-undefined.stdout.txt')).read_text());assert undefined==row['module_undefined_symbols']
 assert set(undefined)==({'__addvdi3','__addvsi3','__mulvdi3','__negvdi2','__subvdi3','_gfortran_runtime_error_at','memcpy'} if name=='checked' else {'memcpy','memset'})
 bound=read(case/'prelink.json');assert bound['explicit_standalone_runtime_join_before_link']==row['runtime']['files']
 assert len(row['runtime']['files'])==5 and all(bound['bound'][p]==h for p,h in {**row['actual_link_loads'],**row['runtime']['files']}.items())
 assert row['runtime']['loader_sha256']==digest(row['runtime']['loader'])
 assert not any(re.search('tirust|ninja|collier',p,re.I) for p in row['runtime']['files'])
 details[name]={'executable_sha256':row['sha256'],'module_object_sha256':row['objects']['owned_snapshots.o'],'driver_object_sha256':row['objects']['driver.o'],'module_flags':flags,'runtime_provider_count':5,'actual_LOAD_paths':len(row['actual_link_loads']),'unique_snapshot_API_definitions':6,'undefined':undefined}
assert built['variants']['checked']['objects']['driver.o']==built['variants']['optimized']['objects']['driver.o']
owned_ids=terminal['cleanup']['observed_owned_processes'];assert len({(r['pid'],r['start_time_ticks']) for r in owned_ids})==len(owned_ids)
receipt={'schema':'independent-owned-snapshot-build2-readiness-v1','status':'PASS','audit_source_sha256':digest(__file__),'source_index_sha256':SOURCE,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'module_sha256':built['module_sha256'],'fenv_source_sha256':digest(SRC/'fenv_observer.c'),'variants':details,'closed_commands':57,'build_wall_seconds':elapsed,'cap_seconds':180,'cleanup_reserve_seconds':60,'actual_limits':limits,'owned_identities':len(owned_ids),'survivors':[],'pure_expected_cases':37,'bounded_scenarios':27,'prospective_cohorts_per_variant':20,'prospective_module_calls_per_variant':1840,'prospective_integer_state_words_per_variant':47360,'source_and_static_runtime_file_replay':True,'forbidden_process_native_API_attempts':len(attempts),'new_native_calls':0,'readiness':'One separately admitted standalone RUN using these exact checked/optimized ELF identities; no existing unit-main result inferred from BUILD.','review':'Read complete integer snapshot module,37-case corpus,driver scenario/transport/fenv ordering,strict parser and owned RUN controller. Invalid view expectations cover only actually passed array slices; separate DP/QP caller buffers and matching APIs are obligations. Driver performs all formatted IO after restoration and requires all20cohorts with exact raw inputs/status/masks/64state words and before/after/restored environment. Build source hashes,flags,objects,prebound actual LOAD/static closure/PT listing,nm ownership and57closed commands revalidated file-only. Runtime mappings are prospective RUN gates; BUILD contains no model,constructor,q/dot,geometry helper,amplitude or reducer calls. No physical constructor/canonical-origin/full-caller/same-buffer precision tag/scientific/performance qualification.','public_or_git_mutations':0,'elapsed_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_seconds'],'commands':57,'cases':37,'forbidden_attempts':len(attempts)}))
