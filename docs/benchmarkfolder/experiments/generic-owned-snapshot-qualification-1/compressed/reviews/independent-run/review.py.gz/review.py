from pathlib import Path
import collections,ctypes,datetime,hashlib,importlib.util,json,os,re,subprocess,sys,time
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2';WORK=ROOT/'.tirust-build/generic-owned-snapshot-qualification-work-2';RUN=WORK/'run';OUT=ROOT/'.tirust-build/generic-owned-snapshot-run2-independent-audit-1'
SOURCE='41797bbf9e25eb1836932307f66ad74f413714dd38cf1485e07cc8f2d74160d9';BUILD='cb09bd997719180a66ad18d157d7d0830876ff12611621abeae97537fd342ec1';TERMINAL='3b9b46fd23b59f29e0ef571edf8024f078aeaff1892c8a8f89bca630f636100d';RESULT='0e696761b43e899c78e8457dee150066b948738d43a18633a1bfa38227cb4e0d';RAW='6b75d55910c8f00b0ae10d9a52544913ea2dfa7cf20a477326eda69b32e2c31b'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
start=time.monotonic();assert digest(SRC/'source-index.json')==SOURCE and digest(WORK/'build/terminal.json')==BUILD and digest(RUN/'terminal.json')==TERMINAL and digest(RUN/'result.json')==RESULT
assert digest(ROOT/'.tirust-build/generic-owned-snapshot-build2-independent-audit-1/receipt.json')=='221cff5b413732eef32cd344e103bb7ccf105a75ab44402178ed29d5c5745a4b'
before={str(p.relative_to(RUN)):digest(p) for p in RUN.rglob('*') if p.is_file()}
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('No native/process execution in audit')
def patch(o,n):
 if hasattr(o,n):saved.append((o,n,getattr(o,n)));setattr(o,n,deny)
try:
 for n in ('Popen','run','call','check_call','check_output'):patch(subprocess,n)
 for n in ('system','popen','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe','fork','forkpty'):patch(os,n)
 for n in ('CDLL','PyDLL','_dlopen'):patch(ctypes,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 c=load('snapshot_run_independent_controller',SRC/'controller.py');c.EXPECTED_SOURCE=SOURCE;c.REVIEWED_BUILD=BUILD;c.PHASE='run'
 c.verify_source();built=c.verify_build();corpus=load('snapshot_run_independent_corpus',SRC/'corpus.py');expected=read(SRC/'expectations.json')
 cases=corpus.cases();assert corpus.render(cases)==(SRC/'fixtures.hex').read_text() and {str(x['id']):x for x in cases}==expected['cases']
 analyzer=load('snapshot_run_independent_analyzer',SRC/'analyze.py');parsed={}
 for variant in ('checked','optimized'):
  text=(RUN/variant/'observations.txt').read_text();parsed[variant]=analyzer.analyze(text,expected)
  assert parsed[variant]==read(RUN/variant/'analysis.json')==read(RUN/'result.json')['variants'][variant]
finally:
 for o,n,v in reversed(saved):setattr(o,n,v)
assert not attempts and parsed['checked']==parsed['optimized']
terminal=read(RUN/'terminal.json');result=read(RUN/'result.json')
assert terminal['status']==result['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['result_sha256']==RESULT
assert result['source_index_sha256']==SOURCE and result['reviewed_build_sha256']==BUILD and result['scientific_reducer_calls']==0
for name in ('actual_constructor_completion_qualified','final_dot_runtime_qualified','full_caller_qualified','physical_or_performance_qualification','q_at_use_lowering_qualified','scientific_dispatch_enabled','snapshot_ownership_qualified'):assert result[name] is False
assert terminal['cap_seconds']==180 and terminal['cleanup_reserve_seconds']==60 and terminal['deadline_monotonic']==terminal['original_end_monotonic']==terminal['original_start_monotonic']+180
elapsed=(datetime.datetime.fromisoformat(terminal['finished_utc'])-datetime.datetime.fromisoformat(terminal['started_utc'])).total_seconds();assert 0<elapsed<120
limits=read(RUN/'limits.json');assert limits['actual']=={'address_space_bytes':[4294967296]*2,'file_bytes':[268435456]*2,'core_bytes':[0,0]}
assert limits['pid']==limits['session']==limits['process_group']==terminal['child_pid']
known={(r['pid'],r['start_time_ticks']):r for r in terminal['cleanup']['observed_owned_processes']};assert len(known)==3
details={};allmapfiles={};counters=collections.Counter()
for variant,brow in built['variants'].items():
 folder=RUN/variant;raw=(folder/'observations.txt').read_bytes();assert len(raw)==2156955 and hashlib.sha256(raw).hexdigest()==RAW
 closed=read(folder/'terminal.json');cmd=read(folder/'command.json');started=read(folder/'started.json');pid=started['pid'];identity=started['identity']
 assert closed['returncode']==0 and closed['stdout_tail']=='' and closed['observations_sha256']==RAW and closed['stderr_sha256']==digest(folder/'stderr.txt') and not (folder/'stderr.txt').read_bytes()
 assert cmd['argv']==[brow['path'],str(SRC/'fixtures.hex'),str(folder/'observations.txt')] and cmd['cwd']==str(folder) and cmd['new_session'] is False
 assert cmd['session']==cmd['process_group']==terminal['child_pid'] and identity['parent_pid']==terminal['child_pid']
 assert (pid,identity['start_time_ticks']) in known and (folder/'ready.txt').read_text()==f'READY {pid}\n' and (folder/'done.txt').read_text()==f'DONE {pid}\n'
 expected_files={**brow['runtime']['files'],brow['path']:brow['sha256']}
 for edge in ('before','after'):
  mapped=read(folder/f'maps-{edge}.json');assert mapped['pid']==pid and mapped['started_identity']==identity and mapped['ELF']==expected_files and not mapped['data']
  assert mapped['affinity']==[12] and mapped['exclusive_CPU'] is False
  assert all(mapped['identity'][k]==identity[k] for k in ('pid','start_time_ticks','parent_pid','session','process_group'))
  paths=set()
  for line in mapped['raw'].splitlines():
   f=line.split(None,5)
   if len(f)==6 and f[5].startswith('/'):
    assert not f[5].endswith(' (deleted)');paths.add(str(Path(f[5]).resolve()))
  assert paths==set(expected_files)
  for name,h in expected_files.items():assert digest(name)==h;allmapfiles[name]=h
 # A separate token pass independently joins every status/mask/state/input word
 # to the frozen, regenerated integer expected states and checks cohort controls.
 tags=collections.Counter();ids=[];accepted=refused=0
 for line in raw.decode().splitlines():
  f=line.split();tag=f[0];tags[tag]+=1
  if tag in ('DPWORD','QPWORD'):
   ident,mu=map(int,f[1:3]);key='dp_words' if tag=='DPWORD' else 'qp_words';assert f[3]==expected['cases'][str(ident)][key][mu]
  elif tag=='CASE':
   x=list(map(int,f[1:]));ident,mode,scenario=x[:3];row=expected['cases'][str(ident)];ids.append((ident,mode))
   assert row['scenario']==scenario and x[3:7]==[0,0,0,1]
   request=x[7:12];baseline=x[12:19];pre=x[19:26];post=x[26:33];restored=x[33:40];assert pre==post and baseline==restored
   if mode==0:assert request==[-1]*5 and pre==baseline
   else:
    flags=[1,4,8,16,32];rounding=[0,1024,2048,3072][mode-1] if mode<=4 else 0
    sticky=flags[mode-5] if 5<=mode<=9 else 61 if mode==10 else 0
    halts=flags[mode-11] if 11<=mode<=15 else 61 if mode==19 else 0
    ftz,daz={16:(1,0),17:(0,1),18:(1,1)}.get(mode,(-1,-1));assert request==[rounding,sticky,halts,ftz,daz] and pre[:3]==request[:3]
    if ftz>=0:assert (pre[5]>>15)&1==ftz and (pre[5]>>6)&1==daz
   for state in (baseline,pre,post,restored):
    rounding,sticky,halts,control,cw,csr,sw=state
    assert control==csr&~63 and sticky==(csr|sw)&61 and cw&3072==rounding==(csr>>3)&3072 and halts==(~cw)&61==(~(csr>>7))&61
  elif tag=='STATUS':
   ident,mode,count=map(int,f[1:4]);want=expected['cases'][str(ident)]['expected']['status'];actual=list(map(int,f[4:]));assert count==len(want) and actual==want;accepted+=sum(actual);refused+=len(actual)-sum(actual)
  elif tag=='MASK':
   ident,mode,width=map(int,f[1:4]);state=expected['cases'][str(ident)]['expected']['dp' if width==64 else 'qp'];assert list(map(int,f[4:]))==state['valid']+state['pending_valid']
  elif tag in ('REF','PENDING'):
   ident,mode,width,leg,mu=map(int,f[1:6]);state=expected['cases'][str(ident)]['expected']['dp' if width==64 else 'qp'];assert f[6:]==state['reference' if tag=='REF' else 'pending'][leg-1][mu]
 assert ids==[(i,m) for i in range(1,38) for m in range(20)] and tags['CASE']==tags['STATUS']==740 and tags['MASK']==1480
 assert tags['REF']==tags['PENDING']==11840 and tags['DPWORD']==tags['QPWORD']==148 and accepted+refused==1840
 details[variant]={'raw_sha256':RAW,'raw_bytes':len(raw),'cohort_observations':740,'accepted_module_calls':accepted,'refused_module_calls':refused,'module_call_outcomes':1840,'complete_state_words':47360,'raw_input_words':296,'ELF_maps_before_after_count':6,'pid':pid,'raw_record_counts':dict(tags)}
 counters.update(observations=740,calls=1840,words=47360,input_words=296)
assert (RUN/'checked/observations.txt').read_bytes()==(RUN/'optimized/observations.txt').read_bytes()
assert before=={str(p.relative_to(RUN)):digest(p) for p in RUN.rglob('*') if p.is_file()}
receipt={'schema':'independent-owned-snapshot-run2-audit-v1','status':'PASS','audit_source_sha256':digest(__file__),'source_index_sha256':SOURCE,'build_terminal_sha256':BUILD,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'raw_sha256':RAW,'variants':details,'totals':dict(counters),'checked_optimized_raw_byte_identical':True,'source_expected_corpus_regenerated':True,'strict_parser_replay_exact':True,'independent_token_state_input_fenv_join':True,'actual_ELF_provider_and_executable_hashes':allmapfiles,'actual_limits':limits['actual'],'recorded_stage_seconds':elapsed,'cap_seconds':180,'cleanup_reserve_seconds':60,'owned_identities':3,'survivors':[],'forbidden_process_native_API_attempts':len(attempts),'new_native_calls':0,'evidence_unchanged':True,'scope':'Observed standalone snapshot transport/lifecycle only for the frozen37cases/20actualfenvcohorts/twoGNUbuilds. All cohorts execute; exact statuses/masks/INTEGER128 state, finite input-bit transport/refusals and observed environment restoration pass. No actual constructor/canonical input origin/disjoint caller ownership/full-caller/q-at-use/final-dot/same-buffer precision-tag/scientific/performance qualification. No further native admission is conferred by this audit.','public_or_git_mutations':0,'elapsed_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_seconds'],'totals':dict(counters),'forbidden_attempts':len(attempts)}))
