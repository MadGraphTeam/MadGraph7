# Independent closed snapshot RUN data review

**PASS for the exact standalone fixture lane.** Both saved transcripts have
SHA-256 `6b75d55910c8f00b0ae10d9a52544913ea2dfa7cf20a477326eda69b32e2c31b`
and are byte-identical. Per variant, an independent stdlib-only data checker
verified all 740 case/cohort records, 1,840 returned API outcomes, 1,480 mask
records, and 47,360 reference/pending words against the pinned integer oracle.
There are no missing, duplicate, unknown, or skipped records.

Finite DP words retain signed zero/subnormal bits with zero high64 bits; QP
words retain the low 113th-significant-bit fixture. The selected nonfinite
inputs and pending corruption refuse atomically, and malformed-section results
preserve precisely the inaccessible dirty elements. These are observations of
the saved standalone test calls, not physical constructor execution.

Each variant also supplies 2,960 complete seven-field environment snapshots.
Every requested rounding/sticky/halting/FTZ/DAZ cohort executed. API fields agree
with x87/SSE bits and independently reconstructed full control words. Every
before/after snapshot is identical and every restoration equals its baseline.
The independent child audit obtained the same result and verified all four
saved READY/DONE endpoint maps against original identities, CPU12, and the five
reviewed providers plus each executable. Worker stderr is empty and all worker
and owning-stage return codes are zero; cleanup reports no observed survivors.

The checker reads existing files only. Reproduce without invoking target code:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/generic-owned-snapshot-qualification-run-state-review-1/review_states.py
```

Scope remains the 37 synthetic cases and 20 environments for the two exact
GNU build variants. Precision tags, source-column origin, actual constructor
return, generated caller lifetime, q-at-use/final-dot arithmetic, performance,
and scientific dispatch remain unqualified. This audit ran no target, compiler,
loader, native control API, or project module.
