"""Read existing integer RUN records only; no project imports or native calls."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / '.tirust-build/generic-owned-snapshot-qualification-proposal-2'
RUN = ROOT / '.tirust-build/generic-owned-snapshot-qualification-work-2/run'


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def check_environment(numbers, mode):
    baseline, before, after, restored = [numbers[start:start + 7] for start in (12, 19, 26, 33)]
    assert before == after and baseline == restored
    flags = [1, 4, 8, 16, 32]
    if mode == 0:
        request = [-1] * 5
        assert before == baseline
    else:
        rounding = [0, 1024, 2048, 3072][mode - 1] if mode <= 4 else 0
        sticky = flags[mode - 5] if 5 <= mode <= 9 else 61 if mode == 10 else 0
        halts = flags[mode - 11] if 11 <= mode <= 15 else 61 if mode == 19 else 0
        ftz, daz = {16: (1, 0), 17: (0, 1), 18: (1, 1)}.get(mode, (-1, -1))
        request = [rounding, sticky, halts, ftz, daz]
        assert before[:3] == request[:3]
        cw = (baseline[4] & ~(0x0c00 | 0x3f)) | rounding | (0x3f & ~halts)
        control = (baseline[5] & ~(0x3f | 0x6000 | 0x1f80)) | 0x1f80 | (rounding << 3)
        control &= ~(halts << 7)
        if ftz >= 0:
            control = (control & ~0x8040) | (ftz << 15) | (daz << 6)
        assert before[4] == cw and before[3] == control
    assert numbers[7:12] == request
    for rounding, sticky, halts, control, cw, csr, sw in (baseline, before, after, restored):
        assert rounding in (0, 1024, 2048, 3072)
        assert 0 <= sticky <= 61 and sticky & ~61 == 0
        assert 0 <= halts <= 61 and halts & ~61 == 0
        assert 0 <= cw < 1 << 16 and 0 <= csr < 1 << 32 and 0 <= sw < 1 << 16
        assert control == csr & ~63
        assert sticky == (csr | sw) & 61
        assert rounding == cw & 0x0c00 == (csr >> 3) & 0x0c00
        assert halts == (~cw) & 61 == (~(csr >> 7)) & 61


def review(path, expected):
    rows = [line.split() for line in path.read_text().splitlines()]
    assert all(rows)
    assert rows[0] == ['SCHEMA', 'owned-snapshot-fenv-v1']
    assert rows[1] == ['CONSTANTS', '0', '1024', '2048', '3072', '1', '4', '8', '16', '32', '61']
    assert rows[2] == ['NCASES', '37'] and rows[3] == ['MODES', '20']
    assert rows[-1] == ['DONE', '37']
    assert [row[0] for row in rows[:9]] == [
        'SCHEMA', 'CONSTANTS', 'NCASES', 'MODES', 'SNAPSHOT_FIELDS',
        'CASE_FIELDS', 'STATUS_FIELDS', 'MASK_FIELDS', 'WORD_FIELDS']
    seen = {tag: set() for tag in ('INPUT', 'DPWORD', 'QPWORD', 'CASE', 'STATUS', 'MASK', 'REF', 'PENDING')}
    count = Counter()
    calls = 0
    words = 0
    for row in rows[9:-1]:
        tag = row[0]
        assert tag in seen, ('unknown record', tag)
        count[tag] += 1
        identifier = int(row[1])
        assert 1 <= identifier <= 37
        case = expected['cases'][str(identifier)]
        if tag == 'INPUT':
            assert len(row) == 3 and int(row[2]) == case['scenario']
            key = identifier
        elif tag in ('DPWORD', 'QPWORD'):
            assert len(row) == 4
            mu = int(row[2]); assert 0 <= mu <= 3
            digits, field = (16, 'dp_words') if tag == 'DPWORD' else (32, 'qp_words')
            assert re.fullmatch('[0-9A-F]{' + str(digits) + '}', row[3])
            assert row[3] == case[field][mu]
            key = identifier, mu
        else:
            mode = int(row[2]); assert 0 <= mode <= 19
            if tag == 'CASE':
                assert len(row) == 41
                numbers = list(map(int, row[1:]))
                assert numbers[:3] == [identifier, mode, case['scenario']]
                assert numbers[3:7] == [0, 0, 0, 1]
                check_environment(numbers, mode)
                key = identifier, mode
            elif tag == 'STATUS':
                values = list(map(int, row[3:]))
                want = case['expected']['status']
                assert values == [len(want), *want]
                calls += len(want)
                key = identifier, mode
            elif tag == 'MASK':
                assert len(row) == 8
                width = int(row[3]); assert width in (64, 128)
                state = case['expected']['dp' if width == 64 else 'qp']
                assert list(map(int, row[4:])) == state['valid'] + state['pending_valid']
                key = identifier, mode, width
            else:
                assert len(row) == 8
                width, leg, mu = map(int, row[3:6])
                assert width in (64, 128) and 1 <= leg <= 2 and 0 <= mu <= 3
                assert all(re.fullmatch('[0-9A-F]{32}', word) for word in row[6:])
                state = case['expected']['dp' if width == 64 else 'qp']
                assert row[6:] == state['reference' if tag == 'REF' else 'pending'][leg - 1][mu]
                words += 2
                key = identifier, mode, width, leg, mu
        assert key not in seen[tag], ('duplicate record', tag, key)
        seen[tag].add(key)
    assert dict(count) == dict(INPUT=37, DPWORD=148, QPWORD=148, CASE=740, STATUS=740,
                               MASK=1480, REF=11840, PENDING=11840)
    assert calls == 1840 and words == 47360
    return dict(status='pass-existing-records-only', records=dict(count), observations=740,
                module_calls=1840, complete_integer_state_words=47360,
                all_input_echoes_statuses_masks_reference_pending_words_verified=True,
                full_environment_requests_hardware_equality_restoration_verified=True,
                complete_seven_field_environment_snapshots=2960,
                native_calls=0, project_imports=False)


def main():
    expected = json.loads((SOURCE / 'expectations.json').read_bytes())
    assert identity(SOURCE / 'expectations.json')['sha256'] == '283239e829f71f8baa0e3a9101857f805f03bdee5aa2ea0d3ed53a3d88d810de'
    results = {}
    for variant in ('checked', 'optimized'):
        path = RUN / variant / 'observations.txt'
        assert identity(path)['sha256'] == '6b75d55910c8f00b0ae10d9a52544913ea2dfa7cf20a477326eda69b32e2c31b'
        results[variant] = review(path, expected)
    assert results['checked'] == results['optimized']
    print(json.dumps(results, sort_keys=True))


if __name__ == '__main__':
    main()
