# Final dormant controller-2 source review

No blocking source issue remains in controller `bf281d5f` and ownership helper
`51ca38f0` within this bounded standalone lane. `INITIAL.md` retains the initial
findings; prior corrected controller bytes remain in the packet history. This
review imported or executed no reviewed Python, ran no preflight/tests/discovery,
and invoked no compiler, linker, loader, process controller, native driver or
scientific routine. Reviewed controller/helper and sealed-parent files were not
edited by this reviewer.

The original phase budget is now set before full source authentication and
preflight. BootstrapDeadline derives one absolute end from the original start;
the supervising StageDeadline and child admission retain that end. There is no
new allowance per command, variant, lock acquisition or child. The work cutoff
is 120 seconds, with the remaining 60 seconds reserved inside the 180-second
total. Launch-environment authentication is outside the process-handoff
deferral window. A deferred work alarm rearms the original hard end, and an
alarm at that end raises even if handoff remains active. The uncertainty marker
is set before that hard-end check, including a first alarm delivered late.
An interrupted handoff
without a captured process handle explicitly blocks continuation and cannot
be a successfully closed qualification.

Source-index authentication precedes local/support imports. The new index is
authoritative; inherited proposal-1 receipt/README/plans remain ancestor
evidence as stated in CONTROLLER.md. Imports authenticate their exact files.
Protected input verification retains the sealed snapshot proposal and pinned
toolchain/compiler hooks/providers. Fresh WORK2, stage and variant namespace
checks reject aliases and retries over failed work. The source check does not
constitute an actual preflight run or authentication of a future seal.

The child is bound to its recorded live original supervisor identity, phase,
argv, source hash and fresh session. Native commands check that supervisor and
the original work cutoff. Resource limits remain 4 GiB address space, 256 MiB
per file and zero core size; the child verifies their actual settings. CPU12 is
nonexclusive, tool jobs are serial, and the numerical mutex is inside supervised
work. Closed environment reconstruction strips the identified inherited Python,
Fortran, runtime, loader and compiler injections and supplies private temporary
storage without changing the original pinned compiler policy.

The independent delegated runtime read confirms the required order: prelink
binding and explicit original five-provider join, actual linker-map check, pure
ELF derivation, exact five-provider comparison, then the bound interpreter's
listing. A new quadmath/profile provider cannot widen this lane after a failure.
RUN verifies exactly the checked/O3 variants, owned executable/object/proof
paths, flags, hashes, rederived closure and the same provider map. READY/DONE
checks authenticate the live native PID/start identity, parent/session/group,
actual executable, exact provider mappings and CPU affinity before GO and
after the module calls. The unchanged strict parser binds all frozen state
outputs; equal deterministic replay summaries do not confer scientific scope.

The retained native-worker handle is now closed on failure before fallible
evidence reads, formatting or writes. Live-worker stop checks original
parent/session/group/start identity and uses bounded terminate/kill/wait. If
that closure fails, an unconditional finally path stops only the authenticated
stage's own fresh group, even if evidence I/O also fails. This relies on the
exact pinned standalone driver/observer's no-spawn/no-session-escape scope; it
is not a general process-tree claim. All such paths fail the phase and retain
uncertainty rather than permitting a later stage or qualification pass.

The reviewed new pure-test definitions cover original-deadline propagation,
120→180 handoff rearm/hard failure, no environment hash inside handoff, retained
worker stop ordering, and evidence-failure fail-stop. This reviewer did not run
those tests or inherit their results as native evidence.

The controller remains dormant. Exact source review is not BUILD/RUN admission;
RUN additionally needs a separately reviewed successful actual BUILD terminal.
Actual compiler/loader/runtime behavior, standalone transport results, compiler
ABI, constructor/caller ownership, full lifetime, physical q/dot behavior,
performance and scientific dispatch remain unqualified by this source audit.
