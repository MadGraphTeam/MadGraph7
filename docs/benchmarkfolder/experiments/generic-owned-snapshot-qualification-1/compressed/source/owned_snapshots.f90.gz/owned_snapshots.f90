! PRIVATE SOURCE ONLY: not compiled, linked, or runtime/caller qualified.
! Caller owns all reference/pending arrays and masks as disjoint local objects.
! Prepare accepts only source-bound canonical P(0:3,leg)/MP_P(0:3,leg) views.
! A matching commit must follow the actual normal constructor return in source.
! No W/derived reference, floating negation, allocation, mutable module state,
! external/native call, or claim about global producer/environment purity.
module ml_private_owned_snapshots
  implicit none
  private
  integer, parameter, public :: snapshot_ik=selected_int_kind(33)
  integer, parameter, public :: snapshot_dp=kind(0.0d0)
  integer, parameter, public :: snapshot_qp=selected_real_kind(33,4931)
  integer, parameter, public :: snapshot_max_external=64
  integer, parameter :: snapshot_i64=selected_int_kind(18)
  integer, parameter :: format_assert=1/merge(1,0, &
      bit_size(0_snapshot_ik)==128.and.bit_size(0_snapshot_i64)==64.and.bit_size(0)==32.and. &
      storage_size(0.0_snapshot_dp)==64.and.radix(0.0_snapshot_dp)==2.and. &
      digits(0.0_snapshot_dp)==53.and.maxexponent(0.0_snapshot_dp)==1024.and. &
      minexponent(0.0_snapshot_dp)==-1021.and. &
      storage_size(0.0_snapshot_qp)==128.and.radix(0.0_snapshot_qp)==2.and. &
      digits(0.0_snapshot_qp)==113.and.maxexponent(0.0_snapshot_qp)==16384.and. &
      minexponent(0.0_snapshot_qp)==-16381)
  integer(snapshot_ik), parameter :: low64_mask=int(z'FFFFFFFFFFFFFFFF',snapshot_ik)
  logical, parameter, public :: snapshot_runtime_abi_qualified=.false.
  logical, parameter, public :: snapshot_full_caller_qualified=.false.
  logical, parameter, public :: snapshot_scientific_dispatch_enabled=.false.
  public :: owned_reset_dp,owned_reset_qp,owned_prepare_dp,owned_prepare_qp
  public :: owned_commit_dp,owned_commit_qp
contains
  logical function storage_shape(reference,valid,pending,pending_valid) result(ok)
    integer(snapshot_ik), intent(in) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(in) :: valid(:),pending_valid(:)
    integer :: n
    n=size(reference,3)
    ok=size(reference,1)==2.and.size(reference,2)==4.and. &
       n>=1.and.n<=snapshot_max_external.and.size(valid)==n.and. &
       size(pending,1)==2.and.size(pending,2)==4.and. &
       size(pending,3)==n.and.size(pending_valid)==n
    if(.not.ok) return
    ok=is_contiguous(reference).and.is_contiguous(pending).and. &
       is_contiguous(valid).and.is_contiguous(pending_valid)
  end function

  subroutine reset_storage(reference,valid,pending,pending_valid,ok)
    integer(snapshot_ik), intent(out) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(out) :: valid(:),pending_valid(:),ok
    reference=0_snapshot_ik
    pending=0_snapshot_ik
    valid=.false.
    pending_valid=.false.
    ok=storage_shape(reference,valid,pending,pending_valid)
  end subroutine

  subroutine clear_leg(leg,reference,valid,pending,pending_valid)
    integer, intent(in) :: leg
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    ! Private callers have already checked every array shape and this index.
    valid(leg)=.false.
    pending_valid(leg)=.false.
    reference(:,:,leg)=0_snapshot_ik
    pending(:,:,leg)=0_snapshot_ik
  end subroutine

  integer(snapshot_ik) function dp_scalar_bits(value) result(bits)
    real(snapshot_dp), intent(in) :: value
    integer(snapshot_i64) :: native_word
    ! Equal-size scalar transfer first. INT alone would sign-extend negative
    ! INT64 words; the mask supplies the required unsigned 64->128 transport.
    native_word=transfer(value,0_snapshot_i64)
    bits=iand(int(native_word,snapshot_ik),low64_mask)
  end function

  integer(snapshot_ik) function qp_scalar_bits(value) result(bits)
    real(snapshot_qp), intent(in) :: value
    ! Matching 128-bit mold; genuine QP is a separate prepare/commit gate.
    bits=transfer(value,0_snapshot_ik)
  end function

  logical function finite_word(bits,width) result(ok)
    integer(snapshot_ik), intent(in) :: bits
    integer, intent(in) :: width
    ok=.false.
    select case(width)
    case(64)
      if(ishft(bits,-64)/=0_snapshot_ik) return
      if(ibits(bits,52,11)==2047_snapshot_ik) return
    case(128)
      if(ibits(bits,112,15)==32767_snapshot_ik) return
    case default
      return
    end select
    ok=.true.
  end function

  subroutine owned_reset_dp(reference,valid,pending,pending_valid,ok)
    integer(snapshot_ik), intent(out) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(out) :: valid(:),pending_valid(:),ok
    call reset_storage(reference,valid,pending,pending_valid,ok)
  end subroutine

  subroutine owned_reset_qp(reference,valid,pending,pending_valid,ok)
    integer(snapshot_ik), intent(out) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(out) :: valid(:),pending_valid(:),ok
    call reset_storage(reference,valid,pending,pending_valid,ok)
  end subroutine

  subroutine owned_prepare_dp(leg,column,reference,valid,pending,pending_valid,ok)
    integer, intent(in) :: leg
    real(snapshot_dp), intent(in) :: column(0:)
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    logical, intent(out) :: ok
    integer(snapshot_ik) :: staged(0:3)
    integer :: mu
    logical :: ignored
    ok=.false.
    if(.not.storage_shape(reference,valid,pending,pending_valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    if(leg<1.or.leg>size(valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    call clear_leg(leg,reference,valid,pending,pending_valid)
    if(size(column)/=4.or..not.is_contiguous(column)) return
    do mu=0,3
      staged(mu)=dp_scalar_bits(column(mu))
      if(.not.finite_word(staged(mu),64)) return
    enddo
    pending(1,:,leg)=staged
    pending(2,:,leg)=0_snapshot_ik
    pending_valid(leg)=.true.
    ok=.true.
  end subroutine

  subroutine owned_prepare_qp(leg,column,reference,valid,pending,pending_valid,genuine_qp,ok)
    integer, intent(in) :: leg
    real(snapshot_qp), intent(in) :: column(0:)
    logical, intent(in) :: genuine_qp
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    logical, intent(out) :: ok
    integer(snapshot_ik) :: staged(0:3)
    integer :: mu
    logical :: ignored
    ok=.false.
    if(.not.genuine_qp) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    if(.not.storage_shape(reference,valid,pending,pending_valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    if(leg<1.or.leg>size(valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    call clear_leg(leg,reference,valid,pending,pending_valid)
    if(size(column)/=4.or..not.is_contiguous(column)) return
    do mu=0,3
      staged(mu)=qp_scalar_bits(column(mu))
      if(.not.finite_word(staged(mu),128)) return
    enddo
    pending(1,:,leg)=staged
    pending(2,:,leg)=0_snapshot_ik
    pending_valid(leg)=.true.
    ok=.true.
  end subroutine

  subroutine commit_storage(width,leg,genuine,reference,valid,pending,pending_valid,ok)
    integer, intent(in) :: width,leg
    logical, intent(in) :: genuine
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    logical, intent(out) :: ok
    integer :: mu
    logical :: ignored
    ok=.false.
    if(.not.genuine.or.(width/=64.and.width/=128)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    if(.not.storage_shape(reference,valid,pending,pending_valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    if(leg<1.or.leg>size(valid)) then
      call reset_storage(reference,valid,pending,pending_valid,ignored)
      return
    endif
    valid(leg)=.false.
    if(.not.pending_valid(leg)) then
      call clear_leg(leg,reference,valid,pending,pending_valid)
      return
    endif
    do mu=0,3
      if(.not.finite_word(pending(1,mu,leg),width).or.pending(2,mu,leg)/=0_snapshot_ik) then
        call clear_leg(leg,reference,valid,pending,pending_valid)
        return
      endif
    enddo
    reference(:,:,leg)=pending(:,:,leg)
    pending(:,:,leg)=0_snapshot_ik
    pending_valid(leg)=.false.
    valid(leg)=.true.
    ok=.true.
  end subroutine

  subroutine owned_commit_dp(leg,reference,valid,pending,pending_valid,ok)
    integer, intent(in) :: leg
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    logical, intent(out) :: ok
    call commit_storage(64,leg,.true.,reference,valid,pending,pending_valid,ok)
  end subroutine

  subroutine owned_commit_qp(leg,reference,valid,pending,pending_valid,genuine_qp,ok)
    integer, intent(in) :: leg
    logical, intent(in) :: genuine_qp
    integer(snapshot_ik), intent(inout) :: reference(:,0:,:),pending(:,0:,:)
    logical, intent(inout) :: valid(:),pending_valid(:)
    logical, intent(out) :: ok
    call commit_storage(128,leg,genuine_qp,reference,valid,pending,pending_valid,ok)
  end subroutine
end module ml_private_owned_snapshots
