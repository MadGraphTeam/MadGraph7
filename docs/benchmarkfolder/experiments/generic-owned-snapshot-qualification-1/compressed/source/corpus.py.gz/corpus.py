"""Small independent raw-word corpus for a dormant standalone snapshot unit."""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-snapshot-source-1'
EXPECTED_PARENT='a953bc69888029ceae35d576f9c5557cf046d283b89daa6cad3cfce24aec7011'


def need(value,reason):
    if not value:raise ValueError(reason)


receipt_bytes=(PARENT/'source-receipt.json').read_bytes()
need(hashlib.sha256(receipt_bytes).hexdigest()==EXPECTED_PARENT,'snapshot source ancestor changed')
receipt=json.loads(receipt_bytes)
spec_path=PARENT/'snapshots_spec.py';spec_data=spec_path.read_bytes()
need(dict(bytes=len(spec_data),sha256=hashlib.sha256(spec_data).hexdigest())==receipt['payloads']['snapshots_spec.py'],
     'frozen independent snapshot specification changed')
import sys
spec=importlib.util.spec_from_file_location('owned_snapshot_unit_reference',spec_path)
reference=importlib.util.module_from_spec(spec);sys.modules[spec.name]=reference;spec.loader.exec_module(reference)

DIRTY=dict(dp_reference=int('11'*16,16),dp_pending=int('22'*16,16),
           qp_reference=int('33'*16,16),qp_pending=int('44'*16,16))
SCENARIOS={1:'reset_both',2:'dp_prepare_only',3:'dp_commit',4:'qp_prepare_only',5:'qp_commit',
6:'dp_duplicate_commit',7:'qp_duplicate_commit',8:'dp_commit_reset',9:'qp_commit_reset',
10:'qp_prepare_not_genuine',11:'qp_commit_not_genuine',12:'dp_prepare_bad_leg0',13:'qp_prepare_bad_leg3',
14:'dp_commit_bad_leg3',15:'qp_commit_bad_leg0',16:'dp_short_column',17:'qp_noncontiguous_column',
18:'dp_prepare_bad_reference_shape',19:'qp_commit_bad_pending_shape',20:'dp_reset_bad_reference_shape',
21:'qp_reset_bad_valid_shape',22:'dp_pending_excess_bits',23:'dp_pending_imaginary',
24:'qp_pending_infinity',25:'qp_pending_imaginary',26:'dp_commit_then_qp_reset',27:'qp_commit_then_dp_reset'}
DEFAULT_DP=[0x8000000000000000,0x8000000000000001,0x7fefffffffffffff,0xbff0000000000000]
DEFAULT_QP=[1<<127,(1<<127)|1,(0x3fff<<112)|1,(0x7ffe<<112)|((1<<112)-1)]


def dirty(width):
    state=reference.SnapshotState(width,2);prefix='dp' if width==64 else 'qp'
    state.reference=[[[DIRTY[prefix+'_reference']]*2 for _ in range(4)] for _ in range(2)]
    state.pending=[[[DIRTY[prefix+'_pending']]*2 for _ in range(4)] for _ in range(2)]
    state.valid=[True,True];state.pending_valid=[True,True]
    return state


def export(state):
    return dict(valid=[int(x) for x in state.valid],pending_valid=[int(x) for x in state.pending_valid],
        reference=[[[format(word,'032X') for word in pair] for pair in column] for column in state.reference],
        pending=[[[format(word,'032X') for word in pair] for pair in column] for column in state.pending])


def expect(scenario,dp_words,qp_words):
    """Reuse frozen integer specification; malformed views have explicit slice expectations.

    Direct-column origin, lower bounds and width tags are caller metadata in
    that specification; no native claim is made for those unobservable checks.
    """
    need(scenario in SCENARIOS,'unknown bounded unit scenario')
    dp,qp=dirty(64),dirty(128);status=[]
    def call(result):status.append(int(result['ok']))
    def prepare(state,words,**kw):return state.prepare(1,reference.ColumnView.canonical(state.width,words),**kw)
    if scenario==1:call(dp.reset());call(qp.reset())
    elif scenario in (2,3,6,8,22,23,26):
        call(dp.reset());call(prepare(dp,dp_words))
        if scenario==22:dp.pending[0][0][0]|=1<<64
        if scenario==23:dp.pending[0][0][1]=1
        if scenario!=2:call(dp.commit(1))
        if scenario==6:call(dp.commit(1))
        if scenario==8:call(dp.reset())
        if scenario==26:call(qp.reset())
    elif scenario in (4,5,7,9,24,25,27):
        call(qp.reset());call(prepare(qp,qp_words))
        if scenario==24:qp.pending[0][0][0]=0x7fff<<112
        if scenario==25:qp.pending[0][0][1]=1
        if scenario!=4:call(qp.commit(1))
        if scenario==7:call(qp.commit(1))
        if scenario==9:call(qp.reset())
        if scenario==27:call(dp.reset())
    elif scenario==10:call(prepare(qp,qp_words,genuine_qp=False))
    elif scenario==11:call(qp.commit(1,genuine_qp=False))
    elif scenario==12:call(dp.prepare(0,reference.ColumnView.canonical(64,dp_words)))
    elif scenario==13:call(qp.prepare(3,reference.ColumnView.canonical(128,qp_words)))
    elif scenario==14:call(dp.commit(3))
    elif scenario==15:call(qp.commit(0))
    elif scenario==16:
        call(dp.reset());call(dp.prepare(1,reference.ColumnView.canonical(64,dp_words[:3])))
    elif scenario==17:
        call(qp.reset());call(qp.prepare(1,reference.ColumnView.canonical(128,qp_words,contiguous=False)))
    elif scenario==18:
        # Provided ref first-dimension slice is 1:1, while all other arrays are
        # full. Reset defines only supplied elements, never inaccessible storage.
        for column in dp.reference:
            for pair in column:pair[0]=0
        dp.pending=[reference.zero_column() for _ in range(2)]
        dp.valid=[False,False];dp.pending_valid=[False,False];status.append(0)
    elif scenario==19:
        # Provided pending third-dimension slice contains only leg1.
        qp.reference=[reference.zero_column() for _ in range(2)];qp.pending[0]=reference.zero_column()
        qp.valid=[False,False];qp.pending_valid=[False,False];status.append(0)
    elif scenario==20:
        for column in dp.reference:
            for mu in range(3):column[mu]=[0,0]
        dp.pending=[reference.zero_column() for _ in range(2)]
        dp.valid=[False,False];dp.pending_valid=[False,False];status.append(0)
    elif scenario==21:
        qp.reference=[reference.zero_column() for _ in range(2)];qp.pending=[reference.zero_column() for _ in range(2)]
        qp.valid=[False,True];qp.pending_valid=[False,False];status.append(0)
    return dict(status=status,dp=export(dp),qp=export(qp))


def cases():
    rows=[]
    def add(scenario,tag,dp=DEFAULT_DP,qp=DEFAULT_QP):
        rows.append(dict(id=len(rows)+1,scenario=scenario,tag=tag,
            dp_words=[format(word,'016X') for word in dp],qp_words=[format(word,'032X') for word in qp],
            expected=expect(scenario,dp,qp)))
    for scenario,tag in SCENARIOS.items():add(scenario,tag)
    add(3,'dp_positive_zero_normal_minimal_normal',[0,0x3ff0000000000001,0x0010000000000000,0xffefffffffffffff])
    add(5,'qp_positive_zero_minimal_normal_low_113th_bit',qp=[0,1<<112,(0x3fff<<112)|1,(1<<127)|(0x3fff<<112)|1])
    for mu,(name,word) in enumerate((('positive_infinity',0x7ff0000000000000),('negative_infinity',0xfff0000000000000),
                                   ('signaling_nan',0x7ff0000000000001),('quiet_nan',0x7ff8000000000123))):
        words=list(DEFAULT_DP);words[mu]=word;add(3,'dp_refuse_'+name+'_component'+str(mu),dp=words)
    for mu,(name,word) in enumerate((('positive_infinity',0x7fff<<112),('negative_infinity',(1<<127)|(0x7fff<<112)),
                                   ('signaling_nan',(0x7fff<<112)|1),('quiet_nan',(0x7fff<<112)|(1<<111)|0x123))):
        words=list(DEFAULT_QP);words[mu]=word;add(5,'qp_refuse_'+name+'_component'+str(mu),qp=words)
    need(len(rows)==37,'bounded unit corpus changed unexpectedly')
    return rows


def render(rows):
    output=[str(len(rows))]
    for row in rows:output.extend([str(row['id'])+' '+str(row['scenario']),*row['dp_words'],*row['qp_words']])
    return '\n'.join(output)+'\n'


def generate():
    rows=cases();fixture=render(rows)
    (HERE/'fixtures.hex').write_text(fixture)
    expected=dict(schema='owned-snapshot-unit-expectations-v1',case_count=len(rows),mode_count=20,
        dirty_words={key:format(word,'032X') for key,word in DIRTY.items()},scenarios=SCENARIOS,
        input_sha256=hashlib.sha256(fixture.encode()).hexdigest(),cases={str(row['id']):row for row in rows},
        no_runtime_precision_tag=True,canonical_column_and_ownership_are_caller_preconditions=True,
        actual_constructor_completion_qualified=False,native_snapshot_transport_qualified=False,
        q_at_use_lowering_qualified=False,final_dot_runtime_qualified=False,full_caller_qualified=False,
        scientific_dispatch_enabled=False)
    (HERE/'expectations.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n')
    return expected


if __name__=='__main__':
    import sys
    sys.path.insert(0,str(PARENT));from source_guard import SourceAudit
    audit=SourceAudit(HERE,ROOT);sys.addaudithook(audit)
    expected=generate();need(not audit.attempts,'source corpus crossed execution boundary')
    print(json.dumps(dict(cases=expected['case_count'],cohorts=20,forbidden_api_attempts=audit.attempts,
        compiler_calls=0,native_calls=0,scientific_dispatch_enabled=False),sort_keys=True))
