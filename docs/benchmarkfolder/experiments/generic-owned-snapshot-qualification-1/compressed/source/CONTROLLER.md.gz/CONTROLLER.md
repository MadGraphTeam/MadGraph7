# Dormant snapshot BUILD/RUN controller successor

This successor preserves all 31 source payloads from sealed proposal1
`faae6af3…`, including its exact module, observer, driver, fixtures and oracle.
Its new source-index.json and controller.py govern execution preparation.
Inherited README/JSON plans/source-receipt remain ancestor evidence; their old
work-1 paths and planning caps do not replace this successor's controller.

No compiler, linker, loader or snapshot executable is admitted or run by preparing
this packet. The executable controller requires the exact reviewed source-index
SHA. RUN additionally requires a separately reviewed successful BUILD terminal
SHA. Pure preflight reads hashes, source fixtures and pinned tool/provider files;
it does not query a tool/loader, launch a process, acquire the numerical mutex,
or create an execution directory.

The controller reuses the qualified integer-helper ownership, tool environment,
linker/runtime verification and native handshakes. Ownership carries the original
absolute deadline and retains its hard-end alarm during handoff deferral.
A bootstrap alarm starts before
the first full source authentication. One original 180-second cap per admitted
phase covers authentication, support imports, source preflight, namespace setup,
mutex wait, both variants, compilers/listing or native handshakes, and cleanup.
The work cutoff is 120 seconds with 60 seconds reserved for cleanup. Child
admission carries the same monotonic deadline; no command or variant restarts it.

Both stages use 4 GiB address space, 256 MiB per-file size, zero core size,
CPU12 nonexclusive, serial tools and the existing numerical-tests.lock. Closed
environment reconstruction retains the pinned compiler policy, removes ambient
Python/Fortran/loader/runtime injections and uses a private stage TMPDIR. The
child runs isolated Python and must match its live original supervisor identity,
exact argv, phase and fresh session. Direct --child execution is rejected.

BUILD compiles the unchanged module, existing observer and driver in checked
and O3 variants. Before link, all original five standalone providers are bound.
The actual link map and pure ELF closure must agree with that exact five-provider
set before any PT_INTERP --list query. No profile or new quadmath provider is
added after a failure. The actual six snapshot API exports must be unique, and
the module may not introduce floating/environment helper dependencies.

RUN authenticates exact BUILD variant/object/proof paths, hashes, compiler flags,
runtime providers and successful cleanup. Each native worker pauses at READY
and DONE while its original PID/start ticks/parent/session/group, executable,
actual runtime mappings and CPU affinity are checked. Both variants must pass
the unchanged strict 37-case ×20-cohort parser against the same frozen oracle.
Its deterministic full-state replay summaries must agree.

On native failure, the retained worker is closed using start-identity checks and
bounded terminate/kill/wait before evidence I/O or stage exit. Unresolved worker
closure triggers a failure-only stop of the authenticated stage's own fresh
group, even if evidence writing fails. The exact pinned driver/observer cannot
escape that session/group. This avoids orphaning an unrecorded worker; it never
targets process names or unrelated groups. Failures remain in the fresh work-2
namespace and are not retried.

Pure controller tests exercise real source-only preflight, mocked build ordering,
five-provider rejection, exact BUILD joins, direct/stale child rejection, reused
PID rejection, deadline propagation and cleanup despite evidence failures.
Compiler, loader, process launch/control and native APIs are blocked during the
tests. Prior findings and corrected controller bytes are retained under history
and independent audit folders.

Only source preflight is available before a later explicit admission:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B -I .tirust-build/generic-owned-snapshot-qualification-proposal-2/controller.py --preflight --phase build --source REVIEWED_SOURCE_INDEX_SHA256
```

Future separately admitted stages use --execute --phase build, or --execute
--phase run with --reviewed-build EXACT_BUILD_TERMINAL_SHA256. These are dormant
interfaces, not current execution authorization. Standalone unit transport,
physical constructor/caller ownership, q/dot/IEEE amplitude behavior, performance
and scientific qualification remain unclaimed.
