"""Pure controller admission/closure/identity regressions; all native APIs denied."""
from pathlib import Path
import ast
import copy
import json
import types
import time
import unittest
from unittest.mock import patch,Mock

import controller as c
import corpus
import tool_environment
import unit_runtime
import ownership

HERE=Path(__file__).resolve().parent


class SnapshotController(unittest.TestCase):
    def setUp(self):
        self.previous=(c.EXPECTED_SOURCE,c.REVIEWED_BUILD,c.PHASE,c.SUPERVISOR,c.ABSOLUTE_END)
        c.EXPECTED_SOURCE=c.digest(HERE/'source-index.json');c.REVIEWED_BUILD=None;c.PHASE='build';c.SUPERVISOR=None
        c.ABSOLUTE_END=time.monotonic()+180.
        self.pin=json.loads((HERE/'input-pins.json').read_text())

    def tearDown(self):
        c.EXPECTED_SOURCE,c.REVIEWED_BUILD,c.PHASE,c.SUPERVISOR,c.ABSOLUTE_END=self.previous

    def test_actual_pure_preflight_queries_no_tool_loader_or_native_program(self):
        # The test runner denies subprocess, exec and native loading globally.
        value=c.preflight()
        self.assertEqual(value['compiler_or_loader_queries'],0)
        self.assertEqual(value['native_executions'],0)
        self.assertEqual(value['protected']['pinned_runtime_providers'],5)
        self.assertFalse(value['CPU_reserved'])
        self.assertFalse((c.WORK/'build').exists())

    def test_dynamic_imports_reject_unreviewed_source_before_loading(self):
        c.EXPECTED_SOURCE='0'*64
        with patch.object(c,'load') as load:
            for action in (lambda:c.local('ownership'),lambda:c.support(c.CLEANUP_PATH)):
                with self.assertRaisesRegex(ValueError,'reviewed source'):action()
            load.assert_not_called()

    def test_closed_environment_removes_startup_runtime_and_compiler_injections(self):
        with patch.object(c,'local',return_value=tool_environment),patch.dict(c.os.environ,{
            'PYTHONPATH':'/bad','PYTHONHOME':'/bad','PYTHONSTARTUP':'/bad','GFORTRAN_CONVERT_UNIT':'big_endian',
            'GFORTRAN_UNBUFFERED_ALL':'1','GLIBC_TUNABLES':'bad','LOCPATH':'/bad','DEPENDENCIES_OUTPUT':'/bad',
            'LD_PRELOAD':'/bad','FFLAGS':'-ffast-math','NIX_LDFLAGS':'bad'},clear=True):
            env=c.environment()
        for name in ('PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','GFORTRAN_CONVERT_UNIT','GFORTRAN_UNBUFFERED_ALL',
                     'GLIBC_TUNABLES','LOCPATH','DEPENDENCIES_OUTPUT','FFLAGS'):
            self.assertNotIn(name,env)
        self.assertEqual(env['LD_PRELOAD'],'');self.assertEqual(env['LD_LIBRARY_PATH'],'')
        self.assertEqual(env['TMPDIR'],str(c.WORK/'build/tmp'))

    def test_original_five_providers_are_bound_before_link_and_never_replaced(self):
        bound={'bound':{}}
        with patch.object(c,'digest',side_effect=lambda name:self.pin['files'][str(name)]):
            c.bind_standalone_runtime(bound)
        self.assertEqual(bound['bound'],self.pin['files'])
        self.assertEqual(bound['explicit_standalone_runtime_join_before_link'],self.pin['files'])
        name=next(iter(self.pin['files']));conflict={'bound':{name:'bad'}}
        with self.assertRaisesRegex(ValueError,'conflict'),patch.object(c,'digest',side_effect=lambda n:self.pin['files'][str(n)]):
            c.bind_standalone_runtime(conflict)

    def test_missing_extra_or_profile_runtime_is_not_the_expected_unit_closure(self):
        for change in ('missing','extra','wrong'):
            files=dict(self.pin['files'])
            if change=='missing':files.pop(next(iter(files)))
            elif change=='extra':files['/profile/libquadmath.so.0']='0'*64
            else:files[next(iter(files))]='0'*64
            with self.assertRaises(ValueError):unit_runtime.validate_expected({'files':files},self.pin['files'])
        changed=copy.deepcopy(self.pin);changed['runtime_before_link_augmentation'].pop(next(iter(changed['files'])))
        with patch.object(c,'read',return_value=changed),self.assertRaisesRegex(ValueError,'five-provider'):
            c.bind_standalone_runtime({'bound':{}})

    def test_mocked_BUILD_rejects_extra_provider_before_any_loader_query(self):
        trace=[];old_digest=c.digest;old_read_text=Path.read_text
        runtime=types.SimpleNamespace(derive=lambda *args:{'files':{**self.pin['files'],'/profile/extra.so':'0'*64}},
                                      validate_expected=unit_runtime.validate_expected)
        loader=types.SimpleNamespace(prelink=lambda *args:{'bound':{}},requireactualmap=lambda *args:{},
            query_runtime=Mock(side_effect=AssertionError('loader query must not happen')))
        def command(argv,cwd,logs,label):trace.append(label);return 'GNU 15.2.0'
        def digest(path):
            return old_digest(path) if str(path) in self.pin['files'] else '0'*64
        def read_text(path,*args,**kwargs):
            return 'LOAD test.o\n' if path.name=='link.map' else old_read_text(path,*args,**kwargs)
        with patch.object(c,'command',side_effect=command),patch.object(c,'support',return_value=loader),\
             patch.object(c,'local',return_value=runtime),patch.object(c,'environment',return_value={}),\
             patch.object(c,'dump'),patch.object(c,'digest',side_effect=digest),\
             patch.object(Path,'mkdir'),patch.object(Path,'read_text',read_text):
            with self.assertRaisesRegex(ValueError,'runtime differs'):c.build_locked(c.WORK/'build')
        loader.query_runtime.assert_not_called()
        self.assertIn('checked-link',trace)
        self.assertNotIn('optimized-module-compile',trace)

    def test_build_source_orders_prebind_map_exact_closure_then_loader(self):
        source=(HERE/'controller.py').read_text();tree=ast.parse(source)
        function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='build_locked')
        calls=[(node.lineno,ast.unparse(node.func),[ast.unparse(arg) for arg in node.args])
               for node in ast.walk(function) if isinstance(node,ast.Call)]
        def line(name):return min(row[0] for row in calls if row[1]==name)
        link=min(row[0] for row in calls if row[1]=='command' and row[2][0]=='link')
        self.assertLess(line('loader.prelink'),line('bind_standalone_runtime'))
        self.assertLess(line('bind_standalone_runtime'),link)
        self.assertLess(link,line('loader.requireactualmap'))
        self.assertLess(line('loader.requireactualmap'),line('runtime.derive'))
        self.assertLess(line('runtime.validate_expected'),line('loader.query_runtime'))
        self.assertIn("for operation in ('reset', 'prepare', 'commit')",ast.unparse(function))
        self.assertNotIn('__ml_private_exact_geometry_MOD_exact_geometry_difference',source)

    def test_RUN_requires_separate_successfully_reviewed_BUILD_terminal(self):
        c.PHASE='run'
        with patch.object(c,'work_namespace'),patch.object(Path,'is_dir',return_value=True),\
             patch.object(Path,'is_symlink',return_value=False),patch.object(Path,'resolve',lambda self:self):
            with self.assertRaisesRegex(ValueError,'reviewed BUILD'):c.verify_build()

    def verify_fake_build(self,mutate):
        checksum='b'*64;c.PHASE='run';c.REVIEWED_BUILD=checksum
        variants={name:dict(path=str(c.WORK/'build'/name/'check'),sha256=checksum,flags=flags,
            objects={'owned_snapshots.o':checksum,'driver.o':checksum},prelink_sha256=checksum,
            link_map_sha256=checksum,static_runtime_sha256=checksum,actual_link_loads={},
            runtime={'files':dict(self.pin['files'])}) for name,flags in c.VARIANTS.items()}
        result=dict(source_index_sha256=c.EXPECTED_SOURCE,module_sha256=checksum,fenv_object_sha256=checksum,variants=variants)
        closed=dict(status='passed',returncode=0,cleanup={'survivors':[]},result_sha256=checksum)
        mutate(result,closed)
        def read(path):
            name=Path(path).name
            if name=='terminal.json':return closed
            if name=='result.json':return result
            if name=='input-pins.json':return self.pin
            if name=='prelink.json':return {'bound':self.pin['files']}
            if name=='static-runtime.json':return {'files':self.pin['files']}
            raise AssertionError(name)
        runtime=types.SimpleNamespace(derive=lambda *args:{'files':self.pin['files']},validate_expected=unit_runtime.validate_expected)
        with patch.object(c,'work_namespace'),patch.object(c,'read',side_effect=read),\
             patch.object(c,'digest',return_value=checksum),patch.object(c,'local',return_value=runtime),\
             patch.object(Path,'is_dir',return_value=True),patch.object(Path,'is_symlink',return_value=False),\
             patch.object(Path,'resolve',lambda self:self):
            c.verify_build()

    def test_reviewed_BUILD_rejects_variant_object_path_flag_or_cleanup_drift(self):
        changes=[lambda result,closed:result['variants'].pop('optimized'),
            lambda result,closed:result['variants']['checked']['objects'].update({'exact_geometry.o':'b'*64}),
            lambda result,closed:result['variants']['checked'].update(path='/unowned/check'),
            lambda result,closed:result['variants']['checked'].update(flags=['-Ofast']),
            lambda result,closed:closed.update(status='failed'),
            lambda result,closed:closed['cleanup'].update(survivors=[12]),
            lambda result,closed:result.update(source_index_sha256='a'*64)]
        for change in changes:
            with self.subTest(change=change),self.assertRaises(ValueError):self.verify_fake_build(change)

    def test_child_rejects_direct_or_stale_parent_before_limits_mutex_or_tools(self):
        with patch.object(c,'verify_source'),patch.object(c,'work_namespace'),patch.object(c,'read',return_value={
            'phase':'build','source_index_sha256':c.EXPECTED_SOURCE,'reviewed_build_sha256':None}),\
             patch.object(c,'set_limits') as limits,patch.object(c,'build_locked') as build:
            with self.assertRaisesRegex(ValueError,'Direct or mismatched'):c.child()
            limits.assert_not_called();build.assert_not_called()
        with patch.object(c,'support',return_value=types.SimpleNamespace(matches=lambda row:False)),\
             patch.object(c.os,'getppid',return_value=17):
            c.SUPERVISOR={'pid':17}
            with self.assertRaisesRegex(ValueError,'supervisor identity'):c.require_supervisor()

    def test_reused_PID_with_changed_starttick_is_rejected_before_GO_or_EXIT(self):
        cleanup=types.SimpleNamespace(matches=lambda row:False)
        process=types.SimpleNamespace(pid=43,poll=lambda:None)
        with patch.object(c,'support',return_value=cleanup):
            with self.assertRaisesRegex(ValueError,'identity changed'):c.mapped(process,{},dict(pid=43,start_time_ticks=1))

    def test_fresh_namespace_does_not_retry_an_existing_stage(self):
        with patch.object(c,'verify_source',return_value={}),patch.object(c,'work_namespace'),\
             patch.object(c.os,'sched_getaffinity',return_value={12}),patch.object(Path,'exists',return_value=True):
            with self.assertRaisesRegex(ValueError,'retained without retry'):c.preflight()
        with patch.object(c,'WORK',c.ROOT/'.tirust-build/unowned-name'):
            with self.assertRaisesRegex(ValueError,'namespace'):c.work_namespace()

    def test_one_total_stage_budget_and_shared_mutex_cover_both_variants(self):
        self.assertEqual(c.CAPS,{'build':180.,'run':180.});self.assertEqual(c.CLEANUP,60.)
        self.assertEqual(c.LIMITS,dict(address_space_bytes=4*1024**3,file_bytes=256*1024**2,core_bytes=0))
        self.assertEqual(c.CPU,12)
        source=(HERE/'controller.py').read_text();ownership=(HERE/'ownership.py').read_text()
        self.assertIn('ownership.StageDeadline(CAPS[PHASE],absolute_end=ABSOLUTE_END)',source)
        self.assertIn('self.end-CLEANUP-time.monotonic()',ownership)
        self.assertIn("ROOT/'.tirust-build/numerical-tests.lock'",source)
        self.assertIn('fcntl.flock(lock,fcntl.LOCK_EX)',source)
        self.assertIn("'-B','-I'",source)

    def test_bootstrap_alarm_precedes_source_reads_and_keeps_original_absolute_deadline(self):
        with patch.object(c.signal,'getsignal',return_value=0),patch.object(c.signal,'signal'),\
             patch.object(c.signal,'setitimer') as timer,patch.object(c.time,'monotonic',return_value=c.BOOTSTRAP_STARTED+25.):
            with c.BootstrapDeadline():
                self.assertEqual(c.ABSOLUTE_END,c.BOOTSTRAP_STARTED+180.)
                self.assertEqual(timer.call_args.args[1],95.)
        tree=ast.parse((HERE/'controller.py').read_text())
        main=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='main')
        context=next(node for node in main.body if isinstance(node,ast.With))
        self.assertEqual(ast.unparse(context.items[0].context_expr),'BootstrapDeadline()')
        self.assertEqual(ast.unparse(context.body[0]),'authenticate_source_index()')

    def test_handoff_deferral_rearms_original_hard_end_without_hashing_environment_inside(self):
        deadline=ownership.StageDeadline(180.,absolute_end=180.)
        deadline.end=180.;deadline.handoff=True;deadline.deferred=False
        with patch.object(ownership.time,'monotonic',return_value=120.),patch.object(ownership.signal,'setitimer') as timer:
            deadline.expired(None,None)
            self.assertTrue(deadline.deferred);self.assertEqual(timer.call_args.args[1],60.)
        with patch.object(ownership.time,'monotonic',return_value=180.):
            with self.assertRaisesRegex(TimeoutError,'all-in cap'):deadline.expired(None,None)
        source=(HERE/'controller.py').read_text();active=source[source.index('deadline.handoff=True'):source.index('deadline.handoff=False')]
        self.assertNotIn('environment()',active);self.assertIn('env=launch_environment',active)

    def test_retained_worker_cleanup_closes_handle_before_stage_exit(self):
        trace=[];started=dict(pid=43,parent_pid=17,session=17,process_group=17,start_time_ticks=9)
        process=types.SimpleNamespace(pid=43,returncode=None)
        process.poll=lambda:process.returncode
        process.terminate=lambda:trace.append('terminate')
        process.kill=lambda:trace.append('kill')
        def wait(timeout):trace.append(('wait',timeout));process.returncode=-15
        process.wait=wait
        cleanup=types.SimpleNamespace(matches=lambda record:record==started)
        with patch.object(c,'support',return_value=cleanup),patch.object(c.os,'getpid',return_value=17),\
             patch.object(c.os,'getsid',return_value=17),patch.object(c.os,'getpgrp',return_value=17):
            result=c.close_worker(process,started)
        self.assertEqual(trace[0],'terminate');self.assertEqual(trace[1][0],'wait')
        self.assertEqual(result['survivors'],[])

    def test_evidence_read_or_write_failure_cannot_skip_retained_worker_cleanup(self):
        trace=[];process=types.SimpleNamespace(pid=43,poll=lambda:None)
        for failure in ('digest','dump'):
            with self.subTest(failure=failure),patch.object(c,'close_worker',side_effect=lambda *args:trace.append('closed')),\
                 patch.object(Path,'exists',return_value=True),patch.object(c,'digest',side_effect=OSError('read failed') if failure=='digest' else None),\
                 patch.object(c,'dump',side_effect=OSError('write failed') if failure=='dump' else None):
                with self.assertRaises(OSError):c.record_worker_failure(c.WORK/'run/checked',ValueError('bad'),process,{},c.WORK/'observations')
                self.assertEqual(trace[-1],'closed')

    def test_uncertain_worker_cleanup_always_reaches_owned_group_fallback_even_when_evidence_fails(self):
        process=types.SimpleNamespace(pid=43,poll=lambda:None)
        for failure in ('digest','dump'):
            stop=Mock(side_effect=RuntimeError('owned group stopped'))
            with self.subTest(failure=failure),patch.object(c,'close_worker',side_effect=ValueError('identity unavailable')),\
                 patch.object(Path,'exists',return_value=True),patch.object(c,'digest',side_effect=OSError('read failed') if failure=='digest' else None),\
                 patch.object(c,'dump',side_effect=OSError('write failed') if failure=='dump' else None),\
                 patch.object(c,'stop_owned_group',stop):
                with self.assertRaisesRegex(RuntimeError,'owned group stopped'):
                    c.record_worker_failure(c.WORK/'run/checked',ValueError('bad'),process,{},c.WORK/'observations')
                stop.assert_called_once_with()

    def test_snapshot_RUN_compares_strict_full_state_summaries_without_geometry_claims(self):
        source=(HERE/'controller.py').read_text()
        self.assertNotIn("['case_results']",source)
        self.assertIn("results['checked']==results['optimized']",source)
        for field in ('actual_constructor_completion_qualified','q_at_use_lowering_qualified','final_dot_runtime_qualified',
                      'full_caller_qualified','scientific_dispatch_enabled'):
            self.assertIn("'"+field+"':False",source)


if __name__=='__main__':unittest.main(verbosity=2)
