"""Dormant standalone owned-snapshot BUILD/RUN controller; separate admissions."""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode=True
BOOTSTRAP_STARTED=time.monotonic()
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/generic-owned-snapshot-qualification-work-2'
CPU=12
CAPS={'build':180.,'run':180.}
CLEANUP=60.
LIMITS={'address_space_bytes':4*1024**3,'file_bytes':256*1024**2,'core_bytes':0}
VARIANTS={'checked':['-O0','-fcheck=all','-ftrapv'],'optimized':['-O3','-fno-fast-math']}
EXPECTED_SOURCE=None
REVIEWED_BUILD=None
PHASE=None
SUPERVISOR=None
ABSOLUTE_END=None
CLEANUP_PATH='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'
LOADER_PATH='docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py'


def require(value,message):
    if not value:raise ValueError(message)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def now():return datetime.now(timezone.utc).isoformat()


class BootstrapDeadline:
    """Arm the original phase cutoff before any full source authentication."""
    def __enter__(self):
        global ABSOLUTE_END
        ABSOLUTE_END=BOOTSTRAP_STARTED+CAPS[PHASE]
        self.previous=signal.getsignal(signal.SIGALRM)
        signal.signal(signal.SIGALRM,self.expired)
        signal.setitimer(signal.ITIMER_REAL,max(.001,ABSOLUTE_END-CLEANUP-time.monotonic()))
        return self
    def expired(self,*unused):
        raise TimeoutError('Original phase work cutoff reached during bootstrap/preflight')
    def __exit__(self,*unused):
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,self.previous)


def dump(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')


def load(name,path,checksum):
    require(digest(path)==checksum,'Changed imported source: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def local(name):
    seal=authenticate_source_index()
    return load('owned_snapshot_qualification_'+name,HERE/(name+'.py'),seal['files'][name+'.py']['sha256'])


def support(path):
    authenticate_source_index()
    return load('owned_snapshot_support_'+Path(path).stem,ROOT/path,read(HERE/'input-pins.json')['support'][path])


def verify_files(base,files):
    for relative,want in files.items():
        p=Path(relative)
        require(not p.is_absolute() and '..' not in p.parts,'Unsafe source path')
        item=base/p
        require(not item.is_symlink() and item.is_file() and item.stat().st_size==want['bytes'] and
                digest(item)==want['sha256'],'Changed source: '+relative)


def environment():
    ancestry=read(HERE/'ancestry.json');pin=read(HERE/'toolchain-pins.json')
    inherited=dict(os.environ)
    for name in tuple(inherited):
        if name.startswith(('PYTHON','GFORTRAN_')) or name in (
                'GLIBC_TUNABLES','LOCPATH','GCONV_PATH','DEPENDENCIES_OUTPUT','SUNPRO_DEPENDENCIES',
                'GCC_COMPARE_DEBUG','COLLECT_GCC_OPTIONS','COLLECT_LTO_WRAPPER'):
            inherited.pop(name)
    env=local('tool_environment').reconstruct(pin,ancestry['compiler_environment_names'],{},[],inherited)
    env.update(TMPDIR=str(WORK/PHASE/'tmp'),TMP=str(WORK/PHASE/'tmp'),TEMP=str(WORK/PHASE/'tmp'))
    return env


def protected():
    ancestry=read(HERE/'ancestry.json');pin=read(HERE/'input-pins.json')
    require(os.uname().sysname=='Linux' and os.uname().machine=='x86_64','This qualification targets GNU/Linux x86_64')
    for name,checksum in {**ancestry['source_files'],**pin['support'],**pin['closed_standalone_build'],**pin['files']}.items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        require(path.is_file() and digest(path)==checksum,'Changed protected source/tool/provider: '+name)
    for name,want in pin['additional_compiler_files'].items():
        item=Path(name)
        require(item.is_file() and item.stat().st_size==want['bytes'] and digest(item)==want['sha256'] and
                (not want['executable'] or os.access(item,os.X_OK)),'Changed C/backend compiler input: '+name)
    for name in pin['additional_compiler_absences']:
        require(not Path(name).exists() and not Path(name).is_symlink(),'Unexpected C compiler hook appeared')
    parent=ROOT/ancestry['module_parent'];index=parent/'source-receipt.json'
    require(digest(index)==ancestry['module_receipt_sha256'],'Frozen snapshot parent changed')
    values=read(index);verify_files(parent,values['payloads'])
    require({str(p.relative_to(parent)) for p in parent.rglob('*') if p.is_file()}==
            set(values['payloads'])|{'source-receipt.json','source-receipt.sha256'},'Frozen snapshot inventory changed')
    require(digest(HERE/'owned_snapshots.f90')==ancestry['module_Fortran_sha256'],
            'Standalone module differs from frozen snapshot source')
    toolpin=read(HERE/'toolchain-pins.json')
    for name,checksum in toolpin['donor_lineage'].items():
        require(digest(ROOT/name)==checksum,'Successful toolchain donor changed')
    admitted=local('tool_environment').validate(toolpin,environment())
    require(len(pin['files'])==5 and pin['runtime_before_link_augmentation']==pin['files'],
            'Original five-provider standalone closure required before link')
    return {'module_parent_receipt_sha256':ancestry['module_receipt_sha256'],
            'module_sha256':ancestry['module_Fortran_sha256'],'pinned_runtime_providers':len(pin['files']),
            'tool_admission':admitted,'compiler_queries':0,'loader_queries':0,'native_executions':0}


def authenticate_source_index():
    require(Path.cwd()==ROOT,'Run only from the MadGraph working repository')
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source SHA required')
    seal=read(HERE/'source-index.json');verify_files(HERE,seal['files'])
    require({str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}==
            set(seal['files'])|{'source-index.json'},'Source inventory changed')
    return seal


def verify_source():
    authenticate_source_index()
    return protected()


def work_namespace():
    expected=ROOT/'.tirust-build/generic-owned-snapshot-qualification-work-2'
    require(WORK==expected and WORK.parent.is_dir() and not WORK.parent.is_symlink(),
            'Unexpected standalone work namespace')
    require(not WORK.is_symlink() and WORK.resolve().is_relative_to(ROOT) and
            (not WORK.exists() or WORK.is_dir()),'Unsafe standalone work namespace')
    require(PHASE in CAPS and not (WORK/PHASE).is_symlink(),'Unsafe stage namespace')


def preflight(stage_created=False):
    before=verify_source();require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    work_namespace()
    if not stage_created:require(not (WORK/PHASE).exists(),'Stage namespace already exists; failures are retained without retry')
    corpus=local('corpus');cases=corpus.cases();expected=read(HERE/'expectations.json')
    require(len(cases)==37 and corpus.render(cases)==(HERE/'fixtures.hex').read_text(),'Frozen hex fixtures changed')
    require(expected['case_count']==37 and expected['mode_count']==20 and
            expected['cases']=={str(row['id']):row for row in cases},'Frozen snapshot state expectations changed')
    require(expected['input_sha256']==digest(HERE/'fixtures.hex'),'Snapshot fixture/oracle binding changed')
    if PHASE=='run':verify_build()
    return {'status':'source-only-preflight-passed','source_index_sha256':EXPECTED_SOURCE,
            'protected':before,'caps_seconds':CAPS,'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,
            'CPU':CPU,'CPU_reserved':False,'compiler_or_loader_queries':0,'native_executions':0}


def command(argv,cwd,logs,label):
    require_supervisor()
    logs.mkdir(exist_ok=True,parents=True)
    dump(logs/(label+'.command.json'),{'argv':list(map(str,argv)),'cwd':str(cwd),'started_utc':now(),
         'controller_pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp()})
    with (logs/(label+'.stdout.txt')).open('xb') as output:
        done=subprocess.run(argv,cwd=cwd,env=environment(),stdout=output,stderr=subprocess.STDOUT)
    dump(logs/(label+'.terminal.json'),{'returncode':done.returncode,'finished_utc':now(),
         'stdout_sha256':digest(logs/(label+'.stdout.txt'))})
    require(done.returncode==0,'Admitted command failed: '+label)
    return (logs/(label+'.stdout.txt')).read_text()


def bind_standalone_runtime(bound):
    pin=read(HERE/'input-pins.json');extra=pin['runtime_before_link_augmentation']
    require(len(pin['files'])==5 and extra==pin['files'],'Original five-provider standalone closure required')
    for name,checksum in extra.items():
        require(bound['bound'].get(name,checksum)==checksum and digest(name)==checksum,
                'Standalone pre-link runtime join conflict')
        bound['bound'][name]=checksum
    bound['explicit_standalone_runtime_join_before_link']=dict(extra)
    return extra


def build_locked(directory):
    pin=read(HERE/'toolchain-pins.json');tools={k:v['path'] for k,v in pin['required_tools'].items()}
    loader=support(LOADER_PATH);runtime=local('unit_runtime');logs=directory/'commands'
    for name in ('gfortran','cc'):
        text=command([tools[name],'--version'],directory,logs,name+'-version')
        require('15.2.0' in text,'Compiler version is not GNU15.2.0')
    command([tools['cc'],'-std=c11','-O0','-fPIC','-frounding-math','-c',str(HERE/'fenv_observer.c'),
             '-o','fenv_observer.o'],directory,logs,'fenv-observer-compile')
    variants={}
    for variant,flags in VARIANTS.items():
        case=directory/variant;case.mkdir()
        command([tools['gfortran'],*flags,'-fPIC','-c',str(HERE/'owned_snapshots.f90'),'-o','owned_snapshots.o'],
                case,logs,variant+'-module-compile')
        command([tools['gfortran'],'-O0','-fPIC','-fcheck=all','-frounding-math','-c',
                 str(HERE/'driver.f90'),'-o','driver.o'],case,logs,variant+'-driver-compile')
        link=[tools['gfortran'],'-fPIC','-Wl,-Map,link.map,--cref','-o','check',
              'driver.o','owned_snapshots.o',str(directory/'fenv_observer.o'),'-lm']
        callback=lambda argv,label:command(argv,case,logs,variant+'-'+label)
        bound=loader.prelink(link,case,environment(),callback)
        # Explicit source-protected standalone runtime join BEFORE link/publication.
        # Do not borrow the full-amplitude15-provider closure for this small unit.
        extra=bind_standalone_runtime(bound)
        dump(case/'prelink.json',bound)
        command(link,case,logs,variant+'-link')
        loads=loader.requireactualmap((case/'link.map').read_text(),case,bound,case/'check')
        closure=runtime.derive(case/'check',bound)
        runtime.validate_expected(closure,extra)
        dump(case/'static-runtime.json',closure)
        observed=loader.query_runtime(case/'check',closure['files'],bound,callback)
        symbols=command([tools['nm'],'--defined-only',str(case/'check')],case,logs,variant+'-symbols')
        names=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',symbols,re.M)
        required={'__ml_private_owned_snapshots_MOD_owned_'+operation+'_'+precision
                  for operation in ('reset','prepare','commit') for precision in ('dp','qp')}
        require(all(names.count(name)==1 for name in required),'Snapshot API ownership is not unique')
        require(not any('ml_private_exact_geometry' in name for name in names),'Unrequested geometry helper linked')
        undefined=command([tools['nm'],'--undefined-only',str(case/'owned_snapshots.o')],case,logs,variant+'-module-undefined')
        names=re.findall(r'\bU\s+(\S+)',undefined)
        require(not any(re.search(r'float|quadmath|multc|trunc|extend|feset|ieee',n,re.I) for n in names),
                'Unexpected FP/environment snapshot-module dependency')
        variants[variant]={'path':str(case/'check'),'sha256':digest(case/'check'),'flags':flags,
            'objects':{n:digest(case/n) for n in ('owned_snapshots.o','driver.o')},
            'prelink_sha256':digest(case/'prelink.json'),'link_map_sha256':digest(case/'link.map'),
            'static_runtime_sha256':digest(case/'static-runtime.json'),'runtime':observed,
            'actual_link_loads':loads,'module_undefined_symbols':names}
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,
        'module_sha256':digest(HERE/'owned_snapshots.f90'),'fenv_object_sha256':digest(directory/'fenv_observer.o'),
        'variants':variants,'snapshot_main_calls':0,'scientific_reducer_calls':0,'protected':protected()})


def verify_build():
    work_namespace()
    directory=WORK/'build';terminal=directory/'terminal.json'
    require(directory.is_dir() and not directory.is_symlink() and directory.resolve()==directory,
            'Unsafe owned BUILD directory')
    require(not terminal.is_symlink(),'Reviewed BUILD terminal is a source alias')
    require(REVIEWED_BUILD and digest(terminal)==REVIEWED_BUILD,'Separate exact reviewed BUILD terminal required')
    closed=read(terminal)
    require(closed['status']=='passed' and closed['returncode']==0 and not closed['cleanup']['survivors'],
            'BUILD was not successfully closed')
    require(digest(directory/'result.json')==closed['result_sha256'],'BUILD result changed')
    require(not (directory/'result.json').is_symlink() and not (directory/'fenv_observer.o').is_symlink(),
            'BUILD result/observer is a source alias')
    result=read(directory/'result.json')
    require(result['source_index_sha256']==EXPECTED_SOURCE and result['module_sha256']==digest(HERE/'owned_snapshots.f90'),
            'Reviewed BUILD/source mismatch')
    require(digest(directory/'fenv_observer.o')==result['fenv_object_sha256'],'Observer object changed')
    require(set(result['variants'])==set(VARIANTS),'Exact checked/optimized variant set required')
    for variant,row in result['variants'].items():
        case=directory/variant
        require(row['flags']==VARIANTS[variant],'Reviewed module compiler flags differ')
        require(case.is_dir() and not case.is_symlink() and case.resolve()==case,'Unsafe BUILD variant directory')
        require(row['path']==str(case/'check') and not (case/'check').is_symlink() and
                (case/'check').resolve().is_relative_to(directory),'Executable is outside owned BUILD namespace')
        require(set(row['objects'])=={'owned_snapshots.o','driver.o'},'Exact snapshot/driver object set required')
        require(all(not (case/name).is_symlink() for name in (*row['objects'], 'prelink.json','link.map','static-runtime.json')),
                'BUILD object/proof is a source alias')
        require(digest(row['path'])==row['sha256'],'Executable changed')
        for name,checksum in row['objects'].items():require(digest(case/name)==checksum,'Helper/driver object changed')
        for name,key in [('prelink.json','prelink_sha256'),('link.map','link_map_sha256'),('static-runtime.json','static_runtime_sha256')]:
            require(digest(case/name)==row[key],'Link/runtime proof changed')
        runtime=local('unit_runtime');closure=runtime.derive(row['path'],read(case/'prelink.json'))
        require(closure==read(case/'static-runtime.json'),
                'Standalone static runtime derivation changed')
        expected=read(HERE/'input-pins.json')['files'];runtime.validate_expected(closure,expected)
        require(row['runtime']['files']==expected,'Reviewed runtime differs from original five providers')
        for name,checksum in {**row['actual_link_loads'],**row['runtime']['files']}.items():
            require(digest(name)==checksum,'Admitted runtime/link provider changed')
    return result


def mapped(process,row,started):
    cleanup=support(CLEANUP_PATH)
    require(started and started['pid']==process.pid and cleanup.matches(started) and process.poll() is None,
            'Original native worker identity changed before mapping')
    current=cleanup.identity(process.pid)
    require(current['parent_pid']==os.getpid() and current['session']==os.getsid(0) and
            current['process_group']==os.getpgrp(),'Native worker left its owning stage')
    executable=Path('/proc/'+str(process.pid)+'/exe')
    require(not str(executable.readlink()).endswith(' (deleted)') and
            executable.resolve()==Path(row['path']).resolve() and digest(executable)==row['sha256'],
            'Native worker executable differs from reviewed BUILD')
    raw=Path('/proc/'+str(process.pid)+'/maps').read_text();actual={};data={}
    allowed=read(HERE/'input-pins.json').get('allowed_data_mappings',{})
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)!=6 or not fields[5].startswith('/'):continue
        name=fields[5];require(not name.endswith(' (deleted)'),'Deleted native mapping')
        path=Path(name)
        with path.open('rb') as stream:header=stream.read(4)
        resolved=str(path.resolve())
        if header==b'\x7fELF':actual[resolved]=digest(path)
        else:
            require(allowed.get(resolved)==digest(path),'Unexpected mapped data file')
            data[resolved]=allowed[resolved]
    expected=dict(row['runtime']['files']);expected[str(Path(row['path']).resolve())]=row['sha256']
    require(actual==expected,'Actual worker ELF mappings differ from admitted providers')
    require(sorted(os.sched_getaffinity(process.pid))==[CPU],'Worker affinity differs')
    require(cleanup.matches(started) and process.poll() is None and
            executable.resolve()==Path(row['path']).resolve(),'Native worker identity changed during mapping')
    return {'pid':process.pid,'identity':cleanup.identity(process.pid),'started_identity':started,
            'raw':raw,'ELF':actual,'data':data,'affinity':[CPU],'exclusive_CPU':False}


def run_locked(directory):
    built=verify_build();analyzer=local('analyze');results={}
    for variant,row in built['variants'].items():
        folder=directory/variant;folder.mkdir();output=folder/'observations.txt'
        argv=[row['path'],str(HERE/'fixtures.hex'),str(output)]
        dump(folder/'command.json',{'argv':argv,'started_utc':now(),'cwd':str(folder),
            'session':os.getsid(0),'process_group':os.getpgrp(),'new_session':False})
        process=None;started=None
        try:
            with (folder/'stderr.txt').open('xb') as error:
                require_supervisor()
                process=subprocess.Popen(argv,cwd=folder,env=environment(),stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,stderr=error,text=True,bufsize=1)
                started=support(CLEANUP_PATH).identity(process.pid)
                require(started is not None,'Original native worker identity unavailable')
                dump(folder/'started.json',{'pid':process.pid,'identity':started,
                     'session':os.getsid(process.pid),'process_group':os.getpgid(process.pid),'new_session':False})
                ready=process.stdout.readline();(folder/'ready.txt').write_text(ready)
                require(ready.strip()=='READY '+str(process.pid),'Standalone READY protocol failed')
                dump(folder/'maps-before.json',mapped(process,row,started))
                process.stdin.write('GO\n');process.stdin.flush()
                done=process.stdout.readline();(folder/'done.txt').write_text(done)
                require(done.strip()=='DONE '+str(process.pid),'Standalone DONE protocol failed')
                dump(folder/'maps-after.json',mapped(process,row,started))
                process.stdin.write('EXIT\n');process.stdin.flush()
                tail=process.communicate()[0]
        except BaseException as error:
            # The owning stage supervises this whole session and every descendant.
            # Preserve partial evidence before handing cleanup back to that owner.
            failure={'error':repr(error),'finished_utc':now(),
                'pid':process.pid if process is not None else None,
                'returncode_at_failure':process.poll() if process is not None else None,
                'observations_sha256_at_failure':digest(output) if output.exists() else None,
                'stderr_sha256_at_failure':digest(folder/'stderr.txt') if (folder/'stderr.txt').exists() else None,
                'cleanup_owner':'Retained native handle before stage supervisor closure; no success on this path'}
            if process is not None:
                try:failure['worker_cleanup']=close_worker(process,started)
                except BaseException as cleanup_error:
                    failure['cleanup_error']=repr(cleanup_error);failure['uncertainty_blocks_later_stages']=True
                    dump(folder/'worker-failure.json',failure)
                    # The child owns this fresh session/group. If even the
                    # retained worker cannot be safely closed, stop the entire
                    # authenticated stage group before it can orphan a worker.
                    require(SUPERVISOR is not None and os.getpid()==os.getpgrp()==os.getsid(0),
                            'Unresolved worker cleanup outside authenticated stage group')
                    os.killpg(os.getpgrp(),signal.SIGKILL)
                    raise RuntimeError('Owned stage SIGKILL unexpectedly returned')
            dump(folder/'worker-failure.json',failure)
            raise
        dump(folder/'terminal.json',{'returncode':process.returncode,'finished_utc':now(),
            'stdout_tail':tail,'observations_sha256':digest(output) if output.exists() else None,
            'stderr_sha256':digest(folder/'stderr.txt')})
        require(process.returncode==0 and not tail.strip(),'Standalone worker failed or emitted unexpected trailing output')
        result=analyzer.analyze(output.read_text(),read(HERE/'expectations.json'))
        dump(folder/'analysis.json',result);results[variant]=result
    require(results['checked']==results['optimized'],'Checked and optimized snapshot replay summaries differ')
    verify_build();verify_source()
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,
        'reviewed_build_sha256':REVIEWED_BUILD,'variants':results,'scientific_reducer_calls':0,
        'physical_or_performance_qualification':False,'snapshot_ownership_qualified':False,
        'actual_constructor_completion_qualified':False,'q_at_use_lowering_qualified':False,
        'final_dot_runtime_qualified':False,'full_caller_qualified':False,'scientific_dispatch_enabled':False,
        'scope':'Standalone snapshot transport/lifecycle only; explicit driver-owned fenv perturbations.'})


def set_limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited resource limit too small')
        resource.setrlimit(kind,(value,value))


def require_supervisor():
    require(SUPERVISOR is not None,'Unsupervised child execution is forbidden')
    cleanup=support(CLEANUP_PATH)
    require(os.getppid()==SUPERVISOR['pid'] and cleanup.matches(SUPERVISOR),
            'Original stage supervisor identity changed')
    require(ABSOLUTE_END is not None and time.monotonic()<ABSOLUTE_END-CLEANUP,
            'Original native work cutoff has passed')


def close_worker(process,started):
    """Close the retained direct worker before its stage exits on a failure."""
    if process.poll() is not None:return {'returncode':process.returncode,'already_exited':True}
    cleanup=support(CLEANUP_PATH)
    if started is None:started=cleanup.identity(process.pid)
    require(started and started['pid']==process.pid and started['parent_pid']==os.getpid() and
            started['session']==os.getsid(0) and started['process_group']==os.getpgrp() and cleanup.matches(started),
            'Retained worker start identity unavailable')
    events=[]
    for action in ('terminate','kill'):
        if process.poll() is not None:break
        require(cleanup.matches(started),'Retained worker identity changed before stop')
        getattr(process,action)();events.append(action)
        remaining=max(0.,ABSOLUTE_END-time.monotonic())
        try:process.wait(timeout=min(2.,max(.001,remaining)))
        except subprocess.TimeoutExpired:continue
    require(process.poll() is not None,'Retained worker survived bounded stop')
    return {'returncode':process.returncode,'started_identity':started,'events':events,'survivors':[]}


def bind_supervisor(admission):
    global SUPERVISOR,ABSOLUTE_END
    require(admission['source_index_sha256']==EXPECTED_SOURCE and admission['phase']==PHASE and
            admission['reviewed_build_sha256']==REVIEWED_BUILD,'Child admission changed')
    record=admission.get('supervisor_identity')
    require(record and record['pid']==os.getppid() and admission.get('child_argv')==sys.argv,
            'Direct or mismatched child invocation is forbidden')
    require(os.getsid(0)==os.getpid()==os.getpgrp(),'Child must have the supervisor-owned fresh session')
    ABSOLUTE_END=admission.get('deadline_monotonic')
    require(isinstance(ABSOLUTE_END,(int,float)) and 0<ABSOLUTE_END<time.monotonic()+CAPS[PHASE],
            'Original stage deadline unavailable')
    SUPERVISOR=record
    require_supervisor()


def child():
    verify_source();work_namespace();directory=WORK/PHASE;admission=read(directory/'admission.json')
    require(not directory.is_symlink() and directory.resolve()==directory,'Unsafe child namespace')
    bind_supervisor(admission)
    set_limits()
    require(admission['source_index_sha256']==EXPECTED_SOURCE and admission['phase']==PHASE and
            admission['reviewed_build_sha256']==REVIEWED_BUILD,'Child admission changed')
    actual={name:list(resource.getrlimit(kind)) for kind,name in
            ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}
    require(actual=={k:[v,v] for k,v in LIMITS.items()},'Child resource limits differ')
    dump(directory/'limits.json',{'actual':actual,'pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp()})
    verify_source()
    with (ROOT/'.tirust-build/numerical-tests.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        require_supervisor()
        dump(directory/'lock.json',{'acquired_utc':now(),'path':str(Path(lock.name))})
        if PHASE=='build':build_locked(directory)
        else:run_locked(directory)


def stage():
    authenticate_source_index();work_namespace()
    cleanup=support(CLEANUP_PATH);ownership=local('ownership')
    WORK.mkdir(exist_ok=True);directory=WORK/PHASE;directory.mkdir(exist_ok=False)
    (directory/'tmp').mkdir(exist_ok=False)
    entry={'phase':PHASE,'cap_seconds':CAPS[PHASE],'cleanup_reserve_seconds':CLEANUP,'started_utc':now(),'status':'running',
           'original_start_monotonic':BOOTSTRAP_STARTED,'original_end_monotonic':ABSOLUTE_END}
    owned=None;process=None;raw_record=None;cleaned=False
    with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAPS[PHASE],absolute_end=ABSOLUTE_END) as deadline:
        entry['deadline_monotonic']=deadline.end
        try:
            requests.check();preflight(stage_created=True)
            tools=read(HERE/'toolchain-pins.json')['required_tools']
            argv=[tools['taskset']['path'],'-c',str(CPU),tools['python3']['path'],'-B','-I',str(Path(__file__).relative_to(ROOT)),
                  '--child','--phase',PHASE,'--source',EXPECTED_SOURCE]
            if REVIEWED_BUILD:argv+=['--reviewed-build',REVIEWED_BUILD]
            entry['command']=argv
            dump(directory/'admission.json',{'phase':PHASE,'source_index_sha256':EXPECTED_SOURCE,
                 'reviewed_build_sha256':REVIEWED_BUILD,'command':argv,'resource_limits':LIMITS,
                 'supervisor_identity':cleanup.identity(os.getpid()),'child_argv':argv[6:],
                 'deadline_monotonic':deadline.end})
            with (directory/'console.log').open('xb') as output:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['child_pid']=process.pid;dump(directory/'started.json',entry)
                print('START '+PHASE+' child_pid='+str(process.pid),flush=True)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Standalone stage failed')
            verify_source();requests.check()
            entry.update(status='passed',finished_utc=now(),result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
        except BaseException as error:
            if process is not None and not cleaned:
                try:
                    entry['cleanup']=ownership.cleanup_owned(owned,deadline.end) if owned is not None else \
                        ownership.raw_cleanup(process,raw_record,cleanup,deadline.end)
                except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
            entry.update(status='failed',error=repr(error),finished_utc=now(),
                         scope='Administrative failure closure; never a qualification pass')
            dump(directory/'terminal.json',entry);raise


def main():
    global EXPECTED_SOURCE,REVIEWED_BUILD,PHASE
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preflight',action='store_true');mode.add_argument('--execute',action='store_true');mode.add_argument('--child',action='store_true')
    parser.add_argument('--phase',choices=tuple(CAPS),required=True);parser.add_argument('--source',required=True)
    parser.add_argument('--reviewed-build');args=parser.parse_args()
    EXPECTED_SOURCE=args.source;REVIEWED_BUILD=args.reviewed_build;PHASE=args.phase
    require(re.fullmatch('[0-9a-f]{64}',EXPECTED_SOURCE),'Exact source SHA required')
    if PHASE=='run':require(REVIEWED_BUILD and re.fullmatch('[0-9a-f]{64}',REVIEWED_BUILD),'Separate reviewed BUILD SHA required')
    with BootstrapDeadline():
        authenticate_source_index()
        if args.preflight:print(json.dumps(preflight(),sort_keys=True,indent=2));return
        if args.child:child();return
        stage()


if __name__=='__main__':main()
