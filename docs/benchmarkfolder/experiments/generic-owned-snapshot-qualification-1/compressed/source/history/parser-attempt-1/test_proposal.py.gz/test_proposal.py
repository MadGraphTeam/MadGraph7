"""Pure source/oracle/parser checks; synthetic observations are never native evidence."""
from pathlib import Path
import json
import unittest
import corpus
import analyze

HERE=Path(__file__).resolve().parent
CONSTANTS=[0,1024,2048,3072,1,4,8,16,32,61]


def synthetic_observations(expected):
    """Exercise strict replay with explicit synthetic words, not Fortran output."""
    output=['SCHEMA owned-snapshot-fenv-v1','CONSTANTS '+' '.join(map(str,CONSTANTS)),
        'NCASES '+str(expected['case_count']),'MODES 20',
        'SNAPSHOT_FIELDS round sticky halts mxcsr_control x87cw mxcsr_raw x87sw',
        'CASE_FIELDS id mode scenario status observe_before observe_after restore_ok requests(5) baseline(7) before(7) after(7) restored(7)',
        'STATUS_FIELDS id mode ncall returned_ok(1:ncall)',
        'MASK_FIELDS id mode width valid(1:2) pending_valid(1:2)',
        'WORD_FIELDS id mode width leg component real_word imaginary_word']
    baseline=[0,0,0,0x1f80,0x037f,0x1f80,0]
    for identifier in range(1,expected['case_count']+1):
        row=expected['cases'][str(identifier)];scenario=row['scenario']
        for mode in range(20):
            if mode==0:
                output.append('INPUT '+str(identifier)+' '+str(scenario))
                for mu in range(4):
                    output.append('DPWORD '+str(identifier)+' '+str(mu)+' '+row['dp_words'][mu])
                    output.append('QPWORD '+str(identifier)+' '+str(mu)+' '+row['qp_words'][mu])
            request=analyze.request_for(mode,CONSTANTS)
            if mode==0:before=baseline
            else:
                rounding,sticky,halts,ftz,daz=request
                cw=(0x037f&~(0x0c00|halts))|rounding
                csr=(0x1f80&~(halts<<7))|(rounding<<3)|sticky
                if ftz>=0:csr=(csr&~0x8040)|(ftz<<15)|(daz<<6)
                before=[rounding,sticky,halts,csr&~63,cw,csr,0]
            numbers=[identifier,mode,scenario,0,0,0,1,*request,*baseline,*before,*before,*baseline]
            output.append('CASE '+' '.join(map(str,numbers)))
            status=row['expected']['status']
            output.append('STATUS '+' '.join(map(str,[identifier,mode,len(status),*status])))
            for width,key in ((64,'dp'),(128,'qp')):
                state=row['expected'][key]
                output.append('MASK '+' '.join(map(str,[identifier,mode,width,*state['valid'],*state['pending_valid']])))
            for leg in range(1,3):
                for mu in range(4):
                    for width,key in ((64,'dp'),(128,'qp')):
                        for tag,field in (('REF','reference'),('PENDING','pending')):
                            output.append(tag+' '+' '.join(map(str,[identifier,mode,width,leg,mu]))+' '+
                                ' '.join(row['expected'][key][field][leg-1][mu]))
    output.append('DONE '+str(expected['case_count']))
    return '\n'.join(output)+'\n'


class DormantSnapshotProposal(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.expected=json.loads((HERE/'expectations.json').read_text())
        cls.synthetic=synthetic_observations(cls.expected)

    def test_exact_small_corpus_regenerates_without_writes(self):
        rows=corpus.cases()
        self.assertEqual(len(rows),37)
        self.assertEqual(corpus.render(rows),(HERE/'fixtures.hex').read_text())
        self.assertEqual({row['scenario'] for row in rows},set(range(1,28)))
        for row in rows:self.assertEqual(row,self.expected['cases'][str(row['id'])])

    def test_prepare_only_and_commit_states_are_distinct(self):
        pending=self.expected['cases']['2']['expected']['dp']
        ready=self.expected['cases']['3']['expected']['dp']
        self.assertEqual(pending['valid'],[0,0]);self.assertEqual(pending['pending_valid'],[1,0])
        self.assertEqual(ready['valid'],[1,0]);self.assertEqual(ready['pending_valid'],[0,0])
        self.assertEqual(pending['pending'][0],ready['reference'][0])
        self.assertEqual(self.expected['cases']['6']['expected']['status'],[1,1,1,0])

    def test_DP_zero_extension_and_QP_low_113th_bit_have_independent_expected_words(self):
        dp=self.expected['cases']['3']['expected']['dp']['reference'][0]
        self.assertEqual(dp[0][0],'0'*16+'8000000000000000')
        self.assertEqual(dp[1][0],'0'*16+'8000000000000001')
        qp=self.expected['cases']['5']['expected']['qp']['reference'][0]
        self.assertEqual(qp[2][0],'3FFF0000000000000000000000000001')
        self.assertEqual(qp[0][0],'80000000000000000000000000000000')

    def test_malformed_slice_oracle_preserves_only_inaccessible_dirty_regions(self):
        value=self.expected['cases']['18']['expected']['dp']
        self.assertEqual(value['reference'][1][3],['0'*32,'11'*16])
        value=self.expected['cases']['19']['expected']['qp']
        self.assertEqual(value['pending'][1][0],['44'*16,'44'*16])
        self.assertEqual(self.expected['cases']['21']['expected']['qp']['valid'],[0,1])

    def test_nonfinite_vectors_refuse_atomically_and_other_precision_is_unchanged(self):
        for identifier in range(30,38):
            row=self.expected['cases'][str(identifier)]
            self.assertEqual(row['expected']['status'],[1,0,0])
            target='dp' if row['scenario']==3 else 'qp'
            self.assertEqual(row['expected'][target]['valid'],[0,0])
            self.assertTrue(all(int(word,16)==0 for column in row['expected'][target]['pending'] for pair in column for word in pair))
        self.assertEqual(self.expected['cases']['26']['expected']['dp']['valid'],[1,0])
        self.assertEqual(self.expected['cases']['27']['expected']['qp']['valid'],[1,0])

    def test_complete_synthetic_trace_replays_but_never_claims_native_qualification(self):
        result=analyze.analyze(self.synthetic,self.expected)
        self.assertEqual(result['observations'],37*20)
        self.assertEqual(result['complete_integer_state_words'],37*20*64)
        self.assertTrue(result['analysis_only'])
        for field in ('execution_authorization_checked','native_snapshot_transport_qualified','full_caller_qualified','scientific_dispatch_enabled'):
            self.assertIs(result[field],False)

    def test_truncation_extra_records_and_raw_input_mutation_are_rejected(self):
        for bad in (self.synthetic.rsplit('DONE',1)[0],self.synthetic+'DONE 37\n',
                    self.synthetic.replace('DPWORD 1 0 8000000000000000','DPWORD 1 0 0000000000000000',1)):
            with self.assertRaises(ValueError):analyze.analyze(bad,self.expected)

    def test_output_word_mask_and_status_mutation_are_rejected(self):
        mutations=[self.synthetic.replace('REF 1 0 64 1 0 '+'0'*32,'REF 1 0 64 1 0 '+'1'+'0'*31,1),
            self.synthetic.replace('MASK 1 0 64 0 0 0 0','MASK 1 0 64 1 0 0 0',1),
            self.synthetic.replace('STATUS 1 0 2 1 1','STATUS 1 0 2 1 0',1)]
        for bad in mutations:
            with self.assertRaises(ValueError):analyze.analyze(bad,self.expected)

    def test_environment_delta_skip_and_failed_restore_are_rejected(self):
        source=self.synthetic.splitlines();index=next(i for i,line in enumerate(source) if line.startswith('CASE 1 0 '))
        original=source[index].split()
        for token,value in ((4,'1'),(7,'0'),(27,'1')):
            changed=list(original);changed[token]=value;bad=list(source);bad[index]=' '.join(changed)
            with self.assertRaises(ValueError):analyze.analyze('\n'.join(bad)+'\n',self.expected)

    def test_driver_has_only_matching_word_transport_and_no_IO_inside_cohort(self):
        source=(HERE/'driver.f90').read_text()
        active=source[source.index('      status=qualifier_begin('):source.index('      restore_ok=qualifier_restore(')]
        logical='\n'.join(row.split('!',1)[0] for row in active.splitlines())
        for keyword in ('write(','read(','open(','print ','error stop'):
            self.assertNotIn(keyword,logical.lower())
        self.assertIn('dp_column(mu)=transfer(dp_words(mu),0.0_snapshot_dp)',active)
        self.assertIn('qp_column(mu)=transfer(qp_words(mu),0.0_snapshot_qp)',active)
        self.assertIn("read(line,'(Z16)',iostat=ios) dp_words(mu)",source)
        self.assertIn('integer(native_i64) :: dp_words(0:3)',source)

    def test_plans_are_separate_dormant_and_require_postbuild_actual_binary_binding(self):
        build=json.loads((HERE/'build-plan.json').read_text());run=json.loads((HERE/'run-plan.json').read_text())
        self.assertFalse(build['admitted']);self.assertFalse(run['admitted'])
        self.assertEqual(build['phase'],'BUILD');self.assertEqual(run['phase'],'RUN')
        self.assertTrue(run['requires_reviewed_actual_build_receipt'])
        self.assertIsNone(run['actual_executable_hashes'])
        self.assertFalse(run['physical_constructor_or_q_dot_calls'])


if __name__=='__main__':unittest.main(verbosity=2)
