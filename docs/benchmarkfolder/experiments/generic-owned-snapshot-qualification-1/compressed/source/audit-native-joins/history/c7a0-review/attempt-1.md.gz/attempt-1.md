# Initial dormant controller source review

This review binds controller SHA-256
`7887a1c47f4c7e02bb521ac6ba30c6975a238fa8367f7525c1f478ee6fbe486b`.
It is source inspection only; no project imports, preflight, tests, compiler,
loader query, native process, or controller execution occurred.

Two unresolved findings prevent a closed-source audit result for this attempt.

1. `run_locked()` retains a native Popen handle and a start-identity record,
   but its exception path only records failure and raises. An exception at the
   READY or mapping checks can exit the stage child before the outer
   `OwnedChild` poll has observed the worker. The copied cleanup helper samples
   children only from recorded live anchors; when the stage child has exited,
   it cannot discover an unrecorded worker. Its process-group signaling also
   requires an observed live anchor. The stage remains failed, but the worker
   can remain alive without appearing in the reported survivor set. Close the
   retained worker under its exact identity and the original stage deadline,
   or require supervisor registration/acknowledgment before child exit. An
   uncertain cleanup must remain a failure and block continuation.
2. `stage()` performs source authentication, work-namespace checks, support
   imports, and directory creation before entering `StageDeadline`. Those
   operations are outside the advertised total 180 seconds. The original
   all-in deadline must include that bootstrap as well as lock wait, both
   variants, commands, handshakes, cleanup, and administrative closure.

The remaining inspected joins are appropriately narrow: source authentication
precedes nonstdlib source imports and native calls; the exact six snapshot
symbols and object set replace the old geometry helper; all original five
providers are prebound before linking; actual link inputs are checked and the
pure runtime closure must equal those exact five before interpreter listing;
READY/DONE checks bind original worker identity, executable, maps, and CPU12;
both variants independently replay the complete 37-by-20 snapshot transcript
and compare deterministic summaries. Broader qualification flags remain false.

This report is historical once a corrected controller successor is reviewed.
No sealed parent, scientific source, or native artifact was changed.
