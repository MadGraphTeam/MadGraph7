# Independent dormant controller source audit

Final narrow source result: **CLEAR** at controller
`c7a0c5d19160cda564aa07cd5df96c69bb3a97a30a8b6f1a7637983ec2e8d738`
and ownership helper
`f7ab2cdc0e0fb2dc1d5cc71a1900153898aef39d69a074b68e8923d21e55b731`.
This prepares no BUILD or RUN admission. No project controller/import, preflight,
test, compiler, linker, loader query, native worker, or signal/control API was
executed by this audit.

The controller authenticates its complete reviewed source inventory before
loading repository-owned helper code. Native commands require the original
supervisor binding. The child invocation binds the expected source, separate
reviewed BUILD hash for RUN, exact argv, original parent identity, its own fresh
session/group, and original absolute deadline. Source/namespace failures cannot
start a compiler or native worker.

BUILD compiles only the unchanged snapshot module, unchanged private driver,
and unchanged observer. It requires each of the six named snapshot APIs to have
exactly one definition and rejects the old geometry helper. The module/driver
object set, flags, observer hash, executable path, link proof, and runtime proof
are bound into the reviewed BUILD join. The original five providers are merged
with conflict/hash checks before link; actual link loads and interpreter are
checked, then the pure ELF closure must equal exactly those five before any
interpreter `--list`. The unchanged resolver's optional quadmath allowance is
therefore narrowed by the controller's exact expected-closure check.

RUN requires the exact successfully closed BUILD terminal. READY and DONE both
bind the recorded original worker PID/start identity, direct parent, current
stage session/group, executable hash, exact mapped ELF provider set, and CPU12.
GO and EXIT follow those checks. Both variants must complete the unchanged
strict 37-by-20 input/status/mask/reference/pending/FENV transcript parser,
then return equal deterministic summaries. No old geometry `case_results`
assumption or relaxed skipped-cohort rule is inherited.

The initial review's two findings are retained in `attempt-1.*` and the parent's
`history/controller-attempt-1`. The corrected worker-cleanup and absolute-end
source that still performed evidence I/O too early is retained in the parent's
`history/controller-attempt-2`. Current `record_worker_failure` closes the
retained worker before any fallible evidence hashing, formatting, or writing.
Known workers are identity-checked and terminated/killed/waited under the
original deadline. If closure remains uncertain, best-effort evidence is inside
a `try` whose `finally` stops the authenticated current fresh group, including
the stage anchor. The fallback touches that owned group only; it is neither a
process-name cleanup nor a qualification pass. This narrow conclusion relies
on the pinned standalone driver/observer's absence of group/session escape.

The bootstrap alarm precedes full source authentication and namespace/import
work. The reused StageDeadline now accepts that same absolute end; it does not
restart the 180 seconds. The shared mutex, both serial variants, all commands
and handshakes, 60-second cleanup reserve, and administrative closure use the
original budget. The helper's delta is limited to carrying that absolute end
and computing remaining timer time. The 4 GiB address-space limit, 256 MiB file
limit, zero core limit, fresh private stage paths, and nonexclusive CPU12 remain.

Pure regression source includes mocked provider conflicts, extra/missing runtime
providers before listing, wrong source/BUILD/object/path/flags, PID reuse,
supervisor gating, old stage directories, same-deadline bootstrap, direct worker
closure, and read/write evidence failures on both closed and uncertain cleanup
paths. This audit inspected that source without executing it. All runtime,
ownership, caller, physical-math, scientific, and performance obligations remain
outside this source audit.
