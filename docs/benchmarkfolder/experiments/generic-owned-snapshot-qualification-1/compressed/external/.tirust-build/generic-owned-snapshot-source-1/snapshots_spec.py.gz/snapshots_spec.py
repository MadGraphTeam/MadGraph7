"""Integer-only state/transport specification; Fortran has not been executed.

Native scalar words are signed INT64/INT128 carriers. Stored Python words are
unsigned canonical patterns, corresponding to the same Fortran INTEGER128 bits.
A ColumnView's direct-column marker is a model assumption, not source/ABI proof.
The emitter must authenticate actual repaired P/MP_P column expressions and the
normal constructor-return placement of commit. No W/sign conversion occurs.
"""
from dataclasses import dataclass

MAX_EXTERNAL = 64
MASK64 = (1 << 64) - 1
MASK128 = (1 << 128) - 1


class Refusal(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Refusal(reason)


def evidence(ok, reason=None):
    return dict(ok=bool(ok), reason=reason, Fortran_executed=False,
                runtime_abi_qualified=False, full_caller_qualified=False,
                source_binding_qualified=False, scientific_dispatch_enabled=False)


def native_signed(word, width):
    """Encode a canonical word as its same-width signed integer carrier."""
    require(type(width) is int and width in (64, 128), 'unsupported-width')
    require(type(word) is int and 0 <= word < 1 << width, 'malformed-canonical-word')
    return word - (1 << width) if word >> (width - 1) else word


def dp_transport(native_word):
    """Model INT64 scalar TRANSFER followed by explicit 128-bit zero extension."""
    require(type(native_word) is int and -(1 << 63) <= native_word < 1 << 63,
            'invalid-int64-carrier')
    return native_word & MASK64


def qp_transport(native_word):
    """Model matching INT128 scalar TRANSFER; no DD or DP widening transport."""
    require(type(native_word) is int and -(1 << 127) <= native_word < 1 << 127,
            'invalid-int128-carrier')
    return native_word & MASK128


def finite_word(word, width):
    if type(word) is not int or type(width) is not int or width not in (64, 128) or not 0 <= word < 1 << width:
        return False
    fraction, exponent = (52, 11) if width == 64 else (112, 15)
    return (word >> fraction) & ((1 << exponent) - 1) != (1 << exponent) - 1


@dataclass(frozen=True)
class ColumnView:
    width: int
    native_words: tuple
    direct_column: bool = True
    contiguous: bool = True
    component_lower: int = 0

    @classmethod
    def canonical(cls, width, words, **view):
        return cls(width, tuple(native_signed(word, width) for word in words), **view)


def zero_column():
    return [[0, 0] for _ in range(4)]


class SnapshotState:
    """One precision's caller-owned state model; all arrays are newly owned.

    Shape in Python is [leg][component][real/imaginary], equivalent to Fortran
    (2,0:3,nlegs). Prepare never publishes reference validity. Commit consumes
    one completed preparation; duplicate/unprepared commits invalidate the leg.
    A false genuine-QP gate invalidates the entire QP state.
    """
    def __init__(self, width, nlegs):
        require(type(width) is int and width in (64, 128), 'unsupported-width')
        require(type(nlegs) is int and 1 <= nlegs <= MAX_EXTERNAL, 'unsupported-leg-count')
        self.width = width
        self.nlegs = nlegs
        self.reset()

    def reset(self):
        self.reference = [zero_column() for _ in range(self.nlegs)]
        self.pending = [zero_column() for _ in range(self.nlegs)]
        self.valid = [False] * self.nlegs
        self.pending_valid = [False] * self.nlegs
        return evidence(True)

    def _leg(self, leg):
        if type(leg) is not int or not 1 <= leg <= self.nlegs:
            self.reset()
            raise Refusal('invalid-leg')
        return leg - 1

    def _clear_leg(self, index):
        self.valid[index] = False
        self.pending_valid[index] = False
        self.reference[index] = zero_column()
        self.pending[index] = zero_column()

    def prepare(self, leg, column, genuine_qp=True):
        if self.width == 128 and genuine_qp is not True:
            self.reset()
            return evidence(False, 'not-genuine-qp')
        try:
            index = self._leg(leg)
            self._clear_leg(index)
            require(type(column) is ColumnView and type(column.width) is int and column.width == self.width,
                    'column-kind')
            require(column.direct_column is True and column.contiguous is True, 'unsupported-column-view')
            require(type(column.component_lower) is int and column.component_lower == 0,
                    'component-order')
            require(type(column.native_words) is tuple and len(column.native_words) == 4, 'column-shape')
            transport = dp_transport if self.width == 64 else qp_transport
            staged = []
            for native_word in column.native_words:
                word = transport(native_word)
                require(finite_word(word, self.width), 'nonfinite-column')
                staged.append([word, 0])
            # Publication is after all four scalar transfers and integer checks.
            self.pending[index] = staged
            self.pending_valid[index] = True
            return evidence(True)
        except Refusal as error:
            return evidence(False, str(error))

    def commit(self, leg, genuine_qp=True):
        if self.width == 128 and genuine_qp is not True:
            self.reset()
            return evidence(False, 'not-genuine-qp')
        try:
            index = self._leg(leg)
            self.valid[index] = False
            require(self.pending_valid[index] is True, 'no-completed-prepare')
            pending = self.pending[index]
            require(type(pending) is list and len(pending) == 4, 'pending-shape')
            for pair in pending:
                require(type(pair) is list and len(pair) == 2, 'pending-shape')
                require(finite_word(pair[0], self.width) and type(pair[1]) is int and pair[1] == 0,
                        'invalid-pending-word')
            self.reference[index] = [list(pair) for pair in pending]
            self.pending[index] = zero_column()
            self.pending_valid[index] = False
            self.valid[index] = True
            return evidence(True)
        except Refusal as error:
            if type(leg) is int and 1 <= leg <= self.nlegs:
                self._clear_leg(leg - 1)
            return evidence(False, str(error))

    def consumer_view(self):
        """Read-only model copy; mask readiness is not scientific admission."""
        return (tuple(tuple(tuple(pair) for pair in column) for column in self.reference),
                tuple(self.valid))


class SnapshotPair:
    def __init__(self, nlegs):
        self.dp = SnapshotState(64, nlegs)
        self.qp = SnapshotState(128, nlegs)

    def reset(self):
        self.dp.reset()
        self.qp.reset()
        return evidence(True)
