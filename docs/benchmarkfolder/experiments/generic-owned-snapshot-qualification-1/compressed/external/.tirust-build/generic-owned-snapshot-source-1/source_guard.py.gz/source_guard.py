"""Audit a source-emission process; never a compiler/native ABI controller."""
from pathlib import Path
import os


class SourceAudit:
    def __init__(self, writable, readable):
        self.writable = Path(writable).resolve()
        self.readable = Path(readable).resolve()
        self.attempts = []
        self.read_paths = set()

    def reject(self, event, detail):
        self.attempts.append(dict(event=event, detail=str(detail)))
        raise RuntimeError('source-only boundary rejected ' + event + ': ' + str(detail))

    def path(self, path, writing=False):
        if isinstance(path, int):
            self.reject('unproved descriptor operation', path)
        resolved = Path(os.fsdecode(path)).resolve()
        if writing:
            if not resolved.is_relative_to(self.writable):
                self.reject('outside private source write', resolved)
        elif resolved.is_relative_to(self.readable):
            self.read_paths.add(str(resolved))
        elif not resolved.is_relative_to('/nix/store'):
            self.reject('outside declared source read', resolved)

    def __call__(self, event, args):
        if event.startswith(('subprocess.', 'ctypes.', 'os.exec', 'os.spawn', 'socket.', 'http.client.')) or event in (
                'os.system', 'os.fork', 'os.forkpty', 'os.posix_spawn', 'pty.spawn'):
            self.reject(event, args[:2])
        if event == 'import' and len(args) > 1 and args[1] and str(args[1]).endswith(('.so', '.pyd')):
            self.reject('native extension import', args[1])
        if event == 'open':
            mode, flags = args[1], args[2]
            writing = (isinstance(mode, str) and any(flag in mode for flag in 'wax+')) or (
                isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
            self.path(args[0], bool(writing))
        elif event in ('os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.truncate', 'os.utime'):
            self.path(args[0], True)
        elif event in ('os.rename', 'os.link'):
            self.path(args[0], True)
            self.path(args[1], True)
        elif event == 'os.symlink':
            self.reject('source symlink creation', args[:2])
