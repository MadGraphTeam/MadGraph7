# Dormant current-source QP denominator-mass qualification: source2

Source2 preserves source1 `9e279286…` and its failed BUILD `fa0c1403…` unchanged.
All67 recorded original-variant commands succeeded, including four compilations,
link, policy, symbols and actual runtime checks. The owner nevertheless closed
failed at its unselected-object inventory guard. `rglob` omitted five leaves
under the deliberately symlinked private lib directory:139 local bindings versus
144 in the original nonsymlinked donor. Independent audit `d05b85bf…` confirmed
all five direct library/module hashes and targets match and all140 unselected
bindings remain unchanged. No candidate, recording-unit or amplitude main ran.
The failed stage remains failed and unqualified.

The only controller correction explicitly authenticates that exact intended lib
directory symlink, rejects every other private alias, directly hashes all five
required numerical leaves, and retains the complete144-key canonical inventory.
Build, reviewed-build verification and private-worker binding all use it.
No library check is dropped and unexpected objects remain hard failures.
New pure regressions read the preserved failed actual clone (139→144) and reject
wrong directory targets, missing/modified required leaves and unexpected objects
without modifying any original file. The exact failed source inventory, terminal
and independent audit are bound in `predecessor.json`/`input-pins.json`.
New work/report destinations use suffix2; source1 destinations stay untouched.
Compiler flags, all Fortran source bytes, caps, precision and science gates are
unchanged. Source2 has no native admission from the earlier failed BUILD.

No compiler, loader, reducer or Fortran unit executable has run for this packet.
Production, libraries, references, public evidence and Git are unchanged.
Every native phase needs its own exact source/predecessor review and explicit
`--execute`. Preparation is not admission. The first failure stops its phase;
there is no automatic retry or promotion.

This source continuation uses the already frozen **actual CLI** export of
`loop_sm; u u~ > z g g [virt=QCD]` at source `0fcd2cd…`, original `eb3d67fd…`
TIRust and unchanged NinjaRS. Its195 complete generated-source bindings,
144 numerical object/module/archive bindings, actual generation/compilation
receipts, physical model/card and all100 saved points remain pinned. No new
CLI generation, phase-space input or virtual code is introduced. The deterministic
patch derives all116 actual loop groups and seven helper families from those
current emitted bytes, with declared MP symbols and exact arity/order checks.
`source-proof.json`, `actual-process.patch` and all four complete changed-source
previews permit review and fresh derivation. The rest of the actual source family
is authenticated in `input-pins.json`; it is reused unchanged in private clones.

The private paired helpers follow the separately source-qualified75f32… design:
original public routines/signatures remain byte-identical; every original DP
CALL span remains byte-identical inside its new guard. Only an actual selected
backend9 QP call, after CHOOSE_LOOPLIB, forms complex-QP squares in cyclic
`[last,first,…]` order. Other backend calls retain their old DP mass arrays.
The true MP model symbol, including the existing CMS choice, is passed with
`CMPLX(...,KIND=16)`. QP adapters differ only by private names, mass kind and
the private inner diagnostic target. Numerator construction/contraction,
normalization, native API, MPFR precision, thresholds, scale, error/rescue and
cache policies are unchanged. This does not fix old threshold/CMS refusals.

Only the **tool environment** from successful source83721… BUILD is reused.
Every numerical compilation recipe must match the original compiler policy
before and after BUILD, including original TIRUST flags
`-w -fPIC -ffixed-line-length-132`. No O3 experiment or private MTIRUST/Rust
rebuild occurs. BUILD replaces only CT_interface, TIRUST_interface, the split
reduction caller and common driver objects in each private variant. Every other
physics object remains hash-identical. Observers add a separate recording object.
Actual linker LOADs, unique installed-wrapper symbols, actual PT_INTERP listings
and initialized provider maps bind execution. Recording units authenticate their
actual **subset** of the already prebound compiler/system providers; they never
require all15 physical reducers' providers and never load a reducer DSO.

The independently frozen `units/` subtree has16 payloads and ten normal plus ten
optimized pure tests. Its future Fortran execution uses the actual rendered
paired helper and generated guarded caller, genuine binary128 derived/complex
mass arguments, recording-only stubs and an independent integer oracle. The
stub selects9 at actual I_LIB2 while LIBINDEX1 requests8. Both CT4/5 square/order
records and IEEE observations are checked. The stub observes before the real
direction-switch adapter; real choice/reversal kernels and physics are not
qualified by that unit. It runs only after a separately reviewed BUILD.

The physical phases preserve the full100-point learning sequence in each fresh
worker, then all100 final points:87 DP219 and13 automatic-QP323, including point16.
Cache0 and cache−1 each have two plain workers and separate600s admissions.
DP coefficient, accuracy and status words must be exact for matched histories.
QP changes must pass the existing MadLoop3e-6 criterion **and hard1e-8**, with
every word/accuracy difference retained. IEEE/software-latch observations and
own cache0/cache−1 outputs must agree exactly. Positive fixed120 is never used
as checked stability acceptance.

After both plain gates, original and candidate input observers have separate
600s single-worker admissions. Each must exactly reproduce its own plain cache0
coefficient/accuracy/status and observed IEEE/software words. Read-only journals
retain actual mass formals, old DP and new QP squares, post-direction native
masses, shifts, scale/invariants and QP numerator words. The real SM bottom mass
4.7 has an exact105-bit square, so at least one **successful actual native**
bottom-square witness is required at automatic-QP point16; per-point witness
coverage is reported, rather than inferred from source. An independent rational
oracle checks real-MB/MT squares and actual mass ordering. Matched native shifts,
scale and numerators must stay exact. Mass-dependent invariant differences are
retained explicitly. No tensor-output words are captured and no independent
physical finite-term truth is claimed from matching these amplitude results.
Direct matched-input independent-reducer replay remains separate work.

Tested physical scope is `UseQPIntegrandForTIRust=True`, static real SM MB/MT.
False/dynamic-model behavior is an **untested extension**, not a demonstrated
stale-parameter defect: current `mp_compute_loop_coefs.inc:214` unconditionally
calls MP_UPDATE_AS_PARAM before either integrand branch. The main QP path calls
MP_COMPUTE_LOOP_COEFS first (`loop_matrix_standalone.inc:1094/1103`); MP_DONE
reuses already computed coefficients within the same point and resets at851/1589.
Existing full model initialization/reinitialization remains required for external
mass/width edits. No new False-mode or dynamic-model experiment is introduced.
Mixed rescue chains, full derived/CMS physical truth, loop-induced amplitudes,
broader stress, special inputs/traps and runtime acceptance remain unqualified.
Precise local performance remains Hua-Sheng's TODO; there is no timing experiment.

All phases use nonexclusiveCPU12, the shared numerical mutex,16GiB address-space,
512MiB file and zero-core limits, and60s cleanup reserve. BUILD is600s, units180s,
and each physical/observer phase600s. Protected inputs are rechecked and all
owned descendants must close. Native work/report destinations are fresh separate
`.tirust-build/qp-mass-current-qualification-{work,execution}-2` trees.

From the MadGraph repository root:

```sh
python3 -B .tirust-build/qp-mass-current-qualification-proposal-2/controller.py --source SOURCE_SHA
# Only after exact independent source review:
python3 -B .tirust-build/qp-mass-current-qualification-proposal-2/controller.py --source SOURCE_SHA --stage build --execute
# Only after a separate closed BUILD review:
python3 -B .tirust-build/qp-mass-current-qualification-proposal-2/controller.py --source SOURCE_SHA --stage units --execute --reviewed-build BUILD_SHA
```

Later phase names are `cache0`, `cacheall`, `observeoriginal`, `observecandidate`.
They additionally require exactly the reviewed hashes named in
`validation-plan.json`/controller PREREQUISITES. The full command help lists
`--reviewed-units`, `--reviewed-cache0`, `--reviewed-cacheall` and
`--reviewed-observeoriginal`. Each predecessor's complete own ancestor set and
retained raw hashes are checked. No future or own-stage None is recorded as an
ancestor. Pure tests cover that admission-chain regression, malformed inputs,
recipe restrictions, exact DP versus tolerance, observer corruption and missing
native mass witnesses. Synthetic parser text is never labelled native evidence.

The unsealed preparation history retains the initial whitespace-matching failure
and subsequent correction. No frozen predecessor or native failure was rewritten.
Do not rerun exclusive preparation/test log writers in the frozen source tree;
new tests need a fresh working copy and separately retained receipts.
