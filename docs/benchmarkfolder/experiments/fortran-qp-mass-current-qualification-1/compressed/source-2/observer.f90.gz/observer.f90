! Untimed read-only input observer. No reducer or floating-point arithmetic.
module mgmass_observer_state
  use iso_fortran_env, only: int8,int64,real64,real128
  implicit none
  integer,parameter :: journal=211
  logical,save :: active=.false.
  integer,save :: point=0,groups=0,coefs=0,natives=0,statuses=0,models=0
contains
  subroutine real_word(tag,i,j,z)
    character(len=*),intent(in) :: tag
    integer,intent(in) :: i,j
    real(real128),intent(in) :: z
    integer(int64) :: words(2)
    words=transfer(z,words)
    write(journal,'(A,2(1X,I8),2(1X,Z16.16))') tag,i,j,words
  end subroutine
  subroutine complex_word(tag,i,z)
    character(len=*),intent(in) :: tag
    integer,intent(in) :: i
    complex(real128),intent(in) :: z
    integer(int64) :: words(4)
    words=transfer(z,words)
    write(journal,'(A,1X,I8,4(1X,Z16.16))') tag,i,words
  end subroutine
end module

subroutine mgmass_open()
  use mgmass_observer_state
  implicit none
  integer(int8) :: endian(8)
  if(active.or.point/=0) stop 71
  if(storage_size(0.0_real128)/=128.or.digits(0.0_real128)/=113) stop 72
  open(journal,file='mass-observer.hex',status='new',action='write')
  write(journal,'(A)') 'MGMASS 1'
  endian=transfer(1_int64,endian)
  write(journal,'(A,8(1X,I3))') 'ENDIAN',endian
  active=.true.
end subroutine

subroutine mgmass_point(next_point)
  use mgmass_observer_state
  implicit none
  integer,intent(in) :: next_point
  if(.not.active.or.next_point/=point+1.or.next_point>100) stop 73
  point=next_point
  write(journal,'(A,1X,I8)') 'POINT',point
end subroutine

subroutine mgmass_model(dpmb,dpmt,mpmb,mpmt)
  use mgmass_observer_state
  implicit none
  real(real64),intent(in) :: dpmb,dpmt
  real(real128),intent(in) :: mpmb,mpmt
  integer(int64) :: words(2)
  if(.not.active) return
  models=models+1
  write(journal,'(A,1X,I8,2(1X,Z16.16))') 'MODELDP',point,transfer(dpmb,words(1)),transfer(dpmt,words(1))
  call real_word('MODELMP',point,1,mpmb)
  call real_word('MODELMP',point,2,mpmt)
end subroutine

subroutine mgmass_group(role,mode,n,rank,id,formals,dp_square,qp_square)
  use mgmass_observer_state
  implicit none
  integer,intent(in) :: role,mode,n,rank,id
  complex(real128),intent(in) :: formals(n),qp_square(n)
  complex(real64),intent(in) :: dp_square(n)
  integer :: i
  integer(int64) :: words(2)
  if(.not.active) return
  groups=groups+1
  write(journal,'(A,7(1X,I8))') 'GROUP',groups,point,role,mode,n,rank,id
  do i=1,n
    call complex_word('FORMAL',i,formals(i))
    words=transfer(dp_square(i),words)
    write(journal,'(A,1X,I8,2(1X,Z16.16))') 'DPSQUARE',i,words
    call complex_word('QPSQUARE',i,qp_square(i))
  enddo
end subroutine

subroutine mgmass_coefs(role,n,rank,id,nc,coefficients)
  use mgmass_observer_state
  implicit none
  integer,intent(in) :: role,n,rank,id,nc
  complex(real128),intent(in) :: coefficients(0:nc-1)
  integer :: i
  if(.not.active) return
  coefs=coefs+1
  write(journal,'(A,7(1X,I8))') 'COEFFICIENTS',groups,point,role,n,rank,id,nc
  do i=0,nc-1
    call complex_word('COEF',i,coefficients(i))
  enddo
end subroutine

subroutine mgmass_native(role,mode,n,rank,shifts,invariants,masses,scale)
  use mgmass_observer_state
  implicit none
  integer,intent(in) :: role,mode,n,rank
  real(real128),intent(in) :: shifts(0:3,n),invariants(n,n),scale
  complex(real128),intent(in) :: masses(n)
  integer :: i,j
  if(.not.active) return
  natives=natives+1
  write(journal,'(A,6(1X,I8))') 'NATIVE',groups,point,role,mode,n,rank
  call real_word('SCALE',0,0,scale)
  do i=1,n
    call complex_word('MASS',i,masses(i))
    do j=0,3
      call real_word('SHIFT',j,i,shifts(j,i))
    enddo
    do j=1,n
      call real_word('INVARIANT',j,i,invariants(j,i))
    enddo
  enddo
end subroutine

subroutine mgmass_status(status)
  use mgmass_observer_state
  implicit none
  integer,intent(in) :: status
  if(.not.active) return
  statuses=statuses+1
  write(journal,'(A,3(1X,I8))') 'STATUS',groups,point,status
end subroutine

subroutine mgmass_close()
  use mgmass_observer_state
  implicit none
  if(.not.active.or.point/=100.or.models/=100) stop 74
  write(journal,'(A,6(1X,I12))') 'END',point,groups,coefs,natives,statuses,models
  close(journal)
  active=.false.
end subroutine
