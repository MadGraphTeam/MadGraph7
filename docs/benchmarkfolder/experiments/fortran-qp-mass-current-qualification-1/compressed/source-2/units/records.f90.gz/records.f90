module unit_mass_records
  use, intrinsic :: iso_fortran_env, only: int8,int64,real64,real128
  use, intrinsic :: ieee_arithmetic
  use, intrinsic :: ieee_exceptions
  implicit none
  integer :: current_mode=0,choose_calls=0,qp_calls=0,legacy_calls=0
contains
  subroutine unit_header()
    integer(int8) :: endian(8)
    endian=transfer(1_int64,endian)
    if (endian(1)/=1 .or. any(endian(2:)/=0)) error stop 91
    if (storage_size(0.0_real128)/=128 .or. digits(0.0_real128)/=113) error stop 92
    if (storage_size(0.0_real64)/=64 .or. digits(0.0_real64)/=53) error stop 93
    write(*,'(A)') 'META UNITMASS 1 3 2 113 128 LITTLE'
  end subroutine

  subroutine dump_qp(label,mode,index,z)
    character(*),intent(in) :: label
    integer,intent(in) :: mode,index
    complex(real128),intent(in) :: z
    integer(int64) :: words(4)
    words=transfer(z,words)
    write(*,'(A,2(1X,I0),4(1X,Z16.16))') trim(label),mode,index,words
  end subroutine

  subroutine dump_dp(label,mode,index,z)
    character(*),intent(in) :: label
    integer,intent(in) :: mode,index
    complex(real64),intent(in) :: z
    integer(int64) :: words(2)
    words=transfer(z,words)
    write(*,'(A,2(1X,I0),2(1X,Z16.16))') trim(label),mode,index,words
  end subroutine

  subroutine dump_environment(label,mode)
    character(*),intent(in) :: label
    integer,intent(in) :: mode
    type(ieee_round_type) :: rounding
    logical :: flags(5),halting(5)
    integer :: code
    call ieee_get_rounding_mode(rounding)
    code=-1
    if (rounding==ieee_nearest) code=0
    if (rounding==ieee_up) code=1
    if (rounding==ieee_down) code=2
    if (rounding==ieee_to_zero) code=3
    call ieee_get_flag(ieee_invalid,flags(1))
    call ieee_get_flag(ieee_divide_by_zero,flags(2))
    call ieee_get_flag(ieee_overflow,flags(3))
    call ieee_get_flag(ieee_underflow,flags(4))
    call ieee_get_flag(ieee_inexact,flags(5))
    call ieee_get_halting_mode(ieee_invalid,halting(1))
    call ieee_get_halting_mode(ieee_divide_by_zero,halting(2))
    call ieee_get_halting_mode(ieee_overflow,halting(3))
    call ieee_get_halting_mode(ieee_underflow,halting(4))
    call ieee_get_halting_mode(ieee_inexact,halting(5))
    write(*,'(A,1X,A,1X,I0,11(1X,I0))') 'ENV',trim(label),mode,code,merge(1,0,flags),merge(1,0,halting)
  end subroutine
end module
