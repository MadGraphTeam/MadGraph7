#!/usr/bin/env python3
"""Source and exact-integer tests only. No compiler, loader or amplitude calls."""
import ast
from fractions import Fraction
import hashlib
import importlib.util
import io
import json
from math import isqrt
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
import aloha
from madgraph.core import base_objects, helas_objects
from madgraph.loop import loop_helas_objects
from madgraph.iolibs import file_writers

TEMPLATE = Path('madgraph/iolibs/template_files/loop_optimized')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


PREP = load('current_mass_prepare', HERE / 'prepare.py')
OLD_E = load('current_mass_old_exporter', HERE / 'base' / PREP.EXPORTER)
NEW_E = load('current_mass_new_exporter', HERE / 'src' / PREP.EXPORTER)
OLD_W = load('current_mass_old_writer', HERE / 'base' / PREP.WRITER)
NEW_W = load('current_mass_new_writer', HERE / 'src' / PREP.WRITER)
EXAMPLES = {}


def amplitude(masses, widths=None, pairing=None, number=1, group=0):
    widths = widths or ['ZERO'] * len(masses)
    pairing = pairing or [1] * len(masses)
    seed = helas_objects.HelasWavefunction({'number': 1, 'is_loop': True})
    lines = [helas_objects.HelasWavefunction({
        'particle': base_objects.Particle({'mass': m, 'width': w}), 'is_loop': True,
        'mothers': helas_objects.HelasWavefunctionList([seed])})
        for m, w in zip(masses, widths, strict=True)]
    result = loop_helas_objects.LoopHelasAmplitude({
        'wavefunctions': helas_objects.HelasWavefunctionList([seed, seed] + lines),
        'mothers': helas_objects.HelasWavefunctionList([
            helas_objects.HelasWavefunction({'number': i+11}) for i in range(sum(pairing))]),
        'amplitudes': helas_objects.HelasAmplitudeList([helas_objects.HelasAmplitude({'number': number})]),
        'pairing': pairing, 'number': number, 'loop_group_id': group})
    if len(result.get_masses()) != len(masses):
        raise ValueError('Malformed real graph fixture')
    return result


def direct(module, amp, prefix='MP__', rank=2):
    writer = module.FortranUFOHelasCallWriterOptimized(base_objects.Model())
    writer.mp_prefix = prefix
    with mock.patch.object(loop_helas_objects.LoopHelasAmplitude, 'get_analytic_info', return_value=rank):
        return writer.get_amplitude_call(amp)


def calls(module, amps, born=True, grouped=True):
    diagram = loop_helas_objects.LoopHelasDiagram({'amplitudes': helas_objects.HelasAmplitudeList(amps)})
    matrix = loop_helas_objects.LoopHelasMatrixElement({
        'processes': base_objects.ProcessList([base_objects.Process({'has_born': born})]),
        'diagrams': helas_objects.HelasDiagramList([diagram])})
    matrix['loop_groups'] = [((), amps)] if grouped else []
    writer = module.FortranUFOHelasCallWriterOptimized(base_objects.Model())
    with mock.patch.object(loop_helas_objects.LoopHelasAmplitude, 'get_analytic_info', return_value=2):
        return writer.get_loop_CT_calls(matrix, group_loops=grouped)


def branches(source):
    rows = source.splitlines()
    if len(rows) != 5 or rows[0] != 'IF(CTMODE.LT.4) THEN' or rows[2] != 'ELSE' or rows[4] != 'ENDIF':
        raise ValueError('Guarded call is not an indivisible complete block')
    return rows[1], rows[3]


def routines(source):
    result, current = {}, None
    for line in source.splitlines():
        m = re.match(r'\s*(?:SUBROUTINE|BLOCK DATA)\s+(\w+)', line, re.I)
        if m:
            current = m[1]
            if current in result:
                raise ValueError('Duplicate Fortran routine')
            result[current] = []
        if current:
            result[current].append(line)
            if re.fullmatch(r'\s*END\s*', line, re.I):
                current = None
    return {key: '\n'.join(value) for key, value in result.items()}


def context(amplitude=False, nrs=True, tir=True, qp=True):
    return dict(AmplitudeReduction=amplitude, LoopInduced=amplitude,
        samurai_available=False, ninja_available=True, ninja_supports_quad_prec=True,
        ninjars_available=nrs, ninjars_supports_quad_prec=nrs and qp,
        tirust_available=tir, tirust_supports_quad_prec=tir and qp)


def preprocess(source, ctx):
    with tempfile.TemporaryDirectory(prefix='preprocess-', dir=HERE) as tmp:
        with file_writers.FortranWriter(str(Path(tmp) / 'unused.f')) as writer:
            return '\n'.join(writer.preprocess_template(source, context=ctx))


def round_binary(value, precision):
    """Nearest-even positive rational at unrestricted binary exponent, integer only."""
    if value == 0:
        return value
    sign = -1 if value < 0 else 1
    value = abs(value)
    exponent = value.numerator.bit_length() - value.denominator.bit_length()
    if value < Fraction(2)**exponent:
        exponent -= 1
    quantum = Fraction(2)**(exponent-precision+1)
    q, rem = divmod((value/quantum).numerator, (value/quantum).denominator)
    denominator = (value/quantum).denominator
    if 2*rem > denominator or (2*rem == denominator and q % 2):
        q += 1
    return sign*q*quantum


class CurrentMassSource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='templates-', dir=HERE)
        cls.templates = Path(cls.temp.name)
        shutil.copytree(ROOT / TEMPLATE, cls.templates, dirs_exist_ok=True)
        shutil.copytree(HERE / 'src' / TEMPLATE, cls.templates, dirs_exist_ok=True)
        all_text = ''.join(p.read_text() for p in cls.templates.iterdir() if p.is_file())
        cls.mapping = {k: 2 if fmt == 'd' else '' for k, fmt in re.findall(r'%\((\w+)\)([ds])', all_text)}
        cls.mapping.update(proc_prefix='TEST_', real_dp_format='REAL*8', real_mp_format='REAL*16',
            complex_dp_format='COMPLEX*16', complex_mp_format='COMPLEX*32',
            mass_dp_format='COMPLEX*16', mass_mp_format='COMPLEX*32', maxrank=6)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def export(self, module, old=False):
        exporter = object.__new__(module.LoopProcessOptimizedExporterFortranSA)
        exporter.template_dir = str(ROOT / TEMPLATE if old else self.templates)
        exporter.opt = {'vector_size': 0}
        matrix = mock.Mock()
        matrix.rep_dict = dict(self.mapping)
        matrix.get.return_value = [base_objects.Process({'has_born': True})]
        matrix.get_used_helas_loop_amps.return_value = [(n,n) for n in range(1,7)] + [(1,2),(2,3),(3,4)]
        matrix.get_loop_diagrams.return_value = []
        ct = module.LoopProcessExporterFortranSA.write_CT_interface(exporter, None, matrix, optimized_output=True)
        return ct + '\n' + exporter.write_TIRUST_interface(None, matrix)

    def test_01_exact_preparation_reproduces_and_production_unchanged(self):
        prep = json.loads((HERE/'preparation.json').read_text())
        base = {str(name): (HERE/'base'/name).read_text() for name in PREP.FILES}
        regenerated = PREP.sources(base, PREP.OLD_GUARD.read_text())
        for name, text in regenerated.items():
            self.assertEqual(text, (HERE/'src'/name).read_text(), name)
        for name, wanted in prep['original_files'].items():
            self.assertEqual(PREP.sha(ROOT/name), wanted)
        for name in ['TIRUST_interface.inc','NINJARS_interface.inc','CT_interface.inc','helas_loop_amplitude.inc']:
            self.assertEqual((HERE/'base'/TEMPLATE/name).read_bytes(), (HERE/'src'/TEMPLATE/name).read_bytes())

    def test_02_legacy_routines_identical_both_storage_branches(self):
        old, new = self.export(OLD_E, True), self.export(NEW_E)
        for amplitude_mode in (False,True):
            before = routines(preprocess(old, context(amplitude_mode)))
            after = routines(preprocess(new, context(amplitude_mode)))
            for name, body in before.items():
                self.assertEqual(body, after[name], name)
            self.assertNotIn('TEST_MP_NINJARS_LOOP_QPMASS', after)
            for n,mothers in [(n,n) for n in range(1,7)]+[(1,2),(2,3),(3,4)]:
                name = 'TEST_LOOP_%d%s' % (n,'' if n==mothers else '_%d'%mothers)
                body = after[name+'_QPMASS']
                self.assertLess(body.index('IF(CTMODE.LT.4)'), body.index('DOING_QP ='))
                self.assertLess(body.index('CALL TEST_CHOOSE_LOOPLIB'), body.index('MP_M2L(1)='))
                self.assertIn('IF(DOING_QP.AND.MLReductionLib(I_LIB).EQ.9)', body)
                self.assertNotIn('MLReductionLib(I_LIB).EQ.8.OR.', body)
                self.assertIn('MP_M2L(1)=MP_M%d**2'%n,body)
                for i in range(2,n+1):
                    self.assertIn('MP_M2L(%d)=MP_M%d**2'%(i,i-1),body)
                self.assertIn('MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L,',body)
                self.assertIn('MP_NINJA_LOOP(NLOOPLINE,MP_PL,M2L,',body)
                self.assertIn('CTLOOP(NLOOPLINE,PL,M2L,',body)
                self.assertIn('MP_TIRUST_LOOP_QPMASS(NLOOPLINE,MP_PL,MP_M2L,',body)
            EXAMPLES['routines_amplitude_'+str(amplitude_mode)] = sorted(after)

    def test_03_only_private_qp_adapter_formals_names_differ(self):
        source = self.export(NEW_E)
        for amplitude_mode in (False,True):
            data = routines(preprocess(source, context(amplitude_mode)))
            for name in ('TEST_MP_TIRUST_LOOP','TEST_MP_TIRUST_TENSOR_DIAGNOSTIC'):
                restored = data[name+'_QPMASS'].replace('_QPMASS(', '(')
                restored = restored.replace('COMPLEX*32 M2L(NLOOPLINE)','COMPLEX*16 M2L(NLOOPLINE)')
                self.assertEqual(data[name],restored,name)

    def test_04_actual_symbols_and_dp_guard(self):
        for cms in (False,True):
            for prefix in ('MP__','QP__'):
                with mock.patch.object(aloha,'complex_mass',cms):
                    amp=amplitude(['ZERO','MDL_MW','MDL_MT'],['ZERO','ZERO','MDL_WT'])
                    block=direct(NEW_W,amp,prefix)
                    dp,qp=branches(block)
                    self.assertEqual(dp,direct(OLD_W,amp,prefix))
                    self.assertNotIn(prefix,dp)
                    for symbol in ('ZERO','MDL_MW','CMASS_MDL_MT' if cms else 'MDL_MT'):
                        self.assertIn('CMPLX('+prefix+symbol+',KIND=16)',qp)
                    self.assertNotIn('**2',block)
                    EXAMPLES['symbols_'+str(cms)+'_'+prefix]=block

    def test_05_grouped_ungrouped_loop_induced_and_one_item(self):
        amps=[amplitude(['ZERO','MDL_MB'],number=7,group=3),amplitude(['ZERO','MDL_MB'],number=9,group=3)]
        for born,grouped in ((True,True),(True,False),(False,True),(False,False)):
            old,new=calls(OLD_W,amps,born,grouped),calls(NEW_W,amps,born,grouped)
            self.assertEqual(len(old),len(new))
            for before,after in zip(old,new,strict=True):
                self.assertEqual(before, branches(after)[0] if before.startswith('CALL ') else after)
            self.assertEqual([a.get('loop_group_id') for a in amps],[3,3])
            self.assertEqual(sum(s.startswith('IF(CTMODE') for s in new),1 if born and grouped else 2)

    def test_06_actual_200_retained_ew_symbol_mappings(self):
        groups=json.loads((ROOT/'docs/benchmarkfolder/experiments/ew-qp-mass-prototype/group-mapping.json').read_text())['groups']
        self.assertEqual(len(groups),200)
        for group in groups:
            family=group['entrypoint'].split('_LOOP_')[1].split('_')
            n=int(family[0]); mothers=int(family[1]) if len(family)>1 else n
            args=group['original_actuals']; offset=n if n!=mothers else 0
            pairing=list(map(int,args[:n])) if offset else [1]*n
            amp=amplitude([m['model_symbol'] for m in group['mass_pairs']],pairing=pairing,
                number=group['loop_group'],group=group['loop_group']-1)
            for mother,number in zip(amp.get('mothers'),args[offset:offset+mothers],strict=True):
                mother.set('number',int(number))
            with mock.patch.object(aloha,'complex_mass',False):
                dp,qp=branches(direct(NEW_W,amp,rank=int(args[-3]))%{'proc_prefix':'ML5_0_'})
            self.assertEqual(dp,'CALL '+group['entrypoint']+'('+','.join(args)+')')
            self.assertEqual(qp,'CALL '+group['new_entrypoint']+'('+','.join(group['new_actuals'])+')')

    def test_07_chunk_boundary_and_common_layout(self):
        exporter=object.__new__(NEW_E.LoopProcessOptimizedExporterFortranSA)
        exporter.template_dir=str(self.templates)
        for born in (False,True):
            amp=amplitude(['ZERO','MDL_MB'])
            call_list=[s%self.mapping for s in calls(NEW_W,[amp],born,False)]
            rep=dict(self.mapping)
            text=exporter.split_HELASCALLS(None,rep,'helas_calls_split.inc','',call_list,
                'loop_CT_calls','loop_CT_calls',n_helas=1,context=context(not born))
            self.assertEqual(text.count('IF(CTMODE.LT.4)'),1)
            self.assertIn('COMMON/TEST_CT/LSCALE,CTMODE',text)
            with tempfile.TemporaryDirectory(prefix='render-',dir=HERE) as tmp:
                path=Path(tmp)/'caller.f'
                with file_writers.FortranWriter(str(path)) as stream:
                    stream.writelines(text,context=context(not born))
                rendered=path.read_text()
                self.assertTrue(all(len(line)<=132 for line in rendered.splitlines()))
                self.assertEqual(rendered.count('CTMODE.LT.4'),1)

    def test_08_availability_closure(self):
        source=self.export(NEW_E)
        for nrs,tir,qp in ((False,False,False),(True,True,False),(True,False,True),(False,True,True)):
            emitted=preprocess(source,context(nrs=nrs,tir=tir,qp=qp))
            definitions=routines(emitted)
            for symbol in re.findall(r'CALL\s+(TEST_MP_\w+_QPMASS)\(',emitted):
                self.assertIn(symbol,definitions)
            self.assertEqual('TEST_MP_TIRUST_LOOP_QPMASS' in definitions,tir and qp)
            self.assertNotIn('TEST_MP_NINJARS_LOOP_QPMASS',definitions)

    def test_09_n3_nonzero_mass_and_exact_mb_square_witness(self):
        path=ROOT/'.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n3_uux_zgg/SubProcesses/P0_uux_zgg/loop_CT_calls_1.f'
        text=path.read_text()
        self.assertEqual(text.count('DCMPLX(MDL_MB)'),43)
        self.assertEqual(text.count('DCMPLX(MDL_MT)'),43)
        mass=Fraction(5291729562160333,1125899906842624)
        exact=mass*mass
        self.assertEqual(round_binary(exact,113),exact)
        self.assertNotEqual(round_binary(exact,53),exact)
        self.assertEqual(round_binary(exact,53)-exact,Fraction(2206763817411543,1267650600228229401496703205376))
        EXAMPLES['MB_square_witness']={
            'mass':str(mass),'square_exact':str(exact),'square_significand_bits':exact.numerator.bit_length(),
            'old_square_DP':str(round_binary(exact,53)),'new_square_QP':str(round_binary(exact,113)),
            'MP_mass_input_has_extra_bits':False,'MP_square_recovers_bits':True}

    def test_10_genuine_qp_derived_and_complex_unit_controls(self):
        # Integer-only nearest binary128 sqrt(2), with a strict rounding-cell proof.
        scale=1<<112
        lo=isqrt(2*scale*scale)
        significand=lo+int(8*scale*scale>(2*lo+1)**2)
        derived=Fraction(significand,scale)
        self.assertLess((derived-Fraction(1,2*scale))**2,2)
        self.assertGreater((derived+Fraction(1,2*scale))**2,2)
        self.assertNotEqual(derived,round_binary(derived,53))
        real=1+Fraction(1,1<<100); imag=-Fraction(1,1<<90)
        self.assertEqual(round_binary(real,113),real)
        self.assertNotEqual(round_binary(real,53),real)
        square=(round_binary(real*real-imag*imag,113),round_binary(2*real*imag,113))
        self.assertNotEqual(square[0],round_binary(real*real-imag*imag,53))
        sources=ROOT/'docs/benchmarkfolder/experiments/ew-qp-mass-prototype/sources'
        self.assertIn('MP__MDL_MW = SQRT(CMPLX(', (sources/'reference-15-mp_intparam_definition.inc').read_text())
        self.assertIn('MP__CMASS_MDL_MW = SQRT(CMPLX(', (sources/'reference-11-mp_intparam_definition.inc').read_text())
        EXAMPLES['genuine_QP_unit_controls']={
            'derived_sqrt2_binary128':str(derived),'complex_mass_real':str(real),'complex_mass_imag':str(imag),
            'complex_square_QP_real':str(square[0]),'complex_square_QP_imag':str(square[1]),
            'native_test_executed':False,'physical_model_truth_qualified':False}


def main():
    baseline=json.loads((HERE/'preparation.json').read_text())['original_files']
    log=io.StringIO()
    forbidden=[]
    def blocked(*args,**kwargs):
        forbidden.append(str(args[:1]));raise RuntimeError('Native/process API blocked during source tests')
    with mock.patch.object(subprocess,'Popen',side_effect=blocked),mock.patch.object(os,'system',side_effect=blocked):
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CurrentMassSource))
    for name,wanted in baseline.items():
        if PREP.sha(ROOT/name)!=wanted:raise ValueError('Production bytes changed')
    print(log.getvalue(),end='')
    receipt={'schema':'current-source-backend9-only-qp-mass-source-tests-v1','tests_run':result.testsRun,
        'errors':len(result.errors),'failures':len(result.failures),'success':result.wasSuccessful(),
        'forbidden_API_attempts':forbidden,'compiler_calls':0,'native_amplitudes':0,'examples':EXAMPLES,
        'production_original_hashes_unchanged':True,'physical_truth_qualified':False}
    suffix='optimized' if not __debug__ else 'normal'
    with (HERE/('tests-'+suffix+'.log')).open('x') as stream:stream.write(log.getvalue())
    with (HERE/('tests-'+suffix+'.json')).open('x') as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    if forbidden or not result.wasSuccessful():raise SystemExit(1)


if __name__=='__main__':
    main()
