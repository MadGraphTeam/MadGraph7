#!/usr/bin/env python3
"""Create a private current-source backend9-only QP mass proposal; no native tools."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TEMPLATE = Path('madgraph/iolibs/template_files/loop_optimized')
WRITER = Path('madgraph/iolibs/helas_call_writers.py')
EXPORTER = Path('madgraph/loop/loop_exporters.py')
OLD_GUARD = ROOT / '.tirust-build/qp-mass-general-implementation/caller-guard-proposal/src' / WRITER
FILES = [WRITER, EXPORTER] + [TEMPLATE / name for name in (
    'helas_loop_amplitude.inc', 'helas_calls_split.inc', 'TIRUST_interface.inc',
    'NINJARS_interface.inc', 'CT_interface.inc')]


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def method_span(source, cls, method):
    tree = ast.parse(source)
    family = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == cls)
    node = next(node for node in family.body if isinstance(node, ast.FunctionDef) and node.name == method)
    return node.lineno - 1, node.end_lineno


def method(source, cls, name):
    a, b = method_span(source, cls, name)
    return ''.join(source.splitlines(keepends=True)[a:b])


def swap_once(source, old, new):
    require(source.count(old) == 1, 'Expected one exact source site: ' + old[:90])
    return source.replace(old, new)


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def sources(base, guarded_writer):
    result = dict(base)
    family = 'FortranUFOHelasCallWriterOptimized'
    current = base[str(WRITER)]
    a, b = method_span(current, family, 'generate_loop_amplitude_call')
    lines = current.splitlines(keepends=True)
    replacement = method(guarded_writer, family, 'generate_loop_amplitude_call')
    result[str(WRITER)] = ''.join(lines[:a]) + replacement + ''.join(lines[b:])

    split_name = str(TEMPLATE / 'helas_calls_split.inc')
    result[split_name] = swap_once(base[split_name], "      include 'coupl.inc'\n",
        "      include 'coupl.inc'\n"
        "      %(real_dp_format)s LSCALE\n"
        "      INTEGER CTMODE\n"
        "      COMMON/%(proc_prefix)sCT/LSCALE,CTMODE\n")

    helper = base[str(TEMPLATE / 'helas_loop_amplitude.inc')]
    helper = swap_once(helper, '%(nwfsargs_header)s(%(pairingargs)s%(wfsargs)s%(margs)s',
        '%(nwfsargs_header)s_QPMASS(%(pairingargs)s%(wfsargs)s%(qp_mass_args)s')
    helper = swap_once(helper, '      %(mass_dp_format)s %(margsdecl)s\n',
        '      %(mass_dp_format)s %(margsdecl)s\n'
        '      %(complex_mp_format)s %(mp_margsdecl)s\n')
    helper = swap_once(helper, '      %(mass_dp_format)s M2L(NLOOPLINE)\n',
        '      %(mass_dp_format)s M2L(NLOOPLINE)\n'
        '      %(complex_mp_format)s MP_M2L(NLOOPLINE)\n')
    helper = swap_once(helper, 'C Determine it uses qp or not\n',
        'C Direct legacy callers retain their ABI and DP arithmetic.\n'
        '      IF(CTMODE.LT.4) THEN\n'
        '        CALL %(proc_prefix)sLOOP_%(nloopline)d%(nwfsargs_header)s(%(qp_mass_legacy_args)s)\n'
        '        RETURN\n'
        '      ENDIF\nC Determine it uses qp or not\n')
    choose = '      CALL %(proc_prefix)sCHOOSE_LOOPLIB(LIBINDEX,NLOOPLINE,RANK,complex_mass,ID,doing_qp,I_LIB)\n'
    helper = swap_once(helper, choose, choose +
        'C Evaluate QP squares only for the actually selected backend9.\n'
        '      IF(DOING_QP.AND.MLReductionLib(I_LIB).EQ.9) THEN\n'
        '%(qp_mass_square_assignment)s\n'
        '      ENDIF\n')
    old_call = 'MP_TIRUST_LOOP(NLOOPLINE,MP_PL,M2L,RANK'
    require(helper.count(old_call) == 2, 'Both interference and amplitude routes must exist')
    helper = helper.replace(old_call, 'MP_TIRUST_LOOP_QPMASS(NLOOPLINE,MP_PL,MP_M2L,RANK')
    result[str(TEMPLATE / 'helas_loop_amplitude_qpmass.inc')] = helper

    tir = base[str(TEMPLATE / 'TIRUST_interface.inc')]
    routines = []
    for name in ('MP_TIRUST_TENSOR_DIAGNOSTIC', 'MP_TIRUST_LOOP'):
        start = tir.index('      SUBROUTINE %(proc_prefix)s' + name + '(')
        stop = tir.index('\n      END\n', start) + len('\n      END\n')
        body = tir[start:stop]
        require(body.count('      %(mass_dp_format)s M2L(NLOOPLINE)') == 1, 'One QP mass formal')
        body = body.replace('      %(mass_dp_format)s M2L(NLOOPLINE)',
            '      %(complex_mp_format)s M2L(NLOOPLINE)')
        for symbol in ('MP_TIRUST_TENSOR_DIAGNOSTIC', 'MP_TIRUST_LOOP'):
            body = body.replace(symbol + '(', symbol + '_QPMASS(')
        routines.append(body)
    result[str(TEMPLATE / 'TIRUST_qpmass_interface.inc')] = (
        '## if(tirust_supports_quad_prec){\n' + '\n'.join(routines) + '## }\n')

    exporter = base[str(EXPORTER)]
    anchor = ('            files.append(file)\n        \n        file="\\n".join(files)\n'
              '        \n        if writer:\n            writer.writelines(file,context=self.get_context(matrix_element))')
    addition = '''            files.append(file)
            if optimized_output:
                # Private paired helper preserves every legacy helper above.
                qp = dict(replace_dict)
                qp['qp_mass_args'] = ''.join('M%d,MP_M%d, ' % (i,i)
                                             for i in range(1,callkey[0]+1))
                qp['qp_mass_legacy_args'] = (qp['pairingargs'] + qp['wfsargs'] +
                    qp['margs'] + 'RANK,SQUAREDSOINDEX,LOOPNUM')
                squares = ['        MP_M2L(1)=MP_M%d**2' % callkey[0]] + [
                    '        MP_M2L(%d)=MP_M%d**2' % (i,i-1)
                    for i in range(2,callkey[0]+1)]
                qp['qp_mass_square_assignment'] = '\\n'.join(squares)
                with open(os.path.join(self.template_dir, 'helas_loop_amplitude_qpmass.inc')) as stream:
                    files.append(misc.apply_template(stream.read(), qp))
        
        file="\\n".join(files)
        
        if writer:
            writer.writelines(file,context=self.get_context(matrix_element))'''
    exporter = swap_once(exporter, anchor, addition)
    anchor = ("        with open(os.path.join(self.template_dir, 'TIRUST_interface.inc')) as stream:\n"
              '            source = stream.read() % replace_dict\n')
    exporter = swap_once(exporter, anchor, anchor +
        "        with open(os.path.join(self.template_dir, 'TIRUST_qpmass_interface.inc')) as stream:\n"
        "            source += '\\n' + stream.read() % replace_dict\n")
    ast.parse(exporter)
    ast.parse(result[str(WRITER)])
    result[str(EXPORTER)] = exporter
    return result


def main():
    require(not (HERE / 'base').exists() and not (HERE / 'src').exists(), 'Preparation is exclusive')
    baseline = {str(name): (ROOT / name).read_text() for name in FILES}
    original_hashes = {str(name): sha(ROOT / name) for name in FILES}
    guarded = OLD_GUARD.read_text()
    generated = sources(baseline, guarded)
    for family, values in [('base', baseline), ('src', generated)]:
        for name, data in values.items():
            path = HERE / family / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(data)
    patch = ''.join(''.join(difflib.unified_diff(
        baseline.get(name, '').splitlines(keepends=True), source.splitlines(keepends=True),
        fromfile='a/' + name, tofile='b/' + name))
        for name, source in generated.items() if source != baseline.get(name))
    (HERE / 'implementation.patch').write_text(patch)
    require(original_hashes == {str(name): sha(ROOT / name) for name in FILES}, 'Production changed')
    dump(HERE / 'preparation.json', {
        'schema': 'current-source-backend9-only-qp-mass-source-v1',
        'production_source_commit': '0fcd2cd873d61d134837e1d9e87afb13a47824fd',
        'installed_native_sha256': 'eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9',
        'original_files': original_hashes,
        'guarded_writer_source': str(OLD_GUARD.relative_to(ROOT)),
        'guarded_writer_sha256': sha(OLD_GUARD),
        'base_files': len(baseline), 'candidate_files': len(generated),
        'production_writes': False, 'native_execution': False, 'compiler_calls': 0,
        'new_backend_scope': [9], 'legacy_public_abi_preserved': True,
        'source_only_no_scientific_qualification': True,
    })
    print(json.dumps({'prepared': True, 'base_files': len(baseline), 'candidate_files': len(generated)}))


if __name__ == '__main__':
    main()
