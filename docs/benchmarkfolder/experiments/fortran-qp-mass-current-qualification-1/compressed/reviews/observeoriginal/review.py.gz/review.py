"""Pure closed OBSERVEORIGINAL numerical/provenance replay; no scientific controller import."""
from pathlib import Path
import argparse,ast,builtins,collections,ctypes,hashlib,io,json,math,os,re,statistics,struct,subprocess,sys,time,types
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2';REPORT=ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/observeoriginal';BUILD=REPORT.parent/'build';OUT=Path(__file__).resolve().parent
S='3c0f53a6e5526535b6fae98b0f055466b429a9a9cfc863fb22fb999a5c8a0815';B='74fd12c5bb49d62a59eee94657e25cb9b27760beb90901f6b2ac07c3416a070a';U='1601d5e7bb364f94cba13e4d8375ad7e2d930800a3946d7577fa3298e69ade9a'
seen={}
def digest(p):
 p=Path(p).resolve();key=str(p)
 if key not in seen:seen[key]=hashlib.sha256(p.read_bytes()).hexdigest()
 return seen[key]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_bytes())
def funcs(text,names,namespace):
 tree=ast.parse(text);nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 assert {n.name for n in nodes}==set(names);exec(compile(ast.Module(body=nodes,type_ignores=[]),'<exact frozen pure definitions>','exec'),namespace)
def words(rows):return [{'point':r['point'],'order':r['order'],'status':r['status'],'words':[struct.pack('>d',x).hex().upper() for x in r['coefficients']+[r['accuracy']]]} for r in rows]
def history(text):return [list(map(int,line.split()[:4])) for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
def software(text):
 rows=[list(map(int,line.split())) for line in text.splitlines() if line.strip()]
 assert len(rows)==200 and [r[:2] for r in rows]==[[i,p] for i in range(1,101) for p in (1,2)] and all(len(r)==4 and all(x in (0,1) for x in r[2:]) for r in rows)
 return rows


from fractions import Fraction
def independent_mass(parsed,proof):
 def bits(ws):return sum(int(w,16)<<(64*i) for i,w in enumerate(ws))
 def decode(b,width):
  nf,bias,ne=(112,16383,15) if width==128 else (52,1023,11)
  e=(b>>nf)&((1<<ne)-1);assert e!=(1<<ne)-1
  sig=(b&((1<<nf)-1))|((1<<nf) if e else 0)
  return (-1 if b>>(width-1) else 1)*sig*Fraction(2)**((e-bias if e else 1-bias)-nf)
 def encode(v,width):
  nf,bias=(112,16383) if width==128 else (52,1023)
  if not v:return 0
  sign=int(v<0);v=abs(v);e=v.numerator.bit_length()-v.denominator.bit_length()
  if v<Fraction(2)**e:e-=1
  q=Fraction(2)**(e-nf);scaled=v/q;s,r=divmod(scaled.numerator,scaled.denominator)
  if 2*r>scaled.denominator or 2*r==scaled.denominator and s%2:s+=1
  if s==1<<(nf+1):s>>=1;e+=1
  assert 0<e+bias<(1<<(15 if width==128 else 11))-1
  return sign<<(width-1)|(e+bias)<<nf|(s-(1<<nf))
 table={r['group']:r for r in proof['groups']};counts=collections.Counter();reversals=0;slots=0;coefs=0;shifts=0;invariants=0
 for g in parsed['groups']:
  assert g['role']==0 and g['status']==0 and g['coefficients'] is not None and g['native'] is not None
  metadata=table[g['id']];assert metadata['rank']==g['rank'] and len(metadata['mass_pairs'])==g['n']
  model=parsed['models'][str(g['point'])];symbols=[p['model_symbol'] for p in metadata['mass_pairs']]
  expected=[]
  for sym,formal in zip(symbols,g['formals'],strict=True):
   value=Fraction(0) if sym=='ZERO' else decode(int(model['DP'][0 if sym=='MDL_MB' else 1],16),64)
   assert bits(formal[:2])==encode(value,128) and bits(formal[2:])==0
   expected.append(value);counts[sym]+=1
  expected=[expected[-1],*expected[:-1]]
  for v,d,q in zip(expected,g['DP_squares'],g['QP_squares'],strict=True):
   dpsq=encode(v*v,64);assert int(d[0],16)==dpsq and int(d[1],16)==0
   assert bits(q[:2])==encode(decode(dpsq,64),128) and bits(q[2:])==0;slots+=1
  native_expected=g['QP_squares']
  if g['mode']==5 and g['n']>2:native_expected=[native_expected[0],*reversed(native_expected[1:])];reversals+=1
  assert g['native']['masses']==native_expected
  decode(bits(g['native']['scale']),128)
  assert len(g['coefficients'])==(g['rank']+1)*(g['rank']+2)*(g['rank']+3)*(g['rank']+4)//24
  coefs+=len(g['coefficients']);shifts+=4*g['n'];invariants+=g['n']**2
 return {'groups':len(parsed['groups']),'points_with_model_snapshots':len(parsed['models']),'formal_symbol_slots':dict(counts),'DP_square_and_exact_QP_widened_slots':slots,'native_reversals':reversals,'numerator_complex_QP_records':coefs,'native_real_QP_shift_records':shifts,'native_real_QP_invariant_records':invariants,'finite_native_scale_records':len(parsed['groups']),'independent_model_MU_R_join_available':False,'all_complete_native_status_zero':True,'candidate_input_claim':False}

def main(expected_terminal,expected_result):
 start=time.monotonic();match(SRC/'source-index.json',S);seal=read(SRC/'source-index.json')
 for n,v in seal['files'].items():match(SRC/n,v['sha256'])
 for n,h in seal['support'].items():match(ROOT/n,h)
 match(REPORT/'terminal.json',expected_terminal);match(REPORT/'result.json',expected_result);terminal=read(REPORT/'terminal.json');result=read(REPORT/'result.json')
 assert terminal['status']==result['status']=='passed' and terminal['returncode']==0 and terminal['result_sha256']==expected_result and not terminal['cleanup']['survivors']
 assert terminal['source_index_sha256']==result['source_index_sha256']==S and terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60 and terminal['cpu']==12 and not terminal['cpu_reservation']
 assert result['reviewed']=={'build':B,'units':U,'cache0':'99e98e80fec29a6dbd2e0658b345c09d2fbf1d742e6af5edb6e18abbd6e3423c','cacheall':'2494f913028d9178203f835ad498e77a6413b82fb9318262a5abf8f6f20c692a'} and result['cache']==0 and set(result['lanes'])==set(result['learning'])=={'original-observed'}
 assert read(REPORT/'actual-limits.json')['actual']=={'address_space_bytes':[16*1024**3]*2,'file_bytes':[512*1024**2]*2,'core_bytes':[0,0]}
 for n,h in result['raw_files'].items():match(REPORT/n,h)
 match(BUILD/'terminal.json',B);match(REPORT.parent/'units/terminal.json',U);built=read(BUILD/'result.json');match(BUILD/'result.json',read(BUILD/'terminal.json')['result_sha256'])
 inputs=read(SRC/'input-pins.json');case=inputs['cases']['n3'];donor=Path(case['output']);prefix='SubProcesses/'+case['subprocess']+'/'
 for n,v in inputs['files'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,v['sha256'])
 for n,h in inputs['ancestry'].items():match(ROOT/n,h)
 for n,h in case['generated_sources'].items():match(donor/n,h)
 for n,h in case['numerical_objects'].items():match(donor/n,h)
 point_bytes=Path(case['points']).read_bytes();assert int(point_bytes.splitlines()[0])==100
 # Authenticated unchanged mathematical comparator and strict parsers only.
 analysis=types.ModuleType('mass_audit_analysis');exec(compile((SRC/'base_analysis.py').read_bytes(),'<frozen base analysis>','exec'),analysis.__dict__)
 comparator={};funcs((ROOT/'tools/tirust_benchmark.py').read_text(),{'compare_rows'},comparator)
 def compare(left,right):
  c=analysis.compare_variants(left,right,comparator['compare_rows']);assert c['passed'];changes=[]
  for a,b in zip(left,right,strict=True):
   if a['status']==219:assert a==b
   elif a['words']!=b['words']:changes.append({'point':a['point'],'order':a['order'],'original_words':a['words'],'candidate_words':b['words']})
  return {**c,'DP_exact':True,'QP_changed_rows':changes,'QP_input_precision_change_not_independent_finite_truth':True}
 worker_ns={'BACKEND_CODES':{(2,1):(1,'DP'),(3,9):(1,'QP'),(2,6):(6,'DP'),(3,8):(6,'QP'),(2,7):(7,'DP'),(2,8):(8,'DP'),(3,2):(8,'QP'),(2,9):(9,'DP'),(3,3):(9,'QP')}}
 funcs((ROOT/'tools/tirust_benchmark_worker.py').read_text(),{'MeasurementError','validate_status'},worker_ns)
 memory={};warm_ns={'math':math,'worker':types.SimpleNamespace(validate_status=worker_ns['validate_status']),'MeasurementError':worker_ns['MeasurementError']}
 class MemoryPath:
  def __init__(self,p):self.name=p.name if isinstance(p,MemoryPath) else str(p)
  def __truediv__(self,p):return MemoryPath(self.name+'/'+p)
  def is_file(self):return self.name in memory
  def open(self,*a,**k):return io.StringIO(memory[self.name])
 warm_ns['Path']=MemoryPath
 funcs((ROOT/'tools/tirust_benchmark_warmup.py').read_text(),{'_call_groups','parse_warmup'},warm_ns)
 expected_steady=words(read(case['closed_observation'])['rows']);historical_history=history(Path(case['closed_warmup']).read_text())
 raws={};bindings={};commands=0
 for role in ('original-observed',):
  folder=REPORT/role;row=built['variants'][role];out=ROOT/'.tirust-build/qp-mass-current-qualification-work-2/observeoriginal'/role;proc=out/prefix
  assert not (proc/'worker-protocol.fifo').exists();match(proc/'check',row['executable_sha256'])
  for n,h in row['sources'].items():match(out/n,h)
  for n,h in row['objects'].items():match(out/n,h)
  assert (out/'lib').is_symlink() and (out/'lib').resolve()==(donor/'lib').resolve()
  cardhash=digest(SRC/'cards/cache0.dat')
  for n in list(case['numerical_cards'])+[prefix+'MadLoop5_resources/MadLoopParams.dat']:match(out/n,cardhash)
  match(out/'Cards/param_card.dat',case['param_card_sha256'])
  runtime=row['runtime']['files'];assert len(runtime)==15
  for p,h in runtime.items():match(p,h)
  maps=[]
  for edge in ('before','after'):
   m=read(folder/('maps-'+edge+'.json'));rawnames=set()
   for line in m['maps'].splitlines():
    fields=line.split(None,5)
    if len(fields)==6 and fields[-1].startswith('/'):
     assert not fields[-1].endswith(' (deleted)');rawnames.add(str(Path(fields[-1]).resolve()))
   assert rawnames==set(m['files']);allowed={**runtime,**seal['allowed_extra_mappings'],str((proc/'check').resolve()):row['executable_sha256']}
   assert all(m['files'].get(p)==h for p,h in {**runtime,str((proc/'check').resolve()):row['executable_sha256']}.items())
   assert all(allowed.get(p)==h for p,h in m['files'].items())
   for p,h in m['files'].items():match(p,h)
   assert any(r['pid']==m['pid'] for r in terminal['cleanup']['observed_owned_processes']);maps.append(m)
  assert maps[0]['pid']==maps[1]['pid'] and maps[0]['files']==maps[1]['files']
  for p in (folder/'commands').glob('*.command.json'):
   c=read(p);label=p.name.removesuffix('.command.json');closed=read(p.with_name(label+'.terminal.json'));assert closed['returncode']==0
   match(p.with_name(label+'.stdout.txt'),closed['stdout_sha256']);assert c['argv'][1]=='--list';commands+=1
   providers={str(Path(m[1]).resolve()) for l in p.with_name(label+'.stdout.txt').read_text().splitlines() if 'linux-vdso' not in l and (m:=re.search(r'(/[^\s()]+)\s+\(0x',l))}
   assert providers==set(runtime)
  console=(folder/'worker.log').read_text();assert not re.search(r'##W03\b',console,re.I)
  texts={n:(folder/n).read_text() for n in ('warmup.dat','dimensions.dat')}
  for n,text in texts.items():memory[str(folder)+'/'+n]=text
  raws[role]={'texts':texts,'ready':read(folder/'ready.json'),'stored_warmup':read(folder/'warmup.json'),'learning_comparison':read(folder/'learning-comparison.json'),'exact':(folder/'exact/exact-words.dat').read_text(),'ieee':(folder/'exact/exact-ieee.dat').read_text(),'software':(folder/'exact/software-flags.dat').read_text()}
  assert read(folder/'exact/command.json')['command']==['EXACT',1,0]
  bindings[role]={'executable_sha256':row['executable_sha256'],'mapped_paths':len(maps[0]['files']),'mapped_runtime_providers':15,'pid':maps[0]['pid'],'W03_records':0,'canonical_objects':len(row['objects'])}
 match(REPORT.parent/'cache0/result.json','a0574f5710af9a70ad941297be523774bb97b8b909fa893de1d542c324892ed8')
 plain=read(REPORT.parent/'cache0/result.json')['lanes']['original']
 observer=types.ModuleType('frozen_mass_observer');exec(compile((SRC/'observer_analysis.py').read_bytes(),'<frozen observer parser>','exec'),observer.__dict__)
 observer_path=REPORT/'original-observed/mass-observer.hex';match(observer_path,'7e0350bb705968dc1e6ac23f079ccf48108ab2f1a0bb424463451393eeea427d')
 observer_text=observer_path.read_text();assert len(observer_text.encode())==16140498
 stored_mass=read(REPORT/'original-observed/observed-mass-summary.json');proof=read(SRC/'source-proof.json')
 saved=[];attempts=[]
 def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('Pure numerical replay forbids external APIs')
 def patch(obj,n):
  if hasattr(obj,n):saved.append((obj,n,getattr(obj,n)));setattr(obj,n,deny)
 try:
  for obj,names in [(builtins,['open']),(io,['open','open_code']),(Path,['open','read_bytes','read_text','resolve','stat','write_bytes','write_text']),(os,['open','stat','lstat','listdir','scandir','system','popen','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe']),(subprocess,['Popen','run','call','check_call','check_output']),(ctypes,['CDLL','PyDLL','_dlopen'])]:
   for n in names:patch(obj,n)
  if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
  replayed={};learning_rows={};bootstrap={}
  for role,raw in raws.items():
   folder=str(REPORT/role);warm=warm_ns['parse_warmup'](folder,9,100,raw['ready']);assert warm==raw['stored_warmup']
   assert warm['status_counts']=={'219':87,'323':13} and warm['backend_precision_counts']=={'9:DP':87,'9:QP':13}
   h=history(raw['texts']['warmup.dat']);assert h==historical_history==result['learning'][role]['history']
   learning_rows[role]=words(warm['rows']);assert learning_rows[role]==result['learning'][role]['rows']
   c=compare(expected_steady,learning_rows[role]);assert c==raw['learning_comparison']['comparison']==result['learning'][role]['comparison']
   rows=analysis.exact(raw['exact'],case['expected_codes']);ieee=analysis.ieee(raw['ieee']);soft=software(raw['software'])
   assert rows==result['lanes'][role]['rows'] and ieee==result['lanes'][role]['ieee'] and soft==result['lanes'][role]['software']
   replayed[role]={'rows':rows,'ieee':ieee,'software':soft};bootstrap[role]={'rows':sum(r[0]==0 for r in h),'call_indices':sorted({r[0] for r in h if r[0]==0}),'qualified':False}
  final_comparison=compare(plain['rows'],replayed['original-observed']['rows']);assert result['comparison'] is None
  learning_comparison=compare(expected_steady,learning_rows['original-observed'])
  assert result['lanes']['original-observed']==plain
  observed=observer.parse(observer_text,0);mass=observer.validate_mass_words(observed,proof)
  assert mass==stored_mass and not observed['incomplete_groups'] and observed['native_status_counts']=={'0':3016}
 finally:
  for obj,n,value in reversed(saved):setattr(obj,n,value)
 assert not attempts and commands==2
 independent=independent_mass(observed,proof)
 assert independent['groups']==3016 and independent['native_reversals']==1196
 assert not result['candidate_promoted'] and not result['independent_physical_finite_truth_qualified'] and not result['performance_acceptance'] and result['UseQPIntegrandForTIRust'] is True
 qpchanges=final_comparison['QP_changed_rows'];summary={'final':final_comparison,'learning_cross_arm':learning_comparison}
 (OUT/'comparisons.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 receipt={'schema':'independent-current-QP-mass-OBSERVEORIGINAL-audit-v1','status':'PASS','source_index_sha256':S,'build_terminal_sha256':B,'units_terminal_sha256':U,'observer_terminal_sha256':expected_terminal,'observer_result_sha256':expected_result,'raw_observer_sha256':digest(observer_path),'independent_mass_checks':independent,'audit_source_sha256':digest(Path(__file__)),'comparison_replay_sha256':digest(OUT/'comparisons.json'),'bindings':bindings,'final_answer_rows_total':200,'qualified_learning_answer_rows_total':200,'bootstrap_separate':bootstrap,'per_arm_physical_points':100,'per_arm_DP_points':87,'per_arm_QP_points':13,'all_DP_words_status_accuracy_exact':True,'final_QP_changed_rows':len(qpchanges),'final_coefficient_word_differences':final_comparison['coefficient_word_difference_count'],'final_accuracy_word_differences':final_comparison['accuracy_difference_count'],'maximum_relative_error':final_comparison['regression']['maximum_relative_error'],'predeclared_3e_6_and_1e_8_gates_passed':True,'hardware_and_software_states_equal':True,'two_loader_receipts_passed':True,'whole_final_lane_equals_plain_CACHE0':True,'cleanup_survivors':0,'forbidden_API_attempts':len(attempts),'protected_paths_hashed':len(seen),'new_native_calls':0,'scope':'One actual current loop_sm u u~ > z g g QCD full100 case with static real MB/MT and default-true QP numerator. Original-observer actual DP-square/widened native masses are qualified for these recorded calls; candidate native mass inputs remain unobserved. Physical input masses are not independently >53-bit. Agreement is not independent finite truth, CMS/dynamic-model/false-integrand, candidate-observer, mixed-rescue or performance qualification. Source-enforced fresh clone/learning and graceful shutdown, retained initialized maps and closed owner support runtime attribution; no trap-freedom or hidden internal retry claim.','next_step':'Separate root candidate-observer admission only; no automatic native launch.','elapsed_audit_seconds':time.monotonic()-start}
 (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'QP_changed_rows':len(qpchanges),'coefficient_word_differences':final_comparison['coefficient_word_difference_count'],'accuracy_word_differences':final_comparison['accuracy_difference_count'],'maximum_relative_error':receipt['maximum_relative_error'],'elapsed_seconds':receipt['elapsed_audit_seconds']}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--terminal',required=True);p.add_argument('--result',required=True);a=p.parse_args();main(a.terminal,a.result)
