"""Read/hash only; do not import or execute the scientific BUILD controller."""
import argparse,collections,datetime,hashlib,json,re,time
from pathlib import Path
ROOT=Path.cwd();SOURCE=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2';REPORT=ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/build';OUT=Path(__file__).resolve().parent
SEAL='3c0f53a6e5526535b6fae98b0f055466b429a9a9cfc863fb22fb999a5c8a0815'
seen={}
def digest(p):
 p=Path(p).resolve();k=str(p)
 if k not in seen:seen[k]=hashlib.sha256(p.read_bytes()).hexdigest()
 return seen[k]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())
def signature(r):return tuple((x['sha256'],x['version']) for x in r['compiler']),tuple(r['flags'])
def listing(text):
 paths=set()
 for line in text.splitlines():
  if not line.strip() or 'linux-vdso' in line:continue
  m=re.fullmatch(r'\s*(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)\s*',line);assert m,line
  paths.add(str(Path(m[1]).resolve()))
 return paths

def main(expected_terminal,expected_result):
 started=time.monotonic();match(SOURCE/'source-index.json',SEAL);seal=read(SOURCE/'source-index.json')
 for name,row in seal['files'].items():match(SOURCE/name,row['sha256']);assert (SOURCE/name).stat().st_size==row['bytes']
 for name,h in seal['support'].items():match(ROOT/name,h)
 match(REPORT/'terminal.json',expected_terminal);match(REPORT/'result.json',expected_result)
 terminal=read(REPORT/'terminal.json');built=read(REPORT/'result.json')
 assert terminal['status']==built['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
 assert terminal['source_index_sha256']==built['source_index_sha256']==SEAL and terminal['result_sha256']==expected_result
 assert terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60
 elapsed=None # This controller retains the enforced deadline, not independent start/end wall timestamps.
 limits=read(REPORT/'actual-limits.json');assert limits['actual']=={'address_space_bytes':[16*1024**3]*2,'file_bytes':[512*1024**2]*2,'core_bytes':[0,0]}
 assert built['native_amplitude_calls']==built['unit_executions']==0 and not built['compiler_policy_change'] and not built['private_MTIrust_rebuild']
 inputs=read(SOURCE/'input-pins.json');case=inputs['cases']['n3'];donor=Path(case['output']);objects=case['numerical_objects'];assert len(objects)==144
 for name,h in objects.items():match(donor/name,h)
 for name,h in case['generated_sources'].items():match(donor/name,h)
 for name,row in inputs['files'].items():match(Path(name) if Path(name).is_absolute() else ROOT/name,row['sha256'])
 for name,h in inputs['ancestry'].items():match(ROOT/name,h)
 for name,h in read(SOURCE/'predecessor.json')['files'].items():match(ROOT/name,h)
 assert read(ROOT/'.tirust-build/qp-mass-current-qualification-execution-1/build/terminal.json')['status']=='failed'
 assert not (ROOT/'.tirust-build/qp-mass-current-qualification-execution-1/build/result.json').exists()
 variants={};prefix='SubProcesses/'+case['subprocess']+'/'
 replace={prefix+n+'.o' for n in ('CT_interface','TIRUST_interface','loop_CT_calls_1','check_sa')}
 libraries={'lib/'+n for n in ('libcts.a','libdhelas.a','libiregi.a','libmodel.a','mpmodule.mod')}
 expected_private={n.lower()+'_qpmass_' for n in read(SOURCE/'source-proof.json')['helpers']}|{'ml5_0_mp_tirust_tensor_diagnostic_qpmass_','ml5_0_mp_tirust_loop_qpmass_'}
 assert len(expected_private)==9
 all_commands={};kinds=collections.Counter();physical_runtime=None
 assert set(built['variants'])=={'original','candidate','original-observed','candidate-observed'}
 for variant,row in built['variants'].items():
  output=Path(row['output']);proc=output/prefix;observed=variant.endswith('-observed');extras={prefix+'mgmass_observer.o',prefix+'mgmass_observer_state.mod'} if observed else set()
  assert set(row['objects'])==set(objects)|extras and len(row['sources'])==195
  assert (output/'lib').is_symlink() and str((output/'lib').readlink())==str((donor/'lib').resolve())
  assert not any(p.is_symlink() and p!=output/'lib' for p in output.rglob('*'))
  actual={str(p.relative_to(output)) for p in output.rglob('*') if p.is_file() and p.suffix.lower() in ('.o','.a','.mod') and 'build-history' not in p.parts and 'worker-raw' not in p.parts}
  assert actual|libraries==set(row['objects'])
  for name,h in row['objects'].items():match(output/name,h)
  for name,h in row['sources'].items():match(output/name,h)
  for name,h in objects.items():
   if name not in replace:assert row['objects'][name]==h
  changed=sorted(n for n in objects if row['objects'][n]!=objects[n]);assert set(changed)<=replace
  assert row['unchanged_objects']['unchanged']==140 and set(row['unchanged_objects']['replaced'])==replace
  for name in ('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','check_sa.f'):assert (proc/name).read_bytes()==(SOURCE/'source-preview'/variant/name).read_bytes()
  flags=row['compiler_flags'];assert flags['environment']==case['compiler_flags']['environment']=={} and set(flags['scopes'])==set(case['compiler_flags']['scopes'])
  for scope,policy in case['compiler_flags']['scopes'].items():
   assert set(policy['recipes'])==set(flags['scopes'][scope]['recipes'])
   for name,rec in policy['recipes'].items():assert signature(rec)==signature(flags['scopes'][scope]['recipes'][name])
  assert flags['scopes']['process']['recipes']['TIRUST_interface.f']['flags']==['-w','-fPIC','-ffixed-line-length-132']
  assert row['policy_evidence']['all_original_compiler_policies_preserved'] and not row['policy_evidence']['optimization_experiment']
  match(proc/'check',row['executable_sha256']);match(proc/'private-link.map',row['link_map_sha256']);match(REPORT/variant/'prelink.json',row['prelink_sha256'])
  pre=read(REPORT/variant/'prelink.json');assert pre['completed_before_link']
  for path,h in pre['bound'].items():match(path,h)
  loads={}
  for name in re.findall(r'^LOAD\s+(.+)$',(proc/'private-link.map').read_text(),re.M):
   path=Path(name);path=(proc/path).resolve() if not path.is_absolute() else path.resolve();loads[str(path)]=digest(path);assert pre['bound'].get(str(path))==loads[str(path)]
  assert loads==row['actual_link_loads']
  runtime=row['runtime']['files'];assert len(runtime)==15 and runtime==pre['explicit_current_runtime_before_link']
  assert listing(row['runtime']['listing'])|{row['runtime']['loader']}==set(runtime)
  for path,h in runtime.items():match(path,h)
  if physical_runtime is None:physical_runtime=runtime
  else:assert physical_runtime==runtime
  assert next(h for n,h in runtime.items() if n.endswith('/libmadloop_tirust.so'))==seal['native_sha256']
  text=(REPORT/variant/'commands/symbols.stdout.txt').read_text();defs=collections.Counter();private=[]
  for line in text.splitlines():
   parts=line.split()
   if len(parts)>=3 and parts[-1].startswith('__mtirust_MOD_'):defs[parts[-1]]+=1
   if parts and '_qpmass_' in parts[-1]:private.append(parts[-1])
  assert defs=={n:1 for n in inputs['expected_mtirust_symbols']}==row['MTIRUST_definitions'] and len(defs)==23
  assert set(private)==set(row['private_definitions'])==(expected_private if variant.startswith('candidate') else set()) and len(private)==len(set(private))
  assert not (proc/'mtirust.o').exists() and 'libtirust.a(' in (proc/'private-link.map').read_text()
  for idx,name in enumerate(('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','check_sa.f')):
   cmd=read(REPORT/variant/'commands'/f'{idx:02d}-compile-{name}.command.json')['argv'];assert cmd==row['selected_recipes'][idx][1]
  assert read(REPORT/variant/'commands/link.command.json')['argv']==row['link_command']
  variants[variant]={'executable_sha256':row['executable_sha256'],'canonical_object_count':len(row['objects']),'unselected_unchanged':140,'changed_original_object_names':changed,'runtime_providers':15,'actual_LOAD_paths':len(loads),'stock_MTIRUST_definitions':23,'private_QPMASS_definitions':len(private),'all_legacy_compiler_policies_equal':True}
 unit=built['units'];directory=Path(unit['output']);match(directory/'unit_mass_check',unit['executable_sha256']);match(directory/'unit-link.map',unit['link_map_sha256']);match(REPORT/'units/prelink.json',unit['prelink_sha256'])
 for name,h in unit['objects'].items():match(directory/name,h)
 pre=read(REPORT/'units/prelink.json');assert pre['completed_before_link']
 for path,h in pre['bound'].items():match(path,h)
 loads={}
 for name in re.findall(r'^LOAD\s+(.+)$',(directory/'unit-link.map').read_text(),re.M):
  path=Path(name);path=(directory/path).resolve() if not path.is_absolute() else path.resolve();loads[str(path)]=digest(path);assert pre['bound'].get(str(path))==loads[str(path)]
 assert loads==unit['actual_link_loads']
 runtime=unit['runtime']['files'];assert listing(unit['runtime']['listing'])|{unit['runtime']['loader']}==set(runtime)
 assert set(runtime)<set(physical_runtime) and all(physical_runtime[p]==h for p,h in runtime.items())
 assert not any(re.search('tirust|ninja|collier',Path(p).name,re.I) for p in runtime)
 for p,h in runtime.items():match(p,h)
 spec=read(SOURCE/'units/build-spec.json')
 def expand(argv):return [x.replace('{work}',str(directory)).replace('{units}',str(SOURCE/'units')) for x in argv]
 for rec in spec['compile_commands']:assert read(REPORT/'units/commands'/(rec['label']+'.command.json'))['argv']==expand(rec['argv'])
 link=expand(spec['link_command']);link.insert(1,'-Wl,-Map,unit-link.map,--cref');assert read(REPORT/'units/commands/unit-link.command.json')['argv']==link
 for path in REPORT.rglob('*.command.json'):
  cmd=read(path);label=path.name.removesuffix('.command.json');closed=read(path.with_name(label+'.terminal.json'))
  assert closed['returncode']==0;match(path.with_name(label+'.stdout.txt'),closed['stdout_sha256'])
  if 'stderr_sha256' in closed:match(path.with_name(label+'.stderr.txt'),closed['stderr_sha256'])
  assert not any(cmd['argv'][0]==str(Path(row['output'])/prefix/'check') for row in built['variants'].values()) and cmd['argv'][0]!=str(directory/'unit_mass_check')
  all_commands[str(path.relative_to(REPORT))]=digest(path)
  argv=cmd['argv']
  if '-c' in argv:k='compile'
  elif 'prelink-query-' in label:k='prelink-query'
  elif '--list' in argv:k='loader-list'
  elif '--version' in argv:k='compiler-version'
  elif '--defined-only' in argv:k='nm'
  elif label in ('link','unit-link'):k='link'
  else:k='make-policy-or-dryrun'
  kinds[k]+=1
 assert kinds['compile']==22 and kinds['link']==5 and kinds['nm']==4 and kinds['loader-list']==5
 # A closure-based BUILD readiness verdict does not supply any future unit result.
 report_hashes={str(p.relative_to(REPORT)):digest(p) for p in REPORT.rglob('*') if p.is_file()}
 result={'schema':'independent-current-QP-mass-BUILD2-audit-v1','status':'PASS','source_index_sha256':SEAL,'build_terminal_sha256':expected_terminal,'build_result_sha256':expected_result,'audit_source_sha256':digest(Path(__file__)),'variants':variants,'unit':{'executable_sha256':unit['executable_sha256'],'objects':len(unit['objects']),'runtime_provider_count':len(runtime),'reducer_DSOs':False,'actual_LOAD_paths':len(loads),'exact_source_only_recording_recipe':True},'recorded_command_count':len(all_commands),'recorded_command_kinds':dict(kinds),'all_recorded_commands_returned_zero':True,'commands_exclude_any_main_execution':True,'runtime_before_first_listing_bound':True,'protected_hashed_paths':len(seen),'retained_report_hashes':report_hashes,'native_BUILD_elapsed_seconds':elapsed,'caps':{'total_seconds':600,'cleanup_reserve_seconds':60,'address_space_bytes':16*1024**3},'cleanup_survivors':0,'failed_source1_preserved_and_unqualified':True,'next_step':'Only separate recording-unit RUN admission is scientifically ready; physical/cache/observer runs remain unqualified and separately gated.','new_native_or_tool_queries':0,'audit_elapsed_seconds':time.monotonic()-started}
 (OUT/'receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'commands':len(all_commands),'unit_runtime_providers':len(runtime),'elapsed_seconds':result['audit_elapsed_seconds']}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--terminal',required=True);p.add_argument('--result',required=True);a=p.parse_args();main(a.terminal,a.result)
