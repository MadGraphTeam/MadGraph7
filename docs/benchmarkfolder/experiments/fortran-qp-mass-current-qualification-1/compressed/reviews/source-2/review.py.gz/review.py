from pathlib import Path
import json,hashlib,ast
ROOT=Path.cwd();NEW=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2';OLD=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-1';OUT=ROOT/'.tirust-build/qp-mass-current-source2-independent-audit-1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected='3c0f53a6e5526535b6fae98b0f055466b429a9a9cfc863fb22fb999a5c8a0815'
assert sha(NEW/'source-index.json')==expected
index=json.loads((NEW/'source-index.json').read_bytes()); old=json.loads((OLD/'source-index.json').read_bytes())
assert {str(p.relative_to(NEW)) for p in NEW.rglob('*') if p.is_file()}==set(index['files'])|{'source-index.json'}
assert not any(p.is_symlink() for p in NEW.rglob('*'))
for n,v in index['files'].items():
 p=NEW/n;assert sha(p)==v['sha256'] and p.stat().st_size==v['bytes'];p.read_bytes().decode('utf-8')
for n,v in old['files'].items():assert sha(OLD/n)==v['sha256']
changed=[n for n in old['files'] if (NEW/n).read_bytes()!=(OLD/n).read_bytes()]
assert set(changed)=={'README.md','controller.py','input-pins.json','test_qualification.py','tests-normal.json','tests-normal.log','tests-optimized.json','tests-optimized.log'}
science=[n for n in old['files'] if n.startswith(('source-preview/','units/'))]
assert all((OLD/n).read_bytes()==(NEW/n).read_bytes() for n in science)
def funcs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
f1=funcs(OLD/'controller.py');f2=funcs(NEW/'controller.py')
changed_functions=[n for n in f1 if f1[n]!=f2[n]]
assert set(changed_functions)=={'protected','unchanged_objects','build','verified_build','private_binding'}
assert set(f2)-set(f1)=={'canonical_objects'}
for mode in ('normal','optimized'):
 r=json.loads((NEW/f'tests-{mode}.json').read_bytes());assert r['passed'] and r['tests']==19
ancestor=json.loads((NEW/'predecessor.json').read_bytes())
for n,h in ancestor['files'].items():assert sha(ROOT/n)==h
assert sha(ROOT/'.tirust-build/qp-mass-current-qualification-execution-1/build/terminal.json')=='fa0c14036f9ea341ec3f25f679fe9966c81b32dad245c1ebe976c050a267d5b5'
receipt={'schema':'independent-source2-mechanical-inventory-review-v1','status':'PASS','source_index_sha256':expected,'source_payloads':len(index['files']),'source_payload_bytes':sum(v['bytes'] for v in index['files'].values()),'audit_source_sha256':sha(Path(__file__)),'changed_files':changed,'changed_existing_controller_functions':changed_functions,'new_controller_function':'canonical_objects','unchanged_scientific_preview_unit_files':len(science),'review':'Exact intended donor-lib directory alias plus five mandatory leaf hashes/targets, other-alias rejection, and complete144 (+2observed) object key set are enforced at build, reviewed-build and worker binding. Source1 failure remains failed; no native/scientific/flag/cap changes. Actual failed-clone139-to144 regression and missing/modified/wrong-directory/extra-object negative controls were read with retained19+19 pass receipts; not rerun by this audit.','tests_run_by_auditor':0,'compiler_loader_or_native_calls':0,'scope':'Source/inventory clearance only; root separately admits a fresh BUILD.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':sha(OUT/'receipt.json'),'payloads':len(index['files']),'scientific_files_unchanged':len(science)}))
