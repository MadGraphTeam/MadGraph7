"""Closed recording-unit replay only; all scientific/native APIs stay unused."""
from pathlib import Path
from fractions import Fraction
from math import isqrt
import builtins,ctypes,hashlib,io,json,os,re,subprocess,sys,time,types
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2';REPORT=ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/units';BUILD=REPORT.parent/'build';OUT=Path(__file__).resolve().parent
S='3c0f53a6e5526535b6fae98b0f055466b429a9a9cfc863fb22fb999a5c8a0815';B='74fd12c5bb49d62a59eee94657e25cb9b27760beb90901f6b2ac07c3416a070a';T='1601d5e7bb364f94cba13e4d8375ad7e2d930800a3946d7577fa3298e69ade9a';R='65a1191f60bfc60735a8a41c58131e3c310b12295a1edd5b7c17c62152419f56';P='ac85190df536b6ac0b7e4d17332eb4f1c2bb174ffdf37f8ffe91a78fd67610ad'
seen={}
def digest(p):
 p=Path(p).resolve()
 if str(p) not in seen:seen[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return seen[str(p)]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_bytes())
def decode(words,width):
 bits=sum(int(v,16)<<(64*i) for i,v in enumerate(words));nf,bias,ne=(112,16383,15) if width==128 else (52,1023,11)
 exponent=(bits>>nf)&((1<<ne)-1);assert exponent!=(1<<ne)-1
 sig=(bits&((1<<nf)-1))|((1<<nf) if exponent else 0)
 power=(exponent-bias-nf) if exponent else 1-bias-nf
 return (-1 if bits>>(width-1) else 1)*sig*Fraction(2)**power, bits, Fraction(2)**power
start=time.monotonic();match(SRC/'source-index.json',S);seal=read(SRC/'source-index.json')
for n,w in seal['files'].items():match(SRC/n,w['sha256'])
match(BUILD/'terminal.json',B);bt=read(BUILD/'terminal.json');match(BUILD/'result.json',bt['result_sha256']);build=read(BUILD/'result.json')
match(REPORT/'terminal.json',T);match(REPORT/'result.json',R);match(REPORT/'parsed.json',P)
t=read(REPORT/'terminal.json');r=read(REPORT/'result.json');stored=read(REPORT/'parsed.json')
assert t['status']==r['status']=='passed' and t['returncode']==0 and not t['cleanup']['survivors']
assert t['result_sha256']==R and t['source_index_sha256']==r['source_index_sha256']==S
assert t['cap_seconds']==180 and t['cleanup_reserve_seconds']==60 and t['cpu']==12 and not t['cpu_reservation']
assert r['reviewed']=={'build':B} and read(REPORT/'admission.json')['reviewed']['build']==B
for n,h in r['raw_files'].items():match(REPORT/n,h)
assert read(REPORT/'actual-limits.json')['actual']=={'address_space_bytes':[16*1024**3]*2,'file_bytes':[512*1024**2]*2,'core_bytes':[0,0]}
cmd=read(REPORT/'commands/recording-units.command.json');closed=read(REPORT/'commands/recording-units.terminal.json')
assert closed['returncode']==0 and cmd['argv']==[cmd['cwd']+'/unit_mass_check'] and not cmd['subprocess_new_session']
assert cmd['controller_pid']==cmd['process_group']==cmd['session']==t['pid']
unit=build['units'];actual=Path(cmd['cwd']);original=Path(unit['output'])
for base in (actual,original):
 match(base/'unit_mass_check',unit['executable_sha256'])
 for n,h in unit['objects'].items():match(base/n,h)
 match(base/'unit-link.map',unit['link_map_sha256'])
pre=read(BUILD/'units/prelink.json');match(BUILD/'units/prelink.json',unit['prelink_sha256'])
for name,h in {**unit['actual_link_loads'],**unit['runtime']['files']}.items():match(name,h);assert pre['bound'][name]==h
assert len(unit['runtime']['files'])==5 and not any(re.search('tirust|ninja|collier',Path(n).name,re.I) for n in unit['runtime']['files'])
raw=(REPORT/'commands/recording-units.stdout.txt').read_bytes();assert digest(REPORT/'commands/recording-units.stdout.txt')==closed['stdout_sha256']
assert len(raw.decode().splitlines())==36 and not re.search(r'##W03\b',raw.decode(),re.I)
parser_bytes=(SRC/'units/parser.py').read_bytes();module=types.ModuleType('independent_recording_mass_parser');exec(compile(parser_bytes,'<authenticated unit parser>','exec'),module.__dict__)
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('Replay native/filesystem API forbidden')
def patch(obj,name):
 if hasattr(obj,name):saved.append((obj,name,getattr(obj,name)));setattr(obj,name,deny)
try:
 for obj,names in [(builtins,['open']),(io,['open','open_code']),(Path,['open','read_bytes','read_text','resolve','stat','write_text','write_bytes']),(os,['open','stat','lstat','listdir','scandir','system','popen','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe']),(subprocess,['Popen','run','call','check_call','check_output']),(ctypes,['CDLL','PyDLL','_dlopen'])]:
  for n in names:patch(obj,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 replay=module.parse(raw.decode())
finally:
 for obj,n,v in reversed(saved):setattr(obj,n,v)
assert not attempts and replay==stored==r['parsed']
# Independent direct decoding: validate rounding cells from observed values,
# rather than reuse the parser's integer encoder or square expectations.
rows=[x.split() for x in raw.decode().splitlines()];checks=0
for mode in (4,5):
 q=[];dp=[];squares=[]
 for label,dest,width in [('QPARG',q,128),('DPARG',dp,64),('MASS2',squares,128)]:
  for row in [x for x in rows if x[0]==label and x[1]==str(mode)]:
   w=width//64;dest.append((decode(row[3:3+w],width),decode(row[3+w:],width)))
 assert len(q)==len(dp)==len(squares)==3
 sqrt=q[0][0][0];quant=q[0][0][2];assert (sqrt-quant/2)**2<2<(sqrt+quant/2)**2 and q[0][1][0]==0
 assert q[1][0][0]==1+Fraction(1,2**100) and q[1][1][0]==-Fraction(1,8)-Fraction(1,2**90)
 assert q[2][0][0]==dp[2][0][0] and q[2][1][0]==dp[2][1][0]==0
 assert q[0][0][0]!=dp[0][0][0] and q[1][0][0]!=dp[1][0][0] and q[1][1][0]!=dp[1][1][0]
 assert abs(dp[2][0][0]-Fraction(47,10))<dp[2][0][2]/2
 for observed,argument in zip(squares,[q[2],q[0],q[1]]):
  a,b=argument[0][0],argument[1][0]
  for (value,bits,ulp),truth in zip(observed,[a*a-b*b,2*a*b]):
   error=abs(value-truth);assert error<=ulp/2 and (error<ulp/2 or bits%2==0);checks+=1
 assert squares[0][0][0]==q[2][0][0]**2 and squares[0][0][0].numerator.bit_length()==105
 assert [x for x in rows if x[0]=='CHOOSE' and x[1]==str(mode)]==[['CHOOSE',str(mode),'1','8','2','9','3','2','1','1','1']]
 assert replay['calls'][mode-4]['IEEE_before']==replay['calls'][mode-4]['IEEE_after']==[0,0,0,0,0,1,0,0,0,0,0]
assert replay['IEEE'][0]['state']==[0]*11 and replay['IEEE'][1]['state']==[0,0,0,0,0,1,0,0,0,0,0]
assert r['actual_reducer_executions']==0 and not r['candidate_promoted'] and not replay['real_CHOOSE_kernel_qualified'] and not replay['MP_SWITCH_ORDER_reversal_qualified']
receipt={'schema':'independent-current-QP-mass-recording-UNITS-audit-v1','status':'PASS','source_index_sha256':S,'build_terminal_sha256':B,'units_terminal_sha256':T,'units_result_sha256':R,'parsed_sha256':P,'raw_sha256':hashlib.sha256(raw).hexdigest(),'audit_source_sha256':digest(Path(__file__)),'strict_parser_replay_exact':True,'raw_records':36,'helper_calls':2,'CT_modes':[4,5],'requested_backend':8,'actual_selected_backend':9,'cyclic_mass_order':[3,1,2],'genuine_binary128_input_indices':[1,2],'independently_decoded_square_rounding_cells_checked':checks,'bottom_square_exact_significand_bits':105,'fresh_initial_flags':True,'prepared_inexact_only':True,'per_call_rounding_flags_halting_equal':True,'unit_executable_sha256':unit['executable_sha256'],'authenticated_recorded_BUILD_runtime_provider_count':5,'runtime_scope':'Actual BUILD PT_INTERP listing and prelink records plus current provider hashes; this short RUN records no /proc maps snapshot.','cleanup_survivors':0,'forbidden_API_attempts_during_parser_replay':len(attempts),'new_native_calls':0,'native_elapsed_seconds':None,'failed_source1_unqualified':True,'scope':'Recording helper/guard/mass transport only. Real reducers, actual CHOOSE and direction reversal, physical model initialization, physical accuracy, cache, performance and UseQPIntegrandFalse remain unqualified. Next physical cache0 is a separate root admission, not a result of this unit audit.','elapsed_audit_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_audit_seconds'],'raw_records':36,'replay_attempts':len(attempts)}))
