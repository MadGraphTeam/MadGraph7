"""Read-only diagnosis of the retained, unqualified first QP-mass BUILD."""
import hashlib,json,re,time
from collections import Counter
from pathlib import Path
ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SOURCE=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-1'
REPORT=ROOT/'.tirust-build/qp-mass-current-qualification-execution-1/build'
WORK=ROOT/'.tirust-build/qp-mass-current-qualification-work-1/build'
HERE=Path(__file__).resolve().parent
SEAL='9e27928625b59cc76e71a657799c18f21844050e6e79271ac8810f3f6a85ff06'
TERMINAL='fa0c14036f9ea341ec3f25f679fe9966c81b32dad245c1ebe976c050a267d5b5'
seen={}
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
    p=Path(p).resolve()
    if str(p) not in seen:seen[str(p)]=sha(p.read_bytes())
    return seen[str(p)]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())

def main():
    start=time.monotonic();match(SOURCE/'source-index.json',SEAL);seal=read(SOURCE/'source-index.json')
    for n,w in seal['files'].items():match(SOURCE/n,w['sha256']);assert (SOURCE/n).stat().st_size==w['bytes']
    for n,h in seal['support'].items():match(ROOT/n,h)
    match(REPORT/'terminal.json',TERMINAL);terminal=read(REPORT/'terminal.json')
    assert terminal['status']=='failed' and terminal['returncode']==1 and not terminal['cleanup']['survivors']
    assert terminal['source_index_sha256']==SEAL and terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60
    assert not (REPORT/'result.json').exists() and 'Unselected physics object changed' in (REPORT/'console.log').read_text()
    assert not any((WORK/n).exists() for n in ('candidate','original-observed','candidate-observed','units'))
    pin=read(SOURCE/'input-pins.json');case=pin['cases']['n3'];out=WORK/'original';donor=Path(case['output'])
    old=case['numerical_objects'];assert len(old)==144
    actual={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.suffix.lower() in ('.o','.mod','.a') and 'build-history' not in p.parts and 'worker-raw' not in p.parts}
    missing=sorted(set(old)-set(actual));extras=sorted(set(actual)-set(old))
    assert missing==['lib/libcts.a','lib/libdhelas.a','lib/libiregi.a','lib/libmodel.a','lib/mpmodule.mod'] and not extras and len(actual)==139
    assert (out/'lib').is_symlink() and (out/'lib').resolve()==(donor/'lib').resolve()
    aliases={}
    for name in missing:
        match(out/name,old[name]);match(donor/name,old[name])
        aliases[name]={'sha256':old[name],'resolved':str((out/name).resolve()),'exists':(out/name).is_file()}
    changed={n:{'original':old[n],'clone':actual[n]} for n in set(old)&set(actual) if old[n]!=actual[n]}
    prefix='SubProcesses/'+case['subprocess']+'/'
    assert set(changed)=={prefix+'check_sa.o'}
    replaced={prefix+n+'.o' for n in ('CT_interface','TIRUST_interface','loop_CT_calls_1','check_sa')}
    assert all(actual.get(n,aliases.get(n,{}).get('sha256'))==h for n,h in old.items() if n not in replaced)
    for n,h in old.items():match(donor/n,h)
    for n,h in case['generated_sources'].items():match(donor/n,h)
    for n in ('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','check_sa.f'):
        assert (out/prefix/n).read_bytes()==(SOURCE/'source-preview/original'/n).read_bytes()
    logs=REPORT/'original/commands';counts=Counter();commands={}
    for path in logs.glob('*.command.json'):
        label=path.name.removesuffix('.command.json');c=read(path);t=read(logs/(label+'.terminal.json'))
        assert t['returncode']==0;match(logs/(label+'.stdout.txt'),t['stdout_sha256'])
        if 'stderr_sha256' in t:match(logs/(label+'.stderr.txt'),t['stderr_sha256'])
        commands[label]=c['argv']
        if '-compile-' in label:kind='compile'
        elif label.startswith('prelink-query-'):kind='prelink'
        elif label.startswith('policy-'):kind='version' if '--version' in c['argv'] else 'make'
        elif label=='expanded-check':kind='make'
        else:kind={'link':'link','symbols':'nm','actual-pt-interp-runtime':'loader'}[label]
        counts[kind]+=1
    assert len(commands)==67 and counts=={'compile':4,'prelink':51,'make':7,'version':2,'link':1,'nm':1,'loader':1}
    assert commands['01-compile-TIRUST_interface.f'][1:4]==['-w','-fPIC','-ffixed-line-length-132'] and '-O3' not in commands['01-compile-TIRUST_interface.f']
    for number in ('01','02','03','04'):
        assert (logs/('policy-before-'+number+'.stdout.txt')).read_bytes()==(logs/('policy-after-'+number+'.stdout.txt')).read_bytes()
    pre=read(REPORT/'original/prelink.json');assert pre['completed_before_link']
    for p,h in pre['bound'].items():match(p,h)
    for p,h in pre['explicit_current_runtime_before_link'].items():assert pre['bound'][p]==h
    assert len(pre['explicit_current_runtime_before_link'])==15
    symbols=(logs/'symbols.stdout.txt').read_text();definitions=Counter()
    for line in symbols.splitlines():
        fields=line.split()
        if len(fields)>=3 and fields[-1].startswith('__mtirust_MOD_'):definitions[fields[-1]]+=1
    assert definitions=={n:1 for n in pin['expected_mtirust_symbols']} and len(definitions)==23
    assert not any('_qpmass_' in line.split()[-1] for line in symbols.splitlines() if line.split())
    proc=out/prefix;assert not (proc/'mtirust.o').exists()
    loadpaths=[]
    for spelling in re.findall(r'^LOAD\s+(.+)$',(proc/'private-link.map').read_text(),re.M):
        path=Path(spelling);path=(proc/path).resolve() if not path.is_absolute() else path.resolve()
        assert str(path) in pre['bound'];loadpaths.append(str(path))
    assert 'libtirust.a(' in (proc/'private-link.map').read_text()
    listing=(logs/'actual-pt-interp-runtime.stdout.txt').read_text();providers={}
    for line in listing.splitlines():
        if 'linux-vdso' in line:continue
        found=re.search(r'(/[^\s()]+)\s+\(0x',line);assert found
        path=str(Path(found[1]).resolve());assert path in pre['explicit_current_runtime_before_link'];providers[path]=digest(path)
    assert providers==pre['explicit_current_runtime_before_link']
    assert next(h for n,h in providers.items() if n.endswith('/libmadloop_tirust.so'))==seal['native_sha256']
    retained={str(p.relative_to(REPORT)):digest(p) for p in REPORT.rglob('*') if p.is_file()}
    receipt={'schema':'independent-current-QP-mass-failed-BUILD-audit-v1','audit_status':'PASS','native_BUILD_status':'FAILED_UNQUALIFIED',
        'source_index_sha256':SEAL,'failed_terminal_sha256':TERMINAL,'result_json_absent':True,'recorded_commands':dict(counts),'recorded_command_count':67,
        'all_recorded_commands_returned_zero':True,'retained_report_files':retained,'original_executable_sha256':digest(proc/'check'),
        'prelink_sha256':digest(REPORT/'original/prelink.json'),'link_map_sha256':digest(proc/'private-link.map'),
        'unique_link_LOAD_paths':len(set(loadpaths)),'runtime_provider_count':15,'unique_stock_MTIRUST_definitions':23,
        'donor_object_count':144,'rglob_clone_count':139,'missing_from_rglob_only':aliases,'unexpected_objects':extras,'changed_objects':changed,
        'all_140_unselected_bindings_match_when_exact_aliases_read':True,
        'diagnosis':'clone lib/ is an intentional directory symlink; Path.rglob does not descend it. The five omitted library/module aliases exist and directly hash to frozen originals. The current unchanged_objects comparison consequently fails before a BUILD result is written.',
        'minimal_successor_shape':'Preserve failed source/stage; explicitly validate and merge only the five source-pinned lib aliases, including exact link destination and hashes, into private object inventory. Do not blanket-exempt lib or alter scientific/source/compiler policy.',
        'candidate_observed_unit_builds_not_started':True,'main_or_scientific_runs_not_started':True,'recorded_cleanup_survivors':0,
        'RUN_admissible':False,'audit_native_calls':0,'audit_compiler_calls':0,'audit_loader_calls':0,'audit_source_sha256':sha(Path(__file__).read_bytes()),
        'elapsed_seconds':time.monotonic()-start}
    destination=HERE/'receipt.json';assert not destination.exists();destination.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'audit_status':'PASS','BUILD':'FAILED_UNQUALIFIED','receipt':str(destination),'sha256':digest(destination),'elapsed':receipt['elapsed_seconds']}))

if __name__=='__main__':main()
