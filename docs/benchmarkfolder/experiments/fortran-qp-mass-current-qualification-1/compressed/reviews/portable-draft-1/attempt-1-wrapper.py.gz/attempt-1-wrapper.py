import ast,builtins,collections,collections.abc,ctypes,gzip,hashlib,importlib.util,io,json,math,os,posixpath,re,shlex,shutil,statistics,struct,subprocess,sys,time,types
from pathlib import Path
sys.dont_write_bytecode=True
capsule=Path('.tirust-build/qp-mass-current-retention-1/package').resolve()
expected='464199630c9aaa43edef10026041777af5b55be09cc8655431fe0c06b1296bb4'
manifest=capsule/'draft-inputs.json'
before=hashlib.sha256(manifest.read_bytes()).hexdigest()
if before!=expected:raise RuntimeError('Draft changed before independent review')
root=str(capsule);attempts=[];reads=[]
blocked_events={'os.mkdir','os.remove','os.rmdir','os.rename','os.link','os.symlink','os.chmod','os.chown','os.truncate','os.utime','shutil.copyfile','shutil.copymode','shutil.copystat','shutil.rmtree'}
def reject(event,detail):
 attempts.append({'event':event,'detail':str(detail)})
 raise RuntimeError('Independent audit rejected an external or mutating effect')
def audit(event,args):
 if event=='open':
  path,mode,flags=args
  if isinstance(path,int):return
  absolute=os.path.realpath(os.path.abspath(os.fsdecode(path)))
  if not (absolute==root or absolute.startswith(root+os.sep)):reject(event,absolute)
  if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):reject(event,absolute)
  reads.append(absolute)
 elif event in ('os.scandir','os.listdir'):
  path=args[0]
  if isinstance(path,int):reject(event,path)
  absolute=os.path.realpath(os.path.abspath(os.fsdecode(path)))
  if not (absolute==root or absolute.startswith(root+os.sep)):reject(event,absolute)
 elif event in blocked_events or event.startswith(('subprocess.','ctypes.','os.system','os.exec','os.posix_spawn','os.fork','os.spawn')):
  reject(event,args[:2])
sys.addaudithook(audit)
spec=importlib.util.spec_from_file_location('independent_mass_capsule_review',capsule/'replay.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
started=time.monotonic();result=module.verify(capsule,draft=True,expected_index_sha256=expected);elapsed=time.monotonic()-started
after=hashlib.sha256(manifest.read_bytes()).hexdigest()
if before!=after or attempts or result['forbidden_API_attempts']!=0:raise RuntimeError('Independent review changed data or attempted an effect')
print(json.dumps({'status':'passed','draft_manifest_sha256':before,'manifest_unchanged':before==after,'capsule_only_reads':len(reads),'external_or_mutating_attempts':len(attempts),'nested_forbidden_API_attempts':result['forbidden_API_attempts'],'pure_replay_seconds':elapsed,'stage_status':result['numerical']['stage_status'],'all_planned_stages_closed_pass':result['numerical']['all_planned_stages_closed_pass'],'source_groups':result['source_derivation']['groups'],'build_commands':result['build_commands'],'new_native_executions':0,'scope':'Independent source/draft replay only; no pending-stage, physical-finite-truth or performance qualification.'},sort_keys=True))
