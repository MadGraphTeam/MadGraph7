"""Read-only fresh-export comparison. Logical diagnostics never qualify code.

Only explicitly declared literal root paths and complete comment banner lines
can be normalized. Raw hashes and raw diffs always precede that normalization.
No MG import, process creation, native loading or source rewriting occurs here.
"""
import difflib
import hashlib
from pathlib import Path, PurePosixPath
import re


FILES = ('CT_interface.f', 'TIRUST_interface.f', 'loop_CT_calls_1.f')
PUBLIC_FILES = FILES[:2]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def validate_normalization(normalization):
    policy = {'root_paths': [], 'banner_lines': []}
    if normalization is None:
        return policy
    require(isinstance(normalization, dict), 'Normalization must be a mapping')
    require(set(normalization) <= set(policy), 'Unknown normalization rule')
    for kind in policy:
        rows = normalization.get(kind, [])
        require(isinstance(rows, (list, tuple)), 'Normalization rows must be a list')
        for row in rows:
            require(isinstance(row, dict) and set(row) == {'source', 'target'},
                    'Normalization requires exact source and target literals')
            source, target = row['source'], row['target']
            require(isinstance(source, str) and isinstance(target, str) and source != target,
                    'Normalization literals must be distinct strings')
            if kind == 'root_paths':
                for path in (source, target):
                    require(path.startswith('/') and path != '/' and '\n' not in path and '\r' not in path
                            and '..' not in PurePosixPath(path).parts and not path.endswith('/'),
                            'Root normalization requires complete absolute directory roots')
            else:
                for line in (source, target):
                    require(line.endswith('\n') and '\n' not in line[:-1] and '\r' not in line
                            and line[0] in 'Cc*!' and not line.startswith(('C$', 'c$', '!$', '*$')),
                            'Banner normalization requires one exact non-directive comment line')
            require(source not in [item['source'] for item in policy[kind]], 'Duplicate normalization source')
            policy[kind].append(dict(row))
    all_sources = [row['source'] for rows in policy.values() for row in rows]
    require(all(not any(source in row['target'] for source in all_sources)
                for rows in policy.values() for row in rows), 'Normalization must not chain')
    return policy


def normalize(text, policy):
    counts = []
    for row in policy['root_paths']:
        # A directory root is not a substring of another path component.
        pattern = re.compile(r'(?<![A-Za-z0-9_./-])' + re.escape(row['source']) + r'(?=/|[\s\'\"]|$)')
        text, count = pattern.subn(lambda _: row['target'], text)
        counts.append({'kind': 'root_path', **row, 'occurrences': count})
    for row in policy['banner_lines']:
        lines = text.splitlines(keepends=True)
        count = sum(line == row['source'] for line in lines)
        text = ''.join(row['target'] if line == row['source'] else line for line in lines)
        counts.append({'kind': 'banner_line', **row, 'occurrences': count})
    return text, counts


def logical_blocks(text):
    """Fixed-form statement spans, retaining exact raw body bytes separately."""
    lines = text.splitlines(keepends=True)
    i = 0
    while i < len(lines):
        first = i
        line = lines[i]
        if not line.strip() or line[0] in 'Cc*!':
            yield first, i + 1, None
            i += 1
            continue
        require(not line[132:].strip(), 'Executable source beyond column 132')
        require(len(line) > 5 and line[5] in ' 0\n', 'Orphan fixed-form continuation')
        label = line[:5].strip()
        require(not label or label.isdigit(), 'Invalid fixed-form statement label')
        statement = line[6:132].strip()
        i += 1
        while i < len(lines) and len(lines[i]) > 5 and lines[i][0] not in 'Cc*!' and lines[i][5] not in ' 0\n':
            require(not lines[i][132:].strip(), 'Continuation beyond column 132')
            require(not lines[i][:5].strip(), 'Label on continuation line')
            statement += ' ' + lines[i][6:132].strip()
            i += 1
        yield first, i, (label, statement)


def routines(text):
    """Extract named subroutines AND BLOCK DATA, with unmodified raw spans."""
    lines = text.splitlines(keepends=True)
    found = {}
    active = None
    for first, last, logical in logical_blocks(text):
        if logical is None:
            continue
        _, statement = logical
        header = re.fullmatch(r'(SUBROUTINE)\s+(\w+)\s*\((.*)\)', statement, re.I)
        block = re.fullmatch(r'(BLOCK\s+DATA)\s+(\w+)', statement, re.I)
        if header or block:
            match = header or block
            require(active is None, 'Nested or unterminated Fortran unit')
            name = match[2].upper()
            require(name not in found, 'Duplicate Fortran unit: ' + name)
            active = (name, first, 'subroutine' if header else 'block_data')
        elif re.fullmatch(r'END(?:\s+(?:SUBROUTINE|BLOCK\s+DATA)(?:\s+\w+)?)?', statement, re.I):
            require(active is not None, 'END outside supported Fortran unit')
            name, start, kind = active
            found[name] = {'text': ''.join(lines[start:last]), 'kind': kind}
            active = None
        elif active is None:
            raise ValueError('Unsupported executable text outside named unit: ' + statement)
    require(active is None, 'Unterminated Fortran unit')
    require(bool(found), 'No named Fortran units')
    return found


def canonical_statement(statement):
    """Diagnostic only: preserve quoted literals, labels, tokens and ordering.

    This is not a Fortran semantic proof. Ordinary comments and external
    whitespace are ignored ONLY here, never in a strict comparison.
    """
    result = []
    i = 0
    while i < len(statement):
        char = statement[i]
        if char in "'\"":
            quote = char
            start = i
            i += 1
            while i < len(statement):
                if statement[i] == quote:
                    i += 1
                    if i < len(statement) and statement[i] == quote:
                        i += 1
                        continue
                    break
                i += 1
            else:
                raise ValueError('Unterminated quoted diagnostic literal')
            result.append(statement[start:i])
        else:
            if not char.isspace():
                result.append(char.upper())
            i += 1
    return ''.join(result)


def logical_diagnostic(text):
    lines = text.splitlines(keepends=True)
    result = []
    for first, last, logical in logical_blocks(text):
        if logical is None:
            line = lines[first]
            if line.startswith(('C$', 'c$', '!$', '*$')) or re.match(r'^[Cc][Ff]2[Pp][Yy]', line):
                result.append(['directive', line])
        else:
            label, statement = logical
            result.append([label, canonical_statement(statement)])
    return result


def difference(expected, actual, expected_name, actual_name):
    return ''.join(difflib.unified_diff(expected.splitlines(keepends=True), actual.splitlines(keepends=True),
                                       fromfile=expected_name, tofile=actual_name))


def pair(expected, actual, label, policy, diagnostic=True):
    before, before_rules = normalize(expected, policy)
    after, after_rules = normalize(actual, policy)
    result = {'expected_raw_sha256': digest(expected), 'actual_raw_sha256': digest(actual),
              'raw_bytes_equal': expected == actual, 'allowed_normalized_bytes_equal': before == after,
              'raw_diff': difference(expected, actual, label + '/expected', label + '/actual'),
              'allowed_normalized_diff': difference(before, after, label + '/expected-normalized', label + '/actual-normalized'),
              'normalization_occurrences': {'expected': before_rules, 'actual': after_rules}}
    if diagnostic:
        left, right = logical_diagnostic(before), logical_diagnostic(after)
        result['logical_diagnostic'] = {'equal': left == right, 'expected': left, 'actual': right,
                                       'qualifies_source': False, 'semantic_equivalence_proven': False}
    return result


def compare_sources(original, candidate, preview_original, preview_candidate, normalization=None):
    policy = validate_normalization(normalization)
    for role, files in (('original', original), ('candidate', candidate),
                        ('preview_original', preview_original), ('preview_candidate', preview_candidate)):
        require(set(files) == set(FILES), 'Unexpected file set for ' + role)
        require(all(isinstance(value, str) for value in files.values()), 'Sources must be UTF-8 strings')
    report = {'schema': 'fresh-qp-mass-CLI-source-comparison-v1', 'status': 'generated_pending_source_review',
              'normalization': policy, 'logical_diagnostics_qualify_source': False,
              'semantic_equivalence_proven': False, 'requires_explicit_source_review': True,
              'files': {}, 'public_legacy_bodies_exact': True, 'public_legacy_raw_bodies_exact': True,
              'original_preview_exact': True, 'private_names_exact': True, 'private_bodies_exact': True,
              'caller_exact': True, 'whole_files_exact': True}
    for name in FILES:
        source = {'original_preview': pair(preview_original[name], original[name], name + '/original-preview', policy),
                  'fresh_vs_materialized': pair(preview_candidate[name], candidate[name], name + '/fresh-vs-materialized', policy)}
        report['original_preview_exact'] &= source['original_preview']['allowed_normalized_bytes_equal']
        report['whole_files_exact'] &= source['fresh_vs_materialized']['allowed_normalized_bytes_equal']
        if name in PUBLIC_FILES:
            old, fresh = routines(original[name]), routines(candidate[name])
            po, pc = routines(preview_original[name]), routines(preview_candidate[name])
            source['public'] = {}
            for symbol, row in old.items():
                if symbol not in fresh:
                    source['public'][symbol] = {'missing': True}
                    report['public_legacy_bodies_exact'] = report['public_legacy_raw_bodies_exact'] = False
                else:
                    comparison = pair(row['text'], fresh[symbol]['text'], name + '/public/' + symbol, policy)
                    source['public'][symbol] = comparison
                    report['public_legacy_bodies_exact'] &= comparison['allowed_normalized_bytes_equal']
                    report['public_legacy_raw_bodies_exact'] &= comparison['raw_bytes_equal']
            expected_private, actual_private = set(pc) - set(po), set(fresh) - set(old)
            report['private_names_exact'] &= expected_private == actual_private
            source['private_names'] = {'expected': sorted(expected_private), 'actual': sorted(actual_private),
                                       'missing': sorted(expected_private - actual_private), 'unexpected': sorted(actual_private - expected_private)}
            source['private'] = {symbol: pair(pc[symbol]['text'], fresh[symbol]['text'], name + '/private/' + symbol, policy)
                                 for symbol in sorted(expected_private & actual_private)}
            report['private_bodies_exact'] &= (expected_private == actual_private and
                all(row['allowed_normalized_bytes_equal'] for row in source['private'].values()))
            source['routine_order'] = {'expected': list(pc), 'actual': list(fresh), 'equal': list(pc) == list(fresh)}
        else:
            # This caller intentionally changes. Its raw full-file delta must
            # remain visible; it is never folded into the legacy-routine gate.
            routines(original[name]); routines(candidate[name])
            report['caller_exact'] &= source['fresh_vs_materialized']['allowed_normalized_bytes_equal']
        report['files'][name] = source
    report['strict_pass'] = all(report[key] for key in ('original_preview_exact', 'public_legacy_bodies_exact',
        'private_names_exact', 'private_bodies_exact', 'caller_exact', 'whole_files_exact'))
    report['native_calls'] = report['compiler_calls'] = 0
    return report


def compare_trees(original_dir, candidate_dir, preview_original_dir, preview_candidate_dir, normalization=None):
    def read(directory):
        # read_bytes avoids universal-newline translation hiding CRLF changes.
        return {name: (Path(directory) / name).read_bytes().decode('utf-8') for name in FILES}
    return compare_sources(read(original_dir), read(candidate_dir), read(preview_original_dir),
                           read(preview_candidate_dir), normalization)
