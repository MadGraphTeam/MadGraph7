#!/usr/bin/env python3
"""Dormant current-source QP mass qualification; no native work in default mode."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import struct
import subprocess
import sys
import time
import types

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/qp-mass-current-qualification-work-1'
REPORT=ROOT/'.tirust-build/qp-mass-current-qualification-execution-1'
CPU=12;CLEANUP=60.
CAPS={'build':600.,'units':180.,'cache0':600.,'cacheall':600.,'observeoriginal':600.,'observecandidate':600.}
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
LOADER='docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py'
CLEANUP_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'
DEADLINE_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/run.py'
VARIANTS=('original','candidate','original-observed','candidate-observed')
EXPECTED_SOURCE=None
REVIEWED={name:None for name in ('build','units','cache0','cacheall','observeoriginal')}
PREREQUISITES={'build':(), 'units':('build',), 'cache0':('build','units'),
 'cacheall':('build','units','cache0'),
 'observeoriginal':('build','units','cache0','cacheall'),
 'observecandidate':('build','units','cache0','cacheall','observeoriginal')}
OBSERVATION_FILES={'worker-protocol.fifo','worker-raw','warmup.dat','dimensions.dat','values.dat','timing.dat',
 'timed_status.dat','exact-words.dat','exact-ieee.dat','software-flags.dat','mass-observer.hex',
 'timed-exact-words.dat','timed-ieee.dat','anchor-timing.dat','anchor-status.dat','anchor-exact.dat',
 'anchor-ieee.dat','anchor-values.dat'}

def require(value,message):
    if not value:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text())


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def load(name,path):
    path=Path(path)
    if path.is_relative_to(ROOT) and not path.is_relative_to(HERE):
        require(digest(path)==read(HERE/'support-pins.json')['files'][str(path.relative_to(ROOT))],
                'Pinned helper changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module


def local(name):return load('mgmass_'+name,HERE/(name+'.py'))


def modules():
    sys.path.insert(0,str(ROOT/'tools'))
    import tirust_benchmark as bench
    import tirust_benchmark_compiler as compiler
    from tirust_benchmark_worker import Worker,parse_outputs
    from tirust_benchmark_warmup import parse_warmup
    return bench,compiler,Worker,parse_outputs,parse_warmup


def expected_runtime(case):
    loader=load('mgmass_pure_loader',ROOT/LOADER);row=pin(case)
    interpreter=loader._support('run.py',{'interpreter'}).interpreter(proc(row['output'],case)/'check')
    files={str(Path(p).resolve()):h for p,h in row['runtime']['libraries'].items()};aliases={}
    for left,right in re.findall(r'^\s*(/[^\s]+)\s*=>\s*(/[^\s]+)\s*\(',row['runtime']['ldd'],re.M):
        if Path(left).resolve()==interpreter and Path(right).resolve()!=interpreter:
            name=str(Path(right).resolve())
            require('ld-linux' in Path(name).name and name in files,'Unknown historical loader alias')
            aliases[name]=files.pop(name)
    require(str(interpreter) in files,'Actual interpreter absent from historical closure')
    return {'files':files,'actual_interpreter':str(interpreter),'historical_ldd_only_aliases':aliases}


def clone(source,destination):
    source=Path(source);destination=Path(destination)
    def ignore(directory,names):
        excluded={n for n in names if n in OBSERVATION_FILES or n.endswith(('HelFilter.dat','LoopFilter.dat'))}
        if Path(directory)==source:excluded.add('lib')
        return excluded
    shutil.copytree(source,destination,symlinks=False,ignore=ignore)
    (destination/'lib').symlink_to((source/'lib').resolve(),target_is_directory=True)
    require(all(not p.is_symlink() or p==destination/'lib' for p in destination.rglob('*')),'Private mutable symlink remains')
    require(not any(destination.rglob('*HelFilter.dat')) and not any(destination.rglob('*LoopFilter.dat')),'Fresh filters remain')


def command(argv,cwd,logs,name):
    logs.mkdir(parents=True,exist_ok=True);argv=list(map(str,argv));env=environment();env['PWD']=str(cwd)
    dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd),'controller_pid':os.getpid(),
          'session':os.getsid(0),'process_group':os.getpgrp(),'subprocess_new_session':False})
    with (logs/(name+'.stdout.txt')).open('xb') as stream:
        done=subprocess.run(argv,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))})
    require(done.returncode==0,'Admitted command failed: '+name)
    return (logs/(name+'.stdout.txt')).read_text()


def capture_policy(directory,logs,label):
    """Retain policy helper commands too; make's internal children are not traced."""
    compiler=modules()[1];real=compiler.subprocess;sequence=0
    def recorded_run(argv,**kwargs):
        nonlocal sequence
        sequence+=1;name=label+'-'+str(sequence).zfill(2);logs.mkdir(parents=True,exist_ok=True)
        dump(logs/(name+'.command.json'),{'argv':list(map(str,argv)),'cwd':str(kwargs.get('cwd',directory)),
              'scope':'compiler-policy helper; make-internal child queries are not individually recorded'})
        done=real.run(argv,**kwargs)
        stdout=done.stdout or '';stderr=done.stderr or ''
        require(isinstance(stdout,str) and isinstance(stderr,str),'Policy capture must return text')
        (logs/(name+'.stdout.txt')).write_text(stdout);(logs/(name+'.stderr.txt')).write_text(stderr)
        dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt')),
              'stderr_sha256':digest(logs/(name+'.stderr.txt'))})
        return done
    def recorded_output(argv,**kwargs):
        done=recorded_run(argv,stdout=real.PIPE,**kwargs)
        if done.returncode:raise real.CalledProcessError(done.returncode,argv,output=done.stdout,stderr=done.stderr)
        return done.stdout
    compiler.subprocess=types.SimpleNamespace(run=recorded_run,check_output=recorded_output,PIPE=real.PIPE,
                                              STDOUT=real.STDOUT,CalledProcessError=real.CalledProcessError)
    try:return compiler.capture_effective_flags(directory,env=environment())
    finally:compiler.subprocess=real


def symbols(text):
    found={}
    for line in text.splitlines():
        words=line.split()
        if len(words)>=3 and '__mtirust_MOD_' in words[-1]:found[words[-1]]=found.get(words[-1],0)+1
    return found


def cleanup_owned(owned,end):
    budget=min(55.,max(0.,end-time.monotonic()))
    result=owned.stop(cooperative_seconds=budget*45/55,terminate_seconds=budget*5/55,kill_seconds=budget*5/55)
    require(not result['survivors'],'Owned descendant cleanup unresolved')
    return result


def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard resource limit too small')
        resource.setrlimit(kind,(value,value))


def require_admission(stage):
    admitted=read(REPORT/stage/'admission.json')
    require(admitted['stage']==stage and admitted['source_index_sha256']==EXPECTED_SOURCE
            and admitted['reviewed']==REVIEWED and admitted['cap_seconds']==CAPS[stage]
            and admitted['resource_limits']==LIMITS and admitted['parent_pid']==os.getppid(),
            'Missing/mismatched separate supervisor admission')
    actual={name:list(resource.getrlimit(kind)) for kind,name in
            ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}
    require(actual=={name:[value,value] for name,value in LIMITS.items()},'Actual child resource limits differ')
    require(os.sched_getaffinity(0)=={CPU},'Actual child affinity is not nonexclusive CPU12')
    dump(REPORT/stage/'actual-limits.json',{'actual':actual,'pid':os.getpid(),'session':os.getsid(0)})


def stage(name):
    cleanup=load('mgmass_cleanup',ROOT/CLEANUP_HELPER);deadline_support=load('mgmass_deadline',ROOT/DEADLINE_HELPER)
    deadline_support.STAGE_SECONDS=CAPS[name];deadline_support.CLEANUP_RESERVE=CLEANUP
    directory=REPORT/name;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':name,'source_index_sha256':EXPECTED_SOURCE,'cap_seconds':CAPS[name],
           'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running'}
    owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,deadline_support.StageDeadline() as deadline:
            entry['deadline_monotonic']=deadline.end;requests.check();verify_source();protected()
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(Path(__file__).relative_to(ROOT)),
                  '--child',name,'--source',EXPECTED_SOURCE]
            for key,value in REVIEWED.items():
                if value:argv+=['--reviewed-'+key,value]
            dump(directory/'admission.json',{**entry,'command':argv,'parent_pid':os.getpid(),'reviewed':REVIEWED})
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                    owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Admitted stage failed; no automatic retry')
            protected();verify_source();requests.check()
            entry.update(status='passed',result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
    except BaseException as error:
        if owned is not None and not cleaned:
            try:entry['cleanup']=cleanup_owned(owned,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error),publication_scope='Failure retained; no numerical/timing pass')
        dump(directory/'terminal.json',entry)
        raise


def pin(case='n3'):return read(HERE/'input-pins.json')['cases'][case]
def proc(output,case='n3'):return Path(output)/'SubProcesses'/pin(case)['subprocess']
def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']


def environment():
    compiler=modules()[1];row=pin()
    require(row['compiler_flags']['environment']=={},'Original compiler injection differs')
    paths=[Path(p).parent for p in row['runtime']['libraries'] if Path(p).name=='libmadloop_tirust.so']
    require(len(paths)==1,'Ambiguous current TIRust runtime')
    libraries=[ROOT/'HEPTools/ninja/lib',ROOT/'HEPTools/collier',ROOT/'HEPTools/ninjars/lib',paths[0]]
    return local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),compiler.COMPILER_ENVIRONMENT,{},libraries)


def verify_source():
    require(Path.cwd()==ROOT,'Run only from the MadGraph working repository')
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source seal required')
    seal=read(HERE/'source-index.json')
    require({str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'},'Sealed source exact inventory changed')
    for name,wanted in seal['files'].items():
        path=HERE/name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and not path.is_symlink(),'Unsafe source path')
        require(digest(path)==wanted['sha256'] and path.stat().st_size==wanted['bytes'],'Sealed source bytes changed:'+name)
    for name,wanted in seal['support'].items():require(digest(ROOT/name)==wanted,'Pinned supporting source changed:'+name)
    units=read(HERE/'units/source-index.json')
    require(digest(HERE/'units/source-index.json')=='63abf3e5e9cb4851172e846ff39d723f600dc842a0145254a686f15682272168','Recording unit seal changed')
    require({str(p.relative_to(HERE/'units')) for p in (HERE/'units').rglob('*') if p.is_file()}==set(units['files'])|{'source-index.json'},'Recording unit inventory changed')


def protected():
    data=read(HERE/'input-pins.json');bench=modules()[0];row=pin();output=Path(row['output'])
    for name,wanted in data['files'].items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        require(path.is_file() and digest(path)==wanted['sha256'] and path.stat().st_size==wanted['bytes'],'Protected input changed:'+name)
    for name,wanted in data['ancestry'].items():require(digest(ROOT/name)==wanted,'Closed source/environment ancestry changed:'+name)
    require(bench.generated_sources(output)==row['generated_sources'],'Actual complete CLI source family changed')
    require(bench.numerical_objects(output)==row['numerical_objects'],'Original physics objects/modules/archives changed')
    require(bench.numerical_card_inputs(output)==row['numerical_cards'],'Original numerical cards changed')
    require(not (proc(output)/'worker-protocol.fifo').exists(),'Original worker is active')
    links={str(p.relative_to(output)):{'target':str(p.readlink()),'resolved':str(p.resolve())}
           for p in sorted(output.rglob('*')) if p.is_symlink()}
    require(links==row['links'],'Original source/resource aliases changed')
    require(digest(ROOT/read(HERE/'origin.json')['source_seal'])=='75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25','Reviewed source predecessor changed')
    for name,wanted in read(HERE/'toolchain-pins.json')['donor_lineage'].items():require(digest(ROOT/name)==wanted,'Successful pinned tool environment changed')
    admitted=local('tool_environment').validate(read(HERE/'toolchain-pins.json'),environment())
    require(read(HERE/'validation-plan.json')['UseQPIntegrandForTIRust'] is True,'Tested integrand-policy scope changed')
    return {'source_inputs':len(row['generated_sources']),'physics_object_bindings':len(row['numerical_objects']),
        'input_pins_sha256':digest(HERE/'input-pins.json'),'tool_admission':admitted,'compiler_invocations':0,'native_calls':0}


def preflight():
    verify_source();bound=protected()
    require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    return {'status':'source-only-preflight-passed','source_index_sha256':EXPECTED_SOURCE,'protected':bound,
        'caps_seconds':CAPS,'cleanup_reserve_seconds':CLEANUP,'limits':LIMITS,'cpu_reservation':False,
        'actual_original_runtime':expected_runtime('n3'),'native_calls':0,'compiler_invocations':0,
        'source_derivation':local('preparation').verify_materialized()}


def bind_runtime(prebound):
    expected=expected_runtime('n3')['files']
    for path,wanted in expected.items():
        require(path not in prebound['bound'] or prebound['bound'][path]==wanted,'Runtime/prelink conflict')
        require(digest(path)==wanted,'Prebound runtime changed before link')
        prebound['bound'][path]=wanted
    prebound['explicit_current_runtime_before_link']=expected
    return prebound


def unit_runtime(directory,prebound,logs,label):
    """Actual system/compiler subset, authenticated BEFORE its first listing."""
    loader=load('mgmass_unit_loader',ROOT/LOADER)
    executable=directory/'unit_mass_check';checksum=digest(executable)
    interpreter=loader._support('run.py',{'interpreter'}).interpreter(executable)
    expected=expected_runtime('n3')['files']
    require(str(interpreter)==expected_runtime('n3')['actual_interpreter'] and
            prebound['bound'].get(str(interpreter))==expected[str(interpreter)],'Unit interpreter not prebound')
    listing=command([str(interpreter),'--list',str(executable)],directory,logs,label+'-actual-runtime')
    require('not found' not in listing,'Unresolved recording-unit provider')
    files={str(interpreter):digest(interpreter)}
    for raw in listing.splitlines():
        line=raw.strip()
        if not line or re.fullmatch(r'linux-vdso\.so\.1\s+\(0x[0-9a-fA-F]+\)',line):continue
        match=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line)
        require(match is not None,'Unknown unit runtime line')
        path=str(Path(match[1]).resolve());wanted=digest(path)
        require(expected.get(path)==wanted and prebound['bound'].get(path)==wanted,'Unit runtime escaped authenticated original provider set')
        require(not any(s in Path(path).name.lower() for s in ('tirust','ninja','collier')),'Recording unit must not load reducer DSOs')
        files[path]=wanted
    require(len(files)>1 and digest(executable)==checksum,'Empty runtime or changed recording unit')
    return {'loader':str(interpreter),'listing':listing,'files':files,'closure_role':'Exact observed authenticated system/compiler subset; no forced physical15-provider equality'}


def unchanged_objects(output,observed=False):
    prefix='SubProcesses/'+pin()['subprocess']+'/'
    replaced={prefix+Path(name).with_suffix('.o').name for name in local('policy').NEEDED}
    expected={name:wanted for name,wanted in pin()['numerical_objects'].items() if name not in replaced}
    actual=modules()[0].numerical_objects(output)
    require(all(actual.get(name)==wanted for name,wanted in expected.items()),'Unselected physics object changed')
    extras={prefix+'mgmass_observer.o',prefix+'mgmass_observer_state.mod'} if observed else set()
    require(set(actual)==set(pin()['numerical_objects'])|extras,'Unexpected private object/module set')
    return {'unchanged':len(expected),'replaced':sorted(replaced),'observer_only':sorted(extras)}


def build():
    bench,compiler,*_=modules();policy=local('policy');loader=load('mgmass_build_loader',ROOT/LOADER)
    before=protected();results={}
    for variant in VARIANTS:
        observed=variant.endswith('-observed');output=WORK/'build'/variant;clone(pin()['output'],output)
        directory=proc(output);logs=REPORT/'build'/variant/'commands'
        for name in ('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','check_sa.f'):
            (directory/name).write_bytes((HERE/'source-preview'/variant/name).read_bytes())
        (directory/'makefile').write_text(policy.private_makefile((directory/'makefile').read_text(),observed))
        actual=capture_policy(directory,logs,'policy-before');policy.verify_policy(pin()['compiler_flags'],actual,compiler)
        if observed:
            command([tool('gfortran'),'-w','-fPIC','-ffixed-line-length-132','-J',str(directory),'-c',
                     str(HERE/'observer.f90'),'-o','mgmass_observer.o'],directory,logs,'observer-compile')
        expanded=command([tool('make'),'--no-print-directory','--dry-run','--always-make','SHELL='+tool('bash'),'check'],
                         directory,logs,'expanded-check')
        recipes,link=policy.select_commands(expanded,tool('gfortran'),environment(),observed)
        for index,(name,argv) in enumerate(recipes):command(argv,directory,logs,f'{index:02d}-compile-'+name)
        pre=bind_runtime(loader.prelink(link,directory,environment(),lambda a,n:command(a,directory,logs,n)))
        dump(REPORT/'build'/variant/'prelink.json',pre)
        command(link,directory,logs,'link')
        loads=loader.requireactualmap((directory/'private-link.map').read_text(),directory,pre,directory/'check')
        runtime=loader.query_runtime(directory/'check',expected_runtime('n3')['files'],pre,lambda a,n:command(a,directory,logs,n))
        after=capture_policy(directory,logs,'policy-after');evidence=policy.verify_policy(pin()['compiler_flags'],after,compiler)
        require(bench.same_compiler_policy(actual,after),'Compilation policies changed during build')
        nm=command([tool('nm'),'--defined-only','check'],directory,logs,'symbols')
        wanted={name:1 for name in read(HERE/'input-pins.json')['expected_mtirust_symbols']}
        require(symbols(nm)==wanted,'Installed MTIRUST definitions differ/duplicate')
        # Bind exactly the actual private definitions; no NinjaRS ABI change.
        expected_private={name.lower()+'_qpmass_' for name in read(HERE/'source-proof.json')['helpers']}|{
            'ml5_0_mp_tirust_tensor_diagnostic_qpmass_','ml5_0_mp_tirust_loop_qpmass_'}
        actual_private={line.split()[-1] for line in nm.splitlines() if line.split() and '_qpmass_' in line.split()[-1]}
        require(actual_private==(expected_private if variant.startswith('candidate') else set()),'Private QP-mass symbol ownership differs')
        objects=unchanged_objects(output,observed)
        require(not (directory/'mtirust.o').exists() and 'libtirust.a(' in (directory/'private-link.map').read_text(),'Fortran wrapper must remain the original installed archive')
        results[variant]={'variant':variant,'output':str(output),'sources':bench.generated_sources(output),
            'objects':bench.numerical_objects(output),'unchanged_objects':objects,'compiler_flags':after,
            'policy_evidence':evidence,'executable_sha256':digest(directory/'check'),
            'link_map_sha256':digest(directory/'private-link.map'),'prelink_sha256':digest(REPORT/'build'/variant/'prelink.json'),
            'runtime':runtime,'actual_link_loads':loads,'selected_recipes':recipes,'link_command':link,
            'MTIRUST_definitions':wanted,'private_definitions':sorted(actual_private)}
    units_dir=WORK/'build'/'units';units_dir.mkdir(parents=True,exist_ok=False);logs=REPORT/'build'/'units'/'commands'
    spec=read(HERE/'units/build-spec.json')
    def expand(argv):return [value.replace('{work}',str(units_dir)).replace('{units}',str(HERE/'units')) for value in argv]
    for row in spec['compile_commands']:command(expand(row['argv']),units_dir,logs,row['label'])
    link=expand(spec['link_command']);link.insert(1,'-Wl,-Map,unit-link.map,--cref')
    pre=bind_runtime(loader.prelink(link,units_dir,environment(),lambda a,n:command(a,units_dir,logs,n)))
    dump(REPORT/'build'/'units'/'prelink.json',pre);command(link,units_dir,logs,'unit-link')
    loads=loader.requireactualmap((units_dir/'unit-link.map').read_text(),units_dir,pre,units_dir/'unit_mass_check')
    runtime=unit_runtime(units_dir,pre,logs,'unit')
    unit={'output':str(units_dir),'executable_sha256':digest(units_dir/'unit_mass_check'),
        'link_map_sha256':digest(units_dir/'unit-link.map'),'prelink_sha256':digest(REPORT/'build'/'units'/'prelink.json'),
        'runtime':runtime,'actual_link_loads':loads,
        'objects':{p.name:digest(p) for p in units_dir.iterdir() if p.suffix in ('.o','.mod')}}
    require(protected()==before,'Protected originals changed during build')
    dump(REPORT/'build'/'result.json',{'status':'passed','stage':'build','source_index_sha256':EXPECTED_SOURCE,
        'variants':results,'units':unit,'protected':before,'native_amplitude_calls':0,'unit_executions':0,
        'compiler_policy_change':False,'private_MTIrust_rebuild':False})


def receipt(stage):
    require(REVIEWED.get(stage) and digest(REPORT/stage/'terminal.json')==REVIEWED[stage],'Separate exact reviewed '+stage+' terminal required')
    terminal=read(REPORT/stage/'terminal.json');result=read(REPORT/stage/'result.json')
    require(terminal['stage']==stage and terminal['source_index_sha256']==EXPECTED_SOURCE and
        terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],
        'Predecessor failed or did not close:'+stage)
    require(terminal['result_sha256']==digest(REPORT/stage/'result.json') and result['status']=='passed' and
        result['stage']==stage and result['source_index_sha256']==EXPECTED_SOURCE,'Predecessor result binding changed')
    for name,wanted in result.get('raw_files',{}).items():require(digest(REPORT/stage/name)==wanted,'Retained raw evidence changed:'+name)
    return result


def verified_build():
    built=receipt('build');bench=modules()[0]
    require(set(built['variants'])==set(VARIANTS),'Wrong build variant set')
    for variant,row in built['variants'].items():
        output=Path(row['output']);directory=proc(output)
        require(bench.generated_sources(output)==row['sources'] and bench.numerical_objects(output)==row['objects'] and
            digest(directory/'check')==row['executable_sha256'],'Reviewed build sources/objects/ELF changed')
        require(digest(directory/'private-link.map')==row['link_map_sha256'] and
            digest(REPORT/'build'/variant/'prelink.json')==row['prelink_sha256'],'Reviewed link proof changed')
        for name,wanted in {**row['actual_link_loads'],**row['runtime']['files']}.items():require(digest(name)==wanted,'Reviewed provider changed')
    row=built['units'];directory=Path(row['output'])
    require(digest(directory/'unit_mass_check')==row['executable_sha256'] and
        digest(directory/'unit-link.map')==row['link_map_sha256'] and
        digest(REPORT/'build/units/prelink.json')==row['prelink_sha256'],'Recording unit executable/link proof changed')
    for name,wanted in row['objects'].items():require(digest(directory/name)==wanted,'Recording unit object changed')
    for name,wanted in {**row['actual_link_loads'],**row['runtime']['files']}.items():require(digest(name)==wanted,'Recording unit provider changed')
    return built


def verify_predecessors(stage):
    result={}
    if stage!='build':result['build']=verified_build()
    for previous in PREREQUISITES[stage]:
        if previous!='build':
            value=receipt(previous);result[previous]=value
            require(set(value['reviewed'])==set(PREREQUISITES[previous]) and
                all(value['reviewed'].values()),'Predecessor ancestor set differs')
            require(value['reviewed']['build']==REVIEWED['build'],'Predecessor uses another BUILD')
            for name,wanted in value['reviewed'].items():require(REVIEWED.get(name)==wanted,'Predecessor review chain changed')
    return result


def result_base(stage):
    return {'status':'passed','stage':stage,'source_index_sha256':EXPECTED_SOURCE,
        'reviewed':{name:value for name,value in REVIEWED.items() if value},
        'candidate_promoted':False,'performance_acceptance':False,
        'independent_physical_finite_truth_qualified':False,'UseQPIntegrandFalse_and_dynamic_models_tested':False}


def run_units():
    built=verify_predecessors('units')['build'];source=Path(built['units']['output']);directory=WORK/'units'
    shutil.copytree(source,directory)
    require(digest(directory/'unit_mass_check')==built['units']['executable_sha256'],'Unit run copy changed')
    raw=command([str(directory/'unit_mass_check')],directory,REPORT/'units'/'commands','recording-units')
    parser=load('mgmass_recording_unit_parser',HERE/'units/parser.py');parsed=parser.parse(raw)
    dump(REPORT/'units'/'parsed.json',parsed)
    dump(REPORT/'units'/'result.json',{**result_base('units'),'parsed':parsed,
        'raw_files':inventory(REPORT/'units'),'actual_reducer_executions':0})


def inventory(directory):
    excluded={'result.json','terminal.json','console.log'}
    return {str(p.relative_to(directory)):digest(p) for p in sorted(directory.rglob('*'))
            if p.is_file() and not (p.parent==directory and p.name in excluded)}


def configure_cards(output,cache):
    require(cache in (0,-1),'Unsupported qualified cache setting')
    card=(HERE/'cards'/('cache0.dat' if cache==0 else 'cacheall.dat')).read_bytes()
    paths=list(pin()['numerical_cards'])+['SubProcesses/'+pin()['subprocess']+'/MadLoop5_resources/MadLoopParams.dat']
    for name in paths:
        path=Path(output)/name
        require(not path.is_symlink() and path.parent.resolve().is_relative_to(Path(output).resolve()),'Mutable card escapes private export')
        path.write_bytes(card)
    return private_cards(output,cache)


def private_cards(output,cache):
    bench=modules()[0];row=pin();directory=proc(output)
    checksum=digest(HERE/'cards'/('cache0.dat' if cache==0 else 'cacheall.dat'))
    aliases=list(row['numerical_cards'])+['SubProcesses/'+row['subprocess']+'/MadLoop5_resources/MadLoopParams.dat']
    expected={name:checksum for name in aliases}
    require(bench.numerical_card_inputs(output)==expected,'Private numerical cards changed')
    physical=bench.resolved_parameter_card(directory)
    require(physical is not None and digest(physical)==row['param_card_sha256']==digest(Path(output)/'Cards/param_card.dat'),'Physical card changed')
    require(all((Path(output)/name).resolve().is_relative_to(Path(output).resolve()) for name in aliases),'Mutable card/resource alias escapes export')
    return {'numerical_cards':expected,'physical_card_sha256':row['param_card_sha256'],'cache':cache}


def private_binding(output,row,cache):
    bench=modules()[0]
    require(bench.generated_sources(output)==row['sources'] and bench.numerical_objects(output)==row['objects'] and
        digest(proc(output)/'check')==row['executable_sha256'],'Private worker source/object/ELF changed')
    return private_cards(output,cache)


def maps(worker):
    raw=Path('/proc/'+str(worker.process.pid)+'/maps').read_text();files={}
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'Deleted runtime mapping')
            name=str(Path(fields[-1]).resolve());files[name]=digest(name)
    expected=expected_runtime('n3')['files'];exe=(worker.directory/'check').resolve()
    allowed={**expected,**read(HERE/'source-index.json')['allowed_extra_mappings'],str(exe):digest(exe)}
    require(all(files.get(name)==wanted for name,wanted in expected.items()) and files.get(str(exe))==digest(exe),'Required initialized mapping missing')
    require(all(allowed.get(name)==wanted for name,wanted in files.items()),'Unexpected initialized mapping')
    return {'pid':worker.process.pid,'maps':raw,'files':files}


def float_rows(values):
    return [{'point':r['point'],'order':r['order'],'status':r['status'],
        'words':[struct.pack('>d',v).hex().upper() for v in r['coefficients']+[r['accuracy']]]} for r in values]


def compare_rows(original,candidate):
    analysis=local('base_analysis');comparison=analysis.compare_variants(original,candidate,modules()[0].compare_rows)
    require(comparison['passed'],'Unchanged3e-6 and hard1e-8 scientific coefficient gate failed')
    changes=[]
    for left,right in zip(original,candidate,strict=True):
        if left['status']==219:
            require(left==right,'DP coefficient/status/accuracy words changed')
        elif left['words']!=right['words']:
            changes.append({'point':left['point'],'order':left['order'],'original_words':left['words'],'candidate_words':right['words']})
    return {**comparison,'DP_exact':True,'QP_changed_rows':changes,'QP_input_precision_change_not_independent_finite_truth':True}


def software(text):
    lines=[list(map(int,line.split())) for line in text.splitlines() if line.strip()]
    require(len(lines)==200 and [row[:2] for row in lines]==[[point,phase] for point in range(1,101) for phase in (1,2)],'Incomplete software-latch observations')
    require(all(len(row)==4 and all(x in (0,1) for x in row[2:]) for row in lines),'Invalid software-latch observation')
    return lines


def learning(worker,report,variant):
    parse_warmup=modules()[4];row=pin()
    ready={name:getattr(worker,name) for name in ('points','ndim','nso','nborn','cold_seconds')}
    require([ready[name] for name in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong complete physical dimensions')
    warmup=parse_warmup(worker.directory,9,100,ready)
    current_text=(worker.directory/'warmup.dat').read_text();historical=Path(row['closed_warmup']).read_text()
    def history(text):
        result=[]
        for line in text.splitlines():
            if not line.strip() or line.lstrip().startswith('#'):continue
            fields=line.split();require(len(fields)==9,'Malformed learning record')
            result.append(list(map(int,fields[:4])))
        return result
    require(history(current_text)==history(historical),'Complete learning call/point/order/status history changed')
    expected=float_rows(read(row['closed_observation'])['rows']);actual=float_rows(warmup['rows'])
    comparison=compare_rows(expected,actual)
    dump(report/'ready.json',ready);dump(report/'warmup.json',warmup)
    dump(report/'learning-comparison.json',{'history_exact':True,'bootstrap_raw_retained':True,'comparison':comparison,
        'scope':'Exact call sequence and DP steady words; full100 QP values use predeclared scientific gate; bootstrap numerical fields diagnostic.'})
    shutil.copyfile(worker.directory/'warmup.dat',report/'warmup.dat')
    shutil.copyfile(worker.directory/'dimensions.dat',report/'dimensions.dat')
    return {'ready':ready,'rows':actual,'history':history(current_text),'comparison':comparison}


def exact_command(worker,report):
    report.mkdir(parents=True,exist_ok=False);worker.sequence+=1
    require(worker.sequence==1,'Only one final full100 traversal is admitted')
    dump(report/'command.json',{'command':['EXACT',1,0]})
    worker._send('EXACT 1 0');reply=worker._message()
    require(reply==['EXACTED','1'],'Full100 exact worker failed')
    for name in ('exact-words.dat','exact-ieee.dat','software-flags.dat'):
        shutil.copyfile(worker.directory/name,report/name)
    analysis=local('base_analysis');codes=pin()['expected_codes']
    rows=analysis.exact((report/'exact-words.dat').read_text(),codes)
    flags=analysis.ieee((report/'exact-ieee.dat').read_text())
    require(sum(r['status']==219 for r in rows)==174 and sum(r['status']==323 for r in rows)==26,'Required87DP/13autoQP cohort changed')
    return {'rows':rows,'ieee':flags,'software':software((report/'software-flags.dat').read_text()),
            'scope':'Public full100 words/status,read-only host IEEE/software flags; not a trap-freedom result'}


def physical(stage,cache,observed=None):
    predecessors=verify_predecessors(stage);built=predecessors['build'];before=protected();lanes={};learnings={}
    variants=VARIANTS[:2] if observed is None else (observed+'-observed',)
    loader=load('mgmass_runtime_loader',ROOT/LOADER)
    for variant in variants:
        row=built['variants'][variant];report=REPORT/stage/variant;output=WORK/stage/variant
        clone(row['output'],output);directory=proc(output);configure_cards(output,cache)
        binding=private_binding(output,row,cache)
        pre=read(REPORT/'build'/variant/'prelink.json')
        runtime=loader.query_runtime(directory/'check',expected_runtime('n3')['files'],pre,
            lambda a,n:command(a,directory,report/'commands','before-'+n))
        Worker=modules()[2]
        with ExitStack() as stack:
            worker=stack.enter_context(Worker([tool('taskset'),'-c',str(CPU),str(directory/'check'),pin()['points']],
                directory,report/'worker.log',env=environment(),timeout=240.))
            require(os.sched_getaffinity(worker.process.pid)=={CPU},'Worker affinity changed')
            learnings[variant]=learning(worker,report,variant)
            dump(report/'maps-before.json',maps(worker))
            lanes[variant]=exact_command(worker,report/'exact')
            dump(report/'maps-after.json',maps(worker))
            if observed is not None:
                shutil.copyfile(directory/'mass-observer.hex',report/'mass-observer.hex')
                parsed=local('observer_analysis').parse((report/'mass-observer.hex').read_text(),int(observed=='candidate'))
                mass=local('observer_analysis').validate_mass_words(parsed,read(HERE/'source-proof.json'))
                dump(report/'observed-mass-summary.json',mass)
                own=predecessors['cache0']['lanes'][observed]
                require(lanes[variant]==own,'Observer changed its own uninstrumented exact coefficient/accuracy/status/IEEE/software words')
                if observed=='candidate':
                    original_path=REPORT/'observeoriginal'/'original-observed'/'mass-observer.hex'
                    original=local('observer_analysis').parse(original_path.read_text(),0)
                    joined=local('observer_analysis').compare(original,parsed,read(HERE/'source-proof.json'))
                    dump(REPORT/stage/'native-input-comparison.json',joined)
            require(private_binding(output,row,cache)==binding,'Worker mutated physical/numerical inputs')
        require(not (directory/'worker-protocol.fifo').exists(),'Worker FIFO survived cleanup')
        after=loader.query_runtime(directory/'check',expected_runtime('n3')['files'],pre,
            lambda a,n:command(a,directory,report/'commands','after-'+n))
        require(all(runtime[name]==after[name] for name in ('loader','loader_sha256','files')),'Runtime changed during worker')
    comparison=None
    if observed is None:
        require(learnings['original']['history']==learnings['candidate']['history'],'Cross-worker learning histories differ')
        learning_comparison=compare_rows(learnings['original']['rows'],learnings['candidate']['rows'])
        comparison=compare_rows(lanes['original']['rows'],lanes['candidate']['rows'])
        require(lanes['original']['ieee']==lanes['candidate']['ieee'] and lanes['original']['software']==lanes['candidate']['software'],
                'Candidate changed observed hardware/software exception states')
        if cache==-1:
            for variant in VARIANTS[:2]:require(lanes[variant]==predecessors['cache0']['lanes'][variant],
                'Cache0/cache−1 changed own exact coefficients/accuracy/status/IEEE/software words')
    require(protected()==before,'Protected originals changed during physical qualification')
    dump(REPORT/stage/'result.json',{**result_base(stage),'cache':cache,'lanes':lanes,'learning':learnings,
        'comparison':comparison,'full100_learning_per_worker':True,'points_per_worker':100,'DP_points':87,'QP_points':13,
        'raw_files':inventory(REPORT/stage),'UseQPIntegrandForTIRust':True,
        'model_scope':'Tested True integrand policy and static real SM MB/MT; False/dynamic-model extension untested'})


def main():
    global EXPECTED_SOURCE,REVIEWED
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--stage',choices=tuple(CAPS));mode.add_argument('--child',choices=tuple(CAPS))
    parser.add_argument('--execute',action='store_true');parser.add_argument('--source',required=True)
    for name in REVIEWED:parser.add_argument('--reviewed-'+name)
    args=parser.parse_args();EXPECTED_SOURCE=args.source
    REVIEWED={name:getattr(args,'reviewed_'+name) for name in REVIEWED}
    for value in (EXPECTED_SOURCE,*REVIEWED.values()):
        if value is not None and not re.fullmatch('[0-9a-f]{64}',value):parser.error('Exact SHA256 required')
    selected=args.stage or args.child
    if selected:
        require({name for name,value in REVIEWED.items() if value}==set(PREREQUISITES[selected]),'Exact separately reviewed predecessor set required')
    if args.child:
        limits();require_admission(args.child);verify_source();protected();verify_predecessors(args.child)
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX)
            actions={'build':build,'units':run_units,'cache0':lambda:physical('cache0',0),
                'cacheall':lambda:physical('cacheall',-1),
                'observeoriginal':lambda:physical('observeoriginal',0,'original'),
                'observecandidate':lambda:physical('observecandidate',0,'candidate')}
            actions[args.child]()
        return
    result=preflight()
    if not args.stage:
        require(not args.execute,'--execute needs a separately selected stage');print(json.dumps(result,indent=2));return
    require(args.execute,'Native stages dormant until explicit separately reviewed --execute')
    verify_predecessors(args.stage);stage(args.stage)


if __name__=='__main__':main()


