"""Guarded pure source/parser/controller tests; no compiler, loader or worker."""
from contextlib import ExitStack,redirect_stdout
from fractions import Fraction
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def load(name):
    spec=importlib.util.spec_from_file_location('mgmass_test_'+name,HERE/(name+'.py'))
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
C=load('controller');M=load('materialize');O=load('observer_analysis');P=load('preparation');POL=load('policy')


def qp_words(value):
    value=O.round_binary(value,113);sign=int(value<0);value=abs(value)
    if not value:bits=0
    else:
        exponent=value.numerator.bit_length()-value.denominator.bit_length()
        if value<Fraction(2)**exponent:exponent-=1
        significand=value/Fraction(2)**(exponent-112)
        if significand.denominator!=1:raise ValueError('Unrepresentable synthetic binary128')
        bits=(sign<<127)|((exponent+16383)<<112)|(int(significand)-(1<<112))
    return [f'{bits&((1<<64)-1):016X}',f'{bits>>64:016X}']
def cq(value):return qp_words(value)+qp_words(Fraction(0))
def dp_word(value):return struct.pack('>d',float(value)).hex().upper()
def cd(value):return [dp_word(value),dp_word(0)]


def journal(role):
    """Synthetic text ONLY, independently constructed three-mass/two-mode rows."""
    mb=Fraction(5291729562160333,1125899906842624);mt=Fraction(173);inputs=[mb,mt,Fraction(0)]
    old=[O.round_binary(x*x,53) for x in [inputs[-1],*inputs[:-1]]]
    new=[O.round_binary(x*x,113) for x in [inputs[-1],*inputs[:-1]]]
    def line(tag,indices,words):return ' '.join([tag,*map(str,indices),*words])
    lines=['MGMASS 1','ENDIAN 1 0 0 0 0 0 0 0'];seq=0
    for point in range(1,101):
        lines.append('POINT '+str(point))
        if point==16:
            for mode in (4,5):
                seq+=1;lines.append(f'GROUP {seq} {point} {role} {mode} 3 0 1')
                for i,x in enumerate(inputs,1):
                    lines.extend([line('FORMAL',[i],cq(x)),line('DPSQUARE',[i],cd(old[i-1])),
                        line('QPSQUARE',[i],cq((new if role else old)[i-1]))])
                lines.extend([f'COEFFICIENTS {seq} {point} {role} 3 0 1 1',line('COEF',[0],cq(Fraction(1))),
                    f'NATIVE {seq} {point} {role} {mode} 3 0',line('SCALE',[0,0],qp_words(Fraction(1)))])
                masses=new if role else old
                if mode==5:masses=[masses[0],*reversed(masses[1:])]
                for i,x in enumerate(masses,1):
                    lines.append(line('MASS',[i],cq(x)))
                    for j in range(4):lines.append(line('SHIFT',[j,i],qp_words(Fraction(0))))
                    for j in range(1,4):lines.append(line('INVARIANT',[j,i],qp_words(Fraction(0))))
                lines.append(f'STATUS {seq} {point} 0')
        lines.extend([f'MODELDP {point} {dp_word(mb)} {dp_word(mt)}',line('MODELMP',[point,1],qp_words(mb)),
            line('MODELMP',[point,2],qp_words(mt))])
    lines.append('END 100 2 2 2 2 100')
    proof={'groups':[{'group':1,'rank':0,'mass_pairs':[{'model_symbol':x} for x in ('MDL_MB','MDL_MT','ZERO')]}]}
    return '\n'.join(lines)+'\n',proof


class Qualification(unittest.TestCase):
    def test_01_complete_actual_cli_derivation(self):
        result=P.verify_materialized();self.assertEqual(result['actual_CLI_groups'],116)
        self.assertEqual(result['helper_families'],7);self.assertEqual(result['complete_source_bindings'],195)

    def test_02_original_call_spans_and_public_bodies(self):
        original=(HERE/'source-preview/original/loop_CT_calls_1.f').read_text()
        candidate=(HERE/'source-preview/candidate/loop_CT_calls_1.f').read_text();lines=original.splitlines(keepends=True)
        calls=0
        for a,b,s in M.logical_blocks(original):
            if s and s.startswith('CALL ML5_0_LOOP_'):
                self.assertIn('      IF(CTMODE.LT.4) THEN\n'+''.join(lines[a:b])+'      ELSE\n',candidate);calls+=1
        self.assertEqual(calls,116)
        for name in ('CT_interface.f','TIRUST_interface.f'):
            before=M.routines((HERE/'source-preview/original'/name).read_text())
            after=M.routines((HERE/'source-preview/candidate'/name).read_text())
            for symbol,row in before.items():self.assertEqual(after[symbol],row)

    def test_03_missing_model_or_arity_fail_closed(self):
        with self.assertRaises(ValueError):M.mass_actual('DCMPLX(MDL_MB+1)',{'MP__MDL_MB':'REAL*16'},'MP__')
        with self.assertRaises(ValueError):M.mass_actual('DCMPLX(MDL_MB)',{},'MP__')
        source=(HERE/'source-preview/original/loop_CT_calls_1.f').read_text()
        changed=source.replace('DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,1)','DCMPLX(ZERO),1,I_SO,1)',1)
        row=C.pin();base=Path(row['output']);p=base/'SubProcesses'/row['subprocess']
        with self.assertRaises(ValueError):M.candidate((p/'CT_interface.f').read_text(),(p/'TIRUST_interface.f').read_text(),changed,
            (base/'Source/MODEL/mp_coupl.inc').read_text())

    def test_04_genuine_recording_units_seal_and_scope(self):
        p=HERE/'units/source-index.json';self.assertEqual(C.digest(p),'63abf3e5e9cb4851172e846ff39d723f600dc842a0145254a686f15682272168')
        data=C.read(p)
        for n,w in data['files'].items():self.assertEqual(C.digest(HERE/'units'/n),w['sha256'])
        spec=C.read(HERE/'units/build-spec.json');self.assertEqual(len(spec['compile_commands']),4)
        self.assertNotIn('-ltirust',spec['link_command']);self.assertTrue(spec['only_recording_stubs_linked'])

    def test_05_original_flags_and_selected_recipe_closure(self):
        env=C.environment();fc=C.tool('gfortran')
        text='\n'.join(' '.join([fc,'-w','-fPIC','-ffixed-line-length-132','-c',n,'-o',Path(n).with_suffix('.o').name]) for n in POL.NEEDED)
        text+='\n'+' '.join([fc,'-o','check','check_sa.o','-ltirust'])
        recipes,_=POL.select_commands(text,fc,env);self.assertEqual([n for n,_ in recipes],list(POL.NEEDED))
        with self.assertRaises(ValueError):POL.select_commands(text.replace('CT_interface.f','evil.f'),fc,env)
        before=C.pin()['compiler_flags'];after=copy.deepcopy(before)
        POL.verify_policy(before,after,C.modules()[1])
        after['scopes']['process']['recipes']['TIRUST_interface.f']['flags'].append('-O3')
        with self.assertRaises(ValueError):POL.verify_policy(before,after,C.modules()[1])

    def test_06_pinned_environment_and_all_protected_inputs_are_pure(self):
        result=C.protected();self.assertEqual(result['source_inputs'],195);self.assertEqual(result['physics_object_bindings'],144)
        runtime=C.expected_runtime('n3');self.assertEqual(len(runtime['files']),15)

    def test_07_all_separate_predecessor_chains_accept_only_ancestors(self):
        receipts={};original=copy.deepcopy(C.REVIEWED)
        try:
            for index,stage in enumerate(C.CAPS,1):
                C.REVIEWED={n:(str(list(C.REVIEWED).index(n)+1)*64 if n in C.PREREQUISITES[stage] else None) for n in C.REVIEWED}
                with mock.patch.object(C,'verified_build',return_value={'build':'pure-fixture'}),mock.patch.object(C,'receipt',side_effect=lambda name:receipts[name]):
                    C.verify_predecessors(stage)
                receipts[stage]=C.result_base(stage)
                self.assertEqual(set(receipts[stage]['reviewed']),set(C.PREREQUISITES[stage]))
            bad=copy.deepcopy(receipts['units']);bad['reviewed']['units']=None
            C.REVIEWED={n:('1'*64 if n in ('build','units') else None) for n in C.REVIEWED}
            with mock.patch.object(C,'verified_build',return_value={}),mock.patch.object(C,'receipt',return_value=bad),self.assertRaises(ValueError):
                C.verify_predecessors('cache0')
        finally:C.REVIEWED=original

    def test_08_default_and_missing_admission_do_not_execute(self):
        with mock.patch.object(sys,'argv',['controller','--source','a'*64]),mock.patch.object(C,'preflight',return_value={'pure':True}),mock.patch.object(C,'stage') as stage,redirect_stdout(io.StringIO()):
            C.main();stage.assert_not_called()
        with mock.patch.object(sys,'argv',['controller','--source','a'*64,'--stage','build']),mock.patch.object(C,'preflight',return_value={}),self.assertRaises(ValueError):C.main()
        with mock.patch.object(sys,'argv',['controller','--source','a'*64,'--stage','cache0','--execute']),self.assertRaises(ValueError):C.main()

    def test_09_integer_decode_and_original_mb_square(self):
        for x in (Fraction(0),Fraction(1),Fraction(-3,8),Fraction(1,1<<120)):
            self.assertEqual(O.qp(qp_words(x)),x)
        mb=Fraction(5291729562160333,1125899906842624);self.assertEqual((mb*mb).numerator.bit_length(),105)
        self.assertEqual(O.round_binary(mb*mb,113),mb*mb)
        self.assertNotEqual(O.round_binary(mb*mb,53),mb*mb)

    def test_10_complete_synthetic_observer_join(self):
        left,proof=journal(0);right,_=journal(1)
        result=O.compare(O.parse(left,0),O.parse(right,1),proof)
        self.assertTrue(result['passed']);self.assertEqual(result['candidate']['native_bottom_square_witnesses_by_point'],{'16':2})
        self.assertFalse(result['independent_physical_finite_truth_qualified'])

    def test_11_observer_rejects_missing_footer_and_bad_endianness(self):
        text,_=journal(0)
        with self.assertRaises(ValueError):O.parse(text.replace('END 100 2 2 2 2 100',''),0)
        with self.assertRaises(ValueError):O.parse(text.replace('ENDIAN 1 0 0 0 0 0 0 0','ENDIAN 0 0 0 0 0 0 0 1'),0)

    def test_12_observer_nonmass_and_native_square_corruption_fail(self):
        left,proof=journal(0);right,_=journal(1)
        old='SHIFT 0 1 '+' '.join(qp_words(Fraction(0)))
        corrupt=right.replace(old,'SHIFT 0 1 '+' '.join(qp_words(Fraction(1))),1)
        with self.assertRaises(ValueError):O.compare(O.parse(left,0),O.parse(corrupt,1),proof)
        parsed=O.parse(right,1);parsed['groups'][0]['native']['masses'][1]=cq(Fraction(1))
        with self.assertRaises(ValueError):O.validate_mass_words(parsed,proof)

    def test_13_missing_anchor_native_witness_fails(self):
        right,proof=journal(1);parsed=O.parse(right,1)
        for g in parsed['groups']:g['status']=2
        with self.assertRaises(ValueError):O.validate_mass_words(parsed,proof)

    def test_14_exact_DP_stricter_than_scientific_threshold(self):
        rows=C.float_rows(C.read(C.pin()['closed_observation'])['rows']);changed=copy.deepcopy(rows)
        word=changed[0]['words'][0];bits=int(word,16);changed[0]['words'][0]=f'{bits+1:016X}'
        with self.assertRaises(ValueError):C.compare_rows(rows,changed)
        self.assertTrue(C.compare_rows(rows,rows)['DP_exact'])

    def test_15_software_latches_need_all100_points(self):
        text='\n'.join(f'{p} {phase} 0 0' for p in range(1,101) for phase in (1,2))
        self.assertEqual(len(C.software(text)),200)
        with self.assertRaises(ValueError):C.software(text.split('\n',1)[1])


def main():
    forbidden=[]
    def blocked(*args,**kwargs):forbidden.append(str(args[:1]));raise RuntimeError('Native/process boundary blocked in source tests')
    log=io.StringIO()
    with ExitStack() as stack:
        for module,name in [(subprocess,'Popen'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve')]:
            if hasattr(module,name):stack.enter_context(mock.patch.object(module,name,side_effect=blocked))
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Qualification))
    print(log.getvalue(),end='')
    receipt={'schema':'current-qp-mass-dormant-qualification-pure-tests-v1','tests':result.testsRun,
        'errors':len(result.errors),'failures':len(result.failures),'passed':result.wasSuccessful(),
        'forbidden_API_attempts':forbidden,'compiler_calls':0,'loader_queries':0,'native_physical_or_unit_executions':0,
        'synthetic_observer_text_is_not_native_evidence':True}
    mode='normal' if __debug__ else 'optimized'
    with (HERE/('tests-'+mode+'.log')).open('x') as stream:stream.write(log.getvalue())
    with (HERE/('tests-'+mode+'.json')).open('x') as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    if forbidden or not result.wasSuccessful():raise SystemExit(1)


if __name__=='__main__':main()
