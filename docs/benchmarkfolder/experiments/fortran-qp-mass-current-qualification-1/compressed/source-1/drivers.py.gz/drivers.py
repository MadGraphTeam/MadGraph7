"""Identical untimed physical workers, plus separately qualified input observer."""


def require(value,message):
    if not value:raise ValueError(message)


def once(text,old,new):
    require(text.count(old)==1,'Expected one exact worker site: '+repr(old))
    return text.replace(old,new,1)


def worker(base_source,base,observed=False):
    # Existing full100 learning, point setup, scale and model-update arithmetic
    # stay in the original driver. Only the untimed EXACT command is used.
    source=base.worker(base_source)
    declarations=('      LOGICAL MASS_FPE_DP,MASS_FPE_QP\n'
                  '      COMMON/ML5_0_FPE_IN_REDUCTION/MASS_FPE_DP,\n'
                  '     $ MASS_FPE_QP\n')
    source=once(source,base.DECLARATIONS,base.DECLARATIONS+declarations)
    exact=base.EXACT
    exact=once(exact,"         OPEN(77,FILE='exact-ieee.dat',STATUS='NEW')\n",
        "         OPEN(77,FILE='exact-ieee.dat',STATUS='NEW')\n"
        "         OPEN(78,FILE='software-flags.dat',STATUS='NEW')\n"+
        ('         CALL MGMASS_OPEN()\n' if observed else ''))
    exact=once(exact,'            P=POINTS(:,:,K)\n',
        ('            CALL MGMASS_POINT(K)\n' if observed else '')+'            P=POINTS(:,:,K)\n')
    before=('            WRITE(78,\'(2I8,2I4)\') K,1,\n'
            '     $           MERGE(1,0,MASS_FPE_DP),MERGE(1,0,MASS_FPE_QP)\n')
    after=('            WRITE(78,\'(2I8,2I4)\') K,2,\n'
           '     $           MERGE(1,0,MASS_FPE_DP),MERGE(1,0,MASS_FPE_QP)\n')
    call='            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)\n'
    exact=once(exact,call,before+call+
        ('            CALL MGMASS_MODEL(MDL_MB,MDL_MT,MP__MDL_MB,\n'
         '     $           MP__MDL_MT)\n' if observed else '')+after)
    exact=once(exact,'         CLOSE(77)\n','         CLOSE(77)\n         CLOSE(78)\n'+
        ('         CALL MGMASS_CLOSE()\n' if observed else ''))
    source=once(source,base.EXACT,exact)
    if observed:
        source=once(source,"      INCLUDE 'coupl.inc'\n",
            "      INCLUDE 'coupl.inc'\n      INCLUDE 'mp_coupl.inc'\n")
    return source
