#!/usr/bin/env python3
"""Pure parser/oracle/source tests. Never compiles or runs the Fortran fixture."""
from fractions import Fraction
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qp_mass_unit_parser',HERE/'parser.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


class UnitParser(unittest.TestCase):
    def test_01_positive_two_complete_calls(self):
        result=p.parse(p.synthetic_stdout())
        self.assertTrue(result['verified']);self.assertEqual(result['recorded_helper_calls'],2)
        self.assertFalse(result['physical_model_or_amplitude_truth_qualified'])

    def test_02_binary_words_known_values(self):
        self.assertEqual(p.real_words(1,113),['0000000000000000','3FFF000000000000'])
        self.assertEqual(p.real_words(-Fraction(1,8),113),['0000000000000000','BFFC000000000000'])
        self.assertEqual(p.real_words(1,53),['3FF0000000000000'])
        self.assertEqual(p.real_words(-2,53),['C000000000000000'])

    def test_03_real_and_complex_inputs_have_extra_bits(self):
        data=p.oracle()
        for index in [0,1]:self.assertNotEqual(data['masses'][index],data['DP_masses'][index])
        self.assertEqual(data['masses'][2],data['DP_masses'][2])
        self.assertEqual(data['bottom_square_significand_bits'],105)

    def test_04_reversed_or_narrowed_square_is_rejected(self):
        text=p.synthetic_stdout();data=p.oracle()
        old='MASS2 4 1 '+' '.join(data['MASS2'][0])
        for wrong in [data['MASS2'][1],p.complex_words(tuple(p.rounded(x,53) for x in data['ordered_squares'][0]),113)]:
            with self.assertRaises(ValueError):p.parse(text.replace(old,'MASS2 4 1 '+' '.join(wrong)))

    def test_05_narrowed_mass_argument_is_rejected(self):
        text=p.synthetic_stdout();data=p.oracle()
        old='QPARG 4 2 '+' '.join(data['QPARG'][1])
        wrong=p.complex_words(data['DP_masses'][1],113)
        with self.assertRaises(ValueError):p.parse(text.replace(old,'QPARG 4 2 '+' '.join(wrong)))

    def test_06_incomplete_duplicate_and_bad_footer_fail(self):
        text=p.synthetic_stdout()
        for bad in [text.rsplit('END',1)[0],text+text,text.replace('END UNITMASS 2 2 2 0','END UNITMASS 2 2 1 0')]:
            with self.assertRaises(ValueError):p.parse(bad)

    def test_07_fatal_flag_rounding_or_halting_fail(self):
        text=p.synthetic_stdout();old='ENV AFTER 4 0 0 0 0 0 0 0 0 0 0 0'
        bad=['ENV AFTER 4 0 1 0 0 0 0 0 0 0 0 0',
             'ENV AFTER 4 1 0 0 0 0 0 0 0 0 0 0',
             'ENV AFTER 4 0 0 0 0 0 0 1 0 0 0 0']
        for row in bad:
            with self.assertRaises(ValueError):p.parse(text.replace(old,row))

    def test_08_inexact_may_be_raised_but_not_cleared(self):
        rows=p.synthetic_stdout().splitlines();active=False;kept=[]
        for row in rows:
            if row.startswith('ENV AFTER 4'):active=True
            if active and row.startswith('ENV '):
                fields=row.split();fields[8]='1';row=' '.join(fields)
            kept.append(row)
        changed='\n'.join(kept)+'\n';self.assertTrue(p.parse(changed)['verified'])
        with self.assertRaises(ValueError):p.parse(changed.replace('ENV BEFORE 5 0 0 0 0 0 1','ENV BEFORE 5 0 0 0 0 0 0'))

    def test_09_wrong_selected_backend_or_group_fails(self):
        text=p.synthetic_stdout()
        for bad in [text.replace('CHOOSE 4 1 8 2 9','CHOOSE 4 1 8 1 8'),text.replace('STATE 4 1 1 2 1','STATE 4 2 1 2 1')]:
            with self.assertRaises(ValueError):p.parse(bad)

    def test_10_actual_source_binding_and_no_reducer_link(self):
        render=json.loads((HERE/'rendering.json').read_text());build=json.loads((HERE/'build-spec.json').read_text())
        for name,wanted in render['generated_hashes'].items():
            self.assertEqual(hashlib.sha256((HERE/name).read_bytes()).hexdigest(),wanted)
        text=(HERE/'helper.f').read_text()
        self.assertIn('PARAMETER (NSQUAREDSO=1)',text)
        self.assertLess(text.index('CALL QPMUNIT_CHOOSE_LOOPLIB'),text.index('MP_M2L(1)=MP_M3**2'))
        self.assertIn('MLREDUCTIONLIB(I_LIB).EQ.9',text)
        self.assertNotIn('MP_NINJARS_LOOP',text)
        self.assertEqual(build['compiler_commands_executed'],0)
        self.assertTrue(build['only_recording_stubs_linked'])
        self.assertTrue(all('tirust.so' not in str(x) for x in build['link_command']))


def main():
    log=io.StringIO();result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(UnitParser))
    suffix='optimized' if not __debug__ else 'normal'
    with (HERE/('parser-tests-'+suffix+'.log')).open('x') as stream:stream.write(log.getvalue())
    receipt={'tests':result.testsRun,'success':result.wasSuccessful(),'errors':len(result.errors),'failures':len(result.failures),
        'compiler_calls':0,'native_Fortran_executions':0,'test_input':'Synthetic parser fixture; not native stdout',
        'oracle':{k:v for k,v in p.oracle().items() if k in ['QPARG','DPARG','MASS2','genuine_113bit_mass_input_indices','bottom_square_significand_bits']}}
    with (HERE/('parser-tests-'+suffix+'.json')).open('x') as stream:json.dump(receipt,stream,sort_keys=True,indent=2);stream.write('\n')
    print(log.getvalue(),end='')
    if not result.wasSuccessful():raise SystemExit(1)


if __name__=='__main__':main()
