"""Strict pure parser and independent integer IEEE oracle for recording units.

parse(text) reads stdout only. It launches no process and never loads a reducer.
Its successful record comparison requires a separate actual RUN/runtime owner
before it can be described as observed Fortran behavior.
"""
from fractions import Fraction
from math import isqrt
import re


def require(value,message):
    if not value:raise ValueError(message)


def rounded(value,precision):
    """Nearest-even binary rational; these bounded normal fixture values only."""
    value=Fraction(value)
    if not value:return value
    sign=-1 if value<0 else 1;value=abs(value)
    exponent=value.numerator.bit_length()-value.denominator.bit_length()
    if value<Fraction(2)**exponent:exponent-=1
    quantum=Fraction(2)**(exponent-precision+1)
    scaled=value/quantum;q,rem=divmod(scaled.numerator,scaled.denominator)
    if 2*rem>scaled.denominator or (2*rem==scaled.denominator and q%2):q+=1
    return sign*q*quantum


def real_words(value,precision):
    """Canonical little-endian storage words for bounded normal/positive-zero values."""
    value=rounded(value,precision)
    width,bias,exponent_bits=(128,16383,15) if precision==113 else (64,1023,11)
    if not value:bits=0
    else:
        sign=int(value<0);value=abs(value)
        exponent=value.numerator.bit_length()-value.denominator.bit_length()
        if value<Fraction(2)**exponent:exponent-=1
        quantum=Fraction(2)**(exponent-precision+1)
        significand=value/quantum
        require(significand.denominator==1,'Oracle significand is not exact')
        require(1<=exponent+bias<(1<<exponent_bits)-1,'Oracle fixture outside normal range')
        bits=(sign<<(width-1))|((exponent+bias)<<(precision-1))|(int(significand)-(1<<(precision-1)))
    return [f'{(bits>>(64*i))&((1<<64)-1):016X}' for i in range(width//64)]


def complex_words(value,precision):
    return real_words(value[0],precision)+real_words(value[1],precision)


def sqrt2_qp():
    scale=1<<112;lower=isqrt(2*scale*scale)
    # Compare sqrt(2)*scale with exact half-integer (lower+1/2).
    significand=lower+int(8*scale*scale>(2*lower+1)**2)
    result=Fraction(significand,scale)
    require((result-Fraction(1,2*scale))**2<2<(result+Fraction(1,2*scale))**2,
            'Independent sqrt2 rounding cell does not contain sqrt2')
    return result


def oracle():
    derived=sqrt2_qp()
    complex_mass=(1+Fraction(1,1<<100),-Fraction(1,8)-Fraction(1,1<<90))
    mb=rounded(Fraction(47,10),53)
    masses=[(derived,Fraction(0)),complex_mass,(mb,Fraction(0))]
    dp_masses=[tuple(rounded(x,53) for x in z) for z in masses]
    squares=[]
    for a,b in masses:
        real=rounded(a*a-b*b,113);imag=rounded(2*a*b,113)
        # For these particular inputs, ordinary separately rounded products and
        # a final subtraction give the same answer as final exact rounding.
        # This is not an assertion about arbitrary complex multiplication.
        require(real==rounded(rounded(a*a,113)-rounded(b*b,113),113),'Complex-product rounding ambiguity')
        require(imag==rounded(rounded(a*b,113)+rounded(b*a,113),113),'Imaginary-product rounding ambiguity')
        squares.append((real,imag))
    ordered=[squares[2],squares[0],squares[1]]
    return {
        'masses':masses,'DP_masses':dp_masses,'squares':squares,'ordered_squares':ordered,
        'QPARG':[complex_words(z,113) for z in masses],
        'DPARG':[complex_words(z,53) for z in dp_masses],
        'MASS2':[complex_words(z,113) for z in ordered],
        'genuine_113bit_mass_input_indices':[1,2],
        'bottom_square_significand_bits':squares[2][0].numerator.bit_length(),
    }


def parse(text):
    require(isinstance(text,str),'Unit stdout must be text')
    rows=[line.split() for line in text.splitlines() if line.strip()]
    require(rows and rows[0]==['META','UNITMASS','1','3','2','113','128','LITTLE'],'Unit META differs')
    cursor=1;states=[];expected=oracle();calls=[]

    def next_row():
        nonlocal cursor
        require(cursor<len(rows),'Incomplete unit journal')
        value=rows[cursor];cursor+=1;return value

    def environment(label,mode):
        row=next_row()
        require(len(row)==14 and row[:3]==['ENV',label,str(mode)],'Unit IEEE record identity/layout differs')
        try:state=list(map(int,row[3:]))
        except ValueError:raise ValueError('Noninteger unit IEEE record') from None
        require(state[0]==0 and all(x in (0,1) for x in state[1:]),'Unit rounding/state unsupported')
        require(state[1:5]==[0,0,0,0] and state[6:]==[0]*5,'Unit fatal/underflow flag or enabled trap observed')
        if states:require(state[5]>=states[-1]['state'][5],'Unit inexact sticky flag was cleared')
        states.append({'label':label,'mode':mode,'state':state})
        return state

    def vectors(label,mode,values):
        output=[]
        for i,wanted in enumerate(values,1):
            row=next_row()
            require(row[:3]==[label,str(mode),str(i)] and len(row)==3+len(wanted),'Unit vector identity/layout differs')
            require(all(re.fullmatch('[0-9A-F]{16}',x) for x in row[3:]),'Malformed unit storage word')
            require(row[3:]==wanted,'Unit '+label+' words differ from independent integer oracle')
            output.append(row[3:])
        return output

    initial=environment('INITIAL',0)
    require(initial[1:6]==[0]*5,'Unit initial IEEE flags are not fresh')
    environment('PREPARED',0)
    for index,mode in enumerate((4,5),1):
        before=environment('BEFORE',mode)
        arguments=vectors('QPARG',mode,expected['QPARG'])
        dp_arguments=vectors('DPARG',mode,expected['DPARG'])
        require(next_row()==['CHOOSE',str(mode),'1','8','2','9','3','2','1','1','1'],
                'Unit selected/requested backend, type, rank or group differs')
        squares=vectors('MASS2',mode,expected['MASS2'])
        results=vectors('RESULT',mode,[complex_words((10*mode+i,-i),53) for i in range(1,4)])
        require(next_row()==['STATE',str(mode),'1','1','2','1',str(index),str(index),'0'],
                'Unit state/status/counters differ')
        after=environment('AFTER',mode)
        calls.append({'CTMODE':mode,'requested_backend':8,'selected_backend':9,
            'actual_mass_argument_words':arguments,'actual_DP_argument_words':dp_arguments,
            'actual_cyclic_mass_square_words':squares,'synthetic_result_words':results,
            'IEEE_before':before,'IEEE_after':after})
    require(next_row()==['END','UNITMASS','2','2','2','0'],'Unit completion footer differs')
    require(cursor==len(rows),'Extra unit journal records')
    require(calls[0]['actual_mass_argument_words']==calls[1]['actual_mass_argument_words'] and
            calls[0]['actual_cyclic_mass_square_words']==calls[1]['actual_cyclic_mass_square_words'],
            'Repeated unit modes changed input/square words')
    return {'schema':'strict-qp-mass-genuine113-recording-unit-v1','verified':True,
        'recorded_helper_calls':2,'actual_selected_backend':9,'requested_backend':8,
        'cyclic_order':[3,1,2],'components_per_complex_QP':4,'word_storage':'little-endian uint64 hex',
        'genuine_113bit_mass_input_indices':expected['genuine_113bit_mass_input_indices'],
        'bottom_square_significand_bits':expected['bottom_square_significand_bits'],
        'independent_integer_oracle':True,'calls':calls,'IEEE':states,
        'new_native_execution_by_parser':False,'real_reducers_called':False,
        'real_CHOOSE_kernel_qualified':False,'MP_SWITCH_ORDER_reversal_qualified':False,
        'physical_model_or_amplitude_truth_qualified':False}


def synthetic_stdout():
    """Pure positive parser fixture, explicitly not a native execution record."""
    expected=oracle();lines=['META UNITMASS 1 3 2 113 128 LITTLE']
    state='0 0 0 0 0 0 0 0 0 0 0'
    lines+=['ENV INITIAL 0 '+state,'ENV PREPARED 0 '+state]
    for index,mode in enumerate((4,5),1):
        lines.append(f'ENV BEFORE {mode} '+state)
        for label in ('QPARG','DPARG'):
            lines += [f'{label} {mode} {i} '+' '.join(z) for i,z in enumerate(expected[label],1)]
        lines.append(f'CHOOSE {mode} 1 8 2 9 3 2 1 1 1')
        lines += [f'MASS2 {mode} {i} '+' '.join(z) for i,z in enumerate(expected['MASS2'],1)]
        lines += [f'RESULT {mode} {i} '+' '.join(complex_words((10*mode+i,-i),53)) for i in range(1,4)]
        lines.append(f'STATE {mode} 1 1 2 1 {index} {index} 0')
        lines.append(f'ENV AFTER {mode} '+state)
    lines.append('END UNITMASS 2 2 2 0')
    return '\n'.join(lines)+'\n'
