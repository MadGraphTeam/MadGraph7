#!/usr/bin/env python3
"""Dormant, separately admitted private comparison of one Fortran object's flags."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import struct
import subprocess
import sys
import time
import types

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/fortran-tirust-interface-o3-work-2'
REPORT=ROOT/'.tirust-build/fortran-tirust-interface-o3-execution-2'
CPU=12
CAPS={'build':600.,'n1parity':300.,'n1timing':300.,'n3parity':600.,'n3anchortiming':600.}
CLEANUP=60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
VARIANTS=('original','candidate')
PAIRS=7
N1_LOOPS=128
ANCHORS=(('DP',1,15),('QP',16,1))
LOADER='docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py'
CLEANUP_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'
DEADLINE_HELPER='docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/run.py'
EXPECTED_SOURCE=None
REVIEWED={name:None for name in ('build','n1parity','n1timing','n3parity')}
PREREQUISITES={'build':(), 'n1parity':('build',), 'n1timing':('build','n1parity'),
               'n3parity':('build','n1parity','n1timing'),
               'n3anchortiming':('build','n1parity','n1timing','n3parity')}


def require(value,message):
    if not value:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def load(name,path):
    path=Path(path)
    if path.is_relative_to(ROOT) and not path.is_relative_to(HERE):
        require(digest(path)==read(HERE/'source-index.json')['support'][str(path.relative_to(ROOT))],
                'Pinned helper changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module


def local(name):return load('o3_'+name,HERE/(name+'.py'))


def modules():
    sys.path.insert(0,str(ROOT/'tools'))
    import tirust_benchmark as bench
    import tirust_benchmark_compiler as compiler
    from tirust_benchmark_worker import Worker,parse_outputs
    from tirust_benchmark_warmup import parse_warmup
    return bench,compiler,Worker,parse_outputs,parse_warmup


def pin(case):return read(HERE/'input-pins.json')['cases'][case]
def proc(output,case):return Path(output)/'SubProcesses'/pin(case)['subprocess']
def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']


def verify_source():
    require(Path.cwd()==ROOT,'Run only from the MadGraph working repository')
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source seal required')
    seal=read(HERE/'source-index.json')
    require({str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'},
            'Source packet exact inventory changed')
    for name,want in seal['files'].items():
        path=HERE/name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and not path.is_symlink(),
                'Unsafe source path')
        require(digest(path)==want['sha256'] and path.stat().st_size==want['bytes'],'Changed sealed source: '+name)
    for name,checksum in seal['support'].items():
        require(digest(ROOT/name)==checksum,'Changed pinned support: '+name)


def environment():
    compiler=modules()[1];n1=pin('n1');n3=pin('n3')
    require(n1['compiler_flags']['environment']==n3['compiler_flags']['environment']=={},'Original compiler injection differs')
    require(n1['runtime']['libraries']==n3['runtime']['libraries'],'Case runtime providers differ')
    native=[Path(p).parent for p in n1['runtime']['libraries'] if Path(p).name=='libmadloop_tirust.so']
    require(len(native)==1,'Ambiguous frozen TIRust provider')
    libraries=[ROOT/'HEPTools/ninja/lib',ROOT/'HEPTools/collier',ROOT/'HEPTools/ninjars/lib',native[0]]
    return local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),compiler.COMPILER_ENVIRONMENT,{},libraries)


def protected():
    """Read-only inventories and tool resolution; no loader/compiler invocation."""
    data=read(HERE/'input-pins.json');bench=modules()[0]
    for name,row in data['files'].items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        require(path.is_file() and digest(path)==row['sha256'] and path.stat().st_size==row['bytes'],
                'Protected input changed: '+name)
    for name,checksum in data['ancestry'].items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        require(digest(path)==checksum,'Closed ancestry changed: '+name)
    for case,row in data['cases'].items():
        output=Path(row['output'])
        require(bench.generated_sources(output)==row['generated_sources'],'Original generated source inventory changed: '+case)
        require(bench.numerical_objects(output)==row['numerical_objects'],'Original numerical objects changed: '+case)
        require(bench.numerical_card_inputs(output)==row['numerical_cards'],'Original numerical cards changed: '+case)
        if 'links' in row:
            links={str(p.relative_to(output)):{'target':str(p.readlink()),'resolved':str(p.resolve())}
                   for p in sorted(output.rglob('*')) if p.is_symlink()}
            require(links==row['links'],'Original resource/library aliases changed: '+case)
        require(not (proc(output,case)/'worker-protocol.fifo').exists(),'An original worker is active')
    predecessor=verify_predecessor()
    toolpin=read(HERE/'toolchain-pins.json')
    for name,checksum in toolpin['donor_lineage'].items():
        require(digest(ROOT/name)==checksum,'Closed successful tool environment changed')
    admitted=local('tool_environment').validate(toolpin,environment())
    return {'input_pins_sha256':digest(HERE/'input-pins.json'),'toolchain_pins_sha256':digest(HERE/'toolchain-pins.json'),
            'predecessor':predecessor,
            'tool_admission':admitted,'compiler_invocations':0,'native_scientific_evaluations':0}


def verify_predecessor():
    """Source1 was not admitted; keep its complete sealed inventory unchanged."""
    data=read(HERE/'predecessor.json');name=Path(data['predecessor_source'])
    require(not name.is_absolute() and '..' not in name.parts,'Unsafe predecessor source path')
    base=ROOT/name
    actual={str(path.relative_to(base)) for path in base.rglob('*') if path.is_file()}
    require(actual==set(data['predecessor_files']),'Unadmitted predecessor exact inventory changed')
    for relative,checksum in data['predecessor_files'].items():
        path=Path(relative);file=base/path
        require(not path.is_absolute() and '..' not in path.parts and not file.is_symlink(),
                'Unsafe predecessor payload path')
        require(digest(file)==checksum,'Unadmitted predecessor bytes changed: '+relative)
    require(digest(base/'source-index.json')==data['predecessor_source_index_sha256'],
            'Unadmitted predecessor source index changed')
    return {'predecessor_json_sha256':digest(HERE/'predecessor.json'),
            'source_index_sha256':data['predecessor_source_index_sha256'],'payloads':len(actual)}


def expected_runtime(case):
    loader=load('o3_pure_loader',ROOT/LOADER);row=pin(case)
    interpreter=loader._support('run.py',{'interpreter'}).interpreter(proc(row['output'],case)/'check')
    files={str(Path(p).resolve()):h for p,h in row['runtime']['libraries'].items()};aliases={}
    for left,right in re.findall(r'^\s*(/[^\s]+)\s*=>\s*(/[^\s]+)\s*\(',row['runtime']['ldd'],re.M):
        if Path(left).resolve()==interpreter and Path(right).resolve()!=interpreter:
            name=str(Path(right).resolve())
            require('ld-linux' in Path(name).name and name in files,'Unknown historical loader alias')
            aliases[name]=files.pop(name)
    require(str(interpreter) in files,'Actual interpreter absent from historical closure')
    return {'files':files,'actual_interpreter':str(interpreter),'historical_ldd_only_aliases':aliases}


def preflight():
    verify_source();before=protected()
    require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    return {'status':'source-only-preflight-passed','source_index_sha256':EXPECTED_SOURCE,'protected':before,
            'runtime':{case:expected_runtime(case) for case in ('n1','n3')},'caps_seconds':CAPS,
            'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,
            'compiler_invocations':0,'loader_queries':0,'native_scientific_evaluations':0,'performance_acceptance':False}


OBSERVATION_FILES={'worker-protocol.fifo','worker-raw','warmup.dat','dimensions.dat','values.dat','timing.dat',
                   'timed_status.dat','exact-words.dat','exact-ieee.dat','timed-exact-words.dat','timed-ieee.dat',
                   'anchor-timing.dat','anchor-status.dat','anchor-exact.dat','anchor-ieee.dat','anchor-values.dat'}


def clone(source,destination):
    source=Path(source);destination=Path(destination)
    def ignore(directory,names):
        excluded={n for n in names if n in OBSERVATION_FILES or n.endswith(('HelFilter.dat','LoopFilter.dat'))}
        if Path(directory)==source:excluded.add('lib')
        return excluded
    shutil.copytree(source,destination,symlinks=False,ignore=ignore)
    (destination/'lib').symlink_to((source/'lib').resolve(),target_is_directory=True)
    require(all(not p.is_symlink() or p==destination/'lib' for p in destination.rglob('*')),'Private mutable symlink remains')
    require(not any(destination.rglob('*HelFilter.dat')) and not any(destination.rglob('*LoopFilter.dat')),'Fresh filters remain')


def command(argv,cwd,logs,name):
    logs.mkdir(parents=True,exist_ok=True);argv=list(map(str,argv));env=environment();env['PWD']=str(cwd)
    dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd),'controller_pid':os.getpid(),
          'session':os.getsid(0),'process_group':os.getpgrp(),'subprocess_new_session':False})
    with (logs/(name+'.stdout.txt')).open('xb') as stream:
        done=subprocess.run(argv,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))})
    require(done.returncode==0,'Admitted command failed: '+name)
    return (logs/(name+'.stdout.txt')).read_text()


def capture_policy(directory,logs,label):
    """Retain policy helper commands too; make's internal children are not traced."""
    compiler=modules()[1];real=compiler.subprocess;sequence=0
    def recorded_run(argv,**kwargs):
        nonlocal sequence
        sequence+=1;name=label+'-'+str(sequence).zfill(2);logs.mkdir(parents=True,exist_ok=True)
        dump(logs/(name+'.command.json'),{'argv':list(map(str,argv)),'cwd':str(kwargs.get('cwd',directory)),
              'scope':'compiler-policy helper; make-internal child queries are not individually recorded'})
        done=real.run(argv,**kwargs)
        stdout=done.stdout or '';stderr=done.stderr or ''
        require(isinstance(stdout,str) and isinstance(stderr,str),'Policy capture must return text')
        (logs/(name+'.stdout.txt')).write_text(stdout);(logs/(name+'.stderr.txt')).write_text(stderr)
        dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt')),
              'stderr_sha256':digest(logs/(name+'.stderr.txt'))})
        return done
    def recorded_output(argv,**kwargs):
        done=recorded_run(argv,stdout=real.PIPE,**kwargs)
        if done.returncode:raise real.CalledProcessError(done.returncode,argv,output=done.stdout,stderr=done.stderr)
        return done.stdout
    compiler.subprocess=types.SimpleNamespace(run=recorded_run,check_output=recorded_output,PIPE=real.PIPE,
                                              STDOUT=real.STDOUT,CalledProcessError=real.CalledProcessError)
    try:return compiler.capture_effective_flags(directory,env=environment())
    finally:compiler.subprocess=real


def query_runtime(directory,case,prebound,logs,label):
    loader=load('o3_runtime_loader',ROOT/LOADER)
    return loader.query_runtime(directory/'check',expected_runtime(case)['files'],prebound,
                                lambda a,n:command(a,directory,logs,label+'-'+n))


def symbols(text):
    found={}
    for line in text.splitlines():
        words=line.split()
        if len(words)>=3 and '__mtirust_MOD_' in words[-1]:found[words[-1]]=found.get(words[-1],0)+1
    return found


def build():
    bench,compiler,*_=modules();policy=local('policy');before=protected();results={}
    wanted_symbols=read(HERE/'input-pins.json')['expected_mtirust_symbols']
    if isinstance(wanted_symbols,list):wanted_symbols={name:1 for name in wanted_symbols}
    for case in ('n1','n3'):
        row=pin(case)
        for variant in VARIANTS:
            output=WORK/'build'/case/variant;clone(row['output'],output)
            directory=proc(output,case);logs=REPORT/'build'/case/variant/'commands'
            for name in ('check_sa.f','TIRUST_interface.f'):
                (directory/name).write_bytes((HERE/'source-preview'/case/name).read_bytes())
            (directory/'makefile').write_text(policy.private_makefile((directory/'makefile').read_text(),variant=='candidate'))
            actual=capture_policy(directory,logs,'policy-before')
            policy.verify_policy(row['compiler_flags'],actual,variant=='candidate',compiler)
            driver=row['compiler_flags']['scopes']['process']['recipes']['TIRUST_interface.f']['compiler'][0]['path']
            expanded=command([tool('make'),'--no-print-directory','--dry-run','--always-make','SHELL='+tool('bash'),'check'],
                             directory,logs,'expanded-check')
            recipes,link=policy.select_commands(expanded,driver,environment())
            original_objects=bench.numerical_objects(output)
            for i,(name,argv) in enumerate(recipes):command(argv,directory,logs,f'{i:02d}-compile-'+name)
            loader=load('o3_build_loader',ROOT/LOADER)
            prebound=loader.prelink(link,directory,environment(),lambda a,n:command(a,directory,logs,n))
            for path,checksum in expected_runtime(case)['files'].items():
                require(path not in prebound['bound'] or prebound['bound'][path]==checksum,'Runtime/prelink conflict')
                prebound['bound'][path]=checksum
            dump(REPORT/'build'/case/variant/'prelink.json',prebound)
            command(link,directory,logs,'02-link')
            mapfile=directory/'private-link.map'
            loads=loader.requireactualmap(mapfile.read_text(),directory,prebound,directory/'check')
            after=capture_policy(directory,logs,'policy-after')
            evidence=policy.verify_policy(row['compiler_flags'],after,variant=='candidate',compiler)
            require(bench.same_compiler_policy(actual,after),'Compiler policy changed during build')
            changed={'SubProcesses/'+row['subprocess']+'/'+name for name in ('check_sa.o','TIRUST_interface.o')}
            objects=bench.numerical_objects(output)
            require(set(objects)==set(original_objects),'An unexpected numerical object appeared/disappeared')
            require({k:v for k,v in objects.items() if k not in changed}==
                    {k:v for k,v in original_objects.items() if k not in changed},'Another numerical object changed')
            sym=symbols(command([tool('nm'),'--defined-only','check'],directory,logs,'03-executable-symbols'))
            require(sym==wanted_symbols and all(v==1 for v in sym.values()),'MTIRUST definitions differ or duplicate')
            require(not (directory/'mtirust.o').exists() and not (directory/'qp_profile.o').exists(),
                    'Unexpected private reducer/profile object')
            require('libtirust.a(' in mapfile.read_text(),'Stock TIRust Fortran archive member not observed')
            runtime=query_runtime(directory,case,prebound,logs,'build')
            results[case+'/'+variant]={'case':case,'variant':variant,'output':str(output),
                'sources':bench.generated_sources(output),'objects':objects,'compiler_flags':after,'policy_evidence':evidence,
                'executable_sha256':digest(directory/'check'),'link_map_sha256':digest(mapfile),
                'prelink_sha256':digest(REPORT/'build'/case/variant/'prelink.json'),
                'actual_link_loads':loads,'mtirust_definitions':sym,'runtime':runtime}
    require(protected()==before,'Protected originals changed during build')
    dump(REPORT/'build/result.json',{'status':'passed','stage':'build','source_index_sha256':EXPECTED_SOURCE,'variants':results,
          'protected':before,'native_amplitude_calls':0,'compiled_units_per_variant':2,
          'compiler_policy_capture_scope':'Recorded explicitly; make-internal queries are not individually traced',
          'candidate_delta':['TIRUST_interface.f only: -O3 -fno-fast-math']})


def receipt(stage):
    reviewed=REVIEWED.get(stage)
    require(reviewed and digest(REPORT/stage/'terminal.json')==reviewed,'Separate reviewed '+stage+' terminal hash required')
    terminal=read(REPORT/stage/'terminal.json');result=read(REPORT/stage/'result.json')
    require(terminal['stage']==stage and terminal['source_index_sha256']==EXPECTED_SOURCE
            and terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],
            'Predecessor did not close successfully: '+stage)
    require(terminal['result_sha256']==digest(REPORT/stage/'result.json') and result['status']=='passed'
            and result['stage']==stage and result['source_index_sha256']==EXPECTED_SOURCE,'Predecessor source/result binding changed')
    return result


def verified_build():
    bench=modules()[0];built=receipt('build');loader=load('o3_verify_loader',ROOT/LOADER)
    require(set(built['variants'])=={c+'/'+v for c in ('n1','n3') for v in VARIANTS},'Incomplete build variant set')
    for name,row in built['variants'].items():
        output=Path(row['output']);directory=proc(output,row['case']);prelink=REPORT/'build'/name/'prelink.json'
        require(bench.generated_sources(output)==row['sources'] and bench.numerical_objects(output)==row['objects']
                and digest(directory/'check')==row['executable_sha256'],'Reviewed build bytes changed')
        require(digest(prelink)==row['prelink_sha256'] and digest(directory/'private-link.map')==row['link_map_sha256'],
                'Reviewed link evidence changed')
        require(loader.requireactualmap((directory/'private-link.map').read_text(),directory,read(prelink),directory/'check')
                ==row['actual_link_loads'],'Actual LOAD binding changed')
    return built


def verify_predecessors(stage):
    values={}
    if stage!='build':values['build']=verified_build()
    for previous in PREREQUISITES[stage]:
        if previous!='build':values[previous]=receipt(previous)
    for name,value in values.items():
        if name!='build':
            require(value['reviewed']['build']==REVIEWED['build'],'Predecessor used another build')
            for key,want in value['reviewed'].items():
                require(REVIEWED.get(key)==want,'Predecessor review chain changed')
    return values


def private_binding(output,case,built):
    bench=modules()[0];directory=proc(output,case);row=pin(case)
    require(bench.generated_sources(output)==built['sources'] and bench.numerical_objects(output)==built['objects']
            and digest(directory/'check')==built['executable_sha256'],'Private execution bytes changed')
    cards=bench.numerical_card_inputs(output)
    alias='SubProcesses/'+row['subprocess']+'/MadLoop5_resources/MadLoopParams.dat'
    expected={**row['numerical_cards'],alias:next(iter(row['numerical_cards'].values()))}
    require(cards==expected,'Private four-card inventory changed')
    physical=bench.resolved_parameter_card(directory)
    require(physical is not None and digest(physical)==row['param_card_sha256']==digest(output/'Cards/param_card.dat'),
            'Physical parameter card changed')
    require(all((output/name).resolve().is_relative_to(output.resolve()) for name in cards),'Mutable cards escape export')
    return {'cards':cards,'physical_sha256':digest(physical),'executable_sha256':built['executable_sha256']}


def maps(worker,case):
    raw=Path(f'/proc/{worker.process.pid}/maps').read_text();files={}
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'Deleted runtime provider')
            path=Path(fields[-1]).resolve();files[str(path)]=digest(path)
    expected=expected_runtime(case)['files'];exe=(worker.directory/'check').resolve()
    allowed={**expected,**read(HERE/'source-index.json')['allowed_extra_mappings'],str(exe):digest(exe)}
    require(all(files.get(p)==h for p,h in expected.items()) and files.get(str(exe))==digest(exe),'Required mapping absent')
    require(all(allowed.get(p)==h for p,h in files.items()),'Unexpected runtime mapping')
    return {'pid':worker.process.pid,'maps':raw,'files':files}


def start_worker(output,case,variant,built,report,stack):
    _,_,Worker,_,parse_warmup=modules();directory=proc(output,case);row=pin(case)
    before=private_binding(output,case,built)
    runtime=query_runtime(directory,case,read(REPORT/'build'/case/variant/'prelink.json'),report/'commands','before')
    worker=stack.enter_context(Worker([tool('taskset'),'-c',str(CPU),str(directory/'check'),row['points']],
                                     directory,report/'worker.log',env=environment(),timeout=240.))
    ready={name:getattr(worker,name) for name in ('points','ndim','nso','nborn','cold_seconds')}
    require([ready[n] for n in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong frozen dimensions')
    warmup=parse_warmup(directory,9,100,ready)
    actual_text=(directory/'warmup.dat').read_text();historical_text=Path(row['closed_warmup']).read_text()
    def history(text):
        result=[]
        for line in text.splitlines():
            if not line.strip() or line.lstrip().startswith('#'):continue
            fields=line.split();require(len(fields)==9,'Malformed complete learning trace')
            result.append(list(map(int,fields[:4])))
        return result
    observed_history=history(actual_text);historical_history=history(historical_text)
    comparison=local('analysis').compare_variants(float_rows(read(row['closed_observation'])['rows']),
                                                  float_rows(warmup['rows']),modules()[0].compare_rows)
    learning={'raw_byte_identity':actual_text==historical_text,'history_matches':observed_history==historical_history,
              'actual_call_point_order_status':observed_history,'historical_call_point_order_status':historical_history,
              'steady_full100_comparison':comparison,
              'bootstrap_scope':'Call0 numerical fields retained as diagnostics; scientific gate uses the final steady100.'}
    dump(report/'learning-comparison.json',learning)
    require(learning['history_matches'],'Learning call/point/order/status history changed')
    require(comparison['passed'],'Steady full100 learning violates the predeclared scientific criterion')
    dump(report/'ready.json',ready);dump(report/'warmup.json',warmup)
    shutil.copyfile(directory/'warmup.dat',report/'warmup.dat');shutil.copyfile(directory/'dimensions.dat',report/'dimensions.dat')
    dump(report/'maps-before.json',maps(worker,case));dump(report/'private-before.json',before)
    return worker,{'before':before,'runtime':runtime}


def finish_worker(worker,output,case,variant,built,report,binding):
    dump(report/'maps-after.json',maps(worker,case));after=private_binding(output,case,built)
    require(after==binding['before'],'Private inputs changed during execution')
    runtime=query_runtime(worker.directory,case,read(REPORT/'build'/case/variant/'prelink.json'),report/'commands','after')
    require(all(runtime[k]==binding['runtime'][k] for k in ('loader','loader_sha256','files')),'Runtime changed')
    dump(report/'private-after.json',after)


def float_rows(values):
    rows=[]
    for row in values:
        rows.append({'point':row['point'],'order':row['order'],'status':row['status'],
                     'words':[struct.pack('>d',v).hex().upper() for v in row['coefficients']+[row['accuracy']]]})
    return rows


def historical_exact(case):return float_rows(read(pin(case)['closed_observation'])['rows'])


def exact_command(worker,case,destination):
    analysis=local('analysis');worker.sequence+=1;worker._send(f'EXACT {worker.sequence} 0')
    require(worker._message()==['EXACTED',str(worker.sequence)],'Full100 exact command failed')
    destination.mkdir(parents=True,exist_ok=False)
    for name in ('exact-words.dat','exact-ieee.dat'):shutil.copyfile(worker.directory/name,destination/name)
    rows=analysis.exact((destination/'exact-words.dat').read_text(),pin(case)['expected_codes'])
    flags=analysis.ieee((destination/'exact-ieee.dat').read_text(),points=range(1,101))
    comparison=analysis.compare_variants(historical_exact(case),rows,modules()[0].compare_rows)
    dump(destination/'historical-comparison.json',comparison)
    require(comparison['passed'],'Full100 coefficients violate the predeclared historical scientific criterion')
    return {'rows':rows,'ieee':flags,'historical_comparison':comparison}


def own_comparison(reference,actual,destination,label,analysis=None):
    """Retain finite accuracy drift; only coefficient/status words are a gate."""
    analysis=local('analysis') if analysis is None else analysis
    comparison=analysis.compare_own(reference,actual)
    dump(Path(destination)/(label+'.json'),comparison)
    require(comparison['passed'],'Own-reference coefficient/status comparison failed: '+label)
    return comparison


def timed_own_comparisons(reference,previous,actual,destination,analysis=None):
    """Compare against qualified parity and this role's previous timed batch."""
    analysis=local('analysis') if analysis is None else analysis
    # Both reports are retained before either gate, including a first failure.
    reports={'qualified_parity':analysis.compare_own(reference,actual),
             'previous_batch':analysis.compare_own(previous,actual)}
    dump(Path(destination)/'own-comparisons.json',reports)
    require(all(report['passed'] for report in reports.values()),
            'Timed own-reference coefficient/status comparison failed')
    return reports


def result_base(stage):
    return {'status':'passed','stage':stage,'source_index_sha256':EXPECTED_SOURCE,
            'reviewed':{name:REVIEWED[name] for name in PREREQUISITES[stage]},
            'performance_acceptance':False,'candidate_promoted':False,
            'IEEE_scope':'Actual pre/post observations only; no trap-freedom or newly-raised-exception inference.'}


def parity(case,stage):
    built=verify_predecessors(stage)['build'];before=protected();lanes={}
    for variant in VARIANTS:
        report=REPORT/stage/variant;output=WORK/stage/variant;row=built['variants'][case+'/'+variant]
        clone(row['output'],output)
        with ExitStack() as stack:
            worker,binding=start_worker(output,case,variant,row,report,stack)
            lanes[variant]=exact_command(worker,case,report/'exact')
            if variant=='candidate':
                comparison=local('analysis').compare_variants(lanes['original']['rows'],lanes['candidate']['rows'],modules()[0].compare_rows)
                dump(REPORT/stage/'cross-variant-comparison.json',comparison)
                ieee_equal=lanes['candidate']['ieee']==lanes['original']['ieee']
                dump(REPORT/stage/'ieee-comparison.json',{'observed_states_equal':ieee_equal})
                require(comparison['passed'],'Original/candidate scientific coefficient criterion failed')
                require(ieee_equal,'Original/candidate observed IEEE states differ')
            finish_worker(worker,output,case,variant,row,report,binding)
    require(protected()==before,'Protected original changed during parity')
    dump(REPORT/stage/'result.json',{**result_base(stage),'case':case,'lanes':lanes,'comparison':comparison,
          'full100_learning_per_worker':True,'expected_codes':pin(case)['expected_codes'],
          'precision_scope':'n1 DP only' if case=='n1' else 'n3 87 DP and13 automatic-QP points; no exhaustive QP/IEEE domain claim'})


def timing(case,stage,anchor=False):
    previous=verify_predecessors(stage);built=previous['build']
    parity_result=previous['n3parity' if case=='n3' else 'n1parity'];reference=parity_result['lanes']
    analysis=local('analysis');before=protected();workers={};bindings={};all_pairs={};fresh_rows={};fresh_own={}
    with ExitStack() as stack:
        for variant in VARIANTS:
            report=REPORT/stage/variant;output=WORK/stage/variant;row=built['variants'][case+'/'+variant]
            clone(row['output'],output)
            worker,binding=start_worker(output,case,variant,row,report,stack)
            exact=exact_command(worker,case,report/'exact-before-timing')
            fresh_own[variant]=own_comparison(reference[variant]['rows'],exact['rows'],report/'exact-before-timing',
                                             'own-qualified-comparison',analysis)
            require(exact['ieee']==reference[variant]['ieee'],
                    'Fresh timed worker failed its own qualified IEEE reference')
            fresh_rows[variant]=exact['rows']
            workers[variant]=worker;bindings[variant]=(output,row,binding)
        scopes=ANCHORS if anchor else (('full100',None,N1_LOOPS),)
        for label,point,loops in scopes:
            pairs=[]
            previous_rows={variant:[row for row in fresh_rows[variant] if point is None or row['point']==point]
                           for variant in VARIANTS}
            for pair_index in range(1,PAIRS+1):
                order=list(VARIANTS) if pair_index%2 else list(reversed(VARIANTS))
                pair={'pair':pair_index,'order':order}
                for variant in order:
                    worker=workers[variant];worker.sequence+=1
                    command_name='ANCHOR_'+label if anchor else 'TIMED'
                    worker._send(f'{command_name} {worker.sequence} {loops}')
                    reply=['ANCHORED' if anchor else 'DONE',str(worker.sequence),str(loops)]
                    require(worker._message()==reply,'Timed command failed')
                    raw=REPORT/stage/variant/label/f'pair-{pair_index}';raw.mkdir(parents=True,exist_ok=False)
                    names=(('anchor-timing.dat','anchor-status.dat','anchor-exact.dat','anchor-ieee.dat','anchor-values.dat')
                           if anchor else ('timing.dat','values.dat','timed_status.dat','timed-exact-words.dat','timed-ieee.dat'))
                    for name in names:shutil.copyfile(worker.directory/name,raw/name)
                    if anchor:
                        observed=analysis.anchor_outputs({name:(raw/name).read_text() for name in names},
                                                         pin(case)['expected_codes'],point=point,loops=loops)
                        wanted=[row for row in reference[variant]['rows'] if row['point']==point]
                    else:
                        ordinary=modules()[3](worker.directory,9,100,loops)
                        rows=analysis.exact((raw/'timed-exact-words.dat').read_text(),pin(case)['expected_codes'])
                        decimal=analysis.decimal_exact((raw/'values.dat').read_text(),pin(case)['expected_codes'])
                        require(rows==decimal,'Timed final full100 decimal/raw words differ')
                        counts=analysis.status_histogram((raw/'timed_status.dat').read_text(),pin(case)['expected_codes'],loops)
                        require(counts==ordinary['timed_status_counts'],'Timed status parser disagreement')
                        observed={'seconds':ordinary['seconds'],'rows':rows,'status_counts':counts,
                                  'ieee':analysis.ieee((raw/'timed-ieee.dat').read_text(),points=[0])}
                        wanted=reference[variant]['rows']
                    observed['own_comparisons']=timed_own_comparisons(wanted,previous_rows[variant],observed['rows'],raw,analysis)
                    observed['previous_batch_reference']='fresh_full100_exact' if pair_index==1 else 'pair-'+str(pair_index-1)
                    previous_rows[variant]=observed['rows']
                    pair[variant]=observed
                require(pair['candidate']['ieee']==pair['original']['ieee'],'Paired timed actual IEEE states differ')
                comparison=analysis.compare_variants(pair['original']['rows'],pair['candidate']['rows'],modules()[0].compare_rows)
                pair['comparison']=comparison
                dump(REPORT/stage/label/f'pair-{pair_index}-comparison.json',comparison)
                require(comparison['passed'],'Paired timed coefficients violate the predeclared scientific criterion')
                pairs.append(pair);dump(REPORT/stage/label/f'pair-{pair_index}.json',pair)
            all_pairs[label]={'point':point,'loops':loops,'pairs':pairs,'summary':analysis.timing_summary(pairs)}
        for variant,worker in workers.items():
            output,row,binding=bindings[variant]
            finish_worker(worker,output,case,variant,row,REPORT/stage/variant,binding)
    require(protected()==before,'Protected original changed during timing')
    dump(REPORT/stage/'result.json',{**result_base(stage),'case':case,'scopes':all_pairs,'fresh_own_comparisons':fresh_own,
          'cpu':CPU,'cpu_reservation':False,'pairs':PAIRS,'full100_learning_and_exact_before_timing':True,
          'limitations':['Shared-host paired observations; precise local acceptance remains open.',
                         'Final words cover the final traversal or final anchor; status histograms cover every timed call.',
                         'No reduction-time subtraction, component instrumentation or automatic promotion.']})


def require_admission(stage):
    admitted=read(REPORT/stage/'admission.json')
    require(admitted['stage']==stage and admitted['source_index_sha256']==EXPECTED_SOURCE
            and admitted['reviewed']==REVIEWED and admitted['cap_seconds']==CAPS[stage]
            and admitted['resource_limits']==LIMITS and admitted['parent_pid']==os.getppid(),
            'Missing/mismatched separate supervisor admission')
    actual={name:list(resource.getrlimit(kind)) for kind,name in
            ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}
    require(actual=={name:[value,value] for name,value in LIMITS.items()},'Actual child resource limits differ')
    require(os.sched_getaffinity(0)=={CPU},'Actual child affinity is not nonexclusive CPU12')
    dump(REPORT/stage/'actual-limits.json',{'actual':actual,'pid':os.getpid(),'session':os.getsid(0)})


def cleanup_owned(owned,end):
    budget=min(55.,max(0.,end-time.monotonic()))
    result=owned.stop(cooperative_seconds=budget*45/55,terminate_seconds=budget*5/55,kill_seconds=budget*5/55)
    require(not result['survivors'],'Owned descendant cleanup unresolved')
    return result


def stage(name):
    cleanup=load('o3_cleanup',ROOT/CLEANUP_HELPER);deadline_support=load('o3_deadline',ROOT/DEADLINE_HELPER)
    deadline_support.STAGE_SECONDS=CAPS[name];deadline_support.CLEANUP_RESERVE=CLEANUP
    directory=REPORT/name;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':name,'source_index_sha256':EXPECTED_SOURCE,'cap_seconds':CAPS[name],
           'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running'}
    owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,deadline_support.StageDeadline() as deadline:
            entry['deadline_monotonic']=deadline.end;requests.check();verify_source();protected()
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(Path(__file__).relative_to(ROOT)),
                  '--child',name,'--source',EXPECTED_SOURCE]
            for key,value in REVIEWED.items():
                if value:argv+=['--reviewed-'+key,value]
            dump(directory/'admission.json',{**entry,'command':argv,'parent_pid':os.getpid(),'reviewed':REVIEWED})
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                    owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Admitted stage failed; no automatic retry')
            protected();verify_source();requests.check()
            entry.update(status='passed',result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
    except BaseException as error:
        if owned is not None and not cleaned:
            try:entry['cleanup']=cleanup_owned(owned,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error),publication_scope='Failure retained; no numerical/timing pass')
        dump(directory/'terminal.json',entry)
        raise


def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard resource limit too small')
        resource.setrlimit(kind,(value,value))


def main():
    global EXPECTED_SOURCE,REVIEWED
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group()
    group.add_argument('--stage',choices=tuple(CAPS));group.add_argument('--child',choices=tuple(CAPS))
    parser.add_argument('--execute',action='store_true');parser.add_argument('--source',required=True)
    for name in REVIEWED:parser.add_argument('--reviewed-'+name)
    args=parser.parse_args();EXPECTED_SOURCE=args.source
    REVIEWED={name:getattr(args,'reviewed_'+name) for name in REVIEWED}
    for value in [EXPECTED_SOURCE,*REVIEWED.values()]:
        if value is not None and not re.fullmatch('[0-9a-f]{64}',value):parser.error('Expected exact SHA256 source/receipt hash')
    selected=args.stage or args.child
    if selected:
        required=set(PREREQUISITES[selected]);actual={name for name,value in REVIEWED.items() if value}
        if actual!=required:parser.error('This stage requires exactly these separately reviewed receipts: '+','.join(sorted(required)))
    if args.child:
        limits();require_admission(args.child);verify_source();protected();verify_predecessors(args.child)
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX)
            actions={'build':build,'n1parity':lambda:parity('n1','n1parity'),
                     'n1timing':lambda:timing('n1','n1timing'),'n3parity':lambda:parity('n3','n3parity'),
                     'n3anchortiming':lambda:timing('n3','n3anchortiming',anchor=True)}
            actions[args.child]()
        return
    result=preflight()
    if not args.stage:
        require(not args.execute,'--execute needs exactly one selected stage');print(json.dumps(result,indent=2));return
    require(args.execute,'Native stages are dormant without explicit --execute after root review')
    verify_predecessors(args.stage);stage(args.stage)


if __name__=='__main__':main()
