# QP mass correction: matched-input independent-truth follow-up

Source-only research handoff, 2026-11-11. No compiler, loader, reducer, amplitude,
truth replay or new campaign/controller was run or prepared by this follow-up.
The only new artifact is this note. Numerical truth remains unexecuted.

All paths below are relative to
`/shared/external/madloop_tirust/madgraph7_madloop_tirust`.

## Source bindings inspected

The mass proposal is frozen by
`.tirust-build/qp-mass-current-backend9-source-1/source-index.json`, SHA-256
`75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25`.
The existing current n3 science is source `0fcd2cd873d61d134837e1d9e87afb13a47824fd`
with TIRust native DSO SHA-256
`eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9`.
These identify existing provenance; this note does not freshly validate a DSO
or establish that a future replay loads it.

Exact API/header/implementation source hashes read for this handoff:

| Path | SHA-256 |
|---|---|
| `vendor/tirust/mtirust.f90` | `3cb9cf98e82965e546365b293fdfd622cbae2ec09a7ae3d364de3ccf9b9bd56f` |
| `vendor/tirust/tirust.h` | `54e7c78f8087d2fa47a780248caa470d0d802d9d36f37331c5fe775a7beea2ad` |
| `vendor/tirust/src/lib.rs` | `455529b929b725e8fe2d7337ab4a41fa3de9dee1b3a953afe6dc032cf99e5a4c` |
| `vendor/ninjars/mninjars.f90` | `9f20fb4280ba6d86a0323ce5bb4f4b358c15168166dbdb4e220e172952fbdbb7` |
| `vendor/ninjars/ninjars.h` | `c2d536f6664cb3dd6aec64277234ee807f1a8599612b7f638e166ac1f88ae0ce` |
| `vendor/ninjars/src/lib.rs` | `567d984aabd8c94492653741fde71ec4f0ada0c7d8bbc6a48a8229b6de292443` |
| `vendor/ninjars/src/poles.rs` | `4384e5898c4580e41677b543857a965548c7c2b4ae1db6e1bcc24922c7dfa278` |
| `HEPTools/tirust/include/mtirust.f90` | `12295dca6b64a96dbd4f184cf67ed702f38c9fd82658e196fa4c5b7135fee10e` |

At this read, installed `HEPTools/{tirust,ninjars}/include/{tirust,ninjars}.h`
match the corresponding vendor headers, and installed
`HEPTools/ninjars/include/mninjars.f90` matches its vendor module. The installed
TIRust module does **not** match the vendor module: the vendor adds cache
clearing on QP output-decoding failure. Signatures and successful output
conventions are unchanged. A future build must bind its actual module/object
and runtime provider explicitly, rather than infer equality from these names.

Observer draft snapshot read, not a claim that the owner's developing packet
is sealed or immutable:

| Path under `.tirust-build/qp-mass-current-qualification-proposal-1/` | SHA-256 |
|---|---|
| `source-proof.json` | `56564147528767536f761997dacbde0951aa6735379769622c10261c99fecee5` |
| `observer.f90` | `475219ffdd707a2e84ecfe0886140130e2df372ccb1191d322d792955c2db6c0` |
| `observer_analysis.py` | `c805664d73a2dfff3bd69fad57bdf49c3b64c7fe2c96c4d6e1a16ef9babeee23` |

Future qualification must rebind its final frozen observer and actual records.

## Authoritative input and precision distinction

Join observer `GROUP`, `COEFFICIENTS`, `NATIVE` and `STATUS` by sequence and
`(point, role, mode, n, rank, group ID)`. Keep original/candidate roles and
direction/check modes separate. The canonical coefficients are captured before
the NinjaRS odd-degree sign conversion. The authoritative reducer input is the
**final `NATIVE` tuple**:

```
n, rank, final shifts(0:3,n), final invariants(n,n),
final complex squared masses(n), positive scale_squared, native status
```

Additionally bind pole/finite/check/cache semantics from the sealed card and
call protocol. The observer's `NATIVE` record does not itself encode those
four selectors; `mode` alone must not be treated as their complete record.

The observer records raw binary128 words, including signed zeros. Reconstruct
those words directly with `TRANSFER`, or use an exact decoder and a proven
113-bit round trip. Do not pass through Python/binary64 floats, resquare the
already-squared masses, recompute invariants from shifts, change the scale,
shift the loop-momentum origin, or reorder only one matrix axis. Preserve the
first-line residual shift and the negative-width complex branch.

Current physical MB is a binary64 card value promoted to binary128. Its square
requires 105 significant bits and is exactly representable in binary128;
QP squaring recovers information lost by the legacy DP square. This is not a
physical mass input with more than 53 significant bits. The frozen proposal's
separate synthetic real/complex controls address genuine 113-bit input cases.

`madgraph/iolibs/template_files/loop_optimized/CT_interface.inc` has SHA-256
`dfd7cf893599d2976041c1d603c08d888640bc74938d3605e14a707168e6cf16`.
Its `MP_BUILD_KINEMATIC_MATRIX` subtracts M2, applies mass-dependent on-shell
thresholds, and the tensor adapter adds M2 back. Thus changing M2 can change
the final invariant words through rounding or threshold decisions. First
compare both actual tuples `(old invariants, old M2)` and
`(new invariants, new M2)` independently. Optional crossed tuples would isolate
numerical sensitivity; they are not physical amplitudes. Do not silently force
the candidate invariant matrix to the old one or call the change mass-only.

## Direct APIs and contraction convention

Use the existing direct generic Fortran interfaces, with genuine binary128
actual arguments:

```
tirust_tensor_evaluate(n,rank,p,s,m,mu2,raw,status,
    pole_mode,compute_finite,check_pass,cache_enabled)
ninjars_tensor_evaluate(coeff,n,rank,s,p,m,mu2,res,r1,status,pole_mode)
```

TIRust C ABI version 1 is `ml_tirust_evaluate_mp` in `vendor/tirust/tirust.h`.
NinjaRS C ABI version 4 is `ninjars_evaluate_mp_with_poles` in
`vendor/ninjars/ninjars.h`. These transport space-padded 64-byte `ES64.39E4`
records: shifts 4*n; column-major invariants n*n; masses 2*n consecutive
real/imaginary records; scale one record. NinjaRS additionally takes 2*count
coefficient records. All MP buffer lengths count bytes. Both parse at 113 bits
and calculate with 256-bit MPFR; returned Fortran values are binary128.

Bypass the ordinary backend8 MadLoop wrapper when replaying candidate tuples.
That wrapper accepts legacy DP squared masses and computes
`REAL(MU_R**2,KIND=QP)`, while backend9 uses promote-then-square. Calling it
would introduce input differences rather than independently evaluate the same
tuple.

For every canonical monomial i, the one-hot NinjaRS numerator has coefficient
`(-1)**degree(i)` at i+1 and zero elsewhere. TIRust already applies
`Convention::MadLoop` and `TensorWeights::Components`: no additional odd-rank
sign or multinomial factor is due. Compare complex tensor values before
`1/(16*pi**2)`, interference factor 2, or real projection:

```
NinjaRS res(0) <-> TIRust raw(map(i),4)                  # finite
NinjaRS res(1) <-> raw(map(i),1)+raw(map(i),2)            # UV1 + IR1
NinjaRS res(2) <-> raw(map(i),3)                         # IR2
```

`res(0)` is the complete finite result, already including R1. The separately
returned `r1` is a basis diagnostic and must not be added again. Both APIs also
support selectors 0 BOTH, 1 UV, 2 IR, 3 NONE with finite terms retained; use
identical selection. First truth checks should use full finite evaluation and
fresh contexts/cache disabled. Never substitute zero tensors for refusals.

Current n3 generated source directory:
`.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n3_uux_zgg/SubProcesses/P0_uux_zgg`.
Its `TIRUST_interface.f` SHA-256 is
`179e7b982a497176862bb56c9f6ddaa4c227ce593908053fbd4783f2fba8414d`;
`loop_max_coefs.inc` SHA-256 is
`1dca06ff691666dab8f666692137cd040e407c276417611d5fcc744f5f82f19d`.
The generated mapping for canonical indices 0..69 is:

```
1,2,3,4,5,6,7,10,8,11,
13,9,12,14,15,16,17,20,26,18,
21,27,23,29,32,19,22,28,24,30,
33,25,31,34,35,36,37,40,46,56,
38,41,47,57,43,49,59,52,62,66,
39,42,48,58,44,50,60,53,63,67,
45,51,61,54,64,68,55,65,69,70
```

Cumulative component counts are 1,5,15,35,70 for ranks 0..4. The historical
`docs/benchmarkfolder/experiments/ew-threshold-adjudication/tensor-replay/replay.f90`
(SHA-256 `44f8702d46b6d5b2e5f77d107f4ac958b52a9cccccb5388b2250125b5f830fde`)
contains the correct direct-API/sign/R1 pattern but is capped at rank3/35 and
old source/runtime pins. It cannot qualify the current full n3 cohort unchanged.

## Smallest future follow-up and limits

First consume the actual observer records with its strict decoder. Compare the
captured canonical numerator's contraction, then selected one-hot components
of changed-MB groups alongside unchanged ZERO/MT controls. Point16 is an
appropriate initial physical witness. The existing current checked-QP points
are 16,18,21,32,39,52,54,55,65,94,97,98,99; actual upcoming selection/status
records must be checked rather than assumed. Preserve every failure and the
complete modes/check history. Do not run a new generalized campaign merely to
produce the first bounded witness.

The current observer deliberately contains **no tensor outputs**. A fixed-input
dual-backend replay can adjudicate the captured tuple, not prove identity to
the original amplitude's returned tensor words. The latter would require a
separately qualified bounded output observer. Do not enlarge the current
observer unconditionally: recording all four tensor slots can substantially
inflate its journal.

Retain each reducer's independent policy. NinjaRS uses an on-shell threshold
`1e15/2**112` and auxiliary sampling scale
`max(1,abs(real invariants),abs(real M2))`. Identical numerical inputs do not
equate those policies; a discrepancy may involve cuts, threshold decisions or
conditioning as well as mass squaring. Preserve signed-zero branch lips and
propagator order. A consistent reversal must preserve the loop-momentum origin.

TIRust and NinjaRS use different tensor reductions but share oneloopmaster and
code-generation ancestry. Their agreement is not independent scalar finite
truth. Reducer-free pole controls are retained at
`docs/benchmarkfolder/experiments/rank6-rational-pole-oracle-1/` and
`docs/benchmarkfolder/experiments/rank6-rational-ir-poles-qualification-1/`.
They cover their stated exact rational synthetic fixtures, not arbitrary
physical massive finite tensors. The EW analytic amplitude pole formula in
`ew-threshold-adjudication/tensor-replay/analytic-poles/` is process-specific
and cannot be reused as a QCD n3 formula without a separate derivation.

Keep absolute and complex symmetric residuals, especially near zero; use the
existing benchmark scientific criterion rather than invent a relaxed floor.
A 1e-8 output comparison may be insensitive to an approximately 1e-15 mass-square
change, so the exact input-word/square oracle remains separate evidence.
Standalone fixed-input or unchecked mode120 results cannot replace MadLoop's
independent checked stability/rescue qualification, prove a physical finite
term, establish a 256-bit output accuracy, qualify generic CMS/dynamic masses,
or support performance acceptance. No such result is claimed here.
