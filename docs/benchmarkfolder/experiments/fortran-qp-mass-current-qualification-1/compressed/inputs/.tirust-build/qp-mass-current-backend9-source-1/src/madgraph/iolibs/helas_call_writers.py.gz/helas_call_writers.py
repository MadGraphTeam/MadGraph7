################################################################################
#
# Copyright (c) 2010 The MadGraph7 Development team and Contributors
#
# This file is a part of the MadGraph7 project, an application which 
# automatically generates Feynman diagrams and matrix elements for arbitrary
# high-energy processes in the Standard Model and beyond.
#
# It is subject to the MadGraph7 license which should accompany this 
# distribution.
#
# For more information, visit madgraph.phys.ucl.ac.be and amcatnlo.web.cern.ch
#
################################################################################
"""Classes for writing Helas calls. HelasCallWriter is the base class."""
from __future__ import absolute_import
import re
import madgraph
import madgraph.core.base_objects as base_objects
import madgraph.core.helas_objects as helas_objects
import madgraph.loop.loop_helas_objects as loop_helas_objects
import madgraph.models.check_param_card as check_param_card
import aloha.aloha_writers as aloha_writers
import aloha
from madgraph import MadGraph5Error
import madgraph.various.misc as misc
import logging

logger = logging.getLogger('madgraph.helas_call_writers')
if madgraph.ordering:
    set	= misc.OrderedSet

class HelasWriterError(Exception):
    """Class for the error of this module """
    pass


#===============================================================================
# Axial-gauge reference vectors
#===============================================================================
def axial_gauge_requested(output_options):
    """Whether --axial_gauge=True was given on the output line.

    The FD gauge has its own five-component vxxxxx and no vxxxxxr, so the
    option is dropped there (with a warning)."""

    value = (output_options or {}).get('axial_gauge', False)
    if isinstance(value, str):
        value = value.strip().lower() in ('true', 't', '1', 'yes', 'on')
    if not value:
        return False
    if aloha.unitary_gauge == 3:
        if not axial_gauge_requested.warned:
            logger.warning('axial_gauge is not available in the FD gauge: '
                           'the option is ignored.')
            axial_gauge_requested.warned = True
        return False
    return True
axial_gauge_requested.warned = False


def get_axial_gauge_refs(matrix_element):
    """Pick the axial-gauge reference leg of every massless external vector.

    VXXXXX builds its polarisation in the gauge n = (1,0,0,0). Choosing
    instead a lightlike r taken from another external leg gives eps.r = 0,
    and -- when several legs share the same r -- eps_i.eps_j = 0 for every
    same-chirality pair, which makes whole currents and amplitudes vanish
    (arXiv:2312.07447). One reference is therefore shared by all the vectors
    of a gauge group; the reference leg uses the next candidate so that r is
    never its own momentum.

    The choice is made here, once, and is the same for every helicity
    configuration: an external wavefunction still depends only on its own leg
    and its own helicity, so helicity recycling is unaffected. The zeros
    themselves are helicity dependent and are picked up at run time by the
    existing hel_zeroamp scan.

    The reference has to be a leg the vector couples to: a zero needs r to
    meet eps in a vertex, either as the momentum of a fermion line the vector
    is attached to or as another vector sharing r. So a gluon takes a
    coloured leg and a photon a charged one; with e+ e- > u u~ g g a beam
    reference gives no zero at all, the u quark 72 of the 256 (helicity,
    diagram) pairs of the 16 good helicities.  Among those, an
    initial-state leg is preferred as the safest numerically: vxxxxxr divides
    by r.p, which for r on the beam is E * pT * exp(-y) of the gauged leg and
    so is kept away from zero by the usual pT and rapidity cuts (a final-state
    r relies on the separation cuts instead).
    """

    externals = {}
    for wf in matrix_element.get_all_wavefunctions():
        if not wf.get('mothers'):
            externals[wf.get('number_external')] = wf
    if not externals:
        return {}

    massless = [i for i in sorted(externals)
                if externals[i].get('mass').lower() == 'zero']
    vectors = [i for i in massless if externals[i].get('spin') == 3]
    # A single massless leg cannot serve as the reference of itself.
    if not vectors or len(massless) < 2:
        return {}

    def couples_to(vector):
        part = externals[vector]['particle']
        if part.get('color') != 1:
            return lambda i: externals[i]['particle'].get('color') != 1
        if part.get('charge') == 0:
            return lambda i: externals[i]['particle'].get('charge') != 0
        return lambda i: True

    refs = {}
    for vector in vectors:
        candidates = [i for i in massless if couples_to(vector)(i)]
        if len(candidates) < 2:
            candidates = massless
        order = [i for i in candidates
                 if externals[i].get('state') == 'initial']
        order += [i for i in candidates if i not in order]
        refs[vector] = order[1] if vector == order[0] else order[0]
    return refs


#===============================================================================
# HelasCallWriter
#===============================================================================
class HelasCallWriter(base_objects.PhysicsObject):
    """Language independent base class for writing Helas calls. The
    calls are stored in two dictionaries, wavefunctions and
    amplitudes, with entries being a mapping from a set of spin,
    incoming/outgoing states and Lorentz structure to a function which
    writes the corresponding wavefunction/amplitude call (taking a
    HelasWavefunction/HelasAmplitude as argument)."""

    # Dictionaries used for automatic generation of Helas calls
    # Dictionaries from spin states to letters in Helas call
    mother_dict = {1: 'S', 2: 'O', -2: 'I', 3: 'V', 5: 'T', 4:'OR', -4:'IR',
                   99:'P'}
    
    # |pdg| of the particles whose propagators are written with a zero width
    # (see get_wavefunction_call). Set for one matrix element at a time by the
    # exporter (output standalone --zerowidth_decay=).
    zerowidth_pdgs = frozenset()

    @staticmethod
    def customize_argument_for_all_other_helas_object(call, arg):
        """ Place holder for PLUGIN/...
            (used by madevent output for small width handling) 
        """
        return call, arg
        
    @staticmethod
    def default_customize_argument_for_all_other_helas_object(call,arg):
        return call,arg  
    #customize_argument_for_all_other_helas_object = fct_customize_argument_for_all_other_helas_object
    #default_customize_argument_for_all_other_helas_object = fct_customize_argument_for_all_other_helas_object

    def default_setup(self):

        self['model'] = base_objects.Model()
        self['wavefunctions'] = {}
        self['amplitudes'] = {}
        self.width_tchannel_set_tozero = False
        # Axial-gauge reference vectors for external vector wavefunctions.
        # axial_gauge switches the routine name (and hence the cached call
        # templates), so it has to be set once for a whole export;
        # axial_gauge_refs maps external leg -> reference leg and is set per
        # matrix element.
        self.axial_gauge = False
        self.axial_gauge_refs = {}

    def has_axial_gauge_ref(self, wf):
        """Whether this external is written as vxxxxxr: a vector that got a
        reference leg (a massless one, see get_axial_gauge_refs). Any other
        external -- a massive vector in particular -- keeps vxxxxx."""

        return self.axial_gauge and \
               wf.get('number_external') in self.axial_gauge_refs

    def get_axial_gauge_ref(self, wf):
        """Reference leg used for the gauge of this external vector."""

        return self.axial_gauge_refs[wf.get('number_external')]

    def filter(self, name, value):
        """Filter for model property values"""

        if name == 'model':
            if not isinstance(value, base_objects.Model):
                raise self.PhysicsObjectError("Object of type %s is not a model" % type(value))

        if name == 'wavefunctions':
            # Should be a dictionary of functions returning strings, 
            # with keys (spins, flow state)
            if not isinstance(value, dict):
                raise self.PhysicsObjectError("%s is not a valid dictionary for wavefunction" % \
                                                                str(value))

            for key in value.keys():
                self.add_wavefunction(key, value[key])

        if name == 'amplitudes':
            # Should be a dictionary of functions returning strings, 
            # with keys (spins, flow state)
            if not isinstance(value, dict):
                raise self.PhysicsObjectError("%s is not a valid dictionary for amplitude" % \
                                                                str(value))

            for key in value.keys():
                self.add_amplitude(key, value[key])

        return True

    def get_sorted_keys(self):
        """Return process property names as a nicely sorted list."""

        return ['model', 'wavefunctions', 'amplitudes']



    
     

    def get_loop_amp_helas_calls(self, matrix_element):
        """Return a list of strings, corresponding to the Helas calls
        for building loop amplitudes (AMPL) only."""

        assert isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement), \
                  "%s not valid argument for get_loop_amp_helas_calls" % \
                  repr(matrix_element)

        res = []

        for diagram in matrix_element.get_loop_diagrams():
            res.append("# Loop amplitude for loop diagram with ID %d" % \
                       diagram.get('number'))
            for amplitude in diagram.get_loop_amplitudes():
                # Substitute the proc_prefix
                res.append(self.get_amplitude_call(amplitude))

        return res

    def get_sqso_target_skip_code(self, number_checked, sqso_target_numbers,
        continue_label, split_orders, squared_orders, comment):
        """Treat the optimization for the squared order target so that 
        unnecessary computations can be skipped. This function returns the lines
        of codes for doing so, based on the number_checked (typically amplitude number)
        to be checked and the list of squared order contributions 
        sqso_target_numbers specifying for each of them  the maximum contributing
        number. The continue_label informs where the code must 'goto' if indeed
        the rest of this part of the computation must be skipped.
        The split_orders and squared_orders values lists, as well as the string 
        comment template is just for printing out a nice comment in the fortran 
        code explaining what is going on."""
        
        res = []
        for sqso_index, target in enumerate(sqso_target_numbers):
            if target!=number_checked:
                continue
            sqso_name = ' '.join(['%s=%d'%(split_orders[i],val) for i, \
                       val in enumerate(squared_orders[sqso_index][0])])
            sqso_identifier = "(%s), i.e. of split order ID=%d,"\
                                                      %(sqso_name, sqso_index+1)
            res.append(comment%sqso_identifier)
            res.append("IF(FILTER_SO.AND.SQSO_TARGET."+\
                                 "EQ.%d) GOTO %d"%(sqso_index+1,continue_label))
        return res
        
    def get_born_ct_helas_calls(self, matrix_element, include_CT=True,
                                            squared_orders=[], split_orders=[]):
        """Return a two lists of strings, the first corresponding to the Helas
        calls for building the non-loop wavefunctions, the born and CT (only if
        include_CT=True). The second correspond to the Helas calls for the 
        UVCT amplitudes only. The squared_orders can provide the information of 
        what is the maximum contributing CT amp number."""

        assert isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement), \
                  "%s not valid argument for get_born_ct_helas_calls" % \
                  repr(matrix_element)

        res = []

        sqso_max_uvctamp = [sqso[1][0] for sqso in squared_orders]
        sqso_max_ctamp = [sqso[1][1] for sqso in squared_orders]

        for diagram in matrix_element.get_born_diagrams():
            res.extend([ self.get_wavefunction_call(wf) for \
                         wf in diagram.get('wavefunctions') ])
            res.append("# Amplitude(s) for born diagram with ID %d" % \
                       diagram.get('number'))
            for amplitude in diagram.get('amplitudes'):
                res.append(self.get_amplitude_call(amplitude))
                
        for diagram in matrix_element.get_loop_diagrams():
            res.extend([ self.get_wavefunction_call(wf) for \
                         wf in diagram.get('wavefunctions') ])
            if diagram.get_ct_amplitudes() and include_CT:
                res.append("# Counter-term amplitude(s) for loop diagram number %d" % \
                                                          diagram.get('number'))
                for ctamp in diagram.get_ct_amplitudes():
                    res.append(self.get_amplitude_call(ctamp))
                    res.extend(self.get_sqso_target_skip_code(ctamp.get('number'), 
                      sqso_max_ctamp, 2000, split_orders, squared_orders,
                      "# At this point, all CT amps needed for %s are computed."))
        
        if not include_CT:
            return res, []
        
        res_UVCT = []
        for diagram in matrix_element.get_loop_UVCT_diagrams():
            res_UVCT.extend([ self.get_wavefunction_call(wf) for \
                         wf in diagram.get('wavefunctions') ])
            res_UVCT.append("# Amplitude(s) for UVCT diagram with ID %d" % \
                       diagram.get('number'))
            for ctamp in diagram.get('amplitudes'):
                res_UVCT.append(self.get_amplitude_call(ctamp))
                res_UVCT.extend(self.get_sqso_target_skip_code(ctamp.get('number'), 
                  sqso_max_uvctamp, 3000, split_orders, squared_orders,
                  "# At this point, all UVCT amps needed for %s are computed."))

        return res, res_UVCT

    def get_loop_matrix_element_calls(self, loop_matrix_element):
        """Return a list of strings, corresponding to the Helas calls
        for the loop matrix element"""
        
        res_born_CT, res_UVCT = self.get_born_ct_helas_calls(loop_matrix_element)
        res = res_born_CT + res_UVCT + \
                              self.get_loop_amp_helas_calls(loop_matrix_element)
        return res
    

    def get_matrix_element_calls(self, matrix_element):
        """Return a list of strings, corresponding to the Helas calls
        for the matrix element"""

        assert isinstance(matrix_element, helas_objects.HelasMatrixElement), \
                  "%s not valid argument for get_matrix_element_calls" % \
                  type(matrix_element)

        # Do not reuse the wavefunctions for loop matrix elements
        if isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement):
            return self.get_loop_matrix_element_calls(matrix_element)
        
        me = matrix_element.get('diagrams')
        matrix_element.reuse_outdated_wavefunctions(me)

        # A current sum has to be written out once both currents are there.
        # Doing it as soon as the later of the two is made keeps them alive:
        # a slot is only handed on after its last use, and the cubic one is
        # still needed by the amplitude the sum is for.
        sums, uses, folded = self.get_quartic_current_sums(matrix_element)
        slots = matrix_element.get_quartic_sum_me_ids()
        after = {}
        for i, (cubic, quartic, coeff) in enumerate(sums):
            after.setdefault(max(cubic.get('number'), quartic.get('number')),
                             []).append(i)

        # The AMP array is recycled the same way, where the writer knows how
        # to. A merge is written as soon as both of its amplitudes are there,
        # which is what frees the source's entry, see get_amplitude_slots.
        amp_slots = self.get_amplitude_slots(matrix_element)
        position = [0]

        # no t-channel in a decay (is_t_channel assumes two initial particles),
        # also when the output mixes decays with 2 > n processes (--standalone)
        zerowidth_tchannel = self.options['zerowidth_tchannel']
        if matrix_element.get('processes')[0].get_ninitial() == 1:
            self.options['zerowidth_tchannel'] = False
        try:
            res = []
            written = set()
            for diagram in matrix_element.get('diagrams'):


                for wf in diagram.get('wavefunctions'):
                    res.append(self.get_wavefunction_call(wf))
                    for i in after.get(wf.get('number'), []):
                        # a wavefunction number can be listed by more than one
                        # diagram, and the sum must only be written once
                        if i in written:
                            continue
                        written.add(i)
                        cubic, quartic, coeff = sums[i]
                        res.extend(self.get_current_sum_lines(
                            slots[i], cubic, quartic, coeff))
                res.append("# Amplitude(s) for diagram number %d" % \
                           diagram.get('number'))
                for amplitude in diagram.get('amplitudes'):
                    if amplitude.get('number') in folded:
                        # summed into another amplitude through a current sum
                        continue
                    res.append(self.get_amplitude_call_on_slot(
                        amplitude, uses.get(amplitude.get('number')), slots,
                        amp_slots))
                    if amp_slots is not None:
                        res.extend(self.get_amplitude_merge_lines_at(
                            amp_slots, position[0]))
                        position[0] += 1

            if amp_slots is None:
                res.extend(self.get_amplitude_merge_lines(matrix_element))
        finally:
            self.options['zerowidth_tchannel'] = zerowidth_tchannel

        return res

    def get_amplitude_slots(self, matrix_element):
        """The recycled AMP array, or None to leave AMP indexed by amplitude
        number. Only the Fortran writer has an AMP array to recycle."""

        return None

    def get_amplitude_call_on_slot(self, amplitude, substitution, slots,
                                   amp_slots):
        """The amplitude call, written into its recycled AMP entry.

        The slot is swapped onto the amplitude's number and put straight back,
        the same way get_amplitude_call_on_sums does it for the mothers: the
        call is formatted from `out`, which is that number."""

        if amp_slots is None:
            return self.get_amplitude_call_on_sums(amplitude, substitution,
                                                   slots)
        number = amplitude.get('number')
        amplitude.set('number', amp_slots[0][number])
        try:
            return self.get_amplitude_call_on_sums(amplitude, substitution,
                                                   slots)
        finally:
            amplitude.set('number', number)

    def get_amplitude_merge_lines_at(self, amp_slots, position):
        """The merges due just after this amplitude. Fortran only."""

        return []

    def get_quartic_current_sums(self, matrix_element):
        """The current sums to write out. Only the Fortran writer knows how to
        emit one, see FortranUFOHelasCallWriter."""

        return [], {}, set()

    def get_current_sum_lines(self, number, cubic, quartic, coeff):
        """Lines building one current sum. Fortran only."""

        raise NotImplementedError

    def get_amplitude_call_on_sums(self, amplitude, substitution, slots):
        """The amplitude call, reading the current sums in place of the cubic
        currents they were built from.

        The slot is swapped on the mother itself and put back straight away,
        the same way get_loop_amplitude_helas_calls relabels its externals."""

        if not substitution:
            return self.get_amplitude_call(amplitude)

        original = []
        for mother in amplitude.get('mothers'):
            index = substitution.get(mother.get('number'))
            if index is None:
                continue
            original.append((mother, mother.get('me_id')))
            mother.set('me_id', slots[index])
        try:
            return self.get_amplitude_call(amplitude)
        finally:
            for mother, me_id in original:
                mother.set('me_id', me_id)

    def get_amplitude_merge_lines(self, matrix_element):
        """Lines summing the quartic contributions into the amplitude which
        carries the same colour factor. Only the Fortran writer implements
        this, see FortranUFOHelasCallWriter."""

        return []

    def get_wavefunction_calls(self, wavefunctions):
        """Return a list of strings, corresponding to the Helas calls
        for the matrix element"""

        assert isinstance(wavefunctions, helas_objects.HelasWavefunctionList), \
               "%s not valid argument for get_wavefunction_calls" % \
               repr(wavefunctions)

        res = [self.get_wavefunction_call(wf) for wf in wavefunctions]

        return res

    def get_amplitude_calls(self, matrix_element):
        """Return a list of strings, corresponding to the Helas calls
        for the matrix element"""
        
        assert isinstance(matrix_element, helas_objects.HelasMatrixElement), \
               "%s not valid argument for get_matrix_element_calls" % \
               repr(matrix_element)            

        res = []
        for diagram in matrix_element.get('diagrams'):
            res.append("# Amplitude(s) for diagram number %d" % \
                       diagram.get('number'))
            for amplitude in diagram.get('amplitudes'):
                res.append(self.get_amplitude_call(amplitude))

        return res

    def get_wavefunction_call(self, wavefunction):
        """Return the function for writing the wavefunction
        corresponding to the key"""

        try:
            fct =  self["wavefunctions"][wavefunction.get_call_key()]
        except KeyError as error:
            return ""
        else:
           call = fct(wavefunction) 

        
        if  self.options['zerowidth_tchannel'] and wavefunction.is_t_channel():
            call, n = re.subn(r',\s*fk_(?!ZERO)\w*\s*,', ', ZERO,', str(call), flags=re.I)
            if n:
                self.width_tchannel_set_tozero = True
        # zerowidth_pdgs: propagators of these particles (|pdg|) get a zero
        # width in this call only -- the model parameter itself is untouched.
        # Nothing to do in the complex-mass scheme, where the call carries a
        # complex mass instead of a (mass, width) pair.
        zero = self.zerowidth_pdgs
        if zero and abs(wavefunction.get('pdg_code')) in zero:
            width = str(wavefunction.get('width'))
            if width.upper() != 'ZERO':
                call = re.sub(r',\s*(fk_)?%s\s*,' % re.escape(width), ', ZERO,',
                              str(call), count=1, flags=re.I)
        return call
        

    def get_amplitude_call(self, amplitude):
        """Return the function for writing the amplitude
        corresponding to the key"""

        try:
            call = self["amplitudes"][amplitude.get_call_key()]
        except KeyError as error:
            return ""
        else:
            return call(amplitude)

    def add_wavefunction(self, key, function):
        """Set the function for writing the wavefunction
        corresponding to the key"""

        assert isinstance(key, tuple), \
                       "%s is not a valid tuple for wavefunction key" % key
        
        assert callable(function), \
                 "%s is not a valid function for wavefunction string" % function

        self.get('wavefunctions')[key] = function
        return True

    def add_amplitude(self, key, function):
        """Set the function for writing the amplitude
        corresponding to the key"""

        assert isinstance(key, tuple), \
                        "%s is not a valid tuple for amplitude key" % str(key)

        assert callable(function), \
            "%s is not a valid function for amplitude string" % str(function)
            
            
        self.get('amplitudes')[key] = function
        return True

    def get_model_name(self):
        """Return the model name"""
        return self['model'].get('name')

    # Customized constructor

    def __init__(self, argument={}, options={}):
        """Allow generating a HelasCallWriter from a Model
        """

        default_options = {'zerowidth_tchannel': True}
        
        self.options = dict(default_options)
        self.options.update(options)
        
        if isinstance(argument, base_objects.Model):
            super(HelasCallWriter, self).__init__()
            self.set('model', argument)
        else:
            super(HelasCallWriter, self).__init__(argument)
            
#===============================================================================
# FortranHelasCallWriter
#===============================================================================
class FortranHelasCallWriter(HelasCallWriter):
    """The class for writing Helas calls in Fortran, starting from
    HelasWavefunctions and HelasAmplitudes.

    Includes the function generate_helas_call, which automatically
    generates the Fortran Helas call based on the Lorentz structure of
    the interaction."""

    # Dictionaries used for automatic generation of Helas calls
    # Dictionaries from spin states to letters in Helas call
    self_dict = {1: 'H', 2: 'F', -2: 'F', 3: 'J', 5: 'U'}
    # Dictionaries used for sorting the letters in the Helas call
    sort_wf = {'O': 0, 'I': 1, 'S': 2, 'T': 3, 'V': 4}
    sort_amp = {'S': 0, 'V': 2, 'T': 1, 'O': 3, 'I': 4}

    def default_setup(self):
        """Set up special Helas calls (wavefunctions and amplitudes)
        that can not be done automatically by generate_helas_call"""

        super(FortranHelasCallWriter, self).default_setup()

        # Add special fortran Helas calls, which are not automatically
        # generated

        # Gluon 4-vertex division tensor calls ggT for the FR sm and mssm

        key = ((3, 3, 5, 3,tuple(),False), ('A',))
        call = lambda wf: \
               "CALL UVVAXX(W(%d),W(%d),%s,zero,zero,zero,W(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(wf)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[1].get('me_id'),
                wf.get('coupling')[0],
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((3, 5, 3, 1,tuple(), False), ('A',))
        call = lambda wf: \
               "CALL JVTAXX(W(%d),W(%d),%s,zero,zero,W(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(wf)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[1].get('me_id'),
                wf.get('coupling')[0],
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((3, 3, 5), ('A',))
        call = lambda amp: \
               "CALL VVTAXX(W(%d),W(%d),W(%d),%s,zero,AMP(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(amp)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[2].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)

        # SM gluon 4-vertex components

        key = ((3, 3, 3, 3, 1, tuple(), tuple(), False), ('gggg3',))
        call = lambda wf: \
               "CALL JGGGXX(W(%d),W(%d),W(%d),%s,W(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(wf)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[2].get('me_id'),
                wf.get('coupling')[0],
                wf.get('me_id'))
        self.add_wavefunction(key, call)
        key = ((3, 3, 3, 3), ('gggg1',))
        call = lambda amp: \
               "CALL GGGGXX(W(%d),W(%d),W(%d),W(%d),%s,AMP(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(amp)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[2].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)
        key = ((3, 3, 3, 3, 1, tuple(), tuple(), False), ('gggg2',))
        call = lambda wf: \
               "CALL JGGGXX(W(%d),W(%d),W(%d),%s,W(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(wf)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[2].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[1].get('me_id'),
                wf.get('coupling')[0],
                wf.get('me_id'))
        self.add_wavefunction(key, call)
        key = ((3, 3, 3, 3), ('gggg2',))
        call = lambda amp: \
               "CALL GGGGXX(W(%d),W(%d),W(%d),W(%d),%s,AMP(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(amp)[2].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)
        key = ((3, 3, 3, 3, 1, tuple(), tuple(), False), ('gggg1',))
        call = lambda wf: \
               "CALL JGGGXX(W(%d),W(%d),W(%d),%s,W(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(wf)[2].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(wf)[0].get('me_id'),
                wf.get('coupling')[0],
                wf.get('me_id'))
        self.add_wavefunction(key, call)
        key = ((3, 3, 3, 3), ('gggg3',))
        call = lambda amp: \
               "CALL GGGGXX(W(%d),W(%d),W(%d),W(%d),%s,AMP(%d))" % \
               (FortranHelasCallWriter.sorted_mothers(amp)[1].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[2].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[0].get('me_id'),
                FortranHelasCallWriter.sorted_mothers(amp)[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)

        # HEFT VVVS calls

        key = ((1, 3, 3, 3, 3,tuple(), False), ('',))
        call = lambda wf: \
               "CALL JVVSXX(W(%d),W(%d),W(%d),DUM1,%s,%s,%s,W(%d))" % \
               (wf.get('mothers')[0].get('me_id'),
                wf.get('mothers')[1].get('me_id'),
                wf.get('mothers')[2].get('me_id'),
                wf.get('coupling')[0],
                wf.get('mass'),
                wf.get('width'),
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((3, 3, 3, 1, 4,tuple(), False), ('',))
        call = lambda wf: \
               "CALL HVVVXX(W(%d),W(%d),W(%d),DUM1,%s,%s,%s,W(%d))" % \
               (wf.get('mothers')[0].get('me_id'),
                wf.get('mothers')[1].get('me_id'),
                wf.get('mothers')[2].get('me_id'),
                wf.get('coupling')[0],
                wf.get('mass'),
                wf.get('width'),
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((1, 3, 3, 3), ('',))
        call = lambda amp: \
               "CALL VVVSXX(W(%d),W(%d),W(%d),W(%d),DUM1,%s,AMP(%d))" % \
               (amp.get('mothers')[0].get('me_id'),
                amp.get('mothers')[1].get('me_id'),
                amp.get('mothers')[2].get('me_id'),
                amp.get('mothers')[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)

        # HEFT VVVS calls

        key = ((1, 3, 3, 3, 1,tuple(), False), ('',))
        call = lambda wf: \
               "CALL JVVSXX(W(%d),W(%d),W(%d),DUM1,%s,%s,%s,W(%d))" % \
               (wf.get('mothers')[0].get('me_id'),
                wf.get('mothers')[1].get('me_id'),
                wf.get('mothers')[2].get('me_id'),
                wf.get('coupling')[0],
                wf.get('mass'),
                wf.get('width'),
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((3, 3, 3, 1, 4,tuple(), False), ('',))
        call = lambda wf: \
               "CALL HVVVXX(W(%d),W(%d),W(%d),DUM1,%s,%s,%s,W(%d))" % \
               (wf.get('mothers')[0].get('me_id'),
                wf.get('mothers')[1].get('me_id'),
                wf.get('mothers')[2].get('me_id'),
                wf.get('coupling')[0],
                wf.get('mass'),
                wf.get('width'),
                wf.get('me_id'))
        self.add_wavefunction(key, call)

        key = ((1, 3, 3, 3), ('',))
        call = lambda amp: \
               "CALL VVVSXX(W(%d),W(%d),W(%d),W(%d),DUM1,%s,AMP(%d))" % \
               (amp.get('mothers')[0].get('me_id'),
                amp.get('mothers')[1].get('me_id'),
                amp.get('mothers')[2].get('me_id'),
                amp.get('mothers')[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call)

        # Spin2 Helas Routine
        key = ((-2, 2, 5), ('',))
        call = lambda amp: \
               "CALL IOTXXX(W(%d),W(%d),W(%d),%s,%s,AMP(%d))" % \
               (amp.get('mothers')[0].get('me_id'),
                amp.get('mothers')[1].get('me_id'),
                amp.get('mothers')[2].get('me_id'),
                amp.get('coupling')[0],
                amp.get('mothers')[0].get('mass'),
                amp.get('number'))
        self.add_amplitude(key, call)
        
        key = ((-2, 2, 5, 3,tuple(), False), ('',))
        call = lambda wf: \
               "CALL UIOXXX(W(%d),W(%d),%s,%s,%s,%s,W(%d))" % \
               (wf.get('mothers')[0].get('me_id'),
                wf.get('mothers')[1].get('me_id'),
                wf.get('coupling')[0],
                wf.get('mothers')[0].get('mass'),
                wf.get('mass'),
                wf.get('width'),
                wf.get('me_id'))
        self.add_wavefunction(key, call)
        
        key = ((3,3,3,5),('',))
        call = lambda amp: \
               "CALL VVVTXX(W(%d),W(%d),W(%d),W(%d),1d0,%s,AMP(%d))" % \
               (amp.get('mothers')[0].get('me_id'),
                amp.get('mothers')[1].get('me_id'),
                amp.get('mothers')[2].get('me_id'),
                amp.get('mothers')[3].get('me_id'),
                amp.get('coupling')[0],
                amp.get('number'))
        self.add_amplitude(key, call) 
 
        key = ((3,3,5),('',))
        call = lambda amp: \
               "CALL VVTXXX(W(%d),W(%d),W(%d),%s,%s,AMP(%d))" % \
               (amp.get('mothers')[0].get('me_id'),
                amp.get('mothers')[1].get('me_id'),
                amp.get('mothers')[2].get('me_id'),
                amp.get('coupling')[0],
                amp.get('mothers')[0].get('mass'),
                amp.get('number'))
        self.add_amplitude(key, call)  
        

    def get_wavefunction_call(self, wavefunction):
        """Return the function for writing the wavefunction
        corresponding to the key. If the function doesn't exist,
        generate_helas_call is called to automatically create the
        function."""

        if wavefunction.get('spin') == 1 and \
               wavefunction.get('interaction_id') != 0:
            # Special feature: For HVS vertices with the two
            # scalars different, we need extra minus sign in front
            # of coupling for one of the two scalars since the HVS
            # is asymmetric in the two scalars
            wavefunction.set_scalar_coupling_sign(self['model'])

        val = super(FortranHelasCallWriter, self).get_wavefunction_call(wavefunction)

        if val:
            return val
        
        #fallback to case without offshell/onshell distinction
        if isinstance(wavefunction, helas_objects.HelasWavefunction):
            key = wavefunction.get_call_key()

            if key[0][-1] in [None,True]:
                #misc.sprint(key)
                new_key = (key[0][:-1], key[1])
                if new_key in self['wavefunctions']:
                    return self['wavefunctions'][new_key](wavefunction)
            #else:
            #    misc.sprint(key)

        # If function not already existing, try to generate it.

        if len(wavefunction.get('mothers')) > 3:
            raise self.PhysicsObjectError("""Automatic generation of Fortran wavefunctions not
                  implemented for > 3 mothers""")

        self.generate_helas_call(wavefunction)
        return super(FortranHelasCallWriter, self).get_wavefunction_call(\
            wavefunction)

    def get_amplitude_call(self, amplitude):
        """Return the function for writing the amplitude corresponding
        to the key. If the function doesn't exist, generate_helas_call
        is called to automatically create the function."""

        val = super(FortranHelasCallWriter, self).get_amplitude_call(amplitude)

        if val:
            return val

        # If function not already existing, try to generate it.

        if len(amplitude.get('mothers')) > 4:
            raise self.PhysicsObjectError("""Automatic generation of Fortran amplitudes not
                  implemented for > 4 mothers""")

        self.generate_helas_call(amplitude)
        return super(FortranHelasCallWriter, self).get_amplitude_call(amplitude)

    def generate_helas_call(self, argument):
        """Routine for automatic generation of Fortran Helas calls
        according to just the spin structure of the interaction.

        First the call string is generated, using a dictionary to go
        from the spin state of the calling wavefunction and its
        mothers, or the mothers of the amplitude, to letters.

        Then the call function is generated, as a lambda which fills
        the call string with the information of the calling
        wavefunction or amplitude. The call has different structure,
        depending on the spin of the wavefunction and the number of
        mothers (multiplicity of the vertex). The mother
        wavefunctions, when entering the call, must be sorted in the
        correct way - this is done by the sorted_mothers routine.

        Finally the call function is stored in the relevant
        dictionary, in order to be able to reuse the function the next
        time a wavefunction with the same Lorentz structure is needed.
        """
        
        if not isinstance(argument, helas_objects.HelasWavefunction) and \
           not isinstance(argument, helas_objects.HelasAmplitude):
            raise self.PhysicsObjectError("get_helas_call must be called with wavefunction or amplitude")

        call = "CALL "

        call_function = None

        if isinstance(argument, helas_objects.HelasAmplitude) and \
           argument.get('interaction_id') == 0:
            call = "#"
            call_function = lambda amp: call
            
            self.add_amplitude(argument.get_call_key(), call_function)
            return

        if isinstance(argument, helas_objects.HelasWavefunction) and \
               not argument.get('mothers'):
            # String is just IXXXXX, OXXXXX, VXXXXX or SXXXXX
            call = call + HelasCallWriter.mother_dict[\
                argument.get_spin_state_number()]
            # Fill out with X up to 6 positions
            call = call + 'X' * (11 - len(call))
            # Axial gauge: a vector leg that got a reference is written out as
            # VXXXXXR, which takes the (lightlike) momentum of another external
            # leg as its gauge reference.  The reference is fixed at generation
            # time and is the same for every helicity configuration, so this
            # does not change what an external wavefunction depends on -- see
            # get_axial_gauge_refs.  The call templates are cached per call
            # key, which a massless and a massive vector can share, so which of
            # the two a leg gets is decided when its call is written.
            axial = self.axial_gauge and argument.get('spin') == 3
            if axial:
                axial_call = call + 'R(P(0,%d),%s,NHEL(%d),%+d,P(0,%d),W(%d))'
            call = call + "(P(0,%d),"
            if argument.get('spin') != 1:
                # For non-scalars, need mass and helicity
                call = call + "%s,NHEL(%d),"
            if argument.get('spin') == 2:
                call = call + "%+d, FLAVOR(%d),W(%d))"
            else:
                call = call + "%+d,W(%d))"
            if argument.get('spin') == 1:
                call_function = lambda wf: call % \
                                (wf.get('number_external'),
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id'))
            elif axial:
                call_function = lambda wf: axial_call % \
                                (wf.get('number_external'),
                                 wf.get('mass'),
                                 wf.get('number_external'),
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 self.get_axial_gauge_ref(wf),
                                 wf.get('me_id')) \
                                if self.has_axial_gauge_ref(wf) else call % \
                                (wf.get('number_external'),
                                 wf.get('mass'),
                                 wf.get('number_external'),
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id'))
            elif argument.is_boson():
                call_function = lambda wf: call % \
                                (wf.get('number_external'),
                                 wf.get('mass'),
                                 wf.get('number_external'),
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id'))
            else:
                call_function = lambda wf: call % \
                                (wf.get('number_external'),
                                 wf.get('mass'),
                                 wf.get('number_external'),
                                 # For fermions, need particle/antiparticle
                                 - (-1) ** wf.get_with_flow('is_part'),
                                 wf.get('number_external'),
                                 wf.get('me_id'))
        else:
            # String is FOVXXX, FIVXXX, JIOXXX etc.
            if isinstance(argument, helas_objects.HelasWavefunction):
                call = call + \
                       FortranHelasCallWriter.self_dict[\
                argument.get_spin_state_number()]

            mother_letters = FortranHelasCallWriter.sorted_letters(argument)
            # If Lorentz structure is given, by default add this
            # to call name
            lor_name = argument.get('lorentz')[0]

            # Take care of special case: WWWW or WWVV calls
            if len(lor_name) > 3 and lor_name[:2] == "WW":
                if lor_name[:4] == "WWWW":
                    mother_letters = "WWWW"[:len(mother_letters)]
                if lor_name[:4] == "WWVV":
                    mother_letters = "W3W3"[:len(mother_letters)]
                lor_name = lor_name[4:]

            call = call + mother_letters
            call = call + lor_name

            # Check if we need to append a charge conjugation flag
            if argument.needs_hermitian_conjugate():
                call = call + 'C'

            assert len(call) < 12, "Call to Helas routine %s should be maximum 6 chars" \
                      % call[5:]

            # Fill out with X up to 6 positions
            call = call + 'X' * (11 - len(call)) + '('
            # Wavefunctions
            call = call + "W(%d)," * len(argument.get('mothers'))
            # Couplings
            call = call + "%s,"


            if isinstance(argument, helas_objects.HelasWavefunction):
                # Extra dummy coupling for 4-vector vertices
                if argument.get('lorentz') == ['WWVV']:
                    # SM W3W3 vertex
                    call = call + "1D0,"
                elif argument.get('lorentz') == ['WWWW']:
                    # SM WWWW vertex
                    call = call + "0D0,"
                elif argument.get('spin') == 3 and \
                       [wf.get('spin') for wf in argument.get('mothers')] == \
                       [3, 3, 3]:
                    # All other 4-vector vertices (FR) - note that gggg
                    # has already been defined
                    call = call + "DUM0,"
                # Mass and width
                call = call + "%s,%s,"
                # New wavefunction
                call = call + "W(%d))"
            else:
                # Extra dummy coupling for 4-particle vertices
                # Need to replace later with the correct type
                if argument.get('lorentz') == ['WWVV']:
                    # SM W3W3 vertex
                    call = call + "1D0,"
                elif argument.get('lorentz') == ['WWWW']:
                    # SM WWWW vertex
                    call = call + "0D0,"
                elif [wf.get('spin') for wf in argument.get('mothers')] == \
                       [3, 3, 3, 3]:
                    # Other 4-vector vertices (FR) - note that gggg
                    # has already been defined
                    call = call + "DUM0,"
                # Amplitude
                call = call + "AMP(%d))"

            if isinstance(argument, helas_objects.HelasWavefunction):
                # Create call for wavefunction
                if len(argument.get('mothers')) == 2:
                    call_function = lambda wf: call % \
                                    (FortranHelasCallWriter.sorted_mothers(wf)[0].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(wf)[1].\
                                     get('me_id'),
                                     ','.join(wf.get_with_flow('coupling')),
                                     wf.get('mass'),
                                     wf.get('width'),
                                     wf.get('me_id'))
                else:
                    call_function = lambda wf: call % \
                                    (FortranHelasCallWriter.sorted_mothers(wf)[0].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(wf)[1].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(wf)[2].\
                                     get('me_id'),
                                     ','.join(wf.get_with_flow('coupling')),
                                     wf.get('mass'),
                                     wf.get('width'),
                                     wf.get('me_id'))
            else:
                # Create call for amplitude
                if len(argument.get('mothers')) == 3:
                    call_function = lambda amp: call % \
                                    (FortranHelasCallWriter.sorted_mothers(amp)[0].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(amp)[1].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(amp)[2].\
                                     get('me_id'),

                                     ','.join(amp.get('coupling')),
                                     amp.get('number'))
                else:
                    call_function = lambda amp: call % \
                                    (FortranHelasCallWriter.sorted_mothers(amp)[0].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(amp)[1].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(amp)[2].\
                                     get('me_id'),
                                     FortranHelasCallWriter.sorted_mothers(amp)[3].\
                                     get('me_id'),
                                     ','.join(amp.get('coupling')),
                                     amp.get('number'))

        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)

    # Static helper functions

    @staticmethod
    def sorted_letters(arg):
        """Gives a list of letters sorted according to
        the order of letters in the Fortran Helas calls"""

        if isinstance(arg, helas_objects.HelasWavefunction):
            return "".join(sorted([HelasCallWriter.mother_dict[\
            wf.get_spin_state_number()] for wf in arg.get('mothers')],
                                  key= lambda l: FortranHelasCallWriter.sort_wf[l],
                                  reverse=True))

        if isinstance(arg, helas_objects.HelasAmplitude):
            return "".join(sorted([HelasCallWriter.mother_dict[\
            wf.get_spin_state_number()] for wf in arg.get('mothers')],
                                  key= lambda l: FortranHelasCallWriter.sort_amp[l],
                                  reverse=True))

    @staticmethod
    def sorted_mothers(arg):
        """Gives a list of mother wavefunctions sorted according to
        1. The order of the particles in the interaction
        2. Cyclic reordering of particles in same spin group
        3. Fermions ordered IOIOIO... according to the pairs in
           the interaction."""

        assert isinstance(arg, (helas_objects.HelasWavefunction, helas_objects.HelasAmplitude)), \
            "%s is not a valid HelasWavefunction or HelasAmplitude" % repr(arg)

        if not arg.get('interaction_id'):
            return arg.get('mothers')
        my_pdg_code = 0
        my_spin = 0
        if isinstance(arg, helas_objects.HelasWavefunction):
            my_pdg_code = arg.get_anti_pdg_code()
            my_spin = arg.get_spin_state_number()

        sorted_mothers, my_index = arg.get('mothers').sort_by_pdg_codes(\
            arg.get('pdg_codes'), my_pdg_code)

        # If fermion, partner is the corresponding fermion flow partner
        partner = None
        if isinstance(arg, helas_objects.HelasWavefunction) and arg.is_fermion():
            # Fermion case, just pick out the fermion flow partner
            if my_index % 2 == 0:
                # partner is after arg
                partner_index = my_index
            else:
                # partner is before arg
                partner_index = my_index - 1
            partner = sorted_mothers.pop(partner_index)
            # If partner is incoming, move to before arg
            if partner.get_spin_state_number() > 0:
                my_index = partner_index
            else:
                my_index = partner_index + 1

        # Reorder fermions pairwise according to incoming/outgoing
        for i in range(0, len(sorted_mothers), 2):
            if sorted_mothers[i].is_fermion():
                # This is a fermion, order between this fermion and its brother
                if sorted_mothers[i].get_spin_state_number() > 0 and \
                   sorted_mothers[i + 1].get_spin_state_number() < 0:
                    # Switch places between outgoing and incoming
                    sorted_mothers = sorted_mothers[:i] + \
                                      [sorted_mothers[i+1], sorted_mothers[i]] + \
                                      sorted_mothers[i+2:]
                elif sorted_mothers[i].get_spin_state_number() < 0 and \
                   sorted_mothers[i + 1].get_spin_state_number() > 0:
                    # This is the right order
                    pass
            else:
                # No more fermions in sorted_mothers
                break
            
        # Put back partner into sorted_mothers
        if partner:
            sorted_mothers.insert(partner_index, partner)

        same_spin_mothers = []
        if isinstance(arg, helas_objects.HelasWavefunction):
            # Pick out mothers with same spin, for cyclic reordering
            same_spin_index = -1
            i=0
            while i < len(sorted_mothers):
                if abs(sorted_mothers[i].get_spin_state_number()) == \
                       abs(my_spin):
                    if same_spin_index < 0:
                        # Remember starting index for same spin states
                        same_spin_index = i
                    same_spin_mothers.append(sorted_mothers.pop(i))
                else:
                    i += 1

        # Make cyclic reordering of mothers with same spin as this wf
        if same_spin_mothers:
            same_spin_mothers = same_spin_mothers[my_index - same_spin_index:] \
                                + same_spin_mothers[:my_index - same_spin_index]

            # Insert same_spin_mothers in sorted_mothers
            sorted_mothers = sorted_mothers[:same_spin_index] + \
                              same_spin_mothers + sorted_mothers[same_spin_index:]

        # Next sort according to spin_state_number
        return helas_objects.HelasWavefunctionList(sorted_mothers)


#===============================================================================
# UFOHelasCallWriter
#===============================================================================
class UFOHelasCallWriter(HelasCallWriter):
    """The class for writing Helas calls in Fortran, starting from
    HelasWavefunctions and HelasAmplitudes.

    Includes the function generate_helas_call, which automatically
    generates the Fortran Helas call based on the Lorentz structure of
    the interaction."""


    def get_wavefunction_call(self, wavefunction, **opt):
        """Return the function for writing the wavefunction
        corresponding to the key. If the function doesn't exist,
        generate_helas_call is called to automatically create the
        function. -UFO ROUTINE-"""
        
        # Special feature: For octet Majorana fermions, need an extra
        # minus sign in the FVI (and FSI?) wavefunction in UFO
        # models. For MG4 models, this is taken care of by calling
        # different routines (in import_v4.py)
        wavefunction.set_octet_majorana_coupling_sign()

        val = super(UFOHelasCallWriter, self).get_wavefunction_call(wavefunction)
        if val:
            return val

        # If function not already existing, try to generate it.
        self.generate_helas_call(wavefunction, **opt)
        return super(UFOHelasCallWriter, self).get_wavefunction_call(\
            wavefunction)

    def get_amplitude_call(self, amplitude):
        """Return the function for writing the amplitude corresponding
        to the key. If the function doesn't exist, generate_helas_call
        is called to automatically create the function."""

        val = super(UFOHelasCallWriter, self).get_amplitude_call(amplitude)
        if val:
            return val
        
        # If function not already existing, try to generate it.
        self.generate_helas_call(amplitude)
        return super(UFOHelasCallWriter, self).get_amplitude_call(amplitude)

    # Helper function
    def write_factor(self, factor):
        """Create a suitable string for the factor of the form
        (fraction, is_imaginary?)."""
        imag_dict = {True: "IMAG1", False: "ONE"}
        return str(factor[0]*factor[1]) + "*" + imag_dict[factor[2]]

#===============================================================================
# FortranUFOHelasCallWriter
#===============================================================================
class FortranUFOHelasCallWriter(UFOHelasCallWriter):
    """The class for writing Helas calls in Fortran, starting from
    HelasWavefunctions and HelasAmplitudes.

    Includes the function generate_helas_call, which automatically
    generates the Fortran Helas call based on the Lorentz structure of
    the interaction."""

    mp_prefix = check_param_card.ParamCard.mp_prefix

    def get_amplitude_merge_lines(self, matrix_element):
        """Sum every quartic contribution into the amplitude carrying the
        same colour factor.

        The two share a colour factor up to a rational coefficient, so adding
        them here lets the JAMPs run over the cubic diagrams only, which is
        what the JAMP optimiser then has to work with. The amplitudes summed
        away are dropped from the colour amplitudes by
        HelasMatrixElement.get_color_amplitudes."""

        merges = matrix_element.get_quartic_amplitude_merges()
        if not merges:
            return []
        # these were never computed: their current was summed instead
        folded = self.get_quartic_current_sums(matrix_element)[2]

        res = ['# Sum the quartic contributions into their cubic partner']
        for source in sorted(merges):
            if source in folded:
                continue
            target, coeff = merges[source]
            if coeff == 1:
                res.append('AMP(%d) = AMP(%d) + AMP(%d)' %
                           (target, target, source))
            elif coeff == -1:
                res.append('AMP(%d) = AMP(%d) - AMP(%d)' %
                           (target, target, source))
            else:
                res.append('AMP(%d) = AMP(%d) + (%.15e)*AMP(%d)' %
                           (target, target, float(coeff), source))
        return res

    def get_amplitude_slots(self, matrix_element):
        """The recycled AMP array, see
        HelasMatrixElement.get_amplitude_slots."""

        if not matrix_element.get_quartic_amplitude_merges():
            return None
        return matrix_element.get_amplitude_slots()

    def get_amplitude_merge_lines_at(self, amp_slots, position):
        """The merges whose two amplitudes are both there as of this
        position, written into the slots they were given."""

        slots, nslots, folds_at = amp_slots
        res = []
        for target, source, coeff in folds_at.get(position, []):
            args = (slots[target], slots[target], slots[source])
            if coeff == 1:
                res.append('AMP(%d) = AMP(%d) + AMP(%d)' % args)
            elif coeff == -1:
                res.append('AMP(%d) = AMP(%d) - AMP(%d)' % args)
            else:
                res.append('AMP(%d) = AMP(%d) + (%.15e)*AMP(%d)' %
                           (slots[target], slots[target], float(coeff),
                            slots[source]))
        return res

    def get_quartic_current_sums(self, matrix_element):
        """The current sums, see HelasMatrixElement.get_quartic_current_sums"""

        return matrix_element.get_quartic_current_sums()

    def get_current_sum_lines(self, number, cubic, quartic, coeff):
        """Sum the quartic current into the cubic one carrying the same colour
        factor, so that the amplitude reading the sum gets both at once.

        Written as a call rather than as two assignments so that everything
        reading these files -- the helicity recycling in particular, which
        rebuilds the DAG from the calls alone -- sees an ordinary internal
        wavefunction taking two mothers. sumw_1 and subw_1 live in
        aloha_functions.f; the coefficient is always +-1, see
        HelasMatrixElement.compute_quartic_current_sums."""

        return ['CALL %s(%s,%s,%s)' % (
            'SUMW_1' if coeff == 1 else 'SUBW_1',
            self.format_helas_object('W(', '%d') % cubic.get('me_id'),
            self.format_helas_object('W(', '%d') % quartic.get('me_id'),
            self.format_helas_object('W(', '%d') % number)]

    def __init__(self, argument={}, hel_sum = False, options={}):
        """Allow generating a HelasCallWriter from a Model.The hel_sum argument
        specifies if amplitude and wavefunctions must be stored specifying the
        helicity, i.e. W(i) vs W(i,H).
        """
        self.hel_sum = hel_sum
        # Flavor-mask emission state. The exporter sets these around its call
        # to get_matrix_element_calls when the optimization is active. When
        # use_flavor_mask is True and an object carries a non-trivial
        # 'flavor_mask' key, the emitted CALL is prefixed with an IAND guard
        # checking an index bit against CURRENT_{WF,AMP}_MASK selected for the
        # runtime FLAVOR(NEXTERNAL) entry.
        self.use_flavor_mask = False
        self.me_n_flavors = 0
        self.me_active_flavor_mask = None
        super(FortranUFOHelasCallWriter, self).__init__(argument, options=options)

    def format_helas_object(self, prefix, number):
        """ Returns the string for accessing the wavefunction with number in
        argument. Typical output is {prefix}(1,{number}) """

        if self.hel_sum:
            return '%s%s,H)'%(prefix, number)
        else:
            return '%s%s)'%(prefix, number)

    def _flavor_mask_prefix(self, obj, kind):
        """Return an 'IF (IAND(...)) ' prefix for a CALL line, or '' if the
        guard is not needed (feature disabled, no mask on object, or mask is
        all-ones for this ME). kind is 'wf' or 'amp'."""

        if not self.use_flavor_mask or self.me_n_flavors <= 0:
            return ''
        if 'flavor_mask' not in obj:
            return ''
        mask = obj['flavor_mask']
        all_ones = (1 << self.me_n_flavors) - 1
        active_mask = getattr(self, 'me_active_flavor_mask', None)
        if active_mask is None:
            active_mask = all_ones
        if mask == active_mask:
            return ''
        idx = obj.get('number')
        array = 'CURRENT_WF_MASK' if kind == 'wf' else 'CURRENT_AMP_MASK'
        if kind == 'wf' and 'guard_amp_number' in obj:
            idx = obj.get('guard_amp_number')
            array = 'CURRENT_AMP_MASK'
        if not isinstance(idx, int) or idx <= 0:
            return ''
        word = (idx - 1) // 64 + 1
        bit = (idx - 1) % 64
        return 'IF (IAND(%s(%d), ISHFT(1_8, %d)) .NE. 0) ' % (array, word, bit)

    def get_wavefunction_call(self, wavefunction, **opt):
        call = super(FortranUFOHelasCallWriter, self).get_wavefunction_call(
                                                            wavefunction, **opt)
        if not call:
            return call
        prefix = self._flavor_mask_prefix(wavefunction, 'wf')
        return prefix + call if prefix else call

    def get_amplitude_call(self, amplitude,**opts):
        """ We overwrite this function here because we must call
        set_octet_majorana_coupling_sign for all wavefunction taking part in
        this loopHelasAmplitude. This is not necessary in the optimized mode"""

        # Special feature: For octet Majorana fermions, need an extra
        # minus sign in the FVI (and FSI?) wavefunction in UFO
        # models.
        if isinstance(amplitude,loop_helas_objects.LoopHelasAmplitude):
            for lwf in amplitude.get('wavefunctions'):
                lwf.set_octet_majorana_coupling_sign()
            amplitude.set('coupling',amplitude.get_couplings())

        call = super(FortranUFOHelasCallWriter, self).get_amplitude_call(
                                                               amplitude,**opts)
        if not call:
            return call
        prefix = self._flavor_mask_prefix(amplitude, 'amp')
        return prefix + call if prefix else call
        


    def generate_loop_amplitude_call(self, loopamp):
        """ Routine for automatic generation of a call to CutTools for loop
        amplitudes."""

        call = "LOOP%(numLoopLines)s"
        if (len(loopamp.get('pairing')) != len(loopamp.get('mothers'))):
            call += "%(numMotherWfs)s%(numCouplings)s(%(numeratorNumber)d,"
            for i in range(len(loopamp.get('pairing'))):
                call = call + "%(Pairing{0})d,".format(i)
        else:
            call += "%(numCouplings)s(%(numeratorNumber)d,"            
        for i in range(len(loopamp.get('mothers'))):
            call = call + "%(MotherID{0})d,".format(i+1)
        for i in range(len(loopamp.get('wavefunctions'))-2):
            call = call + \
            "DCMPLX(%(LoopMass{0})s),CMPLX({1}%(LoopMass{0})s,KIND=16),"\
                                                     .format(i+1,self.mp_prefix)
        for i in range(len(loopamp.get('coupling'))):
            call = call + \
                   "%(LoopCoupling{0})s,%(MPLoopCoupling{0})s,".format(i+1)
        call = call + "%(LoopRank)d,"
        call = call + "%(LoopSymmetryFactor)d,%(LoopMultiplier)d,"
        call = call + "%(ampNumber)d,AMPL(1,%(ampNumber)d),S(%(ampNumber)d))"
        
        def create_loop_amp(amplitude):
            helas_dict = amplitude.get_helas_call_dict()
            # Make sure the potential minus sign on coupling appears at the
            # right place when specifying the mp_coupling. It must be
            # -MP__GC10 and not MP__-GC10
            for i in range(len(loopamp.get('coupling'))):
                coupl = helas_dict['LoopCoupling%i'%(i+1)] 
                helas_dict['MPLoopCoupling%i'%(i+1)]= \
                   '-%s%s'%(self.mp_prefix,coupl[1:]) if coupl.startswith('-') \
                                              else '%s%s'%(self.mp_prefix,coupl)
            # We add here the placeholder for the proc_prefix
            return 'CALL %(proc_prefix)s'+call%helas_dict

        self.add_amplitude(loopamp.get_call_key(), create_loop_amp)
        return

    def generate_helas_call(self, argument, startingExternalWFNumber=0):
        """Routine for automatic generation of Fortran Helas calls
        according to just the spin structure of the interaction.
        """

        if not isinstance(argument, helas_objects.HelasWavefunction) and \
           not isinstance(argument, helas_objects.HelasAmplitude):
            raise self.PhysicsObjectError("generate_helas_call must be called with wavefunction or amplitude")
        
        call = "CALL "

        call_function = None

        if isinstance(argument, helas_objects.HelasAmplitude) and \
           not isinstance(argument, loop_helas_objects.LoopHelasAmplitude) and \
           argument.get('interaction_id') == 0:
            call = "#"
            call_function = lambda amp: call
            self.add_amplitude(argument.get_call_key(), call_function)
            return

        if isinstance(argument, helas_objects.HelasWavefunction) and \
               not argument.get('mothers'):
            self.generate_external_wavefunction(argument)
            return
                  
        if isinstance(argument,loop_helas_objects.LoopHelasAmplitude):
            self.generate_loop_amplitude_call(argument)
            return
            
        self.generate_all_other_helas_objects(argument)

    def generate_external_wavefunction(self,argument):
        """ Generate an external wavefunction """

        call="CALL "
        call_function = None
        axial = False
        if argument.get('is_loop'):
            call=call+"LCUT_%(conjugate)s%(lcutspinletter)s(Q(0),I,WL(%(number)d))"
        else:
            # String is just IXXXXX, OXXXXX, VXXXXX or SXXXXX
            call = call + HelasCallWriter.mother_dict[\
                argument.get_spin_state_number()]
            # Fill out with X up to 6 positions
            call = call + 'X' * (11 - len(call))
            # Axial gauge: a vector leg that got a reference is written out as
            # VXXXXXR, which takes the (lightlike) momentum of another external
            # leg as its gauge reference. The reference is fixed at generation
            # time and is the same for every helicity configuration, so this
            # does not change what an external wavefunction depends on -- see
            # get_axial_gauge_refs. The call templates are cached per call key,
            # which a massless and a massive vector can share, so which of the
            # two a leg gets is decided when its call is written.
            axial = self.axial_gauge and argument.get('spin') == 3
            call = call + "(P(0,%(number_external)d),"
            if argument.get('spin') != 1:
                # For non-scalars, need mass and helicity
                if argument.get('offshell'):
                    call = call + "SQRT(P(0,%(number_external)d)**2-P(1,%(number_external)d)**2-P(2,%(number_external)d)**2-P(3,%(number_external)d)**2),"
                else:
                    call = call + "%(mass)s,"
                call = call + "NHEL(%(number_external)d),"
            if argument.get('spin') == 2:
                call = call + "%(state_id)+d, FLAVOR(%(number_external)d),{0})".format(\
                                    self.format_helas_object('W(','%(me_id)d'))
            else:
                if axial:
                    axial_call = call.replace('XXXXX(', 'XXXXXR(', 1) + \
                        "%(state_id)+d,P(0,%(axial_ref)d),{0})".format(\
                                    self.format_helas_object('W(','%(me_id)d'))
                call = call + "%(state_id)+d,{0})".format(\
                                    self.format_helas_object('W(','%(me_id)d'))

        if axial:
            call_function = lambda wf: axial_call % dict(
                wf.get_external_helas_call_dict(),
                axial_ref=self.get_axial_gauge_ref(wf)) \
                if self.has_axial_gauge_ref(wf) else \
                call % wf.get_external_helas_call_dict()
        else:
            call_function = lambda wf: call % wf.get_external_helas_call_dict()
        self.add_wavefunction(argument.get_call_key(), call_function)

    def generate_all_other_helas_objects(self,argument):
        """ Generate all the helas objects for which no special handlers was
        placed in generate_helas_call """
        
                
        if isinstance(argument, helas_objects.HelasWavefunction):
            outgoing = argument.find_outgoing_number()
        else:
            outgoing = 0



        # Check if we need to append a charge conjugation flag
        l = [str(l) for l in argument.get('lorentz')]
        flag = []
        if argument.needs_hermitian_conjugate():
            flag = ['C%d' % i for i in \
                                  argument.get_conjugate_index()]
        if (isinstance(argument, helas_objects.HelasWavefunction) and \
           argument.get('is_loop') or \
           (isinstance(argument, helas_objects.HelasAmplitude) and \
           argument.get('type')=='loop')):
            flag.insert(0,"L")

        if isinstance(argument, helas_objects.HelasWavefunction) and argument.get('onshell') is False:
            flag.append('P1D') # D is for $ syntax -> offshell propagator only
        # Creating line formatting:
        call = 'CALL %(routine_name)s(%(wf)s%(coup)s%(mass)s%(extra)s%(out)s)'

        arg = {'routine_name': aloha_writers.combine_name(\
                                        '%s' % l[0], l[1:], outgoing, flag, True),
               'coup': ("%%(coup%d)s," * len(argument.get('coupling'))) % \
                                     tuple(range(len(argument.get('coupling'))))                                            
               }

        # select how to write a single wf
        if (isinstance(argument,helas_objects.HelasWavefunction) \
                 and argument.get('is_loop')) or \
                 ((isinstance(argument,helas_objects.HelasAmplitude) \
                 and argument['type']=='loop')):
            base_wf = "W%(WF{0})s,"
        else:
            base_wf = self.format_helas_object('W(','%({0})d')+','
        
        # compute the full list of wf
        wf = ''
        for i in range(len(argument.get('mothers'))):
            wf += base_wf.format(i)
        arg['wf'] = wf

                
        # Treat other argument
        # First WaveFunction    
        if isinstance(argument, helas_objects.HelasWavefunction):
            if argument['is_loop']:
                arg['out'] = 'WL(%(out)d)'
                if aloha.complex_mass:
                    arg['mass'] = "ML(%(out)d),"
                else:
                    arg['mass'] = "ML(%(out)d),ZERO,"
            else:
                arg['out']=self.format_helas_object('W(','%(out)d')                   
                if aloha.complex_mass:
                    arg['mass'] = "DCMPLX(%(CM)s),"
                else:
                    arg['mass'] = "%(M)s,%(W)s,"
        # Standard Amplitude
        elif argument['type'] == 'base':      
            arg['mass'] = ''  
            arg['out'] = self.format_helas_object('AMP(','%(out)d')              
        # Loop Amplitude
        elif argument['type'] == 'loop':
            arg['mass'] = ''
            arg['out'] = 'BUFF(I)'
        # UV Counterterm (and other)
        else:
            arg['mass'] = ''
            ampl = "AMPL({0},%(out)d)".format(argument.get_epsilon_order()+1)
            arg['out'] = '%s' % ampl
            if isinstance(argument,loop_helas_objects.LoopHelasUVCTAmplitude)\
                   and argument.get_UVCT_couplings()!='1.0d0':
                 # add a second line to take into account the multiplicative factor                 
                 call += "\n %(second_line)s "
                 arg['second_line'] = ampl+"="+ampl+"*(%(uvct)s)"           
        arg['extra'] = '%(bwcutoff)s'

        # ALL ARGUMENT FORMATTED ###############################################
        call, arg = HelasCallWriter.customize_argument_for_all_other_helas_object(call, arg)
        # Store the result.
        call = call % arg
        # Now we have a line correctly formatted
        call_function = lambda wf: call % wf.get_helas_call_dict(\
          OptimizedOutput=False, specifyHel=self.hel_sum)
        
        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)



    def get_loop_amplitude_helas_calls(self, loop_matrix_element):
        """ Returns a list of strings corresponding to the Helas calls for each 
        loop amplitude of this loop matrix element. This function is placed in
        this class and not in HelasWriter, because it contains fortran-specific
        code."""        
        
        res = []
        loopHelasAmpNumberTreated=[]
        for ldiag in loop_matrix_element.get_loop_diagrams():
            for lamp in ldiag.get_loop_amplitudes():
                if lamp.get('number') in loopHelasAmpNumberTreated:
                    continue
                else:
                    loopHelasAmpNumberTreated.append(lamp.get('number'))
                lcutpart=self['model'].get_particle(lamp['type'])
                res.append("ELSEIF (ID.EQ.%d) THEN"%lamp.get('number'))
                res.append("#Loop diagram number %d (might be others, just an example)"\
                                                           %ldiag.get('number'))                
                if lcutpart.get('spin')==1:
                    res.append("DO I=1,1")
                elif lcutpart.get('spin')==2 or lcutpart.get('spin')==3:
                    res.append("DO I=1,4")
                else:
                    raise self.PhysicsObjectError("The L-cut particle type is not supported")
                # Temporarily relabel the 'me_id' attribute of the external wfs
                # in this wavefunction's mothers so to have them matching the
                # convention in the loop helas calls.
                # The same relabeling is performed for couplings.
                # We save the original values to reset them afterwards.
                externalWfNumber=1
                originalNumbers=[]
                couplingNumber=1
                originalCouplings=[]
                for lwf in lamp.get('wavefunctions'):
                    if lwf.get('coupling')!=['none']:
                        originalCouplings.append(lwf.get('coupling'))
                        couplings=[]
                        for coup in lwf.get('coupling'):
                            couplings.append("LC(%d)"%couplingNumber)
                            couplingNumber=couplingNumber+1 
                        lwf.set('coupling',couplings)
                    for mother in lwf.get('mothers'):
                        if not mother.get('is_loop'):
                            originalNumbers.append(mother.get('number'))
                            mother.set('me_id',externalWfNumber)
                            externalWfNumber=externalWfNumber+1
                # Now we can generate the call for the starting loop wavefunction
                res.append(self.get_wavefunction_call(\
                                         lamp.get_starting_loop_wavefunction()))
                # And now for all the other wavefunctions
                res.extend([ self.get_wavefunction_call(wf) for \
                          wf in lamp.get('wavefunctions') if wf.get('mothers')])

                # Get the last wf generated and the corresponding loop
                # wavefunction number
                for lwf in lamp.get('amplitudes')[0].get('mothers'):
                    if lwf.get('mothers'):
                        last_lwf_number=lwf.get('number')
                        break
                # WL is now a 1-D TYPE(ALOHA) array of loop wavefunctions;
                # close the loop by reading the Lorentz components of the
                # last one.
                res.append('BUFF(I)=WL(%d)%%W(I)'%last_lwf_number)
                # And re-establish the original numbering
                indexMothers=0
                indexWfs=0
                for lwf in lamp.get('wavefunctions'):
                    if lwf.get('coupling')!=['none']:
                        lwf.set('coupling',originalCouplings[indexWfs])
                        indexWfs=indexWfs+1
                    for mother in lwf.get('mothers'):
                        if not mother.get('is_loop'):
                            mother.set('me_id',originalNumbers[indexMothers])
                            indexMothers=indexMothers+1 
                res.append('ENDDO')
                if lcutpart.get('spin')==1:
                    res.append("CALL CLOSE_1(BUFF(1),RES)")
                elif lcutpart.get('spin')==2 or lcutpart.get('spin')==3:
                    res.append("CALL CLOSE_4(BUFF(1),RES)")
        # We must change the first 'ELSE IF' into an 'IF'
        res[0]=res[0][4:]
        # And add an ENDIF at the end
        res.append('ENDIF')
        
        return res

#===============================================================================
# FortranUFOHelasCallWriterOptimized
#===============================================================================
class FortranUFOHelasCallWriterOptimized(FortranUFOHelasCallWriter):
    """ Version of FortranUFOHelasCallWriter meeting the needs of the optimized
    output for loop processes """

    def get_amplitude_call(self, *args, **opts):
        """ We overwrite this function here because in the optimized mode one
        does not need to call the function set_octet_majorana_coupling_sign
        for the wavefunctions of the loop amplitudes. So we directly call
        the mother of the mother, namely UFOHelasCallWriter. """
        
        return super(FortranUFOHelasCallWriter, self).get_amplitude_call(
                                                                   *args,**opts)

    def format_helas_object(self, prefix, number):
        """ Returns the string for accessing the wavefunction with number in
        argument. Typical output is {prefix}(1,{number}) """
        
        if self.hel_sum:
            return '%s%s,H)'%(prefix, number)
        else:
            return '%s%s)'%(prefix, number)

    @staticmethod
    def get_terminal_wavefunctions(matrix_element):
        """Prove private diagonal-only roots in the complete optimized graph.

        Unknown graph members or aliases disable the optimization. The emitted
        calls and their generated COMMON consumers are checked separately.
        """
        try:
            producers, consumed, roots = {}, set(), set()
            for diagram in matrix_element.get_loop_diagrams():
                for wf in diagram.get('loop_wavefunctions'):
                    number = wf.get('number')
                    mother = wf.get_loop_mother()
                    if (number <= 0 or number != wf.get('me_id') or
                            number in producers or not wf.get('is_loop') or
                            mother is None):
                        return {}
                    origin = mother.get('number')
                    if (origin != mother.get('me_id') or origin == number or
                            (origin not in producers and origin not in (-1, 0))):
                        return {}
                    info = wf.get_helas_call_dict(OptimizedOutput=True)
                    required = ('loop_mother_number', 'loop_mother_rank',
                                'vertex_rank', 'lcut_size', 'in_size', 'out_size', 'out')
                    if any(key not in info for key in required):
                        return {}
                    if info['out'] != number or info['loop_mother_number'] != origin:
                        return {}
                    producers[number] = {key: info[key] for key in required}
                    consumed.add(origin)
                for amplitude in diagram.get_loop_amplitudes():
                    root = amplitude.get_final_loop_wavefunction()
                    if (root.get('number') != root.get('me_id') or
                            root.get('number') not in producers):
                        return {}
                    roots.add(root.get('number'))
            for wf in matrix_element.get_all_wavefunctions():
                if not wf.get('is_loop') and any(m.get('is_loop') for m in wf.get('mothers')):
                    return {}
            result = {}
            for number in roots - consumed:
                info = producers[number]
                left, right = info['loop_mother_rank'], info['vertex_rank']
                # The measured compact path is vertex-first. Other effective
                # theory kernels retain the full updater.
                if (min(left, right) < 0 or
                        (left < right and left != 0 and right != 0) or
                        not 0 < info['lcut_size'] <= info['out_size'] <= 16 or
                        not 0 < info['in_size'] <= 16):
                    continue
                result[number] = info
            return result
        except (KeyError, ValueError, TypeError, AttributeError, MadGraph5Error):
            return {}

    def get_coef_construction_calls(self, matrix_element, group_loops=True,
                                            squared_orders=[], split_orders=[],
                                            terminal_wavefunctions=None):
        """ Return the calls to the helas routines to construct the coefficients
        of the polynomial representation of the loop numerator (i.e. Pozzorini
        method). Group the coefficients of the loop with same denominator 
        together if group_loops is set True. The squared_orders can provide the 
        information of what is the maximum contributing loop amp number."""

        assert isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement), \
                  "%s not valid argument for get_coef_construction_calls" % \
                  repr(matrix_element)
        loop_induced = (not matrix_element.get('processes')[0].get('has_born'))
        res = []
        sqso_max_lamp = [sqso[1][2] for sqso in squared_orders]     

        # Validate all generated updater statements before redirecting any.
        # This leaves the generic cached wavefunction call functions untouched.
        terminal_calls = {}
        if terminal_wavefunctions:
            for diagram in matrix_element.get_loop_diagrams():
                for wf in diagram.get('loop_wavefunctions'):
                    number = wf.get('number')
                    if number not in terminal_wavefunctions:
                        continue
                    info = terminal_wavefunctions[number]
                    expected = ('CALL %(proc_prefix)sUPDATE_WL_{loop_mother_rank}_{vertex_rank}'
                        '(WL(1,0,1,{loop_mother_number}),{lcut_size},COEFS,'
                        '{in_size},{out_size},WL(1,0,1,{out}))').format(**info)
                    call = self.get_wavefunction_call(wf)
                    if call.splitlines().count(expected) != 1:
                        terminal_calls = {}
                        break
                    terminal_calls[number] = (expected, expected.replace(
                        'UPDATE_WL_', 'TERMINAL_WL_', 1)[:-1]+',WL_ENTRY_INEXACT)')
                else:
                    continue
                break
            if set(terminal_calls) != set(terminal_wavefunctions):
                terminal_calls = {}
        i=0
        for ldiag in matrix_element.get_loop_diagrams():
            res.append("# Coefficient construction for loop diagram with ID %d"\
                       %ldiag.get('number'))
            for lwf in ldiag.get('loop_wavefunctions'):
                    call = self.get_wavefunction_call(lwf)
                    if lwf.get('number') in terminal_calls:
                        before, after = terminal_calls[lwf.get('number')]
                        call = call.replace(before, after, 1)
                    res.append(call)
            for lamp in ldiag.get_loop_amplitudes():
                # If the loop grouping is not desired, then make sure it is 
                # turned off here. It is of course not to be included for 
                # loop-induced processes
                if (not group_loops) or loop_induced:
                    lamp.set('loop_group_id',i)
                    i=i+1
                create_coef=[
                     'CREATE_LOOP_COEFS(WL(1,0,1,%(number)d)',
                     '%(loop_rank)d','%(lcut_size)d',
                     '%(loop_number)d','%(LoopSymmetryFactor)d',
                     '%(LoopMultiplier)d']
                if not loop_induced:
                    create_coef.append('%(amp_number)d,H)')
                else:
                    create_coef.append('%(amp_number)d)')
            
                res.append('CALL %(proc_prefix)s'+','.join(create_coef)%{\
                  'number':lamp.get_final_loop_wavefunction().get('number'),
                  'loop_rank':lamp.get_analytic_info('wavefunction_rank'),
                  'lcut_size':lamp.get_lcut_size(),
        # For the loop_number below, we used the id of the 'loop_group' this 
        # amplitude belongs to. All amplitudes of such loop_group will therefore
        # be added into the same LOOPCOEF array component.
                  'loop_number':(lamp.get('loop_group_id')+1),
                  'amp_number':lamp.get('amplitudes')[0].get('number'),
                  'LoopSymmetryFactor':lamp.get('loopsymmetryfactor'),
                  'LoopMultiplier':lamp.get('multiplier')})
                res.extend(self.get_sqso_target_skip_code(
                      lamp.get('amplitudes')[0].get('number'), 
                      sqso_max_lamp, 4000, split_orders, squared_orders,
                      "# At this point, all loop coefficients needed"+
                                                       " for %s are computed."))
        
        coef_merge=['C  Grouping of loop diagrams now done directly when '+\
                                                      'creating the LOOPCOEFS.']
        
        return res, coef_merge

    def get_loop_CT_calls(self, matrix_element, group_loops=True, 
                                            squared_orders=[], split_orders=[]):
        """ Return the calls to CutTools interface routines to launch the
        computation of the contribution of one loop group. The squared_orders 
        can provide the information of the maximum reference loop group ID for
        each contributing squared loop orders."""

        assert isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement), \
                  "%s not valid argument for get_loop_CT_calls" % \
                  repr(matrix_element)
        
        res = []
        
        sqso_max_lgroup_refs = [sqso[1][3] for sqso in squared_orders]
        
        # Either call CutTools for all loop diagrams or for only the reference
        # amplitude for each group (for which the coefficients are the sum of
        # all others)
        if group_loops and matrix_element.get('processes')[0].get('has_born'):
            # Reformat the loop group list in a convenient form
            loop_group_refs=[(lamps[1][0],lamps[1][1:]) for lamps in \
                                              matrix_element.get('loop_groups')]
            for (lamp_ref, lamps) in loop_group_refs:
                res.append("# CutTools call for loop numbers %s"%\
                   ','.join(['%d'%lamp_ref.get('number'),]+\
                                   ['%d'%lamp.get('number') for lamp in lamps]))
                res.append(self.get_amplitude_call(lamp_ref))
                res.extend(self.get_sqso_target_skip_code(
                  lamp_ref.get('loop_group_id'), sqso_max_lgroup_refs, 5000, 
                  split_orders, squared_orders,
                  "# At this point, all reductions needed for %s are computed."))
        else:
            for ldiag in matrix_element.get_loop_diagrams():
                res.append("# CutTools call for loop # %d"%ldiag.get('number'))
                for lamp in ldiag.get_loop_amplitudes():
                    # Make sure the loop number is used instead of the loop
                    # group number
                    loop_group_id_tmp = lamp.get('loop_group_id')
                    lamp.set('loop_group_id',lamp.get('number')-1)
                    res.append(self.get_amplitude_call(lamp))
                    lamp.set('loop_group_id',loop_group_id_tmp)                    

        return res

    def generate_external_wavefunction(self,argument):
        """ Generate an external wavefunction """
        
        call_function = None
        if argument.get('is_loop'):
            call="LCUT_OPT(PL(0,%(number)d),WL(1,1,1,%(number)d))"
            call_function = lambda wf: "CALL %(proc_prefix)s"+ \
                                              call % {'number':wf.get('number')}
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            # For the tree external wavefunction, just call the mother
            FortranUFOHelasCallWriter.generate_external_wavefunction(self,
                                                                       argument)

    def generate_loop_amplitude_call(self, loopamp):
        """Generate legacy DP and paired-mass QP calls behind a caller guard."""

        name = "LOOP%(numLoopLines)s"
        arguments = ""
        if len(loopamp.get('pairing')) != len(loopamp.get('mothers')):
            name += "%(numMotherWfs)s"
            for i in range(len(loopamp.get('pairing'))):
                arguments += "%(Pairing{0})d,".format(i)
        for i in range(len(loopamp.get('mothers'))):
            arguments += "%(MotherID{0})d,".format(i+1)

        dp_call = name + "(" + arguments
        qp_call = name + "_QPMASS(" + arguments
        for i in range(len(loopamp.get('wavefunctions'))-2):
            dp_call += "DCMPLX(%(LoopMass{0})s),".format(i+1)
            qp_call += (
                "DCMPLX(%(LoopMass{0})s),CMPLX({1}%(LoopMass{0})s,KIND=16),"
                .format(i+1, self.mp_prefix))
        suffix = "%(LoopRank)d,I_SO,%(loop_group_id)d)"
        dp_call += suffix
        qp_call += suffix

        def call_function(amp):
            arguments = amp.get_helas_call_dict(OptimizedOutput=True)
            # Keep the complete block in one item: split_HELASCALLS chunks
            # call-list items. DP must not evaluate any MP actual argument.
            return ('IF(CTMODE.LT.4) THEN\nCALL %(proc_prefix)s' +
                    dp_call % arguments + '\nELSE\nCALL %(proc_prefix)s' +
                    qp_call % arguments + '\nENDIF')

        self.add_amplitude(loopamp.get_call_key(), call_function)
        return

    def generate_all_other_helas_objects(self,argument):
        """ Generate all the helas objects for which no special handlers was
        placed in generate_helas_call """
        
        if isinstance(argument, helas_objects.HelasWavefunction):
            outgoing = argument.find_outgoing_number()
        else:
            outgoing = 0
            
        if isinstance(argument, helas_objects.HelasAmplitude) and \
                                                  argument.get('type')=='loop':
           raise MadGraph5Error('There should not be any helas call '+\
                                'associated with helas amplitudes of type loop.')

        # Check if we need to append a charge conjugation flag
        l = [str(l) for l in argument.get('lorentz')]
        flag = []
        if argument.needs_hermitian_conjugate():
            flag = ['C%d' % i for i in argument.get_conjugate_index()]
        
        if (isinstance(argument, helas_objects.HelasWavefunction) and \
           argument.get('is_loop')):
            flag.insert(0,"L%d"%argument.get_loop_index())

        # Creating line formatting:
        call = 'CALL %(routine_name)s(%(wf)s%(coup)s%(mass)s%(out)s)'
        arg = {'routine_name': aloha_writers.combine_name(\
                                        '%s' % l[0], l[1:], outgoing, flag, True),
               'coup': ("%%(coup%d)s," * len(argument.get('coupling'))) % \
                                     tuple(range(len(argument.get('coupling'))))                                            
               }

        # select how to write a single wf
        if (isinstance(argument,helas_objects.HelasWavefunction) \
                 and argument.get('is_loop')):
            base_wf = "%(WF{0})s,"
        else:
            base_wf = self.format_helas_object('W(','%({0})d')+','
        
        # compute the full list of wf
        wf = ''
        for i in range(len(argument.get('mothers'))):
            wf += base_wf.format(i)
        arg['wf'] = wf

                
        # Treat other argument
        # First WaveFunction
        if isinstance(argument, helas_objects.HelasWavefunction):
            if argument['is_loop']:
                arg['out'] = 'PL(0,%(out)d),COEFS'
            else:
                arg['out']=self.format_helas_object('W(','%(out)d')                   
            if aloha.complex_mass:
                arg['mass'] = "DCMPLX(%(CM)s),"
            else:
                arg['mass'] = "%(M)s,%(W)s,"
        # Standard Amplitude
        elif argument['type'] == 'base':      
            arg['mass'] = ''  
            arg['out'] = self.format_helas_object('AMP(','%(out)d')
        # UV Counterterm (and other)
        else:
            arg['mass'] = ''
            ampl = "AMPL({0},%(out)d)".format(argument.get_epsilon_order()+1)
            arg['out'] = '%s' % ampl
            if isinstance(argument,loop_helas_objects.LoopHelasUVCTAmplitude)\
                   and argument.get_UVCT_couplings()!='1.0d0':
                 # add a second line to take into account the multiplicative factor                 
                 call += "\n %(second_line)s "
                 arg['second_line'] = ampl+"="+ampl+"*(%(uvct)s)"        

        # ALL ARGUMENT FORMATTED ###############################################
        # Store the result.
        call = call % arg
        if (isinstance(argument, helas_objects.HelasWavefunction) and \
           argument.get('is_loop')):
            # We add here the call to the UPDATE_COEF subroutine
            call += "\nCALL {0}UPDATE_WL_%(loop_mother_rank)d_%(vertex_rank)d("
            call += "WL(1,0,1,%(loop_mother_number)d),%(lcut_size)d,COEFS,"
            call += "%(in_size)d,%(out_size)d,WL(1,0,1,%(out)d))"
        # Now we have a line correctly formatted, with the proc_prefix
        call_function = lambda wf:\
                        (call%wf.get_helas_call_dict(OptimizedOutput=True, 
                             specifyHel=self.hel_sum)).format('%(proc_prefix)s')

        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)        

#===============================================================================
# CPPUFOHelasCallWriter
#===============================================================================
class CPPUFOHelasCallWriter(UFOHelasCallWriter):
    """The class for writing Helas calls in C++, starting from
    HelasWavefunctions and HelasAmplitudes.

    Includes the function generate_helas_call, which automatically
    generates the C++ Helas call based on the Lorentz structure of
    the interaction."""

    def __init__(self, argument={}, options={}):
        self.use_flavor_mask = False
        self.me_n_flavors = 0
        self.me_active_flavor_mask = None
        super(CPPUFOHelasCallWriter, self).__init__(argument, options=options)

    def _flavor_mask_prefix(self, obj, kind):
        """Return an 'if ((...)) ' prefix for a C++ HELAS call, or ''."""

        if not self.use_flavor_mask or self.me_n_flavors <= 0:
            return ''
        if 'flavor_mask' not in obj:
            return ''
        mask = obj['flavor_mask']
        all_ones = (1 << self.me_n_flavors) - 1
        active_mask = getattr(self, 'me_active_flavor_mask', None)
        if active_mask is None:
            active_mask = all_ones
        if mask == active_mask:
            return ''
        idx = obj.get('number')
        array = 'current_wf_mask' if kind == 'wf' else 'current_amp_mask'
        if kind == 'wf' and 'guard_amp_number' in obj:
            idx = obj.get('guard_amp_number')
            array = 'current_amp_mask'
        if not isinstance(idx, int) or idx <= 0:
            return ''
        word = (idx - 1) // 64
        bit = (idx - 1) % 64
        return 'if ((%s[%d] & (1ULL << %d)) != 0ULL) ' % (array, word, bit)

    def generate_helas_call(self, argument):
        """Routine for automatic generation of C++ Helas calls
        according to just the spin structure of the interaction.

        First the call string is generated, using a dictionary to go
        from the spin state of the calling wavefunction and its
        mothers, or the mothers of the amplitude, to differentiate which call is
        done.

        Then the call function is generated, as a lambda which fills
        the call string with the information of the calling
        wavefunction or amplitude. The call has different structure,
        depending on the spin of the wavefunction and the number of
        mothers (multiplicity of the vertex). The mother
        wavefunctions, when entering the call, must be sorted in the
        correct way - this is done by the sorted_mothers routine.

        Finally the call function is stored in the relevant
        dictionary, in order to be able to reuse the function the next
        time a wavefunction with the same Lorentz structure is needed.
        """

        if not isinstance(argument, helas_objects.HelasWavefunction) and \
           not isinstance(argument, helas_objects.HelasAmplitude):
            raise self.PhysicsObjectError("get_helas_call must be called with wavefunction or amplitude")
        
        call = ""

        call_function = None

        if isinstance(argument, helas_objects.HelasAmplitude) and \
           argument.get('interaction_id') == 0:
            call = "#"
            call_function = lambda amp: call
            self.add_amplitude(argument.get_call_key(), call_function)
            return

        if isinstance(argument, helas_objects.HelasWavefunction) and \
               not argument.get('mothers'):
            # String is just ixxxxx, oxxxxx, vxxxxx or sxxxxx
            call = call + HelasCallWriter.mother_dict[\
                argument.get_spin_state_number()].lower()
            # Fill out with X up to 6 positions
            call = call + 'x' * (6 - len(call))
            # Specify namespace for Helas calls
            call = call + "(p[perm[%d]],"
            if argument.get('spin') != 1:
                # For non-scalars, need mass and helicity
                call = call + "mME[%d],hel[%d],"
            if argument.get('spin') == 2:
                call = call + "%+d, flavor[%i],w[%d]);"
            else:
                call = call + "%+d,w[%d]);"
            if argument.get('spin') == 1:
                call_function = lambda wf: call % \
                                (wf.get('number_external')-1,
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id')-1)
            elif argument.is_boson():
                call_function = lambda wf: call % \
                                (wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id')-1)
            elif argument.get('spin') == 2:
                call_function = lambda wf: call % \
                                (wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 # For fermions, need particle/antiparticle
                                 - (-1) ** wf.get_with_flow('is_part'),
                                 wf.get('number_external')-1, 
                                 wf.get('me_id')-1)
            else:
                call_function = lambda wf: call % \
                                (wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 wf.get('number_external')-1,
                                 # For fermions, need particle/antiparticle
                                 - (-1) ** wf.get_with_flow('is_part'),
                                 wf.get('me_id')-1)
        else:
            if isinstance(argument, helas_objects.HelasWavefunction):
                outgoing = argument.find_outgoing_number()
            else:
                outgoing = 0
                
            # Check if we need to append a charge conjugation flag
            l = [str(l) for l in argument.get('lorentz')]
            flag = [] 
            if argument.needs_hermitian_conjugate():
                flag = ['C%d' % i for i in argument.get_conjugate_index()]
            
            if isinstance(argument, helas_objects.HelasWavefunction) and argument.get('onshell') is False:
                flag.append('P1D') # D is for $ syntax -> offshell propagator only
                
            # Creating line formatting:
            call = '%(routine_name)s(%(wf)s%(coup)s%(mass)s%(out)s);'
            # compute wf
            arg = {'routine_name': aloha_writers.combine_name(\
                                            '%s' % l[0], l[1:], outgoing, flag,True),
                   'wf': ("w[%%(%d)d]," * len(argument.get('mothers'))) % \
                                      tuple(range(len(argument.get('mothers')))),
                    'coup': ("pars.%%(coup%d)s," * len(argument.get('coupling'))) % \
                                     tuple(range(len(argument.get('coupling'))))           
                   } 
            if isinstance(argument, helas_objects.HelasWavefunction):
                arg['out'] = 'w[%(out)d]'
                if aloha.complex_mass:
                    arg['mass'] = "pars.%(CM)s,%(bwcutoff)s"
                else:
                    arg['mass'] = "pars.%(M)s,pars.%(W)s,%(bwcutoff)s"
            else:        
                arg['out'] = 'amp[%(out)d]'
                arg['mass'] = ''
                
            call = call % arg
            # Now we have a line correctly formatted
            call_function = lambda wf: self.format_coupling(
                                         call % wf.get_helas_call_dict(index=0))
        
        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)

    @staticmethod
    def format_coupling(call):
        """Format the coupling so any minus signs are put in front"""

        return call.replace('pars.-', '-pars.')
        


class GPUFOHelasCallWriter(CPPUFOHelasCallWriter):


    findcoupling = re.compile(r'pars->([-]*[\d\w_]+)\s*,')
    usepointerforvertex = True

    def format_coupling(self, call):
        """Format the coupling so any minus signs are put in front"""

        model = self.get('model')
        if not hasattr(self, 'couplings2order'):
            self.couplings2order = {}
            self.params2order = {}
            
        for coup in re.findall(self.findcoupling, call):
            if coup == 'ZERO':
                call = call.replace('pars.ZERO', '0.')
                continue
            sign = '' 
            if coup.startswith('-'):
                sign = '-'
                coup = coup[1:]
            
            try:
                param = model.get_parameter(coup)
            except KeyError:
                param = False
            
            if param:   
                alias = self.params2order
                name = "cIPD"
            else: 
                alias = self.couplings2order
                name = "cIPC"
            if coup not in alias:
                alias[coup] = len(alias)
            if name == "cIPD":
                call = call.replace('pars.%s%s' % (sign, coup), 
                                    '%s%s[%s]' % (sign, name, alias[coup]))
            else:
                call = call.replace('pars.%s%s' % (sign, coup), 
                                    '%scxtype(cIPC[%s],cIPC[%s])' % 
                                    (sign, 2*alias[coup],2*alias[coup]+1))

        return call
            
    
    def get_external(self,wf, argument):
    
        text = """
#ifdef __CUDACC__
    %s    
#else
    %s
#endif 
"""
        line =  self.get_external_line(wf, argument)
        split_line = line.split(',')
        split_line.insert(-1, ' ievt')
        return text % (line, ','.join(split_line))
    
    def get_external_line(self, wf, argument):

        call = ''
        call = call + HelasCallWriter.mother_dict[\
                argument.get_spin_state_number()].lower() 
        if wf.get('mass').lower() != 'zero' or argument.get('spin') != 2: 
            # Fill out with X up to 6 positions
            call = call + 'x' * (6 - len(call))
            # Specify namespace for Helas calls
            ##call = call + "((double *)(dps + %d * dpt),"
            call = call + "(allmomenta,"
            if argument.get('spin') != 1:
                # For non-scalars, need mass and helicity
                call = call + "pars.%s, cHel[ihel][%d],"
            else:
                call = call + "pars.%s,"
            call = call + "%+d,w[%d], %d);"
            if argument.get('spin') == 1:
                return call % \
                                (wf.get('mass'),
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id')-1,
                                 wf.get('number_external')-1)
            elif argument.is_boson():
                return  self.format_coupling(call % \
                                (wf.get('mass'),
                                 wf.get('number_external')-1,
                                 # For boson, need initial/final here
                                 (-1) ** (wf.get('state') == 'initial'),
                                 wf.get('me_id')-1,
                                 wf.get('number_external')-1))
            else:
                return self.format_coupling(call % \
                                (wf.get('mass'),
                                 wf.get('number_external')-1,
                                 # For fermions, need particle/antiparticle
                                 - (-1) ** wf.get_with_flow('is_part'),
                                 wf.get('me_id')-1,
                                 wf.get('number_external')-1))
        else:
            if wf.get('number_external') == 1:
                call += 'pz'
            elif wf.get('number_external') == 2:
                call += 'mz'
            else:
                call += 'xz'
            call = call + 'x' * (6 - len(call))
            # Specify namespace for Helas calls
            ##call = call + "((double *)(dps + %d * dpt),"
            call = call + "(allmomenta, cHel[ihel][%d],%+d,w[%d],%d);"
            
            return self.format_coupling(call % \
                                (wf.get('number_external')-1,
                                 # For fermions, need particle/antiparticle
                                 - (-1) ** wf.get_with_flow('is_part'),
                                 wf.get('me_id')-1,
                                 wf.get('number_external')-1))
                
                
        
        

    def generate_helas_call(self, argument):
        """Routine for automatic generation of C++ Helas calls
        according to just the spin structure of the interaction.

        First the call string is generated, using a dictionary to go
        from the spin state of the calling wavefunction and its
        mothers, or the mothers of the amplitude, to differentiate which call is
        done.

        Then the call function is generated, as a lambda which fills
        the call string with the information of the calling
        wavefunction or amplitude. The call has different structure,
        depending on the spin of the wavefunction and the number of
        mothers (multiplicity of the vertex). The mother
        wavefunctions, when entering the call, must be sorted in the
        correct way - this is done by the sorted_mothers routine.

        Finally the call function is stored in the relevant
        dictionary, in order to be able to reuse the function the next
        time a wavefunction with the same Lorentz structure is needed.
        """

        if not isinstance(argument, helas_objects.HelasWavefunction) and \
           not isinstance(argument, helas_objects.HelasAmplitude):
            raise self.PhysicsObjectError("get_helas_call must be called with wavefunction or amplitude")


        
        call = ""

        call_function = None

        if isinstance(argument, helas_objects.HelasAmplitude) and \
           argument.get('interaction_id') == 0:
            call = "#"
            call_function = lambda amp: call
            self.add_amplitude(argument.get_call_key(), call_function)
            return

        if isinstance(argument, helas_objects.HelasWavefunction) and \
               not argument.get('mothers'):
            # String is just ixxxxx, oxxxxx, vxxxxx or sxxxxx
            call_function = lambda wf: self.get_external(wf, argument)
        else:
            if isinstance(argument, helas_objects.HelasWavefunction):
                outgoing = argument.find_outgoing_number()
            else:
                outgoing = 0
                
            # Check if we need to append a charge conjugation flag
            l = [str(l) for l in argument.get('lorentz')]
            flag = [] 
            if argument.needs_hermitian_conjugate():
                flag = ['C%d' % i for i in argument.get_conjugate_index()]
                
                
            # Creating line formatting:
            if isinstance(argument, helas_objects.HelasWavefunction):
                call = '%(routine_name)s(%(wf)s%(coup)s%(mass)s%(out)s);'
            else:
                call = '%(routine_name)s(%(wf)s%(coup)s%(mass)s%(out)s); printf(" %(out)s %%%%f %%%%f\\n", %(out2)s.real(), %(out2)s.imag());'
                call = '%(routine_name)s(%(wf)s%(coup)s%(mass)s%(out)s);'
            # compute wf
            arg = {'routine_name': aloha_writers.combine_name(\
                                            '%s' % l[0], l[1:], outgoing, flag,True),
                   'wf': ("w[%%(%d)d]," * len(argument.get('mothers'))) % \
                                      tuple(range(len(argument.get('mothers')))),
                    'coup': ("pars.%%(coup%d)s," * len(argument.get('coupling'))) % \
                                     tuple(range(len(argument.get('coupling'))))           
                   } 
            if isinstance(argument, helas_objects.HelasWavefunction):
                arg['out'] = 'w[%(out)d]'
                if aloha.complex_mass:
                    arg['mass'] = "pars.%(CM)s,"
                else:
                    arg['mass'] = "pars.%(M)s,pars.%(W)s,"
            else:    
                if self.usepointerforvertex:    
                    arg['out'] = '&amp[%(out)d]'
                    arg['out2'] = 'amp[%(out)d]'
                    arg['mass'] = ''
                else:
                    arg['out'] = '&amp[%(out)d]'
                    arg['out2'] = 'amp[%(out)d]'
                    arg['mass'] = ''
                
            call = call % arg
            # Now we have a line correctly formatted
            call_function = lambda wf: self.format_coupling(
                                         call % wf.get_helas_call_dict(index=0))
            
        
        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)


    pass

    def get_matrix_element_calls(self, matrix_element, color_amplitudes, multi_channel_map=False):
        """Return a list of strings, corresponding to the Helas calls
        for the matrix element"""

        assert isinstance(matrix_element, helas_objects.HelasMatrixElement), \
                  "%s not valid argument for get_matrix_element_calls" % \
                  type(matrix_element)
        
        import madgraph.iolibs.export_cpp as export_cpp
        # Do not reuse the wavefunctions for loop matrix elements
        if isinstance(matrix_element, loop_helas_objects.LoopHelasMatrixElement):
            return self.get_loop_matrix_element_calls(matrix_element)

        #restructure data for easier handling
        color = {}
        for njamp, coeff_list in enumerate(color_amplitudes):
            for coeff, namp in coeff_list:
                if namp not in color:
                    color[namp] = {}
                color[namp][njamp] = coeff

        
        
        me = matrix_element.get('diagrams')


        matrix_element.reuse_outdated_wavefunctions(me)


        res = []
        # reset jamp:
        res.append('for(int i=0;i<%s;i++){jamp[i] = cxtype(0.,0.);}'
                   % len(color_amplitudes))
        diagrams = matrix_element.get('diagrams')
        diag_to_config = {}
        if multi_channel_map:
            for config in sorted(multi_channel_map.keys()):
                amp = [a.get('number') for a in \
                                  sum([diagrams[idiag].get('amplitudes') for \
                                       idiag in multi_channel_map[config]], [])]
                diag_to_config[amp[0]] = config
        id_amp = 0
        for diagram in matrix_element.get('diagrams'):
             
            res.extend([ self.get_wavefunction_call(wf) for \
                         wf in diagram.get('wavefunctions') ])
            res.append("# Amplitude(s) for diagram number %d" % 
                       diagram.get('number'))
            for amplitude in diagram.get('amplitudes'):
                id_amp +=1
                namp = amplitude.get('number')
                amplitude.set('number', 1)
                res.append(self.get_amplitude_call(amplitude))
                # amp2
                if id_amp in diag_to_config:
                    res.append("if(channel_id == %i){multi_chanel_num += conj(amp[0])*amp[0];};" % diag_to_config[id_amp])
                    res.append(" multi_chanel_denom += conj(amp[0])*amp[0];")
                # jamp
                for njamp, coeff in color[namp].items():
                    res.append("jamp[%s] += %samp[0];" % 
                         (njamp, export_cpp.OneProcessExporterGPU.coeff(*coeff)))

        return res

    def get_wavefunction_call(self, wavefunction, **opt):
        call = super(CPPUFOHelasCallWriter, self).get_wavefunction_call(
                                                            wavefunction, **opt)
        if not call:
            return call
        prefix = self._flavor_mask_prefix(wavefunction, 'wf')
        return prefix + call if prefix else call

    def get_amplitude_call(self, amplitude):
        call = super(CPPUFOHelasCallWriter, self).get_amplitude_call(amplitude)
        if not call:
            return call
        prefix = self._flavor_mask_prefix(amplitude, 'amp')
        return prefix + call if prefix else call



#===============================================================================
# PythonUFOHelasCallWriter
#===============================================================================
class PythonUFOHelasCallWriter(UFOHelasCallWriter):
    """The class for writing Helas calls in Python, starting from
    HelasWavefunctions and HelasAmplitudes.

    Includes the function generate_helas_call, which automatically
    generates the Python Helas call based on the Lorentz structure of
    the interaction."""

    def get_matrix_element_calls(self, matrix_element, gauge_check=False):
        """Return a list of strings, corresponding to the Helas calls
        for the matrix element"""

        assert isinstance(matrix_element, helas_objects.HelasMatrixElement), \
                  "%s not valid argument for get_matrix_element_calls" % \
                  repr(matrix_element)

        me = matrix_element.get('diagrams')
        matrix_element.reuse_outdated_wavefunctions(me)

        res = []
        for diagram in matrix_element.get('diagrams'):
            wfs = diagram.get('wavefunctions')
            if gauge_check and diagram.get('number') == 1:
                gauge_check_wfs = [wf for wf in wfs if not wf.get('mothers') \
                                   and wf.get('spin') == 3 \
                                   and wf.get('mass').lower() == 'zero']
                if not gauge_check_wfs:
                    raise HelasWriterError('no massless spin one particle for gauge check')
                gauge_check_wf = wfs.pop(wfs.index(gauge_check_wfs[0]))
                res.append(self.generate_helas_call(gauge_check_wf, True)(\
                                                    gauge_check_wf))
            res.extend([ self.get_wavefunction_call(wf) for wf in wfs ])
            res.append("# Amplitude(s) for diagram number %d" % \
                       diagram.get('number'))
            for amplitude in diagram.get('amplitudes'):
                res.append(self.get_amplitude_call(amplitude))
                
        return res



    def generate_helas_call(self, argument, gauge_check=False):
        """Routine for automatic generation of Python Helas calls
        according to just the spin structure of the interaction.
        """

        if not isinstance(argument, helas_objects.HelasWavefunction) and \
           not isinstance(argument, helas_objects.HelasAmplitude):
            raise self.PhysicsObjectError("get_helas_call must be called with wavefunction or amplitude")
        
        call_function = None

        if isinstance(argument, helas_objects.HelasAmplitude) and \
           argument.get('interaction_id') == 0:
            call = "#"
            call_function = lambda amp: call
            self.add_amplitude(argument.get_call_key(), call_function)
            return

        if isinstance(argument, helas_objects.HelasWavefunction) and \
               not argument.get('mothers'):
            # String is just IXXXXX, OXXXXX, VXXXXX or SXXXXX
            call = "w[%d] = "

            wf_name = HelasCallWriter.mother_dict[\
                argument.get_spin_state_number()].lower()
            fixed_wf_name = None
            if aloha.unitary_gauge == 3:
                if argument.get('spin') == 1:
                    wf_name = 'sfd'
                elif argument.get('spin') == 3:
                    fixed_wf_name = 'vfdxxxx'
            if fixed_wf_name is None:
                call = call + wf_name
                # Fill out with X up to 6 positions
                call = call + 'x' * (14 - len(call))
            else:
                call = call + fixed_wf_name
            call = call + "(p[%d],"
            if argument.get('spin') != 1:
                # For non-scalars, need mass and helicity
                if gauge_check and argument.get('spin') == 3 and \
                                                 argument.get('mass') == 'ZERO':
                    call = call + "%s, 4,"
                else:
                    call = call + "%s,hel[%d],"
            call = call + "%+d)"
            if argument.get('spin') == 1:
                call_function = lambda wf: call % \
                                (wf.get('me_id')-1,
                                 wf.get('number_external')-1,
                                 # For boson, need initial/final here
                                 (-1)**(wf.get('state') == 'initial'))
            elif argument.is_boson():
                if not gauge_check or argument.get('mass') != 'ZERO':
                    call_function = lambda wf: call % \
                                (wf.get('me_id')-1,
                                 wf.get('number_external')-1,
                                 wf.get('mass'),
                                 wf.get('number_external')-1,
                                 # For boson, need initial/final here
                                 (-1)**(wf.get('state') == 'initial'))
                else:
                    call_function = lambda wf: call % \
                                (wf.get('me_id')-1,
                                 wf.get('number_external')-1,
                                 'ZERO',
                                 # For boson, need initial/final here
                                 (-1)**(wf.get('state') == 'initial'))
            else:
                # Fermions: always include the flavor argument so that
                # merged-particle models (FLV_Coupling) can look up the
                # correct coupling value at runtime.  The flavor list is
                # passed as an optional argument to smatrix/matrix; when it
                # is None (standard non-merged call) we fall back to -1.
                call_ferm = call[:-1] + ', flavor[%d] if flavor is not None else -1)'
                call_function = lambda wf, c=call_ferm: c % \
                                (wf.get('me_id')-1,
                                 wf.get('number_external')-1,
                                 wf.get('mass'),
                                 wf.get('number_external')-1,
                                 # For fermions, need particle/antiparticle
                                 -(-1)**wf.get_with_flow('is_part'),
                                 # 0-based index into the runtime flavor list
                                 wf.get('number_external')-1)
        else:
            # String is LOR1_0, LOR1_2 etc.
            
            if isinstance(argument, helas_objects.HelasWavefunction):
                outgoing = argument.find_outgoing_number()
            else:
                outgoing = 0

            # Check if we need to append a charge conjugation flag
            l = [str(l) for l in argument.get('lorentz')]
            flag = []
            if argument.needs_hermitian_conjugate():
                flag = ['C%d' % i for i in argument.get_conjugate_index()]
                
                
            # Creating line formatting:
            call = '%(out)s= %(routine_name)s(%(wf)s%(coup)s%(mass)s)'
            # compute wf
            arg = {'routine_name': aloha_writers.combine_name(\
                                            '%s' % l[0], l[1:], outgoing, flag, True),
                   'wf': ("w[%%(%d)d]," * len(argument.get('mothers'))) % \
                                      tuple(range(len(argument.get('mothers')))),
                    'coup': ("%%(coup%d)s," * len(argument.get('coupling'))) % \
                                     tuple(range(len(argument.get('coupling'))))           
                   }

            if isinstance(argument, helas_objects.HelasWavefunction):
                arg['out'] = 'w[%(out)d]'
                if aloha.complex_mass:
                    arg['mass'] = "%(CM)s"
                else:
                    arg['mass'] = "%(M)s,%(W)s"
            else:
                arg['coup'] = arg['coup'][:-1] #removing the last coma
                arg['out'] = 'amp[%(out)d]'
                arg['mass'] = ''
                
            call = call % arg
            # Now we have a line correctly formatted
            call_function = lambda wf: call % wf.get_helas_call_dict(index=0)
                
            routine_name = aloha_writers.combine_name(
                                        '%s' % l[0], l[1:], outgoing, flag)
        
        # Add the constructed function to wavefunction or amplitude dictionary
        if isinstance(argument, helas_objects.HelasWavefunction):
            if not gauge_check:
                self.add_wavefunction(argument.get_call_key(), call_function)
        else:
            self.add_amplitude(argument.get_call_key(), call_function)

        return call_function
