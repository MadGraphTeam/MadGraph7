#!/usr/bin/env python3
"""Pure file-only source replay. Never executes tests, compilers or reducers."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--working-root', type=Path)
    parser.add_argument('--index-sha256')
    args = parser.parse_args()
    index_path = HERE / 'source-index.json'
    if args.index_sha256:
        require(sha(index_path) == args.index_sha256, 'Externally bound source index changed')
    index = json.loads(index_path.read_text())
    actual = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual == set(index['files']) | {'source-index.json'}, 'Owned source inventory changed')
    for name, wanted in index['files'].items():
        p = HERE / name
        require(not p.is_symlink() and p.stat().st_size == wanted['bytes'] and sha(p) == wanted['sha256'],
                'Owned source changed: ' + name)
    spec = importlib.util.spec_from_file_location('current_qpmass_portable_prepare', HERE / 'prepare.py')
    prepare = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prepare)
    baseline = {str(name): (HERE / 'base' / name).read_text() for name in prepare.FILES}
    guarded = (HERE / 'ancestor-guarded-writer-method.txt').read_text()
    # sources() only asks method_span() for this exact class/method; the retained
    # method is wrapped solely to reparse the unchanged method independently.
    guarded_source = 'class FortranUFOHelasCallWriterOptimized:\n' + guarded
    reproduced = prepare.sources(baseline, guarded_source)
    require(set(reproduced) == {str(p.relative_to(HERE/'src')) for p in (HERE/'src').rglob('*') if p.is_file()},
            'Candidate source set differs from its derivation')
    for name, text in reproduced.items():
        require(text == (HERE/'src'/name).read_text(), 'Candidate derivation changed: ' + name)
    for mode in ('normal', 'optimized'):
        receipt = json.loads((HERE/('tests-'+mode+'.json')).read_text())
        require(receipt['success'] and receipt['tests_run'] == 10 and receipt['errors'] == 0 and
                receipt['failures'] == 0 and not receipt['forbidden_API_attempts'] and
                receipt['compiler_calls'] == receipt['native_amplitudes'] == 0,
                'Source test receipt does not pass')
    deps = json.loads((HERE/'dependencies.json').read_text())
    live_files = 0
    if args.working_root:
        root = args.working_root.resolve()
        for name, wanted in deps['files'].items():
            require(sha(root/name) == wanted, 'Explicit source dependency changed: ' + name)
            live_files += 1
        for name, wanted in json.loads((HERE/'preparation.json').read_text())['original_files'].items():
            require(sha(root/name) == wanted, 'Current production source changed: ' + name)
    print(json.dumps({
        'verified': True, 'owned_payloads': len(index['files']),
        'reproduced_candidate_files': len(reproduced), 'source_tests_normal_and_optimized': 10,
        'live_explicit_source_dependencies_checked': live_files, 'new_native_calls': 0,
        'compiler_calls': 0, 'physical_truth_qualified': False, 'candidate_promoted': False,
    }, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
