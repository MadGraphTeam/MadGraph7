# Existing QP mass transport: audit and concrete next gate

Production optimized calls originate at `helas_call_writers.py:2001` and pass
`DCMPLX(LoopMass)`. `LoopHelasAmplitude.get_masses()` selects the real mass or
`CMASS_<mass>` according to the existing complex-mass policy. The optimized
exporter intentionally omits MP mass formals (`loop_exporters.py:1528`) and forms
the cyclic DP M2L array (`:1545`). Both private and public QP TIRust routines
currently accept that DP array; `TIRUST_interface.inc:178` widens it. The low-level
`mtirust.tensor_mp` interface, its input transport and QP contraction remain
genuine QP; this is a source-level mass-square intermediate limitation, not DD
being advertised as QP.

The earlier generalized source package already solved actual-selected-library
routing and retained all legacy routine renderings. Its later caller guard
prevents MP actual construction in DP and preserves one-item split blocks.
The combined qualification retains218 recording fixtures, six amplitude workers
and two original-QP controls. The checked input invariance does not imply
physical acceptance: every physical status was fixed120 with accuracy−1;
backend9 refused37 threshold groups in each mass arm, and both aggregates are
incomplete. Library49af… is not the current eb3… runtime. No ordinary checked
rescue/current-source100-point/DP-regression/CMS/loop-induced/performance gate was
closed for the combined mass correction. These are the concrete nonpromotion
reasons; transport itself was not shown wrong.

The new source narrows that proven design to backend9 and rebases the Fortran
bodies onto current source without factoring or rewriting legacy adapters.
It does not apply the earlier requested-LIBINDEX-only fixture transformer, whose
scope was explicit8/9. The selected-I_LIB guard is retained after CHOOSE_LOOPLIB.
No stale earlier source is restored over current failure/cache fixes.

For current n3, bottom mass is exactly
`5291729562160333/1125899906842624`. Its squared numerator has105 bits; binary128
can represent the exact square. Old DP square minus that square is
`2206763817411543/1267650600228229401496703205376`.
Current top173 has an exactly representable DP square and is not the useful
mass-square discriminator. Anchor16 supplies an existing clean automaticQP323
rescue, but actual native MP bottom groups must still be observed rather than
inferred merely from their presence in generated source.

Recommended sequence: reviewed current-source generation, compile/link, then
separately reviewed normal full100 learning and saved100-point comparison,
cache0/−1. Capture real MP model/mass-square words, actual native calls and all
host outputs/errors. Require exact DP/control equivalence and independently
assess QP changes. A genuine derived-MW or complex-pole unit case must exercise
the113-bit-only argument bits. A later physical derived/CMS gate needs the
independent matched-input reducer/pole evidence and the already separate
geometry correction controls. No threshold refusal is deleted or relabelled.

The approved goal requires genuine QP computation and transport and is already
stronger than DD. This source correction closes a distinct model-input
precision limitation if qualified; until then the limitation stays explicit.
No inference here establishes complete physical accuracy or performance.
