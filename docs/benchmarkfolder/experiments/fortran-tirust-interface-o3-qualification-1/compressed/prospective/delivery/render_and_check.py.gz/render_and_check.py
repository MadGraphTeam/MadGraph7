#!/usr/bin/env python3
"""Render unapplied alternatives and run controlled synthetic make -n checks."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = Path("Template/loop_material/StandAlone/SubProcesses/makefile")
MAKE = Path("/nix/store/0xw6y53ijaqwfd9c99wyaqiinychzv1f-gnumake-4.4.1/bin/make")
BASH = Path("/nix/store/lw117lsr8d585xs63kx5k233impyrq7q-bash-5.3p3/bin/bash")
SENTINEL = "PRIVATE_RECIPE_ONLY_NO_COMPILER"
BASE_FLAGS = ["-w", "-fPIC", "-ffixed-line-length-132"]
EXTRA = ["-O3", "-fno-fast-math"]
UNITS = ("TIRUST_interface", "TIR_interface", "CT_interface",
         "COLLIER_interface", "GOLEM_interface", "loop_matrix", "polynomial")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def render(original, default):
    variable = (
        "# Additional flags for the backend-9 Fortran wrapper only.\n"
        "# Override with make TIRUST_INTERFACE_FFLAGS='...' when required.\n"
        f"TIRUST_INTERFACE_FFLAGS ?={' ' + default if default else ''}\n\n"
    )
    anchor = "include $(ROOT)/Source/make_opts\n"
    assert original.count(anchor) == 1
    result = original.replace(anchor, variable + anchor)
    rules = (
        "# Keep wrapper flags out of prerequisites and all other backend sources.\n"
        "TIRUST_INTERFACE_OBJECTS = $(patsubst %.f,%.o,$(wildcard TIRUST_interface.f $(LOOP_PREFIX)*/TIRUST_interface.f))\n"
        "ifneq ($(strip $(TIRUST_INTERFACE_OBJECTS)),)\n"
        "$(TIRUST_INTERFACE_OBJECTS): %.o: %.f $(POLYNOMIAL) $(OLP_POLYNOMIAL)\n"
        "\t$(FC) $(FFLAGS) $(TIRUST_INTERFACE_FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)\n"
        "endif\n\n"
    )
    anchor = "$(DOTO) : $(DOTF) $(POLYNOMIAL) $(OLP_POLYNOMIAL)\n"
    assert result.count(anchor) == 1
    return result.replace(anchor, rules + anchor)


def fixture(label, text):
    base = HERE / "recipe-fixtures" / label
    (base / "Source" / "MODEL").mkdir(parents=True, exist_ok=True)
    (base / "Source" / "DHELAS").mkdir(parents=True, exist_ok=True)
    sub = base / "SubProcesses"
    process = sub / "P0_fixture"
    process.mkdir(parents=True, exist_ok=True)
    (base / "Source" / "make_opts").write_text(
        f"FC = {SENTINEL}\nFFLAGS = {' '.join(BASE_FLAGS)}\n"
        "libext = a\ndylibext = so\nUNAME = Linux\n"
    )
    (sub / "MadLoop_makefile_definitions").write_text(
        "DOTF = %.f\nDOTO = %.o\nLOOP_PREFIX = P\nLOOP_INCLUDE =\n"
    )
    (sub / "makefile").write_text(text)
    (process / "makefile").write_text(text)
    for unit in UNITS:
        (process / (unit + ".f")).write_text("      END\n")
    return sub, process


def prepared_make_command(parent, override):
    prefix = "P0_fixture/" if parent else ""
    command = [str(MAKE), "-n", "-B", "--no-print-directory", "-f", "makefile", "SHELL=" + str(BASH)]
    command += [prefix + unit + ".o" for unit in UNITS]
    if override is not None:
        command += ["TIRUST_INTERFACE_FFLAGS=" + override]
    return command


def recipes(directory, parent, override):
    # The controlled fixture has no $(shell), and selected targets have no
    # recursive $(MAKE). The sentinel is not a real compiler. PATH is empty.
    command = prepared_make_command(parent, override)
    proc = subprocess.run(command, cwd=directory, text=True, capture_output=True,
                          env={"PATH": "/nonexistent", "LC_ALL": "C"})
    if proc.returncode:
        raise AssertionError(proc.stderr)
    commands = [shlex.split(line) for line in proc.stdout.replace("\\\n", " ").splitlines()
                if line.startswith(SENTINEL + " ")]
    assert len(commands) == len(UNITS), proc.stdout
    by_source = {Path(command[command.index("-c") + 1]).name: command
                 for command in commands}
    assert len(by_source) == len(UNITS)
    return proc.stdout, by_source


def main():
    before = (ROOT / SOURCE).read_bytes()
    original = before.decode()
    alternatives = {
        "opt-in": render(original, ""),
        "enabled-default": render(original, " ".join(EXTRA)),
    }
    receipts = []
    original_fixture = fixture("original", original)
    originals = {}
    for parent, location in zip((True, False), original_fixture):
        stdout, originals[parent] = recipes(location, parent, None)
        (HERE / ("original-" + ("parent" if parent else "local") + ".txt")).write_text(stdout)
    payloads = {}
    for label, content in alternatives.items():
        target = HERE / ("makefile." + label)
        target.write_text(content)
        patch = "".join(difflib.unified_diff(
            original.splitlines(keepends=True), content.splitlines(keepends=True),
            fromfile="a/" + str(SOURCE), tofile="b/" + str(SOURCE), n=3))
        (HERE / ("backend9-wrapper-" + label + ".patch")).write_text(patch)
        payloads[target.name] = digest(content.encode())
        payloads["backend9-wrapper-" + label + ".patch"] = digest(patch.encode())
        locations = fixture(label, content)
        for parent, location in zip((True, False), locations):
            for mode, override in (("default", None), ("tested", " ".join(EXTRA)),
                                   ("disabled", ""), ("custom", "-O2")):
                stdout, found = recipes(location, parent, override)
                expected_extra = ([] if label == "opt-in" else EXTRA) if override is None else shlex.split(override)
                for name, current in found.items():
                    baseline = originals[parent][name]
                    if name == "TIRUST_interface.f":
                        index = baseline.index("-c")
                        assert current == baseline[:index] + expected_extra + baseline[index:], (label, mode, name, current, baseline)
                    else:
                        assert current == baseline, (label, mode, name, current, baseline)
                filename = f"{label}-{'parent' if parent else 'local'}-{mode}.txt"
                (HERE / filename).write_text(stdout)
                receipts.append({"alternative": label, "layout": "parent-OLP" if parent else "local-process",
                                 "mode": mode, "override": override, "wrapper_extra_flags": expected_extra,
                                 "all_other_unit_commands_identical": True,
                                 "unit_commands_checked": len(found), "recipe_output": filename,
                                 "make_dry_run_cwd": str(location.relative_to(ROOT)),
                                 "make_dry_run_argv": prepared_make_command(parent, override)})
    assert (ROOT / SOURCE).read_bytes() == before
    receipt = {"schema": "private-wrapper-make-recipe-check-v1", "status": "passed",
               "scope": "Controlled synthetic make -n metadata only; no exporter/compiler/linker/loader/amplitude execution",
               "production_template": str(SOURCE), "production_template_sha256": digest(before),
               "make_sha256": digest(MAKE.read_bytes()), "bash_sha256": digest(BASH.read_bytes()),
               "make_invocations": len(receipts) + 2, "actual_make_dispatch_verified": True,
               "prior_harness_attempts": [{"make_invocations": 8, "compiler_invocations": 0,
                   "layout": "controlled synthetic fixtures only", "outcome": "two parser/fixture failures, one diagnostic make -n, one recipe dispatch failure (four calls), one debug make -n",
                   "stdout_retained": "diagnostic visible in tool transcript; failed parser attempts not retained",
                   "resolved_by": "join continued lines, correct exporter fixture definitions, replace fallback-prone pattern with explicit enumerated static pattern rule"},
                   {"make_invocations": 18, "compiler_invocations": 0,
                    "outcome": "earlier successful recipe matrix before whitespace-only patch cleanup"}],
               "environment": {"PATH": "/nonexistent", "LC_ALL": "C"}, "compiler_invocations": 0,
               "native_loads": 0, "native_amplitudes": 0, "patches_applied": 0,
               "cases": receipts, "payload_sha256": payloads}
    (HERE / "recipe-checks.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "passed", "recipe_cases": len(receipts),
                      "unit_commands_checked": len(receipts) * len(UNITS),
                      "production_template_sha256": digest(before), "patches_applied": 0}))


if __name__ == "__main__":
    main()
