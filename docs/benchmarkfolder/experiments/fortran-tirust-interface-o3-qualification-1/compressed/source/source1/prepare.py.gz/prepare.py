#!/usr/bin/env python3
"""Freeze two current cases and exact source previews. Pure file reads/writes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROFILE_SOURCE=ROOT/'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-2'
PROFILE_EXEC=ROOT/'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2'
CAMPAIGN=ROOT/'docs/benchmarkfolder/campaigns/entry-latch-cache-guard-1'
CASE_IDS={'n1':'qcd_n1_uux_z','n3':'qcd_n3_uux_zgg'}
ANCESTRY={
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-2/source-index.json':'e633405b99d782ad6cf021be875b258f13e5669a7113c3890c40fa36eca6160f',
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2/build/terminal.json':'16b15cc8db66880abf1fbf127ec0c2ceef2c9226446e30bd7fd6ab61b85c7470',
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2/build/result.json':'fc680d285024c3136904d9f45f9ccd2b7d68d2423b884124938ac4cd7a4956b2',
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2/parity/terminal.json':'4f34848d7888a562dc631bbe5792c65a296dc3b7516b19ab284a9627c25d07f7',
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2/profile/terminal.json':'c59cdd7b14b85706df9d28249b3fb2f608532be480a99b51a97a6721760a6568',
 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2/profile/result.json':'eaf56fab60ac3f65a6f7118724a82bf7f023e3fba2a3db1b8e928affad437c18',
 '.tirust-build/fortran-dp-n1-profile-independent-audit-2/report.json':'7ec5d8dafc24d0bbe83956d36b8cf22e6ce524fe122b03d2f933be2396336f99',
 '.tirust-build/fortran-dp-n1-profile-independent-profile-audit-2/report.json':'226c53f8d2f81f8e99b29e7ac33c480de8628d3a12859153a2aad7534b0d91f0'}


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):return json.loads(Path(path).read_text())


def load(name):
    spec=importlib.util.spec_from_file_location('o3_prepare_'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def entry(path):return {'sha256':digest(path),'bytes':Path(path).stat().st_size}


def dump_new(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def main():
    for name,checksum in ANCESTRY.items():
        if digest(ROOT/name)!=checksum:raise ValueError('Closed profile ancestry changed: '+name)
    sys.path.insert(0,str(ROOT/'tools'))
    import tirust_benchmark as bench
    drivers=load('drivers');policy=load('policy')
    for name in ('tool_environment.py','toolchain-pins.json'):
        with (HERE/name).open('xb') as stream:stream.write((PROFILE_SOURCE/name).read_bytes())
    cases={};files={}
    def bind(path):
        path=Path(path);name=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        files[name]=entry(path)
    for key,case_id in CASE_IDS.items():
        output=ROOT/'.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate'/case_id
        proc=next(output.glob('SubProcesses/P*_*'))
        compilation=read(output/'compilation.json')
        closed=CAMPAIGN/'experiments/numerical'/('full100-warmup-'+case_id+'-1')/'candidate-9'
        lane=read(closed/'candidate-inputs.json');observed=read(closed/'raw/observation.json')
        if lane['compilation']!=compilation or lane['generation']!=read(output/'generation.json'):
            raise ValueError('Closed case/build identity differs: '+key)
        if bench.generated_sources(output)!=compilation['sources'] or digest(proc/'check')!=compilation['executable_sha256']:
            raise ValueError('Current generated case changed: '+key)
        if compilation['effective_compiler_flags']['environment']!={}:
            raise ValueError('Unexpected compiler injection: '+key)
        codes={str(row['point']):row['status'] for row in observed['rows'] if row['order']==0}
        if len(codes)!=100 or not set(codes.values())<={219,323} or (key=='n1' and set(codes.values())!={219}):
            raise ValueError('Unexpected n1 cohort')
        if key=='n3' and [int(point) for point,code in sorted(codes.items(),key=lambda x:int(x[0])) if code==323]!=[16,18,21,32,39,52,54,55,65,94,97,98,99]:
            raise ValueError('Unexpected current n3 automatic-QP distribution')
        preview=HERE/'source-preview'/key;preview.mkdir(parents=True,exist_ok=False)
        original=HERE/'original-source'/key;original.mkdir(parents=True,exist_ok=False)
        for name in ('TIRUST_interface.f','check_sa.f','makefile'):
            (original/name).write_bytes((proc/name).read_bytes())
        (preview/'TIRUST_interface.f').write_bytes((proc/'TIRUST_interface.f').read_bytes())
        (preview/'check_sa.f').write_text(drivers.worker((proc/'check_sa.f').read_text()))
        for variant in ('original','candidate'):
            (preview/('makefile.'+variant)).write_text(policy.private_makefile((proc/'makefile').read_text(),variant=='candidate'))
        points=CAMPAIGN/'points'/(case_id+'.dat')
        for path in (output/'generation.json',output/'compilation.json',proc/'check',proc/'makefile',
                     output/'Cards/param_card.dat',points,points.with_suffix('.json'),closed/'candidate-inputs.json',
                     closed/'inputs-after.json',closed/'result.json',closed/'raw/observation.json',closed/'raw/warmup.dat',closed/'raw/ready.json'):
            bind(path)
        for name in lane['numerical_cards']:bind(output/name)
        for section in ('libraries','archives','metadata'):
            for name in lane['runtime'][section]:bind(Path(name))
        cases[key]={'case_id':case_id,'output':str(output),'subprocess':proc.name,
            'generated_sources':bench.generated_sources(output),'numerical_objects':bench.numerical_objects(output),
            'compiler_flags':compilation['effective_compiler_flags'],'runtime':lane['runtime'],
            'numerical_cards':lane['numerical_cards'],'param_card_sha256':lane['param_card_sha256'],
            'points':str(points),'closed_input':str(closed/'candidate-inputs.json'),
            'closed_observation':str(closed/'raw/observation.json'),'closed_warmup':str(closed/'raw/warmup.dat'),
            'expected_codes':codes,'driver_params':compilation['worker_render_parameters'],
            'links':{str(p.relative_to(output)):{'target':str(p.readlink()),'resolved':str(p.resolve())}
                     for p in sorted(output.rglob('*')) if p.is_symlink()},
            'observed_cold_seconds':observed['cold_seconds'],'settings':lane['settings']}
    bind(ROOT/'vendor/tirust/mtirust.f90')
    symbols=read(PROFILE_EXEC/'build/result.json')['variants']['baseline']['symbols']['definitions']
    dump_new(HERE/'input-pins.json',{'schema':'tirust-interface-only-o3-inputs-v1','cases':cases,'files':files,
             'ancestry':ANCESTRY,'expected_mtirust_symbols':sorted(symbols),
             'numerical_sources_changed':False,'Rust_changed':False,'native_executions':0,'compiler_invocations':0})


if __name__=='__main__':main()
