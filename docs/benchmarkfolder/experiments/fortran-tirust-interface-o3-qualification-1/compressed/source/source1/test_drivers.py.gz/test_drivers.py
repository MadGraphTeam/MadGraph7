"""Pure source transformation checks; never compile or run a worker."""
import ast
import hashlib
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()
spec = importlib.util.spec_from_file_location('o3_common_driver', HERE/'drivers.py')
drivers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(drivers)


def original(case, process):
    path = ROOT/'.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate'/case/'SubProcesses'/process/'check_sa.f'
    return path.read_text()


def originals():
    return (original('qcd_n1_uux_z', 'P0_uux_z'), original('qcd_n3_uux_zgg', 'P0_uux_zgg'))


def warmup(text):
    start = text.index("      OPEN(75,FILE='warmup.dat',STATUS='REPLACE')\n")
    end = text.index('      PREVIOUS_SEQUENCE=0\n', start) + len('      PREVIOUS_SEQUENCE=0\n')
    return text[start:end]


def standard_kernel(text):
    start = text.index('      DO L=1,NLOOPS\n         DO K=1,NPOINTS\n')
    end = text.index('      CALL SYSTEM_CLOCK(T1)\n', start) + len('      CALL SYSTEM_CLOCK(T1)\n')
    return text[start:end]


class DriverTests(unittest.TestCase):
    def test_two_exact_frozen_workers_supported(self):
        for text in originals():
            self.assertIn(hashlib.sha256(text.encode()).hexdigest(), drivers.BASE_WORKERS)
            transformed = drivers.worker(text)
            self.assertIn("'EXACTED '", transformed)
            self.assertIn("'ANCHORED '", transformed)
            self.assertIn("'DONE '", transformed)
            self.assertNotIn('DP_PROFILE', transformed)
            self.assertNotIn('QP_PROFILE', transformed)

    def test_drift_and_reapplication_rejected(self):
        text = originals()[0]
        with self.assertRaisesRegex(ValueError, 'unchanged frozen'):
            drivers.worker(text + '\n')
        with self.assertRaisesRegex(ValueError, 'unchanged frozen'):
            drivers.worker(drivers.worker(text))

    def test_learning_and_legacy_timed_math_are_unchanged(self):
        for text in originals():
            transformed = drivers.worker(text)
            self.assertEqual(warmup(text), warmup(transformed))
            self.assertEqual(standard_kernel(text), standard_kernel(transformed))
            self.assertNotIn('O3_CAPTURE_FP', standard_kernel(transformed))
            self.assertNotIn('WRITE', standard_kernel(transformed))

    def test_common_harness_does_not_depend_on_optimization_role(self):
        for text in originals():
            self.assertEqual(drivers.worker(text), drivers.worker(text))
        self.assertEqual(drivers.EXACT.count('SLOOPMATRIX_THRES'), 1)
        self.assertEqual(drivers.ANCHOR.count('SLOOPMATRIX_THRES'), 1)
        self.assertNotIn('candidate', drivers.EXACT.lower())
        self.assertNotIn('original', drivers.EXACT.lower())

    def test_exact_words_precede_any_float_formatting(self):
        block = drivers.EXACT
        call = block.index('CALL ML5_0_SLOOPMATRIX_THRES')
        after = block.index('CALL O3_CAPTURE_FP(O3_FLAGS(:,2)', call)
        first_write = block.index('WRITE(', call)
        self.assertLess(after, first_write)
        self.assertIn('TRANSFER(ANS(:,J)', block)
        self.assertIn('TRANSFER(ACC(MIN(J,NSO))', block)
        self.assertNotIn('ES26.', block)
        self.assertIn("(3I8,10I4)", block)

    def test_batch_ieee_queries_are_outside_timed_math(self):
        text = drivers.worker(originals()[0])
        start = text.index('      TIMED_CODES=0\n      IF(O3_TIMED)')
        clock = text.index('      CALL SYSTEM_CLOCK(T0)\n', start)
        self.assertIn('CALL O3_CAPTURE_FP', text[start:clock])
        end = text.index('      CALL SYSTEM_CLOCK(T1)\n', clock)
        conversion = text.index('      ELAPSED=DBLE(T1-T0)', end)
        self.assertIn('CALL O3_CAPTURE_FP', text[end:conversion])
        self.assertNotIn('O3_CAPTURE_FP', text[clock:end])

    def test_anchor_loop_and_outputs_are_bounded_and_explicit(self):
        block = drivers.ANCHOR
        start = block.index('         CALL SYSTEM_CLOCK(T0)\n')
        end = block.index('         CALL SYSTEM_CLOCK(T1)\n', start)
        kernel = block[start:end]
        self.assertNotIn('WRITE', kernel)
        self.assertNotIn('OPEN', kernel)
        self.assertNotIn('O3_CAPTURE_FP', kernel)
        self.assertIn('IF(NEXTERNAL.NE.5) GOTO 800', block)
        self.assertIn('IF(NLOOPS.NE.1) GOTO 800', block)
        self.assertIn('O3_POINT=16', block)
        for filename in drivers.ANCHOR_FILES:
            self.assertIn(filename, block)

    def test_pinned_ieee_helper_is_copied_without_execution_or_setters(self):
        helper = (ROOT/drivers.CAPTURE_HELPER).read_bytes()
        tree = ast.parse(helper)
        expected = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == 'CAPTURE' for t in n.targets))
        self.assertEqual(drivers.capture_source(), expected.replace('QP_CAPTURE_FP','O3_CAPTURE_FP'))
        upper = drivers.capture_source().upper()
        self.assertNotIn('IEEE_SET_', upper)
        self.assertNotIn('SYSTEM_CLOCK', upper)
        with patch.object(drivers.hashlib, 'sha256') as fake:
            fake.return_value.hexdigest.return_value = 'wrong'
            with self.assertRaisesRegex(ValueError, 'helper changed'):
                drivers.capture_source()

    def test_generated_fixed_form_fits_frozen132_columns(self):
        for text in originals():
            for line in drivers.worker(text).splitlines():
                if line and line[0] not in 'Cc*!':
                    self.assertLessEqual(len(line), 132, line)


if __name__ == '__main__':
    unittest.main()
