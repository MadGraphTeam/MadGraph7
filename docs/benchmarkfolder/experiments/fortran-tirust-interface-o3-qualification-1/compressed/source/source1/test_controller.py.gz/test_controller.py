"""Pure admission, retention, cloning and controller semantics tests."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('o3_test_controller',HERE/'controller.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


class AdmissionTests(unittest.TestCase):
    def test_every_native_stage_requires_exact_review_chain_before_actions(self):
        for stage in c.CAPS:
            needed=c.PREREQUISITES[stage]
            if needed:
                with (patch.object(sys,'argv',['controller.py','--stage',stage,'--execute','--source','a'*64]),
                      patch.object(c,'preflight',side_effect=AssertionError('must reject before checks'))):
                    with self.assertRaises(SystemExit):c.main()
            extra=next((name for name in c.REVIEWED if name not in needed),None)
            if extra:
                args=['controller.py','--stage',stage,'--source','a'*64]
                for name in (*needed,extra):args+=['--reviewed-'+name,'b'*64]
                with patch.object(sys,'argv',args),patch.object(c,'preflight',side_effect=AssertionError('must reject extras')):
                    with self.assertRaises(SystemExit):c.main()

    def test_build_is_one_selected_stage_and_needs_execute(self):
        args=['controller.py','--stage','build','--source','a'*64]
        with (patch.object(sys,'argv',args),patch.object(c,'preflight',return_value={}),
              patch.object(c,'stage',side_effect=AssertionError('unadmitted'))):
            with self.assertRaisesRegex(ValueError,'dormant'):c.main()
        with (patch.object(sys,'argv',args+['--execute']),patch.object(c,'preflight',return_value={}),
              patch.object(c,'verify_predecessors',return_value={}),patch.object(c,'stage') as called):
            c.main();called.assert_called_once_with('build')

    def test_plain_preflight_never_implicitly_executes_stages(self):
        with (patch.object(sys,'argv',['controller.py','--source','a'*64]),
              patch.object(c,'preflight',return_value={'native_scientific_evaluations':0}),
              patch.object(c,'stage',side_effect=AssertionError('native stage')),
              patch('builtins.print') as printed):
            c.main();self.assertTrue(printed.called)

    def test_failed_wrong_phase_and_wrong_source_receipts_rejected(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(c,'REPORT',Path(tmp)):
            folder=Path(tmp)/'build';folder.mkdir();c.EXPECTED_SOURCE='a'*64
            result={'status':'passed','stage':'build','source_index_sha256':'a'*64}
            (folder/'result.json').write_text(json.dumps(result))
            terminal={'status':'failed','stage':'build','source_index_sha256':'a'*64,'returncode':1,
                      'cleanup':{'survivors':[]},'result_sha256':c.digest(folder/'result.json')}
            for change in ({},{'status':'passed','returncode':0,'stage':'n1parity'},
                           {'status':'passed','returncode':0,'stage':'build','source_index_sha256':'b'*64}):
                t={**terminal,**change};(folder/'terminal.json').write_text(json.dumps(t))
                c.REVIEWED['build']=c.digest(folder/'terminal.json')
                with self.assertRaises(ValueError):c.receipt('build')
            terminal.update(status='passed',returncode=0);(folder/'terminal.json').write_text(json.dumps(terminal))
            c.REVIEWED['build']=c.digest(folder/'terminal.json')
            self.assertEqual(c.receipt('build'),result)

    def test_review_chain_cannot_borrow_another_build(self):
        saved=dict(c.REVIEWED)
        try:
            c.REVIEWED.update(build='a'*64,n1parity='b'*64,n1timing='c'*64,n3parity=None)
            with (patch.object(c,'verified_build',return_value={'kind':'build'}),
                  patch.object(c,'receipt',return_value={'reviewed':{'build':'wrong'}})):
                with self.assertRaisesRegex(ValueError,'another build'):c.verify_predecessors('n1timing')
        finally:c.REVIEWED=saved

    def test_owned_cleanup_budget_bounded_and_survivors_rejected(self):
        class Owned:
            def __init__(self,survivors):self.survivors=survivors;self.args=None
            def stop(self,**kwargs):self.args=kwargs;return {'survivors':self.survivors}
        owned=Owned([])
        with patch.object(c.time,'monotonic',return_value=0):c.cleanup_owned(owned,20)
        self.assertAlmostEqual(sum(owned.args.values()),20)
        self.assertLessEqual(sum(owned.args.values()),c.CLEANUP)
        with patch.object(c.time,'monotonic',return_value=0):
            with self.assertRaises(ValueError):c.cleanup_owned(Owned([99]),20)


class PureFileTests(unittest.TestCase):
    def test_clone_dereferences_mutable_cards_and_removes_filters_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'source';source.mkdir();(source/'lib').mkdir()
            resources=source/'SubProcesses/MadLoop5_resources';resources.mkdir(parents=True)
            (resources/'MadLoopParams.dat').write_text('card')
            directory=source/'SubProcesses/P0_test';directory.mkdir()
            (directory/'MadLoop5_resources').symlink_to('../MadLoop5_resources',target_is_directory=True)
            (resources/'xHelFilter.dat').write_text('stale');(directory/'exact-words.dat').write_text('stale')
            destination=root/'private';c.clone(source,destination)
            self.assertTrue((destination/'lib').is_symlink())
            self.assertFalse((destination/'SubProcesses/P0_test/MadLoop5_resources').is_symlink())
            self.assertFalse(list(destination.rglob('*HelFilter.dat')))
            self.assertFalse((destination/'SubProcesses/P0_test/exact-words.dat').exists())
            (destination/'SubProcesses/P0_test/MadLoop5_resources/MadLoopParams.dat').write_text('private')
            self.assertEqual((resources/'MadLoopParams.dat').read_text(),'card')

    def test_historical_word_conversion_preserves_signed_zero(self):
        row={'point':1,'order':0,'status':219,'coefficients':[0.,-0.,1.,2.],'accuracy':-0.}
        words=c.float_rows([row])[0]['words']
        self.assertEqual(words[0],'0000000000000000');self.assertEqual(words[1],'8000000000000000')
        self.assertEqual(words[-1],'8000000000000000')

    def test_policy_capture_records_helpers_and_restores_proxy(self):
        calls=[]
        class FakeProcess:
            PIPE=subprocess.PIPE;STDOUT=subprocess.STDOUT;CalledProcessError=subprocess.CalledProcessError
            @staticmethod
            def run(argv,**kwargs):
                calls.append(list(argv));return subprocess.CompletedProcess(argv,0,'output','' if kwargs.get('stderr')!=subprocess.STDOUT else None)
        real=FakeProcess()
        compiler=types.SimpleNamespace(subprocess=real)
        def capture(directory,env):
            a=compiler.subprocess.run(['make','--dry-run'],cwd=directory,env=env,text=True,stdout=-1,stderr=-1)
            b=compiler.subprocess.check_output(['gfortran','--version'],cwd=directory,env=env,text=True,stderr=-2)
            self.assertEqual(a.stdout,b);return {'policy':'retained'}
        compiler.capture_effective_flags=capture
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)
            with patch.object(c,'modules',return_value=(None,compiler)),patch.object(c,'environment',return_value={'PATH':'frozen'}):
                self.assertEqual(c.capture_policy(path,path/'logs','before'),{'policy':'retained'})
            self.assertIs(compiler.subprocess,real)
            self.assertEqual(len(list((path/'logs').glob('*.command.json'))),2)
            self.assertEqual(len(list((path/'logs').glob('*.terminal.json'))),2)
        self.assertEqual(calls,[['make','--dry-run'],['gfortran','--version']])

    def test_failed_scientific_exact_comparison_retains_diagnostics(self):
        row={'point':1,'order':0,'status':219,'words':['0000000000000000']*5}
        failed={'passed':False,'coefficient_word_differences_count':1}
        analysis=types.SimpleNamespace(exact=lambda *a:[row],ieee=lambda *a,**k:[],compare_variants=lambda *a:failed)
        class Worker:
            sequence=0
            def _send(self,line):self.sent=line
            def _message(self):return ['EXACTED',str(self.sequence)]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);worker=Worker();worker.directory=root/'worker';worker.directory.mkdir()
            for name in ('exact-words.dat','exact-ieee.dat'):(worker.directory/name).write_text('retained')
            with (patch.object(c,'local',return_value=analysis),patch.object(c,'pin',return_value={'expected_codes':{}}),
                  patch.object(c,'historical_exact',return_value=[row]),
                  patch.object(c,'modules',return_value=(types.SimpleNamespace(compare_rows=lambda *a:None),))):
                with self.assertRaisesRegex(ValueError,'historical scientific'):c.exact_command(worker,'n1',root/'exact')
            self.assertEqual(json.loads((root/'exact/historical-comparison.json').read_text()),failed)
            self.assertEqual((root/'exact/exact-words.dat').read_text(),'retained')

    @unittest.skipUnless((HERE/'source-index.json').exists(),'Parent has not sealed the assembled source packet yet')
    def test_actual_preflight_cannot_invoke_subprocesses(self):
        c.EXPECTED_SOURCE=c.digest(HERE/'source-index.json')
        with (patch.object(c.subprocess,'run',side_effect=AssertionError('external program')),
              patch.object(c.subprocess,'Popen',side_effect=AssertionError('external program')),
              patch.object(c.subprocess,'check_output',side_effect=AssertionError('external program'))):
            result=c.preflight()
        self.assertEqual(result['compiler_invocations'],0)
        self.assertEqual(result['loader_queries'],0)
        self.assertEqual(result['native_scientific_evaluations'],0)


if __name__=='__main__':unittest.main()
