# Private one-file Fortran optimization proposal

No native stage has run. Production sources, reducer libraries and public
documentation are unchanged. This proposal is dormant: each native stage
needs a separately reviewed source/predecessor hash and explicit execution.

The completed n1 profile found about2.195µs of kinematic preprocessing and
1.425µs of tensor mapping/finite checks per amplitude in the ordinary interface
compiled without an optimization flag. Those are descriptive, instrumented
shared-host observations. The nested C-evaluation/module intervals must not be
added, probe costs were not subtracted, and the profile establishes no new
comparison with NinjaRS or optimization gain. The closed PROFILE terminal is
`c59cdd7b14b85706df9d28249b3fb2f608532be480a99b51a97a6721760a6568`;
its independent pure audit is pinned in `input-pins.json`.

The only proposed numerical compilation-policy change is:

```text
original TIRUST_interface.f:  -w -fPIC -ffixed-line-length-132
candidate TIRUST_interface.f: -w -fPIC -ffixed-line-length-132 -O3 -fno-fast-math
```

Both variants retain identical Fortran source bytes. The explicit object recipe
in `policy.py` changes no global or inherited FFLAGS; all other object policies,
including the existing polynomial optimization, must match exactly before and
after BUILD. The common word/IEEE driver is identical in both variants. There
are no component clocks, counters or probes in their mathematical routines.
The original installed MTIRUST wrapper archive and Rust DSO remain pinned and
unchanged; no private wrapper/reducer rebuild is proposed.

The coefficient gate is declared **before any candidate execution**. Unlike a
transport or instrumentation change, ordinary `-O3` may change final rounding.
Every raw coefficient/accuracy word difference is retained. Scientific
coefficients must pass the unmodified `tools/tirust_benchmark.py compare_rows`
MadLoop criterion at3e-6 **and its hard1e-8 ordinary target**, for Born and all
three Laurent coefficients, every order and all100 saved points. No new floor
or outcome-dependent relaxation is introduced. Exact identity is preferred,
not required across variants. Finite nonnegative accuracy scores are retained
and compared diagnostically; accepted DP/QP/status maps may not change.
Observed rounding/flag/halting records must match strictly for this proposal.
They are observations, not evidence of trap freedom or absence of exceptions
raised and cleared inside an amplitude call or observer.

The dormant stage sequence is BUILD, N1PARITY, N1TIMING, N3PARITY, and optional
N3ANCHORTIMING. Each fresh worker performs unchanged bootstrap and full100
learning. Original/candidate input-call/point/status histories must match;
coefficient rounding differences use the same scientific gate. An untimed
full100 word/IEEE traversal qualifies each variant. Every timed repeat must
then match that variant's **own** qualified coefficient/accuracy/status words
exactly. Candidate-original residuals must continue to pass1e-8.

The n1 process is `u u~ > z [virt=QCD]`: all100 points have status219 DP.
Seven alternating matched-history pairs each time128 complete traversals,
12,800 physical calls per batch, approximately one second on the recorded host.
Histograms cover all calls; exact numerical words cover the final100 traversal.

The n3 process is `u u~ > z g g [virt=QCD]`. Its current full100 cohort has
87 status219 DP points and13 status323 automatic-QP points, specifically
16,18,21,32,39,52,54,55,65,94,97,98,99. That complete cohort is mandatory:
n1 contains no QP and cannot qualify the QP routines in the optimized file.
Original n3 learning took about73s in its retained run. Optional later anchor
timings use point1 DP with128 calls and point16 automatic-QP with one slow
call per batch, seven alternating pairs each. They are single-point whole
amplitude observations, not full-cohort process runtimes.

The pinned source2 environment provides11 required tools, explicit make/shell/
compiler/nm/taskset/Python paths and original compiler injection `{}`. Pure
preflight checks hashes, executable bits, exact resolution, original cases,
archives, cards, saved points and closed ancestry. It runs no compiler, shell,
loader or scientific evaluation. BUILD reuses existing numerical objects,
compiles only the common driver and TIRust interface in each of four private
case/variant copies, and retains selected commands, effective policies,
prebound inputs, actual linker LOADs, wrapper symbols, PT_INTERP providers and
process maps. Unselected dry-run prerequisites are never executed.

All native gates use nonexclusiveCPU12 and the existing numerical-tests mutex,
16GiB address-space,512MiB file and zero-core limits. Caps are600s BUILD,
300s N1PARITY/N1TIMING and600s N3PARITY/N3ANCHORTIMING, including60s cleanup
reserve. Stages are append-only. The first failure is retained and stops the
admission; there is no retry, dropped point, changed rescue policy or silent
fallback. Prior stages require separate reviewed terminal hashes.

Broader threshold/soft/collinear/small-Gram/complex-mass fixtures, IEEE special
inputs and trap equivalence, rank-six/six-propagator coverage, poles-only
evaluation and internal failure/cache-trace equality remain separate scopes.
None is qualified by this proposal. Precise local runtime acceptance remains
Hua-Sheng's TODO. No candidate is promoted and no gain is claimed here.

From `/shared/external/madloop_tirust/madgraph7_madloop_tirust`:

```sh
python3 -B -m unittest discover -s .tirust-build/fortran-tirust-interface-o3-proposal-1 -p 'test_*.py'
python3 -B .tirust-build/fortran-tirust-interface-o3-proposal-1/controller.py --source SOURCE_INDEX_SHA256
```

The controller's help lists the separately admitted stages and predecessor
arguments. An admitted stage additionally needs `--stage STAGE --execute`.
Work/report destinations are fresh `.tirust-build/fortran-tirust-interface-o3-work-1`
and `.tirust-build/fortran-tirust-interface-o3-execution-1`. This source proposal
does not grant execution admission.
