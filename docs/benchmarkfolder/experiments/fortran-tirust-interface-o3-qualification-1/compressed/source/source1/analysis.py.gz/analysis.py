"""Pure text parsers for the private original/O3 qualification proposal.

No function opens a path or invokes an external tool. IEEE records describe
observed pre/post state; they do not establish trap freedom or identify flags
raised and cleared inside an amplitude evaluation.
"""
from collections import Counter
from collections.abc import Mapping
import math
import re
import statistics
import struct

N3_QP_POINTS=(16,18,21,32,39,52,54,55,65,94,97,98,99)
N1_CODES={point:219 for point in range(1,101)}
N3_CODES={point:(323 if point in N3_QP_POINTS else 219) for point in range(1,101)}
_DECIMAL=re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eEdD][+-]?[0-9]+)?\Z')
_INTEGER=re.compile(r'[+-]?[0-9]+\Z')
_WORD=re.compile(r'[0-9a-fA-F]{16}\Z')


def require(value,message):
    if not value:raise ValueError(message)


def _integer(value,label):
    require(isinstance(value,str) and _INTEGER.fullmatch(value),label+' must be an integer')
    return int(value)


def _positive_integer(value,label):
    require(type(value) is int and value>0,label+' must be a positive integer')
    return value


def _codes(expected_codes):
    require(isinstance(expected_codes,Mapping),'Expected point/status mapping')
    result={}
    for key,value in expected_codes.items():
        require(type(key) is int or isinstance(key,str),'Invalid expected point key')
        point=_integer(key,'Expected point') if isinstance(key,str) else key
        require(point not in result and 1<=point<=100,'Duplicate/out-of-range expected point')
        require(type(value) is int and value in (219,323),'Expected status must be 219 or 323')
        result[point]=value
    require(set(result)==set(range(1,101)),'Expected codes must cover all 100 points')
    return result


def _points(point):
    if point is None:return list(range(1,101))
    require(type(point) is int and 1<=point<=100,'Invalid selected point')
    return [point]


def _lines(text):
    require(isinstance(text,str),'Raw evidence must be text')
    return [line.split() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]


def _word(value):
    require(_WORD.fullmatch(value),'Malformed binary64 word')
    result=value.upper()
    require((int(result,16)>>52)&2047 != 2047,'Nonfinite binary64 word')
    return result


def _nonnegative_accuracy(word):
    bits=int(word,16)
    require(not bits>>63 or bits&((1<<63)-1)==0,'Negative stability estimate')


def _float(value):
    require(isinstance(value,str) and _DECIMAL.fullmatch(value),'Malformed decimal number')
    result=float(value.replace('D','E').replace('d','e'))
    require(math.isfinite(result),'Nonfinite decimal number')
    return result


def _rows(text,expected_codes,point,decimal):
    codes=_codes(expected_codes);points=_points(point);rows=[]
    for fields in _lines(text):
        require(len(fields)==8,'Malformed answer row')
        p,order,status=(_integer(value,'Answer field') for value in fields[:3])
        require(p in codes and status==codes[p],'Unexpected public status or rescue selection')
        if decimal:
            values=[_float(value) for value in fields[3:]]
            words=[struct.pack('>d',value).hex().upper() for value in values]
        else:words=[_word(value) for value in fields[3:]]
        _nonnegative_accuracy(words[-1])
        rows.append({'point':p,'order':order,'status':status,'words':words})
    require([(row['point'],row['order']) for row in rows]==[(p,o) for p in points for o in (0,1)],
            'Answer rows must contain every requested point and both orders exactly once')
    return rows


def exact(text,expected_codes,point=None):
    """Parse five raw binary64 words per total/split-order answer row."""
    return _rows(text,expected_codes,point,False)


def decimal_exact(text,expected_codes,point=None):
    """Parse retained decimal answers into the same exact-word row format."""
    return _rows(text,expected_codes,point,True)


def ieee(text,points=range(1,101)):
    """Parse point/phase/rounding + five flags + five halting observations."""
    points=list(points)
    require(points and all(type(point) is int and 0<=point<=100 for point in points)
            and len(points)==len(set(points)),'Invalid requested IEEE point sequence')
    rows=[]
    for fields in _lines(text):
        require(len(fields)==13,'Malformed IEEE observation')
        row=[_integer(value,'IEEE field') for value in fields]
        require(row[2] in range(-1,5) and all(value in (-1,0,1) for value in row[3:]),
                'Invalid IEEE rounding/flag/halting observation')
        rows.append(row)
    require([row[:2] for row in rows]==[[point,phase] for point in points for phase in (1,2)],
            'IEEE observations must contain both phases for every requested point once')
    return rows


def status_histogram(text,expected_codes,loops,point=None):
    """Require the full timed-call histogram, including every loop repetition."""
    codes=_codes(expected_codes);loops=_positive_integer(loops,'Loop count')
    wanted=Counter(codes[p] for p in _points(point));actual={}
    for fields in _lines(text):
        require(len(fields)==2,'Malformed status histogram')
        code,count=(_integer(value,'Histogram field') for value in fields)
        require(code in (219,323) and count>0 and code not in actual,'Invalid/duplicate timed status')
        actual[code]=count
    require(actual=={code:count*loops for code,count in wanted.items()},'Timed status count/precision distribution differs')
    return {str(code):actual[code] for code in sorted(actual)}


def anchor_outputs(raw,expected_codes,*,point,loops):
    """Parse a standalone point1-DP or point16-QP timing record and all joins.

    ``raw`` maps the five anchor filenames to text. The timer covers the same
    repeated public-call setup and amplitude kernel as the full100 worker;
    output formatting and IEEE snapshots are outside that clock. A QP anchor
    is exactly one call per matched-history batch.
    """
    require(isinstance(raw,Mapping),'Expected raw-text mapping')
    require(type(point) is int and point in (1,16),'Anchor must be point1 or point16')
    codes=_codes(expected_codes);loops=_positive_integer(loops,'Loop count')
    require(codes[point]==(219 if point==1 else 323),'Anchor does not select its qualified precision')
    require(point!=16 or loops==1,'QP anchor requires a single call')
    names=('anchor-timing.dat','anchor-status.dat','anchor-exact.dat','anchor-ieee.dat','anchor-values.dat')
    require(all(name in raw for name in names),'Missing anchor raw output')
    timing=_lines(raw['anchor-timing.dat'])
    require(len(timing)==1 and len(timing[0])==2,'Malformed anchor timing')
    cold,seconds=map(_float,timing[0]);require(cold>0 and seconds>0,'Nonpositive anchor elapsed time')
    rows=exact(raw['anchor-exact.dat'],codes,point)
    require(decimal_exact(raw['anchor-values.dat'],codes,point)==rows,'Anchor decimal/raw-word answers differ')
    return {'point':point,'loops':loops,'cold_seconds':cold,'seconds':seconds,
            'seconds_per_call':seconds/loops,'rows':rows,
            'ieee':ieee(raw['anchor-ieee.dat'],[point]),
            'timed_status_counts':status_histogram(raw['anchor-status.dat'],codes,loops,point),
            'scope':'Standalone whole-amplitude anchor, not a full100-process runtime.',
            'performance_acceptance':False}


def timing_summary(pairs):
    """Recompute descriptive ratios for at least seven alternating pairs."""
    require(isinstance(pairs,(list,tuple)) and len(pairs)>=7,'At least seven matched pairs are required')
    ratios=[];seconds={'original':[],'candidate':[]}
    for index,row in enumerate(pairs,1):
        require(isinstance(row,Mapping) and type(row.get('pair')) is int and row['pair']==index,'Pair sequence differs')
        order=['original','candidate'] if index%2 else ['candidate','original']
        require(row.get('order')==order,'Matched-history pair order is not the fixed alternating schedule')
        for role in seconds:
            value=row.get(role)
            require(isinstance(value,Mapping),'Missing matched-history role')
            elapsed=value.get('seconds')
            require(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>0,'Invalid timed elapsed')
            seconds[role].append(elapsed)
        ratio=seconds['candidate'][-1]/seconds['original'][-1]
        require(math.isfinite(ratio) and ratio>0,'Invalid paired ratio')
        ratios.append(ratio)
    return {'pairs':len(pairs),'ratios':ratios,'median_ratio':statistics.median(ratios),
            'minimum_ratio':min(ratios),'maximum_ratio':max(ratios),
            'median_seconds':{role:statistics.median(values) for role,values in seconds.items()},
            'performance_acceptance':False,'speedup_claimed':False,
            'interpretation':'Descriptive shared-host paired timings; no performance acceptance or speedup claim.'}


def _comparison_rows(rows,label):
    require(isinstance(rows,(list,tuple)) and len(rows) in (2,200),
            label+' must contain all 100 points or one two-order anchor')
    decoded=[];normalized=[]
    for row in rows:
        require(isinstance(row,Mapping),'Malformed '+label+' comparison row')
        point,order,status=(row.get(name) for name in ('point','order','status'))
        require(type(point) is int and 1<=point<=100 and type(order) is int and order in (0,1),
                'Invalid '+label+' point/order')
        require(type(status) is int and status in (219,323),'Invalid '+label+' public status')
        values=row.get('words')
        require(isinstance(values,(list,tuple)) and len(values)==5 and all(isinstance(v,str) for v in values),
                'Malformed '+label+' exact words')
        words=[_word(value) for value in values];_nonnegative_accuracy(words[-1])
        numbers=[struct.unpack('>d',bytes.fromhex(value))[0] for value in words]
        normalized.append({'point':point,'order':order,'status':status,'words':words})
        decoded.append({'point':point,'order':order,'status':status,'coefficients':numbers[:4],'accuracy':numbers[4]})
    points=list(range(1,101)) if len(rows)==200 else [normalized[0]['point']]
    require([(row['point'],row['order']) for row in normalized]==[(point,order) for point in points for order in (0,1)],
            label+' comparison rows have a missing, duplicate or reordered point/order')
    require(all(normalized[i]['status']==normalized[i+1]['status'] for i in range(0,len(rows),2)),
            label+' split orders have inconsistent public status')
    return normalized,decoded


def compare_variants(original_rows,candidate_rows,compare_rows_fn):
    """Apply the existing MadLoop criterion at both predeclared tolerances.

    Point/order/status changes are hard failures. Coefficient and accuracy word
    differences are retained as diagnostics; accuracy differences do not enter
    the physics criterion. The caller supplies the unchanged existing
    ``tirust_benchmark.compare_rows`` function. No replacement floor, residual
    rule or rounding is introduced here. IEEE parity is a separate caller gate.
    """
    require(callable(compare_rows_fn),'Expected the existing numerical comparator')
    left,left_values=_comparison_rows(original_rows,'Original')
    right,right_values=_comparison_rows(candidate_rows,'Candidate')
    require([(r['point'],r['order'],r['status']) for r in left]==
            [(r['point'],r['order'],r['status']) for r in right],
            'Original/candidate point/order/status differs')
    coefficient_differences=[];accuracy_differences=[]
    for lrow,rrow,lvalues,rvalues in zip(left,right,left_values,right_values):
        for column,(lword,rword) in enumerate(zip(lrow['words'][:4],rrow['words'][:4])):
            if lword!=rword:
                a=lvalues['coefficients'][column];b=rvalues['coefficients'][column]
                coefficient_differences.append({'point':lrow['point'],'order':lrow['order'],'column':column,
                    'original_word':lword,'candidate_word':rword,'original_value':a,'candidate_value':b,
                    'values_equal':a==b})
        if lrow['words'][4]!=rrow['words'][4]:
            a=lvalues['accuracy'];b=rvalues['accuracy']
            accuracy_differences.append({'point':lrow['point'],'order':lrow['order'],
                'original_word':lrow['words'][4],'candidate_word':rrow['words'][4],
                'original_value':a,'candidate_value':b,'value_difference':b-a,
                'absolute_value_difference':abs(b-a),'values_equal':a==b})
    regression=compare_rows_fn(left_values,right_values,tolerance=3e-6)
    ordinary=compare_rows_fn(left_values,right_values,tolerance=1e-8)
    for result in (regression,ordinary):
        require(isinstance(result,Mapping) and type(result.get('passed')) is bool,
                'Existing numerical comparator returned an invalid result')
    return {'passed':regression['passed'] and ordinary['passed'],
            'regression_passed':regression['passed'],'ordinary_target_passed':ordinary['passed'],
            'regression':regression,'ordinary_target':ordinary,
            'regression_tolerance':3e-6,'ordinary_target_tolerance':1e-8,
            'rows_compared':len(left),'coefficient_values_compared':4*len(left),
            'point_order_status_equal':True,
            'coefficient_word_differences':coefficient_differences,
            'accuracy_differences':accuracy_differences,
            'coefficient_word_difference_count':len(coefficient_differences),
            'accuracy_difference_count':len(accuracy_differences),
            'all_coefficient_words_equal':not coefficient_differences,
            'all_accuracy_words_equal':not accuracy_differences,
            'accuracy_comparison_scope':'Finite nonnegative accuracy words/values are diagnostic only.',
            'ieee_comparison_scope':'Separate strict observed-state parity gate; no trap-freedom claim.',
            'physics_comparison_scope':'Existing comparator applied unchanged to all four coefficients and every retained order/point.'}
