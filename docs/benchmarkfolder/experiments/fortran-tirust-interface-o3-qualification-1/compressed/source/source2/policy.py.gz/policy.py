"""One-file optimization policy and strict selected-command parser; pure only."""
from pathlib import Path
import shlex
import shutil

ORIGINAL_FLAGS=['-w','-fPIC','-ffixed-line-length-132']
CANDIDATE_ADDITIONS=['-O3','-fno-fast-math']
TARGET='TIRUST_interface.f'
NEEDED=('check_sa.f',TARGET)


def require(value,message):
    if not value:raise ValueError(message)


def private_makefile(text,candidate=False):
    old='$(FC) $(FFLAGS) -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)'
    new='$(FC) $(FFLAGS) -Wl,-Map,private-link.map,--cref -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)'
    require(text.count(old)==1,'Original check link recipe is not unique')
    require('TIRUST_interface.o:' not in text,'Unexpected existing explicit interface recipe')
    flags=' '+' '.join(CANDIDATE_ADDITIONS) if candidate else ''
    # An explicit recipe avoids target-specific variable inheritance into the
    # polynomial prerequisite or any other object. Global FFLAGS are untouched.
    recipe='''
# Private controlled experiment: only this source receives additional flags.
TIRUST_interface.o: TIRUST_interface.f $(POLYNOMIAL) $(OLP_POLYNOMIAL)
\t$(FC) $(FFLAGS)'''+flags+''' -c $< -o $@ $(LOOP_INCLUDE)
'''
    return text.replace(old,new,1)+recipe


def verify_policy(original,actual,candidate,compiler_module):
    require(original['environment']==actual['environment'],'Compiler injected environment changed')
    require(original['environment']=={},'This proposal qualifies the frozen empty compiler environment only')
    require(set(original['scopes'])==set(actual['scopes']),'Compiler scopes changed')
    changes=[]
    for scope,left in original['scopes'].items():
        right=actual['scopes'][scope]
        require(set(left['recipes'])==set(right['recipes']),'Missing or extra numerical source recipe: '+scope)
        for name,wanted in left['recipes'].items():
            observed=right['recipes'][name]
            expected=dict(wanted)
            if scope=='process' and name==TARGET:
                require(wanted['flags']==ORIGINAL_FLAGS,'Frozen ordinary interface flags differ')
                if candidate:
                    expected['flags']=wanted['flags']+CANDIDATE_ADDITIONS
                    changes.append(scope+'/'+name)
            require(compiler_module._signature(observed)==compiler_module._signature(expected),
                    'Unexpected compiler/flag change: '+scope+'/'+name)
    require(changes==(['process/'+TARGET] if candidate else []),'Candidate flag change is not unique')
    return {'changed_recipes':changes,'candidate_additions':CANDIDATE_ADDITIONS if candidate else [],
            'all_other_compiler_policies_preserved':True,'native_queries_by_verifier':0}


def select_commands(output,expected_compiler,environment):
    selected={};links=[]
    for line in output.replace('\\\n',' ').splitlines():
        argv=shlex.split(line)
        if not argv:continue
        sources=[t for t in argv if not t.startswith('-') and Path(t).suffix.lower() in {'.f','.for','.f90','.f95','.f03','.f08'}]
        wanted=[s for s in sources if Path(s).name in NEEDED]
        outputs=[argv[i+1] for i,t in enumerate(argv[:-1]) if t=='-o']
        link='-c' not in argv and 'check' in outputs
        if not wanted and not link:continue
        require(not any(t in {';','&&','||','|','>','>>','<','&'} for t in argv),'Compound selected recipe')
        resolved=shutil.which(argv[0],path=environment.get('PATH'))
        require(resolved and Path(resolved).resolve()==Path(expected_compiler).resolve(),'Unexpected selected compiler')
        require(argv.count('-o')==1 and len(outputs)==1 and not any(t.startswith('@') for t in argv),
                'Ambiguous selected output or response file')
        if link:
            require(not sources and outputs==['check'],'Unexpected link input source/output')
            require('-ltirust' in argv and 'mtirust.o' not in argv and 'qp_profile.o' not in argv,
                    'Link must preserve the existing wrapper archive')
            links.append(argv)
        else:
            require(argv.count('-c')==1 and len(sources)==1 and len(wanted)==1
                    and sources[0]==Path(sources[0]).name,'Unexpected selected compilation source')
            name=sources[0]
            require(outputs==[Path(name).stem+'.o'] and name not in selected,'Wrong/duplicate selected object')
            selected[name]=argv
    require(set(selected)==set(NEEDED),'Expected exactly the common driver and TIRust interface compilations')
    require(len(links)==1,'Expected one selected check link')
    return [(name,selected[name]) for name in NEEDED],links[0]
