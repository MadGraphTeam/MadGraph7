"""Pure admission, retention, cloning and controller semantics tests."""
import importlib.util
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import struct
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('o3_test_controller',HERE/'controller.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
analysis_spec=importlib.util.spec_from_file_location('o3_test_controller_analysis',HERE/'analysis.py')
analysis=importlib.util.module_from_spec(analysis_spec);analysis_spec.loader.exec_module(analysis)


def exact_rows(accuracy=1e-6,points=(1,)):
    words=[struct.pack('>d',number).hex().upper() for number in (1.,2.,3.,4.,accuracy)]
    return [{'point':point,'order':order,'status':219,'words':list(words)} for point in points for order in (0,1)]


class AdmissionTests(unittest.TestCase):
    def test_every_native_stage_requires_exact_review_chain_before_actions(self):
        for stage in c.CAPS:
            needed=c.PREREQUISITES[stage]
            if needed:
                with (patch.object(sys,'argv',['controller.py','--stage',stage,'--execute','--source','a'*64]),
                      patch.object(c,'preflight',side_effect=AssertionError('must reject before checks'))):
                    with self.assertRaises(SystemExit):c.main()
            extra=next((name for name in c.REVIEWED if name not in needed),None)
            if extra:
                args=['controller.py','--stage',stage,'--source','a'*64]
                for name in (*needed,extra):args+=['--reviewed-'+name,'b'*64]
                with patch.object(sys,'argv',args),patch.object(c,'preflight',side_effect=AssertionError('must reject extras')):
                    with self.assertRaises(SystemExit):c.main()

    def test_build_is_one_selected_stage_and_needs_execute(self):
        args=['controller.py','--stage','build','--source','a'*64]
        with (patch.object(sys,'argv',args),patch.object(c,'preflight',return_value={}),
              patch.object(c,'stage',side_effect=AssertionError('unadmitted'))):
            with self.assertRaisesRegex(ValueError,'dormant'):c.main()
        with (patch.object(sys,'argv',args+['--execute']),patch.object(c,'preflight',return_value={}),
              patch.object(c,'verify_predecessors',return_value={}),patch.object(c,'stage') as called):
            c.main();called.assert_called_once_with('build')

    def test_plain_preflight_never_implicitly_executes_stages(self):
        with (patch.object(sys,'argv',['controller.py','--source','a'*64]),
              patch.object(c,'preflight',return_value={'native_scientific_evaluations':0}),
              patch.object(c,'stage',side_effect=AssertionError('native stage')),
              patch('builtins.print') as printed):
            c.main();self.assertTrue(printed.called)

    def test_failed_wrong_phase_and_wrong_source_receipts_rejected(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(c,'REPORT',Path(tmp)):
            folder=Path(tmp)/'build';folder.mkdir();c.EXPECTED_SOURCE='a'*64
            result={'status':'passed','stage':'build','source_index_sha256':'a'*64}
            (folder/'result.json').write_text(json.dumps(result))
            terminal={'status':'failed','stage':'build','source_index_sha256':'a'*64,'returncode':1,
                      'cleanup':{'survivors':[]},'result_sha256':c.digest(folder/'result.json')}
            for change in ({},{'status':'passed','returncode':0,'stage':'n1parity'},
                           {'status':'passed','returncode':0,'stage':'build','source_index_sha256':'b'*64}):
                t={**terminal,**change};(folder/'terminal.json').write_text(json.dumps(t))
                c.REVIEWED['build']=c.digest(folder/'terminal.json')
                with self.assertRaises(ValueError):c.receipt('build')
            terminal.update(status='passed',returncode=0);(folder/'terminal.json').write_text(json.dumps(terminal))
            c.REVIEWED['build']=c.digest(folder/'terminal.json')
            self.assertEqual(c.receipt('build'),result)

    def test_review_chain_cannot_borrow_another_build(self):
        saved=dict(c.REVIEWED)
        try:
            c.REVIEWED.update(build='a'*64,n1parity='b'*64,n1timing='c'*64,n3parity=None)
            with (patch.object(c,'verified_build',return_value={'kind':'build'}),
                  patch.object(c,'receipt',return_value={'reviewed':{'build':'wrong'}})):
                with self.assertRaisesRegex(ValueError,'another build'):c.verify_predecessors('n1timing')
        finally:c.REVIEWED=saved

    def test_owned_cleanup_budget_bounded_and_survivors_rejected(self):
        class Owned:
            def __init__(self,survivors):self.survivors=survivors;self.args=None
            def stop(self,**kwargs):self.args=kwargs;return {'survivors':self.survivors}
        owned=Owned([])
        with patch.object(c.time,'monotonic',return_value=0):c.cleanup_owned(owned,20)
        self.assertAlmostEqual(sum(owned.args.values()),20)
        self.assertLessEqual(sum(owned.args.values()),c.CLEANUP)
        with patch.object(c.time,'monotonic',return_value=0):
            with self.assertRaises(ValueError):c.cleanup_owned(Owned([99]),20)


class PureFileTests(unittest.TestCase):
    def test_fresh_namespace_and_predeclared_anchor_counts(self):
        self.assertEqual(c.N1_LOOPS,128)
        self.assertEqual(c.ANCHORS,(('DP',1,15),('QP',16,1)))
        self.assertTrue(str(c.WORK).endswith('/fortran-tirust-interface-o3-work-2'))
        self.assertTrue(str(c.REPORT).endswith('/fortran-tirust-interface-o3-execution-2'))

    def test_unadmitted_source1_exact_inventory_and_index_are_guarded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);old=root/'old';old.mkdir();new=root/'new';new.mkdir()
            (old/'source-index.json').write_text('sealed');(old/'payload.txt').write_text('old')
            data={'predecessor_source':'old','predecessor_source_index_sha256':c.digest(old/'source-index.json'),
                  'predecessor_files':{name:c.digest(old/name) for name in ('source-index.json','payload.txt')}}
            (new/'predecessor.json').write_text(json.dumps(data))
            with patch.object(c,'ROOT',root),patch.object(c,'HERE',new):
                self.assertEqual(c.verify_predecessor()['payloads'],2)
                (old/'extra.txt').write_text('extra')
                with self.assertRaisesRegex(ValueError,'inventory'):c.verify_predecessor()
                (old/'extra.txt').unlink();(old/'payload.txt').write_text('changed')
                with self.assertRaisesRegex(ValueError,'bytes changed'):c.verify_predecessor()
    def test_clone_dereferences_mutable_cards_and_removes_filters_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'source';source.mkdir();(source/'lib').mkdir()
            resources=source/'SubProcesses/MadLoop5_resources';resources.mkdir(parents=True)
            (resources/'MadLoopParams.dat').write_text('card')
            directory=source/'SubProcesses/P0_test';directory.mkdir()
            (directory/'MadLoop5_resources').symlink_to('../MadLoop5_resources',target_is_directory=True)
            (resources/'xHelFilter.dat').write_text('stale');(directory/'exact-words.dat').write_text('stale')
            destination=root/'private';c.clone(source,destination)
            self.assertTrue((destination/'lib').is_symlink())
            self.assertFalse((destination/'SubProcesses/P0_test/MadLoop5_resources').is_symlink())
            self.assertFalse(list(destination.rglob('*HelFilter.dat')))
            self.assertFalse((destination/'SubProcesses/P0_test/exact-words.dat').exists())
            (destination/'SubProcesses/P0_test/MadLoop5_resources/MadLoopParams.dat').write_text('private')
            self.assertEqual((resources/'MadLoopParams.dat').read_text(),'card')

    def test_historical_word_conversion_preserves_signed_zero(self):
        row={'point':1,'order':0,'status':219,'coefficients':[0.,-0.,1.,2.],'accuracy':-0.}
        words=c.float_rows([row])[0]['words']
        self.assertEqual(words[0],'0000000000000000');self.assertEqual(words[1],'8000000000000000')
        self.assertEqual(words[-1],'8000000000000000')

    def test_policy_capture_records_helpers_and_restores_proxy(self):
        calls=[]
        class FakeProcess:
            PIPE=subprocess.PIPE;STDOUT=subprocess.STDOUT;CalledProcessError=subprocess.CalledProcessError
            @staticmethod
            def run(argv,**kwargs):
                calls.append(list(argv));return subprocess.CompletedProcess(argv,0,'output','' if kwargs.get('stderr')!=subprocess.STDOUT else None)
        real=FakeProcess()
        compiler=types.SimpleNamespace(subprocess=real)
        def capture(directory,env):
            a=compiler.subprocess.run(['make','--dry-run'],cwd=directory,env=env,text=True,stdout=-1,stderr=-1)
            b=compiler.subprocess.check_output(['gfortran','--version'],cwd=directory,env=env,text=True,stderr=-2)
            self.assertEqual(a.stdout,b);return {'policy':'retained'}
        compiler.capture_effective_flags=capture
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)
            with patch.object(c,'modules',return_value=(None,compiler)),patch.object(c,'environment',return_value={'PATH':'frozen'}):
                self.assertEqual(c.capture_policy(path,path/'logs','before'),{'policy':'retained'})
            self.assertIs(compiler.subprocess,real)
            self.assertEqual(len(list((path/'logs').glob('*.command.json'))),2)
            self.assertEqual(len(list((path/'logs').glob('*.terminal.json'))),2)
        self.assertEqual(calls,[['make','--dry-run'],['gfortran','--version']])

    def test_failed_scientific_exact_comparison_retains_diagnostics(self):
        row={'point':1,'order':0,'status':219,'words':['0000000000000000']*5}
        failed={'passed':False,'coefficient_word_differences_count':1}
        analysis=types.SimpleNamespace(exact=lambda *a:[row],ieee=lambda *a,**k:[],compare_variants=lambda *a:failed)
        class Worker:
            sequence=0
            def _send(self,line):self.sent=line
            def _message(self):return ['EXACTED',str(self.sequence)]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);worker=Worker();worker.directory=root/'worker';worker.directory.mkdir()
            for name in ('exact-words.dat','exact-ieee.dat'):(worker.directory/name).write_text('retained')
            with (patch.object(c,'local',return_value=analysis),patch.object(c,'pin',return_value={'expected_codes':{}}),
                  patch.object(c,'historical_exact',return_value=[row]),
                  patch.object(c,'modules',return_value=(types.SimpleNamespace(compare_rows=lambda *a:None),))):
                with self.assertRaisesRegex(ValueError,'historical scientific'):c.exact_command(worker,'n1',root/'exact')
            self.assertEqual(json.loads((root/'exact/historical-comparison.json').read_text()),failed)
            self.assertEqual((root/'exact/exact-words.dat').read_text(),'retained')

    @unittest.skipUnless((HERE/'source-index.json').exists(),'Parent has not sealed the assembled source packet yet')
    def test_actual_preflight_cannot_invoke_subprocesses(self):
        c.EXPECTED_SOURCE=c.digest(HERE/'source-index.json')
        with (patch.object(c.subprocess,'run',side_effect=AssertionError('external program')),
              patch.object(c.subprocess,'Popen',side_effect=AssertionError('external program')),
              patch.object(c.subprocess,'check_output',side_effect=AssertionError('external program'))):
            result=c.preflight()
        self.assertEqual(result['compiler_invocations'],0)
        self.assertEqual(result['loader_queries'],0)
        self.assertEqual(result['native_scientific_evaluations'],0)


class OwnReferenceTests(unittest.TestCase):
    def test_accuracy_only_fresh_drift_is_accepted_and_recorded(self):
        reference=exact_rows(1e-6);actual=exact_rows(2e-6)
        with tempfile.TemporaryDirectory() as tmp:
            report=c.own_comparison(reference,actual,Path(tmp),'fresh-own',analysis)
            self.assertTrue(report['passed']);self.assertEqual(report['accuracy_drift_count'],2)
            self.assertTrue(report['coeff_exact']);self.assertTrue(report['status_equal'])
            self.assertEqual(json.loads((Path(tmp)/'fresh-own.json').read_text()),report)

    def test_accuracy_only_repeat_reports_parity_and_previous_batch_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            reports=c.timed_own_comparisons(exact_rows(1e-6),exact_rows(2e-6),exact_rows(3e-6),Path(tmp),analysis)
            self.assertEqual(set(reports),{'qualified_parity','previous_batch'})
            self.assertTrue(all(report['passed'] and report['accuracy_drift'] for report in reports.values()))
            self.assertNotEqual(reports['qualified_parity']['accuracy_differences'][0]['reference_word'],
                                reports['previous_batch']['accuracy_differences'][0]['reference_word'])
            self.assertEqual(json.loads((Path(tmp)/'own-comparisons.json').read_text()),reports)

    def test_coefficient_or_status_mutation_fails_with_both_reports_retained(self):
        for label in ('coefficient','status'):
            reference=exact_rows();actual=copy.deepcopy(reference)
            if label=='coefficient':actual[0]['words'][0]=struct.pack('>d',1.25).hex().upper()
            else:
                for row in actual:row['status']=323
            with tempfile.TemporaryDirectory() as tmp:
                with self.assertRaisesRegex(ValueError,'coefficient/status'):
                    c.timed_own_comparisons(reference,reference,actual,Path(tmp),analysis)
                reports=json.loads((Path(tmp)/'own-comparisons.json').read_text())
                self.assertFalse(reports['qualified_parity']['passed'])
                self.assertFalse(reports['previous_batch']['passed'])

    def test_timing_accepts_accuracy_history_and_retains_role_references(self):
        points=range(1,101);qualified=exact_rows(1e-6,points);codes={str(point):219 for point in points}
        flags=[[point,phase,1,*([0]*10)] for point in points for phase in (1,2)]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);workers={}
            class Worker:
                def __init__(self,role):
                    self.sequence=0;self.role=role;self.calls=0;self.directory=root/'workers'/role
                    self.directory.mkdir(parents=True)
                def _send(self,line):
                    command,sequence,loops=line.split();self.calls+=1
                    self.reply=['DONE',sequence,loops]
                    rows=exact_rows((self.calls+2)*1e-6,points)
                    text=''.join(f"{row['point']} {row['order']} {row['status']} "+' '.join(row['words'])+'\n' for row in rows)
                    decimal=''.join(f"{row['point']} {row['order']} {row['status']} "+' '.join(
                        format(struct.unpack('>d',bytes.fromhex(word))[0],'.17e') for word in row['words'])+'\n' for row in rows)
                    outputs={'timing.dat':'0.1 1.0\n','values.dat':decimal,'timed_status.dat':'219 12800\n',
                             'timed-exact-words.dat':text,'timed-ieee.dat':'0 1 1 '+'0 '*10+'\n0 2 1 '+'0 '*10+'\n'}
                    for name,value in outputs.items():(self.directory/name).write_text(value)
                def _message(self):return self.reply
            variants={'n1/'+role:{'output':str(root/'build'/role)} for role in c.VARIANTS}
            prior={'build':{'variants':variants},'n1parity':{'lanes':{role:{'rows':qualified,'ieee':flags} for role in c.VARIANTS}}}
            def start(output,case,role,built,report,stack):
                worker=Worker(role);workers[role]=worker;return worker,{}
            bench=types.SimpleNamespace(compare_rows=lambda *a,**k:{'passed':True})
            with (patch.object(c,'REPORT',root/'report'),patch.object(c,'WORK',root/'work'),
                  patch.object(c,'verify_predecessors',return_value=prior),patch.object(c,'protected',return_value={'same':True}),
                  patch.object(c,'local',return_value=analysis),patch.object(c,'clone'),patch.object(c,'start_worker',side_effect=start),
                  patch.object(c,'exact_command',return_value={'rows':exact_rows(2e-6,points),'ieee':flags}),
                  patch.object(c,'pin',return_value={'expected_codes':codes}),patch.object(c,'finish_worker'),
                  patch.object(c,'modules',return_value=(bench,None,None,
                      lambda *a,**k:{'seconds':1.,'timed_status_counts':{'219':12800}})),
                  patch.object(c,'result_base',return_value={'status':'passed'})):
                c.timing('n1','n1timing')
            result=json.loads((root/'report/n1timing/result.json').read_text())
            self.assertEqual([workers[role].calls for role in c.VARIANTS],[7,7])
            self.assertTrue(all(value['accuracy_drift'] for value in result['fresh_own_comparisons'].values()))
            pairs=result['scopes']['full100']['pairs']
            for role in c.VARIANTS:
                self.assertEqual(pairs[0][role]['previous_batch_reference'],'fresh_full100_exact')
                self.assertEqual(pairs[1][role]['previous_batch_reference'],'pair-1')
                self.assertTrue(all(pair[role]['own_comparisons']['qualified_parity']['passed'] for pair in pairs))
                self.assertTrue(all(pair[role]['own_comparisons']['previous_batch']['accuracy_drift'] for pair in pairs))


if __name__=='__main__':unittest.main()
