"""Pure parser tests; no recorded host path, compiler or native execution."""
import copy
import ast
import importlib.util
from pathlib import Path
import struct
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('o3_analysis',HERE/'analysis.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def existing_comparator():
    """Load only the unchanged pure function, without importing benchmark IO."""
    source=HERE.parents[1]/'tools/tirust_benchmark.py'
    tree=ast.parse(source.read_text(),filename=str(source))
    functions=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='compare_rows']
    if len(functions)!=1:raise ValueError('Existing numerical comparator missing/ambiguous')
    namespace={}
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),namespace)
    return namespace['compare_rows']


COMPARE_ROWS=existing_comparator()


def word(value):return struct.pack('>d',value).hex().upper()


def exact_text(codes=a.N1_CODES,point=None):
    points=range(1,101) if point is None else [point]
    return ''.join(f'{p} {o} {codes[p]} '+' '.join(map(word,[1.,-0.,-2.,0.5,-0.]))+'\n'
                   for p in points for o in (0,1))


def decimal_text(codes=a.N1_CODES,point=None):
    points=range(1,101) if point is None else [point]
    return ''.join(f'{p} {o} {codes[p]} 1.0D0 -0.0 -2.0E0 .5 -0.0\n' for p in points for o in (0,1))


def ieee_text(points=range(1,101)):
    return ''.join(f'{p} {phase} 1 '+' '.join(['0']*10)+'\n' for p in points for phase in (1,2))


def pairs():
    return [{'pair':i,'order':['original','candidate'] if i%2 else ['candidate','original'],
             'original':{'seconds':1.},'candidate':{'seconds':0.9+i/100.}} for i in range(1,8)]


class ExactTests(unittest.TestCase):
    def test_dp_and_auto_qp_shapes_and_signed_zero(self):
        n1=a.exact(exact_text(),a.N1_CODES)
        n3=a.exact(exact_text(a.N3_CODES),a.N3_CODES)
        self.assertEqual(len(n1),200);self.assertEqual(len(n3),200)
        self.assertEqual(n1[0]['words'][1],word(-0.));self.assertEqual(n1[0]['words'][-1],word(-0.))
        self.assertEqual(sum(row['status']==323 for row in n3),26)
        self.assertEqual(n3[30]['point'],16);self.assertEqual(n3[30]['status'],323)

    def test_decimal_roundtrip_uses_the_same_exact_row_format(self):
        self.assertEqual(a.decimal_exact(decimal_text(a.N3_CODES),a.N3_CODES),a.exact(exact_text(a.N3_CODES),a.N3_CODES))
        self.assertEqual(a.exact(exact_text(a.N3_CODES,16),a.N3_CODES,16),
                         a.decimal_exact(decimal_text(a.N3_CODES,16),a.N3_CODES,16))

    def test_json_string_expected_keys_supported_without_collisions(self):
        self.assertEqual(a.exact(exact_text(),{str(k):v for k,v in a.N1_CODES.items()}),a.exact(exact_text(),a.N1_CODES))
        bad=dict(a.N1_CODES);bad['1']=219
        with self.assertRaises(ValueError):a.exact(exact_text(),bad)

    def test_missing_duplicate_reordered_and_wrong_precision_rows_rejected(self):
        text=exact_text(a.N3_CODES);rows=text.splitlines(True)
        for bad in (''.join(rows[1:]),text+rows[0],''.join([rows[1],rows[0],*rows[2:]]),text.replace('16 0 323','16 0 219')):
            with self.assertRaises(ValueError):a.exact(bad,a.N3_CODES)

    def test_nonfinite_and_negative_accuracy_rejected(self):
        for bad in (exact_text().replace(word(1.),'7FF0000000000000',1),
                    exact_text().replace(word(1.),'FFF8000000000000',1),
                    exact_text().replace(word(-0.)+'\n',word(-1.)+'\n',1)):
            with self.assertRaises(ValueError):a.exact(bad,a.N1_CODES)
        for bad in ('nan','inf','1e999','1_0','0x1p0'):
            with self.assertRaises(ValueError):a.decimal_exact(decimal_text().replace('1.0D0',bad,1),a.N1_CODES)

    def test_expected_codes_and_selected_point_are_strict(self):
        for codes in ({1:219},{**a.N1_CODES,1:True},{**a.N1_CODES,1:218}):
            with self.assertRaises(ValueError):a.exact(exact_text(),codes)
        for point in (True,0,101):
            with self.assertRaises(ValueError):a.exact(exact_text(),a.N1_CODES,point)


class IeeeAndHistogramTests(unittest.TestCase):
    def test_full_and_batch_ieee_observations(self):
        self.assertEqual(len(a.ieee(ieee_text())),200)
        self.assertEqual(len(a.ieee(ieee_text([0]),[0])),2)
        self.assertEqual(len(a.ieee(ieee_text([16]),[16])),2)
        observed=ieee_text([0]).replace('0 1 1','0 1 -1',1).replace('0 2 1','0 2 4',1)
        self.assertEqual(a.ieee(observed,[0])[1][2],4)

    def test_incomplete_duplicate_and_invalid_ieee_rejected(self):
        text=ieee_text()
        for bad in (text.split('\n',1)[1],text+text.splitlines()[0]+'\n',text.replace('1 1 1','1 1 5',1),
                    text.replace('1 1 1 0','1 1 1 2',1),text.replace('1 1 1 0','1 1 1 0 0',1)):
            with self.assertRaises(ValueError):a.ieee(bad)

    def test_all_timed_calls_and_precision_distribution_required(self):
        self.assertEqual(a.status_histogram('219 12800\n',a.N1_CODES,128),{'219':12800})
        self.assertEqual(a.status_histogram('219 87\n323 13\n',a.N3_CODES,1),{'219':87,'323':13})
        self.assertEqual(a.status_histogram('323 1\n',a.N3_CODES,1,16),{'323':1})
        for bad in ('219 100\n','219 12800\n219 1\n','219 12800\n323 0\n','218 12800\n'):
            with self.assertRaises(ValueError):a.status_histogram(bad,a.N1_CODES,128)
        for loops in (True,0,-1,1.0):
            with self.assertRaises(ValueError):a.status_histogram('219 100\n',a.N1_CODES,loops)


class AnchorAndSummaryTests(unittest.TestCase):
    def raw(self,point=16,loops=1):
        return {'anchor-timing.dat':'73.0 2.5\n','anchor-status.dat':f'{a.N3_CODES[point]} {loops}\n',
                'anchor-exact.dat':exact_text(a.N3_CODES,point),'anchor-ieee.dat':ieee_text([point]),
                'anchor-values.dat':decimal_text(a.N3_CODES,point)}

    def test_anchor_outputs_join_raw_words_decimal_status_and_ieee(self):
        result=a.anchor_outputs(self.raw(),a.N3_CODES,point=16,loops=1)
        self.assertEqual(result['seconds'],2.5);self.assertEqual(result['timed_status_counts'],{'323':1})
        dp=a.anchor_outputs(self.raw(1,15),a.N3_CODES,point=1,loops=15)
        self.assertEqual(dp['seconds_per_call'],2.5/15)
        self.assertFalse(result['performance_acceptance'])

    def test_anchor_rejects_missing_fields_wrong_joins_and_multiple_qp_calls(self):
        for key,value in [('anchor-values.dat',decimal_text(a.N3_CODES,16).replace('-2.0E0','-3.0E0',1)),
                          ('anchor-status.dat','323 2\n'),('anchor-timing.dat','73 0\n'),
                          ('anchor-ieee.dat',ieee_text([1]))]:
            raw=self.raw();raw[key]=value
            with self.assertRaises(ValueError):a.anchor_outputs(raw,a.N3_CODES,point=16,loops=1)
        raw=self.raw();raw.pop('anchor-exact.dat')
        with self.assertRaises(ValueError):a.anchor_outputs(raw,a.N3_CODES,point=16,loops=1)
        with self.assertRaises(ValueError):a.anchor_outputs(self.raw(16,2),a.N3_CODES,point=16,loops=2)
        with self.assertRaises(ValueError):a.anchor_outputs(self.raw(),a.N1_CODES,point=16,loops=1)

    def test_summary_recomputes_fixed_seven_pair_median(self):
        result=a.timing_summary(pairs())
        self.assertAlmostEqual(result['median_ratio'],0.94);self.assertEqual(result['pairs'],7)
        self.assertFalse(result['performance_acceptance']);self.assertFalse(result['speedup_claimed'])

    def test_summary_rejects_pair_order_gaps_missing_roles_and_bad_elapsed(self):
        for change in ('short','order','gap','role','nan','zero','bool'):
            rows=copy.deepcopy(pairs())
            if change=='short':rows.pop()
            elif change=='order':rows[1]['order']=['original','candidate']
            elif change=='gap':rows[2]['pair']=4
            elif change=='role':rows[0].pop('candidate')
            elif change=='nan':rows[0]['candidate']['seconds']=float('nan')
            elif change=='zero':rows[0]['original']['seconds']=0.
            else:rows[0]['original']['seconds']=True
            with self.assertRaises(ValueError):a.timing_summary(rows)


class VariantComparisonTests(unittest.TestCase):
    def rows(self):return a.exact(exact_text(a.N3_CODES),a.N3_CODES)

    def test_one_ulp_coefficient_and_accuracy_changes_are_diagnostics(self):
        original=self.rows();candidate=copy.deepcopy(original)
        candidate[0]['words'][0]='3FF0000000000001'
        candidate[0]['words'][4]=word(1e-3)
        calls=[]
        def comparator(left,right,tolerance):
            calls.append(tolerance)
            return COMPARE_ROWS(left,right,tolerance=tolerance)
        result=a.compare_variants(original,candidate,comparator)
        self.assertEqual(calls,[3e-6,1e-8])
        self.assertTrue(result['passed']);self.assertTrue(result['regression_passed']);self.assertTrue(result['ordinary_target_passed'])
        self.assertEqual(result['rows_compared'],200);self.assertEqual(result['coefficient_values_compared'],800)
        self.assertEqual(len(result['regression']['residuals']),800)
        self.assertEqual(result['coefficient_word_difference_count'],1);self.assertEqual(result['accuracy_difference_count'],1)
        self.assertFalse(result['all_coefficient_words_equal']);self.assertFalse(result['all_accuracy_words_equal'])
        difference=result['accuracy_differences'][0]
        self.assertEqual(difference['original_word'],word(-0.));self.assertEqual(difference['candidate_value'],1e-3)

    def test_ordinary_target_failure_is_hard_even_when_regression_passes(self):
        original=self.rows();candidate=copy.deepcopy(original);candidate[0]['words'][0]=word(1+1e-6)
        result=a.compare_variants(original,candidate,COMPARE_ROWS)
        self.assertTrue(result['regression_passed']);self.assertFalse(result['ordinary_target_passed']);self.assertFalse(result['passed'])
        self.assertEqual(result['regression']['tolerance'],3e-6);self.assertEqual(result['ordinary_target']['tolerance'],1e-8)

    def test_all_coefficients_orders_and_points_enter_existing_criterion(self):
        original=self.rows();candidate=copy.deepcopy(original);candidate[-1]['words'][3]=word(2.)
        result=a.compare_variants(original,candidate,COMPARE_ROWS)
        self.assertFalse(result['passed'])
        failure=result['ordinary_target']['failures'][-1]
        self.assertEqual((failure['point'],failure['order'],failure['column']),(100,1,3))

    def test_signed_zero_changes_remain_diagnostic(self):
        original=self.rows();candidate=copy.deepcopy(original)
        candidate[0]['words'][1]=word(0.);candidate[0]['words'][4]=word(0.)
        result=a.compare_variants(original,candidate,COMPARE_ROWS)
        self.assertTrue(result['passed'])
        self.assertTrue(result['coefficient_word_differences'][0]['values_equal'])
        self.assertTrue(result['accuracy_differences'][0]['values_equal'])
        self.assertEqual(result['accuracy_differences'][0]['absolute_value_difference'],0.)

    def test_two_order_anchor_uses_same_criterion_and_diagnostics(self):
        rows=a.exact(exact_text(a.N3_CODES,16),a.N3_CODES,16)
        result=a.compare_variants(rows,rows,COMPARE_ROWS)
        self.assertTrue(result['passed']);self.assertEqual(result['coefficient_values_compared'],8)
        self.assertTrue(result['all_coefficient_words_equal']);self.assertTrue(result['all_accuracy_words_equal'])

    def test_status_nonfinite_negative_accuracy_and_shape_fail_before_comparison(self):
        original=self.rows()
        bad=[]
        changed=copy.deepcopy(original);changed[0]['status']=323;changed[1]['status']=323;bad.append(changed)
        changed=copy.deepcopy(original);changed[0]['words'][0]='7FF0000000000000';bad.append(changed)
        changed=copy.deepcopy(original);changed[0]['words'][4]=word(-1.);bad.append(changed)
        changed=copy.deepcopy(original);changed[0]['words'].pop();bad.append(changed)
        changed=copy.deepcopy(original);changed[0]['point']=True;bad.append(changed)
        bad.extend((original[:-1],[original[1],original[0],*original[2:]]))
        for candidate in bad:
            def forbidden(*args,**kwargs):raise AssertionError('Invalid inputs reached comparator')
            with self.assertRaises(ValueError):a.compare_variants(original,candidate,forbidden)

    def test_existing_comparator_result_must_have_literal_boolean_passed(self):
        rows=self.rows()
        with self.assertRaises(ValueError):a.compare_variants(rows,rows,lambda *args,**kwargs:{'passed':'yes'})


class OwnComparisonTests(unittest.TestCase):
    def rows(self):return a.exact(exact_text(a.N3_CODES),a.N3_CODES)

    def test_accuracy_only_mutation_is_accepted_and_recorded(self):
        reference=self.rows();actual=copy.deepcopy(reference);actual[0]['words'][4]=word(1e-3)
        result=a.compare_own(reference,actual)
        self.assertTrue(result['passed']);self.assertTrue(result['coeff_exact']);self.assertTrue(result['status_equal'])
        self.assertEqual(result['rows_compared'],200);self.assertEqual(result['coefficient_words_compared'],800)
        self.assertEqual(result['coefficient_word_difference_count'],0)
        self.assertTrue(result['accuracy_drift']);self.assertEqual(result['accuracy_drift_count'],1)
        self.assertEqual(result['accuracy_value_drift_count'],1)
        difference=result['accuracy_differences'][0]
        self.assertEqual(difference['reference_word'],word(-0.));self.assertEqual(difference['actual_word'],word(1e-3))
        self.assertEqual(difference['reference_value'],-0.);self.assertEqual(difference['actual_value'],1e-3)
        self.assertTrue(difference['word_drift']);self.assertTrue(difference['value_drift'])

    def test_one_ulp_coefficient_mutation_fails_exact_gate(self):
        reference=self.rows();actual=copy.deepcopy(reference);actual[0]['words'][0]='3FF0000000000001'
        result=a.compare_own(reference,actual)
        self.assertFalse(result['passed']);self.assertFalse(result['coeff_exact']);self.assertTrue(result['status_equal'])
        self.assertEqual(result['coefficient_word_difference_count'],1)
        self.assertEqual(result['coefficient_differences'][0]['column'],0)

    def test_public_status_mutation_fails_exact_gate(self):
        reference=self.rows();actual=copy.deepcopy(reference)
        actual[0]['status']=323;actual[1]['status']=323
        result=a.compare_own(reference,actual)
        self.assertFalse(result['passed']);self.assertFalse(result['status_equal']);self.assertTrue(result['coeff_exact'])
        self.assertEqual(result['status_difference_count'],2)
        self.assertEqual(result['status_differences'][0],
                         {'point':1,'order':0,'reference_status':219,'actual_status':323})

    def test_nonfinite_and_negative_accuracy_rejected(self):
        reference=self.rows()
        for invalid in ('7FF0000000000000','7FF8000000000001',word(-1.)):
            actual=copy.deepcopy(reference);actual[0]['words'][4]=invalid
            with self.assertRaises(ValueError):a.compare_own(reference,actual)
            with self.assertRaises(ValueError):a.compare_own(actual,reference)

    def test_signed_zero_accuracy_drift_is_diagnostic(self):
        reference=self.rows();actual=copy.deepcopy(reference);actual[0]['words'][4]=word(0.)
        result=a.compare_own(reference,actual)
        self.assertTrue(result['passed']);self.assertEqual(result['accuracy_drift_count'],1)
        self.assertEqual(result['accuracy_value_drift_count'],0)
        difference=result['accuracy_differences'][0]
        self.assertTrue(difference['word_drift']);self.assertFalse(difference['value_drift']);self.assertTrue(difference['values_equal'])
        self.assertEqual(difference['absolute_value_difference'],0.)

    def test_signed_zero_coefficient_drift_still_fails(self):
        reference=self.rows();actual=copy.deepcopy(reference);actual[0]['words'][1]=word(0.)
        result=a.compare_own(reference,actual)
        self.assertFalse(result['passed']);self.assertFalse(result['coeff_exact'])
        self.assertTrue(result['coefficient_differences'][0]['values_equal'])

    def test_two_order_anchor_and_all100_identity_supported(self):
        full=self.rows();full_result=a.compare_own(full,full)
        self.assertTrue(full_result['passed']);self.assertFalse(full_result['accuracy_drift'])
        anchor=a.exact(exact_text(a.N3_CODES,16),a.N3_CODES,16)
        actual=copy.deepcopy(anchor);actual[1]['words'][4]=word(2e-4)
        result=a.compare_own(anchor,actual)
        self.assertTrue(result['passed']);self.assertEqual(result['rows_compared'],2)
        self.assertEqual(result['coefficient_words_compared'],8);self.assertEqual(result['accuracy_drift_count'],1)

    def test_point_order_shapes_and_split_status_are_not_weakened(self):
        rows=self.rows()
        bad=(rows[:-1],[rows[1],rows[0],*rows[2:]])
        for actual in bad:
            with self.assertRaises(ValueError):a.compare_own(rows,actual)
        actual=copy.deepcopy(rows);actual[0]['status']=323
        with self.assertRaises(ValueError):a.compare_own(rows,actual)
        left=a.exact(exact_text(a.N3_CODES,1),a.N3_CODES,1)
        right=a.exact(exact_text(a.N3_CODES,16),a.N3_CODES,16)
        with self.assertRaisesRegex(ValueError,'point/order'):a.compare_own(left,right)

    def test_decimal_raw_join_still_requires_accuracy_identity(self):
        rows=self.rows();decimal=decimal_text(a.N3_CODES)
        actual=a.decimal_exact(decimal,a.N3_CODES)
        self.assertEqual(actual,rows)
        changed=copy.deepcopy(rows);changed[0]['words'][4]=word(1e-3)
        self.assertTrue(a.compare_own(rows,changed)['passed'])
        self.assertNotEqual(actual,changed)


if __name__=='__main__':unittest.main()
