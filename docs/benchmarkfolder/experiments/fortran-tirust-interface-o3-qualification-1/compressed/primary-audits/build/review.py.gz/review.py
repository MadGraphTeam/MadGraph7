"""Read/hash-only review of the closed four-variant interface-O3 BUILD."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,struct,time,types
ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SRC=ROOT/'.tirust-build/fortran-tirust-interface-o3-proposal-2'
BUILD=ROOT/'.tirust-build/fortran-tirust-interface-o3-execution-2/build'
HERE=Path(__file__).resolve().parent
SOURCE='83721ec7d56313807d5ba2a282411b2ea2623ed0810158bed8a0b0b108afcb0b'
TERM='29dabbb9f0ab7f8e8eebdba6e56dca095b6fcc630dd561cd90f81d7accd56502'
RESULT='2494684a388bdfa0c0bb481d1eccd6b9a28f197551606ac1dec16d5283d2e734'
seen={}
def digest(p):
    p=Path(p).resolve();s=p.stat();k=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if str(p) not in seen:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1048576),b''):h.update(b)
        seen[str(p)]=(k,h.hexdigest())
    assert seen[str(p)][0]==k
    return seen[str(p)][1]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())
def interp(p):
    b=Path(p).read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
    off=struct.unpack_from('<Q',b,32)[0];size,n=struct.unpack_from('<HH',b,54);out=[]
    for i in range(n):
        row=off+i*size
        if struct.unpack_from('<I',b,row)[0]==3:
            a=struct.unpack_from('<Q',b,row+8)[0];length=struct.unpack_from('<Q',b,row+32)[0];out.append(b[a:a+length].rstrip(b'\0').decode())
    assert len(out)==1;return out[0]
def sources(output):
    return {str(p.relative_to(output)):digest(p) for sub in ('Source','SubProcesses') for p in (output/sub).rglob('*') if p.is_file() and (p.suffix.lower() in {'.f','.f90','.for','.inc','.c','.cc','.h'} or p.name.startswith('makefile') or p.name in ('make_opts','MadLoop_makefile_definitions'))}
def objects(output):
    return {str(p.relative_to(output)):digest(p) for p in output.rglob('*') if p.is_file() and p.suffix.lower() in ('.o','.a','.mod') and 'build-history' not in p.parts and 'worker-raw' not in p.parts}
def signature(r):return (tuple((x['sha256'],x['version']) for x in r['compiler']),tuple(r['flags']))

def main():
    start=time.monotonic();match(SRC/'source-index.json',SOURCE);match(BUILD/'terminal.json',TERM);match(BUILD/'result.json',RESULT)
    seal=read(SRC/'source-index.json');pin=read(SRC/'input-pins.json');terminal=read(BUILD/'terminal.json');result=read(BUILD/'result.json')
    assert {str(p.relative_to(SRC)) for p in SRC.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'}
    for n,w in seal['files'].items():match(SRC/n,w['sha256']);assert (SRC/n).stat().st_size==w['bytes']
    for n,h in seal['support'].items():match(ROOT/n,h)
    for n,w in pin['files'].items():
        p=Path(n) if Path(n).is_absolute() else ROOT/n;match(p,w['sha256']);assert p.stat().st_size==w['bytes']
    for n,h in pin['ancestry'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,h)
    pred=read(SRC/'predecessor.json');parent=ROOT/pred['predecessor_source']
    assert {str(p.relative_to(parent)) for p in parent.rglob('*') if p.is_file()}==set(pred['predecessor_files'])
    for n,h in pred['predecessor_files'].items():match(parent/n,h)
    assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
    assert terminal['result_sha256']==RESULT and terminal['source_index_sha256']==SOURCE and terminal['cpu']==12 and terminal['cpu_reservation'] is False
    assert terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60
    assert result['status']=='passed' and result['native_amplitude_calls']==0 and result['compiled_units_per_variant']==2
    assert result['candidate_delta']==['TIRUST_interface.f only: -O3 -fno-fast-math']
    assert set(result['variants'])=={'n1/original','n1/candidate','n3/original','n3/candidate'}
    policy=types.ModuleType('pure_closed_o3_policy');exec(compile((SRC/'policy.py').read_bytes(),str(SRC/'policy.py'),'exec'),policy.__dict__)
    compiler=types.SimpleNamespace(_signature=signature);counts=Counter();rows={};all_commands={}
    for case,original in pin['cases'].items():
        donor=Path(original['output']);assert sources(donor)==original['generated_sources'] and objects(donor)==original['numerical_objects']
        for n,h in original['numerical_cards'].items():match(donor/n,h)
        prefix='SubProcesses/'+original['subprocess']+'/'
        for variant in ('original','candidate'):
            key=case+'/'+variant;row=result['variants'][key];output=Path(row['output']);proc=output/prefix;logs=BUILD/key/'commands';candidate=variant=='candidate'
            assert sources(output)==row['sources'] and objects(output)==row['objects']
            match(proc/'check',row['executable_sha256']);match(proc/'private-link.map',row['link_map_sha256']);match(BUILD/key/'prelink.json',row['prelink_sha256'])
            for n in ('check_sa.f','TIRUST_interface.f'):assert (proc/n).read_bytes()==(SRC/'source-preview'/case/n).read_bytes()
            assert (proc/'TIRUST_interface.f').read_bytes()==(donor/prefix/'TIRUST_interface.f').read_bytes()
            assert (proc/'makefile').read_text()==policy.private_makefile((donor/prefix/'makefile').read_text(),candidate)
            assert not (proc/'mtirust.o').exists() and not (proc/'qp_profile.o').exists()
            changed={prefix+'check_sa.o',prefix+'TIRUST_interface.o'}
            for n,h in original['numerical_objects'].items():
                if n not in changed:match(output/n,h)
            assert policy.verify_policy(original['compiler_flags'],row['compiler_flags'],candidate,compiler)==row['policy_evidence']
            for n,h in original['numerical_cards'].items():match(output/n,h)
            match(output/'Cards/param_card.dat',original['param_card_sha256'])
            pre=read(BUILD/key/'prelink.json');assert pre['completed_before_link']
            for n,h in pre['bound'].items():match(n,h)
            maps=(proc/'private-link.map').read_text();loads={str((proc/s).resolve()):digest(proc/s) for s in re.findall(r'^LOAD\s+(.+)$',maps,re.M)}
            assert loads==row['actual_link_loads'] and len(loads)==(52 if case=='n1' else 54)
            assert all(pre['bound'].get(n)==h for n,h in loads.items())
            assert 'libtirust.a(' in maps and not re.search(r'^LOAD\s+(?:mtirust|qp_profile)\.o$',maps,re.M)
            runtime=row['runtime'];assert len(runtime['files'])==15 and interp(proc/'check')==runtime['loader']
            paths=set()
            for line in runtime['listing'].splitlines():
                line=line.strip()
                if not line or re.fullmatch(r'linux-vdso\.so\.1\s+\(0x[0-9a-fA-F]+\)',line):continue
                m=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line);assert m,line;paths.add(str(Path(m[1]).resolve()))
            assert paths==set(runtime['files'])
            for n,h in runtime['files'].items():match(n,h);assert pre['bound'][n]==h
            assert runtime['files'][runtime['loader']]==runtime['loader_sha256']
            defs=Counter(line.split()[-1] for line in (logs/'03-executable-symbols.stdout.txt').read_text().splitlines() if len(line.split())>=3 and '__mtirust_MOD_' in line.split()[-1])
            assert len(defs)==23 and set(defs.values())=={1} and dict(defs)==row['mtirust_definitions']
            assert set(defs)==set(pin['expected_mtirust_symbols'])
            commandfiles=list(logs.glob('*.command.json'));assert len(commandfiles)==65
            for file in commandfiles:
                label=file.name.removesuffix('.command.json');c=read(file);t=read(logs/(label+'.terminal.json'));assert t['returncode']==0
                match(logs/(label+'.stdout.txt'),t['stdout_sha256'])
                if 'stderr_sha256' in t:match(logs/(label+'.stderr.txt'),t['stderr_sha256'])
                argv=c['argv'];all_commands[key+'/'+label]=argv
                if label.startswith(('00-compile','01-compile')):counts['object_compiles']+=1
                elif label=='02-link':counts['links']+=1;assert argv==pre['command']
                elif label.startswith('prelink-query-'):counts['prelink_queries']+=1
                elif label=='03-executable-symbols':counts['nm_queries']+=1
                elif '--list' in argv:counts['loader_queries']+=1;assert argv==[runtime['loader'],'--list',str(proc/'check')];assert (logs/(label+'.stdout.txt')).read_text()==runtime['listing']
                elif '--version' in argv:counts['version_queries']+=1
                else:assert Path(argv[0]).name=='make';counts['make_dry_runs']+=1;assert '--dry-run' in argv or '-n' in argv
            for i in range(1,5):
                assert (logs/f'policy-before-{i:02d}.stdout.txt').read_bytes()==(logs/f'policy-after-{i:02d}.stdout.txt').read_bytes()
            rows[key]={'executable_sha256':row['executable_sha256'],'source_count':len(row['sources']),'object_inventory_count':len(row['objects']),
                'actual_LOAD_count':len(loads),'prebound_count':len(pre['bound']),'runtime_providers':15,'MTIRUST_definitions':23,
                'interface_flags':row['compiler_flags']['scopes']['process']['recipes']['TIRUST_interface.f']['flags'],
                'driver_object_sha256':digest(proc/'check_sa.o'),'interface_object_sha256':digest(proc/'TIRUST_interface.o'),
                'policy':row['policy_evidence'],'PT_INTERP':runtime['loader']}
        left=result['variants'][case+'/original'];right=result['variants'][case+'/candidate']
        assert left['sources'].keys()==right['sources'].keys()
        assert {n for n in left['sources'] if left['sources'][n]!=right['sources'][n]}=={prefix+'makefile'}
        assert {n for n in left['objects'] if left['objects'][n]!=right['objects'][n]}=={prefix+'TIRUST_interface.o'}
        assert left['runtime']==right['runtime'] or left['runtime']['files']==right['runtime']['files']
        for label in ('00-compile-check_sa.f','01-compile-TIRUST_interface.f'):
            a=all_commands[case+'/original/'+label];b=all_commands[case+'/candidate/'+label]
            assert a==[x for x in b if x not in ('-O3','-fno-fast-math')]
            assert (b.count('-O3'),b.count('-fno-fast-math'))==((1,1) if label.startswith('01-') else (0,0))
    assert counts=={'object_compiles':8,'links':4,'prelink_queries':204,'make_dry_runs':28,'version_queries':8,'nm_queries':4,'loader_queries':4}
    assert len(all_commands)==260
    match(SRC/'source-index.json',SOURCE);match(BUILD/'terminal.json',TERM);match(BUILD/'result.json',RESULT)
    receipt={'schema':'independent-interface-O3-build-audit-v1','status':'PASS','source_index_sha256':SOURCE,
        'build_terminal_sha256':TERM,'build_result_sha256':RESULT,'source_payloads':len(seal['files']),
        'protected_direct_inputs':len(pin['files']),'original_numerical_objects_modules_archives':{'n1':60,'n3':144},
        'successful_recorded_commands':260,'command_categories':dict(counts),'make_internal_queries_individually_counted':False,
        'variants':rows,'only_crossvariant_numerical_object_difference':'TIRUST_interface.o',
        'common_driver_object_identical':True,'all_other_numerical_objects_and_archive_hashes_preserved':True,
        'actual_policy_before_after_stdout_equal':True,'recorded_cleanup_survivors':0,
        'separate_parity_prerequisite_barrier_clear':True,'parity_or_timing_qualified_by_audit':False,
        'candidate_promoted':False,'audit_compiler_calls':0,'audit_loader_calls':0,'audit_native_calls':0,
        'distinct_resolved_files_hashed':len(seen),'distinct_resolved_bytes_hashed':sum(x[0][2] for x in seen.values()),
        'audit_source_sha256':digest(Path(__file__)),'elapsed_seconds':time.monotonic()-start}
    out=HERE/'receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','receipt':str(out),'sha256':digest(out),'elapsed':receipt['elapsed_seconds']},sort_keys=True))

if __name__=='__main__':main()
