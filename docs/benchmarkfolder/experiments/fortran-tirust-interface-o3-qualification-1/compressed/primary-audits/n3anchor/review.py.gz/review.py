"""Pure audit of closed O3 N3 anchor timing, without executing any numerical binary."""
import ast,builtins,ctypes,hashlib,io,json,math,os,statistics,struct,subprocess,time
from fractions import Fraction
from pathlib import Path
ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
HERE=Path(__file__).resolve().parent
BASE=ROOT/'.tirust-build/fortran-tirust-interface-o3-n1parity-independent-audit-2'
assert hashlib.sha256((BASE/'receipt.json').read_bytes()).hexdigest()=='3ad7b6166417a7507ab4eeb8d8946d1a0e20772f19b32c343354d987e6d264fe'
base_receipt=json.loads((BASE/'receipt.json').read_text())
assert hashlib.sha256((BASE/'review.py').read_bytes()).hexdigest()==base_receipt['audit_source_sha256']
base={'__file__':str(BASE/'review.py'),'__name__':'reused_audit_helpers'}
exec(compile((BASE/'review.py').read_bytes(),str(BASE/'review.py'),'exec'),base)
SRC,REPORT,WORK=(base[n] for n in ('SRC','REPORT','WORK'))
digest,match,read,words=(base[n] for n in ('digest','match','read','words'))
SOURCE=base['SOURCE'];BUILD=base['BUILD'];PARITY='af82c067c35dbc4895b974060492cf17365a5e962adf33f10e2468c5a44b71dc'
PRIOR={'build':BUILD,'n1parity':base['TERMINAL'],'n1timing':'d10ecb2613cd406fc72ee11dea79ddc1ff48a5d93bdb9bdcca28c9cbda5a3fd1','n3parity':PARITY}
TERMINAL='ddabc42a0bb1368a94103c21bee2b387c872e1c55740fd5b2dd2120a201d224e'
RESULT='c5585510d4128f15562a36bbdcf8fa96f73d19a34e96cf89a53d7040c82b7d8e'

def main():
    start=time.monotonic();p=REPORT/'n3anchortiming'
    for file,want in ((SRC/'source-index.json',SOURCE),(REPORT/'build/terminal.json',BUILD),(REPORT/'n3parity/terminal.json',PARITY),(p/'terminal.json',TERMINAL),(p/'result.json',RESULT)):match(file,want)
    seal=read(SRC/'source-index.json');pins=read(SRC/'input-pins.json');case=pins['cases']['n3']
    for n,w in seal['files'].items():match(SRC/n,w['sha256'])
    for n,h in seal['support'].items():match(ROOT/n,h)
    for n,w in pins['files'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,w['sha256'])
    for n,h in pins['ancestry'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,h)
    bt=read(REPORT/'build/terminal.json');match(REPORT/'build/result.json',bt['result_sha256']);built=read(REPORT/'build/result.json')
    pt=read(REPORT/'n3parity/terminal.json');match(REPORT/'n3parity/result.json',pt['result_sha256']);parity=read(REPORT/'n3parity/result.json')
    term=read(p/'terminal.json');result=read(p/'result.json')
    assert term['status']=='passed' and term['returncode']==0 and not term['cleanup']['survivors']
    assert term['source_index_sha256']==SOURCE and term['result_sha256']==RESULT and term['stage']=='n3anchortiming'
    assert term['cap_seconds']==600 and term['cleanup_reserve_seconds']==60 and term['cpu']==12 and not term['cpu_reservation']
    assert result['reviewed']==PRIOR and result['source_index_sha256']==SOURCE
    assert result['full100_learning_and_exact_before_timing'] and result['pairs']==7 and result['case']=='n3'
    assert not result['performance_acceptance'] and not result['candidate_promoted']
    assert set(result['scopes'])=={'DP','QP'}
    for label,point,loops in (('DP',1,15),('QP',16,1)):
        assert result['scopes'][label]['loops']==loops and result['scopes'][label]['point']==point
    for stage,checksum in PRIOR.items():
        match(REPORT/stage/'terminal.json',checksum);previous_terminal=read(REPORT/stage/'terminal.json')
        assert previous_terminal['status']=='passed' and previous_terminal['returncode']==0 and not previous_terminal['cleanup']['survivors']
        match(REPORT/stage/'result.json',previous_terminal['result_sha256'])
    prefix='SubProcesses/'+case['subprocess']+'/'
    raw={};maps={};queries=0
    for role in ('original','candidate'):
        report=p/role;out=WORK/'n3anchortiming'/role;proc=out/prefix;bound=built['variants']['n3/'+role]
        before=read(report/'private-before.json');assert before==read(report/'private-after.json')
        assert before['executable_sha256']==bound['executable_sha256'] and before['physical_sha256']==case['param_card_sha256']
        cards={**case['numerical_cards'],prefix+'MadLoop5_resources/MadLoopParams.dat':next(iter(case['numerical_cards'].values()))}
        assert before['cards']==cards
        for n,h in cards.items():match(out/n,h);assert (out/n).resolve().is_relative_to(out.resolve())
        match(out/'Cards/param_card.dat',case['param_card_sha256']);match(proc/'check',bound['executable_sha256'])
        for n,h in bound['sources'].items():match(out/n,h)
        for n,h in bound['objects'].items():match(out/n,h)
        for n,h in case['numerical_objects'].items():
            if n not in (prefix+'check_sa.o',prefix+'TIRUST_interface.o'):match(out/n,h)
        assert not (proc/'worker-protocol.fifo').exists()
        expected={**bound['runtime']['files'],str(proc/'check'):bound['executable_sha256']};assert len(expected)==16
        maps[role]={}
        for edge in ('before','after'):
            file=report/('maps-'+edge+'.json');m=read(file)
            assert all(m['files'].get(n)==h for n,h in expected.items())
            assert all({**expected,**seal['allowed_extra_mappings']}.get(n)==h for n,h in m['files'].items())
            paths={line.split(None,5)[5] for line in m['maps'].splitlines() if len(line.split(None,5))==6 and line.split(None,5)[5].startswith('/')}
            assert paths==set(m['files']) and not any(n.endswith(' (deleted)') for n in paths)
            for n,h in m['files'].items():match(n,h)
            assert any(x['pid']==m['pid'] for x in term['cleanup']['observed_owned_processes'])
            maps[role][edge]=digest(file)
        commands=list((report/'commands').glob('*.command.json'));assert len(commands)==2
        for file in commands:
            name=file.name.removesuffix('.command.json');cmd=read(file);closed=read(file.with_name(name+'.terminal.json'))
            assert cmd['argv']==[bound['runtime']['loader'],'--list',str(proc/'check')] and closed['returncode']==0
            match(file.with_name(name+'.stdout.txt'),closed['stdout_sha256']);queries+=1
        import re
        assert not re.search(r'##W03\b',(report/'worker.log').read_text(),re.I)
        ready=read(report/'ready.json');assert [ready[k] for k in ('points','ndim','nso','nborn')]==[100,1,1,1]
        warm=read(report/'warmup.json');assert warm['cold_seconds']==ready['cold_seconds']
        text=(report/'warmup.dat').read_text();assert text==(proc/'warmup.dat').read_text()==warm['raw_outputs']['warmup.dat']
        assert (report/'dimensions.dat').read_text()==(proc/'dimensions.dat').read_text()==warm['raw_outputs']['dimensions.dat']
        assert list(map(int,warm['raw_outputs']['dimensions.dat'].split()))==[1,1,1]
        exact=report/'exact-before-timing'
        raw[role]={'warm':warm,'warmtext':text,'learning':read(report/'learning-comparison.json'),
                   'exact':(exact/'exact-words.dat').read_text(),'ieee':(exact/'exact-ieee.dat').read_text(),
                   'historical':read(exact/'historical-comparison.json'),'own':read(exact/'own-qualified-comparison.json'),
                   'batches':{}}
        names=('anchor-timing.dat','anchor-values.dat','anchor-status.dat','anchor-exact.dat','anchor-ieee.dat')
        for label in ('DP','QP'):
            raw[role]['batches'][label]=[]
            for i in range(1,8):
                folder=report/label/('pair-'+str(i))
                row={n:(folder/n).read_text() for n in names}
                row['own']=read(folder/'own-comparisons.json');raw[role]['batches'][label].append(row)
        for n in names:assert (proc/n).read_text()==raw[role]['batches']['QP'][-1][n]
    pairfiles={label:[read(p/label/('pair-'+str(i)+'.json')) for i in range(1,8)] for label in ('DP','QP')}
    comparisonfiles={label:[read(p/label/('pair-'+str(i)+'-comparison.json')) for i in range(1,8)] for label in ('DP','QP')}
    assert all(pairfiles[label]==result['scopes'][label]['pairs'] for label in pairfiles)
    historical_text=Path(case['closed_warmup']).read_text();historical=words(read(case['closed_observation'])['rows'])
    analysis={};exec(compile((SRC/'analysis.py').read_bytes(),str(SRC/'analysis.py'),'exec'),analysis)
    tree=ast.parse((ROOT/'tools/tirust_benchmark.py').read_bytes());tree.body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare_rows'];assert len(tree.body)==1
    numerical={};exec(compile(tree,'sealed-compare_rows','exec'),numerical)
    blocked=[];saved=[]
    def deny(*a,**kw):blocked.append(repr(a[:2]));raise RuntimeError('Forbidden API during pure timing replay')
    try:
        for obj,n in ((builtins,'open'),(io,'open'),(io,'open_code'),(os,'open'),(os,'system'),(os,'popen'),(subprocess,'Popen'),(subprocess,'run'),(subprocess,'call'),(subprocess,'check_call'),(subprocess,'check_output'),(ctypes,'CDLL'),(ctypes,'PyDLL')):
            saved.append((obj,n,getattr(obj,n)));setattr(obj,n,deny)
        fresh={};learning={};allcalls=0;descriptive={};usage={}
        def history(text):return [list(map(int,line.split()[:4])) for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
        for role in ('original','candidate'):
            r=raw[role];lc=r['learning'];actual=history(r['warmtext'])
            assert actual==history(historical_text)==lc['actual_call_point_order_status']==lc['historical_call_point_order_status']
            assert lc['history_matches'] and lc['raw_byte_identity']==(r['warmtext']==historical_text)
            groups={}
            for line in r['warmtext'].splitlines():
                if not line.strip() or line.lstrip().startswith('#'):continue
                f=line.split();assert len(f)==9;groups.setdefault(int(f[0]),[]).append(f)
            assert [k for k in groups if k>0][-100:]==list(range(1,101))
            warmrows=[]
            for call in range(1,101):
                assert [(int(f[1]),int(f[2]),int(f[3])) for f in groups[call]]==[(call,0,case['expected_codes'][str(call)]),(call,1,case['expected_codes'][str(call)])]
                for f in groups[call]:
                    v=list(map(float,f[4:]));assert all(math.isfinite(x) for x in v) and v[-1]>=0
                    warmrows.append({'point':call,'order':int(f[2]),'status':int(f[3]),'coefficients':v[:4],'accuracy':v[4],'actual_backend':9,'precision':('QP' if int(f[3])==323 else 'DP')})
            assert warmrows==r['warm']['rows'] and r['warm']['status_counts']=={'219':87,'323':13}
            assert analysis['compare_variants'](historical,words(warmrows),numerical['compare_rows'])==lc['steady_full100_comparison'] and lc['steady_full100_comparison']['passed']
            fresh[role]=analysis['exact'](r['exact'],case['expected_codes'])
            assert analysis['ieee'](r['ieee'])==parity['lanes'][role]['ieee']
            assert analysis['compare_variants'](historical,fresh[role],numerical['compare_rows'])==r['historical'] and r['historical']['passed']
            own=analysis['compare_own'](parity['lanes'][role]['rows'],fresh[role]);assert own==r['own']==result['fresh_own_comparisons'][role] and own['passed'] and not own['accuracy_drift']
            learning[role]={'steady_calls':100,'whole_history_rows':len(actual),'status_counts':{'219':87,'323':13},'raw_history_identical':lc['raw_byte_identity']}
        for label,point,loops,status in (('DP',1,15,219),('QP',16,1,323)):
            timings={'original':[],'candidate':[]};previous={role:[r for r in fresh[role] if r['point']==point] for role in fresh}
            scope_calls=0
            for i,pair in enumerate(pairfiles[label],1):
                assert pair['pair']==i and pair['order']==(['original','candidate'] if i%2 else ['candidate','original'])
                for role in pair['order']:
                    r=raw[role]['batches'][label][i-1];observed=pair[role]
                    parsed=analysis['anchor_outputs'](r,case['expected_codes'],point=point,loops=loops)
                    assert parsed=={k:v for k,v in observed.items() if k not in ('own_comparisons','previous_batch_reference')}
                    fields=r['anchor-timing.dat'].split();assert len(fields)==2
                    cold,elapsed=map(float,fields);assert math.isfinite(elapsed) and elapsed>0 and cold==raw[role]['warm']['cold_seconds']
                    timings[role].append(Fraction(fields[1]))
                    assert parsed['timed_status_counts']=={str(status):loops};allcalls+=loops;scope_calls+=loops
                    wanted=[r for r in parity['lanes'][role]['rows'] if r['point']==point]
                    own={'qualified_parity':analysis['compare_own'](wanted,parsed['rows']),'previous_batch':analysis['compare_own'](previous[role],parsed['rows'])}
                    assert own==r['own']==observed['own_comparisons'] and all(x['passed'] and not x['accuracy_drift'] for x in own.values())
                    assert observed['previous_batch_reference']==('fresh_full100_exact' if i==1 else 'pair-'+str(i-1))
                    previous[role]=parsed['rows']
                assert pair['candidate']['ieee']==pair['original']['ieee']
                comp=analysis['compare_variants'](pair['original']['rows'],pair['candidate']['rows'],numerical['compare_rows'])
                assert comp==pair['comparison']==comparisonfiles[label][i-1] and comp['passed'] and comp['all_accuracy_words_equal'] and comp['all_coefficient_words_equal']
            summary=analysis['timing_summary'](pairfiles[label]);assert summary==result['scopes'][label]['summary'] and not summary['performance_acceptance'] and not summary['speedup_claimed']
            ratios=[c/o for c,o in zip(timings['candidate'],timings['original'])]
            med=statistics.median(ratios);mad=statistics.median(abs(x-med) for x in ratios)
            assert math.isclose(float(med),summary['median_ratio'],rel_tol=1e-15)
            assert all(math.isclose(float(q),v,rel_tol=1e-15) for q,v in zip(ratios,summary['ratios']))
            descriptive[label]={'point':point,'loops':loops,'median_ratio':float(med),'median_ratio_rational':str(med),'ratio_MAD':float(mad),
                'ratios':[float(x) for x in ratios],'median_seconds_per_call':{role:float(statistics.median(values)/loops) for role,values in timings.items()}}
            usage[label]={'calls':scope_calls,'status':status,'final_recorded_coefficients_compared':7*2*4,'final_recorded_accuracy_compared':7*2}
        assert allcalls==224 and not blocked
    finally:
        for obj,n,value in reversed(saved):setattr(obj,n,value)
    match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    receipt={'schema':'independent-O3-n3-anchor-timing-audit-v1','status':'PASS','source_index_sha256':SOURCE,'build_terminal_sha256':BUILD,
      'parity_terminal_sha256':PARITY,'timing_terminal_sha256':TERMINAL,'timing_result_sha256':RESULT,
      'audit_source_sha256':digest(Path(__file__)),'helper_source_sha256':base_receipt['audit_source_sha256'],
      'pure_raw_replay_exact':True,'learning':learning,'fresh_full100_exact_calls':200,'timed_calls':allcalls,
      'pairs_per_anchor':7,'batches':28,'anchor_usage':usage,'calibration_performed':False,
      'schedule_scope':'Seven alternating pairs are declared in the source and retained pair records; no independent per-command timestamp trace is present.',
      'clock_scope':'Fortran SYSTEM_CLOCK elapsed wall seconds, final formatting/IEEE output outside clock; raw integer ticks are not separately retained.',
      'status_histogram':{'219':210,'323':14},'coefficient_and_accuracy_word_differences':0,'own_accuracy_drift_count':0,'observed_IEEE_equal':True,
      'numerical_scope':'Exact words cover the final anchor call per batch; status histograms cover every timed call. Both unchanged 3e-6 and1e-8 comparisons replayed.',
      'independent_fraction_summary':descriptive,
      'mapped_before_after':maps,'runtime_provider_count_per_worker':15,'closed_loader_receipts':queries,'W03_console_records':0,'recorded_cleanup_survivors':0,
      'distinct_live_files_hashed':len(base['seen']),'forbidden_API_attempts':len(blocked),'audit_native_calls':0,
      'scope':'N3 single-point DP/automatic-QP whole-amplitude descriptive shared-host timings after full100 science; no full-cohort runtime, acceptance, trap-freedom, gain or promotion claim.',
      'candidate_promoted':False,'performance_acceptance':False,'elapsed_seconds':time.monotonic()-start}
    output=HERE/'receipt.json';assert not output.exists();output.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':'PASS','receipt':str(output),'sha256':digest(output),'elapsed':receipt['elapsed_seconds'],'summary':receipt['independent_fraction_summary']},sort_keys=True))

if __name__=='__main__':main()
