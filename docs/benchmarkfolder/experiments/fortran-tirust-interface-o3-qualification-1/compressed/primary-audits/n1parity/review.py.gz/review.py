"""Independent pure raw N1 parity and closed input/runtime binding review."""
import ast,builtins,ctypes,hashlib,io,json,math,os,re,struct,subprocess,time,types
from collections import Counter
from pathlib import Path
ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SRC=ROOT/'.tirust-build/fortran-tirust-interface-o3-proposal-2'
REPORT=ROOT/'.tirust-build/fortran-tirust-interface-o3-execution-2'
WORK=ROOT/'.tirust-build/fortran-tirust-interface-o3-work-2'
HERE=Path(__file__).resolve().parent
SOURCE='83721ec7d56313807d5ba2a282411b2ea2623ed0810158bed8a0b0b108afcb0b'
BUILD='29dabbb9f0ab7f8e8eebdba6e56dca095b6fcc630dd561cd90f81d7accd56502'
TERMINAL='558849b4ce6eb99da75c36d613c9828b4a5b96ecbec88e35109ee1a4dab69a1f'
RESULT='d87ce9312707595382a27846f694031c3cde9086c2b23d23420fcbd87cdbd8e9'
seen={}
def digest(p):
    p=Path(p).resolve();s=p.stat();k=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if str(p) not in seen:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1048576),b''):h.update(b)
        seen[str(p)]=(k,h.hexdigest())
    assert seen[str(p)][0]==k
    return seen[str(p)][1]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())
def words(rows):return [{'point':r['point'],'order':r['order'],'status':r['status'],'words':[struct.pack('>d',v).hex().upper() for v in r['coefficients']+[r['accuracy']]]} for r in rows]

def main():
    start=time.monotonic();p=REPORT/'n1parity';match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    match(SRC/'source-index.json',SOURCE);match(REPORT/'build/terminal.json',BUILD)
    seal=read(SRC/'source-index.json');pin=read(SRC/'input-pins.json');case=pin['cases']['n1'];terminal=read(p/'terminal.json');result=read(p/'result.json')
    for n,w in seal['files'].items():match(SRC/n,w['sha256'])
    for n,h in seal['support'].items():match(ROOT/n,h)
    for n,w in pin['files'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,w['sha256'])
    for n,h in pin['ancestry'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,h)
    bt=read(REPORT/'build/terminal.json');match(REPORT/'build/result.json',bt['result_sha256']);built=read(REPORT/'build/result.json')
    assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
    assert terminal['result_sha256']==RESULT and terminal['source_index_sha256']==SOURCE and terminal['stage']=='n1parity'
    assert terminal['cap_seconds']==300 and terminal['cleanup_reserve_seconds']==60 and terminal['cpu']==12 and not terminal['cpu_reservation']
    assert result['reviewed']=={'build':BUILD} and result['source_index_sha256']==SOURCE and result['case']=='n1'
    assert result['full100_learning_per_worker'] and not result['candidate_promoted'] and not result['performance_acceptance']
    assert result['expected_codes']==case['expected_codes']=={str(i):219 for i in range(1,101)}
    raw={};bindings={};queries=0;prefix='SubProcesses/'+case['subprocess']+'/'
    historical_text=Path(case['closed_warmup']).read_text();historical=words(read(case['closed_observation'])['rows'])
    for variant in ('original','candidate'):
        report=p/variant;output=WORK/'n1parity'/variant;proc=output/prefix;bound=built['variants']['n1/'+variant]
        before=read(report/'private-before.json');assert before==read(report/'private-after.json')
        assert before['executable_sha256']==bound['executable_sha256'] and before['physical_sha256']==case['param_card_sha256']
        cards={**case['numerical_cards'],prefix+'MadLoop5_resources/MadLoopParams.dat':next(iter(case['numerical_cards'].values()))}
        assert before['cards']==cards
        for n,h in cards.items():match(output/n,h);assert (output/n).resolve().is_relative_to(output.resolve())
        match(output/'Cards/param_card.dat',case['param_card_sha256']);match(proc/'check',bound['executable_sha256'])
        for n,h in bound['sources'].items():match(output/n,h)
        for n,h in bound['objects'].items():match(output/n,h)
        for n,h in case['numerical_objects'].items():
            if n not in (prefix+'check_sa.o',prefix+'TIRUST_interface.o'):match(output/n,h)
        assert not (proc/'worker-protocol.fifo').exists()
        expected={**bound['runtime']['files'],str(proc/'check'):bound['executable_sha256']};assert len(expected)==16
        extra=seal['allowed_extra_mappings'];mapids={}
        for edge in ('before','after'):
            m=read(report/('maps-'+edge+'.json'));assert all(m['files'].get(n)==h for n,h in expected.items())
            assert all({**expected,**extra}.get(n)==h for n,h in m['files'].items())
            paths={line.split(None,5)[5] for line in m['maps'].splitlines() if len(line.split(None,5))==6 and line.split(None,5)[5].startswith('/')}
            assert paths==set(m['files']) and not any(n.endswith(' (deleted)') for n in paths)
            for n,h in m['files'].items():match(n,h)
            assert any(x['pid']==m['pid'] for x in terminal['cleanup']['observed_owned_processes'])
            mapids[edge]=digest(report/('maps-'+edge+'.json'))
        cmdfiles=list((report/'commands').glob('*.command.json'));assert len(cmdfiles)==2
        for file in cmdfiles:
            name=file.name.removesuffix('.command.json');cmd=read(file);term=read(file.with_name(name+'.terminal.json'))
            assert cmd['argv']==[bound['runtime']['loader'],'--list',str(proc/'check')] and term['returncode']==0
            match(file.with_name(name+'.stdout.txt'),term['stdout_sha256']);queries+=1
        assert not re.search(r'##W03\b',(report/'worker.log').read_text(),re.I)
        ready=read(report/'ready.json');assert [ready[k] for k in ('points','ndim','nso','nborn')]==[100,1,1,1]
        warm=read(report/'warmup.json');assert warm['cold_seconds']==ready['cold_seconds']
        learning=read(report/'learning-comparison.json')
        text=(report/'warmup.dat').read_text();assert text==(proc/'warmup.dat').read_text()==warm['raw_outputs']['warmup.dat']
        assert (report/'dimensions.dat').read_text()==(proc/'dimensions.dat').read_text()==warm['raw_outputs']['dimensions.dat']
        assert list(map(int,warm['raw_outputs']['dimensions.dat'].split()))==[1,1,1]
        raw[variant]={'words':(report/'exact/exact-words.dat').read_text(),'ieee':(report/'exact/exact-ieee.dat').read_text(),
            'warm':warm,'warmtext':text,'learning':learning,'historical_comparison':read(report/'exact/historical-comparison.json')}
        assert raw[variant]['words']==(proc/'exact-words.dat').read_text() and raw[variant]['ieee']==(proc/'exact-ieee.dat').read_text()
        bindings[variant]={'executable_sha256':bound['executable_sha256'],'maps_sha256':mapids,'runtime_providers':15,'four_cards':cards}
    analyzer={};exec(compile((SRC/'analysis.py').read_bytes(),str(SRC/'analysis.py'),'exec'),analyzer)
    tree=ast.parse((ROOT/'tools/tirust_benchmark.py').read_bytes());tree.body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare_rows'];assert len(tree.body)==1
    numerical={};exec(compile(tree,'sealed-compare_rows','exec'),numerical)
    blocked=[];saved=[]
    def deny(*a,**kw):blocked.append(repr(a[:2]));raise RuntimeError('Forbidden API during pure parity replay')
    try:
        for obj,n in ((builtins,'open'),(io,'open'),(io,'open_code'),(os,'open'),(os,'system'),(os,'popen'),(subprocess,'Popen'),(subprocess,'run'),(subprocess,'call'),(subprocess,'check_call'),(subprocess,'check_output'),(ctypes,'CDLL'),(ctypes,'PyDLL')):
            saved.append((obj,n,getattr(obj,n)));setattr(obj,n,deny)
        parsed={};learning_counts={};hist=lambda text:[list(map(int,line.split()[:4])) for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
        for variant in ('original','candidate'):
            r=raw[variant];rows=analyzer['exact'](r['words'],case['expected_codes']);ieee=analyzer['ieee'](r['ieee'])
            assert rows==result['lanes'][variant]['rows'] and ieee==result['lanes'][variant]['ieee']
            comparison=analyzer['compare_variants'](historical,rows,numerical['compare_rows'])
            assert comparison==result['lanes'][variant]['historical_comparison']==r['historical_comparison'] and comparison['passed']
            actual=hist(r['warmtext']);previous=hist(historical_text);learning=r['learning']
            assert actual==previous==learning['actual_call_point_order_status']==learning['historical_call_point_order_status']
            assert learning['history_matches'] and learning['raw_byte_identity']==(r['warmtext']==historical_text)
            groups=[]
            for line in r['warmtext'].splitlines():
                if not line.strip() or line.lstrip().startswith('#'):continue
                f=line.split();assert len(f)==9;call=int(f[0])
                if not groups or groups[-1][0]!=call:
                    assert not groups or call>groups[-1][0];groups.append((call,[]))
                groups[-1][1].append(f)
            window=[g for g in groups if g[0]>0][-100:];assert [x[0] for x in window]==list(range(1,101))
            warmrows=[]
            for call,entries in window:
                assert [(int(f[1]),int(f[2]),int(f[3])) for f in entries]==[(call,0,219),(call,1,219)]
                for f in entries:
                    values=list(map(float,f[4:]));assert all(math.isfinite(v) for v in values) and values[-1]>=0
                    warmrows.append({'point':call,'order':int(f[2]),'status':219,'coefficients':values[:4],'accuracy':values[4],'actual_backend':9,'precision':'DP'})
            assert warmrows==r['warm']['rows'] and r['warm']['status_counts']=={'219':100}
            lc=analyzer['compare_variants'](historical,words(warmrows),numerical['compare_rows'])
            assert lc==learning['steady_full100_comparison'] and lc['passed']
            parsed[variant]={'rows':rows,'ieee':ieee};learning_counts[variant]={'steady_calls':100,'rows':200,'status':219,'whole_history_rows':len(actual),'raw_history_identical':learning['raw_byte_identity']}
        comparison=analyzer['compare_variants'](parsed['original']['rows'],parsed['candidate']['rows'],numerical['compare_rows'])
        assert comparison==result['comparison'] and comparison['passed'] and comparison['all_coefficient_words_equal'] and comparison['all_accuracy_words_equal']
        assert comparison['coefficient_values_compared']==800 and comparison['accuracy_difference_count']==comparison['coefficient_word_difference_count']==0
        assert parsed['original']==parsed['candidate'] and not blocked
    finally:
        for obj,n,value in reversed(saved):setattr(obj,n,value)
    assert read(p/'cross-variant-comparison.json')==comparison and read(p/'ieee-comparison.json')=={'observed_states_equal':True}
    match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    receipt={'schema':'independent-O3-n1-parity-audit-v1','status':'PASS','source_index_sha256':SOURCE,'build_terminal_sha256':BUILD,
        'parity_terminal_sha256':TERMINAL,'parity_result_sha256':RESULT,'pure_raw_replay_exact':True,'learning':learning_counts,
        'public_calls_each':100,'public_status_each':219,'coefficient_words_compared':800,'accuracy_words_compared':200,
        'coefficient_word_differences':0,'accuracy_word_differences':0,'strict_observed_IEEE_equal':True,
        'existing_3e6_and_1e8_comparators_replayed':True,'runtime_bindings':bindings,'closed_runtime_loader_receipts':queries,
        'W03_console_records':0,'recorded_cleanup_survivors':0,'forbidden_API_attempts':len(blocked),
        'scope':'N1 native-DP physical parity only; no QP coverage, trap freedom, newly raised flags, timing or promotion claim.',
        'separate_N1_timing_prerequisite_clear':True,'candidate_promoted':False,'audit_native_calls':0,'audit_compiler_calls':0,'audit_loader_calls':0,
        'distinct_resolved_files_hashed':len(seen),'distinct_resolved_bytes_hashed':sum(x[0][2] for x in seen.values()),
        'audit_source_sha256':digest(Path(__file__)),'elapsed_seconds':time.monotonic()-start}
    out=HERE/'receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','receipt':str(out),'sha256':digest(out),'elapsed':receipt['elapsed_seconds']},sort_keys=True))

if __name__=='__main__':main()
