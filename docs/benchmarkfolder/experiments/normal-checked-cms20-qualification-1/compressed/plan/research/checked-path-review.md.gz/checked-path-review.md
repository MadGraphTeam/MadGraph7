# Source-only checked-path research

No implementation, compiler, loader, amplitude, native experiment, or Git operation was performed. The inspected scientific source is original candidate2, seal `ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74`, not matched-private8. `source-bindings.json` records actual file hashes. Runtime support is not established by this review.

## Source names used below

- C2: `.tirust-build/kinematic-invariant-amplitude-proposal-2/candidate/`.
- Donor: `.tirust-build/kinematic-invariant-amplitude-executor-2/work/builds/cms/candidate/SubProcesses/P0_epem_mupmum/`.
- Checked: `.tirust-build/current-cms-replay-2/workers/candidate-9-auto/cms_ew_n2_epem_mupmum/`.
- Protocol: `docs/benchmarkfolder/experiments/current-cms-replay-supervisor-1/protocol/`.

## Existing checked worker and force policy

Use Checked `SubProcesses/P0_epem_mupmum/check_sa.f` as the modern checked-worker policy reference, with Checked `Cards/MadLoopParams.dat`. The worker sets `FORCE_STABILITY_CHECK(.TRUE.)` at line67, calls THRES with requested precision -1 at74, and retains the bootstrap. Its subsequent `1000+NPOINTS` warmup loop (79ff) is unsuitable for the proposed one-bootstrap/one-measurement bound. Preserve the checked call policy, not that long warmup loop. Protocol `tirust_benchmark.py:807-817` explicitly admits only CTModeRun=-1 and CTModeInit=1.

The checked card uses backend9, LoopPoleMode0, full finite evaluation, true QP integrand, CTModeRun=-1, MLStabThres1e-3 and both rotations0. Its cache is -1; a proposal retaining the candidate2 diagnostic cache0 must identify that explicit difference. Candidate2 fixed-mode cards already use cache0, full finite/poles, genuine QP. Do not silently change physics, threshold, rotations, model or OSThres.

Retain FORCE true to avoid weakening the existing worker. C2 `loop_matrix.f:2991-2998` repeats SLOOPMATRIX only if H=1 or total accuracy<0. Qualified219/323 therefore cause exactly one actual SLOOP entry per THRES call. Count actual entries at the wrapper/implementation boundary (26/32), not just driver calls. Any extra evaluation is retained and fails the proposed accounting bound; do not retry or silently raise the bound.

LoopPoleMode0 triggers BYPASS_FILTERS (`loop_matrix.f:572`) and temporarily sets CHECKPHASE=false, HELDOUBLECHECKED=true, all helicities and groups enabled (889-904). It does not bypass stability: CTModeRun=-1 enters the ordinary check block1428. Postcall INIT flags are restored at1802-1812; they are restored state, not a readiness failure. Label this as checked full-sum/filter-bypass execution, not default filter initialization. LoopPoleMode=-1 with one bootstrap would need a different readiness plan.

## Failure flags, contributions, returns and accuracy

The FPE flags are sticky logical reduction-failure indicators for the current precision/backend attempt, not a hardware IEEE exception audit. Both reset at outer entry (`loop_matrix.f:825-828`). Backend9 native/validation failure or nonfinite contraction sets DP at `TIR_interface.f:835-862`, QP at `TIRUST_interface.f:504-524`. Native failure returns zeroed placeholder contributions with STABLE=false; those placeholders are not valid results. The aggregate NaN guard also sets the active precision flag (`loop_matrix.f:1178-1187`).

Each pass resets S(group,order)=true then invokes each selected group (`loop_matrix.f:1145-1157`). Thus a final all-true S array does not prove previous passes or actual execution; require pass/group coverage and each post-adapter STABLE value. Fixed-mode contribution warnings at1173 are disabled when CTModeRun=-1, so absence of a warning is not a success criterion.

The ordinary sequence is DP mode1, DP mode2 (1461), then configured DP rotations. It evaluates DP accuracy (1602), replacing accuracy by1 if the DP flag was raised (1607-1611). With backend9 only and failure at threshold, it resets BOTH flags (1657-1658), sets DOING_QP_EVALS=true and CTMODE4, then rebuilds through200 (1660-1667). QP mode4 and mode5 plus configured rotations use the same ordinary checks. A prior DP flag must be retained in trace evidence; the final flags should be clear after successful QP. Requiring every native call in the entire worker to succeed would incorrectly reject a legitimate rescue.

QP accuracy is computed at1511, forced to1 on a QP flag1516-1520, then checked against MLStabThres1527. Stable DP is H2/U9 (1741-1743). Successful QP rescue is H3/U3 (1524-1526). Exhausted failure is H4/U0. T is2 if MP_DONE_ONCE, otherwise1 (1758-1762). Exact successful backend9 codes are219 or323 for this single-backend/genuine-QP plan. Require323 only when claiming exercised DP-to-QP rescue; a legitimate219 means rescue was unexercised, not a reason to force QP. Reject unknown H1, initialization T3/4, H4, other backend aliases or inconsistent split-order codes. Donor `MadLoopCommons.f:271-340` is the authoritative H/U alias mapping; `loop_matrix.f:2906-2944` documents H/T/U. MP_DONE_ONCE is set even when QP coefficients merely copy DP (mp_compute_loop_coefs199), so T2 alone does not prove a genuine QP numerator.

Acceptance should require finite final Born/finite/single/double outputs for both orders0/1; finite nonnegative accuracy for each order, strictly below the bound card threshold; valid219/323; final flags false; complete pass/group records and all STABLE/native status successes in the accepted precision epoch. Retain DP failure status/error/flags/accuracy evidence without reading failed tensor coefficients. For a rescue claim require actual ordered DP1/2 attempts, evidence of threshold failure, reset/transition, and successful QP4/5, with actual QP producer true. QP checking failure cannot be promoted by a small final numerical difference.

The host accuracy estimator is not the card's illustrative two-number expression: `loop_matrix.f:2059-2091` forms each Laurent range and midpoint, then a weighted aggregate over three Laurent slots. It zeroes unselected-order accuracies and treats NaN specially (2101-2117). Retain the exact returned accuracy and require finiteness independently; the stability decision is separate from the external3e-6/target1e-8 numerical comparison. Failed outputs remain opaque; compare only after all native/host/contribution gates.

NLO statistics (`Template/NLO/SubProcesses/BinothLHA.f:479-509`) count H2 as stable, H3 as rescued, H4 as exceptional, and T2/4 as QP used. Dedicated TIRust counters identify H2/U9 and H3/U3; they count returned amplitudes, not tensor calls. Standalone THRES does not update those NLO counters. Use the trace/return histogram for this private run. `TIRUST_QP_COUNT=1` in loop_matrix128-130 is backend availability, not an evaluation counter. NRS retry counters apply only to backend8 and should remain zero here.

## Provenance, direction and rotation lifecycle

No metadata-only invalidation fix was identified for a single backend9, true QP integrand, full-helicity checked path. Do not make a scientific change preemptively.

C2 `loop_matrix.f:501-503` resets DP/QP environment tokens and QP producer each actual outer entry;827 resets MP_DONE and829 MP_PS_SET. The DP token is captured immediately before HELAS at1065. At1021-1027 a false MP_DONE causes QP token capture and private QP numerator production; the returned producer flag is taken from actual backend/options (`mp_compute_loop_coefs.f:185-191`, genuine/copy branch320-325). MP_DONE is then true. Dispatch1149-1157 passes the matching token/producer through private loop_CT_calls. Public old helpers intentionally carry unknown provenance.

Direction checks jump directly to300, reusing the same numerator, external W/MP_W and environment provenance. Modes2/5 reverse and negate corners and permute masses with the first fixed. PC_BUILD_CHORD must be joined to actual mode and ordered native shifts/masses, including nonzero conservation residual q0. These modes are source-supported but were not qualified by the prior mode4-only native comparison. TIRust CHECK_PASS is true exactly for2/5 (`TIRUST_interface.f:158/339`); record it rather than inferring independence from a repeated function name. Cache0 prevents primary/check tensor reuse for this bounded diagnostic.

Rotations go through200 and clear caches (`loop_matrix.f:971-978`). QP MP_ROTATE_PS invalidates MP_DONE (Donor improve_ps564), so the next200 rebuilds/captures genuine QP provenance. Even restoring rotation0 invalidates MP_DONE, which is safe. Full cleanup occurs1814-1836. Environment tokens encode arithmetic controls, not event identity; repeated token bits across events/passes are expected. Join outer-entry ID, precision/backend epoch, direction mode, rotation index, producer generation, group and split order. Capture the real external momenta and native inputs when needed. Mixed backends, changing QP-integrand options while MP_DONE is true, direct public diagnostic entrypoints and multiple workers sharing COMMON state are outside this narrow lineage conclusion.

## Minimal bounded evidence proposal

Preserve arithmetic and decision branches. Use a bounded private integer recorder, flushed after ordinary returns; retain whole stdout and error framing. Record actual SLOOP entry/exit, effective checked flags, pass begin and end, precision/backend epoch, current mode/rotation, native begin/end status and immediate error, post-adapter STABLE and DP/QP flags, host accuracy/decision, DP-to-QP reset transition, actual QP producer and MP_DONE lifecycle. Do not read uninitialized native STATUS on pre-native support/kinematic early returns; an adapter completion with STABLE=false must still be recorded even if no native call occurred. Capture no failed coefficient arrays.

With26groups, onebackend9, rotations0, and exactly two actual SLOOP entries, maximum native calls is26*(2DP+2QP)*2=208 per worker; ordinary DP bootstrap then rescued CMS20 would be156. Original plus candidate would have maximum416, with distinct contexts and no retry. With two rotations per precision the maximum is416 per worker. Bind chosen rotations in the plan; fail on overflow, missing footer, incomplete pass/group coverage, unexpected entry count, timeout or unclosed process. FORCE true must not be disabled to satisfy a call budget. Stop qualification on extra unknown-triggered entries while retaining all evidence.

This is a source-only recommendation. Root must review the concrete proposal before implementation, build, loading, or native execution. Normal-host stability, broad accuracy, performance and modes2/5 runtime behavior remain unqualified.
