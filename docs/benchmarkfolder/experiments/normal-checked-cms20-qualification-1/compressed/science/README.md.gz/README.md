# Private automatic-check source experiment

This is the concrete observation-only derivative authorized from source plan `9387a2858df75bf34d0940121da6e006fe7648a9d63d241276ba05f94487f7b4`. It has not been compiled, loaded or evaluated. Its scientific base is private candidate2 `ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74`, including unchanged original legacy backend8 and the existing backend9 invariant certificate.

`prepare.py` authenticates parent packets before parsing, derives five instrumented Fortran sources plus an unchanged loop-call source, and emits the patches. Removing every marked NCHECK insertion restores all six candidate files exactly. The original public kinematic helpers and legacy backend8 routines remain byte-identical. The certificate, bound factory, numerical branches, thresholds, model, libraries and compiler policy do not change.

The new checked driver follows the modern CMS checked worker's `FORCE_STABILITY_CHECK(.TRUE.)` and `SLOOPMATRIX_THRES(...,-1D0,...)` policy. It requests one point1 bootstrap, waits for the controller's complete checked bootstrap gate at READY, and permits one CMS20 measurement. There is no long warmup loop, fixed-mode120 acceptance, automatic retry or timing qualification. Its card is the previous candidate9 mode4 card with only `CTModeRun` changed to `-1`; cache0, full poles/finite, genuine QP and threshold1e-3 remain explicit. Saved physical input bytes remain unchanged.

The bounded Fortran recorder stores integer/TRANSFER observations of actual entries, producer generations, direction passes, group attempts, native inputs and statuses, helper branch witnesses, host decisions and resets. It never receives a tensor output array. An ordinary failed DP epoch is retained; only a complete successful accepted epoch can qualify the final amplitude. A handled DP failure followed by genuine QP modes4/5 and return323 is distinct from final-QP failure. A valid checked219 observation leaves rescue coverage unexercised.

`checked_trace.py` checks framing and lifecycle before any amplitude comparison. `checked_geometry.py` replays the source DAG, residual-preserving chords, integer bounds/certificate and native reconstruction for all26 routes/modes1,2,4,5. Original complex threshold predicates are witnessed at their unchanged Fortran branches, not recreated with a different complex division implementation. The exact mode4 input/canonical numerator join to the closed matched9 stream is a separate prerequisite for rescued-QP comparison. See `TRACE_SCHEMA.md` and `GEOMETRY.md` for detailed limits.

The source-only controller is separate at `../kinematic-normal-checked-controller-1`; it reuses the corrected inherited make overlay, actual dependency-schema checks, immutable donor objects/archives, owner/deadline/mutex and provider mapping guards. Its proposed fresh output is `../kinematic-normal-checked-executor-1`. BUILD and RUN require separate admission; source preparation cannot launch them.

The proposed retained attempt has two THRES requests, at most four actual SLOOP entries through the existing forced wrapper, sixteen passes and416 native/group records. Qualification requires exactly two actual entries, no forced rerun, and at most208 native calls. Trace overflow or unknown reuse fails qualification. No production, general exporter, enabled-cache checked path, rotation, point21, broader stability or performance qualification follows from this packet.

Pure source checks:

```sh
source tools/tirust_env.sh
python3 -B -m unittest discover -s .tirust-build/kinematic-normal-checked-source-1 -p 'test_*.py'
python3 -O -B -m unittest discover -s .tirust-build/kinematic-normal-checked-source-1 -p 'test_*.py'
python3 -B .tirust-build/kinematic-normal-checked-source-1/verify.py --reviewed-source-index SOURCE_SHA256
```

These commands are file-only. No native command is supplied by this source packet.
