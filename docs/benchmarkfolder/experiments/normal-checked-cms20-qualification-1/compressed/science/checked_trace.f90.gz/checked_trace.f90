! Private observational recorder. No numerical decisions, output tensor arguments,
! scientific state writes, STOP, or I/O during amplitude arithmetic.
module ml_private_checked_trace
  use ml_private_amplitude_support, only: pc_ik,pc_dp_bits,pc_qp_bits,pc_capture_env
  use mtirust, only: tirust_error_message
  implicit none
  private
  public :: pc_checked_phase_start,pc_checked_flush,pc_checked_sloop_enter,pc_checked_sloop_exit
  public :: pc_checked_pass_begin,pc_checked_pass_end,pc_checked_producer_begin,pc_checked_producer_end
  public :: pc_checked_dp_invalid,pc_checked_decision,pc_checked_rescue_transition,pc_checked_flags_reset
  public :: pc_checked_group_begin,pc_checked_group_end,pc_checked_canonical
  public :: pc_checked_native_begin,pc_checked_native_end,pc_checked_adapter_stage,pc_checked_pair
  integer,parameter :: max_groups=416,max_events=1024,max_error=8192,max_n=4,max_nc=15
  integer,parameter :: format_assert=1/merge(1,0,storage_size(0.0_8)==64.and. &
      digits(0.0_8)==53.and.bit_size(0)==32.and.storage_size(0.0_16)==128.and.digits(0.0_16)==113.and.bit_size(0_pc_ik)==128)
  ! Event kinds: enter1 exit2 pass_begin3 pass_end4 producer_begin5
  ! producer_end6 narrowed_DP7 decision8 rescue9 reset10.
  type event_record
    integer :: seq=0,kind=0,phase=-1,entry=0,pass=0,ni=0,nw=0,iv(40)=0
    integer(pc_ik) :: wv(40)=0
  end type
  type group_record
    integer :: h(22)=0,times(5)=0,stage(2)=[-1,-999]
    integer(pc_ik) :: env(2)=0,external(32)=0,shifts(16)=0,invariants(16)=0,masses(8)=0,scale(1)=0
    integer(pc_ik) :: canonical(30)=0
    integer :: routing(3)=0,we(4)=0,pairing(4)=0,classes(16)=0,have(4)=0
    integer :: pair(16)=0,used(16)=0,chord(16)=0,qerror(64)=0
    integer :: pair_seen(16)=0,pair_flags(4,16)=0
    integer(pc_ik) :: pair_raw(2,16)=0,pair_smat(2,16)=0,pair_ref(16)=0,pair_direct(16)=0
    integer :: error_length=0,error_ambiguous=0,error_bytes(max_error)=0
  end type
  type(event_record),save :: events(max_events)
  type(group_record),save :: groups(max_groups)
  integer,save :: phase=-1,point=0,request=0,clock=0,entry=0,pass=0,ng=0,ne=0
  integer,save :: written_g=0,written_e=0,pending=0,failed=0,omitted=0,generation=0
  integer,save :: generation_dp=0,generation_qp=0,producer_pending=0
  logical,save :: phase_open=.false.,entry_open=.false.,pass_open=.false.
  interface pc_checked_pair
    module procedure pair_dp,pair_qp
  end interface
  interface pc_checked_canonical
    module procedure canonical_dp,canonical_qp
  end interface
  interface pc_checked_native_begin
    module procedure native_begin_dp,native_begin_qp
  end interface
  interface pc_checked_native_end
    module procedure native_end_dp,native_end_qp
  end interface
contains
  subroutine bad()
    failed=1
    if(omitted<huge(omitted)) omitted=omitted+1
  end subroutine
  integer function tick()
    clock=clock+1
    tick=clock
  end function
  subroutine event(kind,iv,wv)
    integer,intent(in)::kind,iv(:)
    integer(pc_ik),intent(in)::wv(:)
    if(.not.phase_open.or.ne>=max_events.or.size(iv)>40.or.size(wv)>40) then
      call bad();return
    endif
    ne=ne+1
    events(ne)%seq=tick();events(ne)%kind=kind;events(ne)%phase=phase
    events(ne)%entry=entry;events(ne)%pass=pass
    events(ne)%ni=size(iv);events(ne)%nw=size(wv)
    events(ne)%iv(:size(iv))=iv;events(ne)%wv(:size(wv))=wv
  end subroutine
  subroutine pc_checked_phase_start(new_phase,saved_point)
    integer,intent(in)::new_phase,saved_point
    if(phase_open.or.entry_open.or.pending/=0.or.ng/=written_g.or.ne/=written_e) call bad()
    if(new_phase/=phase+1.or.new_phase<0.or.new_phase>1) call bad()
    phase=new_phase;point=saved_point;request=request+1;phase_open=.true.
  end subroutine
  subroutine pc_checked_sloop_enter()
    if(entry_open.or.pass_open.or.pending/=0) call bad()
    entry=entry+1;entry_open=.true.;generation_dp=0;generation_qp=0;producer_pending=0
    call event(1,[entry], [integer(pc_ik)::])
  end subroutine
  subroutine pc_checked_sloop_exit(h,t,u,acc,fpe_dp,fpe_qp)
    integer,intent(in)::h,t,u
    real(kind=8),intent(in)::acc(0:1)
    logical,intent(in)::fpe_dp,fpe_qp
    if(.not.entry_open.or.pass_open.or.pending/=0.or.producer_pending/=0) call bad()
    call event(2,[h,t,u,merge(1,0,fpe_dp),merge(1,0,fpe_qp)],pc_dp_bits(acc))
    entry_open=.false.
  end subroutine
  subroutine pc_checked_pass_begin(mode,backend,checkphase,heldoublechecked,mp_done,mp_done_once,eval_done,stab_index)
    integer,intent(in)::mode,backend,stab_index
    logical,intent(in)::checkphase,heldoublechecked,mp_done,mp_done_once,eval_done(:)
    integer::mask,j
    if(.not.entry_open.or.pass_open.or.pending/=0.or.size(eval_done)>20) call bad()
    mask=0
    do j=1,min(size(eval_done),20)
      if(eval_done(j)) mask=ibset(mask,j-1)
    enddo
    pass=pass+1;pass_open=.true.
    call event(3,[mode,backend,merge(1,0,checkphase),merge(1,0,heldoublechecked), &
        merge(1,0,mp_done),merge(1,0,mp_done_once),mask,stab_index], [integer(pc_ik)::])
  end subroutine
  subroutine pc_checked_pass_end(s,fpe_dp,fpe_qp)
    logical,intent(in)::s(1,26),fpe_dp,fpe_qp
    if(.not.pass_open.or.pending/=0) call bad()
    call event(4,[merge(1,0,fpe_dp),merge(1,0,fpe_qp),reshape(merge(1,0,s),[26])], [integer(pc_ik)::])
    pass_open=.false.
  end subroutine
  subroutine pc_checked_producer_begin(width,env)
    integer,intent(in)::width
    integer(pc_ik),intent(in)::env
    if(.not.entry_open.or.producer_pending/=0.or.(width/=64.and.width/=128)) call bad()
    generation=generation+1;producer_pending=width
    if(width==64) generation_dp=generation
    if(width==128) generation_qp=generation
    call event(5,[width,generation],[env])
  end subroutine
  subroutine pc_checked_producer_end(width,genuine,env,external_bits)
    integer,intent(in)::width
    logical,intent(in)::genuine
    integer(pc_ik),intent(in)::env,external_bits(32)
    integer::gen
    gen=generation_dp
    if(width==128) gen=generation_qp
    if(producer_pending/=width) call bad()
    call event(6,[width,gen,merge(1,0,genuine)],[env,external_bits])
    producer_pending=0
  end subroutine
  subroutine pc_checked_dp_invalid()
    call event(7,[generation_dp],[integer(pc_ik)::])
    generation_dp=0
  end subroutine
  subroutine pc_checked_decision(width,acc,threshold,fpe_dp,fpe_qp)
    integer,intent(in)::width
    real(kind=8),intent(in)::acc(0:1),threshold
    logical,intent(in)::fpe_dp,fpe_qp
    if(pass_open.or.pending/=0) call bad()
    call event(8,[width,merge(1,0,fpe_dp),merge(1,0,fpe_qp)], [pc_dp_bits(acc),pc_dp_bits(threshold)])
  end subroutine
  subroutine pc_checked_rescue_transition(fpe_dp,fpe_qp)
    logical,intent(in)::fpe_dp,fpe_qp
    call event(9,[merge(1,0,fpe_dp),merge(1,0,fpe_qp)],[integer(pc_ik)::])
  end subroutine
  subroutine pc_checked_flags_reset(fpe_dp,fpe_qp)
    logical,intent(in)::fpe_dp,fpe_qp
    call event(10,[merge(1,0,fpe_dp),merge(1,0,fpe_qp)],[integer(pc_ik)::])
  end subroutine
  subroutine pc_checked_group_begin(mode,id,sqso,n,rank,nw,we,pairing,route_ok,producer_ok, &
      chord,classes,have,env,external_bits)
    integer,intent(in)::mode,id,sqso,n,rank,nw,we(nw),pairing(n),chord(0:3,n),classes(n,n)
    logical,intent(in)::route_ok,producer_ok,have(n)
    integer(pc_ik),intent(in)::env,external_bits(32)
    integer::k,width,gen,nc
    if(.not.pass_open.or.pending/=0.or.ng>=max_groups) then
      call bad();return
    endif
    if(n<1.or.n>4.or.rank<0.or.rank>2.or.nw<1.or.nw>4) then
      call bad();return
    endif
    width=64;gen=generation_dp
    if(mode>=4) then
      width=128;gen=generation_qp
    endif
    nc=(rank+1)*(rank+2)*(rank+3)*(rank+4)/24
    ng=ng+1;k=ng;pending=k
    groups(k)%h=[k,phase,entry,pass,mode,9,id,sqso,n,rank,nc,width,merge(113,53,width==128), &
        gen,0,-999,0,0,0,0,0,0]
    groups(k)%times(1)=tick()
    groups(k)%env(1)=env;groups(k)%external=external_bits
    groups(k)%routing=[nw,merge(1,0,route_ok),merge(1,0,producer_ok)]
    groups(k)%we(:nw)=we;groups(k)%pairing(:n)=pairing
    groups(k)%classes(:n*n)=reshape(classes,[n*n]);groups(k)%have(:n)=merge(1,0,have)
    groups(k)%chord(:4*n)=reshape(chord,[4*n])
  end subroutine
  subroutine pc_checked_group_end(stable,fpe_dp,fpe_qp)
    logical,intent(in)::stable,fpe_dp,fpe_qp
    integer::k
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    groups(k)%h(17:20)=[1,merge(1,0,stable),merge(1,0,fpe_dp),merge(1,0,fpe_qp)]
    groups(k)%h(22)=merge(1,0,groups(k)%h(15)==0)
    if(groups(k)%h(15)==1.and.groups(k)%times(4)==0) call bad()
    groups(k)%times(5)=tick();pending=0
  end subroutine
  subroutine pc_checked_adapter_stage(stage,status)
    integer,intent(in)::stage,status
    if(pending<1.or.pending>ng) then
      call bad();return
    endif
    if(stage<0.or.stage>5.or.stage<groups(pending)%stage(1)) call bad()
    groups(pending)%stage=[stage,status]
  end subroutine
  subroutine native_metadata(mode,n,rank,classes,have,pair,used,chord,qerror,env,check_pass,cache,finite,pole)
    integer,intent(in)::mode,n,rank,classes(n,n),chord(0:3,n),qerror(0:3,n,n),pole
    logical,intent(in)::have(n),pair(n,n),used(n,n),check_pass,cache,finite
    integer(pc_ik),intent(in)::env
    integer::k
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    if(any(groups(k)%h([5,9,10])/=[mode,n,rank]).or.groups(k)%h(15)/=0.or.groups(k)%times(2)==0) call bad()
    if(any(groups(k)%classes(:n*n)/=reshape(classes,[n*n])).or. &
       any(groups(k)%have(:n)/=merge(1,0,have)).or.any(groups(k)%chord(:4*n)/=reshape(chord,[4*n]))) call bad()
    if(groups(k)%env(1)/=env) call bad()
    if(any(groups(k)%pair_seen(:n*n)/=1)) call bad()
    groups(k)%env(2)=pc_capture_env()
    groups(k)%pair(:n*n)=reshape(merge(1,0,pair),[n*n]);groups(k)%used(:n*n)=reshape(merge(1,0,used),[n*n])
    groups(k)%qerror(:4*n*n)=reshape(qerror,[4*n*n])
    ! Options are recorded in a lifecycle record immediately before native entry.
    call event(11,[k,merge(1,0,check_pass),merge(1,0,cache),merge(1,0,finite),pole],[integer(pc_ik)::])
    groups(k)%stage=[5,-999]
    groups(k)%h(15)=1;groups(k)%times(3)=tick()
  end subroutine
  subroutine capture_error(status)
    integer,intent(in)::status
    character(len=max_error)::message
    integer::k,j,length
    ! Must be the first operation after the original evaluate call.
    call tirust_error_message(message)
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    length=len_trim(message)
    groups(k)%error_length=length
    ! 512 can also be a full Fortran local_error; retain ambiguity conservatively.
    groups(k)%error_ambiguous=merge(1,0,length==512.or.length==max_error)
    do j=1,length
      groups(k)%error_bytes(j)=iachar(message(j:j))
    enddo
    groups(k)%h(16)=status
  end subroutine
  subroutine finish_native(after)
    type(group_record),intent(in)::after
    integer::k
    logical::same
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    if(groups(k)%h(15)/=1.or.groups(k)%times(4)/=0) call bad()
    same=all(groups(k)%shifts==after%shifts).and.all(groups(k)%invariants==after%invariants).and. &
      all(groups(k)%masses==after%masses).and.all(groups(k)%scale==after%scale)
    groups(k)%h(21)=merge(1,0,same);groups(k)%times(4)=tick()
  end subroutine
  subroutine pair_dp(i,j,raw_valid,raw_diffsq,s_mat,ref_normalization,mass_mask,zero_branch,use_direct,direct_value)
    integer,intent(in)::i,j,mass_mask
    logical,intent(in)::raw_valid,zero_branch,use_direct
    complex(kind=8),intent(in)::raw_diffsq,s_mat
    real(kind=8),intent(in)::ref_normalization,direct_value
    integer::k,n,index
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    n=groups(k)%h(9)
    if(i<1.or.i>n.or.j<1.or.j>n.or.groups(k)%h(12)/=64) then
      call bad();return
    endif
    index=(j-1)*n+i
    if(groups(k)%pair_seen(index)/=0.or.mass_mask<0.or.mass_mask>3) call bad()
    groups(k)%pair_seen(index)=1
    groups(k)%pair_flags(:,index)=[merge(1,0,raw_valid),mass_mask,merge(1,0,zero_branch),merge(1,0,use_direct)]
    groups(k)%pair_raw(:,index)=[pc_dp_bits(real(raw_diffsq,kind=8)),pc_dp_bits(aimag(raw_diffsq))]
    groups(k)%pair_smat(:,index)=[pc_dp_bits(real(s_mat,kind=8)),pc_dp_bits(aimag(s_mat))]
    groups(k)%pair_ref(index)=pc_dp_bits(ref_normalization)
    groups(k)%pair_direct(index)=pc_dp_bits(direct_value)
  end subroutine
  subroutine pair_qp(i,j,raw_valid,raw_diffsq,s_mat,ref_normalization,mass_mask,zero_branch,use_direct,direct_value)
    integer,intent(in)::i,j,mass_mask
    logical,intent(in)::raw_valid,zero_branch,use_direct
    complex(kind=16),intent(in)::raw_diffsq,s_mat
    real(kind=16),intent(in)::ref_normalization,direct_value
    integer::k,n,index
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    n=groups(k)%h(9)
    if(i<1.or.i>n.or.j<1.or.j>n.or.groups(k)%h(12)/=128) then
      call bad();return
    endif
    index=(j-1)*n+i
    if(groups(k)%pair_seen(index)/=0.or.mass_mask<0.or.mass_mask>3) call bad()
    groups(k)%pair_seen(index)=1
    groups(k)%pair_flags(:,index)=[merge(1,0,raw_valid),mass_mask,merge(1,0,zero_branch),merge(1,0,use_direct)]
    groups(k)%pair_raw(:,index)=[pc_qp_bits(real(raw_diffsq,kind=16)),pc_qp_bits(aimag(raw_diffsq))]
    groups(k)%pair_smat(:,index)=[pc_qp_bits(real(s_mat,kind=16)),pc_qp_bits(aimag(s_mat))]
    groups(k)%pair_ref(index)=pc_qp_bits(ref_normalization)
    groups(k)%pair_direct(index)=pc_qp_bits(direct_value)
  end subroutine
  subroutine canonical_dp(canonical)
    complex(kind=8),intent(in)::canonical(:)
    integer::k,j,nc
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    nc=groups(k)%h(11)
    if(size(canonical)/=nc.or.groups(k)%h(12)/=64.or.groups(k)%times(2)/=0) then
      call bad();return
    endif
    do j=1,nc
      groups(k)%canonical(2*j-1)=pc_dp_bits(real(canonical(j),kind=8))
      groups(k)%canonical(2*j)=pc_dp_bits(aimag(canonical(j)))
    enddo
    groups(k)%times(2)=tick()
  end subroutine
  subroutine copy_dp(n,p,s,m,mu2,out)
    integer,intent(in)::n
    real(kind=8),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=8),intent(in)::m(n)
    type(group_record),intent(inout)::out
    integer::j
    out%shifts(:4*n)=reshape(pc_dp_bits(p),[4*n])
    out%invariants(:n*n)=reshape(pc_dp_bits(s),[n*n])
    do j=1,n
      out%masses(2*j-1)=pc_dp_bits(real(m(j),kind=8))
      out%masses(2*j)=pc_dp_bits(aimag(m(j)))
    enddo
    out%scale(1)=pc_dp_bits(mu2)
  end subroutine
  subroutine native_begin_dp(mode,n,rank,p,s,m,mu2,classes,have,pair,used,chord,qerror, &
      env,check_pass,cache,finite,pole)
    integer,intent(in)::mode,n,rank,classes(n,n),chord(0:3,n),qerror(0:3,n,n),pole
    real(kind=8),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=8),intent(in)::m(n)
    logical,intent(in)::have(n),pair(n,n),used(n,n),check_pass,cache,finite
    integer(pc_ik),intent(in)::env
    if(pending<1.or.pending>ng.or.n<1.or.n>4) then
      call bad();return
    endif
    if(groups(pending)%h(12)/=64) call bad()
    call native_metadata(mode,n,rank,classes,have,pair,used,chord,qerror,env,check_pass,cache,finite,pole)
    call copy_dp(n,p,s,m,mu2,groups(pending))
  end subroutine
  subroutine native_end_dp(status,p,s,m,mu2)
    integer,intent(in)::status
    real(kind=8),intent(in)::p(:,:),s(:,:),mu2
    complex(kind=8),intent(in)::m(:)
    type(group_record)::after
    integer::n
    call capture_error(status)
    if(pending<1.or.pending>ng) return
    n=groups(pending)%h(9)
    if(any(shape(p)/=[4,n]).or.any(shape(s)/=[n,n]).or.size(m)/=n.or.groups(pending)%h(12)/=64) then
      call bad();return
    endif
    after=group_record()
    call copy_dp(n,p,s,m,mu2,after)
    call finish_native(after)
  end subroutine
  subroutine canonical_qp(canonical)
    complex(kind=16),intent(in)::canonical(:)
    integer::k,j,nc
    k=pending
    if(k<1.or.k>ng) then
      call bad();return
    endif
    nc=groups(k)%h(11)
    if(size(canonical)/=nc.or.groups(k)%h(12)/=128.or.groups(k)%times(2)/=0) then
      call bad();return
    endif
    do j=1,nc
      groups(k)%canonical(2*j-1)=pc_qp_bits(real(canonical(j),kind=16))
      groups(k)%canonical(2*j)=pc_qp_bits(aimag(canonical(j)))
    enddo
    groups(k)%times(2)=tick()
  end subroutine
  subroutine copy_qp(n,p,s,m,mu2,out)
    integer,intent(in)::n
    real(kind=16),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=16),intent(in)::m(n)
    type(group_record),intent(inout)::out
    integer::j
    out%shifts(:4*n)=reshape(pc_qp_bits(p),[4*n])
    out%invariants(:n*n)=reshape(pc_qp_bits(s),[n*n])
    do j=1,n
      out%masses(2*j-1)=pc_qp_bits(real(m(j),kind=16))
      out%masses(2*j)=pc_qp_bits(aimag(m(j)))
    enddo
    out%scale(1)=pc_qp_bits(mu2)
  end subroutine
  subroutine native_begin_qp(mode,n,rank,p,s,m,mu2,classes,have,pair,used,chord,qerror, &
      env,check_pass,cache,finite,pole)
    integer,intent(in)::mode,n,rank,classes(n,n),chord(0:3,n),qerror(0:3,n,n),pole
    real(kind=16),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=16),intent(in)::m(n)
    logical,intent(in)::have(n),pair(n,n),used(n,n),check_pass,cache,finite
    integer(pc_ik),intent(in)::env
    if(pending<1.or.pending>ng.or.n<1.or.n>4) then
      call bad();return
    endif
    if(groups(pending)%h(12)/=128) call bad()
    call native_metadata(mode,n,rank,classes,have,pair,used,chord,qerror,env,check_pass,cache,finite,pole)
    call copy_qp(n,p,s,m,mu2,groups(pending))
  end subroutine
  subroutine native_end_qp(status,p,s,m,mu2)
    integer,intent(in)::status
    real(kind=16),intent(in)::p(:,:),s(:,:),mu2
    complex(kind=16),intent(in)::m(:)
    type(group_record)::after
    integer::n
    call capture_error(status)
    if(pending<1.or.pending>ng) return
    n=groups(pending)%h(9)
    if(any(shape(p)/=[4,n]).or.any(shape(s)/=[n,n]).or.size(m)/=n.or.groups(pending)%h(12)/=128) then
      call bad();return
    endif
    after=group_record()
    call copy_qp(n,p,s,m,mu2,after)
    call finish_native(after)
  end subroutine
  subroutine words(seq,tag,data)
    integer,intent(in)::seq
    character(*),intent(in)::tag
    integer(pc_ik),intent(in)::data(:)
    write(76,'(A,1X,I0,1X,A,1X,I0,1X,*(Z32.32,1X))') 'CHECK_WORDS',seq,tag,size(data),data
  end subroutine
  subroutine metadata(seq,tag,data)
    integer,intent(in)::seq,data(:)
    character(*),intent(in)::tag
    write(76,'(A,1X,I0,1X,A,1X,I0,1X,*(I0,1X))') 'CHECK_META',seq,tag,size(data),data
  end subroutine
  subroutine pc_checked_flush()
    integer::k,n,nc,ec
    if(.not.phase_open.or.entry_open.or.pass_open.or.pending/=0.or.producer_pending/=0) call bad()
    write(76,'(A,1X,3(I0,1X))') 'CHECK_BEGIN',phase,point,request
    do k=written_e+1,ne
      write(76,'(A,1X,7(I0,1X))') 'CHECK_EVENT',events(k)%seq,events(k)%kind,events(k)%phase, &
        events(k)%entry,events(k)%pass,events(k)%ni,events(k)%nw
      call metadata(events(k)%seq,'EVENT',events(k)%iv(:events(k)%ni))
      call words(events(k)%seq,'EVENT',events(k)%wv(:events(k)%nw))
    enddo
    do k=written_g+1,ng
      n=groups(k)%h(9);nc=groups(k)%h(11);ec=groups(k)%error_length
      write(76,'(A,1X,*(I0,1X))') 'CHECK_GROUP',groups(k)%h
      call metadata(k,'TIMES',groups(k)%times)
      call metadata(k,'STAGE',groups(k)%stage)
      call words(k,'ENV',groups(k)%env)
      call words(k,'EXTERNAL',groups(k)%external)
      call words(k,'SHIFT',groups(k)%shifts(:4*n))
      call words(k,'INV',groups(k)%invariants(:n*n))
      call words(k,'MASS',groups(k)%masses(:2*n))
      call words(k,'SCALE',groups(k)%scale)
      call words(k,'CANON',groups(k)%canonical(:2*nc))
      call words(k,'PRAW',reshape(groups(k)%pair_raw(:,:n*n),[2*n*n]))
      call words(k,'PSMAT',reshape(groups(k)%pair_smat(:,:n*n),[2*n*n]))
      call words(k,'PREF',groups(k)%pair_ref(:n*n))
      call words(k,'PDIRECT',groups(k)%pair_direct(:n*n))
      call metadata(k,'PSEEN',groups(k)%pair_seen(:n*n))
      call metadata(k,'PFLAGS',reshape(groups(k)%pair_flags(:,:n*n),[4*n*n]))
      call metadata(k,'ROUTE',groups(k)%routing)
      call metadata(k,'WE',groups(k)%we(:groups(k)%routing(1)))
      call metadata(k,'PAIRING',groups(k)%pairing(:n))
      call metadata(k,'CLASS',groups(k)%classes(:n*n))
      call metadata(k,'HAVE',groups(k)%have(:n))
      call metadata(k,'PAIR',groups(k)%pair(:n*n))
      call metadata(k,'USE',groups(k)%used(:n*n))
      call metadata(k,'CHORD',groups(k)%chord(:4*n))
      call metadata(k,'QERROR',groups(k)%qerror(:4*n*n))
      write(76,'(A,1X,I0,1X,I0,1X,I0,1X,*(Z2.2))') 'CHECK_ERROR',k,ec, &
        groups(k)%error_ambiguous,groups(k)%error_bytes(:ec)
    enddo
    write(76,'(A,1X,8(I0,1X))') 'CHECK_END',phase,clock,ng,ne,failed,omitted,pending,producer_pending
    flush(76)
    written_e=ne;written_g=ng;phase_open=.false.
  end subroutine
end module
