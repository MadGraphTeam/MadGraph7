"""Pure bounded checked-run trace parser. Failed tensor outputs are never present.

Parsing returns exact integers/IEEE words. Qualification verifies host lifecycle
and accepted-epoch completeness before permitting any outer coefficient arithmetic.
The separately source-bound geometry verifier is mandatory, not a boolean bypass.
"""
from fractions import Fraction
import hashlib
import re

SCHEMA = 'private-checked-v1'
MAX_BYTES = 16 * 1024 * 1024
MAX_GROUPS, MAX_EVENTS, MAX_ERROR = 416, 1024, 8192
HEX = re.compile(r'[0-9A-F]{32}\Z')
HEX64 = re.compile(r'[0-9A-F]{16}\Z')
INTEGER = re.compile(r'-?(?:0|[1-9][0-9]*)\Z')
FIELDS = ('seq','phase','entry','pass','mode','backend','group','sqso','n','rank','nc',
          'width','digits','generation','native_count','status','complete','stable',
          'fpe_dp','fpe_qp','unchanged','early')
EVENT_SHAPES = {1:(1,0),2:(5,2),3:(8,0),4:(28,0),5:(2,1),6:(3,33),
                7:(1,0),8:(3,3),9:(2,0),10:(2,0),11:(5,0)}
META_TAGS = ('TIMES','STAGE','ROUTE','WE','PAIRING','CLASS','HAVE','PAIR','USE','CHORD','QERROR')
WORD_TAGS = ('ENV','EXTERNAL','SHIFT','INV','MASS','SCALE','CANON','PRAW','PSMAT','PREF','PDIRECT')
CMS_SHAPES = ((3,2),(3,2),(4,2),(4,2),(4,2),(4,2),(4,2),(4,2),(2,0),(3,2),(3,2),(4,2),
              (4,2),(1,0),(2,2),(1,0),(1,0),(2,2),(1,0),(3,2),(3,2),(3,2),(3,2),(4,2),(2,2),(2,2))


def require(ok, message):
    if not ok:
        raise ValueError(message)


def integers(fields):
    require(all(INTEGER.fullmatch(x) and len(x)<=20 for x in fields), 'Malformed integer')
    return [int(x) for x in fields]


def finite_word(word, width):
    if not isinstance(word, str) or not HEX.fullmatch(word) or width not in (64,128):
        return False
    value=int(word,16)
    if value>>width:
        return False
    fraction,exponent=(52,11) if width==64 else (112,15)
    return (value>>fraction)&((1<<exponent)-1) != (1<<exponent)-1


def exact_word(word, width=64):
    """Exact finite binary rational, only for qualified host accuracy/threshold."""
    require(finite_word(word,width),'Nonfinite/invalid word')
    value=int(word,16);f,e,bias=(52,11,1023) if width==64 else (112,15,16383)
    mantissa=value&((1<<f)-1);exponent=(value>>f)&((1<<e)-1)
    power=1-bias-f if exponent==0 else exponent-bias-f
    if exponent:
        mantissa+=1<<f
    if value>>(width-1):
        mantissa=-mantissa
    return Fraction(mantissa*(1<<power),1) if power>=0 else Fraction(mantissa,1<<(-power))


def environment_valid(word):
    if not isinstance(word,str) or not HEX.fullmatch(word):
        return False
    token=int(word,16)
    if token>>64 or token&0xFFFFFFFF00000000 != 0x4B45000000000000:
        return False
    csr=(token>>16)&0xFFFF;cw=token&0xFFFF
    return (csr&0x003F==0 and cw&0xE0C0==0 and csr&0xE040==0 and
            cw&0x0C00==0 and cw&0x0300==0x0300)


def _routes(routes):
    require(isinstance(routes,dict) and set(routes)==set(range(1,27)), 'Expected source-bound26 routes')
    for group,row in routes.items():
        require(set(row)=={'n','rank','sqso','nw','we','pairing'},'Unexpected route schema')
        require(all(type(row[k]) is int for k in ('n','rank','sqso','nw')), 'Noninteger route')
        require((row['n'],row['rank'])==CMS_SHAPES[group-1] and row['sqso']==1,'CMS route differs')
        require(type(row['we']) is list and type(row['pairing']) is list,'Route array differs')
        require(1<=row['nw']<=4 and len(row['we'])==row['nw'] and len(row['pairing'])==row['n'],
                'Route dimensions differ')
        require(all(type(x) is int for x in row['we']+row['pairing']),'Noninteger route array')
        require(sum(row['pairing'])==row['nw'] and all(x>0 for x in row['pairing']),'Bad pairing')


def parse_trace(text, expected_routes, *, complete_phases=(0,1)):
    """Parse complete phase packets; (0,) explicitly permits bootstrap-only evidence.

    No coefficient conversion or acceptance happens here. The exact authenticated
    route dictionary must come from the scientific source packet.
    """
    _routes(expected_routes)
    require(isinstance(text,str) and len(text.encode('utf-8'))<=MAX_BYTES,'Trace byte limit/type')
    require(tuple(complete_phases) in ((0,), (0,1)),'Unsupported phase selection')
    lines=text.splitlines();cursor=0;events=[];groups=[];phases={};all_serials=[]
    prev_clock=0;last_event_serial=0
    def take():
        nonlocal cursor
        require(cursor<len(lines),'Truncated trace')
        fields=lines[cursor].split();cursor+=1
        require(fields,'Blank trace record')
        return fields
    def array(seq, tag, count, words=False):
        fields=take();prefix='CHECK_WORDS' if words else 'CHECK_META'
        require(len(fields)==4+count and fields[:1]==[prefix], 'Wrong record shape: '+tag)
        require(integers([fields[1],fields[3]])==[seq,count] and fields[2]==tag,'Wrong record identity: '+tag)
        if words:
            require(all(HEX.fullmatch(x) for x in fields[4:]),'Malformed word')
            return fields[4:]
        return integers(fields[4:])
    for phase in complete_phases:
        fields=take()
        require(fields[0]=='CHECK_BEGIN' and len(fields)==4,'Missing phase begin')
        ph,point,request=integers(fields[1:])
        require((ph,point,request)==(phase,1 if phase==0 else 20,phase+1),'Phase identity differs')
        begin_g,begin_e=len(groups),len(events)
        while cursor<len(lines) and lines[cursor].split()[:1]==['CHECK_EVENT']:
            fields=take();require(len(fields)==8,'Malformed event header')
            seq,kind,ep,entry,pas,ni,nw=integers(fields[1:])
            require(kind in EVENT_SHAPES and (ni,nw)==EVENT_SHAPES[kind],'Unknown event shape')
            require(ep==phase and seq>prev_clock and entry>=1 and pas>=0,'Event context differs')
            require(seq>last_event_serial,'Event stream reordered')
            last_event_serial=seq
            iv=array(seq,'EVENT',ni);wv=array(seq,'EVENT',nw,True)
            events.append(dict(seq=seq,kind=kind,phase=ep,entry=entry,pass_id=pas,ints=iv,words=wv))
            all_serials.append(seq)
            require(len(events)<=MAX_EVENTS,'Lifecycle event capacity exceeded')
        while cursor<len(lines) and lines[cursor].split()[:1]==['CHECK_GROUP']:
            fields=take();require(len(fields)==23,'Malformed group header')
            g=dict(zip(FIELDS,integers(fields[1:])));seq=g['seq'];n=g['n'];nc=g['nc'];route=expected_routes.get(g['group'])
            require(seq==len(groups)+1 and g['phase']==phase and route is not None,'Group identity differs')
            require(g['entry']>=1 and g['pass']>=1 and g['mode'] in (1,2,4,5) and g['backend']==9,'Group context differs')
            require((n,g['rank'],g['sqso'])==(route['n'],route['rank'],1),'Group source shape differs')
            require(nc==(g['rank']+1)*(g['rank']+2)*(g['rank']+3)*(g['rank']+4)//24,'Coefficient count differs')
            require((g['width'],g['digits'])==((64,53) if g['mode']<4 else (128,113)),'Wrong precision transport')
            require(all(g[k] in (0,1) for k in ('native_count','complete','stable','fpe_dp','fpe_qp','unchanged','early')),
                    'Nonlogical group field')
            md={};md['TIMES']=array(seq,'TIMES',5);md['STAGE']=array(seq,'STAGE',2)
            wd={tag:array(seq,tag,count,True) for tag,count in
                [('ENV',2),('EXTERNAL',32),('SHIFT',4*n),('INV',n*n),('MASS',2*n),('SCALE',1),('CANON',2*nc),('PRAW',2*n*n),('PSMAT',2*n*n),('PREF',n*n),('PDIRECT',n*n)]}
            md['PSEEN']=array(seq,'PSEEN',n*n);md['PFLAGS']=array(seq,'PFLAGS',4*n*n)
            md['ROUTE']=array(seq,'ROUTE',3)
            require(md['ROUTE'][0]==route['nw'] and all(x in (0,1) for x in md['ROUTE'][1:]),'Route flags differ')
            for tag,count in [('WE',route['nw']),('PAIRING',n),('CLASS',n*n),('HAVE',n),('PAIR',n*n),
                              ('USE',n*n),('CHORD',4*n),('QERROR',4*n*n)]:
                md[tag]=array(seq,tag,count)
            require(md['WE']==route['we'] and md['PAIRING']==route['pairing'],'Actual routing differs')
            require(all(x in (0,1) for tag in ('HAVE','PAIR','USE') for x in md[tag]),'Nonlogical metadata')
            fields=take();require(fields[:1]==['CHECK_ERROR'] and len(fields) in (4,5),'Malformed error record')
            es,length,ambiguous=integers(fields[1:4]);encoded=fields[4] if len(fields)==5 else ''
            require(es==seq and 0<=length<=MAX_ERROR and ambiguous in (0,1),'Error bounds differ')
            require(len(encoded)==2*length and re.fullmatch('[0-9A-F]*',encoded) is not None,'Error bytes differ')
            require(ambiguous==int(length in (512,MAX_ERROR)),'Error ambiguity marker differs')
            times=md['TIMES'];nonzero=[x for x in times if x]
            require(nonzero==sorted(set(nonzero)) and all(x>prev_clock for x in nonzero),'Group chronology differs')
            require(times[0]>0 and (times[4]>0)==bool(g['complete']),'Incomplete group framing')
            require(-1<=md['STAGE'][0]<=5,'Unknown adapter stage')
            if g['native_count']:
                require(times[1]>0 and times[2]>0 and times[3]>0 and md['STAGE']==[5,-999], 'Native stage missing')
                require(not g['early'] and 0<=g['status']<=3,'Native completion status differs')
            else:
                require(times[2:4]==[0,0] and g['status']==-999 and g['early']==g['complete'], 'Early return invented native status')
                require(md['STAGE'][0]<5 and not g['unchanged'] and length==0,'Early-return data differs')
            pairs=[]
            for k in range(n*n):
                rv,mask,zero,use=md['PFLAGS'][4*k:4*k+4]
                require(rv in (0,1) and mask in (0,1,2,3) and zero in (0,1) and use in (0,1),'Invalid pair witness')
                pairs.append({'i':k%n+1,'j':k//n+1,'raw_valid':rv,'mass_mask':mask,'zero_branch':zero,'use':use,
                    'words':{'RAW':wd['PRAW'][2*k:2*k+2],'S':wd['PSMAT'][2*k:2*k+2],
                             'REF':wd['PREF'][k:k+1],'DIRECT':wd['PDIRECT'][k:k+1]}})
            require(all(x in (0,1) for x in md['PSEEN']),'Invalid pair seen bit')
            g.update(pairs=pairs,meta=md,words=wd,error={'length':length,'ambiguous':ambiguous,'hex':encoded},times=times)
            groups.append(g);all_serials.extend(nonzero)
            require(len(groups)<=MAX_GROUPS,'Group capacity exceeded')
        fields=take();require(fields[:1]==['CHECK_END'] and len(fields)==9,'Missing phase footer')
        ep,clock,ng,ne,failed,omitted,pending,producer_pending=integers(fields[1:])
        require((ep,ng,ne)==(phase,len(groups),len(events)),'Footer counts differ')
        require(failed in (0,1) and omitted>=0 and pending>=0 and producer_pending>=0,'Footer state malformed')
        require(prev_clock<=clock<=MAX_GROUPS*5+MAX_EVENTS and sorted(all_serials)==list(range(1,clock+1)), 'Missing/duplicate trace chronology')
        phases[phase]={'point':point,'request':request,'clock':clock,'groups':groups[begin_g:],
                       'events':events[begin_e:],'failed':failed,'omitted':omitted,'pending':pending,
                       'producer_pending':producer_pending}
        prev_clock=clock
    require(cursor==len(lines),'Unexpected records after phase footer')
    return {'schema':SCHEMA,'phases':phases,'events':events,'groups':groups,
            'complete_phases':list(complete_phases),'bytes':len(text.encode()),
            'sha256':hashlib.sha256(text.encode()).hexdigest()}


def _word64(word):
    require(isinstance(word,str) and HEX64.fullmatch(word),'Expected64-bit outer word')
    return word.zfill(32)


def qualify_phase(trace, phase, outer, *, geometry_validator=None):
    """Fail closed before output coefficient arithmetic; allow handled DP failures.

    geometry_validator(group,producer) must be the controller's authenticated
    implementation and return a dict with literal passed=True and detailed proof.
    Authenticating that implementation belongs to the sealed controller.
    """
    require(trace.get('schema')==SCHEMA and phase in trace['phases'],'Wrong parsed trace')
    require(callable(geometry_validator),'Source-bound geometry verifier required')
    p=trace['phases'][phase]
    require(not any(p[k] for k in ('failed','omitted','pending','producer_pending')),'Trace failure/overflow/unclosed state')
    require(set(outer)=={'code','output_words','accuracy_words','fpe_dp','fpe_qp'},'Outer schema differs')
    require(type(outer['code']) is int and outer['code'] in (219,323),'Unqualified return code')
    require(type(outer['fpe_dp']) is int and type(outer['fpe_qp']) is int and outer['fpe_dp']==0 and outer['fpe_qp']==0,'Final software failure flag')
    require(type(outer['output_words']) is list and len(outer['output_words'])==8,'Missing outer columns/orders')
    require(type(outer['accuracy_words']) is list and len(outer['accuracy_words'])==2,'Missing outer accuracy')
    outputs=[_word64(x) for x in outer['output_words']]
    accuracy=[_word64(x) for x in outer['accuracy_words']]
    require(all(finite_word(x,64) for x in outputs+accuracy),'Nonfinite final outer word')
    timeline=[]
    for e in p['events']:
        timeline.append((e['seq'],'event',e))
    for g in p['groups']:
        for index,name in enumerate(('group_begin','canonical','native_begin','native_end','group_end')):
            if g['times'][index]:
                timeline.append((g['times'][index],name,g))
    timeline.sort(key=lambda x:x[0])
    entries=[];passes=[];decisions=[];producers={};active={64:None,128:None};pending_prod=None
    current_entry=None;current_pass=None;current_group=None;options={};transition=None;reset=None
    exit_event=None;seen_generation=set();geometry=[];handled_failures=[];epoch_flags=[0,0]
    for serial,kind,row in timeline:
        if kind=='event':
            e=row;iv=e['ints'];wv=e['words'];k=e['kind']
            if k==1:
                require(current_entry is None and current_pass is None and current_group is None,'Nested entry')
                require(iv==[e['entry']],'Entry identity mismatch')
                entries.append(e['entry']);current_entry=e['entry'];active={64:None,128:None};epoch_flags=[0,0]
                require(len(entries)==1,'Forced wrapper rerun is not qualified')
                continue
            require(current_entry==e['entry'],'Event outside actual entry')
            if k==2:
                require(current_pass is None and current_group is None and pending_prod is None,'Exit with unfinished work')
                require(iv[3:]==[0,0] and 100*iv[0]+10*iv[1]+iv[2]==outer['code'],'Exit status/flags mismatch')
                require(wv==accuracy,'Returned accuracy differs from driver')
                exit_event=e;current_entry=None
            elif k==3:
                require(current_pass is None and current_group is None and pending_prod is None,'Nested/unfinished pass')
                mode,backend,checkphase,heldouble,mpdone,mponce,mask,stab=iv
                require(mode in (1,2,4,5) and backend==9 and checkphase==0 and heldouble==1,'Checks not effective')
                require(mpdone in (0,1) and mponce in (0,1),'Bad MP flags')
                expected=[1,2,4,5][len(passes)] if len(passes)<4 else None
                require(mode==expected,'Direction/pass order differs')
                require(stab==(0 if mode in (1,4) else 1),'Stability index differs')
                require(mask==(1 if mode in (1,4) else 3),'EVAL_DONE mask differs')
                if mode>=4:
                    require(transition is not None and reset is not None and mpdone==1 and mponce==1,'QP not naturally entered')
                current_pass={'id':e['pass_id'],'mode':mode,'groups':[],'end':None}
                passes.append(current_pass)
            elif k==4:
                require(current_pass is not None and e['pass_id']==current_pass['id'] and current_group is None,'Pass end mismatch')
                require(all(x in (0,1) for x in iv),'Nonlogical pass status')
                require([g['group'] for g in current_pass['groups']]==list(range(1,27)), 'Missing/duplicate/scheduled group')
                require(iv[2:]==[g['stable'] for g in current_pass['groups']], 'S differs from adapter results')
                require(all(iv[k]>=epoch_flags[k] for k in (0,1)), 'Pass cleared a software flag')
                require(iv[1 if current_pass['mode']<4 else 0]==0,'Inactive-precision pass flag')
                epoch_flags=iv[:2]
                current_pass['end']=e;current_pass=None
            elif k==5:
                width,gen=iv
                require(width in (64,128) and gen>0 and gen not in seen_generation and pending_prod is None,
                        'Bad/reused producer generation')
                require(current_pass is None and current_group is None,'Producer during reduction')
                if width==64:
                    require(not passes and not decisions and transition is None, 'DP producer regenerated during direction checks')
                else:
                    require(len(passes)==2 and len(decisions)==1 and decisions[0]['failed'] and
                            transition is not None and reset is not None, 'QP producer before natural rescue transition')
                    require(active[128] is None, 'QP producer regenerated without a scheduled rotation')
                require(environment_valid(wv[0]),'Invalid producer controls')
                seen_generation.add(gen);pending_prod={'width':width,'generation':gen,'env':wv[0]}
            elif k==6:
                width,gen,genuine=iv
                require(pending_prod is not None and (width,gen)==(pending_prod['width'],pending_prod['generation']),
                        'Producer completion without its begin')
                require(genuine==1 and wv[0]==pending_prod['env'],'Widened/changed producer')
                require(all(finite_word(x,width) for x in wv[1:]),'Nonfinite external producer')
                producer={**pending_prod,'genuine':genuine,'external':wv[1:],'valid':True}
                producers[gen]=producer;active[width]=gen;pending_prod=None
            elif k==7:
                require(iv==[active[64] or 0] and pending_prod is not None and pending_prod['width']==128,
                        'DP narrowing marker outside QP production')
                if active[64] is not None:
                    producers[active[64]]['valid']=False
                active[64]=None
            elif k==8:
                width,fd,fq=iv
                require(width in (64,128) and fd in (0,1) and fq in (0,1),'Decision precision/flags')
                require(pending_prod is None and current_pass is None and current_group is None and len(passes)==(2 if width==64 else 4),
                        'Decision before complete direction checks')
                require(len(decisions)==(0 if width==64 else 1),'Duplicate decision')
                require(all(finite_word(x,64) for x in wv),'Nonfinite host accuracy/threshold')
                vals=[exact_word(x) for x in wv];threshold=vals[2]
                require(threshold==exact_word('00000000000000003F50624DD2F1A9FC') and all(v>=0 for v in vals[:2]),'Threshold/accuracy differs')
                require(iv[1:]==passes[-1]['end']['ints'][:2],'Decision flags differ')
                failed=max(vals[:2])>=threshold
                active_flag=fd if width==64 else fq
                require((fq if width==64 else fd)==0,'Inactive-precision decision flag')
                if active_flag:
                    require(vals[:2]==[Fraction(1),Fraction(1)] and failed,'Host flag did not force failure')
                decisions.append({'width':width,'failed':failed,'accuracy':wv[:2],'threshold':wv[2],
                                  'flags':[fd,fq],'event':e})
            elif k==9:
                require(len(decisions)==1 and decisions[0]['width']==64 and decisions[0]['failed'], 'Rescue without failed DP decision')
                require(pending_prod is None and current_pass is None and current_group is None and transition is None and iv==decisions[0]['flags'],'Rescue flag history differs')
                transition=e
            elif k==10:
                require(pending_prod is None and current_pass is None and current_group is None and transition is not None and reset is None and iv==[0,0], 'Missing/original flag reset differs')
                reset=e;epoch_flags=[0,0]
            elif k==11:
                seq,check,cache,finite,pole=iv
                require(current_group is not None and current_group['seq']==seq and seq not in options,
                        'Native options outside group')
                require((check,cache,finite,pole)==(int(current_group['mode'] in (2,5)),0,1,0),
                        'Native check/cache/finite/pole options differ')
                options[seq]=iv[1:]
            else:
                raise ValueError('Unknown event')
        else:
            g=row
            require(current_entry==g['entry'] and current_pass is not None and current_pass['id']==g['pass'] and
                    current_pass['mode']==g['mode'],'Group outside pass')
            width=g['width']
            if kind=='group_begin':
                require(current_group is None,'Nested group')
                require(g['generation']>0 and active[width]==g['generation'],'Stale or missing producer lineage')
                producer=producers[g['generation']]
                require(producer['valid'] and g['meta']['ROUTE'][1:]==[1,1],'Unknown route/producer')
                require(g['words']['ENV'][0]==producer['env'] and g['words']['EXTERNAL']==producer['external'],
                        'Consumer leaves/token differ from producer')
                require(all(finite_word(x,width) for x in g['words']['EXTERNAL']),'Nonfinite consumer leaves')
                current_group=g
            else:
                require(current_group is g,'Group boundary mismatch')
                if kind=='canonical':
                    require(all(finite_word(x,width) for x in g['words']['CANON']),'Nonfinite canonical numerator')
                elif kind=='native_begin':
                    require(g['seq'] in options,'Missing native options')
                    require(g['words']['ENV'][0]==g['words']['ENV'][1] and environment_valid(g['words']['ENV'][1]),
                            'Invalid/changed native controls')
                    require(all(finite_word(x,width) for tag in ('SHIFT','INV','MASS','SCALE','PRAW','PSMAT','PREF','PDIRECT') for x in g['words'][tag]),
                            'Nonfinite native input')
                    require(g['meta']['PSEEN']==[1]*(g['n']**2),'Missing pair witness')
                    require([q['use'] for q in g['pairs']]==g['meta']['USE'],'Pair/native USE differs')
                    proof=geometry_validator(g,producers[g['generation']])
                    require(isinstance(proof,dict) and proof.get('passed') is True,'Geometry proof missing/failed')
                    geometry.append({'seq':g['seq'],'proof':proof})
                elif kind=='native_end':
                    require(g['unchanged']==1 and g['error']['ambiguous']==0,'Native input mutation/incomplete error')
                    require(g['status']!=0 or g['error']['length']==0,'Success with retained error')
                elif kind=='group_end':
                    require(g['complete']==1,'Incomplete group')
                    if g['native_count']==0:
                        stage,stage_status=g['meta']['STAGE']
                        require(stage in (0,1,3,4), 'Unknown pre-native early-return stage')
                        require((stage<3 and stage_status==-999) or (stage>=3 and 0<=stage_status<=3),
                                'Invalid early-return stage status')
                        require(stage!=3 or stage_status!=0, 'Unexplained post-initialization early return')
                    if g['native_count']==0 or g['status']!=0 or not g['stable']:
                        require(not g['stable'] and (g['fpe_dp'] if width==64 else g['fpe_qp']),
                                'Failed contribution did not set active flag')
                        handled_failures.append({'seq':g['seq'],'width':width,'native_count':g['native_count'],
                                                 'status':g['status'],'stage':g['meta']['STAGE']})
                    require((g['fpe_qp'] if width==64 else g['fpe_dp'])==0, 'Inactive-precision group flag')
                    require(g['fpe_dp']>=epoch_flags[0] and g['fpe_qp']>=epoch_flags[1], 'Flag cleared within precision epoch')
                    epoch_flags=[g['fpe_dp'],g['fpe_qp']]
                    previous=current_pass['groups'][-1] if current_pass['groups'] else None
                    if previous:
                        require(g['fpe_dp']>=previous['fpe_dp'] and g['fpe_qp']>=previous['fpe_qp'],
                                'Flag cleared inside pass')
                    current_pass['groups'].append(g);current_group=None
    require(len(entries)==1 and current_entry is None and current_pass is None and current_group is None and
            pending_prod is None and exit_event is not None,'Incomplete actual entry lifecycle')
    rescued=outer['code']==323
    require(len(passes)==(4 if rescued else 2) and len(decisions)==(2 if rescued else 1),'Return/epoch coverage mismatch')
    require(not decisions[-1]['failed'] and decisions[-1]['accuracy']==accuracy,'Final host decision differs')
    require(all(exact_word(w)>=0 and exact_word(w)<exact_word(decisions[-1]['threshold']) for w in accuracy),
            'Returned accuracy not accepted')
    if rescued:
        require(decisions[0]['failed'] and transition is not None and reset is not None,'Missing natural rescue evidence')
    else:
        require(transition is None and reset is None and not handled_failures,'DP-only result hides failed attempt')
    accepted=passes[-2:]
    for ps in accepted:
        require(ps['end']['ints'][:2]==[0,0] and ps['end']['ints'][2:]==[1]*26,'Accepted pass has failed/missing contribution')
        require(all(g['native_count']==1 and g['status']==0 and g['stable']==1 and g['unchanged']==1 and
                    g['fpe_dp']==0 and g['fpe_qp']==0 for g in ps['groups']), 'Accepted epoch native/adapter failure')
    require(len(p['groups'])<=104 and sum(g['native_count'] for g in p['groups'])<=104,'Qualified phase bound exceeded')
    return {'passed':True,'phase':phase,'code':outer['code'],'rescue_exercised':rescued,'actual_entries':1,
            'passes':len(passes),'group_attempts':len(p['groups']),
            'native_calls':sum(g['native_count'] for g in p['groups']),
            'accepted_modes':[ps['mode'] for ps in accepted],'handled_failures':handled_failures,
            'accepted_groups':[g['seq'] for ps in accepted for g in ps['groups']],
            'geometry':geometry,'decisions':decisions,'output_arithmetic_admitted':True,
            'normal_host_stability_this_phase':True,'broad_accuracy_qualified':False,'performance_qualified':False}
