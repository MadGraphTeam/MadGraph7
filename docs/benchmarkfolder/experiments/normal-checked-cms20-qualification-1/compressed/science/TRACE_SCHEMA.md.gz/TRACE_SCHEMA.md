# Checked trace v1: observation, framing and acceptance

This is source-only instrumentation for the sealed CMS20 automatic-check plan. It does not qualify a native run. The module records existing values and branch outcomes; it never supplies scientific inputs or changes the reduction, certificate, stability, rescue or cache policy. It has no tensor-output argument and performs no I/O during arithmetic. All trace faults latch `failed=1` and increment the conservative trace-fault/omission counter named `omitted`; this field is not an exact count of dropped records. Every nonzero fault/omission count blocks qualification. No trace fault causes STOP inside the scientific path. Only `pc_checked_flush` emits buffered records, on already opened unit76 after the outer return.

The scope is a fresh single worker/backend9, full sum, LoopPoleMode0, CTModeRun=-1, FORCE true, genuine QP integrand, finite terms and both poles, cache0, rotations0. Exactly one ordinary bootstrap may precede one CMS20 measurement. The controller must gate bootstrap before sending RUN; the trace parser does not launch or schedule anything.

## Fortran API

All scalar integers/logicals use default32-bit GNU kinds. `pc_ik` is the existing128-bit integer kind. Native and canonical routines overload real/complex kind8 and16. No generic dispatch selects precision from a claimed flag.

```fortran
pc_checked_phase_start(phase, saved_point)
pc_checked_flush()
pc_checked_sloop_enter()
pc_checked_sloop_exit(H,T,U,accuracy(0:1),fpe_dp,fpe_qp)
pc_checked_pass_begin(mode,backend,checkphase,heldoublechecked, &
  mp_done,mp_done_once,eval_done(:),stab_index)
pc_checked_pass_end(s(1,26),fpe_dp,fpe_qp)
pc_checked_producer_begin(width,env)
pc_checked_producer_end(width,genuine,env,external_bits(32))
pc_checked_dp_invalid()
pc_checked_decision(width,accuracy(0:1),threshold,fpe_dp,fpe_qp)
pc_checked_rescue_transition(fpe_dp,fpe_qp)
pc_checked_flags_reset(fpe_dp,fpe_qp)
pc_checked_group_begin(mode,id,sqso,n,rank,nw,we(nw),pairing(n), &
  route_ok,producer_ok,chord(0:3,n),classes(n,n),have(n),env,external_bits(32))
pc_checked_group_end(stable,fpe_dp,fpe_qp)
pc_checked_canonical(canonical(:))
pc_checked_adapter_stage(stage,status)
pc_checked_pair(i,j,raw_valid,raw_diffsq,s_mat,ref_normalization, &
  mass_mask,zero_branch,use_direct,direct_value)
pc_checked_native_begin(mode,n,rank,p(0:3,n),s(n,n),m(n),mu2,classes, &
  have,pair,used,chord,qerror(0:3,n,n),env,check_pass,cache,finite,pole)
pc_checked_native_end(status,p(:,:),s(:,:),m(:),mu2)
```

`native_end` invokes the original MTIRUST `TIRUST_ERROR_MESSAGE` first, then copies and compares native input words. It never reads RAW. Its8192-character message is retained as exact bytes after the getter's documented trimming behavior; lengths512 or8192 are marked ambiguous and block qualification (512 may fill the existing Fortran local_error buffer). No C-required-length value is invented, and no new library symbol is introduced. Empty messages must accompany native success. Failed native statuses may retain nonempty errors, subject to complete capture.

Stages are0 before the rank guard,1 after rank guard,2 after support guard,3 after initialization with its actual status,4 after budget setter with its actual status,5 at native entry. Early returns retain native_count0/status-999 and the last observed stage. The qualifier accepts only explicit rank/support/initialization/budget-or-kinematic early failures at stages0/1/3/4 with consistent status. Default stage-1, stage2 and successful initialization followed by unexplained return remain unqualified. Native status is read only after the real native call.

The pass-end hook must follow the original aggregate NaN guard. It may observe an active-precision failure flag rising after otherwise successful groups; that is preserved as host failure. A flag may never clear inside the precision epoch. The SKIP jump bypassing this hook produces an incomplete trace and cannot qualify. The original DP-to-QP reset has separate before/after events; trace code does not write those flags.

## Exact wire format

All floating values are represented as32 uppercase hexadecimal digits. Binary64 occupies only the low64 bits; nonzero high bits are invalid. Complex values are consecutive real/imaginary words. Producer and consumer external words follow `PC_EXTERNAL(2,0:3,4)`: external leg, then momentum component, then real/imaginary. Native shifts flatten as propagator then component. All matrices and pair records use Fortran column-major order, index `(j-1)*n+i`. No conservation residual, signed zero, ordering, or magnitude is normalized.

Each phase packet is:

1. `CHECK_BEGIN phase point request` (phase0/point1/request1 or phase1/point20/request2).
2. Zero or more lifecycle triples: `CHECK_EVENT serial kind phase entry pass ni nw`, followed by exact `CHECK_META serial EVENT ni ...` and `CHECK_WORDS serial EVENT nw ...` arrays.
3. Group records in sequence order. Each begins `CHECK_GROUP` and the22 header fields below, followed by fixed named integer/word arrays and the error bytes.
4. `CHECK_END phase clock cumulative_groups cumulative_events failed omitted pending_group pending_producer`.

Header fields: `seq, phase, entry, pass, mode, backend, group, sqso, n, rank, nc, width, digits, generation, native_count, status, complete, stable, fpe_dp, fpe_qp, unchanged, early`.

Group metadata order: TIMES(5), STAGE(2); then word arrays ENV(2), EXTERNAL(32), SHIFT(4n), INV(n²), MASS(2n), SCALE(1), CANON(2nc), PRAW(2n²), PSMAT(2n²), PREF(n²), PDIRECT(n²); then metadata PSEEN(n²), PFLAGS(4n²), ROUTE(3), WE(nw), PAIRING(n), CLASS(n²), HAVE(n), PAIR(n²), USE(n²), CHORD(4n), QERROR(4n²). Each array line carries its exact sequence, tag and length. ROUTE is `[nw,route_ok,producer_ok]`; ENV is `[entry_environment,native_environment]`.

TIMES are the shared chronological serials for group begin, canonical capture, native begin, native end, group end; absent stages are zero. Every nonzero serial, including lifecycle events, must occur exactly once in the contiguous global range. Native options are lifecycle event11 immediately before native entry. Native groups require all pair witnesses, canonical capture and a completed input-unchanged check.

PFLAGS stores `[raw_valid,mass_mask,zero_branch,use_direct]` for each pair. `mass_mask` bits1/2 record the actual original mass-I/mass-J snap assignments, in original order. Diagonal rows have raw_valid=false and initialized zero RAW/REF/DIRECT placeholders with the actual S value. Off-diagonal RAW and S are complex kinematic intermediates, not tensor coefficients. The geometry verifier checks their relation to actual input shifts and source-bound branch policy. It does not infer unobserved compiler complex-division/hypot branch predicates.

The error line is `CHECK_ERROR seq length ambiguous HEXBYTES`, with contiguous two-digit uppercase bytes and no token when empty. Unknown/duplicate tags, altered arities, footer mismatch, truncation, malformed or overlong integers/words, duplicate or missing serials and trailing records are rejected.

Lifecycle events:

| Kind | Meaning | Integer payload | Word payload |
|---|---|---|---|
|1|Actual SLOOP entry|entry|none|
|2|Actual SLOOP exit|H,T,U,FPEdp,FPEqp|accuracy0,accuracy1 (64)|
|3|Pass begin|mode,backend,CHECKPHASE,HELDOUBLECHECKED,MP_DONE,MP_DONE_ONCE,EVALmask,STAB_INDEX|none|
|4|Pass end|FPEdp,FPEqp,26 S bits|none|
|5|Producer begin|width,generation|entry environment|
|6|Producer end|width,generation,genuine|environment,32 external words|
|7|DP narrowing invalidation|previous DP generation|none|
|8|Host decision|width,FPEdp,FPEqp|accuracy0,accuracy1,threshold (64)|
|9|Before rescue reset|FPEdp,FPEqp|none|
|10|After original reset|FPEdp,FPEqp|none|
|11|Native options|group sequence,CHECK_PASS,cache,finite,pole|none|

## Python API and geometry seam

```python
trace = parse_trace(text, authenticated_routes, complete_phases=(0,))
proof = qualify_phase(trace, 0, outer,
                      geometry_validator=authenticated_geometry.validate_geometry)
```

Final parsing uses `complete_phases=(0,1)`. Routes are the integer-keyed contents of this packet's authenticated expected-routes.json; no route discovery or numerical loading occurs. `outer` has exactly `code` (integer), `output_words` (eight16-digit words, Born/finite/single/double for order0 then order1), `accuracy_words` (two16-digit words), `fpe_dp` and `fpe_qp` (integers). The controller authenticates source/card/point/runtime/maps first and supplies the driver state words. The parser only interprets trace integers and IEEE bits.

`trace['phases'][phase]` contains groups/events and footer state. Group dictionaries use header names directly, plus `meta`, `words`, `times`, `error` and `pairs`. A pair dictionary contains `i,j,raw_valid,mass_mask,zero_branch,use` plus `words={RAW:[re,im],S:[re,im],REF:[word],DIRECT:[word]}`. Producer dictionaries passed to the geometry callback contain width, generation, genuine, env, external, valid. `geometry_validator(group,producer)` must return a dictionary with literal `passed=True` and source-bound proof; a boolean or absent callback never qualifies. Authenticating that implementation is the controller's responsibility. The checked geometry module is the required production callback; synthetic test doubles isolate state-machine tests only.

Qualification requires exactly one actual SLOOP entry per phase. Directions must be1/2, optionally followed only after the failed-DP decision/original reset by4/5. No producer is regenerated during a direction pair. QP production cannot precede the failed decision or reset. The current producer's exact leaves and environment must match the consumer; narrowed DP provenance becomes invalid. Every pass must contain exactly groups1..26, with matching S values and monotonic active-precision software flags. Inactive-precision flags fail. Native inputs, canonical numerator inputs and kinematic witnesses are classified through integer exponent fields; no failed tensor outputs exist in the schema.

Return219 accepts the complete DP epoch and leaves rescue unexercised. Return323 additionally proves failed DP checks, original reset, genuine QP production, successful native/adapter contributions in both4/5 and cleared final flags. Handled DP native or pre-native failures remain recorded. Successful final output words must be finite; accuracy must be finite, nonnegative, identical to the host exit/decision and strictly below the exact binary64 card value1e-3. Accuracy comparisons use exact rational decoding; output coefficients remain words. Only the resulting `output_arithmetic_admitted=True` permits the controller's external numerical comparisons. Host stability, external agreement and pole prediction remain separate results.

The returned proof includes `accepted_groups` (sequence IDs), `accepted_modes`, `handled_failures`, `decisions`, per-group geometry proofs, actual-entry/pass/group/native counts and `rescue_exercised`. Accepted mode4 records for the fixed-result join are selected by both membership in accepted_groups and mode==4. The full-run comparator must require bootstrap qualification before measurement; calling phase1 qualification alone does not supply the missing bootstrap comparison or process ownership proof.

## Fixed bounds and remaining qualification

Storage is416 groups and1024 lifecycle events. The largest admitted plan allows four actual SLOOP entries through the unchanged FORCE wrapper, four passes each,26 groups each. Qualification accepts only two actual entries total, at most208 native calls. Directions use no additional producer calls; the16 helicities are bounded by the frozen CMS source. The observer's scalar chronology has at most3104 serials (five group stages plus one per lifecycle event); the parser checks this before constructing any chronology range.

A deliberately pessimistic wire bound includes416 maximum-shape groups,8192 error bytes each, all pair words/flags and1024 maximum40-integer/40-word events. It remains below16MiB. The Fortran compile-time contract includes default32-bit integers and IEEE64/128 kinds; Python also rejects larger payloads. Overflow is retained as a failed attempt; it is never converted into successful coverage. Recorded group/event counts are exact; the `omitted` field conservatively counts trace faults and omissions, including faults where a record was retained, and must not be reported as an exact dropped-record count.

Tests are pure synthetic protocol/state tests, including serialized corruption and causal reordering. They neither execute Fortran nor establish geometry or numerical agreement. No compiler, loader or native evaluation has been run for these files. Source stripping, exact caller shapes, native compilation, closure, mode2/5 behavior and actual checked CMS20 outcomes still require their separate reviews/admissions. Broad accuracy, performance, caches, rotations and production promotion remain unqualified.
