# Pure geometry validation for the private checked experiment

`checked_geometry.validate_geometry(group, producer)` returns a proof dictionary
with `passed`, `failures`, source pins, exact closure words, and per-pair
certificate results. It never returns a bare Boolean and never examines tensor
or amplitude output buffers. The strict lifecycle parser supplies the resolved
producer event, including its actual external-wavefunction words, width,
generation, genuine-QP marker, and entry environment token. The validator checks
these against the actual consumer words and token; an unrelated `valid=True`
flag cannot substitute for those checks. The parser remains responsible for
proving the producer occurs before the consumer and has not been invalidated by
MP-to-DP narrowing or another producer transition.

The input contract is the parsed group from `checked_trace.py`: scalar identity
fields; `words` containing `ENV`, `EXTERNAL`, `SHIFT`, `INV`, `MASS`, `SCALE`, and
`CANON`; `meta` containing `ROUTE`, `WE`, `PAIRING`, `CLASS`, `HAVE`, `PAIR`,
`USE`, `CHORD`, and `QERROR`; and all `n*n` helper `pairs`. The external-word
order is leg, component 0:3, then real/imaginary, matching
`PC_EXTERNAL(2,0:3,4)`. Shift words are chord-major; invariant/class/pair/use
matrices are Fortran column-major; each chord or pair error has four consecutive
component exponents. Binary64 words must be zero extended; binary128 words use
their complete integer encoding. Nonfinite words, unknown routes, wrong mode or
width, missing witnesses, and unsupported intermediate overflow fail closed.

The following immutable packets are authenticated before any helper bytes are
executed or data are parsed:

| Packet | Index SHA-256 |
|---|---|
| Caller DAG/factory | `aba903450f49e0e18ba3fff40dbf6074e1cd67e9af1c67cd83bbd6fd583c1047` |
| Integer certificate reference | `1665eff3188c947f35673b958cd0f02525fd031dc814b708dfdda69160b57964` |
| Earlier conditional source replay | `a51a685abffb384e9503f2a25703f4fb09a08ba13e07c164081eae52993e081e` |
| Candidate2 source | `ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74` |

Only consumed payloads are loaded, each checked against its index hash and byte
count. Exact helper bytes are executed in a fresh Python module after that
check. No unpinned sibling import, native library, compiler, or physics evaluator
is invoked. The evidence dictionary lists every consumed payload.

## Arithmetic and route proof

The pinned DAG proves the same-kind external W1:4 copies and the two-term ALOHA
momentum sums producing W5:8. Starting from the actual external W words, the
validator performs every addition and subtraction in its recorded source order,
with exact rational values and nearest-even IEEE encoding after each operation.
It retains signed zeros, gradual underflow, and exact unary-negation sign flips.
Corner construction starts at zero and subtracts the actual `WE` entries in
their preserved `PAIRING` groups. Modes 2 and 5 negate the reversed corner list
only for more than two corners. Both the complete closure and each ordered
prefix are then accumulated from zero exactly as in TIRust's caller. The first
shift is the computed conservation residual; it is never replaced by zero.

The factory's original integer reference reconstructs `CLASS`, all chord
bounds, `HAVE`, all difference bounds, and `PAIR`. All arrays, including the
diagonal sentinel entries, must match the recorded values exactly. Producer
kind and environment checks precede construction. No unknown/legacy fallback
metadata is accepted as a certified route.

For CMS group 3 the original route is `WE=[1,2,4,3]` with four singleton
corners. In modes 1/4 the symbolic corners are `(p1,p2,-p4,-p3)` and the
critical difference of chords 2 and 4 is `p4-p2`. Writing the exact symbolic
conservation residual as `r=p1+p2-p3-p4`, this is also `p1-p3-r`.
Modes 2/5 use `(p3,p4,-p2,-p1)`, so the corresponding critical difference is
`p2-p4`, or `-p1+p3+r`. The pair remains `(2,4)` (and its transpose), its class
remains COMPOSITE=2, and the square is spacelike for the retained CMS20 input.
This symbolic identity does not assert that a reverse-order floating closure
equals the bitwise negation of the original closure: both operation sequences
are replayed independently. The mode-2/5 fixtures test the actual sequence,
including a deliberately nonzero closure and the N<=2 exception.

## Helper witnesses and native invariants

Each helper pair records the actual complex `RAW`, `S`, real `REF` and `DIRECT`,
plus `raw_valid`, mass-snap mask (bit 1 for mass I, bit 2 for mass J),
zero-branch choice, and `USE`. Diagonals use defined literal-zero RAW/REF/DIRECT
with `raw_valid=0`; their actual S is checked. For offdiagonal pairs the validator
independently replays all four rounded differences, their rounded Minkowski
square, and the source normalization expression. The real raw word must match
exactly. The imaginary raw value must be zero; the sign of that zero is retained
as observed rather than claimed independently reconstructed from complex
multiplication.

Mass and zero-threshold decisions are **witnesses of execution inside the
unchanged source branches**. This validator does not reimplement GNU complex
division or hypot and therefore does not claim independent reevaluation of
their floating predicates. Source stripping/audit and the parser's witness
coverage/order checks establish where those decisions were recorded. No
threshold or mass policy is changed here.

Using these actual branch decisions, the validator replays the original S
assignment, then mass-I replacement, then mass-J replacement, then any zero
replacement, with exact rounded complex-component addition/subtraction. The
unchanged integer certificate reference determines whether the observed zero
branch may set USE. A mass snap, protected class, absent bound, or failed
certificate forbids USE. DIRECT equals the captured raw real word only for a
certified pair; otherwise it must retain literal zero. Native INV is either
DIRECT or the original two mass additions to S. Finally the original finite
upper-triangle normalization copies only numerically unequal entries, preserving
already equal opposite-signed zero words. Every native invariant word must
match. Protected rows consequently retain the full legacy round trip, including
its rounding; an algebraically equivalent replacement by RAW is rejected.

## Closed mode-4 comparison and limits

`join_matched_mode4(groups, phase=1)` independently authenticates the matched
source index `357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b`,
the closed run `52faa470d8be22b81f8636edba21f5fba6c2d13be1f0241a8212a7b2055839a7`,
and backend9 trace `f856793011f4f837e11b8d267b05fa98b1e87b45fd23ad9eba42345e64381c34`.
It requires a complete actual-mode4 epoch and compares every SHIFT, INV, MASS,
SCALE, and canonical numerator word exactly for all 26 groups. No tolerance,
sorting of momenta, rotation, or zeroing is allowed. The caller must first
qualify the accepted epoch using lifecycle/status/flags; an exact input join
alone does not establish acceptance or accuracy.

Failed native calls can still have their input geometry validated. Their status
is explicitly retained, and no failed tensor coefficient is read. This module
does not independently reconstruct model masses, the scale, or numerator
construction; it requires their finite words and checks their exact identity
against the closed mode4 stream where that join is applicable. Caller source
binding, model/card binding, and the external lifecycle/accepted-epoch gates
remain required. Synthetic producer events and branch witnesses in the tests
do not qualify real-source producer lineage or a native checked run.

## Pure verification

Run from the repository root:

```sh
source tools/tirust_env.sh
python3 -B -m unittest discover -s .tirust-build/kinematic-normal-checked-source-1 -p test_checked_geometry.py -v
```

The suite covers all 104 route/mode combinations; independent hand-derived
mode reversals and nonzero residuals; signed zeros/subnormals; mutated routing,
metadata, raw/S/direct/native words; complex mass round-trip cancellation;
protected-row and false-certificate rejection; producer/environment mismatches;
finite-word admission; complete matched joins; and opaque failed outputs.
An independent historical input-only fixture authenticates the preserved trace
capsule and replays all 52 closed matched9 shifts and factory arrays using actual
old producer words. Its old lifecycle is not substituted for the new producer
contract.

Two initial fixture failures are retained in the task history: session 76788
had an incorrect hand-written spatial residual (4 rather than 0), and session
89275 used a mass scale 2^80 that still retained the small raw term in binary128.
The expected residual was corrected and the cancellation fixture now uses 2^200.
Neither fix changed the validator or a scientific policy.
