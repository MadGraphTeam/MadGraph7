"""Pure source admission; no compiler, loader, child process or library loading."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def preflight(expected):
    require(type(expected) is str and re.fullmatch('[0-9a-f]{64}', expected) is not None,
            'An explicit reviewed source index is required')
    require(pin(HERE / 'index.json')['sha256'] == expected, 'Source index differs')
    index = json.loads((HERE / 'index.json').read_bytes())
    for name, record in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe source path')
        require(pin(HERE / name) == {k: record[k] for k in ('bytes', 'sha256')},
                'Source payload changed: ' + name)
    spec = importlib.util.spec_from_file_location('private_checked_prepare', HERE / 'prepare.py')
    prepare = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prepare)
    products, proof = prepare.derive()
    for name, expected_raw in products.items():
        require((HERE / name).read_bytes() == expected_raw, 'Derived source differs: ' + name)
    require(json.loads((HERE / 'source-proof.json').read_bytes()) == proof, 'Source proof differs')
    require(all(v['exact_inverse'] for v in proof['sources'].values()), 'Scientific body inverse failed')
    require(proof['scientific_arithmetic_changed'] is False, 'Unexpected scientific change')
    binding = json.loads((HERE / 'error-interface-binding.json').read_bytes())
    for name, expected_pin in binding['files'].items():
        require(pin(HERE.parents[1] / name) == expected_pin, 'Existing error interface source differs')
    geometry_spec = importlib.util.spec_from_file_location('private_checked_geometry_preflight', HERE / 'checked_geometry.py')
    geometry = importlib.util.module_from_spec(geometry_spec)
    geometry_spec.loader.exec_module(geometry)
    geometry_evidence = geometry.references()['source_evidence']
    return {'schema': 'private-normal-checked-source-preflight-v1', 'passed': True,
            'source_index_sha256': expected, 'payloads': len(index['files']),
            'source_products': len(products), 'scientific_bodies_exact': len(proof['sources']),
            'routes': 26, 'native_actions': 0, 'card_inverse': True,
            'geometry_helper_source_files': len(geometry_evidence),
            'normal_checked_native_qualified': False, 'performance_qualified': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--reviewed-source-index', required=True)
    args = parser.parse_args()
    print(json.dumps(preflight(args.reviewed_source_index), sort_keys=True))
