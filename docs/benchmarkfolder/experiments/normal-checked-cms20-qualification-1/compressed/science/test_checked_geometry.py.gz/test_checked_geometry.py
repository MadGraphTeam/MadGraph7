"""Pure integer/rational tests; synthetic witnesses do not qualify a native run."""
import copy
import gzip
import hashlib
import importlib.util
import json
import unittest
from fractions import Fraction as F
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('checked_geometry_under_test',HERE/'checked_geometry.py')
G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)
TOKEN='00000000000000004B4500001F80033F'


def external(width, rows=None):
    # Actual stored W signs; deliberately nonconserving to expose q0 erasure.
    rows=rows or [[-17,0,0,-17],[-19,0,0,19],[11,3,0,10],[23,-3,0,-12]]
    return [G.textword(G.encode(x,width)) for row in rows for value in row for x in (value,0)]


def fixture(route=3,mode=4,ext=None,masses=None):
    width=64 if mode in (1,2) else 128;refs=G.references()
    ext=ext or external(width);replay,meta,initial,finished=G.expected_metadata(route,mode,width,ext)
    n,rank=G.NR[route-1];nc=1 if rank==0 else 15
    masses=masses or [(0,0)]*n
    pairs=[]; inv=[[0]*n for _ in range(n)]; use=[]
    p,emin=(53,-1022) if width==64 else (113,-16382)
    # This fixture simulates only the real, zero-mass snap predicate. It is
    # independent of the production helper's branch witnesses.
    ost=G.value(G.encode(F(1,100000000),64),64)
    for j in range(n):
        for i in range(n):
            raw=(0,0);ref=0;zero=False;chosen=False
            if i!=j:
                q=[G.sub(a,b,width) for a,b in zip(replay['shifts'][i],replay['shifts'][j])]
                rawreal=G.mul(q[0],q[0],width)
                for component in q[1:]:rawreal=G.sub(rawreal,G.mul(component,component,width),width)
                raw=(rawreal,0)
                norm=G.encode(abs(G.value(replay['shifts'][i][0],width))+abs(G.value(replay['shifts'][j][0],width)),width)
                norm=G.encode(G.value(norm,width)/2,width);ref=G.mul(norm,norm,width)
                zero=bool(G.value(ref,width) and abs(G.value(rawreal,width)/G.value(ref,width))<ost)
                chosen=bool(zero and refs['certificate'].certificate([G.value(x,width) for x in q],
                    G.value(rawreal,width),finished[(i,j)],p,emin,initial['pair_class'][i][j],False,True,True))
                smat=G._complex_sub(G._complex_sub(raw,masses[i],width),masses[j],width)
            else:smat=G._complex_neg(G._complex_add(masses[i],masses[j],width),width)
            if zero and not chosen:smat=G._complex_neg(G._complex_add(masses[i],masses[j],width),width)
            direct=raw[0] if chosen else 0
            inv[i][j]=direct if chosen else G._complex_add(G._complex_add(smat,masses[i],width),masses[j],width)[0]
            use.append(int(chosen))
            pairs.append({'i':i+1,'j':j+1,'raw_valid':int(i!=j),'mass_mask':0,
                'zero_branch':int(zero),'use':int(chosen),'words':{
                    'RAW':list(map(G.textword,raw)),'S':list(map(G.textword,smat)),
                    'REF':[G.textword(ref)],'DIRECT':[G.textword(direct)]}})
    for j in range(1,n):
        for i in range(j):
            if G.value(inv[j][i],width)!=G.value(inv[i][j],width):inv[j][i]=inv[i][j]
    meta['USE']=use
    group={'seq':1,'phase':1,'entry':1,'pass':1,'mode':mode,'backend':9,'group':route,'sqso':1,
        'n':n,'rank':rank,'nc':nc,'width':width,'digits':53 if width==64 else 113,
        'generation':7,'native_count':1,'status':0,'complete':1,'stable':1,
        'fpe_dp':0,'fpe_qp':0,'unchanged':1,'early':0,'meta':meta,'pairs':pairs,
        'words':{'ENV':[TOKEN,TOKEN],'EXTERNAL':ext,
            'SHIFT':[G.textword(x) for row in replay['shifts'] for x in row],
            'INV':[G.textword(x) for x in G._flat_matrix(inv)],
            'MASS':[G.textword(x) for row in masses for x in row],
            'SCALE':[G.textword(G.encode(10000,width))],'CANON':[G.textword(0)]*(2*nc)}}
    producer={'width':width,'generation':7,'genuine':int(width==128),'env':TOKEN,
              'external':ext[:],'valid':True}
    return group,producer


def historical_external(point,mode):
    """Authenticate old input-only trace; no tensor output is accessed."""
    cap=G.ROOT/'docs/benchmarkfolder/experiments/current-kinematic-trace-runtime-qualification-1'
    evidence={};idx=json.loads(G._pin(cap/'evidence-index.json',
        {'sha256':'730f8f220c17676287dda092a19fb24fbca2073d1ecb0e7ceb44a3a16b5402e4'},evidence))
    key=f'results/runs/cms-point{point}-mode{mode}-enabled/trace.dat'
    record=idx['compressed_text'][key]
    raw=gzip.decompress(G._pin(cap/record['path'],idx['files'][record['path']],evidence))
    assert len(raw)==record['raw_bytes'] and hashlib.sha256(raw).hexdigest()==record['raw_sha256']
    suffix='DP' if mode==1 else 'QP';words=[]
    rows=[line.split() for line in raw.decode('ascii').splitlines() if line.startswith('KT_EXTERNAL_'+suffix+' ')]
    for leg in range(1,5):
        row=next(x for x in rows if int(x[7])==leg)
        data=row[11:]
        if mode==1:words.extend(f'{int(x,16):032X}' for x in data)
        else:words.extend(f'{int(data[k],16)+(int(data[k+1],16)<<64):032X}' for k in range(0,len(data),2))
    assert len(words)==32
    return words


def closed_matched():
    ev={};read=G._packet('matched',ev)
    parser=G._module('matched_test_pinned',read('matched_inputs.py'))
    routes={int(k):v for k,v in json.loads(read('expected-routes.json')).items()}
    closure=json.loads(G._pin(G.MATCHED_RESULTS/'run-closure.json',{'sha256':G.MATCHED_CLOSURE},ev))
    key='runs/cms-p20-mode4-lib9-matched/trace.dat'
    raw=G._pin(G.MATCHED_RESULTS/key,closure['payloads'][key],ev)
    return parser.parse_trace(raw.decode('ascii'),9,routes)['calls']


class GeometryTests(unittest.TestCase):
    def assertRejected(self,g,p,phrase):
        got=G.validate_geometry(g,p)
        self.assertFalse(got['passed'],got)
        self.assertIn(phrase,' '.join(got['failures']))

    def test_all_26_routes_all_four_modes(self):
        for route in range(1,27):
            for mode in (1,2,4,5):
                with self.subTest(route=route,mode=mode):
                    g,p=fixture(route,mode);got=G.validate_geometry(g,p)
                    self.assertTrue(got['passed'],got['failures'])

    def test_signed_zero_nearest_and_subnormal(self):
        for width in (64,128):
            negative=1<<(width-1)
            self.assertEqual(G.add(negative,negative,width),negative)
            self.assertEqual(G.add(negative,0,width),0)
            self.assertEqual(G.sub(negative,0,width),negative)
            self.assertEqual(G.sub(0,0,width),0)
            self.assertEqual(G.mul(negative,G.encode(2,width),width),negative)
            nf,_,bias=G.fmt(width);small=F(2)**(1-bias-nf)
            self.assertEqual(G.encode(small/2,width),0)
            self.assertEqual(G.encode(-small/2,width),negative)
            self.assertEqual(G.encode(3*small/2,width),2)

    def test_hand_derived_residual_and_reverse(self):
        for mode in (1,2,4,5):
            width=64 if mode<3 else 128
            replay=G.replay_shifts(3,mode,width,external(width))
            shifts=[[G.value(x,width) for x in row] for row in replay['shifts']]
            expected=[[2,0,0,0],[17,0,0,17],[36,0,0,-2],[13,3,0,10]]
            if mode in (2,5):expected=[[-2,0,0,0],[11,3,0,10],[34,0,0,-2],[15,0,0,17]]
            self.assertEqual(shifts,expected)

    def test_mode2_and5_do_not_reverse_two_corners(self):
        for a,b in ((1,2),(4,5)):
            width=64 if a==1 else 128
            self.assertEqual(G.replay_shifts(26,a,width,external(width))['shifts'],
                             G.replay_shifts(26,b,width,external(width))['shifts'])

    def test_q0_must_retain_nonzero_residual(self):
        for mode in (2,5):
            g,p=fixture(mode=mode);g['words']['SHIFT'][:4]=['0'*32]*4
            self.assertRejected(g,p,'shift/reversal/residual')

    def test_wrong_mode_routing_and_bound_fail_closed(self):
        for field in ('mode','WE','PAIRING','CLASS','HAVE','PAIR','CHORD','QERROR'):
            g,p=fixture(mode=5)
            if field=='mode':g['mode']=4
            else:g['meta'][field]=g['meta'][field][:];g['meta'][field][0]+=1
            self.assertRejected(g,p,'mismatch')

    def test_kind_environment_and_producer_are_not_boolean_shortcuts(self):
        for mutation in ('genuine','generation','external','env','width','valid'):
            g,p=fixture()
            if mutation=='external':p['external'][0]=G.textword(G.encode(11,128))
            elif mutation=='env':p['env']='0'*32
            elif mutation=='valid':p['valid']=False
            else:p[mutation]=0
            self.assertFalse(G.validate_geometry(g,p)['passed'],mutation)
        g,p=fixture();self.assertRejected(g,True,'Missing producer')

    def test_native_status_failure_does_not_decode_tensor_outputs(self):
        g,p=fixture();g['status']=1;g['stable']=0;g['tensor_output']='FORBIDDEN'
        result=G.validate_geometry(g,p)
        self.assertTrue(result['passed'],result)
        self.assertEqual(result['native_status'],1)
        self.assertNotIn('tensor_output',str(result))

    def test_missing_or_duplicated_witness_and_raw_mutation(self):
        for mutation in ('missing','duplicate','RAW','S','REF','DIRECT'):
            g,p=fixture()
            if mutation=='missing':g['pairs'].pop()
            elif mutation=='duplicate':g['pairs'][1]=copy.deepcopy(g['pairs'][0])
            else:g['pairs'][1]['words'][mutation][0]=G.textword(G.encode(123,128))
            self.assertFalse(G.validate_geometry(g,p)['passed'],mutation)

    def test_protected_row_false_certificate_rejected(self):
        g,p=fixture();row=next(x for x in g['pairs'] if x['i']!=x['j'] and
            g['meta']['CLASS'][(x['j']-1)*g['n']+x['i']-1]==1)
        row['use']=1;g['meta']['USE'][(row['j']-1)*g['n']+row['i']-1]=1
        self.assertRejected(g,p,'Certificate/USE')

    def test_complex_mass_legacy_roundtrip_is_not_replaced_by_raw(self):
        for mode,width in ((1,64),(4,128)):
            masses=[(G.encode(2**200+i,width),G.encode(-3-i,width)) for i in range(4)]
            g,p=fixture(mode=mode,masses=masses)
            got=G.validate_geometry(g,p)
            self.assertTrue(got['passed'],got['failures'])
            row=next(x for x in g['pairs'] if x['i']!=x['j'] and x['zero_branch']==0)
            at=(row['j']-1)*g['n']+row['i']-1
            self.assertNotEqual(g['words']['INV'][at],row['words']['RAW'][0])
            g['words']['INV'][at]=row['words']['RAW'][0]
            self.assertRejected(g,p,'Native invariant')

    def test_mass_snap_branch_order_is_witnessed_not_inferred(self):
        width=128;masses=[(G.encode(11+i,width),G.encode(-1-i,width)) for i in range(4)]
        g,p=fixture(masses=masses)
        # Synthetic witness executes MASSI then MASSJ. It verifies replay order,
        # not truth of the compiler's complex threshold predicates.
        row=next(x for x in g['pairs'] if x['i']==1 and x['j']==2)
        row['mass_mask']=3;row['zero_branch']=0;row['use']=0
        smat=G._complex_neg(masses[0],width)
        row['words']['S']=list(map(G.textword,smat))
        reconstructed=G._complex_add(G._complex_add(smat,masses[0],width),masses[1],width)[0]
        g['words']['INV'][4]=G.textword(reconstructed)
        g['words']['INV'][1]=G.textword(reconstructed)
        self.assertTrue(G.validate_geometry(g,p)['passed'])
        row['words']['S']=list(map(G.textword,G._complex_neg(masses[1],width)))
        self.assertRejected(g,p,'branch-order')

    def test_nonfinite_and_dp_high_words_rejected(self):
        for mode,width in ((1,64),(4,128)):
            for tag in ('SHIFT','INV','MASS','SCALE','CANON'):
                g,p=fixture(mode=mode);nf,ne,_=G.fmt(width)
                g['words'][tag][0]=G.textword(((1<<ne)-1)<<nf)
                self.assertRejected(g,p,'Nonfinite')
        g,p=fixture(mode=2);g['words']['SHIFT'][0]=G.textword(1<<90)
        self.assertRejected(g,p,'zero extended')

    def test_closed_mode4_source_shifts_and_metadata(self):
        # Independent saved native SHIFT/mapping/bound words, not generated by
        # this implementation. Old input producer does NOT qualify new lineage.
        calls=closed_matched()
        for phase,point in ((0,1),(1,20)):
            ext=historical_external(point,4)
            for row in (x for x in calls if x['phase']==phase):
                replay,expected,_,_=G.expected_metadata(row['group'],4,128,ext)
                self.assertEqual([G.textword(x) for r in replay['shifts'] for x in r],row['words']['SHIFT'])
                for tag,items in expected.items():self.assertEqual(items,row['meta'][tag],(phase,row['group'],tag))

    def test_critical_pair_modes1_2_4_5_certify_and_false_use_rejected(self):
        for mode in (1,2,4,5):
            ext=historical_external(20,1 if mode in (1,2) else 4)
            g,p=fixture(mode=mode,ext=ext);result=G.validate_geometry(g,p)
            self.assertTrue(result['passed'],result['failures'])
            self.assertEqual([r['certified'] for r in result['pairs'] if r['pair'] in ([2,4],[4,2])],[True,True])
            row=g['pairs'][3*g['n']+1];row['use']=0;g['meta']['USE'][3*g['n']+1]=0
            self.assertRejected(g,p,'Certificate/USE')

    def test_closed_matched_join_exact_and_canonical_mutation(self):
        calls=[x for x in closed_matched() if x['phase']==1]
        result=G.join_matched_mode4(calls)
        self.assertTrue(result['passed'],result)
        calls[0]['words']['CANON'][0]=G.textword(int(calls[0]['words']['CANON'][0],16)^1)
        result=G.join_matched_mode4(calls)
        self.assertFalse(result['passed']);self.assertEqual(result['differences'][0]['field'],'CANON')

    def test_matched_join_requires_actual_complete_mode4_epoch(self):
        calls=[x for x in closed_matched() if x['phase']==1]
        self.assertFalse(G.join_matched_mode4(calls[:-1])['passed'])
        calls[0]['mode']=5
        self.assertFalse(G.join_matched_mode4(calls)['passed'])


if __name__=='__main__':unittest.main()
