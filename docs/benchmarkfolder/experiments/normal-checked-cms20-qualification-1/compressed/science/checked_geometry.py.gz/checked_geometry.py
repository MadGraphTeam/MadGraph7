"""Pure checked-input geometry replay. No tensor or amplitude output is read.

The lifecycle parser supplies the resolved producer event. This module checks
its actual words, generation, kind and environment against the consumer, then
replays the pinned source DAG and integer certificate. Floating snap predicates
are witnessed by instrumented original branches, not reimplemented here.
"""
import hashlib
import json
import re
import types
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PACKETS = {
    'factory': ('kinematic-invariant-caller-metadata-1',
        'aba903450f49e0e18ba3fff40dbf6074e1cd67e9af1c67cd83bbd6fd583c1047'),
    'certificate': ('kinematic-invariant-general-proposal-1',
        '1665eff3188c947f35673b958cd0f02525fd031dc814b708dfdda69160b57964'),
    'conditional': ('kinematic-invariant-caller-trace-conditional-1',
        'a51a685abffb384e9503f2a25703f4fb09a08ba13e07c164081eae52993e081e'),
    'candidate': ('kinematic-invariant-amplitude-proposal-2',
        'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'),
    'matched': ('kinematic-matched-native-input-proposal-1',
        '357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b'),
}
MATCHED_RESULTS = ROOT / '.tirust-build/kinematic-matched-native-input-executor-2/results'
MATCHED_CLOSURE = '52faa470d8be22b81f8636edba21f5fba6c2d13be1f0241a8212a7b2055839a7'
HEX = re.compile(r'[0-9A-F]{32}\Z')
NR = ((3,2),(3,2),(4,2),(4,2),(4,2),(4,2),(4,2),(4,2),
      (2,0),(3,2),(3,2),(4,2),(4,2),(1,0),(2,2),(1,0),
      (1,0),(2,2),(1,0),(3,2),(3,2),(3,2),(3,2),(4,2),(2,2),(2,2))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _pin(path, expected, evidence):
    raw = path.read_bytes()
    actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    require(actual['sha256'] == expected['sha256'], 'Source hash: '+str(path))
    if 'bytes' in expected:
        require(actual['bytes'] == expected['bytes'], 'Source size: '+str(path))
    evidence[str(path.relative_to(ROOT))] = actual
    return raw


def _packet(name, evidence):
    directory, sha = PACKETS[name]
    path = ROOT / '.tirust-build' / directory
    index = json.loads(_pin(path/'index.json', {'sha256': sha}, evidence))
    def read(filename):
        return _pin(path/filename, index['files'][filename], evidence)
    return read


def _module(name, raw):
    module = types.ModuleType(name)
    # Execute only bytes already authenticated against the sealed index.
    exec(compile(raw, name, 'exec'), module.__dict__)
    return module


@lru_cache(maxsize=1)
def references():
    evidence = {}
    fac = _packet('factory', evidence)
    factory = _module('checked_pinned_factory', fac('runtime_reference.py'))
    dag = json.loads(fac('dag-metadata.json'))
    fac('derive_dag.py'); fac('caller_bounds.f90'); fac('cms_bounds_data.inc')
    cert = _packet('certificate', evidence)
    certificate = _module('checked_pinned_certificate', cert('certificate_reference.py'))
    conditional = _packet('conditional', evidence)
    # Retained source proof for nearest-even operation order; no main() call.
    conditional('analyze.py')
    candidate = _packet('candidate', evidence)
    for filename in ('candidate/CT_interface.f', 'candidate/TIRUST_interface.f',
                     'candidate/loop_CT_calls_1.f'):
        candidate(filename)
    return {'factory': factory, 'certificate': certificate, 'dag': dag,
            'source_evidence': evidence}


def fmt(width):
    require(width in (64, 128), 'Unsupported word width')
    return (52, 11, 1023) if width == 64 else (112, 15, 16383)


def word(text, width):
    require(isinstance(text, str) and HEX.fullmatch(text), 'Malformed word')
    value = int(text, 16)
    require(value < 1 << width, 'DP word is not zero extended')
    nf, ne, _ = fmt(width)
    require(((value >> nf) & ((1 << ne)-1)) != (1 << ne)-1,
            'Nonfinite input word')
    return value


def value(bits, width):
    nf, ne, bias = fmt(width)
    require(type(bits) is int and 0 <= bits < 1 << width, 'Malformed integer word')
    exponent = (bits >> nf) & ((1 << ne)-1)
    require(exponent != (1 << ne)-1, 'Nonfinite input word')
    fraction = bits & ((1 << nf)-1)
    mantissa = fraction | ((1 << nf) if exponent else 0)
    result = F(mantissa) * F(2)**((exponent or 1)-bias-nf)
    return -result if bits >> (width-1) else result


def encode(number, width, negative_zero=False):
    """RN-even finite IEEE encoding, including gradual underflow and zero sign."""
    nf, ne, bias = fmt(width)
    number = F(number)
    sign = int(number < 0 or (number == 0 and negative_zero))
    if not number:
        return sign << (width-1)
    a = abs(number)
    e = a.numerator.bit_length()-a.denominator.bit_length()
    if a < F(2)**e:
        e -= 1
    shift = max(e-nf, 1-bias-nf)
    units = a / F(2)**shift
    q, r = divmod(units.numerator, units.denominator)
    q += int(2*r > units.denominator or (2*r == units.denominator and q % 2))
    if not q:
        return sign << (width-1)
    if q >= 1 << (nf+1):
        q >>= 1
        shift += 1
    exponent = shift+nf+bias if q >= 1 << nf else 0
    require(exponent < (1 << ne)-1, 'Replay overflow: unsupported')
    return (sign << (width-1)) | (exponent << nf) | (q & ((1 << nf)-1))


def textword(bits):
    return f'{bits:032X}'


def neg(a, width):
    return a ^ (1 << (width-1))


def add(a, b, width):
    x, y = value(a, width), value(b, width)
    return encode(x+y, width, not x and not y and bool(a >> (width-1))
                  and bool(b >> (width-1)))


def sub(a, b, width):
    return add(a, neg(b, width), width)


def mul(a, b, width):
    return encode(value(a,width)*value(b,width), width,
                  bool((a ^ b) >> (width-1)))


def _complex_add(a, b, width):
    return tuple(add(x, y, width) for x, y in zip(a, b))


def _complex_neg(a, width):
    return tuple(neg(x, width) for x in a)


def _complex_sub(a, b, width):
    return _complex_add(a, _complex_neg(b, width), width)


def _external(words, width):
    require(len(words) == 32, 'Expected four complex external momenta')
    raw = [word(x, width) for x in words]
    ext = [[tuple(raw[8*e+2*mu:8*e+2*mu+2]) for e in range(4)] for mu in range(4)]
    require(all(value(z[1], width) == 0 for row in ext for z in row),
            'External imaginary momentum is nonzero')
    return ext


def replay_shifts(route, mode, width, external_words, refs=None):
    refs = refs or references()
    d = refs['dag']; r = d['routes'][route-1]
    require(mode in (1,2,4,5) and width == (64 if mode in (1,2) else 128),
            'Mode/precision mismatch')
    ext = _external(external_words, width)
    w = {e+1: [ext[mu][e][0] for mu in range(4)] for e in range(4)}
    proofs = d['wavefunction_proofs']['dp' if width == 64 else 'qp']
    for number in range(5,9):
        rows = proofs[str(number)]
        require(len(rows) == 1 and len(rows[0]['terms']) == 2,
                'Unsupported pinned ALOHA DAG')
        terms = rows[0]['terms']
        w[number] = [add(w[terms[0][1]][mu] if terms[0][0] == 1 else neg(w[terms[0][1]][mu],width),
                         w[terms[1][1]][mu] if terms[1][0] == 1 else neg(w[terms[1][1]][mu],width), width)
                     for mu in range(4)]
    corners = []; offset = 0
    for count in r['pairing']:
        row = [0]*4
        for e in r['we'][offset:offset+count]:
            row = [sub(x,y,width) for x,y in zip(row,w[e])]
        corners.append(row); offset += count
    require(offset == len(r['we']), 'Invalid pinned corner grouping')
    if mode in (2,5) and r['n'] > 2:
        corners = [[neg(x,width) for x in row] for row in reversed(corners)]
    closure = [0]*4
    for row in corners:
        closure = [add(x,y,width) for x,y in zip(closure,row)]
    shifts = [closure]; prefix = [0]*4
    for row in corners[:-1]:
        prefix = [add(x,y,width) for x,y in zip(prefix,row)]
        shifts.append(prefix)
    return {'external': ext, 'corners': corners, 'shifts': shifts}


def _flat_matrix(matrix):
    return [matrix[i][j] for j in range(len(matrix)) for i in range(len(matrix))]


def expected_metadata(route, mode, width, external_words, refs=None):
    refs = refs or references()
    replay = replay_shifts(route,mode,width,external_words,refs)
    r = refs['dag']['routes'][route-1]; n = r['n']
    initial = refs['factory'].build(refs['dag'],route,mode,width,n,replay['external'],True)
    require(initial is not None, 'Factory rejected actual producer inputs')
    finished = refs['factory'].finish(width,replay['shifts'],initial,True)
    require(finished is not None, 'Difference factory rejected shifts')
    zero = refs['factory'].ZERO
    metadata = {'ROUTE': [r['nw'],1,1], 'WE':r['we'], 'PAIRING':r['pairing'],
        'CLASS':_flat_matrix(initial['pair_class']), 'HAVE':[1]*n,
        'CHORD':[x for row in initial['chord_error'] for x in row],
        'PAIR':[int((i,j) in finished) for j in range(n) for i in range(n)],
        'QERROR':[x for j in range(n) for i in range(n)
                  for x in finished.get((i,j),[zero]*4)]}
    return replay, metadata, initial, finished


def _pair_replay(group, replay, initial, finished, refs):
    """Source branch witnesses are required; never invent unobserved decisions."""
    n, width = group['n'],group['width']; w = group['words']; meta=group['meta']
    pairs = group['pairs']
    require(len(pairs) == n*n, 'Missing helper pair witnesses')
    indexed = {(x['i'],x['j']):x for x in pairs}
    require(len(indexed) == n*n and set(indexed) == {(i+1,j+1) for i in range(n) for j in range(n)},
            'Duplicated or missing helper pair indices')
    masses = [tuple(word(x,width) for x in w['MASS'][2*i:2*i+2]) for i in range(n)]
    shifts = replay['shifts']; native = [[0]*n for _ in range(n)]; summaries=[]
    p, emin = (53,-1022) if width == 64 else (113,-16382)
    for j in range(n):
        for i in range(n):
            row=indexed[(i+1,j+1)]; pw=row['words']
            require(type(row['mass_mask']) is int and 0 <= row['mass_mask'] <= 3,
                    'Invalid mass branch witness')
            require(all(type(row[k]) is int and row[k] in (0,1)
                        for k in ('raw_valid','zero_branch','use')), 'Invalid logical pair witness')
            raw=tuple(word(x,width) for x in pw['RAW']); smat=tuple(word(x,width) for x in pw['S'])
            require(len(raw)==len(smat)==2 and len(pw['REF'])==len(pw['DIRECT'])==1,
                    'Invalid helper word shapes')
            direct=word(pw['DIRECT'][0],width); ref=word(pw['REF'][0],width)
            require(row['use'] == meta['USE'][j*n+i], 'Pair USE disagrees with native metadata')
            mass_mask=row['mass_mask']; zero=bool(row['zero_branch'])
            if i==j:
                require(row['raw_valid']==0 and mass_mask==0 and not zero and not row['use'],
                        'Diagonal branch witness invalid')
                expected_s=_complex_neg(_complex_add(masses[i],masses[j],width),width)
                certified=False; raw_real=None
            else:
                require(row['raw_valid']==1, 'Missing offdiagonal raw witness')
                q=[sub(a,b,width) for a,b in zip(shifts[i],shifts[j])]
                raw_real=mul(q[0],q[0],width)
                for component in q[1:]:
                    raw_real=sub(raw_real,mul(component,component,width),width)
                require(raw[0]==raw_real and value(raw[1],width)==0, 'RAW_DIFFSQ source replay mismatch')
                ref_expected=add(0,shifts[i][0]&((1<<(width-1))-1),width)
                ref_expected=add(ref_expected,shifts[j][0]&((1<<(width-1))-1),width)
                ref_expected=encode(value(ref_expected,width)/2,width)
                ref_expected=mul(ref_expected,ref_expected,width)
                require(ref==ref_expected, 'Normalization source replay mismatch')
                require(not zero or value(ref,width)!=0, 'Zero branch with zero normalization')
                expected_s=_complex_sub(_complex_sub(raw,masses[i],width),masses[j],width)
                if mass_mask&1:
                    require(any(value(x,width) for x in masses[i]), 'Mass-I snap on zero mass')
                    expected_s=_complex_neg(masses[j],width)
                if mass_mask&2:
                    require(any(value(x,width) for x in masses[j]), 'Mass-J snap on zero mass')
                    expected_s=_complex_neg(masses[i],width)
                certified=bool(zero and refs['certificate'].certificate(
                    [value(x,width) for x in q],value(raw_real,width),
                    finished.get((i,j),[refs['factory'].ZERO]*4),p,emin,
                    initial['pair_class'][i][j],bool(mass_mask),(i,j) in finished,True))
                require(bool(row['use']) == certified, 'Certificate/USE mismatch')
                if zero and not certified:
                    expected_s=_complex_neg(_complex_add(masses[i],masses[j],width),width)
            require(smat==expected_s, 'Legacy S_MAT branch-order replay mismatch')
            require(direct==(raw_real if certified else 0), 'DIRECT word mismatch')
            native[i][j]=(direct if certified else
                _complex_add(_complex_add(smat,masses[i],width),masses[j],width)[0])
            summaries.append({'pair':[i+1,j+1], 'class':initial['pair_class'][i][j],
                'mass_mask':mass_mask, 'zero_branch':zero, 'certified':certified,
                'raw_word':None if raw_real is None else textword(raw_real)})
    # Source uses numeric inequality: preserve already equal +/-0 bits.
    for j in range(1,n):
        for i in range(j):
            if value(native[j][i],width) != value(native[i][j],width):
                native[j][i]=native[i][j]
    require([textword(x) for x in _flat_matrix(native)]==w['INV'],
            'Native invariant/reconstruction/upper-triangle mismatch')
    return summaries


def validate_geometry(group, producer):
    """Return an explicit proof object; malformed or unknown paths fail closed."""
    result={'passed':False,'failures':[], 'source_evidence':{},
        'scope':'input geometry only; no tensor or amplitude outputs',
        'snap_predicates':'original source branch witnesses; not independently reevaluated'}
    try:
        refs=references(); result['source_evidence']=refs['source_evidence']
        require(isinstance(group,dict) and isinstance(producer,dict), 'Missing producer event')
        route,mode,width,n=group['group'],group['mode'],group['width'],group['n']
        require(type(route) is int and 1<=route<=26, 'Unknown route')
        require((n,group['rank'])==NR[route-1] and group['sqso']==1 and group['backend']==9,
                'Route/rank/split-order/backend mismatch')
        require(group['nc']==(1 if group['rank']==0 else 15), 'Wrong coefficient count')
        require(group['digits']==(53 if width==64 else 113), 'Precision digits mismatch')
        require(group['native_count']==1 and group['unchanged']==1, 'No unchanged native input call')
        require(producer.get('valid') is True and producer['generation']==group['generation']
                and producer['width']==width and group['generation']>0, 'Producer lineage mismatch')
        require(refs['factory'].producer_kind_ok(mode,width,producer['genuine']==1),
                'Unknown or widened precision producer')
        w=group['words'];meta=group['meta']
        require(w['EXTERNAL']==producer['external'], 'Consumer external words differ from producer')
        require(len(w['ENV'])==2 and w['ENV'][0]==w['ENV'][1]==producer['env'],
                'Entry/use/producer environment differs')
        require(HEX.fullmatch(producer['env']) and refs['factory'].environment_ok(int(producer['env'],16)),
                'Unqualified floating environment')
        counts={'SHIFT':4*n,'INV':n*n,'MASS':2*n,'SCALE':1,'CANON':2*group['nc']}
        for tag,count in counts.items():
            require(len(w[tag])==count, 'Wrong '+tag+' input shape')
            for x in w[tag]:word(x,width)
        replay,expected,initial,finished=expected_metadata(route,mode,width,w['EXTERNAL'],refs)
        require(w['SHIFT']==[textword(x) for row in replay['shifts'] for x in row],
                'Source DAG shift/reversal/residual mismatch')
        for tag,items in expected.items():
            require(meta[tag]==items, 'Factory/route metadata mismatch: '+tag)
        require(len(meta['USE'])==n*n and all(type(x)is int and x in (0,1) for x in meta['USE']),
                'Invalid USE shape/values')
        pairs=_pair_replay(group,replay,initial,finished,refs)
        result.update(passed=True, route=route, mode=mode, width=width,
            closure_words=[textword(x) for x in replay['shifts'][0]], pairs=pairs,
            protected_rows_legacy=True, raw_real_replayed=True,
            imaginary_raw_zero_checked=True, signed_imaginary_raw_zero_replayed=False,
            factory_metadata_replayed=True, native_invariants_replayed=True,
            native_status=group['status'], native_status_not_an_accuracy_claim=True)
    except (ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
        result['failures'].append(str(exc))
    return result


def join_matched_mode4(groups, phase=1):
    """Exact input join only; caller must first qualify its accepted epoch."""
    evidence={};result={'passed':False,'failures':[], 'source_evidence':evidence,
        'accepted_epoch_must_be_qualified_by_caller':True}
    try:
        require(phase in (0,1), 'Unknown matched phase')
        matched=_packet('matched',evidence)
        parser=_module('checked_pinned_matched',matched('matched_inputs.py'))
        routes=json.loads(matched('expected-routes.json'))
        routes={int(k):v for k,v in routes.items()}
        closure=json.loads(_pin(MATCHED_RESULTS/'run-closure.json',{'sha256':MATCHED_CLOSURE},evidence))
        require(closure['passed'] is True, 'Closed matched run did not pass')
        logical='runs/cms-p20-mode4-lib9-matched/trace.dat'
        raw=_pin(MATCHED_RESULTS/logical,closure['payloads'][logical],evidence)
        old=parser.parse_trace(raw.decode('ascii'),9,routes)['calls']
        selected=[x for x in old if x['phase']==phase]
        require(len(groups)==26 and len(selected)==26, 'Expected complete 26-group mode4 epoch')
        current={x['group']:x for x in groups}
        require(set(current)==set(range(1,27)), 'Duplicate/missing checked groups')
        differences=[]
        for reference in selected:
            group=current[reference['group']]
            require(group['mode']==4 and group['width']==128 and group['phase']==phase,
                    'Matched join requires actual mode4/phase')
            for field in ('rank','n','nc','sqso','backend'):
                require(group[field]==reference[field], 'Matched call shape mismatch')
            for tag in ('SHIFT','INV','MASS','SCALE','CANON'):
                a,b=group['words'][tag],reference['words'][tag]
                require(len(a)==len(b), 'Matched word shape mismatch')
                differences += [{'group':group['group'],'field':tag,'index':i,
                                 'current':x,'reference':y}
                                for i,(x,y) in enumerate(zip(a,b)) if x!=y]
        result.update(passed=not differences,differences=differences,groups=26,phase=phase)
    except (ValueError,KeyError,TypeError,IndexError) as exc:
        result['failures'].append(str(exc))
    return result
