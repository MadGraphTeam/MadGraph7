"""Pure regression checks of observation placement and exact source inverse."""
import importlib.util
from pathlib import Path
import re
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('private_checked_prepare_tests', HERE / 'prepare.py')
P = importlib.util.module_from_spec(spec)
spec.loader.exec_module(P)


class SourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.products, cls.proof = P.derive()

    def text(self, name):
        return self.products['candidate/' + name].decode()

    def test_all_six_scientific_bodies_restore_exactly(self):
        for name in P.NAMES:
            self.assertEqual(P.MARK.sub('', self.text(name)).encode(),
                             (P.BASE / 'candidate' / name).read_bytes())
        altered = self.text('loop_matrix.f').replace('      STAB_INDEX=0\n', '      STAB_INDEX=1\n', 1)
        self.assertNotEqual(P.MARK.sub('', altered).encode(),
                            (P.BASE / 'candidate/loop_matrix.f').read_bytes())

    def test_subroutine_boundary_does_not_absorb_separating_newlines(self):
        raw = '      SUBROUTINE A()\n      END\n\n\n      SUBROUTINE B()\n      END\n'
        self.assertEqual(P.sub(raw, 'A'), '      SUBROUTINE A()\n      END')

    def test_legacy_reducers_and_public_helpers_unchanged(self):
        old = (P.BASE / 'candidate/CT_interface.f').read_text()
        current = self.text('CT_interface.f')
        for name in ('ML5_0_NINJARS_LOOP', 'ML5_0_MP_NINJARS_LOOP',
                     'ML5_0_BUILD_KINEMATIC_MATRIX', 'ML5_0_MP_BUILD_KINEMATIC_MATRIX'):
            self.assertEqual(P.sub(current, name), P.sub(old, name), name)
        self.assertEqual(self.text('loop_CT_calls_1.f'), (P.BASE / 'candidate/loop_CT_calls_1.f').read_text())

    def test_four_callers_bracket_private9_with_explicit_metadata(self):
        for name in ('ML5_0_LOOP_3', 'ML5_0_LOOP_4', 'ML5_0_LOOP_2', 'ML5_0_LOOP_1_2'):
            body = P.sub(self.text('CT_interface.f'), name)
            self.assertEqual(body.count('CALL PC_CHECKED_GROUP_BEGIN('), 2)
            self.assertEqual(body.count('CALL PC_CHECKED_GROUP_END('), 2)
            self.assertEqual(body.count('RESHAPE(PC_EXTERNAL,(/32/))'), 2)
            for call in ('CALL ML5_0_PRIVATE_TIRLOOP(', 'CALL ML5_0_PRIVATE_MP_TIRUST_LOOP('):
                at = body.index(call)
                self.assertGreater(at, body.rfind('CALL PC_CHECKED_GROUP_BEGIN(', 0, at))
                self.assertLess(at, body.index('CALL PC_CHECKED_GROUP_END(', at))

    def test_errors_observed_immediately_without_raw_outputs(self):
        for name in ('ML5_0_PRIVATE_TIRUST_DIAGNOSTIC', 'ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC'):
            body = P.sub(self.text('TIRUST_interface.f'), name)
            call = body.index('CALL TIRUST_TENSOR_EVALUATE(')
            self.assertLess(body.index('CALL PC_CHECKED_NATIVE_END(', call),
                            body.index('IF(STATUS.NE.TIRUST_SUCCESS) RETURN', call))
            marked = '\n'.join(m.group() for m in P.MARK.finditer(body))
            self.assertNotIn('RAW(', marked)
            self.assertIn('CALL PC_CHECKED_ADAPTER_STAGE(0,-999)', marked)
            self.assertIn('CALL PC_CHECKED_ADAPTER_STAGE(3,STATUS)', marked)

    def test_pair_witnesses_follow_actual_unchanged_branches(self):
        for name in ('ML5_0_PRIVATE_KINEMATIC_MATRIX', 'ML5_0_MP_PRIVATE_KINEMATIC_MATRIX'):
            body = P.sub(self.text('CT_interface.f'), name)
            self.assertEqual(body.count('CALL PC_CHECKED_PAIR('), 2)
            self.assertEqual(body.count('NC_MASS_MASK=IOR(NC_MASS_MASK,1)'), 1)
            self.assertEqual(body.count('NC_MASS_MASK=IOR(NC_MASS_MASK,2)'), 1)
            start = body.index('IF(ABS(DIFFSQ/REF_NORMALIZATION).LT.OSTHRES)THEN')
            self.assertLess(start, body.index('NC_ZERO_BRANCH=.TRUE.', start))
            self.assertLess(body.index('NC_ZERO_BRANCH=.TRUE.', start),
                            body.index('PC_USE(I,J)=PC_CERTIFY_', start))

    def test_producer_and_reset_hooks_observe_original_transitions(self):
        body = P.sub(self.text('loop_matrix.f'), 'ML5_0_SLOOPMATRIX_RETRY_IMPL')
        qp = body.index('PC_ENV_QP=PC_CAPTURE_ENV()')
        self.assertLess(qp, body.index('CALL PC_CHECKED_PRODUCER_BEGIN(128', qp))
        self.assertLess(body.index('CALL ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(', qp),
                        body.index('CALL PC_CHECKED_PRODUCER_END(128', qp))
        rescue = body.index('CALL PC_CHECKED_RESCUE_TRANSITION(')
        reset = body.index('FPE_IN_DP_REDUCTION=.FALSE.', rescue)
        self.assertLess(rescue, reset)
        self.assertLess(reset, body.index('CALL PC_CHECKED_FLAGS_RESET(', reset))
        self.assertIn('NC_WORD64=TRANSFER(W(NC_J)%P(NC_I),NC_WORD64)', body)
        self.assertIn('MPW(NC_J)%P(NC_I),NC_EXTERNAL(:,NC_I,NC_J)', body)

    def test_driver_is_checked_and_strictly_bounded(self):
        driver = self.products['driver-checked.f'].decode()
        self.assertEqual(driver.count('CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)'), 2)
        self.assertEqual(driver.count('CALL ML5_0_FORCE_STABILITY_CHECK(.TRUE.)'), 1)
        self.assertNotIn('FORCE_STABILITY_CHECK(.FALSE.)', driver)
        self.assertNotIn('1000+NPOINTS', driver)
        self.assertIn('IF(DID_RUN.OR.SEQUENCE.NE.1.OR.NLOOPS.NE.1)', driver)
        self.assertIn("IF(STAGE.EQ.'A'.AND.(CODE.EQ.219.OR.CODE.EQ.323))", driver)
        self.assertNotIn('CODE.EQ.120', driver)
        for name in ('KTRACE_DRIVER_VALUES', 'KTRACE_READ_POINT'):
            self.assertEqual(P.sub(driver, name), P.sub((P.BASE / 'driver-amplitude.f').read_text(), name))

    def test_card_one_value_change_with_exact_inverse(self):
        old = (P.BASE / 'inputs/cms-backend9-mode4-MadLoopParams.dat').read_bytes()
        new = self.products['inputs/backend9-auto-MadLoopParams.dat']
        self.assertEqual(new.replace(b'#CTModeRun\n-1\n', b'#CTModeRun\n4\n', 1), old)
        self.assertIn(b'#TIRustGlobalCache\n0\n', new)

    def test_observation_blocks_never_modify_scientific_state(self):
        forbidden = re.compile(r'^\s*(?:FPE_IN_|PC_ENV_|PC_CLASS|PC_CHORD|PC_HAVE|PC_USE|DIFFSQ|S_MAT|CTMODE|MP_DONE|ANS|LOOPRES|LOOPCOEFS)\w*[^=]*=', re.M)
        for name in P.NAMES:
            for block in P.MARK.finditer(self.text(name)):
                self.assertIsNone(forbidden.search(block.group()), (name, block.group(1)))


if __name__ == '__main__':
    unittest.main()
