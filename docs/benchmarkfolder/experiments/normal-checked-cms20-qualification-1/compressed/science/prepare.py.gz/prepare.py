"""Hash-before-parse, source-only observation derivative of the sealed C2 candidate.

All scientific changes are insertions inside uniquely named comment blocks.
Removing those blocks must restore all six original source bytes exactly.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / '.tirust-build/kinematic-invariant-amplitude-proposal-2'
BASE_SHA = 'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
PLAN = ROOT / '.tirust-build/kinematic-normal-checked-proposal-1'
PLAN_SHA = '9387a2858df75bf34d0940121da6e006fe7648a9d63d241276ba05f94487f7b4'
MATCHED = ROOT / '.tirust-build/kinematic-matched-native-input-proposal-1'
MATCHED_SHA = '357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b'
NAMES = ('CT_interface.f', 'TIRUST_interface.f', 'TIR_interface.f',
         'loop_matrix.f', 'loop_CT_calls_1.f', 'mp_compute_loop_coefs.f')
MARK = re.compile(r'^C NCHECK_BEGIN ([A-Z0-9_]+)\n.*?^C NCHECK_END \1\n', re.M | re.S)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin_bytes(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def pin(path):
    return pin_bytes(Path(path).read_bytes())


def packet(root, sha):
    require(pin(root / 'index.json')['sha256'] == sha, 'Source index changed: ' + str(root))
    index = json.loads((root / 'index.json').read_bytes())
    for name, expected in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe source path')
        require(pin(root / name) == {k: expected[k] for k in ('bytes', 'sha256')},
                'Sealed source changed: ' + name)
    return index


def once(text, old, new):
    require(text.count(old) == 1, ('Anchor differs', text.count(old), old[:120]))
    return text.replace(old, new, 1)


def insertion(name, text):
    require(re.fullmatch('[A-Z0-9_]+', name) is not None, 'Bad observation block name')
    require(text.endswith('\n'), 'Observation insertion needs final newline')
    return 'C NCHECK_BEGIN ' + name + '\n' + text + 'C NCHECK_END ' + name + '\n'


def before(text, anchor, name, new):
    return once(text, anchor, insertion(name, new) + anchor)


def after(text, anchor, name, new):
    return once(text, anchor, anchor + insertion(name, new))


def sub(text, name):
    start = text.index('      SUBROUTINE ' + name + '(')
    end = re.search(r'^      END[ \t]*$', text[start:], re.M)
    require(end is not None, 'Missing subroutine end: ' + name)
    return text[start:start + end.end()]


def replace_sub(text, name, function):
    original = sub(text, name)
    result = function(original)
    require(MARK.sub('', result) == original, 'Scientific body changed: ' + name)
    return once(text, original, result)


def use(body, name, anchor='      IMPLICIT NONE\n'):
    return before(body, anchor, name, '      USE ML_PRIVATE_CHECKED_TRACE\n')


def external_words(width):
    if width == 64:
        copy = ('              NC_WORD64=TRANSFER(W(NC_J)%P(NC_I),NC_WORD64)\n'
                '              NC_EXTERNAL(:,NC_I,NC_J)=IAND(\n'
                '     $         INT(NC_WORD64,PC_IK),MASKR(64,PC_IK))\n')
        wave, token, producer = 'W', 'PC_ENV_DP', '.TRUE.'
    else:
        copy = ('              NC_EXTERNAL(:,NC_I,NC_J)=TRANSFER(\n'
                '     $         MPW(NC_J)%P(NC_I),NC_EXTERNAL(:,NC_I,NC_J))\n')
        wave, token, producer = 'MPW', 'PC_ENV_QP', 'PC_QP_PRODUCER'
    return ('            DO NC_J=1,4\n'
            '              DO NC_I=0,3\n' + copy +
            '              ENDDO\n'
            '            ENDDO\n'
            f'            CALL PC_CHECKED_PRODUCER_END({width},{producer},\n'
            f'     $       {token},RESHAPE(NC_EXTERNAL,(/32/)))\n')


def loop_matrix(text):
    def instrument(b):
        b = use(b, 'HOST_USE')
        b = after(b, '      LOGICAL PC_QP_PRODUCER,PC_CALL_PRODUCER\n', 'HOST_DECL',
                  '      INTEGER NC_I,NC_J\n'
                  '      INTEGER*8 NC_WORD64(2)\n'
                  '      INTEGER(PC_IK) NC_EXTERNAL(2,0:3,4)\n')
        b = before(b, '      PC_ENV_DP=0_PC_IK\n', 'HOST_ENTER',
                   '      CALL PC_CHECKED_SLOOP_ENTER()\n')
        b = after(b, '          PC_ENV_QP=PC_CAPTURE_ENV()\n', 'QP_PRODUCER_BEGIN',
                  '          CALL PC_CHECKED_PRODUCER_BEGIN(128,PC_ENV_QP)\n')
        b = after(b, '          CALL ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(MP_P,\n'
                     '     $     BUFFR_BIS,PC_QP_PRODUCER)\n', 'QP_PRODUCER_END', external_words(128))
        b = after(b, '          PC_ENV_DP=PC_CAPTURE_ENV()\n', 'DP_PRODUCER_BEGIN',
                  '          CALL PC_CHECKED_PRODUCER_BEGIN(64,PC_ENV_DP)\n')
        b = after(b, '          CALL ML5_0_HELAS_CALLS_AMPB_1(P,NHEL,H,IC)\n',
                  'DP_PRODUCER_END', external_words(64))
        b = after(b, ' 300  CONTINUE\n', 'PASS_BEGIN',
                  '      CALL PC_CHECKED_PASS_BEGIN(CTMODE,MLREDUCTIONLIB(I_LIB),\n'
                  '     $ CHECKPHASE,HELDOUBLECHECKED,MP_DONE,MP_DONE_ONCE,\n'
                  '     $ EVAL_DONE,STAB_INDEX)\n')
        b = before(b, ' 1226 CONTINUE\n', 'PASS_END',
                   '      CALL PC_CHECKED_PASS_END(S,FPE_IN_DP_REDUCTION,\n'
                   '     $ FPE_IN_QP_REDUCTION)\n')
        anchor = '          IF(MAXVAL(ACC).GE.MLSTABTHRES) THEN\n'
        require(b.count(anchor) == 2, 'Two precision accuracy decisions expected')
        parts = b.split(anchor)
        b = parts[0] + insertion('QP_DECISION',
              '          CALL PC_CHECKED_DECISION(128,ACC,MLSTABTHRES,\n'
              '     $     FPE_IN_DP_REDUCTION,FPE_IN_QP_REDUCTION)\n') + anchor + parts[1] + insertion('DP_DECISION',
              '          CALL PC_CHECKED_DECISION(64,ACC,MLSTABTHRES,\n'
              '     $     FPE_IN_DP_REDUCTION,FPE_IN_QP_REDUCTION)\n') + anchor + parts[2]
        b = before(b, '              I_LIB=INDEX_QP_TOOLS(1)\n', 'RESCUE_TRANSITION',
                   '              CALL PC_CHECKED_RESCUE_TRANSITION(\n'
                   '     $         FPE_IN_DP_REDUCTION,FPE_IN_QP_REDUCTION)\n')
        anchor = ('              FPE_IN_DP_REDUCTION=.FALSE.\n'
                  '              FPE_IN_QP_REDUCTION=.FALSE.\n'
                  '              I_QP_LIB=1\n')
        b = after(b, anchor, 'RESCUE_RESET',
                  '              CALL PC_CHECKED_FLAGS_RESET(\n'
                  '     $         FPE_IN_DP_REDUCTION,FPE_IN_QP_REDUCTION)\n')
        b = before(b, 'C     Reinitialize the check phase logicals and the filters if check\n', 'HOST_EXIT',
                   '      CALL PC_CHECKED_SLOOP_EXIT(RET_CODE_H,RET_CODE_T,\n'
                   '     $ RET_CODE_U,ACCURACY,FPE_IN_DP_REDUCTION,\n'
                   '     $ FPE_IN_QP_REDUCTION)\n')
        return b
    return replace_sub(text, 'ML5_0_SLOOPMATRIX_RETRY_IMPL', instrument)


def mp_compute(text):
    def instrument(b):
        b = use(b, 'MP_USE')
        return after(b, '            DPW_COPIED=.TRUE.\n', 'NARROWED_DP_INVALID',
                     '            CALL PC_CHECKED_DP_INVALID()\n')
    return replace_sub(text, 'ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS', instrument)


def ct_interface(text):
    def instrument(b):
        b = use(b, 'GROUP_USE', '      USE ALOHA_OBJECT\n')
        b = after(b, '      LOGICAL PC_ROUTE_OK,PC_PRODUCER_OK\n', 'GROUP_FLAGS',
                  '      LOGICAL NC_FPE_DP,NC_FPE_QP\n'
                  '      COMMON/ML5_0_FPE_IN_REDUCTION/NC_FPE_DP,NC_FPE_QP\n')
        qp = ('            CALL ML5_0_PRIVATE_MP_TIRUST_LOOP(NLOOPLINE,MP_PL,M2L,\n'
              '     $       RANK,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),\n'
              '     $       S(SQUAREDSOINDEX,LOOPNUM),LOOPNUM,SQUAREDSOINDEX,\n'
              '     $       PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)\n')
        dp = ('            CALL ML5_0_PRIVATE_TIRLOOP(SQUAREDSOINDEX,LOOPNUM,I_LIB,\n'
              '     $       NLOOPLINE,PL,M2L,RANK,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),\n'
              '     $       S(SQUAREDSOINDEX,LOOPNUM),PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)\n')
        start = ('            CALL PC_CHECKED_GROUP_BEGIN(CTMODE,LOOPNUM,\n'
                 '     $       SQUAREDSOINDEX,NLOOPLINE,RANK,SIZE(WE),WE,\n'
                 '     $       PAIRING,PC_ROUTE_OK,PC_PRODUCER_OK,PC_CHORD,\n'
                 '     $       PC_CLASS,PC_HAVE,PC_ENV,\n'
                 '     $       RESHAPE(PC_EXTERNAL,(/32/)))\n')
        end = ('            CALL PC_CHECKED_GROUP_END(S(SQUAREDSOINDEX,LOOPNUM),\n'
               '     $       NC_FPE_DP,NC_FPE_QP)\n')
        for width, call in ((128, qp), (64, dp)):
            b = before(b, call, f'GROUP_BEGIN_{width}', start)
            b = after(b, call, f'GROUP_END_{width}', end)
        return b
    for name in ('ML5_0_LOOP_3', 'ML5_0_LOOP_4', 'ML5_0_LOOP_2', 'ML5_0_LOOP_1_2'):
        text = replace_sub(text, name, instrument)
    def helper(b):
        qp = b.startswith('      SUBROUTINE ML5_0_MP_PRIVATE_')
        zero = '0.0E0_16' if qp else '0.0D0'
        b = use(b, 'PAIR_USE', '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,\n')
        b = after(b, '      INTEGER I,J,K\n', 'PAIR_DECL',
                  '      INTEGER NC_MASS_MASK\n'
                  '      LOGICAL NC_ZERO_BRANCH\n')
        diagonal = '          IF(I.EQ.J)THEN\n            S_MAT(I,J)=-(M2L(I)+M2L(J))\n'
        b = after(b, diagonal, 'PAIR_DIAGONAL',
                  '            CALL PC_CHECKED_PAIR(I,J,.FALSE.,\n'
                  f'     $       ({zero},{zero}),S_MAT(I,J),{zero},\n'
                  f'     $       0,.FALSE.,.FALSE.,{zero})\n')
        b = after(b, '            PC_MASS_SNAP=.FALSE.\n', 'PAIR_BRANCH_RESET',
                  '            NC_MASS_MASK=0\n'
                  '            NC_ZERO_BRANCH=.FALSE.\n')
        anchor = '                PC_MASS_SNAP=.TRUE.\n'
        require(b.count(anchor) == 2, 'Two ordered mass-snap assignments required')
        chunks = b.split(anchor)
        b = chunks[0] + anchor + insertion('PAIR_MASS_I',
              '                NC_MASS_MASK=IOR(NC_MASS_MASK,1)\n') + chunks[1] + anchor + insertion('PAIR_MASS_J',
              '                NC_MASS_MASK=IOR(NC_MASS_MASK,2)\n') + chunks[2]
        b = after(b, '              IF(ABS(DIFFSQ/REF_NORMALIZATION).LT.OSTHRES)THEN\n',
                  'PAIR_ZERO_BRANCH', '                NC_ZERO_BRANCH=.TRUE.\n')
        anchor = '              ENDIF\n            ENDIF\n          ENDIF\n\n        ENDDO\n'
        require(b.count(anchor) == 1, 'Pair-final branch anchor differs')
        b = once(b, anchor, '              ENDIF\n            ENDIF\n' + insertion('PAIR_OFFDIAGONAL',
                 '            CALL PC_CHECKED_PAIR(I,J,.TRUE.,DIFFSQ,\n'
                 '     $       S_MAT(I,J),REF_NORMALIZATION,NC_MASS_MASK,\n'
                 '     $       NC_ZERO_BRANCH,PC_USE(I,J),PC_DIRECT(I,J))\n') +
                 '          ENDIF\n\n        ENDDO\n')
        return b
    for name in ('ML5_0_PRIVATE_KINEMATIC_MATRIX', 'ML5_0_MP_PRIVATE_KINEMATIC_MATRIX'):
        text = replace_sub(text, name, helper)
    return text


def tir_interface(text):
    def instrument(b):
        b = use(b, 'DP_CANON_USE', '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK\n')
        return before(b, '        CALL ML5_0_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,\n',
                      'DP_CANONICAL',
                      '        CALL PC_CHECKED_CANONICAL(\n'
                      '     $   LOOPCOEFS(0:NLOOPCOEFS-1,I_SQSO,I_LOOPGROUP))\n')
    return replace_sub(text, 'ML5_0_PRIVATE_TIRLOOP', instrument)


def tirust_interface(text):
    def diagnostic(b):
        b = use(b, 'NATIVE_USE')
        b = before(b, '      STABLE=.FALSE.\n', 'ADAPTER_ENTRY',
                   '      CALL PC_CHECKED_ADAPTER_STAGE(0,-999)\n')
        b = after(b, '      IF(RANK.LT.0.OR.RANK.GT.2) RETURN\n', 'ADAPTER_RANK',
                  '      CALL PC_CHECKED_ADAPTER_STAGE(1,-999)\n')
        b = after(b, '      IF(.NOT.TIRUST_SUPPORTS(NLOOPLINE,RANK,TIRUSTCOMPUTEFINITE))\n'
                     '     $  RETURN\n', 'ADAPTER_SUPPORT',
                  '      CALL PC_CHECKED_ADAPTER_STAGE(2,-999)\n')
        b = after(b, '      CALL ML5_0_INITIALIZE_TIRUST(STATUS)\n', 'ADAPTER_PLAN',
                  '      CALL PC_CHECKED_ADAPTER_STAGE(3,STATUS)\n')
        b = after(b, '      CALL TIRUST_SET_CACHE_BUDGET(INT(TIRUSTCACHEMAXBYTES,C_INT64_T)\n'
                     '     $ ,STATUS)\n', 'ADAPTER_CACHE',
                  '      CALL PC_CHECKED_ADAPTER_STAGE(4,STATUS)\n')
        call = ('      CALL TIRUST_TENSOR_EVALUATE(NLOOPLINE,RANK,SHIFTS,INVARIANTS\n'
                '     $ ,MASSES,SCALE,RAW(1:NC,1:4),STATUS,MAX(0,LOOPPOLEMODE)\n'
                '     $ ,TIRUSTCOMPUTEFINITE,CHECK_PASS,CACHE_ENABLED)\n')
        b = before(b, call, 'NATIVE_BEGIN',
                   '      CALL PC_CHECKED_NATIVE_BEGIN(CTMODE,NLOOPLINE,RANK,\n'
                   '     $ SHIFTS,INVARIANTS,MASSES,SCALE,PC_CLASS,PC_HAVE,\n'
                   '     $ PC_PAIR,PC_USE,PC_CHORD,PC_QERROR,PC_ENV,CHECK_PASS,\n'
                   '     $ CACHE_ENABLED,TIRUSTCOMPUTEFINITE,MAX(0,LOOPPOLEMODE))\n')
        b = after(b, call, 'NATIVE_END',
                  '      CALL PC_CHECKED_NATIVE_END(STATUS,SHIFTS,INVARIANTS,\n'
                  '     $ MASSES,SCALE)\n')
        return b
    for name in ('ML5_0_PRIVATE_TIRUST_DIAGNOSTIC', 'ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC'):
        text = replace_sub(text, name, diagnostic)
    def canonical(b):
        b = use(b, 'QP_CANON_USE')
        return before(b, '      CALL ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,\n',
                      'QP_CANONICAL',
                      '      CALL PC_CHECKED_CANONICAL(\n'
                      '     $ LOOPCOEFS(0:NCOEF_R(RANK)-1,SQSOINDEX,ID))\n')
    return replace_sub(text, 'ML5_0_PRIVATE_MP_TIRUST_LOOP', canonical)


def driver():
    donor_name = ('.tirust-build/current-cms-replay-2/workers/candidate-9-auto/'
                  'cms_ew_n2_epem_mupmum/SubProcesses/P0_epem_mupmum/check_sa.f')
    donor = (ROOT / donor_name).read_text()
    main = (HERE / 'driver-main.f.in').read_text()
    force = '      CALL ML5_0_FORCE_STABILITY_CHECK(.TRUE.)\n'
    require(donor.count(force) == main.count(force) == 1, 'Checked FORCE policy differs')
    thres = 'CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)'
    require(donor.count(thres) == 3 and main.count(thres) == 2, 'Checked THRES derivation differs')
    require('1000+NPOINTS' in donor and '1000+NPOINTS' not in main, 'Bounded warmup removal differs')
    require('FORCE_STABILITY_CHECK(.FALSE.)' not in main, 'Checked force policy weakened')
    helpers = (BASE / 'driver-amplitude.f').read_text()
    card = sub(helpers, 'KTRACE_DRIVER_CARD')
    card = once(card, '      INTEGER MODE,BACKEND\n',
                '      INTEGER MODE,BACKEND\n'
                '      LOGICAL NC_BYPASS,NC_FORCE\n'
                '      COMMON/ML5_0_BYPASS_CHECK/NC_BYPASS,NC_FORCE\n')
    card = once(card, '      IF(LoopPoleMode.NE.0) STOP 24\n',
                '      IF(LoopPoleMode.NE.0.OR.MODE.NE.-1.OR.BACKEND.NE.9)\n'
                '     $ STOP 24\n'
                '      IF(.NOT.NC_FORCE.OR.NC_BYPASS) STOP 24\n'
                '      IF(NRotations_DP.NE.0.OR.NRotations_QP.NE.0) STOP 24\n'
                '      IF(MLStabThres.NE.1.000000D-03) STOP 24\n'
                '      IF(ImprovePSPoint.NE.2.OR.CheckCycle.NE.3) STOP 24\n')
    state = sub(helpers, 'KTRACE_DRIVER_STATE')
    state = once(state, "      IF(STAGE.EQ.'A'.AND.(CODE.EQ.110.OR.CODE.EQ.120))\n",
                 "      IF(STAGE.EQ.'A'.AND.(CODE.EQ.219.OR.CODE.EQ.323))\n")
    state = once(state, 'C     returning an unchecked fixed-mode code. INIT has then been restored.\n',
                 'C     returning a recognized checked code. INIT has then been restored.\n')
    values = sub(helpers, 'KTRACE_DRIVER_VALUES')
    read_point = sub(helpers, 'KTRACE_READ_POINT')
    combined = main.rstrip() + '\n\n' + '\n\n'.join((card, state, values, read_point)) + '\n'
    return combined.encode(), {'checked_donor': {'path': donor_name, **pin(ROOT / donor_name)},
        'checked_policy': {'force_stability_check': True, 'requested_precision': '-1D0',
                           'thres_requests': 2, 'long_warmup_removed': True},
        'raw_value_helper_unchanged': pin_bytes(values.encode()),
        'point_reader_unchanged': pin_bytes(read_point.encode()),
        'state_helper_delta': 'Read actual CT mode only for checked219/323; comments updated',
        'card_helper_delta': 'Read-only checks for exact checked policy and bound card values'}


def derive():
    base = packet(BASE, BASE_SHA)
    packet(PLAN, PLAN_SHA)
    packet(MATCHED, MATCHED_SHA)
    bindings = json.loads((PLAN / 'bindings.json').read_bytes())['files']
    for name, expected in bindings.items():
        require(pin(ROOT / name) == expected, 'Plan input changed: ' + name)
    transforms = {'loop_matrix.f': loop_matrix, 'mp_compute_loop_coefs.f': mp_compute,
                  'CT_interface.f': ct_interface, 'TIR_interface.f': tir_interface,
                  'TIRUST_interface.f': tirust_interface}
    products, proof = {}, {}
    for name in NAMES:
        raw = (BASE / 'candidate' / name).read_bytes()
        text = raw.decode()
        result = transforms.get(name, lambda x: x)(text)
        require(MARK.sub('', result) == text, 'Whole-source inverse failed: ' + name)
        products['candidate/' + name] = result.encode()
        products[name + '.patch'] = ''.join(difflib.unified_diff(
            text.splitlines(True), result.splitlines(True), fromfile='candidate2/' + name,
            tofile='checked/' + name)).encode()
        proof[name] = {'original': pin_bytes(raw), 'derived': pin_bytes(result.encode()),
                       'instrumentation_blocks': len(MARK.findall(result)), 'exact_inverse': True}
    for name in ('cms-point1.dat', 'cms-point20.dat', 'cms-param_card.dat'):
        products['inputs/' + name] = (BASE / 'inputs' / name).read_bytes()
    original_card = (BASE / 'inputs/cms-backend9-mode4-MadLoopParams.dat').read_bytes()
    require(original_card.count(b'#CTModeRun\n4\n') == 1, 'Card mode anchor')
    card = original_card.replace(b'#CTModeRun\n4\n', b'#CTModeRun\n-1\n', 1)
    policy = json.loads((PLAN / 'policy.json').read_bytes())
    require(pin_bytes(card) == policy['planned_literal_card_pin'], 'Literal checked card differs')
    products['inputs/backend9-auto-MadLoopParams.dat'] = card
    products['driver-checked.f'], driver_proof = driver()
    products['expected-routes.json'] = (MATCHED / 'expected-routes.json').read_bytes()
    proof = {'schema': 'private-checked-source-inverse-v1', 'base_sha256': BASE_SHA,
             'plan_sha256': PLAN_SHA, 'base_payloads': len(base['files']),
             'scientific_arithmetic_changed': False, 'protected_legacy8_restored': True,
             'sources': proof, 'card_inverse': True,
             'driver': driver_proof,
             'declared_compile_objects': ['checked_trace.o', 'check_sa.o', 'loop_matrix.o',
                 'mp_compute_loop_coefs.o', 'CT_interface.o', 'TIR_interface.o', 'TIRUST_interface.o'],
             'new_native_actions': 0}
    return products, proof


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    products, proof = derive()
    if args.write:
        require(not (HERE / 'index.json').exists(), 'Sealed source packet is immutable')
        for name, raw in products.items():
            path = HERE / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        (HERE / 'source-proof.json').write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'products': len(products), 'sources': len(proof['sources']),
                      'all_exact_inverses': True, 'native_actions': 0}))
