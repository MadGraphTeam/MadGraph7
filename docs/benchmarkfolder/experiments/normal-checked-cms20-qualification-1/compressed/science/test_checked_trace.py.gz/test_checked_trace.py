"""Pure synthetic protocol/state-machine tests, not numerical qualification.

The explicit geometry test double ONLY isolates lifecycle gating; real admission
must use the separately authenticated exact geometry implementation. No compiler,
loader, library or Fortran code is executed by this suite.
"""
import copy
import importlib.util
from pathlib import Path
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('private_checked_test_module',HERE/'checked_trace.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
ZERO='0'*32
ONE='0'*16+'3FF0000000000000'
THRESHOLD='0'*16+'3F50624DD2F1A9FC'
ENV='00000000000000004B4500001F80033F'
ROUTES={i:{'n':n,'rank':rank,'sqso':1,'nw':n,'we':list(range(1,n+1)),'pairing':[1]*n}
        for i,(n,rank) in enumerate(M.CMS_SHAPES,1)}


def geometry_test_double(group,producer):
    return {'passed':True,'test_only':'synthetic lifecycle fixture; no numerical/source qualification'}


def outer(code):
    return {'code':code,'output_words':['0000000000000000']*8,
            'accuracy_words':['0000000000000000']*2,'fpe_dp':0,'fpe_qp':0}


class Fixture:
    def __init__(self):
        self.clock=0;self.entry=0;self.pas=0;self.generation=0
        self.events=[];self.groups=[];self.phases=[];self.epoch_flags=[0,0]
    def tick(self):
        self.clock+=1;return self.clock
    def event(self,kind,iv,wv=()):
        e={'seq':self.tick(),'kind':kind,'phase':self.phase,'entry':self.entry,
           'pass_id':self.pas,'ints':list(iv),'words':list(wv)}
        self.events.append(e);return e
    def producer(self,width,narrow=False):
        self.generation+=1;gen=self.generation
        self.event(5,[width,gen],[ENV])
        if narrow:
            self.event(7,[gen-1])
        self.event(6,[width,gen,1],[ENV]+[ZERO]*32)
        return gen
    def group(self,mode,group,gen,fail=False,early=False):
        route=ROUTES[group];n=route['n'];rank=route['rank'];nc=(rank+1)*(rank+2)*(rank+3)*(rank+4)//24
        width=64 if mode<4 else 128
        status=1 if fail else 0
        if fail or early:
            self.epoch_flags[0 if width==64 else 1]=1
        g=dict(zip(M.FIELDS,[len(self.groups)+1,self.phase,self.entry,self.pas,mode,9,group,1,n,rank,nc,
                           width,53 if width==64 else 113,gen,0 if early else 1,-999 if early else status,
                           1,0 if fail or early else 1,*self.epoch_flags,0 if early else 1,1 if early else 0]))
        g['times']=[self.tick(),self.tick(),0,0,0]
        if not early:
            self.event(11,[g['seq'],int(mode in (2,5)),0,1,0])
            g['times'][2]=self.tick();g['times'][3]=self.tick()
        g['times'][4]=self.tick()
        pair_flags=[]
        for j in range(n):
            for i in range(n):
                pair_flags.extend([int(i!=j),0,0,0])
        g['meta']={'TIMES':g['times'],'STAGE':[4,0] if early else[5,-999],
            'PSEEN':[0 if early else 1]*(n*n),'PFLAGS':pair_flags,'ROUTE':[n,1,1],'WE':route['we'],
            'PAIRING':route['pairing'],'CLASS':[0]*(n*n),'HAVE':[1]*n,'PAIR':[0]*(n*n),'USE':[0]*(n*n),
            'CHORD':[0]*(4*n),'QERROR':[0]*(4*n*n)}
        g['words']={'ENV':[ENV,ZERO if early else ENV],'EXTERNAL':[ZERO]*32,'SHIFT':[ZERO]*(4*n),
            'INV':[ZERO]*(n*n),'MASS':[ZERO]*(2*n),'SCALE':[ONE if width==64 else '3FFF'+'0'*28],
            'CANON':[ZERO]*(2*nc),'PRAW':[ZERO]*(2*n*n),'PSMAT':[ZERO]*(2*n*n),
            'PREF':[ZERO]*(n*n),'PDIRECT':[ZERO]*(n*n)}
        err=b'synthetic native failure' if fail else b''
        g['error']={'length':len(err),'ambiguous':0,'hex':err.hex().upper()}
        self.groups.append(g);return g
    def passes(self,modes,gen,failed=False,early=False):
        for mode in modes:
            self.pas+=1
            self.event(3,[mode,9,0,1,int(mode>=4),int(mode>=4),1 if mode in (1,4) else 3,
                          0 if mode in (1,4) else 1])
            gs=[self.group(mode,i,gen,fail=failed and mode==1 and i==3,
                           early=early and mode==1 and i==3) for i in range(1,27)]
            self.event(4,[*self.epoch_flags]+[g['stable'] for g in gs])
    def phase_packet(self,phase,rescued=False,early=False):
        self.phase=phase;self.entry+=1;self.epoch_flags=[0,0]
        start_e=len(self.events);start_g=len(self.groups)
        self.event(1,[self.entry]);dp=self.producer(64)
        self.passes((1,2),dp,failed=rescued and not early,early=early)
        self.event(8,[64,*self.epoch_flags],[ONE if rescued else ZERO]*2+[THRESHOLD])
        if rescued:
            self.event(9,self.epoch_flags);self.epoch_flags=[0,0];self.event(10,[0,0])
            qp=self.producer(128,narrow=True);self.passes((4,5),qp)
            self.event(8,[128,0,0],[ZERO,ZERO,THRESHOLD])
        code=323 if rescued else 219
        self.event(2,[code//100,code//10%10,code%10,0,0],[ZERO,ZERO])
        self.phases.append({'phase':phase,'point':1 if phase==0 else 20,'request':phase+1,
            'events':self.events[start_e:],'groups':self.groups[start_g:],
            'footer':[phase,self.clock,len(self.groups),len(self.events),0,0,0,0]})
        return self
    def text(self):
        rows=[]
        def array(prefix,seq,tag,data):
            rows.append(' '.join(map(str,[prefix,seq,tag,len(data),*data])))
        for p in self.phases:
            rows.append(f"CHECK_BEGIN {p['phase']} {p['point']} {p['request']}")
            for e in p['events']:
                rows.append(' '.join(map(str,['CHECK_EVENT',e['seq'],e['kind'],e['phase'],e['entry'],e['pass_id'],
                                              len(e['ints']),len(e['words'])])))
                array('CHECK_META',e['seq'],'EVENT',e['ints']);array('CHECK_WORDS',e['seq'],'EVENT',e['words'])
            for g in p['groups']:
                rows.append(' '.join(map(str,['CHECK_GROUP',*[g[k] for k in M.FIELDS]])))
                for tag in ('TIMES','STAGE'):
                    array('CHECK_META',g['seq'],tag,g['meta'][tag])
                for tag in M.WORD_TAGS:
                    array('CHECK_WORDS',g['seq'],tag,g['words'][tag])
                for tag in ('PSEEN','PFLAGS','ROUTE','WE','PAIRING','CLASS','HAVE','PAIR','USE','CHORD','QERROR'):
                    array('CHECK_META',g['seq'],tag,g['meta'][tag])
                er=g['error'];rows.append(f"CHECK_ERROR {g['seq']} {er['length']} {er['ambiguous']} {er['hex']}")
            rows.append('CHECK_END '+' '.join(map(str,p['footer'])))
        return '\n'.join(rows)+'\n'


class CheckedTests(unittest.TestCase):
    def fixture(self,rescued=True,early=False):
        f=Fixture().phase_packet(0).phase_packet(1,rescued=rescued,early=early)
        t=M.parse_trace(f.text(),ROUTES)
        return f,t
    def qualify(self,t,phase=1,code=323,geometry=geometry_test_double):
        return M.qualify_phase(t,phase,outer(code),geometry_validator=geometry)
    def test_handled_dp_failure_then_qp_success(self):
        f,t=self.fixture();q=self.qualify(t)
        self.assertTrue(q['rescue_exercised']);self.assertEqual(q['native_calls'],104)
        self.assertEqual(q['accepted_modes'],[4,5]);self.assertEqual(q['handled_failures'][0]['status'],1)
        self.assertEqual(M.qualify_phase(t,0,outer(219),geometry_validator=geometry_test_double)['passes'],2)
        self.assertEqual(len(t['groups']),156)
    def test_dp_success_retains_unexercised_rescue(self):
        _,t=self.fixture(rescued=False);q=self.qualify(t,code=219)
        self.assertFalse(q['rescue_exercised']);self.assertEqual(q['accepted_modes'],[1,2])
    def test_explicit_pre_native_failure_is_handled(self):
        _,t=self.fixture(early=True);q=self.qualify(t)
        self.assertEqual(q['native_calls'],103);self.assertEqual(q['handled_failures'][0]['status'],-999)
        self.assertEqual(q['handled_failures'][0]['stage'],[4,0])
    def test_bootstrap_only_framing(self):
        f=Fixture().phase_packet(0);t=M.parse_trace(f.text(),ROUTES,complete_phases=(0,))
        self.assertTrue(self.qualify(t,phase=0,code=219)['passed'])
        with self.assertRaises(ValueError):M.parse_trace(f.text(),ROUTES)
    def test_geometry_mandatory_and_boolean_not_proof(self):
        _,t=self.fixture()
        for callback in (None,lambda g,p:True,lambda g,p:{'passed':False}):
            with self.assertRaises(ValueError):self.qualify(t,geometry=callback)
    def test_final_failed_group_blocks_output_arithmetic(self):
        _,t=self.fixture();g=t['phases'][1]['groups'][-1];g['status']=1;g['stable']=0;g['fpe_qp']=1
        with self.assertRaises(ValueError):self.qualify(t)
    def test_misleading_final_flags_cannot_erase_dp_history(self):
        _,t=self.fixture();next(e for e in t['phases'][1]['events'] if e['kind']==9)['ints']=[0,0]
        with self.assertRaises(ValueError):self.qualify(t)
    def test_wrong_check_store_and_cache(self):
        for index,value in ((1,0),(2,1),(3,0),(4,1)):
            _,t=self.fixture();e=next(e for e in t['phases'][1]['events'] if e['kind']==11 and
                                      next(g for g in t['groups'] if g['seq']==e['ints'][0])['mode']==5)
            e['ints'][index]=value
            with self.assertRaises(ValueError):self.qualify(t)
    def test_genuine_producer_and_invalid_controls(self):
        for mutation in ('wide','environment','leaves'):
            _,t=self.fixture();e=next(e for e in t['phases'][1]['events'] if e['kind']==6 and e['ints'][0]==128)
            if mutation=='wide':e['ints'][2]=0
            elif mutation=='environment':e['words'][0]=ZERO
            else:e['words'][1]=ONE
            with self.assertRaises(ValueError):self.qualify(t)
    def test_stale_dp_after_narrowing(self):
        _,t=self.fixture();g=next(g for g in t['phases'][1]['groups'] if g['mode']==4)
        g['generation']=g['generation']-1
        with self.assertRaises(ValueError):self.qualify(t)
    def test_missing_reset_or_direction_group(self):
        _,t=self.fixture();next(e for e in t['phases'][1]['events'] if e['kind']==10)['ints']=[1,0]
        with self.assertRaises(ValueError):self.qualify(t)
        _,t=self.fixture();t['phases'][1]['groups'].pop()
        with self.assertRaises(ValueError):self.qualify(t)
    def test_unknown_wrapper_return_and_final_nonfinite_gate_first(self):
        _,t=self.fixture()
        for code in (110,120,130,343,420,219):
            with self.assertRaises(ValueError):self.qualify(t,code=code)
        called=[];out=outer(323);out['output_words'][1]='7FF0000000000000'
        with self.assertRaises(ValueError):
            M.qualify_phase(t,1,out,geometry_validator=lambda g,p:called.append(g))
        self.assertEqual(called,[])
    def test_nonfinite_inputs_dp_upper_bits_and_error_ambiguity(self):
        for mutation in ('nan','upper','mutation','ambiguous'):
            _,t=self.fixture();g=t['phases'][1]['groups'][0]
            if mutation=='nan':g['words']['SHIFT'][0]='0'*16+'7FF8000000000001'
            elif mutation=='upper':g['words']['SHIFT'][0]='0000000000000001'+'0'*16
            elif mutation=='mutation':g['unchanged']=0
            else:g['error']['ambiguous']=1
            with self.assertRaises(ValueError):self.qualify(t)
    def test_overflow_and_truncation_rejected(self):
        f,t=self.fixture();t['phases'][1]['failed']=1;t['phases'][1]['omitted']=1
        with self.assertRaises(ValueError):self.qualify(t)
        for text in (f.text().rsplit('CHECK_END',1)[0],f.text()+'EXTRA\n'):
            with self.assertRaises(ValueError):M.parse_trace(text,ROUTES)
    def test_pair_witness_complete_and_native_consistent(self):
        for mutation in ('seen','use'):
            _,t=self.fixture();g=t['phases'][1]['groups'][0]
            if mutation=='seen':g['meta']['PSEEN'][0]=0
            else:g['pairs'][0]['use']=1
            with self.assertRaises(ValueError):self.qualify(t)
    def test_flags_cannot_clear_between_directions(self):
        _,t=self.fixture()
        for g in t['phases'][1]['groups']:
            if g['mode']==2:g['fpe_dp']=0
        with self.assertRaises(ValueError):self.qualify(t)
    def test_host_aggregate_failure_after_successful_groups_can_be_rescued(self):
        f,_=self.fixture()
        for g in f.phases[1]['groups']:
            if g['mode']==1:
                g['status']=0;g['stable']=1;g['fpe_dp']=0
                g['error']={'length':0,'ambiguous':0,'hex':''}
        first_end=next(e for e in f.phases[1]['events'] if e['kind']==4)
        first_end['ints']=[1,0]+[1]*26
        t=M.parse_trace(f.text(),ROUTES)
        q=self.qualify(t)
        self.assertTrue(q['rescue_exercised']);self.assertEqual(q['handled_failures'],[])
        self.assertEqual(q['decisions'][0]['flags'],[1,0])
    def test_inactive_precision_flag_is_not_hidden_by_rescue(self):
        _,t=self.fixture();t['phases'][1]['groups'][0]['fpe_qp']=1
        with self.assertRaises(ValueError):self.qualify(t)
    def test_qp_producer_cannot_precede_failed_dp_decision(self):
        f,_=self.fixture();events=f.phases[1]['events']
        begin=next(e for e in events if e['kind']==5 and e['ints'][0]==128)
        decision=next(e for e in events if e['kind']==8 and e['ints'][0]==64)
        start=decision['seq'];old=begin['seq']
        for e in events:
            if start<=e['seq']<old:e['seq']+=1
        begin['seq']=start;events.sort(key=lambda e:e['seq'])
        t=M.parse_trace(f.text(),ROUTES)
        with self.assertRaises(ValueError):self.qualify(t)
    def test_unknown_early_stage_is_retained_but_never_qualified(self):
        f,_=self.fixture(early=True)
        next(g for g in f.phases[1]['groups'] if g['early'])['meta']['STAGE']=[-1,-999]
        t=M.parse_trace(f.text(),ROUTES)
        with self.assertRaises(ValueError):self.qualify(t)
    def test_unbounded_footer_count_rejected_without_allocation(self):
        f,_=self.fixture();f.phases[1]['footer'][1]=10**18
        with self.assertRaises(ValueError):M.parse_trace(f.text(),ROUTES)
    def test_wire_duplicate_serial_and_error_size_rejected(self):
        f,_=self.fixture();f.phases[1]['groups'][0]['times'][2]=f.phases[1]['groups'][0]['times'][1]
        with self.assertRaises(ValueError):M.parse_trace(f.text(),ROUTES)
        f,_=self.fixture();f.phases[1]['groups'][0]['error']['length']=1
        with self.assertRaises(ValueError):M.parse_trace(f.text(),ROUTES)
    def test_trace_maximum_encoded_size_is_bounded(self):
        # Pessimistic counts and full32-bit signed integer widths, including all
        # pair witnesses,8192 error bytes pergroup and maximum event payloads.
        group_upper=2000+22*12+201*33+230*12+8192*2
        event_upper=300+40*12+40*33
        self.assertLess(2*200+416*group_upper+1024*event_upper,M.MAX_BYTES)
    def test_source_observation_only_and_capacities(self):
        src=(HERE/'checked_trace.f90').read_text()
        code='\n'.join(line.split('!')[0] for line in src.splitlines()).lower()
        self.assertNotRegex(code,r'\b(?:stop|error\s+stop)\b')
        self.assertNotRegex(code,r'\braw\s*\(')
        self.assertIn('max_groups=416,max_events=1024,max_error=8192',src)
        self.assertLessEqual(max(map(len,src.splitlines())),132)
        before_flush=code.split('subroutine pc_checked_flush()',1)[0]
        # The formatting helpers are only called by flush; arithmetic routines do no I/O.
        before_helpers=before_flush.split('subroutine words(',1)[0]
        self.assertNotRegex(before_helpers,r'\b(?:write|print|open|flush)\s*\(')
    def test_integer_finite_classification_and_exact_threshold(self):
        self.assertTrue(M.finite_word(ZERO,64));self.assertTrue(M.finite_word('8000'+'0'*28,128))
        self.assertFalse(M.finite_word('7FFF'+'0'*28,128));self.assertFalse(M.finite_word('0'*16+'FFF0000000000000',64))
        self.assertEqual(M.exact_word(ONE),1)


if __name__=='__main__':
    unittest.main()
