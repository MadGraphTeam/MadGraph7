import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import run


class RealDependencyBoundary(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        verifier=run.load('checked_test_frozen_verifier',run.HERE/'verify.py')
        verifier.authenticate(run.OLD/'index.json',run.OLD_SHA)
        cls.parent = run.load('matched_test_parent', run.OLD / 'run.py')
        p = cls.parent
        p.R, p.G, p.B, p.PLAN, p.TOOLCHAIN, _ = p.verify_source(run.OLD_SHA)
        p.BASE, p.WORK, p.RESULTS = run.BASE, run.WORK, run.RESULTS

    def setUp(self):
        self.saved = run.P
        run.P = self.parent

    def tearDown(self):
        run.P = self.saved

    def test_actual_file_backed_dependency_adapter(self):
        result = run.dependency_preflight('build')
        self.assertEqual(result, {'native_actions': 0, 'files': 150, 'private_records': 3})
        for name, value in run.P.B['external_private_files'].items():
            self.assertEqual(run.P.R.PREREQUISITES.DATA['external'][name],
                             {'size': value['bytes'], 'sha256': value['sha256']})

    def test_actual_donor_preflight_without_owned_helpers(self):
        verifier = run.load('matched_donor_file_verifier', run.HERE / 'verify.py')
        with patch.object(run, 'V', verifier), patch.object(run.P.R, 'L', None):
            receipt = run.donor_preflight()
        self.assertEqual(receipt['objects'], 211)
        self.assertEqual(receipt['modules'], 10)
        self.assertEqual(receipt['providers'], 15)
        self.assertEqual(receipt['native_actions'], 0)

    def test_run_namespace_reaches_fake_retained_capture(self):
        L = run.setup_owned('run')
        seen = []
        L.command = lambda *args, **kwargs: seen.append((args, kwargs)) or 'fake-output'
        self.assertEqual(L.capture(['non-executed-literal-query'], run.ROOT), 'fake-output')
        self.assertEqual(len(seen), 1)
        self.assertEqual(L.STAGES, ('build', 'run'))
        self.assertEqual(L.CPU, 12)


class Controller(unittest.TestCase):
    def test_empty_or_malformed_source_hash_fails_before_helpers(self):
        for value in ('', None, '0'*63, 'g'*64, 'A'*64):
            with patch.object(run, 'load', side_effect=AssertionError('Helper import before admission')):
                with self.assertRaisesRegex(ValueError, '64-hex'):
                    run.verify_source(value)

    def test_make_job_mapping_is_explicit(self):
        calls = []
        fake = SimpleNamespace(STAGES=(), CURRENT_STAGE=None, CPU=None,
            command=lambda *a, **kw: calls.append((a, kw)) or 'done')
        parent = SimpleNamespace(setup_owned=lambda stage: fake, R=SimpleNamespace())
        with patch.object(run, 'P', parent), patch.object(run, 'ACTUAL_MAKE_TRANSFORMS', []):
            L = run.setup_owned('build')
            L.command(['make', '-j2', 'pc-objects'], 'test', run.ROOT, 30)
            self.assertEqual(calls[0][0][0], ['make', '-j1', 'pc-objects'])
            self.assertEqual(run.ACTUAL_MAKE_TRANSFORMS[0]['actual_argv'], ['make', '-j1', 'pc-objects'])

    def test_closed_build_requires_explicit_hash(self):
        with self.assertRaisesRegex(ValueError, 'Explicit closed-build'):
            run.reviewed_build(None)

    def test_closed_build_bad_hash_fails_before_native_or_receipt_parse(self):
        with patch.object(run, 'V', SimpleNamespace(pin=lambda p: {'sha256': 'actual'})):
            with self.assertRaisesRegex(ValueError, 'Build closure differs'):
                run.reviewed_build('unreviewed')

    def test_saved_outputs_are_append_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'record.json'
            run.save(path, {'first': True})
            with self.assertRaises(FileExistsError):
                run.save(path, {'replacement': True})
            self.assertEqual(json.loads(path.read_bytes()), {'first': True})

    def test_reference_plan_is_exact_and_no_point21(self):
        plan = run.read(run.HERE / 'validation-plan.json')
        self.assertEqual([x['backend'] for x in plan['requests']], [9])
        self.assertEqual(len(plan['requests']), 1)
        self.assertEqual(plan['build']['seconds_total'], 420)
        self.assertEqual(plan['run']['seconds_total'], 960)
        self.assertEqual(plan['run']['actual_SLOOP_retention_max'], 4)
        self.assertEqual(plan['build']['compiled_objects'], ['check_sa.o','loop_matrix.o','mp_compute_loop_coefs.o','CT_interface.o','TIR_interface.o','TIRUST_interface.o','checked_trace.o'])
        for item in plan['requests']:
            self.assertEqual((item['point'], item['requested_mode']), (20, -1))
            self.assertEqual((item['bootstrap_calls'], item['measurement_calls']), (1, 1))
            self.assertEqual(item['bootstrap'], 'inputs/cms-point1.dat')

    def test_native_owner_derivative_and_limits(self):
        verifier = run.load('checked_controller_verifier_test', run.HERE / 'verify.py')
        self.assertEqual((run.HERE/'native_job.py').read_text(),verifier.expected_native_job())
        self.assertEqual((run.HERE/'limit_exec.py').read_bytes(),(verifier.MATCHED/'limit_exec.py').read_bytes())
        expected=(verifier.MATCHED/'worker_entry.py').read_text().replace(
            'kinematic-matched-native-input-executor-2','kinematic-normal-checked-executor-1')
        self.assertEqual((run.HERE/'worker_entry.py').read_text(),expected)

    def test_pending_scientific_seal_blocks_admission(self):
        verifier=run.load('checked_pending_verifier_test',run.HERE/'verify.py')
        with patch.object(verifier,'SCIENCE_SHA',None):
            with self.assertRaisesRegex(ValueError,'pending review'):
                verifier._scientific_preflight()

    def test_checked_request_keeps_force_cache_and_return_contract(self):
        plan=run.read(run.HERE/'validation-plan.json')
        self.assertTrue(plan['force_stability_check']);self.assertEqual(plan['cache'],0)
        self.assertEqual(plan['requests'][0]['expected_checked_returns'],[219,323])
        self.assertEqual(plan['run']['worker_seconds'],780)
        self.assertEqual(plan['run']['native_records_retention_max'],416)


if __name__ == '__main__':
    unittest.main()
