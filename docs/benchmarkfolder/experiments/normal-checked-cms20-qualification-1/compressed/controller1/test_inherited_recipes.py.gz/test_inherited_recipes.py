"""Pure replay of the inherited numerical recipe audit, never a make run.

The captured fixture belongs to the earlier matched build. It validates the
retained numerical/support recipes; the new checked recorder expansion remains
subject to the actual all-source audit at a separately admitted build.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unittest
import run

OLD=run.ROOT/'.tirust-build/kinematic-matched-native-input-controller-2'
SHA='9076a51a0be56c57fb7dda32cfec3ef9b038bec2e73dc5e751bf31dc5ac3bc41'


def authenticated_module():
 raw=(OLD/'index.json').read_bytes()
 if hashlib.sha256(raw).hexdigest()!=SHA: raise ValueError('Recipe fixture source seal differs')
 index=json.loads(raw)
 for name,item in index['files'].items():
  content=(OLD/name).read_bytes()
  if {'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}!=item:
   raise ValueError('Recipe fixture source payload differs')
 spec=importlib.util.spec_from_file_location('closed_checked_recipe_tests',OLD/'test_inherited_recipes.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module


Fixture=authenticated_module()


class InheritedRecipes(Fixture.InheritedRecipes):
 @classmethod
 def setUpClass(cls):
  super().setUpClass()
  cls.successor=run

 def test_successor_exact_restoration_passes_actual_capture_and_policy(self):
  overlay=self.successor.make_addition(self.old_overlay)
  result,seen,versions=self.capture(self.augmented(overlay))
  self.helper.validate_compiler_equality(self.flags,result)
  self.assertEqual({name:len(value['recipes']) for name,value in result['scopes'].items()},
                   {'process':25,'MODEL':14,'DHELAS':175})
  self.assertEqual(seen,['process','MODEL','DHELAS']);self.assertEqual(len(versions),1)
  self.assertEqual(re.findall(r'^pc-objects: (.*)$',overlay,re.MULTILINE),[
   'check_sa.o loop_matrix.o mp_compute_loop_coefs.o CT_interface.o TIR_interface.o TIRUST_interface.o checked_trace.o'])
  self.assertEqual(Fixture.recipe_block(overlay,'environment_token.c'),
                   Fixture.recipe_block(self.old_overlay,'environment_token.c'))
  self.assertIn('checked_trace.o: checked_trace.f90 amplitude_support.o\n\t$(FC) $(FFLAGS)',overlay)
  self.assertIn('check_sa.o loop_matrix.o mp_compute_loop_coefs.o CT_interface.o TIR_interface.o TIRUST_interface.o: checked_trace.o',overlay)


if __name__=='__main__': unittest.main(verbosity=2)
