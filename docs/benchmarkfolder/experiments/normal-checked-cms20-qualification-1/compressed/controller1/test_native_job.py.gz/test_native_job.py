"""Mock worker protocol tests: no child, executable, compiler or library runs."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def pin(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def require(ok,message):
 if not ok: raise ValueError(message)


class BootstrapBoundary(unittest.TestCase):
 def exercise(self,gate):
  with tempfile.TemporaryDirectory() as tmp:
   base=Path(tmp);cwd=base/'worker/SubProcesses/P0_epem_mupmum';cwd.mkdir(parents=True)
   evidence=base/'evidence';evidence.mkdir();cards=cwd.parents[1]/'Cards';cards.mkdir()
   for path in (cwd/'check',cwd/'bootstrap.dat',cwd/'measurement.dat',cards/'param_card.dat',cards/'MadLoopParams.dat'):
    path.write_bytes(b'SYNTHETIC, NEVER EXECUTED\n')
   plan=json.loads((HERE/'validation-plan.json').read_bytes());request=plan['requests'][0]
   spec={'request':request,'cwd':str(cwd),'evidence':str(evidence),'source_index_sha256':'a'*64,
    'executable':str(cwd/'check'),'executable_pin':pin(cwd/'check'),
    'bootstrap_file':str(cwd/'bootstrap.dat'),'bootstrap_pin':pin(cwd/'bootstrap.dat'),
    'point_file':str(cwd/'measurement.dat'),'point_pin':pin(cwd/'measurement.dat'),
    'physical_card':pin(cards/'param_card.dat'),'numerical_card':pin(cards/'MadLoopParams.dat'),
    'expected_runtime':{'synthetic-ELF-never-loaded':'b'*64}}
   specpath=evidence/'specification.json';specpath.write_text(json.dumps(spec))
   calls=[];saved=[];closes=[];timeouts=[]
   def save(path,data):
    path=Path(path);saved.append((path.name,data));path.write_text(json.dumps(data))
   def verify_record(path,expected): require(pin(path)==expected,'Synthetic input changed')
   comparator=types.SimpleNamespace(bootstrap_gate=lambda *args,**kwargs:gate() if callable(gate) else gate)
   def load(name,path):
    require(name=='normal_checked_bootstrap_comparator','Unexpected helper load')
    require(Path(path).name=='compare.py','Unexpected comparator path')
    return comparator
   # Only replace the import with explicit mocked boundary functions. The
   # complete owned execute/control/collection body below remains unchanged.
   raw=(HERE/'native_job.py').read_text()
   anchor='from admission import HERE, ROOT, helpers, load, read_json, require, save, sealed, sha, verify_record'
   require(raw.count(anchor)==1,'Owned source import differs')
   module=types.ModuleType('mocked_checked_native_owner');module.__file__=str(HERE/'native_job.py')
   module.__dict__.update(HERE=HERE,ROOT=ROOT,helpers=lambda:None,load=load,
    read_json=lambda p:json.loads(Path(p).read_bytes()),require=require,save=save,
    sealed=lambda *args:None,sha=lambda raw:hashlib.sha256(raw).hexdigest(),verify_record=verify_record)
   exec(compile(raw.replace(anchor,'# Explicit test-only boundary injection',1),module.__file__,'exec'),module.__dict__)
   for name in module.OUTPUTS:(cwd/name).write_bytes(b'SYNTHETIC OUTPUT, NEVER DECODED\n')
   class FakeWorker:
    def __init__(self,argv,directory,log,env=None,timeout=None):
     # No subprocess. The current Python pid is only a /proc/maps read source;
     # mapped_files is replaced below and close never sends any signal.
     self.process=types.SimpleNamespace(pid=os.getpid(),returncode=None);self.closed=False
     self.timeout=timeout;timeouts.append(timeout);Path(log).write_bytes(b'')
     require(argv[-3:]==['-1','20','9'],'Driver argument scope differs')
     self.queue=[['READY','1','1','1','1','1','1.0E-1']];self._message()
    def _message(self): return self.queue.pop(0)
    def run(self,loops):
     calls.append(loops);timeouts.append(self.timeout)
     self.queue.append(['DONE','1','1']);self._message()
    def close(self,graceful=True):
     closes.append(graceful);self.queue.append(['BYE']);self._message()
     self.closed=True;self.process.returncode=0
   fake=types.ModuleType('tirust_benchmark_worker');fake.Worker=FakeWorker
   # This intentionally tests only gate sequencing and retained owner evidence,
   # not actual ELF-map verification (inherited unchanged from the reviewed owner).
   module.mapped_files=lambda raw,expected:{'elf':expected,'data':{}}
   old_path=sys.path[:];failure=None
   try:
    with patch.dict(sys.modules,{'tirust_benchmark_worker':fake}):
     try:module.execute(specpath)
     except ValueError as exc:failure=str(exc)
   finally:sys.path[:]=old_path
   result=json.loads((evidence/'result.json').read_bytes())
   return result,calls,closes,timeouts,saved,failure

 def test_failed_bootstrap_is_retained_and_never_requests_measurement(self):
  result,calls,closes,timeouts,saved,failure=self.exercise({'passed':False,'reason':'synthetic bad group'})
  self.assertEqual(calls,[]);self.assertEqual(closes,[True]);self.assertEqual(timeouts,[180])
  self.assertFalse(result['measurement_command_attempted']);self.assertFalse(result['measurement_completed'])
  self.assertFalse(result['bootstrap_gate_passed']);self.assertFalse(result['orchestration_complete'])
  self.assertEqual([x[0] for x in result['protocol']],['READY','BYE'])
  self.assertIn('Owned native request incomplete',failure)
  self.assertEqual([name for name,_ in saved],['bootstrap-gate.json','result.json'])
  self.assertEqual(len(result['outputs']),9)

 def test_passed_bootstrap_requests_exactly_one_measurement_at_600_seconds(self):
  result,calls,closes,timeouts,saved,failure=self.exercise({'passed':True})
  self.assertEqual(calls,[1]);self.assertEqual(closes,[True]);self.assertEqual(timeouts,[180,600])
  self.assertTrue(result['measurement_command_attempted']);self.assertTrue(result['measurement_completed'])
  self.assertTrue(result['bootstrap_gate_passed']);self.assertTrue(result['orchestration_complete'])
  self.assertEqual([x[0] for x in result['protocol']],['READY','DONE','BYE']);self.assertIsNone(failure)
  self.assertEqual([x['boundary'] for x in result['runtime_maps']],['READY','DONE'])
  self.assertFalse(result['numerically_qualified'])

 def test_bootstrap_parser_exception_does_not_send_RUN_or_retry(self):
  def bad():raise ValueError('synthetic malformed checked trace')
  result,calls,closes,timeouts,saved,failure=self.exercise(bad)
  self.assertEqual(calls,[]);self.assertEqual(closes,[True])
  self.assertIn('synthetic malformed checked trace',result['failure']['message'])
  self.assertFalse(result['bootstrap_gate_passed']);self.assertEqual([name for name,_ in saved],['result.json'])


if __name__=='__main__':unittest.main(verbosity=2)
