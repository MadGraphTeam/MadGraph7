#!/usr/bin/env python3
"""Bounded private normal-checked9 build/run gates. Default is file-only."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / '.tirust-build/kinematic-normal-checked-executor-1'
SOURCE = ROOT / '.tirust-build/kinematic-normal-checked-source-1'
SCIENCE_SHA = '7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9'  # Reviewed immutable scientific source.
WORK, RESULTS = BASE / 'work', BASE / 'results'
OLD = ROOT / '.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA = 'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
P = H = V = PLAN = None
ACTUAL_MAKE_TRANSFORMS = []


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def verify_source(expected):
    global P, H, V, PLAN
    require(type(expected) is str and len(expected) == 64 and
            all(c in "0123456789abcdef" for c in expected),
            "Explicit 64-hex reviewed source index required")
    if V is None:
        V = load('reference_verify', HERE / 'verify.py')
    verified = V.verify(expected)
    if P is None:
        P = load('reference_retained_controller', OLD / 'run.py')
        H = load('reference_retained_build', OLD / 'build_stage.py')
        P.R, P.G, P.B, P.PLAN, P.TOOLCHAIN, protected = P.verify_source(OLD_SHA)
        P.BASE, P.WORK, P.RESULTS = BASE, WORK, RESULTS
    else:
        *_, protected = P.verify_source(OLD_SHA)
    PLAN = read(HERE / 'validation-plan.json')
    require([x['backend'] for x in PLAN['requests']] == [9], 'Checked backend scope differs')
    require(all(x['requested_mode'] == -1 and x['point'] == 20 and
                x['bootstrap_calls'] == x['measurement_calls'] == 1 and
                x['outer_entries_max'] == 2 for x in PLAN['requests']), 'Reference scope differs')
    return {'upstream': protected, 'source_index': V.pin(HERE / 'index.json'),
            'bindings': V.pin(HERE / 'bindings.json'), 'verified': verified,
            'scientific_source_index': V.pin(SOURCE / 'index.json'),
            'candidate_donor_current': donor_preflight()}


def setup_owned(stage):
    L = P.setup_owned(stage)
    L.STAGES = ('build', 'run')
    L.CURRENT_STAGE = stage
    L.CPU = 12
    original = L.command

    def command(args, label, cwd=ROOT, timeout=600, cpu=True):
        args = [str(x) for x in args]
        if args and args[0] == 'make':
            changed = ['-j1' if x == '-j2' else x for x in args]
            if changed != args:
                ACTUAL_MAKE_TRANSFORMS.append({'label': label, 'inherited_request': args,
                                               'actual_argv': changed})
            args = changed
        return original(args, label, cwd, timeout, cpu)

    L.command = command
    P.R.PC_SAVE = save
    return L


def dependency_preflight(stage):
    L = setup_owned(stage)

    def forbidden(*args, **kwargs):
        raise ValueError('Native action forbidden in file-only dependency preflight')

    L.command = forbidden
    L.runtime = forbidden
    snapshot = P.R.dependency_snapshot()
    expected = P.B['external_private_files']
    require(all(snapshot.get(name) == value for name, value in expected.items()),
            'Inherited size/bytes dependency adapter differs')
    return {'native_actions': 0, 'files': len(snapshot), 'private_records': len(expected)}


def donor():
    binding = read(HERE / 'bindings.json')['files']['candidate_build']
    V.checked(ROOT / binding['path'], binding)
    item = read(ROOT / binding['path'])
    P.R.exact_inventory(Path(item['output']), item['sources'])
    for path, checksum in {**item['prelink_bound'], **item['runtime']['files']}.items():
        require(V.pin(path)['sha256'] == checksum, 'Closed candidate input changed: ' + path)
    V.checked(item['executable'], item['executable_pin'])
    for name, value in item['all_objects_after'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['reused_libraries'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['modules_after'].items():
        V.checked(Path(item['output']) / name, value)
    return item


def donor_preflight():
    item = donor()
    require(len(item['all_objects_after']) == 211 and len(item['modules_after']) == 10 and
            len(item['reused_libraries']) == 4 and len(item['runtime']['files']) == 15 and
            len(item['prelink_bound']) == 151, 'Closed candidate donor shape differs')
    module = 'SubProcesses/P0_epem_mupmum/ml_private_amplitude_support.mod'
    require(module in item['modules_after'], 'Existing amplitude support module missing')
    return {'current_files_verified': True, 'objects': 211, 'modules': 10,
            'libraries': 4, 'providers': 15, 'prelink_inputs': 151,
            'receipt': V.pin(ROOT / read(HERE / 'bindings.json')['files']['candidate_build']['path']),
            'executable': item['executable_pin'], 'native_actions': 0}


def literal_cards(output, request):
    for name, key in [('param_card.dat', 'physical_card'), ('MadLoopParams.dat', 'card')]:
        paths = {output / 'Cards' / name, *((output / 'SubProcesses').rglob(name))}
        for path in paths:
            H.write_private(output, path, (HERE / request[key]).read_bytes())


def objects_preserved(before, after):
    added = 'SubProcesses/P0_epem_mupmum/checked_trace.o'
    require(set(after) == set(before) | {added}, 'Unexpected new/missing process object')
    require(len(before) == 211 and len(after) == 212, 'Closed donor object count differs')


def modules_preserved(before, after):
    added = 'SubProcesses/P0_epem_mupmum/ml_private_checked_trace.mod'
    require(len(before) == 10 and len(after) == 11, 'Closed donor module count differs')
    require(set(after) == set(before) | {added}, 'Unexpected new/missing Fortran module')
    for name, value in before.items():
        require(after[name] == value, 'Reused Fortran module changed: ' + name)


def make_addition(original_overlay):
    # The inherited flag audit needs recipes for EVERY present Fortran source,
    # even when the real build freezes and reuses those objects. Preserve them.
    old_targets = ('pc-objects: CT_interface.o TIRUST_interface.o TIR_interface.o '
                   'loop_matrix.o loop_CT_calls_1.o mp_compute_loop_coefs.o '
                   'certificate.o caller_bounds.o amplitude_support.o environment_token.o')
    new_targets = ('pc-objects: check_sa.o loop_matrix.o mp_compute_loop_coefs.o '
                   'CT_interface.o TIR_interface.o TIRUST_interface.o checked_trace.o')
    require(original_overlay.count(old_targets) == 1, 'Original support aggregate differs')
    return original_overlay.replace(old_targets, new_targets, 1) + """
# One extra recorder object; the original support recipes above remain exact.
PROCESS += checked_trace.o
check: checked_trace.o
checked_trace.o: checked_trace.f90 amplitude_support.o
	$(FC) $(FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)
check_sa.o loop_matrix.o mp_compute_loop_coefs.o CT_interface.o TIR_interface.o TIRUST_interface.o: checked_trace.o
"""


def build():
    original = donor()
    output = WORK / 'builds' / 'cms' / 'checked'
    require(not output.parent.exists(), 'Fresh build required; no retry')
    output.parent.mkdir(parents=True)
    dependencies = P.R.dependency_snapshot()
    H.clone(P.R, Path(original['output']), output)
    directory = output / 'SubProcesses' / H.SUBPROCESS
    literal_cards(output, PLAN['requests'][0])
    H.write_private(output, directory / 'check_sa.f', (SOURCE / 'driver-checked.f').read_bytes())
    for name in ('CT_interface.f', 'TIRUST_interface.f', 'TIR_interface.f',
                 'loop_matrix.f', 'mp_compute_loop_coefs.f'):
        H.write_private(output, directory / name, (SOURCE / 'candidate' / name).read_bytes())
    H.write_private(output, directory / 'checked_trace.f90', (SOURCE / 'checked_trace.f90').read_bytes())
    require(not (directory / 'checked_trace.o').exists() and
            not (directory / 'ml_private_checked_trace.mod').exists(), 'New recorder object/module already exists')
    make = (Path(original['output']) / 'SubProcesses' / H.SUBPROCESS / 'makefile').read_bytes()
    overlay = H.make_addition(True).encode()
    require(make.endswith(overlay) and make.count(overlay) == 1, 'Closed candidate make overlay differs')
    make = make[:-len(overlay)] + make_addition(overlay.decode()).encode()
    H.write_private(output, directory / 'makefile', make)
    stages_path = ROOT / P.B['current_stages']['path']
    V.checked(stages_path, P.B['current_stages'])
    stages = P.R.load('reference_retained_stages', stages_path)
    targets = tuple(PLAN['build']['compiled_objects'])
    receipt = H.link_one(P.R, stages, output, 'checked', original, targets)
    H.preserved_objects(original['all_objects_after'], receipt['all_objects_after'],
                        set(targets))
    objects_preserved(original['all_objects_after'], receipt['all_objects_after'])
    modules_preserved(original['modules_after'], receipt['modules_after'])
    require(P.QUERIES == ['checked'], 'Build requires exactly one loader query')
    require(dependencies == P.R.dependency_snapshot(), 'Dependencies changed during build')
    save(RESULTS / 'build-summary.json', {
        'executables': 1, 'compiled_objects': list(targets),
        'checked_build': V.pin(RESULTS / 'builds/checked/build.json'),
        'executable': receipt['executable'], 'executable_pin': receipt['executable_pin'],
        'inherited_make_job_requests_and_actual_transform': ACTUAL_MAKE_TRANSFORMS,
        'actual_make_jobs': 1, 'native_main_calls': 0, 'tensor_calls': 0,
        'scientific_library_rebuilds': False, 'private8_geometry_policy_changed': False, 'checked_trace_only': True,
        'scientific_source_index_sha256': SCIENCE_SHA, 'existing_modules_preserved': True})


def reviewed_build(expected):
    require(expected, 'Explicit closed-build review required')
    require(V.pin(RESULTS / 'build-closure.json')['sha256'] == expected, 'Build closure differs')
    closure = read(RESULTS / 'build-closure.json')
    require(closure['passed'] and closure['source_index_sha256'] == V.pin(HERE / 'index.json')['sha256'],
            'Closed build failed or belongs to another source')
    for name, value in closure['payloads'].items():
        V.checked(RESULTS / name, value)
    item = read(RESULTS / 'builds/checked/build.json')
    V.checked(item['executable'], item['executable_pin'])
    P.R.exact_inventory(Path(item['output']), item['sources'])
    for path, checksum in {**item['prelink_bound'], **item['runtime']['files']}.items():
        require(V.pin(path)['sha256'] == checksum, 'Closed candidate input changed: ' + path)
    for name, value in item['all_objects_after'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['reused_libraries'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['modules_after'].items():
        V.checked(Path(item['output']) / name, value)
    return item


def run_checked(build_sha, source_sha):
    item = reviewed_build(build_sha)
    completed, failure = [], None
    try:
        for request in PLAN['requests']:
            P.R.L.remaining(780)
            P.R.L.q.verify_hashes(item['prelink_bound'])
            output = H.clone(P.R, Path(item['output']), WORK / 'workers' / request['id'])
            literal_cards(output, request)
            directory = output / 'SubProcesses' / H.SUBPROCESS
            evidence = RESULTS / 'runs' / request['id']
            evidence.mkdir(parents=True, exist_ok=False)
            V.checked(directory / 'check', item['executable_pin'])
            runtime = P.runtime(directory / 'check', item['prelink_bound'], request['id'], item['runtime'])
            expected = {**runtime['files'], str((directory / 'check').resolve()): item['executable_pin']['sha256']}
            for key in ('bootstrap', 'measurement'):
                shutil.copyfile(HERE / request[key], directory / (key + '-input.dat'))
            specification = {'request': request, 'cwd': str(directory), 'expected_runtime': expected,
                'bootstrap_file': str(directory / 'bootstrap-input.dat'),
                'point_file': str(directory / 'measurement-input.dat'),
                'bootstrap_pin': V.pin(directory / 'bootstrap-input.dat'),
                'point_pin': V.pin(directory / 'measurement-input.dat'),
                'executable': str(directory / 'check'), 'executable_pin': item['executable_pin'],
                'evidence': str(evidence), 'source_index_sha256': source_sha,
                'scientific_source_index_sha256': SCIENCE_SHA,
                'build_receipt_sha256': V.pin(RESULTS / 'builds/checked/build.json')['sha256'],
                'numerical_card': V.pin(output / 'Cards/MadLoopParams.dat'),
                'physical_card': V.pin(output / 'Cards/param_card.dat')}
            specpath = evidence / 'specification.json'
            save(specpath, specification)
            P.R.command([sys.executable, '-B', HERE / 'worker_entry.py', specpath,
                         V.pin(specpath)['sha256'], source_sha], 'worker-' + request['id'], directory, 780)
            require(read(evidence / 'result.json')['orchestration_complete'], 'Incomplete worker retained')
            completed.append(request['id'])
        require(P.QUERIES == [r['id'] for r in PLAN['requests']], 'Runtime query count/order differs')
        comparator = load('checked_comparator', HERE / 'compare.py')
        comparison = comparator.compare_stage(RESULTS / 'runs', PLAN['requests'],
            controller_source_sha=source_sha, build_receipt=item)
        save(RESULTS / 'checked-comparison.json', comparison)
        require(comparison['passed'], 'Checked host/geometry/amplitude gate failed; evidence retained')
    except BaseException as exc:
        failure = repr(exc)
        raise
    finally:
        save(RESULTS / 'run-requests.json', {'requests': PLAN['requests'], 'completed': completed,
            'not_completed': [x for x in PLAN['requests'] if x['id'] not in completed],
            'failure': failure, 'maximum_driver_THRES_requests': 2, 'actual_SLOOP_retention_max': 4, 'performance_measurement': False})


def payloads(stage):
    paths = {RESULTS / name for name in (f'stage-{stage}.json', f'{stage}-before.json', f'{stage}-after.json')}
    for label in P.COMMANDS:
        paths.update({RESULTS / 'execution' / (label + '.json'), RESULTS / 'execution' / (label + '.txt')})
    for label in P.QUERIES:
        paths.add(RESULTS / 'runtime' / (label + '.json'))
    if stage == 'build':
        paths.add(RESULTS / 'build-summary.json')
        folder = RESULTS / 'builds/checked'
        if folder.exists():
            paths.update(p for p in folder.rglob('*') if p.is_file())
    else:
        paths.update({RESULTS / 'checked-comparison.json', RESULTS / 'run-requests.json'})
        for request in PLAN['requests']:
            folder = RESULTS / 'runs' / request['id']
            if folder.exists():
                paths.update(p for p in folder.rglob('*') if p.is_file())
    return {str(p.relative_to(RESULTS)): V.pin(p) for p in sorted(paths) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('build', 'run'))
    parser.add_argument('--reviewed-source-index', required=True)
    parser.add_argument('--reviewed-build-sha256')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(Path.cwd() == ROOT, 'Run from repository root')
    before = verify_source(args.reviewed_source_index)
    preflight = dependency_preflight(args.stage)
    if args.stage == 'run':
        require(args.reviewed_build_sha256, 'Separate closed-build review required')
        reviewed_build(args.reviewed_build_sha256)
    if not args.execute:
        print(json.dumps({'passed': True, 'stage': args.stage, 'dependency_preflight': preflight}))
        return
    require(not (RESULTS / ('stage-' + args.stage + '.json')).exists(), 'Append-only stage; no retry')
    if args.stage == 'run':
        require(args.reviewed_build_sha256, 'Separate closed-build review required')
    save(RESULTS / (args.stage + '-before.json'), before)
    L = setup_owned(args.stage)
    started = time.monotonic()
    failure = postfailure = lock = active = None
    with L.cleanup.SignalRequests() as signals:
        L.REQUESTS = P.R.BudgetRequests(signals)
        try:
            lock = P.R.acquire(signals)
            active = time.monotonic()
            with L.Deadline(PLAN[args.stage]['seconds_total'] - 60):
                if args.stage == 'build':
                    build()
                else:
                    run_checked(args.reviewed_build_sha256, args.reviewed_source_index)
        except BaseException as exc:
            failure = exc
        finally:
            if lock is not None:
                lock.close()
            try:
                after = verify_source(args.reviewed_source_index)
                require(after == before, 'Protected inputs changed')
                save(RESULTS / (args.stage + '-after.json'), after)
            except BaseException as exc:
                postfailure = exc
            result = {'stage': args.stage, 'passed': failure is None and postfailure is None,
                'failure': None if failure is None else repr(failure),
                'postcheck_failure': None if postfailure is None else repr(postfailure),
                'source_index_sha256': args.reviewed_source_index,
                'reviewed_build_sha256': args.reviewed_build_sha256,
                'owned_command_count': len(P.COMMANDS), 'loader_query_count': len(P.QUERIES),
                'elapsed_seconds': time.monotonic() - started,
                'elapsed_after_lock': None if active is None else time.monotonic() - active,
                'performance_measurement': False, 'host_stability_qualified': False}
            save(RESULTS / ('stage-' + args.stage + '.json'), result)
            save(RESULTS / (args.stage + '-closure.json'), {**result, 'payloads': payloads(args.stage)})
    if failure is not None:
        raise failure
    if postfailure is not None:
        raise postfailure


if __name__ == '__main__':
    main()
