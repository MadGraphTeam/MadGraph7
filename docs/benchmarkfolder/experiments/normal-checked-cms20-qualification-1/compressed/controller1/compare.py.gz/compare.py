"""Pure checked lifecycle/geometry/output qualification, including READY gate.

Only exact integer output words are inspected before native, geometry, host,
software and complete-output gates. Failed contributions remain opaque. The
ordinary control is required before any measurement coefficient arithmetic.
"""
import hashlib
import json
from pathlib import Path
import re
import types

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCIENCE=ROOT/'.tirust-build/kinematic-normal-checked-source-1'
SCIENCE_SHA='7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9'  # Reviewed immutable scientific source.
OLD=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
OLD_COMPARE_SHA='ecce1e1f99f0de7d1798880cc9137251b4e553accc708f3cee357ed794b99272'
ORDINARY=ROOT/'.tirust-build/kinematic-invariant-amplitude-executor-2/results'
ORDINARY_CLOSURE_SHA='b364bd8535d0f5850cb5a21390c5678cbb1c1dd8fddfae6f0174cf50d261f7a7'
ORDINARY_COMPARE_SHA='6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451'
MATCHED=ROOT/'.tirust-build/kinematic-matched-native-input-executor-2/results'
MATCHED_CLOSURE_SHA='52faa470d8be22b81f8636edba21f5fba6c2d13be1f0241a8212a7b2055839a7'
# Exact closed report pin; kept distinct from the scientific matched-input seal.
MATCHED_COMPARE_SHA='af4b58a379ac35a78066a1bcad38ed3f4fe9e16e6b0d4583dbd4e6c940eba6d5'
OUTPUTS=('bootstrap-values.dat','driver-state.dat','driver-bits.dat','qualification.dat',
         'dimensions.dat','values.dat','timed_status.dat','timing.dat','trace.dat')
BOOT_OUTPUTS=OUTPUTS[:5]+('trace.dat',)
HEX64=re.compile('[0-9A-F]{16}\\Z')
DECIMAL=re.compile(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?\Z')
REQUEST={'id':'cms-p20-auto-lib9-checked','backend':9,'variant':'checked','stage':'run',
 'point':20,'requested_mode':-1,'expected_checked_returns':[219,323],
 'bootstrap_calls':1,'measurement_calls':1,'outer_entries_max':2,
 'card':'backend9-auto-MadLoopParams.dat','physical_card':'inputs/cms-param_card.dat',
 'bootstrap':'inputs/cms-point1.dat','measurement':'inputs/cms-point20.dat'}


def require(ok,message):
    if not ok: raise ValueError(message)


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
    raw=Path(path).read_bytes();actual=pin(raw)
    require(actual['sha256']==expected if isinstance(expected,str) else
            actual=={k:expected[k] for k in ('bytes','sha256')},'Pinned bytes changed: '+str(path))
    return raw


def module(path,raw):
    obj=types.ModuleType('checked_'+Path(path).stem);obj.__file__=str(path)
    exec(compile(raw,str(path),'exec'),obj.__dict__)
    return obj


def packet(path,sha):
    require(type(sha)is str and re.fullmatch('[0-9a-f]{64}',sha),'Reviewed source seal required')
    raw=checked(path/'index.json',sha);index=json.loads(raw);files={}
    for name,record in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source path')
        files[name]=checked(path/name,record)
    return index,files


def sources(controller_sha):
    own,ownraw=packet(HERE,controller_sha)
    verifier=module(HERE/'verify.py',ownraw['verify.py'])
    require(verifier.SCIENCE_SHA==SCIENCE_SHA,'Scientific seal declarations differ')
    preflight=verifier.verify(controller_sha)
    require(preflight['passed'] and preflight['native_admission_ready'],'Source admission incomplete')
    index,raw=packet(SCIENCE,SCIENCE_SHA)
    trace=module(SCIENCE/'checked_trace.py',raw['checked_trace.py'])
    geometry=module(SCIENCE/'checked_geometry.py',raw['checked_geometry.py'])
    poles=module(HERE/'pole_checks.py',ownraw['pole_checks.py'])
    routes={int(k):v for k,v in json.loads(raw['expected-routes.json']).items()}
    old_index,_=packet(OLD,OLD_SHA)
    require(old_index['files']['amplitude_compare.py']['sha256']==OLD_COMPARE_SHA,'Criterion source differs')
    legacy=module(OLD/'amplitude_compare.py',checked(OLD/'amplitude_compare.py',OLD_COMPARE_SHA))
    legacy.verify_sources()
    return {'trace':trace,'geometry':geometry,'poles':poles,'routes':routes,'legacy':legacy,
        'evidence':{'controller_index_sha256':controller_sha,'scientific_index_sha256':SCIENCE_SHA,
            'controller_payloads':len(ownraw),'scientific_payloads':len(raw),'preflight':preflight,
            'criterion_source_sha256':OLD_COMPARE_SHA}}


def validate_requests(requests):
    require(requests==[REQUEST],'Checked scope must be exactly the one reviewed worker')


def _build(runs_dir,provided=None):
    raw=(Path(runs_dir).parent/'builds/checked/build.json').read_bytes();build=json.loads(raw)
    require(provided is None or provided==build,'Provided build differs from retained build receipt')
    require(build['variant']=='checked' and build['scientific_source_index_sha256']==SCIENCE_SHA,
            'Build scientific source/variant differs')
    checked(build['executable'],build['executable_pin'])
    for path,sha in {**build['prelink_bound'],**build['runtime']['files']}.items():checked(path,sha)
    return build,pin(raw)


def _spec(directory,spec,controller_sha,build,build_pin):
    validate_requests([spec['request']]);directory=Path(directory)
    raw=checked(directory/'specification.json',pin(json.dumps(spec,indent=2,sort_keys=True).encode()+b'\n'))
    # The exact writer is fixed by run.py; also compare its decoded structure.
    require(json.loads(raw)==spec,'Specification bytes/record differ')
    require(spec['source_index_sha256']==controller_sha and spec['scientific_source_index_sha256']==SCIENCE_SHA,
            'Worker source seals differ')
    require(spec['build_receipt_sha256']==build_pin['sha256'],'Worker build seal differs')
    cwd=Path(spec['cwd']);require(cwd.is_absolute() and Path(spec['evidence'])==directory,'Worker paths differ')
    require(Path(spec['executable'])==cwd/'check' and spec['executable_pin']==build['executable_pin'],
            'Worker executable differs')
    checked(spec['executable'],build['executable_pin'])
    runtime={**build['runtime']['files'],str((cwd/'check').resolve()):build['executable_pin']['sha256']}
    require(spec['expected_runtime']==runtime,'Expected runtime closure differs')
    checks=[(HERE/REQUEST['card'],cwd.parents[1]/'Cards/MadLoopParams.dat','numerical_card'),
        (HERE/REQUEST['physical_card'],cwd.parents[1]/'Cards/param_card.dat','physical_card'),
        (HERE/REQUEST['bootstrap'],Path(spec['bootstrap_file']),'bootstrap_pin'),
        (HERE/REQUEST['measurement'],Path(spec['point_file']),'point_pin')]
    evidence={'specification.json':pin(raw),'build_receipt':build_pin}
    for source,path,key in checks:
        expected=pin(source.read_bytes());require(spec[key]==expected,'Worker literal input differs: '+key)
        checked(path,expected);evidence[key]=expected
    return evidence


def _protocol(protocol,maps,directory,expected,*,bootstrap=False):
    require(isinstance(protocol,list) and protocol and len(protocol[0])==7 and
            protocol[0][:6]==['READY','1','1','1','1','1'] and DECIMAL.fullmatch(protocol[0][6]),
            'READY protocol differs')
    require(len(protocol)==1 if bootstrap else protocol[1:]==[['DONE','1','1'],['BYE']],
            'Unexpected protocol/extra outer requests')
    require([x['boundary'] for x in maps]==(['READY'] if bootstrap else ['READY','DONE']),
            'Actual runtime boundary count differs')
    evidence={}
    for row in maps:
        name=row['file'];require(Path(name).name==name,'Unsafe map path')
        raw=checked(Path(directory)/name,row['sha256'])
        require(row['elf']==expected,'Actual mapped ELF closure differs')
        evidence[name]=pin(raw)
    return evidence


def states(text,phases):
    rows=[]
    for line in text.splitlines():
        if not line.strip() or line.startswith('#'):continue
        f=line.split();require(len(f)==16 and f[0]=='STATE' and f[1] in ('A','B'),'State schema differs')
        v=list(map(int,f[2:12]));bits=f[12:]
        require(all(re.fullmatch('[0-9A-F]{8}',x) for x in bits),'Logical words malformed')
        require(all(x in (0,1) for x in v[6:]) and [int(x,16) for x in bits]==v[6:],'Logical flags differ')
        rows.append(dict(zip(('phase','call','point','requested_mode','code','actual_mode','checkphase',
                             'helicity_checked','fpe_dp','fpe_qp'),v),stage=f[1],logical_words=bits))
    require([(r['phase'],r['call'],r['point'],r['stage']) for r in rows]==
            [(p,p+1,1 if p==0 else 20,s) for p in phases for s in ('B','A')],
            'Missing/repeated/extra outer state entries')
    for row in rows:
        require(row['requested_mode']==-1,'Checked mode request differs')
        if row['stage']=='B':require((row['code'],row['actual_mode'])==(-987654321,-999),'Pre-call sentinel differs')
        else:require(row['code'] in (219,323) and row['actual_mode'] in (1,2,4,5),'Not a checked accepted outer status')
    return rows


def coverage(text,phases,after):
    rows=[]
    for line in text.splitlines():
        if not line.strip() or line.startswith('#'):continue
        f=line.split();require(len(f)==10 and all(HEX64.fullmatch(x) for x in f[5:]),'Raw coefficient schema differs')
        v=list(map(int,f[:5]));rows.append(dict(zip(('phase','call','point','order','code'),v),words=f[5:]))
    require([(r['phase'],r['call'],r['point'],r['order'],r['code']) for r in rows]==
            [(p,p+1,1 if p==0 else 20,o,after[p]['code']) for p in phases for o in (0,1)],
            'Raw coefficient/status/split-order coverage differs')
    return rows


def _outer(raw,phases,legacy):
    """Words, integer flags, text shape only; never decode output coefficients."""
    require(raw['dimensions.dat'].split()==['1','1','1'],'Split-order dimensions differ')
    ss=states(raw['driver-state.dat'],phases);after={r['phase']:r for r in ss if r['stage']=='A'}
    rr=coverage(raw['driver-bits.dat'],phases,after)
    for p in phases:
        code=after[p]['code']
        if p==0:legacy._decimal_shape(raw['bootstrap-values.dat'],[(1,1,0,code),(1,1,1,code)],4)
        else:
            legacy._decimal_shape(raw['values.dat'],[(1,0,code),(1,1,code)],3)
            require(raw['timed_status.dat'].split()==[str(code),'1'],'Timed return/count differs')
    require(not any(r['fpe_dp'] or r['fpe_qp'] for r in after.values()),'Final software failure; outputs opaque')
    require(all((int(w,16)>>52)&2047!=2047 for r in rr for w in r['words']),
            'Nonfinite final coefficient/accuracy; outputs opaque')
    return ss,rr,after


def _phase(trace,p,ss,rows,science):
    after=next(r for r in ss if r['phase']==p and r['stage']=='A');rr=[r for r in rows if r['phase']==p]
    outer={'code':after['code'],'output_words':[w for r in rr for w in r['words'][:4]],
           'accuracy_words':[r['words'][4] for r in rr],'fpe_dp':after['fpe_dp'],'fpe_qp':after['fpe_qp']}
    proof=science['trace'].qualify_phase(trace,p,outer,geometry_validator=science['geometry'].validate_geometry)
    require(proof['passed'] is True and proof['output_arithmetic_admitted'] is True,'Checked phase unqualified')
    require(after['actual_mode']==proof['accepted_modes'][0],'Driver restored basic mode differs from accepted epoch')
    accepted=[g for g in trace['phases'][p]['groups'] if g['seq'] in proof['accepted_groups']]
    joined={'required':proof['rescue_exercised'],'passed':None,'reason':'Accepted DP input is a different precision'}
    if proof['rescue_exercised']:
        joined=science['geometry'].join_matched_mode4([g for g in accepted if g['mode']==4],phase=p)
        joined['required']=True;require(joined['passed'] is True,'Accepted mode4 does not match frozen native inputs')
    primary=[g for g in accepted if g['mode']==proof['accepted_modes'][0] and g['group']==3]
    require(len(primary)==1,'Accepted primary group3 missing')
    return proof,joined,primary[0]


def _saved(kind,backend=9):
    require(kind in ('ordinary','matched') and backend in ((9,) if kind=='ordinary' else (8,9)),'Unknown saved control')
    root,close_sha,report_name,report_sha=(ORDINARY,ORDINARY_CLOSURE_SHA,'ordinary-comparison.json',ORDINARY_COMPARE_SHA) if kind=='ordinary' else (MATCHED,MATCHED_CLOSURE_SHA,'matched-comparison.json',MATCHED_COMPARE_SHA)
    raw=checked(root/('ordinary-closure.json' if kind=='ordinary' else 'run-closure.json'),close_sha)
    closure=json.loads(raw);require(closure['passed'] is True and closure['failure'] is None,'Saved stage failed')
    record=closure['payloads'][report_name];require(record['sha256']==report_sha,'Saved comparison binding differs')
    report_raw=checked(root/report_name,record);report=json.loads(report_raw);require(report['passed'] is True,'Saved comparison failed')
    obs=report['observations']['cms-p1-mode4-lib9-candidate' if kind=='ordinary' else str(backend)]
    require(obs['eligible'] is True and not obs['failures'] and not obs.get('incomplete_contribution_warnings'),
            'Selected saved control failed')
    req=obs['request'];require((req['point'],req['backend'],req['requested_mode'])==(1 if kind=='ordinary' else 20,backend,4),'Saved control identity differs')
    require(all((r['code'],r['actual_mode'],r['fpe_dp'],r['fpe_qp'])==(120,4,0,0)
                for r in obs['states'] if r['stage']=='A'),'Saved control status/flags differ')
    return obs,{'closure':pin(raw),'comparison':pin(report_raw),'selected_id':obs['id']}


def _view(rows,phase,identifier):
    selected=[r for r in rows if r['phase']==phase]
    require(len(selected)==2 and [r['order'] for r in selected]==[0,1],'Eligible phase/order coverage differs')
    return {'id':identifier,'eligible':True,'raw_rows':[{**r,'phase':1} for r in selected]}


def _poles(science,rows,p,proof,group,spec):
    return science['poles'].check_poles([r for r in rows if r['phase']==p],p,input_proof={'qualification':proof,'group':group,
        'physical_card':spec['physical_card'],'point_pin':spec['bootstrap_pin' if p==0 else 'point_pin']})


def _evaluate_phase(science,trace,p,ss,rows,spec):
    proof,joined,primary=_phase(trace,p,ss,rows,science)
    comparisons=[]
    for backend in ((9,) if p==0 else (8,9)):
        saved,evidence=_saved('ordinary' if p==0 else 'matched',backend)
        comparison=science['legacy'].compare_coefficients(_view(saved['raw_rows'],1,saved['id']),
            _view(rows,p,REQUEST['id']))
        comparisons.append({'backend':backend,'saved_control':evidence,**comparison})
    coefficients_passed=all(row['passed'] for row in comparisons)
    poles=_poles(science,rows,p,proof,primary,spec)
    return {'passed':proof['passed'] and coefficients_passed and poles['passed'],
        'host_stability_passed':proof['passed'],'rescue_exercised':proof['rescue_exercised'],
        'matched_mode4_join':joined,'host_qualification':proof,'coefficient_comparisons':comparisons,
        'full_coefficients_passed':coefficients_passed,
        'pole_checks':poles,'measurement_coefficients_decoded':p==1}


def bootstrap_gate(directory,spec,*,protocol,runtime_maps):
    """Live READY file-only gate: no process/library calls, no measurement words."""
    result={'schema':'private-checked-bootstrap-gate-v1','passed':False,'failures':[],
            'measurement_requested':False,'native_actions':0,'source_evidence':{}}
    try:
        directory=Path(directory);evidence=Path(spec['evidence']);science=sources(spec['source_index_sha256'])
        build,bpin=_build(evidence.parent)
        result['source_evidence'].update(_spec(evidence,spec,spec['source_index_sha256'],build,bpin))
        require(directory==Path(spec['cwd']),'Bootstrap directory differs')
        result['source_evidence'].update(_protocol(protocol,runtime_maps,evidence,spec['expected_runtime'],bootstrap=True))
        raw={}
        for name in BOOT_OUTPUTS:
            data=(directory/name).read_bytes();require(len(data)<=(16<<20),'Bootstrap output exceeds bound')
            result['source_evidence'][name]=pin(data);raw[name]=data.decode('ascii')
        console=(evidence/'stdout.txt').read_bytes();result['source_evidence']['stdout.txt']=pin(console)
        require(b'##W03' not in console,'Incomplete contribution warning; bootstrap opaque')
        ss,rows,after=_outer(raw,(0,),science['legacy'])
        trace=science['trace'].parse_trace(raw['trace.dat'],science['routes'],complete_phases=(0,))
        phase=_evaluate_phase(science,trace,0,ss,rows,spec)
        result.update(passed=phase['passed'],phase=phase,states=ss,raw_rows=rows,
            source_admission=science['evidence'],actual_outer_entries=1,ready_maps=1)
        if not phase['passed']:result['failures'].append('Ordinary host/geometry/coefficient/pole bootstrap gate failed')
    except (ValueError,KeyError,TypeError,OSError,UnicodeError,IndexError) as exc:
        result['failures'].append(str(exc))
    return result


def _closed(directory,spec,request,build,bpin,controller_sha):
    evidence=_spec(directory,spec,controller_sha,build,bpin)
    data=(directory/'result.json').read_bytes();native=json.loads(data);evidence['result.json']=pin(data)
    require(native['request']==request,'Native worker request differs')
    pid=native['native_pid'];require(type(pid)is int and pid>0,'Missing owned PID')
    require(native['orchestration_complete'] is True and native['runtime_map_verified'] is True and
            native['trace_complete'] is True and native['native_returncode']==0 and
            not native['stdout_overflow'] and not native['collection_errors'] and
            native['failure'] is None and native['cleanup_failure'] is None,'Incomplete worker ownership/cleanup')
    require(native['close_receipts'] and all(x['complete'] is True and x['worker_closed'] is True and
        x['returncode']==0 and x['pid']==pid for x in native['close_receipts']),'Owned close failed')
    evidence.update(_protocol(native['protocol'],native['runtime_maps'],directory,spec['expected_runtime']))
    require(native['bootstrap_gate_passed'] is True and native['measurement_command_attempted'] is True and
            native['measurement_completed'] is True,'Measurement was not admitted/completed exactly once')
    require(set(native['outputs'])==set(OUTPUTS),'Closed output file set differs')
    raw={}
    for name in OUTPUTS:
        data=checked(directory/name,native['outputs'][name]);evidence[name]=pin(data);raw[name]=data.decode('ascii')
    # Structural closure precedes all numerical gates, including native errors.
    return native,raw,evidence


def compare_stage(runs_dir,requests,*,controller_source_sha,build_receipt):
    result={'schema':'private-normal-checked-comparison-v1','passed':False,'execution_complete':False,
        'bootstrap_control_passed':False,'measurement_interpretation_allowed':False,
        'host_stability_qualified_this_fixture':False,'broad_accuracy_qualified':False,
        'performance_qualified':False,'failures':[],'phases':{},'source_evidence':{}}
    try:
        validate_requests(requests);runs_dir=Path(runs_dir);science=sources(controller_source_sha)
        build,bpin=_build(runs_dir,build_receipt);directory=runs_dir/REQUEST['id']
        spec=json.loads((directory/'specification.json').read_bytes())
        native,raw,evidence=_closed(directory,spec,REQUEST,build,bpin,controller_source_sha)
        result.update(execution_complete=True,native_pid=native['native_pid'],ready_done_maps=2,
                      source_evidence=evidence,source_admission=science['evidence'])
        console=(directory/'stdout.txt').read_bytes();result['source_evidence']['stdout.txt']=pin(console)
        require(b'##W03' not in console,'Incomplete contribution warning; coefficients opaque')
        ss,rows,after=_outer(raw,(0,1),science['legacy']);result.update(states=ss,raw_rows=rows,outer_entries_observed=2)
        trace=science['trace'].parse_trace(raw['trace.dat'],science['routes'],complete_phases=(0,1))
        # Entire worker accepted lifecycle is checked before any coefficients.
        phase_proofs={p:_phase(trace,p,ss,rows,science) for p in (0,1)}
        receipt_raw=(directory/'bootstrap-gate.json').read_bytes();receipt=json.loads(receipt_raw)
        result['source_evidence']['bootstrap-gate.json']=pin(receipt_raw)
        require(receipt['passed'] is True and receipt['measurement_requested'] is False,'READY bootstrap gate missing/failed')
        require(receipt['raw_rows']==[r for r in rows if r['phase']==0] and receipt['states']==[r for r in ss if r['phase']==0],
                'Final bootstrap words/state differ from READY evidence')
        for name in BOOT_OUTPUTS:
            ready_pin=receipt['source_evidence'][name]
            final_prefix=raw[name].encode('ascii')[:ready_pin['bytes']]
            require(pin(final_prefix)==ready_pin,'Bootstrap output prefix changed after READY: '+name)
        p0=_evaluate_phase(science,trace,0,ss,rows,spec);result['phases']['0']=p0
        result['bootstrap_control_passed']=p0['passed'];require(p0['passed'],'Ordinary bootstrap failed; measurement stays opaque')
        result['measurement_interpretation_allowed']=True
        p1=_evaluate_phase(science,trace,1,ss,rows,spec);result['phases']['1']=p1
        result['host_stability_qualified_this_fixture']=all(x['host_stability_passed'] for x in (p0,p1))
        result['rescues_exercised']=[p for p,row in ((0,p0),(1,p1)) if row['rescue_exercised']]
        result['actual_native_calls']=sum(x[0]['native_calls'] for x in phase_proofs.values())
        result['actual_SLOOP_entries']=sum(x[0]['actual_entries'] for x in phase_proofs.values())
        require(p1['passed'],'CMS20 coefficient or separate pole consistency gate failed')
        result['passed']=True
    except (ValueError,KeyError,TypeError,OSError,UnicodeError,IndexError) as exc:
        result['failures'].append(str(exc))
    result['limitations']=['One CMS point and its ordinary bootstrap only; no broad accuracy or performance claim.',
        'Host accepted epochs, retained-engine agreement and universal pole consistency are separate checks.',
        'Native failure/status alone is never used to interpret failed coefficient buffers.',
        'A DP-only accepted result does not qualify the unobserved checked QP rescue path.']
    return result
