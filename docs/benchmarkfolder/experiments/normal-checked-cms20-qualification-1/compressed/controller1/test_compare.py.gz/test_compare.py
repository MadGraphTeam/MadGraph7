"""Pure checked-controller integration tests; synthetic evidence is not physics qualification."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('checked_compare_tests',HERE/'compare.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
LEGACY=M.module(M.OLD/'amplitude_compare.py',M.checked(M.OLD/'amplitude_compare.py',M.OLD_COMPARE_SHA))
ZERO='0000000000000000';ONE='3FF0000000000000';ACC='3EB0C6F7A0B5ED8D'


def fixture(phases=(0,1),codes=(219,323)):
    ss=[];rr=[];state_lines=[];bit_lines=[];raw={'dimensions.dat':'1 1 1\n','qualification.dat':'pending\n','trace.dat':'synthetic\n','timing.dat':'0 0\n'}
    for p in phases:
        code=codes[p];point=1 if p==0 else 20
        for stage in ('B','A'):
            v=[p,p+1,point,-1,code if stage=='A' else -987654321,
               (1 if code==219 else 4) if stage=='A' else -999,0,1,0,0]
            state_lines.append('STATE '+stage+' '+' '.join(map(str,v))+' 00000000 00000001 00000000 00000000')
        for order in (0,1):
            head=[p,p+1,point,order,code];words=[ONE]*4+[ACC]
            bit_lines.append(' '.join(map(str,head))+' '+' '.join(words))
        name='bootstrap-values.dat' if p==0 else 'values.dat'
        heads=[[1,1,o,code] if p==0 else [1,o,code] for o in (0,1)]
        raw[name]='\n'.join(' '.join(map(str,h))+' 1 1 1 1 0.000001' for h in heads)+'\n'
    raw['driver-state.dat']='\n'.join(state_lines)+'\n';raw['driver-bits.dat']='\n'.join(bit_lines)+'\n'
    if 1 in phases:raw['timed_status.dat']=str(codes[1])+' 1\n'
    return raw


def proof(phase=1,code=323):
    return {'passed':True,'phase':phase,'code':code,'output_arithmetic_admitted':True,
            'rescue_exercised':code==323,'accepted_modes':[4,5] if code==323 else [1,2],
            'accepted_groups':list(range(1,53)),'native_calls':104 if code==323 else 52,'actual_entries':1}


class ParseTests(unittest.TestCase):
    def test_checked_status_and_restored_basic_mode(self):
        raw=fixture();ss,rows,after=M._outer(raw,(0,1),LEGACY)
        self.assertEqual([after[p]['actual_mode'] for p in (0,1)],[1,4])
        self.assertEqual([r['code'] for r in rows],[219,219,323,323])
        # Source-bound reason for basic mode, not final direction-test mode.
        source=(M.SCIENCE/'candidate/loop_matrix.f').read_text()
        self.assertIn('CTMODE=BASIC_CT_MODE\n',source)
    def test_unchecked120_and_wrong_requested_mode_rejected(self):
        for before,after in [(' 323 ',' 120 '),(' -1 ',' 4 ')]:
            raw=fixture();raw['driver-state.dat']=raw['driver-state.dat'].replace(before,after)
            with self.assertRaises(ValueError):M._outer(raw,(0,1),LEGACY)
    def test_missing_order_and_extra_entry_rejected(self):
        raw=fixture();raw['driver-bits.dat']='\n'.join(raw['driver-bits.dat'].splitlines()[:-1])
        with self.assertRaisesRegex(ValueError,'coverage'):M._outer(raw,(0,1),LEGACY)
        raw=fixture();raw['driver-state.dat']+=raw['driver-state.dat'].splitlines()[-1]+'\n'
        with self.assertRaisesRegex(ValueError,'entries'):M._outer(raw,(0,1),LEGACY)
    def test_nonfinite_binary_outputs_block_before_decoder(self):
        for word in ('7FF0000000000000','FFF0000000000000','7FF8000000000001','FFF8000000000001'):
            raw=fixture();raw['driver-bits.dat']=raw['driver-bits.dat'].replace(ONE,word,1)
            with patch.object(LEGACY,'decode64',side_effect=AssertionError('decoded')):
                with self.assertRaisesRegex(ValueError,'Nonfinite'):M._outer(raw,(0,1),LEGACY)
        raw=fixture();raw['driver-bits.dat']=raw['driver-bits.dat'].replace(ONE,'8000000000000000',1)
        M._outer(raw,(0,1),LEGACY)
    def test_softwareflag_is_not_hidden_by_checked_return(self):
        raw=fixture();lines=raw['driver-state.dat'].splitlines();f=lines[-1].split();f[10]='1';f[14]='00000001';lines[-1]=' '.join(f);raw['driver-state.dat']='\n'.join(lines)
        with patch.object(LEGACY,'decode64',side_effect=AssertionError('decoded')):
            with self.assertRaisesRegex(ValueError,'software'):M._outer(raw,(0,1),LEGACY)
    def test_bootstrap_rejects_measurement_rows(self):
        with self.assertRaisesRegex(ValueError,'entries'):M._outer(fixture(),(0,),LEGACY)
    def test_decimal_warnings_and_splitorder_not_ignored(self):
        raw=fixture();raw['values.dat']=raw['values.dat'].replace(' 1 1 1 1 ',' NaN 1 1 1 ')
        with self.assertRaisesRegex(ValueError,'decimal'):M._outer(raw,(0,1),LEGACY)
        raw=fixture();raw['dimensions.dat']='1 2 1'
        with self.assertRaisesRegex(ValueError,'dimensions'):M._outer(raw,(0,1),LEGACY)


class PhaseTests(unittest.TestCase):
    def fixture(self,code=323):
        raw=fixture(codes=(219,code));ss,rr,_=M._outer(raw,(0,1),LEGACY)
        q=proof(code=code);primary=q['accepted_modes'][0]
        groups=[{'seq':g,'mode':primary,'group':g,'phase':1} for g in range(1,27)]
        groups += [{'seq':26+g,'mode':primary+1,'group':g,'phase':1} for g in range(1,27)]
        geometry=types.SimpleNamespace(validate_geometry=lambda *a:None,join_matched_mode4=lambda gs,phase:{'passed':len(gs)==26,'phase':phase})
        called=[]
        trace_module=types.SimpleNamespace(qualify_phase=lambda *a,**k:called.append(k['geometry_validator']) or q)
        science={'trace':trace_module,'geometry':geometry}
        return {'phases':{1:{'groups':groups}}},ss,rr,science,called
    def test_qp_requires_real_validator_and_full_matched_join(self):
        t,ss,rr,science,called=self.fixture();q,join,g=M._phase(t,1,ss,rr,science)
        self.assertIs(called[0],science['geometry'].validate_geometry);self.assertTrue(join['passed']);self.assertEqual(g['group'],3)
        science['geometry'].join_matched_mode4=lambda *a,**k:{'passed':False}
        with self.assertRaisesRegex(ValueError,'frozen native'):M._phase(t,1,ss,rr,science)
    def test_dp_does_not_require_different_precision_bit_equality(self):
        t,ss,rr,science,_=self.fixture(219)
        science['geometry'].join_matched_mode4=lambda *a,**k:(_ for _ in ()).throw(AssertionError('DP forced into QP'))
        q,join,g=M._phase(t,1,ss,rr,science)
        self.assertFalse(join['required']);self.assertFalse(q['rescue_exercised'])
    def test_restored_mode_is_primary_not_direction_mode(self):
        t,ss,rr,science,_=self.fixture();ss[-1]['actual_mode']=5
        with self.assertRaisesRegex(ValueError,'restored basic mode'):M._phase(t,1,ss,rr,science)
    def test_pole_rows_are_filtered_per_phase(self):
        _,rr,_=M._outer(fixture(),(0,1),LEGACY);seen=[]
        poles=types.SimpleNamespace(check_poles=lambda rows,p,**kw:seen.append(rows) or {'passed':True})
        M._poles({'poles':poles},rr,0,{}, {},{'physical_card':{},'bootstrap_pin':{}})
        self.assertEqual(len(seen[0]),2);self.assertEqual({r['phase'] for r in seen[0]},{0})
    def test_only_matched8_disagreement_fails_phase(self):
        raw=fixture();ss,rr,_=M._outer(raw,(0,1),LEGACY)
        ordinary=copy.deepcopy(rr[2:]);changed=copy.deepcopy(ordinary);changed[0]['words'][1]='4000000000000000'
        def saved(kind,backend):
            return {'id':str(backend),'raw_rows':changed if backend==8 else ordinary},{'selected_id':str(backend)}
        q=proof();science={'legacy':LEGACY}
        with patch.object(M,'_phase',return_value=(q,{'passed':True},{})),patch.object(M,'_saved',side_effect=saved),\
             patch.object(M,'_poles',return_value={'passed':True}):
            result=M._evaluate_phase(science,{},1,ss,rr,{})
        self.assertFalse(result['passed']);self.assertFalse(result['full_coefficients_passed'])
        self.assertEqual([x['backend'] for x in result['coefficient_comparisons']],[8,9])
        self.assertEqual([x['passed'] for x in result['coefficient_comparisons']],[False,True])
    def test_saved_controls_are_eligible_and_pinned(self):
        for name,backend in (('ordinary',9),('matched',8),('matched',9)):
            obs,e=M._saved(name,backend);self.assertTrue(obs['eligible']);self.assertFalse(obs['failures']);self.assertIn('closure',e)


class StageGateTests(unittest.TestCase):
    def setup_fixture(self,root):
        directory=root/M.REQUEST['id'];directory.mkdir()
        spec={'request':M.REQUEST,'source_index_sha256':'s','physical_card':{},'bootstrap_pin':{},'point_pin':{}}
        (directory/'specification.json').write_text(json.dumps(spec));(directory/'stdout.txt').write_text('')
        raw=fixture();ss,rr,_=M._outer(raw,(0,1),LEGACY);boot=fixture((0,))
        # Real appended trace would preserve the ready prefix exactly.
        raw['trace.dat']=boot['trace.dat']+'measurement\n'
        receipt={'passed':True,'measurement_requested':False,'raw_rows':[r for r in rr if r['phase']==0],
                 'states':[r for r in ss if r['phase']==0],
                 'source_evidence':{n:M.pin(boot[n].encode()) for n in M.BOOT_OUTPUTS}}
        (directory/'bootstrap-gate.json').write_text(json.dumps(receipt))
        science={'legacy':LEGACY,'trace':types.SimpleNamespace(parse_trace=lambda *a,**k:{'mock':True}),
                 'routes':{},'evidence':{}}
        return directory,spec,raw,science
    def exercise(self,mutate=None,phase_error=None,bootstrap_ok=True):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);d,spec,raw,science=self.setup_fixture(root)
            if mutate:mutate(d,raw,science)
            calls=[]
            def ph(trace,p,ss,rr,sci):
                if p==phase_error:raise ValueError('failed accepted native epoch')
                return proof(p),{},{}
            def ev(science,trace,p,ss,rows,spec):
                calls.append(p)
                return {'passed':p!=0 or bootstrap_ok,'host_stability_passed':True,
                        'rescue_exercised':p==1,'coefficient_comparison':{'passed':True}}
            with patch.object(M,'sources',return_value=science),patch.object(M,'_build',return_value=({},{})),\
                 patch.object(M,'_closed',return_value=({'native_pid':123},raw,{})),\
                 patch.object(M,'_phase',side_effect=ph),patch.object(M,'_evaluate_phase',side_effect=ev):
                result=M.compare_stage(root,[M.REQUEST],controller_source_sha='s',build_receipt={})
            return result,calls
    def test_complete_success_reports_checked_scope(self):
        r,c=self.exercise();self.assertTrue(r['passed'],r['failures']);self.assertEqual(c,[0,1]);self.assertTrue(r['execution_complete'])
        self.assertTrue(r['host_stability_qualified_this_fixture']);self.assertFalse(r['broad_accuracy_qualified'])
    def test_native_failure_blocks_all_coefficient_math_but_retains_execution(self):
        r,c=self.exercise(phase_error=1);self.assertFalse(r['passed']);self.assertTrue(r['execution_complete']);self.assertEqual(c,[])
        self.assertFalse(r['measurement_interpretation_allowed'])
    def test_bootstrap_disagreement_blocks_measurement_math(self):
        r,c=self.exercise(bootstrap_ok=False);self.assertEqual(c,[0]);self.assertFalse(r['measurement_interpretation_allowed'])
    def test_W03_precedes_any_math(self):
        r,c=self.exercise(mutate=lambda d,raw,sci:(d/'stdout.txt').write_text('##W03 failed'))
        self.assertFalse(r['passed']);self.assertEqual(c,[]);self.assertTrue(r['execution_complete'])
    def test_empty_or_truncated_trace_is_not_bypassed(self):
        def change(d,raw,sci):
            raw['trace.dat']='';sci['trace'].parse_trace=lambda *a,**k:(_ for _ in ()).throw(ValueError('Missing phase begin'))
        r,c=self.exercise(mutate=change);self.assertEqual(c,[]);self.assertFalse(r['passed'])
    def test_ready_prefix_mutation_blocks_interpretation(self):
        r,c=self.exercise(mutate=lambda d,raw,sci:raw.__setitem__('trace.dat','changed\n'))
        self.assertEqual(c,[]);self.assertFalse(r['passed']);self.assertIn('prefix changed',r['failures'][0])
    def test_ready_raw_word_mutation_blocks_interpretation(self):
        def change(d,raw,sci):
            receipt=json.loads((d/'bootstrap-gate.json').read_text());receipt['raw_rows'][0]['words'][0]=ZERO
            (d/'bootstrap-gate.json').write_text(json.dumps(receipt))
        r,c=self.exercise(mutate=change);self.assertEqual(c,[]);self.assertFalse(r['passed'])
    def test_source_pending_fails_closed(self):
        with patch.object(M,'SCIENCE_SHA',None):
            with self.assertRaisesRegex(ValueError,'seal'):M.packet(M.SCIENCE,M.SCIENCE_SHA)


class InputAndReadyTests(unittest.TestCase):
    def prepare(self,root):
        directory=root/'output/SubProcesses/P0';directory.mkdir(parents=True)
        evidence=root/'results/runs'/M.REQUEST['id'];evidence.mkdir(parents=True)
        cards=directory.parents[1]/'Cards';cards.mkdir()
        (directory/'check').write_bytes(b'synthetic executable bytes: never executed')
        spec={'request':M.REQUEST,'cwd':str(directory),'evidence':str(evidence),
              'source_index_sha256':'controller','scientific_source_index_sha256':M.SCIENCE_SHA,
              'build_receipt_sha256':'build','executable':str(directory/'check'),
              'executable_pin':M.pin((directory/'check').read_bytes())}
        for source,dest,key in ((M.HERE/M.REQUEST['card'],cards/'MadLoopParams.dat','numerical_card'),
             (M.HERE/M.REQUEST['physical_card'],cards/'param_card.dat','physical_card'),
             (M.HERE/M.REQUEST['bootstrap'],directory/'bootstrap.dat','bootstrap_pin'),
             (M.HERE/M.REQUEST['measurement'],directory/'point.dat','point_pin')):
            dest.write_bytes(source.read_bytes());spec[key]=M.pin(dest.read_bytes())
        spec['bootstrap_file']=str(directory/'bootstrap.dat');spec['point_file']=str(directory/'point.dat')
        spec['expected_runtime']={str(directory/'check'):spec['executable_pin']['sha256']}
        (evidence/'specification.json').write_text(json.dumps(spec,indent=2,sort_keys=True)+'\n')
        build={'executable_pin':spec['executable_pin'],'runtime':{'files':{}}}
        return directory,evidence,spec,build
    def test_exact_materialized_input_contract_and_card_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            d,e,s,b=self.prepare(Path(tmp));result=M._spec(e,s,'controller',b,{'sha256':'build'})
            self.assertEqual(result['point_pin'],s['point_pin'])
            (d.parents[1]/'Cards/MadLoopParams.dat').write_text('changed')
            with self.assertRaisesRegex(ValueError,'Pinned bytes changed'):M._spec(e,s,'controller',b,{'sha256':'build'})
    def test_wrong_runtime_or_source_binding_rejected(self):
        for field,new in (('scientific_source_index_sha256','unreviewed'),('expected_runtime',{})):
            with tempfile.TemporaryDirectory() as tmp:
                d,e,s,b=self.prepare(Path(tmp));s[field]=new
                (e/'specification.json').write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
                with self.assertRaises(ValueError):M._spec(e,s,'controller',b,{'sha256':'build'})
    def test_ready_snapshot_and_warning_gate(self):
        for warning in (False,True):
            with tempfile.TemporaryDirectory() as tmp:
                d,e,s,b=self.prepare(Path(tmp));raw=fixture((0,))
                for name in M.BOOT_OUTPUTS:(d/name).write_text(raw[name])
                (e/'stdout.txt').write_text('##W03 failure' if warning else '')
                mapraw=b'only synthetic retained map text\n';(e/'maps-0.txt').write_bytes(mapraw)
                maps=[{'boundary':'READY','file':'maps-0.txt','sha256':M.pin(mapraw)['sha256'],'elf':s['expected_runtime']}]
                science={'legacy':LEGACY,'routes':{},'evidence':{},
                         'trace':types.SimpleNamespace(parse_trace=lambda *a,**k: {'synthetic':True})}
                with patch.object(M,'sources',return_value=science),patch.object(M,'_build',return_value=(b,{'sha256':'build'})),\
                     patch.object(M,'_evaluate_phase',return_value={'passed':True}) as evaluate:
                    r=M.bootstrap_gate(d,s,protocol=[['READY','1','1','1','1','1','0.1']],runtime_maps=maps)
                self.assertEqual(r['passed'],not warning,r['failures'])
                self.assertEqual(evaluate.call_count,0 if warning else 1)
                self.assertFalse(r['measurement_requested'])


if __name__=='__main__':unittest.main()
