"""File-only checked-controller lineage/preflight; never invokes native tools."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCIENCE=ROOT/'.tirust-build/kinematic-normal-checked-source-1'
SCIENCE_SHA='7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9'  # Reviewed immutable scientific source.
MATCHED=ROOT/'.tirust-build/kinematic-matched-native-input-controller-2'
PINS={
 'scientific_source':'7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9',
 'approved_plan':'9387a2858df75bf34d0940121da6e006fe7648a9d63d241276ba05f94487f7b4',
 'matched_controller':'9076a51a0be56c57fb7dda32cfec3ef9b038bec2e73dc5e751bf31dc5ac3bc41',
 'amplitude_source':'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74',
 'candidate_build_closure':'8cab371e9affd5297c0f48c30184361959d20f3d3a48c6dbd6109b86bf49bacb',
 'candidate_build':'35b556bd50d4e40f34925145d69acd1fcc4ea865a3eaea2214c44e4727a9b5e6',
 'ordinary_closure':'b364bd8535d0f5850cb5a21390c5678cbb1c1dd8fddfae6f0174cf50d261f7a7',
 'ordinary_comparison':'6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451',
 'matched_run_closure':'52faa470d8be22b81f8636edba21f5fba6c2d13be1f0241a8212a7b2055839a7',
 'matched_comparison':'af4b58a379ac35a78066a1bcad38ed3f4fe9e16e6b0d4583dbd4e6c940eba6d5',
}
COMPILED=['check_sa.o','loop_matrix.o','mp_compute_loop_coefs.o','CT_interface.o',
          'TIR_interface.o','TIRUST_interface.o','checked_trace.o']


def require(ok,message):
 if not ok: raise ValueError(message)


def pin(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
 require(pin(path)=={k:expected[k] for k in ('bytes','sha256')},'Changed bound file: '+str(path))


def authenticate(path,sha):
 require(pin(path)['sha256']==sha,'Source index changed: '+str(path))
 data=json.loads(Path(path).read_bytes())
 for name,record in data['files'].items():
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source payload')
  checked(Path(path).parent/name,record)
 return data


def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
 sys.modules[name]=module;spec.loader.exec_module(module);return module


def expected_native_job():
 """Exact small derivative of the already reviewed owned-worker implementation."""
 source=(MATCHED/'native_job.py').read_text()
 replacements=[
  ('"""One owned bootstrap/single-measurement worker; no retry or timing claim."""',
   '"""One owned checked worker; pure READY gate before measurement, no retry."""'),
  ('from admission import HERE, ROOT, helpers, read_json, require, save, sealed, sha, verify_record',
   'from admission import HERE, ROOT, helpers, load, read_json, require, save, sealed, sha, verify_record'),
  ('worker=None;error=None;cleanup_error=None;measured=False;collection_errors=[]',
   'worker=None;error=None;cleanup_error=None;measured=False;collection_errors=[]\n'
   '    bootstrap_ready=False;bootstrap_receipt=None;measurement_attempted=False'),
  ('        worker.timeout=300\n        worker.run(1);measured=True',
   '        bootstrap_ready=True\n'
   "        comparator=load('normal_checked_bootstrap_comparator',HERE/'compare.py')\n"
   '        bootstrap_receipt=comparator.bootstrap_gate(directory,spec,protocol=messages,runtime_maps=captures)\n'
   "        save(evidence/'bootstrap-gate.json',bootstrap_receipt)\n"
   "        require(bootstrap_receipt['passed'] is True,'Checked bootstrap gate failed; measurement not requested')\n"
   '        worker.timeout=600\n        measurement_attempted=True\n        worker.run(1);measured=True'),
  ('worker.close(graceful=measured)','worker.close(graceful=bootstrap_ready)'),
  ("require(len(raw)<=67108864,'Worker file exceeds reviewed byte cap')",
   "require(len(raw)<=(16777216 if name=='trace.dat' else 67108864),'Worker file exceeds reviewed byte cap')"),
  ("'numerically_qualified':False,'performance_measurement':False}",
   "'bootstrap_gate_passed':bootstrap_receipt is not None and bootstrap_receipt.get('passed') is True,\n"
   "            'measurement_command_attempted':measurement_attempted,'measurement_completed':measured,\n"
   "            'numerically_qualified':False,'performance_measurement':False}"),
 ]
 for old,new in replacements:
  require(source.count(old)==1,'Owned worker derivative anchor differs')
  source=source.replace(old,new,1)
 return source


def _scientific_preflight():
 require(type(SCIENCE_SHA) is str and len(SCIENCE_SHA)==64,'Scientific source seal is pending review')
 source=authenticate(SCIENCE/'index.json',SCIENCE_SHA)
 # All source modules are authenticated above. Scope local import names and
 # restore them so another retained packet cannot supply a stale prepare module.
 names=[Path(name).stem for name in source['files'] if '/' not in name and name.endswith('.py')]
 saved={name:sys.modules.get(name) for name in names};old_path=sys.path[:]
 try:
  for name in names: sys.modules.pop(name,None)
  sys.path.insert(0,str(SCIENCE))
  verifier=load('normal_checked_scientific_verifier',SCIENCE/'verify.py')
  result=verifier.preflight(SCIENCE_SHA)
 finally:
  sys.path[:]=old_path
  for name in names:
   sys.modules.pop(name,None)
   if saved[name] is not None: sys.modules[name]=saved[name]
 require(result['passed'] is True and result['native_actions']==0,'Scientific preflight failed')
 return result,source


def verify(expected=None,*,allow_pending=False):
 own=authenticate(HERE/'index.json',expected) if expected is not None else None
 require(own is not None or allow_pending,'Explicit sealed controller index required')
 bindings=json.loads((HERE/'bindings.json').read_bytes())
 require(bindings['root']==str(ROOT) and set(bindings['files'])==set(PINS),'Controller bindings differ')
 for key,sha in PINS.items():
  record=bindings['files'][key];require(record['sha256']==sha,'Fixed lineage differs: '+key)
  path=Path(record['path']);require(not path.is_absolute() and '..' not in path.parts,'Unsafe binding path')
  checked(ROOT/path,record)
 packets={}
 for key in ('approved_plan','matched_controller','amplitude_source'):
  record=bindings['files'][key];packets[key]=authenticate(ROOT/record['path'],record['sha256'])
 plan_dir=(ROOT/bindings['files']['approved_plan']['path']).parent
 approved_bindings=json.loads((plan_dir/'bindings.json').read_bytes())
 for name,record in approved_bindings['files'].items(): checked(ROOT/name,record)
 closures={};counts={}
 for key in ('candidate_build_closure','ordinary_closure','matched_run_closure'):
  path=ROOT/bindings['files'][key]['path'];closure=json.loads(path.read_bytes())
  require(closure['passed'] is True and closure['failure'] is None and closure['postcheck_failure'] is None,
          'Closed prerequisite failed: '+key)
  for name,record in closure['payloads'].items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe closed payload')
   checked(path.parent/name,record)
  closures[key]=closure;counts[key]=len(closure['payloads'])
 for binding,closure,member in (
  ('candidate_build','candidate_build_closure','builds/candidate/build.json'),
  ('ordinary_comparison','ordinary_closure','ordinary-comparison.json'),
  ('matched_comparison','matched_run_closure','matched-comparison.json')):
  checked(ROOT/bindings['files'][binding]['path'],closures[closure]['payloads'][member])
 require((HERE/'limit_exec.py').read_bytes()==(MATCHED/'limit_exec.py').read_bytes(),'Worker resource limits changed')
 require((HERE/'worker_entry.py').read_text()==(MATCHED/'worker_entry.py').read_text().replace(
  'kinematic-matched-native-input-executor-2','kinematic-normal-checked-executor-1'),'Worker ownership/root derivative differs')
 require((HERE/'native_job.py').read_text()==expected_native_job(),'Owned worker derivative differs')
 base=(ROOT/bindings['files']['amplitude_source']['path']).parent
 old_card=(base/'inputs/cms-backend9-mode4-MadLoopParams.dat').read_bytes()
 require(old_card.count(b'#CTModeRun\n4\n')==1,'Literal card anchor differs')
 expected_card=old_card.replace(b'#CTModeRun\n4\n',b'#CTModeRun\n-1\n',1)
 require((HERE/'backend9-auto-MadLoopParams.dat').read_bytes()==expected_card,'Card has changes beyond CTModeRun')
 policy=json.loads((plan_dir/'policy.json').read_bytes())
 require(pin(HERE/'backend9-auto-MadLoopParams.dat')==policy['planned_literal_card_pin'],'Card differs from approved plan')
 for name in ('cms-param_card.dat','cms-point1.dat','cms-point20.dat'):
  require((HERE/'inputs'/name).read_bytes()==(base/'inputs'/name).read_bytes(),'Fixed physical input differs')
 plan=json.loads((HERE/'validation-plan.json').read_bytes());r=plan['requests']
 require(len(r)==1 and r[0]['id']=='cms-p20-auto-lib9-checked','One checked worker required')
 require((r[0]['backend'],r[0]['point'],r[0]['requested_mode'],r[0]['variant'],r[0]['stage'])==(9,20,-1,'checked','run'),
         'Checked worker scope differs')
 require(r[0]['expected_checked_returns']==[219,323] and r[0]['bootstrap_calls']==r[0]['measurement_calls']==1 and
         r[0]['outer_entries_max']==2,'Checked acceptance/outer count differs')
 require(r[0]['card']=='backend9-auto-MadLoopParams.dat' and r[0]['physical_card']=='inputs/cms-param_card.dat' and
         r[0]['bootstrap']=='inputs/cms-point1.dat' and r[0]['measurement']=='inputs/cms-point20.dat','Worker input paths differ')
 require(plan['build']['compiled_objects']==COMPILED and plan['build']['seconds_total']==420 and
         plan['build']['jobs']==1 and plan['build']['loader_queries']==1,'Build boundary differs')
 require(plan['run']['seconds_total']==960 and plan['run']['worker_seconds']==780 and
         plan['run']['bootstrap_seconds']==180 and plan['run']['measurement_seconds']==600,'Run budget differs')
 require(plan['cpu']==12 and plan['cpu_exclusive'] is False and plan['retry'] is False and
         plan['force_stability_check'] is True and plan['cache']==0 and plan['pole_mode']==0 and
         plan['requested_precision']=='-1D0','Checked scientific/resource policy differs')
 require(plan['scientific_source_index_sha256']==SCIENCE_SHA,'Scientific seal declaration differs')
 science=None
 if SCIENCE_SHA is None:
  require(allow_pending,'Scientific source seal is pending review')
 else:
  science,_=_scientific_preflight()
  for name in ('backend9-auto-MadLoopParams.dat','inputs/cms-param_card.dat','inputs/cms-point1.dat','inputs/cms-point20.dat'):
   require((HERE/name).read_bytes()==(SCIENCE/'inputs'/Path(name).name).read_bytes(),'Scientific input bytes differ')
 return {'passed':True,'scope':'file-only frozen prerequisite checks',
         'native_admission_ready':own is not None and science is not None,'scientific_source_pending':science is None,
         'controller_payloads':0 if own is None else len(own['files']),
         'frozen_source_payloads':{k:len(v['files']) for k,v in packets.items()},
         'closed_payloads':counts,'approved_plan_bound_files':len(approved_bindings['files']),
         'literal_card_only_change':'CTModeRun 4 -> -1','scientific_preflight':science,'native_actions':0}


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--reviewed-source-index');parser.add_argument('--pending-source-preflight',action='store_true')
 args=parser.parse_args()
 print(json.dumps(verify(args.reviewed_source_index,allow_pending=args.pending_source_preflight),indent=2,sort_keys=True))
