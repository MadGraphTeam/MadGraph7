"""Pure pole-adapter checks; synthetic proof objects do not qualify native work."""
import copy
import importlib.util
from pathlib import Path
from fractions import Fraction as F
import json
import struct
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pure_checked_poles',HERE/'pole_checks.py')
P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)


class PoleChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.refs=P.references()

 def fixture(self,phase=0):
  refs=self.refs;old=refs['single']['result']['points'][phase]['captured_inputs']
  external=[]
  for leaf in old['external_complex_words']:
   external += [leaf[i+1]+leaf[i] for i in range(0,16,2)]
  scale=[old['native_mu_squared_words'][1]+old['native_mu_squared_words'][0]]
  geometry={'passed':True,'route':3,'mode':4,'width':128,
            'source_evidence':{'synthetic-source-proof':{'bytes':1,'sha256':'0'*64}}}
  group={'seq':3,'phase':phase,'group':3,'mode':4,'backend':9,'sqso':1,'width':128,'digits':113,
         'n':4,'rank':2,'nc':15,'native_count':1,'complete':1,'stable':1,'unchanged':1,
         'status':0,'fpe_dp':0,'fpe_qp':0,'early':0,'words':{'EXTERNAL':external,'SCALE':scale}}
  qualification={'passed':True,'output_arithmetic_admitted':True,'phase':phase,'code':323,
                 'accepted_modes':[4,5],'accepted_groups':list(range(1,53)),
                 'geometry':[{'seq':3,'proof':geometry}]}
  observed=json.loads(refs['double']['payloads']['source/observations.json'])['rows']
  rows=[copy.deepcopy(r) for r in observed if r['phase']==phase and r['worker'].endswith('lib9-candidate')]
  self.assertEqual(len(rows),2)
  for row in rows:row['code']=323;row['words'][4]='0000000000000000'
  point=1 if phase==0 else 20
  proof={'qualification':qualification,'group':group,
         'physical_card':P.pin(refs['double']['payloads']['source/param_card.dat']),
         'point_pin':P.pin(refs['single']['payloads'][f'source/point{point}.dat'])}
  return rows,proof

 def run_check(self,rows,proof,phase=0):
  with patch.object(P,'references',return_value=self.refs):
   return P.check_poles(rows,phase,input_proof=proof)

 def test_actual_retained_sources_replay(self):
  self.assertEqual(self.refs['double']['result']['native_executions'],0)
  self.assertEqual(self.refs['single']['result']['native_executions'],0)
  self.assertEqual([x['trace_parent_stage_passed'] for x in self.refs['single']['result']['points']],[True,False])
  self.assertGreater(len(self.refs['source_evidence']),40)

 def test_synthetic_proof_with_eligible_retained_rows_and_inputs(self):
  for phase in (0,1):
   rows,proof=self.fixture(phase);result=self.run_check(rows,proof,phase)
   self.assertTrue(result['passed']);self.assertTrue(result['ordinary_target_passed'])
   self.assertEqual(len(result['comparisons']),4)
   self.assertTrue(result['inputs']['historical_exact_input_values_equal'])
   self.assertFalse(result['normal_host_stability_qualified_by_this_adapter'])
   self.assertFalse(result['finite_truth_qualified'])

 def test_no_current_output_decode_before_phase_qualification(self):
  rows,proof=self.fixture();proof['qualification']['passed']=False
  with patch.object(self.refs['legacy'],'decode64',side_effect=AssertionError('decoded failed output')):
   with self.assertRaisesRegex(ValueError,'phase not qualified'):self.run_check(rows,proof)

 def test_failed_native_or_missing_geometry_blocks_decode(self):
  for field,value in [('status',1),('stable',0),('fpe_qp',1),('unchanged',0)]:
   rows,proof=self.fixture();proof['group'][field]=value
   with patch.object(self.refs['legacy'],'decode64',side_effect=AssertionError('decoded failed output')):
    with self.assertRaisesRegex(ValueError,'Failed group'):self.run_check(rows,proof)
  rows,proof=self.fixture();proof['qualification']['geometry']=[]
  with self.assertRaisesRegex(ValueError,'geometry proof'):self.run_check(rows,proof)

 def test_all_output_words_classified_before_first_row_decode(self):
  for bad in ('7FF0000000000000','FFF8000000000001','7FF8000000000000'):
   rows,proof=self.fixture();rows[1]['words'][3]=bad
   with patch.object(self.refs['legacy'],'decode64',side_effect=AssertionError('decoded nonfinite stage')):
    with self.assertRaisesRegex(ValueError,'nonfinite output'):self.run_check(rows,proof)

 def test_nonfinite_input_and_imaginary_leaf_rejected(self):
  rows,proof=self.fixture();proof['group']['words']['SCALE'][0]='7FFF'+'0'*28
  with self.assertRaisesRegex(ValueError,'current pole inputs'):self.run_check(rows,proof)
  rows,proof=self.fixture();proof['group']['words']['EXTERNAL'][1]='3FFF'+'0'*28
  with self.assertRaisesRegex(ValueError,'Nonreal'):self.run_check(rows,proof)

 def test_missing_order_or_wrong_phase_rejected(self):
  rows,proof=self.fixture()
  with self.assertRaisesRegex(ValueError,'coverage'):self.run_check(rows[:1],proof)
  rows[1]['phase']=1
  with self.assertRaisesRegex(ValueError,'coverage'):self.run_check(rows,proof)

 def test_wrong_card_or_point_rejected(self):
  for key in ('physical_card','point_pin'):
   rows,proof=self.fixture();proof[key]={'bytes':1,'sha256':'0'*64}
   with self.assertRaisesRegex(ValueError,'model/point'):self.run_check(rows,proof)

 def test_secondary_mode_not_used_as_primary(self):
  rows,proof=self.fixture();proof['group']['mode']=5
  with self.assertRaisesRegex(ValueError,'primary group3'):self.run_check(rows,proof)

 def test_input_change_is_reported_not_assumed_equal(self):
  rows,proof=self.fixture();word=proof['group']['words']['SCALE'][0]
  proof['group']['words']['SCALE'][0]=f'{int(word,16)+1:032X}'
  result=self.run_check(rows,proof)
  self.assertFalse(result['inputs']['historical_exact_input_values_equal'])
  self.assertTrue(result['inputs']['historical_input_equality_not_assumed'])

 def test_dp_current_input_is_supported_with_no_qp_equality_claim(self):
  rows,proof=self.fixture();g=proof['group'];q=proof['qualification']
  for tag in ('EXTERNAL','SCALE'):
   g['words'][tag]=[struct.pack('>d',float(self.refs['single']['module'].binary128([w[16:],w[:16]]))).hex().upper().zfill(32)
                    for w in g['words'][tag]]
  g.update(mode=1,width=64,digits=53);q.update(code=219,accepted_modes=[1,2])
  q['geometry'][0]['proof'].update(mode=1,width=64)
  for row in rows:row['code']=219
  result=self.run_check(rows,proof)
  self.assertTrue(result['passed']);self.assertEqual(result['inputs']['width'],64)

 def test_single_coefficient_failure_is_retained(self):
  rows,proof=self.fixture();rows[1]['words'][2]='3FF0000000000000'
  result=self.run_check(rows,proof)
  self.assertFalse(result['passed']);self.assertEqual(len(result['failures']),1)
  self.assertEqual((result['failures'][0]['order'],result['failures'][0]['column']),(1,2))

 def test_existing_criterion_and_target_boundaries(self):
  legacy=self.refs['legacy']
  for tolerance in (legacy.TOL,legacy.TARGET):
   # abs(x-y)/abs(x+y) == t exactly must fail strict '<'.
   m=P._metric(1+tolerance,1-tolerance,F(1),legacy)
   self.assertFalse(m['passed'] if tolerance==legacy.TOL else m['ordinary_target_passed'])
  self.assertTrue(P._metric(F(1),F(-1),F(10**9),legacy)['passed'])
  self.assertIsNone(P._metric(F(1),F(-1),F(1),legacy)['symmetric_relative_error'])
  self.assertTrue(P._metric(F(0),F(0),F(0),legacy)['passed'])

 def test_current_values_opaque_on_unqualified_row(self):
  rows,proof=self.fixture();rows[1]['eligible']=False
  with patch.object(self.refs['legacy'],'decode64',side_effect=AssertionError('decoded ineligible row')):
   with self.assertRaisesRegex(ValueError,'output remains opaque'):self.run_check(rows,proof)

 def test_hash_before_parse(self):
  with self.assertRaisesRegex(ValueError,'Changed pinned pole input'):
   P.checked(HERE/'pole_checks.py','0'*64)


if __name__=='__main__':unittest.main()
