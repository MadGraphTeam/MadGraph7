# Private normal checked controller

This source-only controller implements approved plan
`9387a2858df75bf34d0940121da6e006fe7648a9d63d241276ba05f94487f7b4` and binds
scientific source `7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9`.
No source-preparation step compiled, loaded or evaluated scientific code. The
executor `.tirust-build/kinematic-normal-checked-executor-1` remains unmaterialized.
The controller index is a separate review boundary; it does not authorize build
or run. Exact `--execute` admission is required separately for each stage.

File-only reproduction from the repository root:

```sh
source tools/tirust_env.sh
python3 -B .tirust-build/kinematic-normal-checked-controller-1/verify.py --reviewed-source-index <controller-index-sha256>
python3 -B -m unittest discover -s .tirust-build/kinematic-normal-checked-controller-1 -p 'test_*.py' -v
```

The controller reuses corrected matched controller2 ownership, shared lock,
deadline, compiler-recipe audit, actual loader/provider guards and append-only
receipts. A fresh checked ELF replaces six existing objects and adds
`checked_trace.o`; all205 other donor objects, ten old modules and scientific
libraries remain pinned. Build has one loader query and no Fortran main call.
RUN requires a separate reviewed closed-build hash. Proposed invocations are:

```sh
python3 -B .tirust-build/kinematic-normal-checked-controller-1/run.py build --reviewed-source-index <controller-index-sha256> --execute
python3 -B .tirust-build/kinematic-normal-checked-controller-1/run.py run --reviewed-source-index <controller-index-sha256> --reviewed-build-sha256 <closed-build-sha256> --execute
```

One fresh backend9 worker uses ordinary point1 once, then CMS20 once. The literal
card is candidate2's backend9 mode4 card with only `CTModeRun: 4 -> -1`; cache0,
all poles, finite terms and original thresholds remain. The driver preserves
`FORCE_STABILITY_CHECK(.TRUE.)` and requested precision `-1D0`.

At READY the pure comparator authenticates the current source/build/specification,
actual runtime map, literal cards/points and closed bootstrap files. It requires
complete source-bound geometry and accepted host DP1/2 or QP4/5 epochs, zero final
software flags, finite output encodings, noW03, both split orders, agreement with
the eligible closed ordinary9QP control, and separately reported universal QED
pole consistency. Only then does ownership code send exactly one RUN command.
Failure/parser exceptions retain the files and close without another evaluation.

The final comparator checks both complete phase lifecycles before interpreting
any coefficient. It reconciles the READY receipt with exact retained bootstrap
words and every bootstrap-file prefix. A failed bootstrap blocks measurement
coefficient arithmetic. CMS20 compares every Born/finite/single/double-pole word
for orders0/1 against BOTH eligible closed matched8 and9 controls, retaining each
comparison separately. It does not select any failed old reference output.

Return219 can qualify the observed checked DP epoch without claiming QP coverage.
Return323 requires actual failed DP history, reset, genuine QP producer lineage,
complete successful modes4/5 and an exact26-group primary mode4 native-input and
canonical-numerator join to closed matched9. The driver's final CTMODE is the
restored basic mode1/4, distinct from the final direction-test mode2/5.

Pole checks authenticate and exactly replay both retained public QED audits,
then apply those model/charge/normalization conventions to the ACTUAL accepted
primary group3 external words and scale. Current-vs-historical input differences
are reported. Existing3e-6 regression and1e-8 target criteria are retained.
Runtime coupling bits and independent UV cancellation remain unobserved. Pole
consistency, full coefficient agreement, host acceptance and rescue coverage
remain separate results; none claims broad accuracy or performance.

Resource bounds are single-job/nonexclusive CPU12, BUILD420s (360s work plus60s
cleanup), RUN960s (900s work plus60s cleanup), one780s worker with180s bootstrap
and600s measurement protocol timeouts, trace16MiB and ordinary-file64MiB limits.
No retry, rotation change, threshold change, private library rebuild or cache
policy change is introduced. The scientific recorder retains at most4 actual
SLOOP entries/416 groups/1024 lifecycle events; qualification requires exactly
one actual entry per phase and at most104 groups per phase.

The recipe tests replay captured numerical/support recipes without invoking
make. They do not claim an actual captured expansion for the new recorder; the
actual all-source audit remains a build prerequisite. Synthetic comparator tests
exercise gate ordering and failure classification, not scientific accuracy.
