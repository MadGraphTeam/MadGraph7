#!/usr/bin/env python3
"""Run-only private checked9 successor; reuse the original closed executable."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / '.tirust-build/kinematic-normal-checked-executor-2'
SOURCE = ROOT / '.tirust-build/kinematic-normal-checked-source-1'
SCIENCE_SHA = '7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9'  # Reviewed immutable scientific source.
WORK, RESULTS = BASE / 'work', BASE / 'results'
OLD = ROOT / '.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA = 'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
P = H = V = PLAN = None
DONOR_PROVENANCE = None


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def verify_source(expected):
    global P, H, V, PLAN
    require(type(expected) is str and len(expected) == 64 and
            all(c in "0123456789abcdef" for c in expected),
            "Explicit 64-hex reviewed source index required")
    if V is None:
        V = load('reference_verify', HERE / 'verify.py')
    verified = V.verify(expected)
    if P is None:
        P = load('reference_retained_controller', OLD / 'run.py')
        H = load('reference_retained_build', OLD / 'build_stage.py')
        P.R, P.G, P.B, P.PLAN, P.TOOLCHAIN, protected = P.verify_source(OLD_SHA)
        P.BASE, P.WORK, P.RESULTS = BASE, WORK, RESULTS
    else:
        *_, protected = P.verify_source(OLD_SHA)
    PLAN = read(HERE / 'validation-plan.json')
    require([x['backend'] for x in PLAN['requests']] == [9], 'Checked backend scope differs')
    require(all(x['requested_mode'] == -1 and x['point'] == 20 and
                x['bootstrap_calls'] == x['measurement_calls'] == 1 and
                x['outer_entries_max'] == 2 for x in PLAN['requests']), 'Reference scope differs')
    return {'upstream': protected, 'source_index': V.pin(HERE / 'index.json'),
            'bindings': V.pin(HERE / 'bindings.json'), 'verified': verified,
            'scientific_source_index': V.pin(SOURCE / 'index.json'),
            'candidate_donor_current': donor_preflight()}


def setup_owned(stage):
    require(stage == 'run', 'Successor permits RUN only; compilation is forbidden')
    L = P.setup_owned(stage)
    L.STAGES = ('run',)
    L.CURRENT_STAGE = stage
    L.CPU = 12
    original = L.command
    item, _ = V.reviewed_donor_build(V.BUILD_SHA)
    request = PLAN['requests'][0]
    directory = WORK / 'workers' / request['id'] / 'SubProcesses' / H.SUBPROCESS
    def command(args, label, cwd=ROOT, timeout=600, cpu=True):
        args = [str(x) for x in args]
        loader = [item['runtime']['loader'], '--list', str(directory / 'check')]
        worker = [sys.executable, '-B', str(HERE / 'worker_entry.py')]
        require(args == loader or (len(args) == 6 and args[:3] == worker and
            args[3] == str(RESULTS / 'runs' / request['id'] / 'specification.json')),
            'Run-only command boundary rejects compiler/build/unknown command')
        return original(args, label, cwd, timeout, cpu)
    L.command = command
    P.R.PC_SAVE = save
    return L


def dependency_preflight(stage):
    L = setup_owned(stage)

    def forbidden(*args, **kwargs):
        raise ValueError('Native action forbidden in file-only dependency preflight')

    L.command = forbidden
    L.runtime = forbidden
    snapshot = P.R.dependency_snapshot()
    expected = P.B['external_private_files']
    require(all(snapshot.get(name) == value for name, value in expected.items()),
            'Inherited size/bytes dependency adapter differs')
    return {'native_actions': 0, 'files': len(snapshot), 'private_records': len(expected)}


def donor_preflight():
    item, evidence = V.reviewed_donor_build(V.BUILD_SHA)
    return evidence


def literal_cards(output, request):
    for name, key in [('param_card.dat', 'physical_card'), ('MadLoopParams.dat', 'card')]:
        paths = {output / 'Cards' / name, *((output / 'SubProcesses').rglob(name))}
        for path in paths:
            H.write_private(output, path, (HERE / request[key]).read_bytes())


def reviewed_build(expected):
    global DONOR_PROVENANCE
    item, DONOR_PROVENANCE = V.reviewed_donor_build(expected)
    return item


def run_checked(build_sha, source_sha):
    item = reviewed_build(build_sha)
    completed, failure = [], None
    try:
        for request in PLAN['requests']:
            P.R.L.remaining(780)
            P.R.L.q.verify_hashes(item['prelink_bound'])
            output = H.clone(P.R, Path(item['output']), WORK / 'workers' / request['id'])
            literal_cards(output, request)
            directory = output / 'SubProcesses' / H.SUBPROCESS
            evidence = RESULTS / 'runs' / request['id']
            evidence.mkdir(parents=True, exist_ok=False)
            V.checked(directory / 'check', item['executable_pin'])
            runtime = P.runtime(directory / 'check', item['prelink_bound'], request['id'], item['runtime'])
            expected = {**runtime['files'], str((directory / 'check').resolve()): item['executable_pin']['sha256']}
            for key in ('bootstrap', 'measurement'):
                shutil.copyfile(HERE / request[key], directory / (key + '-input.dat'))
            specification = {'request': request, 'cwd': str(directory), 'expected_runtime': expected,
                'bootstrap_file': str(directory / 'bootstrap-input.dat'),
                'point_file': str(directory / 'measurement-input.dat'),
                'bootstrap_pin': V.pin(directory / 'bootstrap-input.dat'),
                'point_pin': V.pin(directory / 'measurement-input.dat'),
                'executable': str(directory / 'check'), 'executable_pin': item['executable_pin'],
                'evidence': str(evidence), 'source_index_sha256': source_sha,
                'scientific_source_index_sha256': SCIENCE_SHA,
                'build_receipt_sha256': DONOR_PROVENANCE['build_receipt']['sha256'],
                'donor_build_closure_sha256': V.BUILD_SHA,
                'donor_build_source_index_sha256': V.PRIOR_SHA,
                'numerical_card': V.pin(output / 'Cards/MadLoopParams.dat'),
                'physical_card': V.pin(output / 'Cards/param_card.dat')}
            specpath = evidence / 'specification.json'
            save(specpath, specification)
            P.R.command([sys.executable, '-B', HERE / 'worker_entry.py', specpath,
                         V.pin(specpath)['sha256'], source_sha], 'worker-' + request['id'], directory, 780)
            require(read(evidence / 'result.json')['orchestration_complete'], 'Incomplete worker retained')
            completed.append(request['id'])
        require(P.QUERIES == [r['id'] for r in PLAN['requests']], 'Runtime query count/order differs')
        comparator = load('checked_comparator', HERE / 'compare.py')
        comparison = comparator.compare_stage(RESULTS / 'runs', PLAN['requests'],
            controller_source_sha=source_sha, build_receipt=item)
        save(RESULTS / 'checked-comparison.json', comparison)
        require(comparison['passed'], 'Checked host/geometry/amplitude gate failed; evidence retained')
    except BaseException as exc:
        failure = repr(exc)
        raise
    finally:
        save(RESULTS / 'run-requests.json', {'requests': PLAN['requests'], 'completed': completed,
            'not_completed': [x for x in PLAN['requests'] if x['id'] not in completed],
            'failure': failure, 'maximum_driver_THRES_requests': 2, 'actual_SLOOP_retention_max': 4, 'performance_measurement': False})


def payloads(stage):
    paths = {RESULTS / name for name in (f'stage-{stage}.json', f'{stage}-before.json', f'{stage}-after.json')}
    for label in P.COMMANDS:
        paths.update({RESULTS / 'execution' / (label + '.json'), RESULTS / 'execution' / (label + '.txt')})
    for label in P.QUERIES:
        paths.add(RESULTS / 'runtime' / (label + '.json'))
    paths.update({RESULTS / 'checked-comparison.json', RESULTS / 'run-requests.json',
                  RESULTS / 'retrospective-bootstrap-preflight.json'})
    for request in PLAN['requests']:
        folder = RESULTS / 'runs' / request['id']
        if folder.exists():
            paths.update(p for p in folder.rglob('*') if p.is_file())
    return {str(p.relative_to(RESULTS)): V.pin(p) for p in sorted(paths) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('run',))
    parser.add_argument('--reviewed-source-index', required=True)
    parser.add_argument('--reviewed-build-sha256', required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(Path.cwd() == ROOT, 'Run from repository root')
    before = verify_source(args.reviewed_source_index)
    preflight = dependency_preflight(args.stage)
    reviewed_build(args.reviewed_build_sha256)
    comparator = load('checked_successor_preflight_comparator', HERE / 'compare.py')
    retrospective = comparator.retrospective_bootstrap_gate(controller_sha=args.reviewed_source_index)
    require(retrospective['passed'] is True, 'Closed ordinary bootstrap is not qualified by corrected controller')
    if not args.execute:
        print(json.dumps({'passed': True, 'stage': args.stage, 'dependency_preflight': preflight,
                          'donor_build': DONOR_PROVENANCE, 'retrospective_bootstrap': retrospective}))
        return
    require(not (RESULTS / ('stage-' + args.stage + '.json')).exists(), 'Append-only stage; no retry')
    save(RESULTS / 'retrospective-bootstrap-preflight.json', retrospective)
    save(RESULTS / (args.stage + '-before.json'), before)
    L = setup_owned(args.stage)
    started = time.monotonic()
    failure = postfailure = lock = active = None
    with L.cleanup.SignalRequests() as signals:
        L.REQUESTS = P.R.BudgetRequests(signals)
        try:
            lock = P.R.acquire(signals)
            active = time.monotonic()
            with L.Deadline(PLAN[args.stage]['seconds_total'] - 60):
                run_checked(args.reviewed_build_sha256, args.reviewed_source_index)
        except BaseException as exc:
            failure = exc
        finally:
            if lock is not None:
                lock.close()
            try:
                after = verify_source(args.reviewed_source_index)
                require(after == before, 'Protected inputs changed')
                save(RESULTS / (args.stage + '-after.json'), after)
            except BaseException as exc:
                postfailure = exc
            result = {'stage': args.stage, 'passed': failure is None and postfailure is None,
                'failure': None if failure is None else repr(failure),
                'postcheck_failure': None if postfailure is None else repr(postfailure),
                'source_index_sha256': args.reviewed_source_index,
                'reviewed_build_sha256': args.reviewed_build_sha256,
                'owned_command_count': len(P.COMMANDS), 'loader_query_count': len(P.QUERIES),
                'elapsed_seconds': time.monotonic() - started,
                'elapsed_after_lock': None if active is None else time.monotonic() - active,
                'performance_measurement': False, 'host_stability_qualified': False}
            save(RESULTS / ('stage-' + args.stage + '.json'), result)
            save(RESULTS / (args.stage + '-closure.json'), {**result, 'payloads': payloads(args.stage)})
    if failure is not None:
        raise failure
    if postfailure is not None:
        raise postfailure


if __name__ == '__main__':
    main()
