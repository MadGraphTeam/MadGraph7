# Private normal checked RUN-only successor

This successor reuses the unchanged checked executable from closed build
`3071f3887244a34ebdf134e3867484cae6ddec9a6623309d3668d8817d26f09a`.
Its original build receipt is `f172832d12ef1a568467fe44bd3ec2c80f8f9717c628e1ab689a3773a57e0145`;
the scientific source remains `7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9`.
There is no compilation or link stage in this controller. Native execution still
requires separate review of its final source index and explicit RUN admission.

The original controllerfd482 RUN closed failed754078 after one ordinary bootstrap
and graceful BYE. Its comparator expected `scientific_source_index_sha256` inside
the low-level build receipt, while the builder wrote that metadata into the
separately closed build summary. No CMS20 measurement was requested. Original
receipts, source, specification, failure and raw files remain unchanged.

The corrected resolver authenticates original controllerfd482→build3071→summary
4a32825→receiptf172→scientific7dab, including actual current source/object/module,
archive, prelink, provider and executable pins. It returns the original receipt
without adding fields or relabeling history. New worker specifications separately
bind the new controller index, donor build sourcefd482, closure3071 and receiptf172.
The scientific Fortran, recorder, driver, native owner, cards, thresholds, cache,
libraries and numerical eligibility gates are unchanged.

`compare.retrospective_bootstrap_gate` is an explicit file-only regression. It
authenticates all20 closed failed-run payloads and feeds the original specification,
READY snapshot/map and retained bootstrap files through the same complete gate as
a future worker. The historical source identity and paths are not rewritten.
This verifies provenance, protocol, source geometry, host lifecycle, ordinary full
coefficient agreement and separate universal pole consistency together. The
result is labeled retrospective; original run/gate failure remains recorded and
no measurement is sent. Preseal preparation records current source hashes before
and after; final CLI admission authenticates the sealed successor source.

The CLI accepts RUN only. Its default path performs full file-only preflight,
including retrospective bootstrap qualification, and creates no executor:

```sh
source tools/tirust_env.sh
python3 -B .tirust-build/kinematic-normal-checked-controller-2/run.py run --reviewed-source-index <successor-index-sha256> --reviewed-build-sha256 3071f3887244a34ebdf134e3867484cae6ddec9a6623309d3668d8817d26f09a
python3 -B -m unittest discover -s .tirust-build/kinematic-normal-checked-controller-2 -p 'test_*.py' -v
```

Adding `--execute` is a separately reviewed action. It clones the original checked
build into ignored executor2, queries the admitted loader once, and starts exactly
one fresh backend9 worker: ordinary point1 bootstrap, then CMS20 only after the
live READY gate passes. No retry, extra bootstrap, recompilation or alternative
library is introduced. The shared lock, owned process cleanup, nonexclusive CPU12,
4GiB cap and960s active-stage bound are inherited. That stage work deadline excludes
file-only preflight, lock acquisition and final verification, as in the original
controller. One worker retains180s bootstrap/600s measurement protocol limits.

Return219 qualifies only an observed complete DP1/2 epoch. Return323 requires
handled DP failure, reset, genuine QP producer lineage, successful QP4/5 passes and
an exact26-group primary mode4 input/canonical join to closed matched9. CMS20
coefficient comparisons require both eligible matched8 and9 controls. Born, finite,
single/double poles and orders0/1 are retained separately; existing3e-6 regression
and1e-8 target criteria remain. Host stability, rescue coverage, engine agreement
and universal pole consistency are distinct checks, without broad accuracy or
performance claims. Precise timings remain Hua-Sheng's local TODO.
