# RUN-only correction and regression scope

The sole functional correction is joining the actual build-summary provenance
instead of expecting a nonexistent science field in the original H.link_one
receipt. The original fd482 source and3071/f172 build remain immutable. Scientific
source7dab and installed libraries are unchanged; the successor has no build path.
The original failed RUN754078 remains failed, including its admission receipt.

The original64 pure tests did not exercise compare._build against the actual
produced checked build receipt; synthetic downstream tests mocked that resolver.
New actual-data regressions reproduce the original KeyError, authenticate the
unchanged real producer schema, verify corrected summary/receipt/source linkage,
reject mutated actual metadata/specification/READY evidence, and exercise the
complete retrospective saved-bootstrap gate before successor sealing.

Retrospective and live paths share _bootstrap_snapshot_gate. Only raw-file location
and explicit old/new specification compatibility differ. The old specification
is consumed unchanged with fd482; a live specification must identify the newly
sealed controller plus the fixed donor closure/source. The native owner remains
byte-identical to fd482, and worker_entry changes only executor1→executor2.

The retained-bootstrap diagnostic is not a new native trial or a repair of
historical status. It cannot request RUN. Failed tensor outputs remain opaque.
Actual measurement is still gated on a fresh ordinary bootstrap, complete accepted
host/native epochs, exact source geometry and all existing output checks. No
floating-point, threshold, mass policy, model, precision or cache changes occur.
