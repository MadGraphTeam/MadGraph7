"""Pure source-bound QED pole consistency checks after checked-output admission.

The caller authenticates its trace and supplies the actual accepted primary-pass
route-3 group plus the parser/geometry proof. This adapter independently replays
the immutable pole audits, uses their model/charge convention on the current
captured leaves, and keeps pole consistency separate from host or finite truth.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import re
import types

ROOT=Path(__file__).resolve().parents[2]
AUDITS={
 'double':('cms-universal-qed-pole-audit-1','1565ac55fe6aeeefbd4f660455c422c4b954737a434d27138cbe8433d9534b77'),
 'single':('cms-universal-qed-single-pole-audit-1','99603d41d662e90f071b8052eb4303bcba8af451c5c96654febc276e620ad11e')}
OLD=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
COMPARE_SHA='ecce1e1f99f0de7d1798880cc9137251b4e553accc708f3cee357ed794b99272'
HEX=re.compile(r'[0-9A-F]{32}\Z')
HEX64=re.compile(r'[0-9A-F]{16}\Z')


def require(ok,message):
 if not ok:raise ValueError(message)


def pin(raw):
 return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
 raw=Path(path).read_bytes();actual=pin(raw)
 require(actual['sha256']==expected if isinstance(expected,str) else actual==expected,
         'Changed pinned pole input: '+str(path))
 return raw


def module(path,raw):
 result=types.ModuleType('private_pole_'+Path(path).parent.name);result.__file__=str(path)
 exec(compile(raw,str(path),'exec'),result.__dict__)
 return result


def references():
 """Authenticate before parsing/import, then exactly replay both saved results."""
 result={};evidence={}
 for key,(directory,seal) in AUDITS.items():
  root=ROOT/'docs/benchmarkfolder/experiments'/directory
  raw=checked(root/'evidence-index.json',seal);index=json.loads(raw)
  evidence[str((root/'evidence-index.json').relative_to(ROOT))]=pin(raw)
  payloads={}
  for name,identity in index['files'].items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe audit path')
   payloads[name]=checked(root/name,identity)
   evidence[str((root/name).relative_to(ROOT))]=identity
  helper=module(root/'source/calculate.py',payloads['source/calculate.py'])
  replay=helper.calculate()
  require(replay==json.loads(payloads['source/result.json']),'Retained pole replay differs')
  result[key]={'module':helper,'result':replay,'payloads':payloads}
 oldindex=json.loads(checked(OLD/'index.json',OLD_SHA))
 require(oldindex['files']['amplitude_compare.py']['sha256']==COMPARE_SHA,'Comparison derivation differs')
 compare_raw=checked(OLD/'amplitude_compare.py',oldindex['files']['amplitude_compare.py'])
 result['legacy']=module(OLD/'amplitude_compare.py',compare_raw)
 evidence[str((OLD/'index.json').relative_to(ROOT))]=pin((OLD/'index.json').read_bytes())
 evidence[str((OLD/'amplitude_compare.py').relative_to(ROOT))]=pin(compare_raw)
 result['source_evidence']=evidence
 return result


def finite_word(word,width):
 if not isinstance(word,str) or not HEX.fullmatch(word) or width not in (64,128):return False
 bits=int(word,16)
 if bits>>width:return False
 f,e=(52,11) if width==64 else (112,15)
 return (bits>>f)&((1<<e)-1)!=(1<<e)-1


def _proof(input_proof,phase,refs):
 require(type(phase) is int and phase in (0,1),'Unknown pole phase')
 require(isinstance(input_proof,dict) and set(input_proof)=={'qualification','group','physical_card','point_pin'},
         'Pole input proof schema differs')
 q=input_proof['qualification'];g=input_proof['group'];point=1 if phase==0 else 20
 require(q.get('passed') is True and q.get('output_arithmetic_admitted') is True and q.get('phase')==phase,
         'Checked phase not qualified; pole coefficients remain opaque')
 require(q.get('code') in (219,323) and q.get('accepted_modes') in ([1,2],[4,5]),'Accepted epoch differs')
 require((q['code']==219)==(q['accepted_modes']==[1,2]),'Return/accepted precision differs')
 require(g.get('seq') in q.get('accepted_groups',[]) and g.get('phase')==phase and g.get('group')==3 and
         g.get('mode')==q['accepted_modes'][0] and g.get('backend')==9 and g.get('sqso')==1,
         'Expected accepted primary group3')
 width=g['width'];require((g['mode'],width,g.get('digits')) in ((1,64,53),(4,128,113)),
                         'Genuine input precision differs')
 require((g.get('n'),g.get('rank'),g.get('nc'))==(4,2,15),'Group3 shape differs')
 require(all(g.get(k)==1 for k in ('native_count','complete','stable','unchanged')) and
         all(g.get(k)==0 for k in ('status','fpe_dp','fpe_qp','early')),'Failed group remains opaque')
 proofs=[x['proof'] for x in q.get('geometry',[]) if x.get('seq')==g['seq']]
 require(len(proofs)==1 and proofs[0].get('passed') is True and
         (proofs[0].get('route'),proofs[0].get('mode'),proofs[0].get('width'))==(3,g['mode'],width) and
         isinstance(proofs[0].get('source_evidence'),dict) and bool(proofs[0]['source_evidence']),
         'Missing source-bound geometry proof')
 physical=pin(refs['double']['payloads']['source/param_card.dat'])
 point_pin=pin(refs['single']['payloads'][f'source/point{point}.dat'])
 require(input_proof['physical_card']==physical and input_proof['point_pin']==point_pin,
         'Pole model/point differs from retained convention')
 w=g['words'];require(set(('EXTERNAL','SCALE')).issubset(w),'Missing current pole input words')
 require(len(w['EXTERNAL'])==32 and len(w['SCALE'])==1 and
         all(finite_word(x,width) for x in w['EXTERNAL']+w['SCALE']),'Nonfinite/malformed current pole inputs')
 return g,proofs[0]


def _factor(g,phase,refs):
 """Same retained dot/log/charge formula, now on actual accepted input words."""
 old=refs['single']['module'];width=g['width']
 def decode(w):
  return old.binary128([w[16:],w[:16]]) if width==128 else refs['legacy'].decode64(w[16:])
 flat=list(map(decode,g['words']['EXTERNAL']))
 require(all(flat[i]==0 for i in range(1,32,2)),'Nonreal current external momentum')
 vectors=[[flat[8*leg+2*mu] for mu in range(4)] for leg in range(4)]
 require(all(v[0]<0 for v in vectors[:2]) and all(v[0]>0 for v in vectors[2:]),'Crossed momentum signs differ')
 mu2=decode(g['words']['SCALE'][0]);require(mu2>0,'Nonpositive current mu squared')
 charges=refs['single']['result']['all_outgoing_charges'];require(charges==[-1,1,1,-1],'Charge convention changed')
 pairs=[]
 with localcontext() as context:
  context.prec=70;soft=D(0)
  for i in range(4):
   for j in range(i+1,4):
    invariant=abs(2*old.dot(vectors[i],vectors[j]));require(invariant>0,'Zero pair invariant: pole formula unavailable')
    logarithm=old.decimal(invariant/mu2).ln();term=-2*charges[i]*charges[j]*logarithm;soft+=term
    pairs.append({'legs':[i+1,j+1],'charge_product':charges[i]*charges[j],
                  'invariant':old.wire(invariant),'log_pair_over_mu2':str(logarithm),'term':str(term)})
  factor=-D(6)+soft
  historical=refs['single']['result']['points'][phase]
  oldv=[[F(int(v['numerator']),int(v['denominator'])) for v in row] for row in historical['all_outgoing_vectors']]
  oldmu=historical['native_mu_squared'];oldmu=F(int(oldmu['numerator']),int(oldmu['denominator']))
  same_values=vectors==oldv and mu2==oldmu
  if same_values:require(str(factor)==historical['single_factor'],'Current identical-input factor replay differs')
  return factor,{'width':width,'group_seq':g['seq'],'mode':g['mode'],
          'current_external_words':g['words']['EXTERNAL'],'current_scale_words':g['words']['SCALE'],
          'historical_exact_input_values_equal':same_values,
          'historical_input_equality_not_assumed':True,'single_factor':str(factor),
          'historical_single_factor':historical['single_factor'],'pair_terms':pairs,
          'external_shell_residuals':old.wire([old.dot(v,v) for v in vectors]),
          'external_conservation_residual':old.wire([sum(v[a] for v in vectors) for a in range(4)])}


def _metric(observed,expected,finite,legacy):
 magnitude=max(abs(observed),abs(expected));difference=abs(observed-expected)
 symmetric=difference/abs(observed+expected) if observed+expected else F(0) if not magnitude else None
 pole=magnitude/max(abs(finite),F(1,10**99))
 def accepted(tolerance):
  return (symmetric is not None and symmetric<tolerance) or pole<tolerance
 return {'observed':legacy.wire(observed),'expected':legacy.wire(expected),
         'relative_error':legacy.wire(difference/magnitude if magnitude else F(0)),
         'symmetric_relative_error':legacy.wire(symmetric),'pole_to_finite':legacy.wire(pole),
         'passed':accepted(legacy.TOL),'ordinary_target_passed':accepted(legacy.TARGET)}


def check_poles(rows,phase,*,input_proof):
 """Return pole checks only. Failed preconditions raise before output decoding."""
 refs=references();g,geometry=_proof(input_proof,phase,refs)
 point=1 if phase==0 else 20;code=input_proof['qualification']['code']
 require(isinstance(rows,list) and len(rows)==2 and
         [(r.get('phase'),r.get('point'),r.get('order'),r.get('code')) for r in rows]==
         [(phase,point,order,code) for order in (0,1)],'Missing/wrong pole row coverage')
 require(all(r.get('eligible',True) is True and len(r.get('words',[]))==5 and
         all(isinstance(w,str) and HEX64.fullmatch(w) and finite_word(w.zfill(32),64) for w in r['words'])
         for r in rows),'Failed/nonfinite output remains opaque')
 factor,input_record=_factor(g,phase,refs);legacy=refs['legacy'];comparisons=[]
 with localcontext() as context:
  context.prec=70;alpha=D(refs['double']['result']['alpha_reconstructed']);pi=D('3.1415926535897932384626433832795')
  for row in rows:
   born,finite,single,double=map(legacy.decode64,row['words'][:4]);dborn=refs['single']['module'].decimal(born)
   for column,observed,expected in ((2,single,dborn*alpha/(2*pi)*factor),(3,double,-4*dborn*alpha/(2*pi))):
    comparisons.append({'phase':phase,'point':point,'order':row['order'],'column':column,
      'coefficient':'single_pole' if column==2 else 'double_pole','observed_word':row['words'][column],
      **_metric(observed,F(expected),finite,legacy)})
 return {'schema':'private-checked-cms-pole-consistency-v1','passed':all(x['passed'] for x in comparisons),
   'ordinary_target_passed':all(x['ordinary_target_passed'] for x in comparisons),'phase':phase,'point':point,
   'comparisons':comparisons,'failures':[x for x in comparisons if not x['passed']],
   'inputs':input_record,'source_evidence':refs['source_evidence'],'geometry_source_evidence':geometry['source_evidence'],
   'criterion':'LoopMEComparator: abs(a-b)/abs(a+b)<3e-6, or pole magnitude/finite maximum<3e-6; target1e-8 separately',
   'model':refs['double']['result']['model'],'alpha_reconstructed':str(alpha),'decimal_working_digits':70,
   'double_formula':refs['double']['result']['pole_formula'],'single_formula':refs['single']['result']['formula'],
   'amplitude_scope':refs['single']['result']['amplitude_scope'],
   'source_normalization':refs['single']['result']['source_normalization'],
   'current_trial_external_words_observed':True,'model_runtime_coupling_bits_observed':False,
   'complete_Fortran_rounding_emulated':False,'UV_cancellation_independently_measured':False,
   'normal_host_stability_qualified_by_this_adapter':False,'matched_engine_agreement_qualified_by_this_adapter':False,
   'finite_truth_qualified':False,'full_amplitude_truth_qualified':False,'performance_qualified':False,
   'failed_tensor_outputs_read':False,'native_actions':0}
