"""Pure successor provenance and command-boundary tests; no native actions."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

run=load('successor_controller_under_test',HERE/'run.py')
V=load('successor_verifier_under_test',HERE/'verify.py')


class ActualDonor(unittest.TestCase):
 def test_actual_unmodified_receipt_and_summary_compatibility(self):
  build,e=V.reviewed_donor_build(V.BUILD_SHA)
  self.assertNotIn('scientific_source_index_sha256',build)
  self.assertEqual(e['build_receipt']['sha256'],V.RECEIPT_SHA)
  self.assertEqual(e['build_summary']['sha256'],V.SUMMARY_SHA)
  self.assertEqual(e['build_source_index']['sha256'],V.PRIOR_SHA)
  self.assertEqual(e['scientific_source_index']['sha256'],V.SCIENCE_SHA)
  self.assertTrue(e['prior_run_remains_failed']);self.assertFalse(e['prior_measurement_requested'])
  self.assertEqual(e['current_build']['objects'],212)
  self.assertEqual(e['current_build']['modules'],11)
  self.assertEqual(e['current_build']['prelink_inputs'],152)
  self.assertEqual(e['current_build']['providers'],15)
  self.assertEqual(e['native_actions'],0)

 def _virtual_mutation(self,path,transform):
  original=Path.read_bytes;actual=original(path);bad=transform(actual);parsed=[]
  decoder=V.json.loads
  def read(p):return bad if p==path else original(p)
  def parse(raw,*args,**kwargs):
   parsed.append(raw);return decoder(raw,*args,**kwargs)
  with patch.object(Path,'read_bytes',read),patch.object(V,'json',SimpleNamespace(loads=parse)):
   with self.assertRaisesRegex(ValueError,'Changed bound file'):
    V.reviewed_donor_build(V.BUILD_SHA)
  self.assertNotIn(bad,parsed,'Tampered payload was parsed before its hash was checked')
  self.assertEqual(original(path),actual,'Read-only mutation changed disk')

 def test_changed_actual_summary_fails_before_parse(self):
  self._virtual_mutation(V.DONOR_RESULTS/'build-summary.json',lambda b:b+b' ')

 def test_missing_actual_summary_science_key_fails_before_parse(self):
  def remove(raw):
   d=json.loads(raw);d.pop('scientific_source_index_sha256');return json.dumps(d).encode()
  self._virtual_mutation(V.DONOR_RESULTS/'build-summary.json',remove)

 def test_changed_actual_build_receipt_fails_before_parse(self):
  self._virtual_mutation(V.DONOR_RESULTS/'builds/checked/build.json',lambda b:b+b' ')

 def test_receipt_cannot_be_relabelled_with_science(self):
  def relabel(raw):
   d=json.loads(raw);d['scientific_source_index_sha256']=V.SCIENCE_SHA;return json.dumps(d).encode()
  self._virtual_mutation(V.DONOR_RESULTS/'builds/checked/build.json',relabel)

 def test_same_hash_from_wrong_binding_path_rejected(self):
  path=HERE/'bindings.json';original=Path.read_bytes;d=json.loads(original(path))
  d['files']['checked_build']['path']='.tirust-build/unreviewed-copy/build.json'
  bad=json.dumps(d).encode()
  with patch.object(Path,'read_bytes',lambda p:bad if p==path else original(p)):
   with self.assertRaisesRegex(ValueError,'Fixed lineage/path differs: checked_build'):
    V.reviewed_donor_build(V.BUILD_SHA)

 def test_missing_binding_key_rejected(self):
  path=HERE/'bindings.json';original=Path.read_bytes;d=json.loads(original(path))
  d['files'].pop('checked_build_summary');bad=json.dumps(d).encode()
  with patch.object(Path,'read_bytes',lambda p:bad if p==path else original(p)):
   with self.assertRaisesRegex(ValueError,'binding keys/root'):
    V.reviewed_donor_build(V.BUILD_SHA)

 def test_only_original_closed_build_is_admitted(self):
  for value in (None,'',V.RECEIPT_SHA,'0'*64):
   with patch.object(V,'_fixed_bindings',side_effect=AssertionError('Read before fixed seal check')):
    with self.assertRaisesRegex(ValueError,'Explicit fixed closed-build'):
     V.reviewed_donor_build(value)


class RunOnly(unittest.TestCase):
 def test_source_index_required_before_helpers(self):
  for value in ('',None,'0'*63,'g'*64,'A'*64):
   with patch.object(run,'load',side_effect=AssertionError('Import before source admission')):
    with self.assertRaisesRegex(ValueError,'64-hex'):run.verify_source(value)

 def test_default_verifier_requires_own_seal(self):
  with patch.object(V,'_fixed_bindings',side_effect=AssertionError('Before source admission')):
   with self.assertRaisesRegex(ValueError,'Explicit sealed'):V.verify()

 def test_no_build_function_or_build_cli_stage(self):
  self.assertFalse(hasattr(run,'build'))
  with patch.object(sys,'argv',[str(HERE/'run.py'),'build','--reviewed-source-index','0'*64,
      '--reviewed-build-sha256',V.BUILD_SHA]),patch.object(run,'verify_source') as verify:
   with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):run.main()
   verify.assert_not_called()
  with self.assertRaisesRegex(ValueError,'RUN only'):run.setup_owned('build')

 def test_run_command_allowlist_rejects_compile(self):
  calls=[];fake=SimpleNamespace(command=lambda *a,**kw:calls.append((a,kw)) or 'ok')
  parent=SimpleNamespace(setup_owned=lambda stage:fake,R=SimpleNamespace())
  donor={'runtime':{'loader':'/fixed/loader'}}
  verifier=SimpleNamespace(reviewed_donor_build=lambda _: (donor,{}),BUILD_SHA=V.BUILD_SHA)
  plan=run.read(HERE/'validation-plan.json')
  with patch.object(run,'P',parent),patch.object(run,'V',verifier),patch.object(run,'PLAN',plan),patch.object(run,'H',SimpleNamespace(SUBPROCESS='P0_epem_mupmum')):
   L=run.setup_owned('run')
   for argv in (['make','-j1'],['gfortran','-c','x.f'],['/fixed/loader','--list','/wrong/check']):
    with self.assertRaisesRegex(ValueError,'Run-only command boundary'):L.command(argv,'blocked')
   self.assertFalse(calls)
   exe=run.WORK/'workers'/plan['requests'][0]['id']/'SubProcesses/P0_epem_mupmum/check'
   self.assertEqual(L.command(['/fixed/loader','--list',str(exe)],'loader'),'ok')
   self.assertEqual(L.STAGES,('run',));self.assertEqual(L.CPU,12)

 def test_donor_resolver_does_not_read_successor_build_path(self):
  original={'variant':'checked'};evidence={'build_receipt':{'sha256':V.RECEIPT_SHA}}
  verifier=SimpleNamespace(reviewed_donor_build=lambda seal:(original,evidence))
  with patch.object(run,'V',verifier),patch.object(run,'DONOR_PROVENANCE',None):
   self.assertIs(run.reviewed_build(V.BUILD_SHA),original)
   self.assertEqual(run.DONOR_PROVENANCE,evidence)

 def test_file_only_cli_runs_retrospective_without_creating_executor(self):
  with tempfile.TemporaryDirectory() as tmp:
   results=Path(tmp)/'never-created';called=[]
   comparator=SimpleNamespace(retrospective_bootstrap_gate=lambda **kw:called.append(kw) or {'passed':True})
   with patch.object(sys,'argv',[str(HERE/'run.py'),'run','--reviewed-source-index','a'*64,
       '--reviewed-build-sha256',V.BUILD_SHA]),patch.object(run,'verify_source',return_value={}),       patch.object(run,'dependency_preflight',return_value={'native_actions':0}),       patch.object(run,'reviewed_build',return_value={}),patch.object(run,'load',return_value=comparator),       patch.object(run,'RESULTS',results),contextlib.redirect_stdout(io.StringIO()):
    run.main()
   self.assertEqual(called,[{'controller_sha':'a'*64}]);self.assertFalse(results.exists())

 def test_failed_closed_bootstrap_blocks_execute_before_any_stage_write(self):
  with tempfile.TemporaryDirectory() as tmp:
   results=Path(tmp)/'never-created';comparator=SimpleNamespace(retrospective_bootstrap_gate=lambda **kw:{'passed':False})
   with patch.object(sys,'argv',[str(HERE/'run.py'),'run','--reviewed-source-index','a'*64,
       '--reviewed-build-sha256',V.BUILD_SHA,'--execute']),patch.object(run,'verify_source',return_value={}),       patch.object(run,'dependency_preflight',return_value={}),patch.object(run,'reviewed_build',return_value={}),       patch.object(run,'load',return_value=comparator),patch.object(run,'RESULTS',results):
    with self.assertRaisesRegex(ValueError,'Closed ordinary bootstrap'):run.main()
   self.assertFalse(results.exists())

 def test_policy_and_native_owner_unchanged(self):
  plan=run.read(HERE/'validation-plan.json');old=run.read(V.PRIOR/'validation-plan.json')
  self.assertEqual(plan['run'],old['run']);self.assertEqual(plan['requests'],old['requests'])
  self.assertEqual(plan['available_stages'],['run']);self.assertEqual(plan['run']['seconds_total'],960)
  self.assertEqual(plan['build']['new_compilations'],0);self.assertEqual(plan['build']['new_links'],0)
  self.assertEqual((HERE/'native_job.py').read_bytes(),(V.PRIOR/'native_job.py').read_bytes())
  self.assertEqual((HERE/'limit_exec.py').read_bytes(),(V.PRIOR/'limit_exec.py').read_bytes())
  self.assertEqual((HERE/'worker_entry.py').read_text(),(V.PRIOR/'worker_entry.py').read_text().replace(
   'kinematic-normal-checked-executor-1','kinematic-normal-checked-executor-2'))

 def test_saved_outputs_remain_append_only(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'receipt.json';run.save(path,{'original':True})
   with self.assertRaises(FileExistsError):run.save(path,{'overwrite':True})
   self.assertEqual(json.loads(path.read_bytes()),{'original':True})


class ActualDependencyBoundary(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  V.authenticate(run.OLD/'index.json',run.OLD_SHA)
  cls.parent=run.load('successor_actual_parent',run.OLD/'run.py');p=cls.parent
  p.R,p.G,p.B,p.PLAN,p.TOOLCHAIN,_=p.verify_source(run.OLD_SHA)
  p.BASE,p.WORK,p.RESULTS=run.BASE,run.WORK,run.RESULTS

 def test_real_dependency_snapshot_and_run_namespace_no_commands(self):
  with patch.object(run,'P',self.parent),patch.object(run,'V',V),       patch.object(run,'PLAN',run.read(HERE/'validation-plan.json')),       patch.object(run,'H',SimpleNamespace(SUBPROCESS='P0_epem_mupmum')):
   result=run.dependency_preflight('run')
   self.assertEqual(result,{'native_actions':0,'files':150,'private_records':3})
   L=run.setup_owned('run');seen=[]
   L.command=lambda *a,**k:seen.append((a,k)) or 'fake-query'
   self.assertEqual(L.capture(['literal-not-executed'],run.ROOT),'fake-query')
   self.assertEqual(len(seen),1);self.assertEqual(L.STAGES,('run',))


if __name__=='__main__':unittest.main()
