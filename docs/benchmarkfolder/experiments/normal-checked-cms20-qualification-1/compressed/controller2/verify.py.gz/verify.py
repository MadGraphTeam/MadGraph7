"""Run-only successor provenance/preflight; no compiler, loader or process calls."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCIENCE=ROOT/'.tirust-build/kinematic-normal-checked-source-1'
SCIENCE_SHA='7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9'  # Reviewed immutable scientific source.
MATCHED=ROOT/'.tirust-build/kinematic-matched-native-input-controller-2'
PRIOR=ROOT/'.tirust-build/kinematic-normal-checked-controller-1'
DONOR_RESULTS=ROOT/'.tirust-build/kinematic-normal-checked-executor-1/results'
PRIOR_SHA='fd482474221715397a0dff7b47244ef25a07f077e79b4b8a47c5e3beca398c03'
BUILD_SHA='3071f3887244a34ebdf134e3867484cae6ddec9a6623309d3668d8817d26f09a'
SUMMARY_SHA='4a32825da2511600228eb11c4a2dfaca2577adb8647e8fb36426cb17893a260e'
RECEIPT_SHA='f172832d12ef1a568467fe44bd3ec2c80f8f9717c628e1ab689a3773a57e0145'
FAILED_SHA='754078acb9700ffa10b9c040bc6c0de86784e4da66adaaef0e8fdcb8441985af'
PINS={
 'prior_controller':PRIOR_SHA,'checked_build_closure':BUILD_SHA,
 'checked_build_summary':SUMMARY_SHA,'checked_build':RECEIPT_SHA,'prior_failed_run':FAILED_SHA,
 'scientific_source':'7dab8a04296a44e6eef1cf017bee751491220b77804ebe2a34faa328f85cb2c9',
 'approved_plan':'9387a2858df75bf34d0940121da6e006fe7648a9d63d241276ba05f94487f7b4',
 'matched_controller':'9076a51a0be56c57fb7dda32cfec3ef9b038bec2e73dc5e751bf31dc5ac3bc41',
 'amplitude_source':'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74',
 'candidate_build_closure':'8cab371e9affd5297c0f48c30184361959d20f3d3a48c6dbd6109b86bf49bacb',
 'candidate_build':'35b556bd50d4e40f34925145d69acd1fcc4ea865a3eaea2214c44e4727a9b5e6',
 'ordinary_closure':'b364bd8535d0f5850cb5a21390c5678cbb1c1dd8fddfae6f0174cf50d261f7a7',
 'ordinary_comparison':'6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451',
 'matched_run_closure':'52faa470d8be22b81f8636edba21f5fba6c2d13be1f0241a8212a7b2055839a7',
 'matched_comparison':'af4b58a379ac35a78066a1bcad38ed3f4fe9e16e6b0d4583dbd4e6c940eba6d5',
}
COMPILED=['check_sa.o','loop_matrix.o','mp_compute_loop_coefs.o','CT_interface.o',
          'TIR_interface.o','TIRUST_interface.o','checked_trace.o']


def require(ok,message):
 if not ok: raise ValueError(message)


def pin(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
 require(pin(path)=={k:expected[k] for k in ('bytes','sha256')},'Changed bound file: '+str(path))


def authenticate(path,sha):
 require(pin(path)['sha256']==sha,'Source index changed: '+str(path))
 data=json.loads(Path(path).read_bytes())
 for name,record in data['files'].items():
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source payload')
  checked(Path(path).parent/name,record)
 return data


def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
 sys.modules[name]=module;spec.loader.exec_module(module);return module


def _fixed_bindings():
 bindings=json.loads((HERE/'bindings.json').read_bytes())
 require(bindings['root']==str(ROOT) and set(bindings['files'])==set(PINS),'Controller binding keys/root differ')
 # Every inherited path is fixed by the authenticated old controller. New
 # entries deliberately point to OLD receipts, never successor replacements.
 old=authenticate(PRIOR/'index.json',PRIOR_SHA)
 original=json.loads((PRIOR/'bindings.json').read_bytes())['files']
 expected={k:v['path'] for k,v in original.items()}
 expected.update(prior_controller=str((PRIOR/'index.json').relative_to(ROOT)),
     checked_build_closure=str((DONOR_RESULTS/'build-closure.json').relative_to(ROOT)),
     checked_build_summary=str((DONOR_RESULTS/'build-summary.json').relative_to(ROOT)),
     checked_build=str((DONOR_RESULTS/'builds/checked/build.json').relative_to(ROOT)),
     prior_failed_run=str((DONOR_RESULTS/'run-closure.json').relative_to(ROOT)))
 for key,sha in PINS.items():
  record=bindings['files'][key]
  require(record['sha256']==sha and record['path']==expected[key],'Fixed lineage/path differs: '+key)
  checked(ROOT/record['path'],record)
 return bindings,old


def _closed(path,sha,*,passed):
 require(pin(path)['sha256']==sha,'Closed stage hash differs')
 record=json.loads(path.read_bytes())
 require(record['source_index_sha256']==PRIOR_SHA and record['passed'] is passed and
         record['postcheck_failure'] is None,'Historical stage identity/status differs')
 for name,identity in record['payloads'].items():
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe historical payload')
  checked(path.parent/name,identity)
 return record


def _inventory(output):
 suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
 return {str(p.relative_to(ROOT)):pin(p)
         for subtree in ('Source','SubProcesses')
         for p in sorted((output/subtree).rglob('*'))
         if p.is_file() and (p.suffix.lower() in suffixes or p.name.startswith('makefile')
             or p.name in ('make_opts','MadLoop_makefile_definitions'))}


def _current_build(item):
 output=DONOR_RESULTS.parent/'work/builds/cms/checked'
 executable=output/'SubProcesses/P0_epem_mupmum/check'
 require(item['variant']=='checked' and item['case']=='cms' and item['output']==str(output) and
         item['executable']==str(executable),'Closed donor path/variant differs')
 require('scientific_source_index_sha256' not in item,'Original build schema was relabeled')
 require(item['compiled_targets']==COMPILED and item['fortran_main_calls']==0 and
         item['tensor_evaluations']==0 and item['library_rebuilds'] is False,'Closed build boundary differs')
 require(_inventory(output)==item['sources'] and len(item['sources'])==275,'Donor source inventory differs')
 counts={'all_objects_after':212,'modules_after':11,'reused_libraries':4,'prelink_bound':152}
 for key,count in counts.items():
  require(len(item[key])==count,'Donor count differs: '+key)
 for key in ('all_objects_after','modules_after','reused_libraries'):
  for name,identity in item[key].items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe donor object path')
   checked(output/name,identity)
 require(len(item['runtime']['files'])==15,'Donor provider count differs')
 for path,sha in {**item['prelink_bound'],**item['runtime']['files']}.items():
  require(Path(path).is_absolute() and pin(path)['sha256']==sha,'Donor link/provider input changed: '+path)
 checked(executable,item['executable_pin'])
 checked(output/'Cards/param_card.dat',item['physical_card'])
 require((output/'Cards/MadLoopParams.dat').read_bytes()==(HERE/'backend9-auto-MadLoopParams.dat').read_bytes(),
         'Donor numerical card differs')
 # Join the actual compiled source bytes to the sealed scientific packet.
 source=authenticate(SCIENCE/'index.json',SCIENCE_SHA)
 directory=output/'SubProcesses/P0_epem_mupmum'
 for target,origin in [('check_sa.f','driver-checked.f'),('checked_trace.f90','checked_trace.f90')]+[
    (name,'candidate/'+name) for name in ('CT_interface.f','TIRUST_interface.f','TIR_interface.f',
                                        'loop_matrix.f','mp_compute_loop_coefs.f')]:
  require(pin(directory/target)==source['files'][origin],'Compiled scientific source differs: '+target)
 return {'sources':275,'objects':212,'modules':11,'libraries':4,'prelink_inputs':152,'providers':15,
         'executable':item['executable_pin'],'native_actions':0}


def reviewed_donor_build(expected_closure_sha):
 """Return the ORIGINAL f172 record and a separate authenticated ancestry."""
 require(expected_closure_sha==BUILD_SHA,'Explicit fixed closed-build review required')
 bindings,old=_fixed_bindings()
 closure=_closed(DONOR_RESULTS/'build-closure.json',BUILD_SHA,passed=True)
 require(closure['stage']=='build' and closure['failure'] is None and closure['reviewed_build_sha256'] is None and
         len(closure['payloads'])==138,'Closed build scope differs')
 sp=bindings['files']['checked_build_summary'];bp=bindings['files']['checked_build']
 require(closure['payloads']['build-summary.json']=={k:sp[k] for k in ('bytes','sha256')} and
         closure['payloads']['builds/checked/build.json']=={k:bp[k] for k in ('bytes','sha256')},
         'Closed build payload linkage differs')
 summary=json.loads((DONOR_RESULTS/'build-summary.json').read_bytes())
 item=json.loads((DONOR_RESULTS/'builds/checked/build.json').read_bytes())
 build_pin={k:bp[k] for k in ('bytes','sha256')}
 require(summary['checked_build']==build_pin and summary['scientific_source_index_sha256']==SCIENCE_SHA,
         'Summary build/scientific-source binding differs')
 require(summary['executable']==item['executable'] and summary['executable_pin']==item['executable_pin'] and
         summary['executables']==1 and summary['compiled_objects']==COMPILED and
         summary['native_main_calls']==summary['tensor_calls']==0 and
         summary['scientific_library_rebuilds'] is False,'Summary executable/build boundary differs')
 current=_current_build(item)
 failed=_closed(DONOR_RESULTS/'run-closure.json',FAILED_SHA,passed=False)
 require(failed['stage']=='run' and failed['reviewed_build_sha256']==BUILD_SHA and
         failed['failure']=="RuntimeError('Command returned 1')" and len(failed['payloads'])==20,
         'Prior failed-run ancestry differs')
 worker=DONOR_RESULTS/'runs/cms-p20-auto-lib9-checked'
 receipt=json.loads((worker/'bootstrap-gate.json').read_bytes())
 result=json.loads((worker/'result.json').read_bytes())
 require(receipt['passed'] is False and receipt['failures']==["'scientific_source_index_sha256'"] and
         result['bootstrap_gate_passed'] is False and result['measurement_command_attempted'] is False and
         result['measurement_completed'] is False and result['native_returncode']==0 and
         result['cleanup_failure'] is None and all(x['complete'] and x['worker_closed'] and x['returncode']==0
                                                  for x in result['close_receipts']),
         'Prior failure/cleanup classification differs')
 return item,{'build_receipt':build_pin,'build_receipt_path':str(DONOR_RESULTS/'builds/checked/build.json'),
     'build_closure':pin(DONOR_RESULTS/'build-closure.json'),'build_summary':pin(DONOR_RESULTS/'build-summary.json'),
     'build_source_index':pin(PRIOR/'index.json'),'scientific_source_index':pin(SCIENCE/'index.json'),
     'prior_failed_run':pin(DONOR_RESULTS/'run-closure.json'),'prior_run_remains_failed':True,
     'prior_measurement_requested':False,'prior_controller_payloads':len(old['files']),
     'closed_build_payloads':138,'prior_failed_payloads':20,'current_build':current,'native_actions':0}


def expected_native_job():
 authenticate(PRIOR/'index.json',PRIOR_SHA)
 return (PRIOR/'native_job.py').read_text()


def verify(expected=None,*,allow_pending=False):
 own=authenticate(HERE/'index.json',expected) if expected is not None else None
 require(own is not None or allow_pending,'Explicit sealed controller index required')
 bindings,old=_fixed_bindings()
 # Preserve all earlier recipe, science inverse-proof, dependency, and source
 # checks using their authenticated old implementation and original identity.
 prior=load('checked_prior_file_verifier',PRIOR/'verify.py')
 previous=prior.verify(PRIOR_SHA)
 require(previous['passed'] is True and previous['native_admission_ready'] is True,'Prior source preflight failed')
 build,provenance=reviewed_donor_build(BUILD_SHA)
 for name in ('limit_exec.py','native_job.py','pole_checks.py','backend9-auto-MadLoopParams.dat',
              'inputs/cms-param_card.dat','inputs/cms-point1.dat','inputs/cms-point20.dat'):
  require((HERE/name).read_bytes()==(PRIOR/name).read_bytes(),'Unchanged successor payload differs: '+name)
 expected_worker=(PRIOR/'worker_entry.py').read_text().replace(
     'kinematic-normal-checked-executor-1','kinematic-normal-checked-executor-2')
 require((HERE/'worker_entry.py').read_text()==expected_worker,'Worker successor path derivative differs')
 plan=json.loads((HERE/'validation-plan.json').read_bytes())
 oldplan=json.loads((PRIOR/'validation-plan.json').read_bytes())
 for key in ('requests','run','cpu','cpu_exclusive','force_stability_check','cache','pole_mode',
             'requested_precision','retry','scientific_source_index_sha256','approved_plan_index_sha256'):
  require(plan[key]==oldplan[key],'Successor policy differs: '+key)
 require(plan['available_stages']==['run'] and plan['executor']=='kinematic-normal-checked-executor-2' and
         plan['separate_build_review_required'] is True and plan['prior_failed_run_sha256']==FAILED_SHA,
         'Successor scope differs')
 require(plan['build']=={'reuse_only':True,'new_compilations':0,'new_links':0,'native_main_calls':0,
     'loader_queries':0,'reviewed_closure_sha256':BUILD_SHA,'original_receipt_sha256':RECEIPT_SHA,
     'original_source_index_sha256':PRIOR_SHA},'Build reuse contract differs')
 return {'passed':True,'scope':'run-only successor; file-only compatibility and current inputs',
     'native_admission_ready':own is not None,'controller_payloads':0 if own is None else len(own['files']),
     'prior_source_preflight':previous,'donor_build':provenance,'scientific_source_pending':False,
     'native_actions':0,'historical_run_reclassified':False}


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--reviewed-source-index');parser.add_argument('--pending-source-preflight',action='store_true')
 args=parser.parse_args()
 print(json.dumps(verify(args.reviewed_source_index,allow_pending=args.pending_source_preflight),indent=2,sort_keys=True))


