"""Actual closed-bootstrap regressions. Never starts a process or reads failed tensors."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest
import compare as M

BUILD_SHA='f172832d12ef1a568467fe44bd3ec2c80f8f9717c628e1ab689a3773a57e0145'
SUMMARY_SHA='4a32825da2511600228eb11c4a2dfaca2577adb8647e8fb36426cb17893a260e'
OLD=M.ROOT/'.tirust-build/kinematic-normal-checked-controller-1'


def actual_records():
    index,oldraw=M.packet(OLD,M.DONOR_CONTROLLER_SHA)
    closed=json.loads(M.checked(M.DONOR_RESULTS/'build-closure.json',M.DONOR_BUILD_SHA))
    build_raw=M.checked(M.DONOR_RESULTS/'builds/checked/build.json',closed['payloads']['builds/checked/build.json'])
    summary_raw=M.checked(M.DONOR_RESULTS/'build-summary.json',closed['payloads']['build-summary.json'])
    assert M.pin(build_raw)['sha256']==BUILD_SHA and M.pin(summary_raw)['sha256']==SUMMARY_SHA
    failed=json.loads(M.checked(M.DONOR_RESULTS/'run-closure.json',M.FAILED_RUN_SHA))
    prefix='runs/'+M.REQUEST['id']+'/'
    directory=M.DONOR_RESULTS/'runs'/M.REQUEST['id']
    spec=json.loads(M.checked(directory/'specification.json',failed['payloads'][prefix+'specification.json']))
    native=json.loads(M.checked(directory/'result.json',failed['payloads'][prefix+'result.json']))
    return {'oldraw':oldraw,'build':json.loads(build_raw),'build_pin':M.pin(build_raw),
            'summary':json.loads(summary_raw),'failed':failed,'directory':directory,'spec':spec,'native':native}


class RealClosedBootstrap(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.actual=actual_records()
    def test_real_producer_shape_reproduces_original_consumer_failure(self):
        a=self.actual
        self.assertNotIn('scientific_source_index_sha256',a['build'])
        self.assertEqual(a['summary']['scientific_source_index_sha256'],M.SCIENCE_SHA)
        self.assertEqual(a['summary']['checked_build'],a['build_pin'])
        old=M.module(OLD/'compare.py',a['oldraw']['compare.py'])
        with self.assertRaisesRegex(KeyError,'scientific_source_index_sha256'):
            old._build(M.DONOR_RESULTS/'runs')
    def test_actual_old_spec_and_READY_map_pass_unchanged(self):
        a=self.actual;original=copy.deepcopy(a['spec'])
        M._spec(a['directory'],a['spec'],M.DONOR_CONTROLLER_SHA,a['build'],a['build_pin'],historical=True)
        M._protocol(a['native']['protocol'][:1],a['native']['runtime_maps'],a['directory'],a['spec']['expected_runtime'],bootstrap=True)
        self.assertEqual(a['spec'],original)
    def test_changed_actual_spec_is_rejected_before_output_interpretation(self):
        a=self.actual
        for key in ('scientific_source_index_sha256','build_receipt_sha256','source_index_sha256'):
            changed=copy.deepcopy(a['spec']);changed[key]='0'*64
            with self.assertRaisesRegex(ValueError,'Pinned bytes changed'):
                M._spec(a['directory'],changed,M.DONOR_CONTROLLER_SHA,a['build'],a['build_pin'],historical=True)
    def test_changed_actual_READY_or_map_is_rejected(self):
        a=self.actual;protocol=copy.deepcopy(a['native']['protocol'][:1]);protocol[0][1]='2'
        with self.assertRaisesRegex(ValueError,'READY'):
            M._protocol(protocol,a['native']['runtime_maps'],a['directory'],a['spec']['expected_runtime'],bootstrap=True)
        maps=copy.deepcopy(a['native']['runtime_maps']);maps[0]['elf']={}
        with self.assertRaisesRegex(ValueError,'closure'):
            M._protocol(a['native']['protocol'][:1],maps,a['directory'],a['spec']['expected_runtime'],bootstrap=True)
    def test_full_actual_closed_bootstrap_gate_preserves_historical_failure(self):
        result=M.retrospective_bootstrap_gate()
        self.assertTrue(result['passed'],result['failures'])
        self.assertTrue(result['retrospective_only']);self.assertFalse(result['original_run_passed'])
        self.assertFalse(result['original_bootstrap_gate_passed']);self.assertTrue(result['original_failure_preserved'])
        self.assertEqual(result['retained_payloads_verified'],20)
        self.assertFalse(result['measurement_requested']);self.assertEqual(result['new_native_actions'],0)
        self.assertEqual(result['phase']['host_qualification']['accepted_modes'],[1,2])
        self.assertEqual(result['phase']['host_qualification']['native_calls'],52)
        self.assertTrue(result['phase']['full_coefficients_passed']);self.assertTrue(result['phase']['pole_checks']['passed'])
        self.assertFalse(result['phase']['rescue_exercised'])
        self.assertFalse((M.ROOT/'.tirust-build/kinematic-normal-checked-executor-2').exists())


if __name__=='__main__':unittest.main()
