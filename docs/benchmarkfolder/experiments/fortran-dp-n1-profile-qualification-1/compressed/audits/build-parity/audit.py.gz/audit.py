"""Independent pure replay: file/JSON/log/ELF bytes only; no subprocess APIs."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-2'
EXECUTION = ROOT / 'docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-2'
SOURCE_SHA = 'e633405b99d782ad6cf021be875b258f13e5669a7113c3890c40fa36eca6160f'
PINS = {
    'build': ('16b15cc8db66880abf1fbf127ec0c2ceef2c9226446e30bd7fd6ab61b85c7470',
              'fc680d285024c3136904d9f45f9ccd2b7d68d2423b884124938ac4cd7a4956b2'),
    'parity': ('4f34848d7888a562dc631bbe5792c65a296dc3b7516b19ab284a9627c25d07f7',
               '1416b8e74e4f311e860cfc8d6ce6132d8df4b5727d444bf1b33019b1dbf1a583'),
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def json_normal(value):
    return json.loads(json.dumps(value))


def interpreter(path):
    raw = Path(path).read_bytes()
    require(raw[:6] == b'\x7fELF\x02\x01', 'Expected little-endian ELF64')
    offset = struct.unpack_from('<Q', raw, 32)[0]
    width, count = struct.unpack_from('<HH', raw, 54)
    values = []
    for index in range(count):
        row = offset + index * width
        if struct.unpack_from('<I', raw, row)[0] == 3:
            start = struct.unpack_from('<Q', raw, row + 8)[0]
            length = struct.unpack_from('<Q', raw, row + 32)[0]
            values.append(raw[start:start + length].rstrip(b'\0').decode())
    require(len(values) == 1, 'Ambiguous PT_INTERP')
    return values[0]


def commands(folder):
    categories = collections.Counter()
    for path in sorted(folder.glob('*.command.json')):
        record = read(path)
        name = path.name.removesuffix('.command.json')
        terminal = read(folder / (name + '.terminal.json'))
        require(terminal['returncode'] == 0, 'Recorded command failed: ' + name)
        require(sha(folder / (name + '.stdout.txt')) == terminal['stdout_sha256'],
                'Recorded stdout hash changed: ' + name)
        argv = record['argv']
        if '-c' in argv:
            category = 'object_compiles'
        elif name == '05-link':
            category = 'links'
        elif name.startswith('prelink-query-'):
            category = 'prelink_compiler_queries'
            require(len(argv) == 2 and argv[1].startswith(('-print-file-name=', '-print-search-dirs')),
                    'Unexpected prelink query')
        elif name.startswith(('06-', '07-')):
            category = 'nm_queries'
        elif name == 'expanded-check':
            category = 'expanded_make'
        else:
            category = 'runtime_loader_queries'
            require('--list' in argv, 'Unexpected remaining recorded command')
        categories[category] += 1
    return dict(categories)


def stage(name):
    folder = EXECUTION / name
    terminal, result = read(folder / 'terminal.json'), read(folder / 'result.json')
    require(sha(folder / 'terminal.json') == PINS[name][0], 'Terminal pin: ' + name)
    require(sha(folder / 'result.json') == PINS[name][1], 'Result pin: ' + name)
    require(terminal['status'] == result['status'] == 'passed' and terminal['returncode'] == 0,
            'Unsuccessful stage: ' + name)
    require(not terminal['cleanup']['survivors'], 'Cleanup unresolved: ' + name)
    require(terminal['result_sha256'] == PINS[name][1] and
            terminal['source_index_sha256'] == result['source_index_sha256'] == SOURCE_SHA,
            'Broken source/result join: ' + name)
    actual = read(folder / 'actual-limits.json')['actual']
    require(actual == {key: [value, value] for key, value in terminal['resource_limits'].items()},
            'Actual resource limit mismatch: ' + name)
    return result


def definitions(path):
    out = {}
    for line in Path(path).read_text().splitlines():
        fields = line.split()
        if len(fields) >= 3 and '__mtirust_MOD_' in fields[-1]:
            out[fields[-1]] = out.get(fields[-1], 0) + 1
    return out


def main():
    require(sha(SOURCE / 'source-index.json') == SOURCE_SHA, 'Source seal changed')
    seal = read(SOURCE / 'source-index.json')
    require({str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file()} ==
            set(seal['files']) | {'source-index.json'}, 'Source exact inventory changed')
    for name, row in seal['files'].items():
        require(sha(SOURCE / name) == row['sha256'] and
                (SOURCE / name).stat().st_size == row['bytes'], 'Changed source: ' + name)
    for name, checksum in seal['support'].items():
        require(sha(ROOT / name) == checksum, 'Changed support: ' + name)
    pin = read(SOURCE / 'input-pins.json')
    build = stage('build')
    built = {}
    for variant, row in build['variants'].items():
        output = Path(row['output'])
        process = output / 'SubProcesses/P0_uux_z'
        actual, original = row['compiler_flags'], pin['compiler_flags']
        require(actual['environment'] == original['environment'] == {}, 'Compiler injection drift')
        for scope, old in original['scopes'].items():
            recipes = actual['scopes'][scope]['recipes']
            extra = {'qp_profile.f90', 'mtirust.f90'} if scope == 'process' else set()
            require(set(recipes) == set(old['recipes']) | extra, 'Compiler recipe inventory')
            for name, recipe in old['recipes'].items():
                require(recipe['compiler'] == recipes[name]['compiler'] and
                        recipe['flags'] == recipes[name]['flags'], 'Compiler policy drift: ' + name)
            for name in extra:
                require(recipes[name]['flags'] == ['-O3', '-fPIC'], 'Private module recipe drift')
        for name, checksum in row['sources'].items():
            require(sha(output / name) == checksum, 'Generated source changed: ' + name)
        for name, checksum in row['objects'].items():
            require(sha(output / name) == checksum, 'Object changed: ' + name)
        # The clone intentionally replaces lib/ with a read-only directory symlink.
        # Its archive/module members are covered by prelink inputs, not rglob objects.
        prefix = 'SubProcesses/P0_uux_z/'
        changed = {prefix + name for name in ('TIR_interface.o', 'TIRUST_interface.o', 'check_sa.o')}
        added = {prefix + name for name in ('mtirust.o', 'qp_profile.o', 'mtirust.mod', 'dp_profile_state.mod')}
        old_objects = {name: value for name, value in pin['numerical_objects'].items()
                       if name not in changed and not name.startswith('lib/')}
        new_objects = {name: value for name, value in row['objects'].items() if name not in changed | added}
        require(old_objects == new_objects, 'Frozen nonprofile object changed')
        require(sha(process / 'check') == row['executable_sha256'], 'Executable changed')
        require(sha(process / 'private-link.map') == row['link_map_sha256'], 'Link map changed')
        prelink_path = EXECUTION / 'build' / variant / 'prelink.json'
        require(sha(prelink_path) == row['prelink_sha256'], 'Prelink receipt changed')
        prelink = read(prelink_path)
        for name, checksum in prelink['bound'].items():
            require(sha(name) == checksum, 'Prebound file changed: ' + name)
        link_map = (process / 'private-link.map').read_text()
        loads = {str((process / name).resolve()): sha((process / name).resolve())
                 for name in re.findall(r'^LOAD\s+(.+)$', link_map, re.M)}
        require(loads == row['actual_link_loads'] and len(loads) == 54, 'Actual LOAD mismatch')
        require(all(prelink['bound'].get(name) == value for name, value in loads.items()), 'Unbound LOAD')
        require('LOAD mtirust.o' in link_map and
                not re.search(r'libtirust\.a\([^)]*mtirust[^)]*\)', link_map), 'MTIRUST precedence changed')
        for name, checksum in row['runtime']['files'].items():
            require(sha(name) == checksum, 'Runtime provider changed: ' + name)
        require(interpreter(process / 'check') == row['runtime']['loader'], 'Actual PT_INTERP changed')
        log_root = EXECUTION / 'build' / variant / 'commands'
        own = definitions(log_root / '06-module-symbols.stdout.txt')
        require(own == definitions(log_root / '07-executable-symbols.stdout.txt') ==
                row['symbols']['definitions'] and len(own) == 23 and set(own.values()) == {1}, 'MTIRUST symbol proof')
        counts = commands(log_root)
        require(counts == {'object_compiles': 5, 'links': 1, 'nm_queries': 2,
                           'expanded_make': 1, 'prelink_compiler_queries': 51,
                           'runtime_loader_queries': 1}, 'Recorded build action count')
        built[variant] = {'recorded_commands': counts, 'actual_LOADs': 54,
                          'runtime_providers': len(row['runtime']['files']), 'MTIRUST_definitions': 23,
                          'compiler_injected_environment': actual['environment']}
        require(built[variant]['runtime_providers'] == 15, 'Provider count')
    parity = stage('parity')
    require(parity['build_terminal_sha256'] == PINS['build'][0], 'PARITY BUILD join')
    spec = importlib.util.spec_from_file_location('independent_n1_pure_parser', SOURCE / 'analyze.py')
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    lanes = {}
    baseline_raw = None
    baseline_words = None
    original_warmup = Path(pin['closed_observation']).with_name('warmup.dat').read_bytes()
    for lane in ('baseline', 'observed-0', 'observed-1', 'observed-2'):
        folder = EXECUTION / 'parity' / lane
        observed = lane != 'baseline'
        mode = int(lane[-1]) if observed else 0
        exact_folder = folder / 'exact'
        raw = tuple((exact_folder / name).read_bytes() for name in ('dp-exact.dat', 'dp-ieee.dat'))
        if baseline_raw is None:
            baseline_raw = raw
        require(raw == baseline_raw, 'Raw word/IEEE parity failed: ' + lane)
        replay = {'rows': parser.exact(raw[0].decode()), 'ieee': parser.ieee(raw[1].decode()),
                  'profile': parser.profile((exact_folder / 'dp-parity-timers.tsv').read_text(), mode, 100, observed),
                  'probe': parser.probe((exact_folder / 'dp-probe.tsv').read_text())}
        require(json_normal(replay) == parity['lanes'][lane], 'Raw parser/result join: ' + lane)
        warmup = read(folder / 'warmup.json')
        require(warmup['raw_outputs']['warmup.dat'].encode() == original_warmup, 'Full learning bytes changed: ' + lane)
        require(warmup['rows'] == read(pin['closed_observation'])['rows'], 'Full learning row join: ' + lane)
        require(read(folder / 'private-before.json') == read(folder / 'private-after.json'), 'Private input change: ' + lane)
        variant = 'observed' if observed else 'baseline'
        expected = build['variants'][variant]
        private = read(folder / 'private-before.json')
        require(private['executable_sha256'] == expected['executable_sha256'], 'Private executable join')
        require(private['physical_sha256'] == read(pin['closed_input'])['param_card_sha256'], 'Physical card join')
        alias = 'SubProcesses/P0_uux_z/MadLoop5_resources/MadLoopParams.dat'
        require(private['cards'] == {**pin['numerical_cards'], alias: next(iter(pin['numerical_cards'].values()))},
                'Private four-card inventory')
        for phase in ('before', 'after'):
            mapped = read(folder / ('maps-' + phase + '.json'))['files']
            require(all(mapped.get(name) == value for name, value in expected['runtime']['files'].items()),
                    'Mapped provider join: ' + lane)
            allowed = {**expected['runtime']['files'], **seal['allowed_extra_mappings']}
            remaining = {name: value for name, value in mapped.items() if allowed.get(name) != value}
            require(len(remaining) == 1 and next(iter(remaining.values())) == expected['executable_sha256'],
                    'Unexpected actual mapping: ' + lane)
        require(commands(folder / 'commands') == {'runtime_loader_queries': 2}, 'Parity recorded loader query count')
        lanes[lane] = {'raw_word_rows': len(replay['rows']), 'actual_IEEE_rows': len(replay['ieee']),
                       'statuses': sorted({row['status'] for row in replay['rows']}),
                       'native_request_counters': replay['profile']['request_counters'],
                       'full_learning_bytes_identical': True, 'actual_runtime_maps_joined': True}
    require(not (EXECUTION / 'profile').exists(), 'Unexpected PROFILE stage')
    report = {'schema': 'independent-n1-build-parity-audit-v1', 'status': 'PASS',
              'source_index_sha256': SOURCE_SHA, 'stage_pins': PINS, 'build': built, 'parity': lanes,
              'blocking_defects': [], 'compiler_invocations_by_auditor': 0,
              'loader_queries_by_auditor': 0, 'native_numerical_evaluations_by_auditor': 0,
              'PROFILE_observed': False, 'performance_acceptance': False,
              'recorded_query_count_scope': {
                  'build_recorded_commands': 122, 'build_recorded_prelink_compiler_queries': 102,
                  'build_recorded_runtime_loader_queries': 2, 'parity_recorded_runtime_loader_queries': 8,
                  'unseparately_logged_capture_effective_flags_calls': 4,
                  'implied_helper_make_dryruns': 12, 'implied_helper_compiler_version_queries': 4,
                  'limitation': 'Make parsing also executes shell queries (uname/compiler-version/grep). Individual child processes of tools are not exhaustively logged; recorded actions are not a total native-process count.'},
              'limitations': ['PARITY clocks and empty probes are qualification records, not accepted timing evidence.',
                              'IEEE state equality observes sticky flags; true-to-true does not identify newly raised exceptions.',
                              'Cleanup qualification is limited to retained observed descendants with matching process-start/session identities.',
                              'Exact agreement of unchanged algorithms is not independent physical truth or performance acceptance.']}
    with (HERE / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'report': str(HERE / 'report.json'),
                      'report_sha256': sha(HERE / 'report.json'), 'auditor_native_executions': 0}))


if __name__ == '__main__':
    main()
