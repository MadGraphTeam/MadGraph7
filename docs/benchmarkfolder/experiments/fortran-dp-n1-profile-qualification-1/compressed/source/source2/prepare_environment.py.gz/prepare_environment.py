#!/usr/bin/env python3
"""Freeze known successful tool paths using file reads only; no store globs."""
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
PHYSICAL=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-proposal-1'
SOURCE_SHA='8e19ec4f1e422e5022cb3161cfe248bbc3a11cc6a2e3912e3693718ccea571ce'
INPUT_SHA='764233779d1fe4db4351d0c34ad0b1faf7bd5cd33da6a51e1b9b43970be9dfa7'


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def entry(path,executable=False):
    path=Path(path)
    return {'sha256':digest(path),'bytes':path.stat().st_size,'executable':executable}


def main():
    if digest(PHYSICAL/'source-index.json')!=SOURCE_SHA or digest(PHYSICAL/'input-pins.json')!=INPUT_SHA:
        raise ValueError('Successful physical environment source changed')
    donor=json.loads((PHYSICAL/'input-pins.json').read_text())
    tools=donor['tools']
    required={'make':tools['make'],'nm':tools['nm'],'readelf':str(Path(tools['nm']).with_name('readelf')),
              'gfortran':tools['gfortran'],'bash':tools['make_shell'],
              'sh':str(Path(tools['make_shell']).with_name('sh')),'taskset':tools['taskset'],
              'python3':str(Path(tools['python']).with_name('python3')),
              'cc':donor['environment']['CC']}
    # Resolve only known make-parse helpers against the retained closed PATH.
    # Preserve uname's invocation alias: its resolved file is multicall coreutils.
    for name in ('uname','grep'):
        found=shutil.which(name,path=donor['environment']['PATH'])
        if found is None:raise ValueError('Closed helper unavailable: '+name)
        required[name]=str(Path(found).resolve().with_name(name))
    prefixes=[]
    # Standalone nm/readelf2.46 do not replace compiler-internal ld/as2.44.
    for name in ('make','bash','nm','cc','gfortran','taskset','python3','uname','grep'):
        prefix=str(Path(required[name]).parent)
        if prefix not in prefixes:prefixes.append(prefix)
    env_path=':'.join(prefixes+[donor['environment']['PATH']])
    required={name:{'path':path,'resolved':str(Path(path).resolve()),**entry(path,True)} for name,path in required.items()}
    # This compiler closure is read at explicit known paths, never discovered
    # through /nix/store globs or compiler/shell invocations.
    compiler=Path(tools['gfortran']);support=compiler.parent.parent/'nix-support'
    closure={}
    for name in ('utils.bash','darwin-sdk-setup.bash','add-flags.sh','cc-ldflags','libc-ldflags','libcxx-ldflags'):
        path=support/name;closure[str(path)]=entry(path)
    closure[str(support/'cc-wrapper-hook')]=None
    for path in (
        compiler,
        Path('/nix/store/g825z4hlkyiqm8zpv4kbjkvw5fl901pz-gfortran-15.2.0/bin/gfortran'),
        Path('/nix/store/g825z4hlkyiqm8zpv4kbjkvw5fl901pz-gfortran-15.2.0/libexec/gcc/x86_64-unknown-linux-gnu/15.2.0/f951'),
        compiler.with_name('as'),compiler.with_name('ld'),
        Path('/nix/store/d75200gb22v7p0703h5jrkgg8bqydk5q-coreutils-9.8/bin/cat'),
        Path('/nix/store/d75200gb22v7p0703h5jrkgg8bqydk5q-coreutils-9.8/bin/mktemp'),
        Path('/nix/store/d75200gb22v7p0703h5jrkgg8bqydk5q-coreutils-9.8/bin/rm'),
        Path('/nix/store/qfmq7p42ak5yn389qvx7zpxkan5i4xiy-gnugrep-3.12/bin/grep')):
        closure[str(path)]=entry(path,True)
    closed_build=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-work-1/build'
    terminal=json.loads((closed_build/'terminal.json').read_text());result=json.loads((closed_build/'result.json').read_text())
    if terminal['status']!='passed' or result['status']!='passed' or result['source_index_sha256']!=SOURCE_SHA:
        raise ValueError('Donor physical BUILD is not a closed successful source8e19 build')
    lineage={str(path.relative_to(ROOT)):digest(path) for path in
             (PHYSICAL/'source-index.json',PHYSICAL/'input-pins.json',closed_build/'terminal.json',closed_build/'result.json')}
    original=json.loads((HERE/'input-pins.json').read_text())['compiler_flags']['environment']
    value={'schema':'n1-profile-pinned-environment-successor-v1','closed_environment':donor['environment'],
           'path':env_path,'required_tools':required,'compiler_closure':closure,
           'original_compiler_environment':original,'donor_lineage':lineage,
           'path_policy':'Pinned direct tools precede the complete recorded successful PATH; no current harness PATH is used.',
           'native_executions':0,'compiler_queries':0,'store_globs':False}
    with (HERE/'toolchain-pins.json').open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')


if __name__=='__main__':main()
