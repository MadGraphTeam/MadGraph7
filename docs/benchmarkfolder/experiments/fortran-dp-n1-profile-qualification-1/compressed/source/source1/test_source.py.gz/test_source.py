"""Pure source/parser/admission tests. No compiler, loader or physics execution."""
import importlib.util
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


def load(name):
    spec=importlib.util.spec_from_file_location('dp_n1_test_'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


p=load('prepare');a=load('analyze');c=load('controller')


def exact_text():
    return ''.join(f'{point} {order} 219 '+' '.join(['3FF0000000000000']*4+['0000000000000000'])+'\n'
                   for point in range(1,101) for order in (0,1))


def timer_text(mode=2,calls=100,observed=True):
    lines=[f'# mode {mode}','# clock_rate 1000000000']
    active=observed and mode!=0
    for ct in range(3):
        n=calls if active and ct else 0
        lines.append(f'# requests/native/valid/failed {ct} {n} {n} {n} 0')
        if n:
            lines += [f'{stage} {ct} {n} {17 if mode==2 else 0}' for stage in range(1,7)]
    if active:lines.append(f'7 0 {2*calls} {19 if mode==2 else 0}')
    return '\n'.join(lines)+'\n'


class SourceTests(unittest.TestCase):
    def test_derivation_matches_closed_preview(self):
        original={n:(HERE/'original-source'/n).read_text() for n in p.SOURCE}
        baseline,observed=p.derive(original)
        for folder,files in [('baseline-source',baseline),('observed-source',observed)]:
            for name,text in files.items():self.assertEqual(text,(HERE/folder/name).read_text())
        self.assertEqual(baseline['check_sa.f'],observed['check_sa.f'])
        for name in ('TIRUST_interface.f','TIR_interface.f','mtirust.f90'):
            self.assertEqual(baseline[name],original[name])

    def test_transform_rejects_drift_and_reapplication(self):
        text=(HERE/'original-source'/'mtirust.f90').read_text()
        with self.assertRaises(ValueError):p.transport(p.transport(text))
        with self.assertRaises(ValueError):p.transport(text.replace('status = evaluate_dp(','status = other_dp('))

    def test_only_dp_routines_instrumented(self):
        left=(HERE/'baseline-source'/'TIRUST_interface.f').read_text()
        right=(HERE/'observed-source'/'TIRUST_interface.f').read_text()
        # Every routine beginning MP_ and initialization remain exact.
        for name in ('ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC','ML5_0_MP_TIRUST_LOOP','ML5_0_INITIALIZE_TIRUST'):
            regex=r'^      SUBROUTINE '+name+r'\(.*?^      END\n'
            self.assertEqual(re.search(regex,left,re.M|re.S).group(),re.search(regex,right,re.M|re.S).group())

    def test_floating_safeguards_and_native_scope_preserved(self):
        text=(HERE/'observed-source'/'mtirust.f90').read_text()
        body=text.split('  subroutine tensor_dp(',1)[1].split('  end subroutine',1)[0]
        start=body.index('call dp_profile_start(dp_tick)')
        end=body.index('call dp_profile_end(4,dp_tick)')
        self.assertIn('status = evaluate_dp(',body[start:end])
        self.assertNotIn('ensure_context',body[start:end])
        self.assertNotIn('set_cache_budget',body[start:end])
        self.assertIn('if (status /= TIRUST_SUCCESS) coefs = cmplx(0,0,kind=KI_TIR)',body[end:])
        adapter=(HERE/'observed-source'/'TIRUST_interface.f').read_text()
        self.assertIn('TIRUST_INVARIANT_BITS=TRANSFER',adapter)
        self.assertIn('CHECK_PASS=CTMODE.EQ.2.OR.CTMODE.EQ.5',adapter)

    def test_probe_crosses_same_separate_module_boundary(self):
        worker=(HERE/'baseline-source'/'check_sa.f').read_text()
        probe=(HERE/'qp_profile.f90').read_text().split('  subroutine dp_profile_probe(',1)[1]
        self.assertIn('SUBROUTINE DP_EMPTY_PROBE_LOOP',worker)
        self.assertIn('call dp_empty_probe_loop(repetitions,whole,rate)',probe)
        flags=json.loads((HERE/'input-pins.json').read_text())['compiler_flags']
        self.assertNotIn('-flto',json.dumps(flags))
        self.assertNotRegex(worker,r'\bINTEGER DP_MODE\b')
        self.assertIn('  private\n',(HERE/'qp_profile.f90').read_text())

    def test_no_new_fixed_form_truncation(self):
        for folder in ('baseline-source','observed-source'):
            for f in (HERE/folder).glob('*.f'):
                # This frozen exporter uses fixed132; our inserted lines fit72.
                self.assertFalse(any(len(line)>132 for line in f.read_text().splitlines()
                                     if line and line[0] not in 'Cc*!'))


class ParserTests(unittest.TestCase):
    def test_exact_signed_zero_words_preserved(self):
        text=exact_text().replace('0000000000000000','8000000000000000',1)
        self.assertEqual(a.exact(text)[0]['words'][-1],'8000000000000000')

    def test_exact_cohort_failures_nonfinite_and_duplicates_rejected(self):
        for text in (exact_text().replace('219','323',1),exact_text().replace('3FF0000000000000','7FF0000000000000',1),
                     exact_text().split('\n',1)[1],exact_text()+exact_text().splitlines()[0]+'\n'):
            with self.assertRaises(ValueError):a.exact(text)

    def test_ieee_all_points_both_phases_required(self):
        text=''.join(f'{p} {phase} 1 '+' '.join(['0']*10)+'\n' for p in range(1,101) for phase in (1,2))
        self.assertEqual(len(a.ieee(text)),200)
        with self.assertRaises(ValueError):a.ieee(text.split('\n',1)[1])
        self.assertEqual(len(a.ieee('0 1 1 '+'0 '*10+'\n0 2 1 '+'0 '*10+'\n',timed=True)),2)

    def test_two_directions_and_event_clears_required(self):
        result=a.profile(timer_text(),2,100,True)
        self.assertEqual(result['request_counters'][1],[100,100,100,0])
        self.assertEqual(len(result['scopes']),13)
        for text in (timer_text().replace('7 0 200','7 0 100'),timer_text().replace('2 100 100 100 0','2 100 99 100 0'),
                     timer_text().replace('4 2 100 17\n',''),timer_text()+'4 2 100 17\n'):
            with self.assertRaises(ValueError):a.profile(text,2,100,True)

    def test_disabled_and_counter_only_clock_contract(self):
        a.profile(timer_text(0),0,100,True)
        a.profile(timer_text(2,observed=False),2,100,False)
        a.profile(timer_text(1),1,100,True)
        with self.assertRaises(ValueError):a.profile(timer_text(2).replace('# mode 2','# mode 1'),1,100,True)

    def test_probe_raw_overhead_not_subtracted(self):
        result=a.probe('# x\n100000 1000000000 18000000 12000000\n')
        self.assertEqual(result['whole_loop_ticks'],18000000)
        self.assertIn('never subtracted',result['interpretation'])
        with self.assertRaises(ValueError):a.probe('100 1000000000 18 12\n')


class AdmissionTests(unittest.TestCase):
    def test_default_preflight_has_zero_external_commands(self):
        c.EXPECTED_SOURCE=c.digest(HERE/'source-index.json')
        with (patch.object(c.subprocess,'run',side_effect=AssertionError('native invocation')),
             patch.object(c.subprocess,'Popen',side_effect=AssertionError('native invocation')),
             patch.object(c.subprocess,'check_output',side_effect=AssertionError('native invocation'))):
            result=c.preflight()
        self.assertEqual(result['native_executions'],0)
        self.assertEqual(result['compiler_invocations'],0)

    def test_cli_separate_admissions_precede_actions(self):
        for argv in (['--stage','parity'],['--stage','profile','--reviewed-build','a'*64],['--stage','build']):
            with (patch.object(sys,'argv',['controller.py',*argv,'--source','b'*64]),
                  patch.object(c,'preflight',return_value={}),patch.object(c,'stage',side_effect=AssertionError('unadmitted'))):
                with self.assertRaises((SystemExit,ValueError)):c.main()

    def test_failed_and_wrong_source_predecessor_receipts_rejected(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(c,'REPORT',Path(tmp)):
            folder=Path(tmp)/'build';folder.mkdir()
            result={'status':'passed','source_index_sha256':'a'*64}
            (folder/'result.json').write_text(json.dumps(result))
            terminal={'status':'failed','returncode':1,'cleanup':{'survivors':[]},'result_sha256':c.digest(folder/'result.json')}
            (folder/'terminal.json').write_text(json.dumps(terminal));c.EXPECTED_SOURCE='a'*64
            with self.assertRaises(ValueError):c.receipt('build',c.digest(folder/'terminal.json'))
            terminal.update(status='passed',returncode=0);(folder/'terminal.json').write_text(json.dumps(terminal));c.EXPECTED_SOURCE='b'*64
            with self.assertRaises(ValueError):c.receipt('build',c.digest(folder/'terminal.json'))


if __name__=='__main__':unittest.main()
