"""Pure, strict n1 parsers. Reads no live executable and calls no native code."""
import math
import re
import statistics

STAGES = {1:'support_initialization_budget',2:'kinematic_preprocessing',
          3:'complete_DP_module_call',4:'C_evaluate_dp_only',
          5:'tensor_mapping_and_finite_checks',6:'contraction_normalization_finite_checks',
          7:'event_clear_inclusive',8:'empty_probe'}


def require(value, message):
    if not value:
        raise ValueError(message)


def exact(text):
    rows = []
    for line in text.splitlines():
        fields = line.split()
        require(len(fields)==8, 'Malformed exact row')
        point,order,status = map(int, fields[:3])
        require(status==219, 'n1 cohort contains failure, initialization or rescue')
        words = [word.upper() for word in fields[3:]]
        require(all(re.fullmatch('[0-9A-F]{16}', w) for w in words), 'Malformed binary64 word')
        require(all((int(w,16)>>52)&2047 != 2047 for w in words), 'Nonfinite exact word')
        require(not (int(words[-1],16)>>63) or int(words[-1],16)&((1<<63)-1)==0,
                'Negative stability estimate')
        rows.append({'point':point,'order':order,'status':status,'words':words})
    require([(r['point'],r['order']) for r in rows]==[(p,o) for p in range(1,101) for o in (0,1)],
            'Exact rows must contain all100 points and both orders once')
    return rows


def ieee(text, timed=False):
    rows = [list(map(int,line.split())) for line in text.splitlines() if line.strip()]
    expected = [[p,phase] for p in ([0] if timed else range(1,101)) for phase in (1,2)]
    require([r[:2] for r in rows]==expected and all(len(r)==13 for r in rows), 'Incomplete IEEE observations')
    require(all(r[2] in range(-1,5) and all(v in (-1,0,1) for v in r[3:]) for r in rows), 'Invalid IEEE observation')
    return rows


def profile(text, mode, calls, observed):
    headers = dict(re.findall(r'^# (mode|clock_rate) ([0-9]+)$', text, re.M))
    require(headers.get('mode')==str(mode), 'Wrong timer mode')
    rate = int(headers.get('clock_rate','0'))
    require(rate>0, 'Nonpositive clock rate')
    scopes = {}
    summaries = {}
    for line in text.splitlines():
        if line.startswith('# requests/native/valid/failed '):
            values = list(map(int,line.split()[2:]))
            require(len(values)==5 and values[0] in range(3) and values[0] not in summaries,
                    'Malformed request counters')
            summaries[values[0]]=values[1:]
        elif line and not line.startswith('#'):
            stage,ct,count,ticks = map(int,line.split())
            require(stage in STAGES and ct in range(3) and count>0 and ticks>=0,
                    'Malformed stage counters')
            require((stage,ct) not in scopes, 'Duplicate timer scope')
            require(mode==2 or ticks==0, 'Clock ticks in disabled/count-only mode')
            scopes[stage,ct]={'stage':stage,'ctmode':ct,'name':STAGES[stage],
                              'count':count,'ticks':ticks,'seconds':ticks/rate}
    require(set(summaries)=={0,1,2}, 'Missing request counter scopes')
    if observed and mode:
        require(summaries[0]==[0,0,0,0] and all(summaries[ct]==[calls,calls,calls,0] for ct in (1,2)),
                'Expected exactly one valid native DP request per direction per amplitude')
        expected={(s,ct) for s in range(1,7) for ct in (1,2)}|{(7,0)}
        require(set(scopes)==expected, 'Missing or extra n1 stage scopes')
        require(all(v['count']==(2*calls if key==(7,0) else calls) for key,v in scopes.items()),
                'Unexpected stage/clear request count')
    else:
        require(not scopes and all(v==[0,0,0,0] for v in summaries.values()),
                'Unobserved or disabled path unexpectedly records hooks')
    return {'mode':mode,'clock_rate':rate,'request_counters':summaries,
            'scopes':[scopes[k] for k in sorted(scopes)],
            'interpretation':'Stage3 contains stage4; do not sum them or subtract a noisy probe estimate.'}


def probe(text):
    rows = [line.split() for line in text.splitlines() if line.strip() and not line.startswith('#')]
    require(len(rows)==1 and len(rows[0])==4, 'Malformed probe record')
    repetitions,rate,whole,scoped = map(int,rows[0])
    require(repetitions==100000 and rate>0 and whole>=scoped>=0, 'Invalid empty probe counts/ticks')
    return {'repetitions':repetitions,'clock_rate':rate,'whole_loop_ticks':whole,'scoped_ticks':scoped,
            'whole_loop_seconds_per_pair':whole/rate/repetitions,
            'scoped_seconds_per_pair':scoped/rate/repetitions,
            'interpretation':'Whole loop includes calls, aggregation and loop overhead; descriptive, never subtracted.'}


def summary(cycles):
    require(len(cycles)==7 and [r['cycle'] for r in cycles]==list(range(1,8)), 'Incomplete fixed seven-cycle profile')
    lanes=('baseline','observed-0','observed-1','observed-2')
    ratios={lane:[] for lane in lanes[1:]}
    for row in cycles:
        require(set(row['lanes'])==set(lanes), 'Missing profile lane')
        base=row['lanes']['baseline']['seconds']
        require(math.isfinite(base) and base>0, 'Bad baseline elapsed')
        for lane in ratios:
            value=row['lanes'][lane]['seconds']
            require(math.isfinite(value) and value>0, 'Bad observed elapsed')
            ratios[lane].append(value/base)
    return {'paired_cycle_ratios':ratios,
            'median_ratios':{k:statistics.median(v) for k,v in ratios.items()},
            'interpretation':'Descriptive instrumentation overhead only; no optimization or acceptance claim.',
            'performance_acceptance':False,'speedup_claimed':False}
