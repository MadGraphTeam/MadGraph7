# Source-only n1 DP attribution proposal

**No BUILD, PARITY or PROFILE stage has run. No speedup is claimed.**
This private diagnostic targets the approximately9µs descriptive shared-host
TIRust/NinjaRS gap for `u u~ > z [virt=QCD]`. It does not change production,
Rust, budget/cache semantics, independent stability tests or backend defaults.
Precise runtime acceptance remains Hua-Sheng's local TODO.

The frozen current n1 export is from campaign `entry-latch-cache-guard-1`,
scientific source0fcd2cd873, with native TIRust DSOeb3d67fd… . It has one
N=3/rank2 tensor group,15 moments, one squared order and no generic Fortran
tensor cache. Both directions remain enabled. All100 saved boosted on-shellZ
points, physical/numerical cards, source/include inventories, numerical objects,
compiler policies, executable and recorded native providers are pinned in
`input-pins.json`. Reference repositories remain untouched.

`original-source/` copies the actual frozen files. `baseline-source/` changes
only the common worker harness; its three numerical files are byte-identical
to the originals. `observed-source/` adds bounded integer counters/clocks to
that same numerical source. Both variants use the identical IEEE/command
harness and the same explicit private MTIRUST override and five-unit build.
No unmodified historical executable is relabeled as this new baseline.
`prepare.py` reproduces the exact transformations; `instrumentation.diff`
contains only baseline→observed numerical instrumentation.

The observed lanes are hooks-disabled, counter-only and clocks+counter. Each
fresh worker performs unchanged setup/bootstrap and full100 learning with
filters removed recursively. Every learning row, including call0, must match
the retained current n1 trace. Before any timed batch, every lane must match
the baseline's complete100-point, both-order raw binary64 answer/accuracy
words, status219 and actual pre/post IEEE observations. Mode2 clocks gathered
during this parity qualification are discarded as timing evidence.

| Stage | Scope |
|---|---|
|1|Support query, initialization and cache-budget call|
|2|Kinematic preprocessing, including existing safeguards|
|3|Complete Fortran DP module call|
|4|C `evaluate_dp` call only, within stage3|
|5|Tensor mapping and finite checks|
|6|Contraction, normalization and final finite checks|
|7|Event clearing, including context check|

Stage3 contains stage4: their intervals must not be added. Primary CT1 and
independent-check CT2 counters remain separate; both must contain exactly one
successful native request per physical call. The fixture requires two event
clears per warmed physical call. Any unexpected topology, rescue, failure,
missing stage or counter mismatch fails the qualification; nothing is retried
or dropped. API timing includes native wrapper/allocation/reduction costs and
does not isolate internal Rust stages.

The empty-probe loop runs100,000 times in `check_sa.o`, across the same separate
module-call boundary as the real hooks. Its whole-loop and empty-bracket raw
ticks are retained separately; neither is subtracted from physics intervals.
The four full-amplitude lanes provide the observed instrumentation-overhead
controls. Seven fixed alternating cycles use128 complete100-point traversals
per lane/batch, with no adaptive calibration. Timed exact-word evidence covers
the **final100-point traversal**; status histograms and native/stage counts
cover **all12,800 calls** in each batch. Batch IEEE snapshots are outside its
clock. Sticky IEEE equality observes state; true→true flags cannot identify
new exceptions. No precision timing confidence bound or acceptance gate is
inferred from this diagnostic.

BUILD, PARITY and PROFILE are separately admitted, append-only stages. BUILD
must be closed and independently reviewed before PARITY; PARITY must be closed
and reviewed before PROFILE. Each admission binds the exact source and prior
terminal hashes. Selected compilation/link commands, prebound link inputs,
actual linker LOADs/private MTIRUST precedence, actual PT_INTERP runtime lists
and process maps are retained. Compiler invocations are confined to BUILD;
loader queries require an admitted stage. Pure preflight hashes files and parses
ELF bytes, without executing native code.

All stages use nonexclusiveCPU12 and the existing
`.tirust-build/numerical-tests.lock`. Caps are600s BUILD,300s PARITY,600s PROFILE,
including mutex waiting, synchronous checks and a60s cleanup reserve. The
owned-descendant helper retains process-start/session identities and bounded
cleanup; failures are preserved and require a new reviewed successor rather
than an automatic retry. Children have16GiB address-space,512MiB file and
zero-core limits. Original exports and shared library directories are read-only.

From `/shared/external/madloop_tirust/madgraph7_madloop_tirust`:

```sh
python3 -B docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-1/test_source.py
python3 -B docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-1/controller.py --source SOURCE_INDEX_SHA256
```

After separate coordinator review, each command below admits exactly one stage:

```sh
python3 -B docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-1/controller.py --stage build --execute --source SOURCE_INDEX_SHA256
python3 -B docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-1/controller.py --stage parity --execute --source SOURCE_INDEX_SHA256 --reviewed-build BUILD_TERMINAL_SHA256
python3 -B docs/benchmarkfolder/experiments/fortran-dp-n1-profile-proposal-1/controller.py --stage profile --execute --source SOURCE_INDEX_SHA256 --reviewed-build BUILD_TERMINAL_SHA256 --reviewed-parity PARITY_TERMINAL_SHA256
```

Execution destinations are fresh
`.tirust-build/fortran-dp-n1-profile-1` and
`docs/benchmarkfolder/experiments/fortran-dp-n1-profile-execution-1`.
The existing QP bulk-decoder qualification/timing campaign is independent and
uses the same mutex. This proposal grants no execution admission itself.
