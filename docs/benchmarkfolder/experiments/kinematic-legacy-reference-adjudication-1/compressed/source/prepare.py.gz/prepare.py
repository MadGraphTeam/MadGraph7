#!/usr/bin/env python3
"""Pure, hash-before-parse derivation. No compiler, loader, or amplitudes."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def source(key):
    binding = json.loads((HERE / 'bindings.json').read_bytes())['files'][key]
    path = ROOT / binding['path']
    require(pin(path) == {k: binding[k] for k in ('bytes', 'sha256')}, 'Changed input: ' + key)
    return path.read_text()


def replace_once(text, old, new):
    require(text.count(old) == 1, 'Ambiguous source anchor: ' + old[:90])
    return text.replace(old, new, 1)


def hook(backend, vector, step, status):
    return (f'      CALL PC_REF_NATIVE({step},{backend},CTMODE,\n'
            f'     $ STORAGE_SIZE({vector}(0,1)),DIGITS({vector}(0,1)),\n'
            f'     $ ID,SQSOINDEX,NLOOPLINE,RANK,{status})\n')


def derive_adapter(original):
    text = original
    blocks = [
        (6, 'P_NINJA', 'NINJA_STATUS',
         '      CALL NINJA_TENSOR_EVALUATE(TENSORCOEFS,NLOOPLINE,RANK,REAL_S_MAT\n'
         '     $ ,P_NINJA,M2L,MU_R**2,NINJA_RES,R1,NINJA_STATUS)\n'),
        (6, 'MP_P_NINJA', 'NINJA_STATUS',
         '      CALL NINJA_TENSOR_EVALUATE(MP_NINJA_TENSORCOEFS,NLOOPLINE,RANK\n'
         '     $ ,MP_REAL_S_MAT_NINJA,MP_P_NINJA,MP_M2L_NINJA,NINJA_SCALE\n'
         '     $ ,NINJA_RES,NINJA_R1,NINJA_STATUS)\n'),
        (8, 'P_NRS', 'NRS_STATUS',
         '      IF(NRS_RETRY_MODE) THEN\n'
         '        CALL NINJARS_TENSOR_EVALUATE_COMPENSATED(TENSORCOEFS(0:CURR_MAX\n'
         '     $COEF-1),NLOOPLINE,RANK,REAL_S_MAT,P_NRS,MASSES,NRS_SCALE,NRS_RES\n'
         '     $   ,R1,NRS_STATUS,MAX(0,LOOPPOLEMODE))\n'
         '      ELSE\n'
         '        CALL NINJARS_TENSOR_EVALUATE(TENSORCOEFS(0:CURR_MAXCOEF-1)\n'
         '     $   ,NLOOPLINE,RANK,REAL_S_MAT,P_NRS,MASSES,NRS_SCALE,NRS_RES,R1\n'
         '     $   ,NRS_STATUS,MAX(0,LOOPPOLEMODE))\n'
         '      ENDIF\n'),
        (8, 'P_NRS', 'NRS_STATUS',
         '      CALL NINJARS_TENSOR_EVALUATE(TENSORCOEFS(0:CURR_MAXCOEF-1)\n'
         '     $ ,NLOOPLINE,RANK,REAL_S_MAT,P_NRS,MASSES,NRS_SCALE,NRS_RES,R1\n'
         '     $ ,NRS_STATUS,MAX(0,LOOPPOLEMODE))\n'),
    ]
    for backend, vector, status, block in blocks:
        text = replace_once(text, block, hook(backend, vector, 0, '-999') + block +
                            hook(backend, vector, 1, status))
    return text


LOGGER = '''
C     Private bounded usage/status log. No legacy COMMON writes.
      SUBROUTINE PC_REF_PHASE_START(NEW_PHASE)
      IMPLICIT NONE
      INTEGER NEW_PHASE,PHASE,SEQUENCE,WRITTEN,RECORDS(12,4096)
      COMMON/PC_REF_PRIVATE_STATE/PHASE,SEQUENCE,WRITTEN,RECORDS
      IF(NEW_PHASE.NE.PHASE+1.OR.NEW_PHASE.GT.1) STOP 26
      PHASE=NEW_PHASE
      WRITE(76,'(A,I10)') 'REF_BEGIN',PHASE
      FLUSH(76)
      END

      SUBROUTINE PC_REF_NATIVE(STEP,BACKEND,MODE,WIDTH,PRECISION,
     $ ID,SQSO,N,RANK,STATUS)
      IMPLICIT NONE
      INTEGER STEP,BACKEND,MODE,WIDTH,PRECISION,ID,SQSO,N,RANK,STATUS
      INTEGER PHASE,SEQUENCE,WRITTEN,RECORDS(12,4096)
      COMMON/PC_REF_PRIVATE_STATE/PHASE,SEQUENCE,WRITTEN,RECORDS
      IF(PHASE.LT.0.OR.PHASE.GT.1) STOP 26
      IF(SEQUENCE.GE.4096) STOP 26
      SEQUENCE=SEQUENCE+1
      RECORDS(:,SEQUENCE)=(/SEQUENCE,PHASE,STEP,BACKEND,MODE,
     $ WIDTH,PRECISION,ID,SQSO,N,RANK,STATUS/)
C     Integer assignments only inside reduction. Flush after outer return.
      END

      SUBROUTINE PC_REF_FLUSH
      IMPLICIT NONE
      INTEGER PHASE,SEQUENCE,WRITTEN,RECORDS(12,4096),I
      COMMON/PC_REF_PRIVATE_STATE/PHASE,SEQUENCE,WRITTEN,RECORDS
      DO I=WRITTEN+1,SEQUENCE
        WRITE(76,'(A,12I10)') 'REF_NATIVE',RECORDS(:,I)
      ENDDO
      WRITTEN=SEQUENCE
      WRITE(76,'(A,2I10)') 'REF_END',PHASE,SEQUENCE
      FLUSH(76)
      END

      BLOCK DATA PC_REF_PRIVATE_INIT
      IMPLICIT NONE
      INTEGER PHASE,SEQUENCE,WRITTEN,RECORDS(12,4096)
      COMMON/PC_REF_PRIVATE_STATE/PHASE,SEQUENCE,WRITTEN,RECORDS
      DATA PHASE,SEQUENCE,WRITTEN/-1,0,0/
      END
'''


def derive_driver(original):
    text = replace_once(original, 'backend(1/9)', 'backend(6/8)')
    text = replace_once(text, "      IF(TRIM(ARG).NE.'1'.AND.TRIM(ARG).NE.'4') STOP 21\n",
                        "      IF(TRIM(ARG).NE.'4') STOP 21\n")
    text = replace_once(text, '      IF(POINT_ID.LT.1) STOP 21\n',
                        '      IF(POINT_ID.NE.1.AND.POINT_ID.NE.20) STOP 21\n')
    text = replace_once(text, "      IF(TRIM(ARG).NE.'1'.AND.TRIM(ARG).NE.'9') STOP 21\n",
                        "      IF(TRIM(ARG).NE.'6'.AND.TRIM(ARG).NE.'8') STOP 21\n")
    text = replace_once(text, '      IF(.NOT.UseQPIntegrandForCutTools) STOP 24\n',
                        '      IF(.NOT.UseQPIntegrandForCutTools) STOP 24\n'
                        '      IF(.NOT.UseQPIntegrandForNinja) STOP 24\n'
                        '      IF(.NOT.UseQPIntegrandForNinjaRS) STOP 24\n')
    for phase, anchor in [(0, '         CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)\n'),
                          (1, '      CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)\n')]:
        # Exact line equality avoids matching the indented bootstrap suffix.
        lines = text.splitlines(keepends=True)
        require(lines.count(anchor) == 1, 'Ambiguous outer call anchor')
        i = lines.index(anchor)
        lines.insert(i + 1, '      CALL PC_REF_FLUSH\n')
        lines.insert(i, f'      CALL PC_REF_PHASE_START({phase})\n')
        text = ''.join(lines)
    return text + LOGGER


def card(original, backend):
    require(backend in (6, 8), 'Only admitted reference IDs')
    return replace_once(original, '#MLReductionLib\n1\n', f'#MLReductionLib\n{backend}\n')


def main():
    original_adapter = source('CT_interface')
    original_driver = source('driver')
    products = {'CT_interface.f': derive_adapter(original_adapter),
                'driver-reference.f': derive_driver(original_driver)}
    for name, original in [('CT_interface.f', original_adapter), ('driver-reference.f', original_driver)]:
        products[name + '.patch'] = ''.join(difflib.unified_diff(
            original.splitlines(keepends=True), products[name].splitlines(keepends=True),
            fromfile='sealed-original/' + name, tofile='private-reference/' + name))
    for backend in (6, 8):
        products[f'backend{backend}-mode4-MadLoopParams.dat'] = card(source('card'), backend)
    for name, text in products.items():
        with (HERE / name).open('x') as stream:
            stream.write(text)
    print(json.dumps({'native_actions': 0, 'derived': {name: pin(HERE / name) for name in products}}, indent=2))


if __name__ == '__main__':
    main()
