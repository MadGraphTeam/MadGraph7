import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import run


class RealDependencyBoundary(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parent = run.load('reference_test_parent', run.OLD / 'run.py')
        p = cls.parent
        p.R, p.G, p.B, p.PLAN, p.TOOLCHAIN, _ = p.verify_source(run.OLD_SHA)
        p.BASE, p.WORK, p.RESULTS = run.BASE, run.WORK, run.RESULTS

    def setUp(self):
        self.saved = run.P
        run.P = self.parent

    def tearDown(self):
        run.P = self.saved

    def test_actual_file_backed_dependency_adapter(self):
        result = run.dependency_preflight('build')
        self.assertEqual(result, {'native_actions': 0, 'files': 150, 'private_records': 3})
        for name, value in run.P.B['external_private_files'].items():
            self.assertEqual(run.P.R.PREREQUISITES.DATA['external'][name],
                             {'size': value['bytes'], 'sha256': value['sha256']})

    def test_run_namespace_reaches_fake_retained_capture(self):
        L = run.setup_owned('run')
        seen = []
        L.command = lambda *args, **kwargs: seen.append((args, kwargs)) or 'fake-output'
        self.assertEqual(L.capture(['non-executed-literal-query'], run.ROOT), 'fake-output')
        self.assertEqual(len(seen), 1)
        self.assertEqual(L.STAGES, ('build', 'run'))
        self.assertEqual(L.CPU, 12)


class Controller(unittest.TestCase):
    def test_make_job_mapping_is_explicit(self):
        calls = []
        fake = SimpleNamespace(STAGES=(), CURRENT_STAGE=None, CPU=None,
            command=lambda *a, **kw: calls.append((a, kw)) or 'done')
        parent = SimpleNamespace(setup_owned=lambda stage: fake, R=SimpleNamespace())
        with patch.object(run, 'P', parent), patch.object(run, 'ACTUAL_MAKE_TRANSFORMS', []):
            L = run.setup_owned('build')
            L.command(['make', '-j2', 'pc-objects'], 'test', run.ROOT, 30)
            self.assertEqual(calls[0][0][0], ['make', '-j1', 'pc-objects'])
            self.assertEqual(run.ACTUAL_MAKE_TRANSFORMS[0]['actual_argv'], ['make', '-j1', 'pc-objects'])

    def test_closed_build_requires_explicit_hash(self):
        with self.assertRaisesRegex(ValueError, 'Explicit closed-build'):
            run.reviewed_build(None)

    def test_closed_build_bad_hash_fails_before_native_or_receipt_parse(self):
        with patch.object(run, 'V', SimpleNamespace(pin=lambda p: {'sha256': 'actual'})):
            with self.assertRaisesRegex(ValueError, 'Build closure differs'):
                run.reviewed_build('unreviewed')

    def test_saved_outputs_are_append_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'record.json'
            run.save(path, {'first': True})
            with self.assertRaises(FileExistsError):
                run.save(path, {'replacement': True})
            self.assertEqual(json.loads(path.read_bytes()), {'first': True})

    def test_reference_plan_is_exact_and_no_point21(self):
        plan = run.read(run.HERE / 'validation-plan.json')
        self.assertEqual([x['backend'] for x in plan['requests']], [8, 6])
        self.assertEqual(len(plan['requests']), 2)
        self.assertEqual(plan['build']['seconds_total'], 300)
        self.assertEqual(plan['run']['seconds_total'], 1500)
        self.assertEqual(plan['run']['outer_entries_max'], 4)
        self.assertEqual(plan['build']['compiled_objects'], ['check_sa.o', 'CT_interface.o'])
        for item in plan['requests']:
            self.assertEqual((item['point'], item['requested_mode']), (20, 4))
            self.assertEqual((item['bootstrap_calls'], item['measurement_calls']), (1, 1))
            self.assertEqual(item['bootstrap'], 'inputs/cms-point1.dat')

    def test_native_owner_and_limits_unchanged_worker_root_updated(self):
        for name in ('native_job.py', 'limit_exec.py'):
            self.assertEqual((run.HERE / name).read_bytes(), (run.OLD / name).read_bytes())
        expected = (run.OLD / 'worker_entry.py').read_text().replace(
            "root=ROOT/'.tirust-build/kinematic-invariant-amplitude-executor-2'",
            "root=ROOT/'.tirust-build/kinematic-invariant-reference-adjudication-executor-1'")
        self.assertEqual((run.HERE / 'worker_entry.py').read_text(), expected)


if __name__ == '__main__':
    unittest.main()
