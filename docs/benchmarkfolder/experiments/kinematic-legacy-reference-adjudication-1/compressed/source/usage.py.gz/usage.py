"""Pure validator for the proposed integer-only native-call observation."""


def parse(text, backend):
    if backend not in (6, 8):
        raise ValueError('Unadmitted reference backend')
    phase = -1
    records = []
    pending = None
    completed = {0: [], 1: []}
    ended = set()
    for line in text.splitlines():
        words = line.split()
        if not words:
            continue
        if words[0] == 'REF_BEGIN':
            if (len(words) != 2 or int(words[1]) != phase + 1 or pending is not None or
                    (phase >= 0 and phase not in ended)):
                raise ValueError('Invalid phase boundary')
            phase = int(words[1])
            if phase not in (0, 1):
                raise ValueError('Extra outer phase')
            continue
        if words[0] == 'REF_END':
            if (len(words) != 3 or phase not in (0, 1) or phase in ended or
                    list(map(int, words[1:])) != [phase, len(records)] or
                    pending is not None or not completed[phase]):
                raise ValueError('Invalid phase end/count marker')
            ended.add(phase)
            continue
        if words[0] != 'REF_NATIVE' or len(words) != 13:
            raise ValueError('Unknown usage record')
        row = dict(zip(('sequence', 'phase', 'step', 'backend', 'mode', 'width',
                        'digits', 'group', 'split_order', 'n', 'rank', 'status'),
                       map(int, words[1:])))
        if row['sequence'] != len(records) + 1 or row['sequence'] > 4096:
            raise ValueError('Invalid usage sequence or bound')
        if row['phase'] != phase or phase not in (0, 1) or phase in ended:
            raise ValueError('Usage outside admitted phase')
        if (row['backend'], row['mode'], row['width'], row['digits']) != (backend, 4, 128, 113):
            raise ValueError('Actual backend or precision differs')
        if not (1 <= row['group'] <= 26 and row['split_order'] == 1 and
                1 <= row['n'] <= 4 and 0 <= row['rank'] <= 6):
            raise ValueError('Native route shape outside bound')
        records.append(row)
        if row['step'] == 0:
            if pending is not None or row['status'] != -999:
                raise ValueError('Nested or malformed native attempt')
            pending = row
        elif row['step'] == 1:
            keys = ('phase', 'backend', 'mode', 'width', 'digits', 'group', 'split_order', 'n', 'rank')
            if pending is None or any(row[k] != pending[k] for k in keys):
                raise ValueError('Unmatched native return')
            completed[phase].append(row)
            pending = None
        else:
            raise ValueError('Unknown native step')
    if phase != 1 or ended != {0, 1} or pending is not None or any(not completed[x] for x in (0, 1)):
        raise ValueError('Incomplete usage observation')
    failures = [row for row in records if row['step'] == 1 and row['status'] != 0]
    return {'complete': True, 'passed': not failures, 'records': records,
            'native_completed_per_phase': {str(k): len(v) for k, v in completed.items()},
            'nonzero_native_statuses': failures, 'actual_dp_calls': 0,
            'coefficient_accuracy_proven': False}
