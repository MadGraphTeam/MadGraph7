#!/usr/bin/env python3
"""File-only verification of the sealed proposal and its closed lineage."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def checked(path, expected):
    require(pin(path) == {k: expected[k] for k in ('bytes', 'sha256')}, str(path))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify(expected):
    require(pin(HERE / 'index.json')['sha256'] == expected, 'Proposal index changed')
    index = json.loads((HERE / 'index.json').read_bytes())
    for name, value in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe local payload')
        checked(HERE / name, value)
    binding = json.loads((HERE / 'bindings.json').read_bytes())
    require(binding['root'] == str(ROOT), 'Repository root differs')
    inputs = binding['files']
    for item in inputs.values():
        checked(ROOT / item['path'], item)
    source_index = json.loads((ROOT / inputs['source_index']['path']).read_bytes())
    source_root = (ROOT / inputs['source_index']['path']).parent
    for name, value in source_index['files'].items():
        checked(source_root / name, value)
    closure = json.loads((ROOT / inputs['build_closure']['path']).read_bytes())
    checked(ROOT / inputs['original_build']['path'], closure['payloads']['builds/original/build.json'])
    build = json.loads((ROOT / inputs['original_build']['path']).read_bytes())
    for key in ('CT_interface', 'loop_matrix'):
        checked(ROOT / inputs[key]['path'], build['sources'][inputs[key]['path']])
    for key in ('driver', 'card', 'physical_card', 'point1', 'point20'):
        relative = str((ROOT / inputs[key]['path']).relative_to(source_root))
        checked(ROOT / inputs[key]['path'], source_index['files'][relative])
    geometry_index = json.loads((ROOT / inputs['conditional_geometry_index']['path']).read_bytes())
    checked(ROOT / inputs['conditional_geometry']['path'], geometry_index['files']['results.json'])
    prepare = load('prepare', 'prepare.py')
    require((HERE / 'CT_interface.f').read_text() == prepare.derive_adapter(prepare.source('CT_interface')),
            'Adapter derivation differs')
    require((HERE / 'driver-reference.f').read_text() == prepare.derive_driver(prepare.source('driver')),
            'Driver derivation differs')
    for backend in (6, 8):
        require((HERE / f'backend{backend}-mode4-MadLoopParams.dat').read_text() ==
                prepare.card(prepare.source('card'), backend), 'Card derivation differs')
    diagnosis = load('reference_diagnose', 'diagnose.py')
    require(json.loads((HERE / 'diagnosis.json').read_bytes()) == diagnosis.summary(),
            'Pure closed diagnosis differs')
    return {'passed': True, 'proposal_payloads': len(index['files']),
            'source_payloads': len(source_index['files']), 'direct_input_bindings': len(inputs),
            'native_actions': 0, 'build_or_run_controller_present': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reviewed-index', required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.reviewed_index), sort_keys=True))
