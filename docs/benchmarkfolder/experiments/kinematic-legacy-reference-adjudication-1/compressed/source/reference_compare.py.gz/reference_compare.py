"""Pure reference gate: actual QP usage, then bootstrap, then measurement.

No native invocation. Failed/unqualified measurement words remain opaque.
Agreement is retained without selecting a majority winner or declaring truth.
"""
import hashlib
import json
from pathlib import Path
import types

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_INDEX_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
OLD_COMPARE_SHA='ecce1e1f99f0de7d1798880cc9137251b4e553accc708f3cee357ed794b99272'
USAGE_SHA='b4fb17b7d7efba6acbfe261e62bf13a885b41c9b648487e1e5fc28e55457f1ce'
SAVED_SHAS={
    'ordinary_comparison':'6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451',
    'point20_comparison':'7b2390b98193dd11c66ae8eae64ec7b36f5497accd9e2e355de03ccfacda5d6d',
}
INPUT_SHAS={
    'physical_card':'96158fedb398f3a7957bff10db0a7101281eb57ef0e9973e9c6e43c727efb8ec',
    'point1':'ed760e231007f76fa0f6b80aad72be2291a5e5cef8343e14c69e40dd6a50233b',
    'point20':'57d7f677e925d7bc258e65fe440880d2876f0317de3904c348060e08c48edd1d',
}
CARD_SHAS={6:'2c6e8317324ae0d0194b5c8b1840545c64adc0732658abdd23adc06c399a6d2d',
           8:'5dad1b91bdb0ebf81b82f1b42561e45387adf85e7cfa10ed44cd6311499d810e'}


def require(condition,message):
    if not condition:
        raise ValueError(message)


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
    raw=Path(path).read_bytes()
    if isinstance(expected,str):
        require(pin(raw)['sha256']==expected,'Pinned bytes changed: '+str(path))
    else:
        require(pin(raw)=={k:expected[k] for k in ('bytes','sha256')},'Pinned bytes changed: '+str(path))
    return raw


def _load_checked_module(path,sha,name,adapt=None):
    raw=checked(path,sha)
    source=raw.decode('utf-8')
    if adapt is not None:
        source=adapt(source)
    module=types.ModuleType(name)
    module.__file__=str(path)
    exec(compile(source,str(path),'exec'),module.__dict__)
    return module


def _legacy():
    index=json.loads(checked(OLD/'index.json',OLD_INDEX_SHA))
    require(index['files']['amplitude_compare.py']['sha256']==OLD_COMPARE_SHA,
            'Comparator is not a member of the closed source packet')
    def usage_aware(source):
        anchor="        require(not raw['trace.dat'],'Unexpected diagnostic trace output')"
        require(source.count(anchor)==1,'Legacy empty-trace guard differs')
        # This is the sole in-memory adaptation. The outer gate has already
        # authenticated and validated this nonempty REF usage stream.
        return source.replace(anchor,'        # REF usage stream checked by outer reference gate.',1)
    module=_load_checked_module(OLD/'amplitude_compare.py',OLD_COMPARE_SHA,
                                'private_reference_legacy_compare',usage_aware)
    module.verify_sources()
    return module


def _usage():
    return _load_checked_module(HERE/'usage.py',USAGE_SHA,'private_reference_usage')


def _binding(key,sha):
    data=json.loads((HERE/'bindings.json').read_bytes())
    require(data['root']==str(ROOT),'Reference repository root differs')
    item=data['files'][key]
    path=Path(item['path'])
    require(not path.is_absolute() and '..' not in path.parts,'Unsafe reference binding')
    require(item['sha256']==sha,'Reference binding is not the admitted closed input: '+key)
    raw=checked(ROOT/path,item)
    return raw,{'path':str(path),**pin(raw)}


def _cards_and_points(directory,request):
    """Exact retained specification and materialized worker inputs, before decoding."""
    spec_raw=(directory/'specification.json').read_bytes()
    spec=json.loads(spec_raw)
    require(spec['request']==request,'Reference specification request differs')
    source_card=HERE/request['card']
    numerical=pin(checked(source_card,CARD_SHAS[request['backend']]))
    expected={}
    for key,sha in INPUT_SHAS.items():
        _,record=_binding(key,sha)
        expected[key]={k:record[k] for k in ('bytes','sha256')}
    require(spec['numerical_card']==numerical and spec['physical_card']==expected['physical_card'],
            'Reference card pins differ')
    require(spec['bootstrap_pin']==expected['point1'] and spec['point_pin']==expected['point20'],
            'Reference phase-space input pins differ')
    cwd=Path(spec['cwd'])
    require(cwd.is_absolute(),'Reference worker cwd is not absolute')
    for path,value in ((cwd.parents[1]/'Cards/MadLoopParams.dat',numerical),
                       (cwd.parents[1]/'Cards/param_card.dat',expected['physical_card']),
                       (Path(spec['bootstrap_file']),expected['point1']),
                       (Path(spec['point_file']),expected['point20'])):
        checked(path,value)
    return {'specification.json':pin(spec_raw),'numerical_card':numerical,**expected}


def _structural_evidence(directory,request,native,observation):
    """Verify worker closure/maps/entry integers without reading coefficients."""
    legacy=_legacy()
    pid=native.get('native_pid')
    require(type(pid) is int and pid>0,'Missing native worker PID')
    observation['native_pid']=pid
    require(native['orchestration_complete'] is True and native['runtime_map_verified'] is True and
            native['trace_complete'] is True and native['native_returncode']==0 and
            not native['stdout_overflow'] and not native['collection_errors'] and
            native['failure'] is None and native['cleanup_failure'] is None,
            'Incomplete worker/runtime/cleanup evidence')
    closes=native['close_receipts']
    require(closes and all(x['complete'] is True and x['worker_closed'] is True and
                          x['returncode']==0 and x['pid']==pid for x in closes),
            'Worker ownership/close receipts failed')
    protocol=native['protocol']
    require(len(protocol)==3 and protocol[0][:6]==['READY','1','1','1','1','1'] and
            len(protocol[0])==7 and legacy.DECIMAL_TOKEN.fullmatch(protocol[0][6]) and
            protocol[1]==['DONE','1','1'] and protocol[2]==['BYE'],
            'Protocol is not one bootstrap plus one measurement')
    maps=native['runtime_maps']
    require([x['boundary'] for x in maps]==['READY','DONE'],'Missing/duplicate runtime maps')
    require(maps[0]['elf'] and maps[0]['elf']==maps[1]['elf'],'READY/DONE ELF map sets differ')
    for capture in maps:
        name=capture['file']
        require(Path(name).name==name,'Unsafe retained map path')
        raw=checked(directory/name,capture['sha256'])
        observation['source_evidence'][name]=pin(raw)
    observation['ready_done_maps']=2
    observation['protocol_complete']=True
    state=checked(directory/'driver-state.dat',native['outputs']['driver-state.dat'])
    observation['source_evidence']['driver-state.dat']=pin(state)
    legacy._states(state.decode('ascii'),request['point'],request['requested_mode'],observation)
    observation['structural_complete']=True


def inspect_reference_worker(directory,request):
    """Native usage/status gate happens before legacy output-column parsing."""
    directory=Path(directory)
    observation={'id':request['id'],'request':request,'eligible':False,'failures':[],
        'raw_rows':[],'states':[],'native_usage_gate_passed':False,
        'bootstrap_control_passed':False,'measurement_interpretation_allowed':False,
        'source_evidence':{},'outer_entries_observed':0,'ready_done_maps':0,
        'protocol_complete':False,'structural_complete':False,'native_pid':None}
    try:
        evidence=_cards_and_points(directory,request)
        native_raw=(directory/'result.json').read_bytes()
        native=json.loads(native_raw)
        require(native['request']==request,'Native reference request differs')
        observation.update(source_evidence={
            'specification.json':evidence['specification.json'],
            'result.json':pin(native_raw)},input_contract=evidence)
        _structural_evidence(directory,request,native,observation)
        trace=checked(directory/'trace.dat',native['outputs']['trace.dat'])
        observation['source_evidence']['trace.dat']=pin(trace)
        usage=_usage().parse(trace.decode('ascii'),request['backend'])
        observation['native_usage']=usage
        require(usage['complete'] is True and usage['passed'] is True and
                usage['actual_dp_calls']==0 and not usage['nonzero_native_statuses'],
                'Native usage/status failed; all coefficient interpretation blocked')
        observation['native_usage_gate_passed']=True
        # The sole adapted legacy assertion is permitted only after the gate
        # above. All protocol/maps/output pins/software flags/W03 checks remain.
        legacy=_legacy().inspect_worker(directory,request)
        observation.update(legacy)
        observation['source_evidence']['specification.json']=evidence['specification.json']
        observation['native_usage']=usage
        observation['native_usage_gate_passed']=True
        observation['input_contract']=evidence
        observation['bootstrap_control_passed']=False
        observation['measurement_interpretation_allowed']=False
    except (KeyError,ValueError,TypeError,OSError,UnicodeError) as exc:
        observation['failures'].append(str(exc))
    return observation


def load_saved():
    """Only the selected eligible closed rows; no failed saved outputs decoded."""
    reports={};evidence={}
    for key,sha in SAVED_SHAS.items():
        raw,record=_binding(key,sha)
        reports[key]=json.loads(raw);evidence[key]=record
    selection={
        'ordinary_CT_QP':('ordinary_comparison','cms-p1-mode4-lib1-original',1,1,'original'),
        'CMS20_CT_original_QP':('point20_comparison','cms-p20-mode4-lib1-original',20,1,'original'),
        'CMS20_CT_candidate_QP':('point20_comparison','cms-p20-mode4-lib1-candidate',20,1,'candidate'),
        'CMS20_TIRust_candidate_QP':('point20_comparison','cms-p20-mode4-lib9-candidate',20,9,'candidate'),
    }
    observations={}
    for label,(report,key,point,backend,variant) in selection.items():
        obs=reports[report]['observations'][key]
        require(obs['eligible'] is True and not obs['failures'],'Saved comparison row is ineligible: '+key)
        req=obs['request']
        require((req['point'],req['requested_mode'],req['backend'],req['variant'])==(point,4,backend,variant),
                'Saved comparison identity differs: '+key)
        after=[x for x in obs['states'] if x['stage']=='A']
        require(len(after)==2 and all(x['code']==120 and x['actual_mode']==4 and
                x['fpe_dp']==0 and x['fpe_qp']==0 for x in after),'Saved row has failed mode/flags')
        require(not obs.get('incomplete_contribution_warnings'),'Saved row contains W03')
        observations[label]=obs
    return {'observations':observations,'source_evidence':evidence}


def _phase_view(observation,phase,*,saved=False):
    require(observation['eligible'] is True,'Failed reference coefficients remain opaque')
    if phase==1 and not saved:
        require(observation['measurement_interpretation_allowed'] is True,
                'Bootstrap gate failed; measurement words remain opaque')
    rows=[x for x in observation['raw_rows'] if x['phase']==phase]
    require(len(rows)==2 and [x['order'] for x in rows]==[0,1],'Reference phase/order coverage differs')
    # Legacy comparator selects phase1; only the chosen bootstrap view is relabelled.
    return {'id':observation['id'],'eligible':True,'raw_rows':[{**x,'phase':1} for x in rows]}


def validate_requests(requests):
    require(len(requests)==2 and [x['backend'] for x in requests]==[8,6],
            'Reference scope must be exactly backend8 then backend6')
    for r in requests:
        expected={'id':f"cms-p20-mode4-lib{r['backend']}-reference",'variant':'reference','stage':'run',
                  'requested_mode':4,'point':20,'expected_fixed_unchecked_return':120,
                  'bootstrap_calls':1,'measurement_calls':1,'outer_entries_max':2,
                  'card':f"backend{r['backend']}-mode4-MadLoopParams.dat",
                  'physical_card':'inputs/cms-param_card.dat','bootstrap':'inputs/cms-point1.dat',
                  'measurement':'inputs/cms-point20.dat'}
        require(all(r.get(k)==v for k,v in expected.items()),'Reference request differs from admitted scope')


def compare_reference_stage(root,requests):
    validate_requests(requests);root=Path(root)
    observations={r['backend']:inspect_reference_worker(root/r['id'],r) for r in requests}
    legacy=_legacy();saved=load_saved();bootstrap=[];measurements=[];failures=[]
    for backend in (8,6):
        obs=observations[backend]
        row={'backend':backend,'reference_id':'ordinary_CT_QP','candidate_id':obs['id'],
             'eligible':obs['eligible'],'passed':False}
        if obs['eligible']:
            row.update(legacy.compare_coefficients(_phase_view(saved['observations']['ordinary_CT_QP'],1,saved=True),
                                                   _phase_view(obs,0)))
            obs['bootstrap_control_passed']=row['passed']
            obs['measurement_interpretation_allowed']=row['passed']
        else:
            row['interpretation_blocked']=True
        if not row['passed']:
            failures.append({'backend':backend,'stage':'bootstrap',
                'failure':obs['failures'] or ['Ordinary bootstrap coefficient regression failed']})
        bootstrap.append(row)
    def measure(label,left,right,left_saved=False,right_saved=False):
        allowed=lambda x,is_saved: x['eligible'] and (is_saved or x['measurement_interpretation_allowed'])
        eligible=allowed(left,left_saved) and allowed(right,right_saved)
        row={'label':label,'reference_id':left['id'],'candidate_id':right['id'],
             'eligible':eligible,'passed':False}
        if eligible:
            row.update(legacy.compare_coefficients(_phase_view(left,1,saved=left_saved),
                                                   _phase_view(right,1,saved=right_saved)))
        else:
            row.update(interpretation_blocked=True,blocked_workers=[x['id'] for x,s in
                       ((left,left_saved),(right,right_saved)) if not allowed(x,s)])
        if not row['passed']:
            failures.append({'stage':'measurement','comparison':label,
                'failure':'Coefficient disagreement' if eligible else 'Native/software/bootstrap gate blocked interpretation'})
        measurements.append(row)
    measure('NinjaRS8_vs_Ninja6',observations[8],observations[6])
    for backend in (8,6):
        for label in ('CMS20_CT_original_QP','CMS20_CT_candidate_QP','CMS20_TIRust_candidate_QP'):
            measure(f'reference{backend}_vs_{label}',saved['observations'][label],observations[backend],left_saved=True)
    pids=[x['native_pid'] for x in observations.values() if x['native_pid'] is not None]
    distinct=len(pids)==2 and len(set(pids))==2
    if not distinct:
        failures.append({'stage':'ownership','failure':'Two distinct completed native workers not established'})
    native_gate=all(x['eligible'] and x['native_usage_gate_passed'] for x in observations.values()) and distinct
    bootstrap_gate=all(x['passed'] for x in bootstrap)
    return {'schema':'private-cms20-reference-comparison-v1','passed':not failures,
        'execution_complete':all(x['structural_complete'] for x in observations.values()) and distinct,
        'native_usage_gate_passed':native_gate,'bootstrap_controls_passed':bootstrap_gate,
        'reference_gate_passed':native_gate and bootstrap_gate,
        'references_agree':measurements[0]['eligible'] and measurements[0]['passed'],
        'backend_order':[8,6],'workers_requested':2,
        'outer_entries_observed':sum(x['outer_entries_observed'] for x in observations.values()),
        'ready_done_maps':sum(x['ready_done_maps'] for x in observations.values()),
        'observations':{str(k):v for k,v in observations.items()},'bootstrap_comparisons':bootstrap,
        'measurement_comparisons':measurements,'failures':failures,'saved_source_evidence':saved['source_evidence'],
        'comparison_source_sha256':OLD_COMPARE_SHA,'usage_source_sha256':USAGE_SHA,
        'criterion':'LoopMEComparator: abs(a-b)/abs(a+b)<tolerance, or pole magnitude/finite maximum<tolerance',
        'relative_error_metric':'abs(a-b)/max(abs(a),abs(b)); zero-zero is zero',
        'tolerance':'3e-6','ordinary_target_tolerance':'1e-8',
        'winner_selected':False,'same_native_input_established':False,
        'independent_accuracy_qualified':False,'normal_host_stability_qualified':False,
        'performance_measurement':False,
        'limitations':['Fixed120 returns are unchecked host evaluations.',
            'Native status0 and128-bit transport do not prove coefficient accuracy.',
            'Legacy reference invariant projection differs from candidate9 direct invariants; same-input truth is not established.',
            'All disagreements are retained; no majority vote or automatic retry.']}
