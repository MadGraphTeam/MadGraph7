import unittest
from unittest.mock import patch
import prepare
import usage


def sample(backend=6, status=0, width=128):
    lines = []
    seq = 0
    for phase in (0, 1):
        lines.append(f'REF_BEGIN {phase}')
        for step in (0, 1):
            seq += 1
            lines.append('REF_NATIVE ' + ' '.join(map(str, [seq, phase, step,
                backend, 4, width, 113, 3, 1, 4, 2, -999 if step == 0 else status])))
        lines.append(f'REF_END {phase} {seq}')
    return '\n'.join(lines)


class Proposal(unittest.TestCase):
    def test_only_native_hooks_added_to_original_adapter(self):
        old = prepare.source('CT_interface')
        new = prepare.derive_adapter(old)
        lines = new.splitlines(keepends=True)
        kept = []
        hooks = 0
        i = 0
        while i < len(lines):
            if lines[i].startswith('      CALL PC_REF_NATIVE('):
                self.assertIn('STORAGE_SIZE(', lines[i + 1])
                self.assertIn('ID,SQSOINDEX,NLOOPLINE,RANK,', lines[i + 2])
                i += 3
                hooks += 1
            else:
                kept.append(lines[i])
                i += 1
        self.assertEqual(hooks, 8)
        self.assertEqual(''.join(kept), old)

    def test_hash_checked_before_parse(self):
        with patch.object(prepare, 'pin', return_value={'bytes': 0, 'sha256': 'wrong'}):
            with self.assertRaisesRegex(ValueError, 'Changed input'):
                prepare.source('CT_interface')

    def test_source_anchor_drift_fails(self):
        with self.assertRaisesRegex(ValueError, 'Ambiguous'):
            prepare.derive_adapter(prepare.source('CT_interface').replace(
                '      CALL NINJA_TENSOR_EVALUATE(TENSORCOEFS,',
                '      CALL CHANGED_TENSOR_EVALUATE(TENSORCOEFS,', 1))

    def test_driver_is_qp_only_and_bounded(self):
        driver = prepare.derive_driver(prepare.source('driver'))
        self.assertIn("IF(TRIM(ARG).NE.'4') STOP 21", driver)
        self.assertIn("IF(TRIM(ARG).NE.'6'.AND.TRIM(ARG).NE.'8') STOP 21", driver)
        self.assertIn('POINT_ID.NE.1.AND.POINT_ID.NE.20', driver)
        self.assertEqual(driver.count('CALL ML5_0_SLOOPMATRIX_THRES('), 2)
        self.assertEqual(driver.count('CALL PC_REF_PHASE_START('), 2)
        self.assertEqual(driver.count('CALL PC_REF_FLUSH\n'), 2)
        self.assertIn('SEQUENCE.GE.4096', driver)
        self.assertIn('UseQPIntegrandForNinjaRS', driver)
        self.assertIn('UseQPIntegrandForNinja)', driver)

    def test_native_hook_is_integer_only_and_no_io(self):
        body = prepare.LOGGER.split('      SUBROUTINE PC_REF_NATIVE(')[1].split('      END\n')[0]
        for forbidden in ('REAL', 'COMPLEX', 'WRITE(', 'FLUSH(', 'READ(', 'IEEE_', 'ALLOCATE', 'ML5_0_'):
            self.assertNotIn(forbidden, body)
        self.assertIn('RECORDS(:,SEQUENCE)=', body)

    def test_card_only_backend_changes(self):
        original = prepare.source('card')
        for backend in (6, 8):
            changed = prepare.card(original, backend)
            self.assertEqual(changed.replace(f'#MLReductionLib\n{backend}\n', '#MLReductionLib\n1\n'), original)
        with self.assertRaises(ValueError):
            prepare.card(original, 7)

    def test_usage_good_both_backends(self):
        for backend in (6, 8):
            result = usage.parse(sample(backend), backend)
            self.assertTrue(result['passed'])
            self.assertEqual(result['native_completed_per_phase'], {'0': 1, '1': 1})
            self.assertFalse(result['coefficient_accuracy_proven'])

    def test_ninja_test_failed_retained(self):
        result = usage.parse(sample(status=1), 6)
        self.assertFalse(result['passed'])
        self.assertEqual(len(result['nonzero_native_statuses']), 2)

    def test_dp_fallback_rejected(self):
        with self.assertRaisesRegex(ValueError, 'precision differs'):
            usage.parse(sample(width=64), 6)

    def test_missing_native_return_rejected(self):
        with self.assertRaises(ValueError):
            usage.parse('\n'.join(sample().splitlines()[:-2]), 6)

    def test_truncation_after_complete_pair_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Incomplete'):
            usage.parse('\n'.join(sample().splitlines()[:-1]), 6)

    def test_end_count_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError, 'end/count'):
            usage.parse(sample().replace('REF_END 1 4', 'REF_END 1 2'), 6)

    def test_unknown_backend_rejected(self):
        with self.assertRaises(ValueError):
            usage.parse(sample(), 7)
        with self.assertRaises(ValueError):
            usage.parse(sample(), 8)

    def test_changed_route_on_return_rejected(self):
        text = sample().replace('REF_NATIVE 2 0 1 6 4 128 113 3',
                                'REF_NATIVE 2 0 1 6 4 128 113 4')
        with self.assertRaisesRegex(ValueError, 'Unmatched'):
            usage.parse(text, 6)


if __name__ == '__main__':
    unittest.main()
