#!/usr/bin/env python3
"""Summarize only eligible, closed coefficients and old input provenance."""
from fractions import Fraction
import json
import struct
import prepare


def binary64(word):
    return Fraction.from_float(struct.unpack('>d', bytes.fromhex(word))[0])


def summary():
    data = json.loads(prepare.source('point20_comparison'))
    prepare.require(data['subset_scope']['closed_parent_stress_sha256'] ==
                    'c696421eb4948b4d2de5993cc84455b1ac04d0f659b245341729714f91ae8482',
                    'Unexpected closed subgroup')
    rows = [x for x in data['comparisons'] if x['label'] == 'candidate9_vs_original1' and x['mode'] == 4]
    prepare.require(len(rows) == 1 and rows[0]['eligible'], 'No eligible QP comparison')
    columns = [{k: row[k] for k in ('coefficient', 'order', 'reference_word', 'candidate_word',
                                   'reference', 'candidate', 'relative_error', 'passed', 'pole_to_finite')}
               for row in rows[0]['residuals']]
    control = []
    selected = []
    for mode in (1, 4):
        obs = data['observations'][f'cms-p20-mode{mode}-lib1-original']
        prepare.require(obs['eligible'], 'Failed controls must remain opaque')
        selected.append(next(x for x in obs['raw_rows'] if x['phase'] == 1 and x['order'] == 0))
    for index, name in enumerate(('Born', 'finite', 'single_pole', 'double_pole')):
        dp, qp = (binary64(x['words'][index]) for x in selected)
        residual = abs(dp - qp) / max(abs(dp), abs(qp)) if dp or qp else Fraction(0)
        control.append({'coefficient': name, 'DP_word': selected[0]['words'][index],
                        'QP_word': selected[1]['words'][index],
                        'relative_error_numerator': str(residual.numerator),
                        'relative_error_denominator': str(residual.denominator),
                        'relative_error_decimal': format(float(residual), '.17e')})
    geometry = json.loads(prepare.source('conditional_geometry'))
    pairs = [x for x in geometry['rows'] if x['stream'] == 'cms-point20-mode4-enabled'
             and x['pair'] == [2, 4]]
    prepare.require(sorted(x['route'] for x in pairs) == [3, 4, 8, 12, 24], 'Captured route set differs')
    return {'schema': 'private-cms20-reference-diagnosis-v1', 'native_actions': 0,
            'parent_stress_remains_failed': True, 'failed_coefficients_decoded': False,
            'eligible_QP_coefficients': columns, 'CutTools_DP_QP_difference': control,
            'old_QP_input_pairs': pairs,
            'candidate_native_geometry_observed': False,
            'per_group_successful_coefficients_observed': False,
            'responsible_group_identified': False,
            'unresolved': ['finite and single-pole truth', 'actual candidate per-group native invariants',
                           'independent native status-qualified QP reference',
                           'normal host checked stability/rescue'],
            'hypothesis_limits': [
                'Near-two double-pole ratio does not establish a common normalization error.',
                'Legacy helper zeroing is proven on old captured inputs; new candidate decisions were not logged.',
                'Ninja/NinjaRS references preserve legacy projected geometry; agreement is not necessarily a same-input adjudication.',
                'CutTools QP is not independent truth merely because its software flags are clear.']}


if __name__ == '__main__':
    result = summary()
    with (prepare.HERE / 'diagnosis.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'native_actions': 0, 'output': prepare.pin(prepare.HERE / 'diagnosis.json')}))
