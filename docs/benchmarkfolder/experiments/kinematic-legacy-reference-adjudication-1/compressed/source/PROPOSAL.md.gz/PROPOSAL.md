# CMS20 legacy-reference adjudication: source-only proposal

No compilation, loader query, native evaluation, Git operation, production edit,
library change, or reference-repository change was performed for this packet.
The failed amplitude campaign remains failed and incomplete. This is an
uncompiled proposal. Its controller defaults to file-only verification; native
execution additionally requires the parent's separate conditional admission,
a sealed source packet, passing pure tests and independent review.

## Closed finding

The parent stress closure is `c696421e…`; the separately retained pure CMS20
comparison is `7b2390b9…`. All numbers below come from eligible returned rows.
Failed TIRust DP and original TIRust QP coefficient words remain opaque.
Total order 0 and split order 1 contain identical words, so the discrepancy is
duplicated rather than confined to one split order.

| Coefficient | Original CutTools QP | Candidate TIRust QP | Relative residual |
|---|---:|---:|---:|
| Born | 0.0338642869505281705 | same | 0 |
| finite | 0.00819205173742339546 | -0.0344596168243842746 | 1.23772904322 |
| single pole | -0.00233546698305832400 | -0.00496751292099207806 | 0.529851855406 |
| double pole | -0.0000813899644760634566 | -0.000162776864325700260 | 0.499990586419 |

All three Laurent columns fail the existing `3e-6` criterion; the small-pole
exception does not apply. A nearly doubled double pole does not establish a
uniform normalization error: the finite term changes sign and the single pole
has a different ratio. The candidate retains the original Laurent mapping and
QP contraction normalization. At ordinary point 1 the original and candidate
TIRust words were identical in DP and QP.

CutTools DP and QP themselves differ by about 1.666%, 0.9355%, and 0.1332% for
finite, single pole, and double pole. Clear software flags and fixed return 120
do not establish an accurate reference. A separate universal-double-pole audit
is sealed at `.tirust-build/cms-universal-qed-pole-audit-1/index.json`
(`5748eeb6…`); its support for candidate9 applies
only to that coefficient and is not a finite/single-pole qualification here.

## What the retained geometry does and does not establish

The authenticated conditional input packet `a51a685a…` reconstructs the old
CMS20 QP raw pair (2,4) for groups 3, 4, 8, 12, and 24 as approximately
`-2.49999999999979135261276717087177703e-7`. The original helper took its zero
branch for these pairs, with no preceding mass snap. Each is a structural
composite pair; the conditional arithmetic certificate admits a veto with an
error bound far smaller than the raw magnitude. `diagnosis.json` retains the
exact old words and per-route bounds.

This establishes a possible input change for those five captured routes.
The new amplitude run did not record actual certification decisions, native
invariants, or successful per-group contributions. It therefore cannot identify
which group causes the finite/pole mismatch, prove that all 26 routes behaved
as expected, or attribute the change to a particular scalar kernel. No old
failed output is used to make such an attribution.

Both reference adapters must retain their original helper policy:

1. Build the original cumulative chords, preserving their first residual.
2. Call the original `MP_BUILD_KINEMATIC_MATRIX` with its unchanged branch order
   and `OSThres=1e-8`.
3. Form native invariants as `REAL(S_MAT(i,j)+mass2(i)+mass2(j), KIND=QP)`.

Thus legacy Ninja/NinjaRS can inherit a zeroed small spacelike invariant where
candidate9 conditionally passes raw `DIFFSQ` directly. Identical phase-space
cards and repairs do **not** imply identical native geometry. This first
reference experiment preserves that distinction. It is not a consistent-native-
input adjudication, and it changes no scalar on-shell threshold or mass policy.
A later exact input trace and consistent-input standalone comparison may be
needed if these legacy references do not settle the discrepancy.

## Concrete private derivative

The original sealed ELF accepts only backend arguments 1 or 9; changing only its
card also fails its backend-consistency guard. It cannot honestly execute 6/8.
The proposed successor reuses every original numerical object/archive except
`check_sa.o` and `CT_interface.o`, which are rebuilt from the two supplied
private source derivatives. No scientific library is rebuilt.

- `driver-reference.f` accepts only mode 4, point 1 or 20, and backend 6 or 8.
  It keeps exactly one ordinary-point bootstrap and one measurement call,
  `FORCE_STABILITY_CHECK(.FALSE.)`, literal full-pole mode 0, finite evaluation,
  and all existing numerical inputs and thresholds. It additionally checks the
  Ninja and NinjaRS genuine-QP-integrand switches.
- `CT_interface.f` adds only eight passive observer calls around the four
  existing DP/QP native reduction paths. Removing these calls restores the
  original file byte-for-byte. Every native call argument and arithmetic
  expression is unchanged. The DP hooks expose any unexpected fallback.
- The observer records integer phase, attempt/return, backend, actual CT mode,
  native real storage width/digits, group/split-order, topology/rank, and raw
  native status. Inside reduction it performs only bounded integer assignments
  to a new private COMMON. It does not read coefficients, perform floating-point
  arithmetic, write legacy COMMONs, change flags, allocate, or do I/O.
- Logs flush only after an outer amplitude returns. The 4096-record bound is
  fixed for the entire worker (196608 bytes of integer records on the qualified
  32-bit-integer compiler). Exceeding it fails the diagnostic. An interrupted
  outer call may lose its buffered records; it remains unqualified.
- Each flush terminates with an explicit phase/end-count marker. A truncated
  log ending at a completed native-call pair still fails completeness.
- `usage.py` requires paired attempts/returns in both phases, backend identity,
  mode 4, 128-bit storage and 113 significand bits, no DP calls, and raw status 0
  for every native return before coefficient interpretation. Native nonzero
  statuses are retained. In particular, Ninja status 1 is not silently accepted:
  the legacy adapter only sets its software failure flag for status 2.

COLLIER is excluded: the frozen generated availability table says backend 7 has
no QP implementation. Backends 6 and 8 are marked QP-capable. The reduction and
integrand are QP, but squared masses and scale retain their original DP-derived
values and final amplitude output is binary64. NinjaRS uses the oneloopmaster scalar code family also used
by TIRust (with separately pinned revisions), so it is not a wholly independent scalar implementation.

## Proposed separately gated native sequence

The future executor root is
`.tirust-build/kinematic-invariant-reference-adjudication-executor-1`.
The controller must be sealed and independently reviewed before either gate is
admitted. `run.py build` and `run.py run` are separate append-only gates; omitting
`--execute` runs only file-backed prerequisite verification. The run gate also
requires the exact reviewed closed-build hash. Neither gate starts the other.

**Build-only gate:** clone the closed original build; bind and rehash all source,
objects, archives, compiler and prelink files before copying. Rebuild only the
two specified objects with the closed flags, then link one fresh ELF. Verify
preserved objects/libraries before and after. Bind actual PT_INTERP before one
loader `--list` query; reconcile the exact closed 15-provider set before any
future worker. Use the retained OwnedChild/deadline/mutex machinery, CPU 12
nonexclusive, jobs 1, 300 seconds after lock (240 work plus 60 cleanup), and no
Fortran main. Preflight, lock wait and post-verification are outside that work
cap. Unknown providers or failures stop the gate without retry.

**Reference-run gate after closed-build review:** exactly two fresh workers,
first NinjaRS 8 then Ninja 6, each with point 1 bootstrap and CMS20 measurement,
mode 4. Maximum four outer entries. Reuse the existing 8-GiB worker, 180-second
bootstrap, 300-second measurement, 600-second owned-command, stdout/file limits,
and fixed no-retry cleanup. Stage cap: 1500 seconds after lock, with the final
60 reserved for cleanup; same qualification on preflight/lock/post-verification.
No CMS21 request, DP reference run, automatic rescue, extra bootstrap, or
timing-acceptance run is permitted.

Authenticate each literal card and saved point before launch. Verify actual
ELF/provider maps at READY and DONE. Retain source/ELF/archive/provider hashes,
all integer/word outputs, native call logs, software flags, return codes,
warnings, ownership/cleanup receipts, and unexecuted requests on failure.

Before interpreting CMS20, require eligible ordinary bootstrap output, raw
native status 0 and the actual usage contract, and compare its Born/finite/poles
and split orders with the saved CutTools QP ordinary reference. A failed
bootstrap gate blocks measurement coefficient interpretation. At CMS20 apply
the same eligibility gate, retain every failure, and compare both references
with each other and with the eligible saved CutTools QP/candidate9 QP rows using
the existing criterion. Do not choose a winner by majority or native status.
Disagreement remains open and motivates a separately reviewed exact-native-input
study. This experiment does not qualify normal host stability or performance.

## Pure verification

From the repository root, with `tools/tirust_env.sh` sourced:

```
python3 -B -m unittest discover -s .tirust-build/kinematic-invariant-reference-adjudication-proposal-1 -p test_proposal.py -v
```

The pure tests cover source reconstruction, hash-before-parse rejection,
anchor drift, exact card deltas, QP-only bounds, integer-only observation, and
native usage/status failures, the actual inherited size/bytes dependency schema,
the retained runtime-query stage namespace, and immutable worker ownership and
limits. `diagnose.py` reproduces the closed-data diagnosis
without parsing failed coefficients. `prepare.py` is a pure derivation helper,
not a build/controller command; its output writes require absent target files.
