"""Synthetic evidence tests. No native reducer or process is run."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock
import reference_compare as R

# Reuse the closed synthetic file fixture, authenticated before pure code load.
_index=json.loads(R.checked(R.OLD/'index.json',R.OLD_INDEX_SHA))
_fixture_raw=R.checked(R.OLD/'test_amplitude_compare.py',_index['files']['test_amplitude_compare.py'])
R.checked(R.OLD/'amplitude_compare.py',R.OLD_COMPARE_SHA)
sys.path.insert(0,str(R.OLD))
FIX=types.ModuleType('closed_reference_test_fixtures')
FIX.__file__=str(R.OLD/'test_amplitude_compare.py')
exec(compile(_fixture_raw,FIX.__file__,'exec'),FIX.__dict__)


def request(backend):
    return {'id':f'cms-p20-mode4-lib{backend}-reference','variant':'reference','stage':'run',
            'backend':backend,'requested_mode':4,'point':20,'expected_fixed_unchecked_return':120,
            'bootstrap_calls':1,'measurement_calls':1,'outer_entries_max':2,
            'card':f'backend{backend}-mode4-MadLoopParams.dat','physical_card':'inputs/cms-param_card.dat',
            'bootstrap':'inputs/cms-point1.dat','measurement':'inputs/cms-point20.dat'}


def usage(backend,width=128,digits=113,status=0):
    lines=[];sequence=0
    for phase in [0,1]:
        lines.append(f'REF_BEGIN {phase}')
        for step in [0,1]:
            sequence+=1
            values=[sequence,phase,step,backend,4,width,digits,3,1,4,2,-999 if step==0 else status]
            lines.append('REF_NATIVE '+' '.join(map(str,values)))
        lines.append(f'REF_END {phase} {sequence}')
    return '\n'.join(lines)+'\n'


def saved_observation(label,point,coefs=(1.,2.,-3.,4.)):
    words=[FIX.word(x) for x in (*coefs,-1.)]
    return {'id':label,'eligible':True,'raw_rows':[{'phase':1,'point':point,'order':order,
            'code':120,'call':2,'words':words[:]} for order in [0,1]]}


def synthetic_saved(candidate9=(1.,2.,-3.,4.)):
    return {'source_evidence':{'synthetic':'unit-test-only'},'observations':{
        'ordinary_CT_QP':saved_observation('saved-ordinary-CT',1),
        'CMS20_CT_original_QP':saved_observation('saved-CMS20-original-CT',20),
        'CMS20_CT_candidate_QP':saved_observation('saved-CMS20-candidate-CT',20),
        'CMS20_TIRust_candidate_QP':saved_observation('saved-CMS20-candidate-TIRust',20,candidate9)}}


class ReferenceCompare(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.root=self.base/'runs';self.root.mkdir()
        self.legacy=R._legacy()
        self.patch=mock.patch.object(R,'_legacy',return_value=self.legacy)
        self.patch.start();self.addCleanup(self.patch.stop)
        self.saved_patch=mock.patch.object(R,'load_saved',return_value=synthetic_saved())
        self.saved_mock=self.saved_patch.start();self.addCleanup(self.saved_patch.stop)
        self.requests=[request(8),request(6)]

    def worker(self,backend,*,coefs=(1.,2.,-3.,4.),bootstrap=(1.,2.,-3.,4.),
               log=None,flags=(0,0),warning=False):
        r=request(backend)
        d=FIX.make_worker(self.root,r,100+backend,coefs=coefs,final_flags=flags,warning=warning)
        (d/'trace.dat').write_text(usage(backend) if log is None else log)
        rows=(d/'driver-bits.dat').read_text().splitlines()
        for index in [0,1]:
            fields=rows[index].split();fields[5:]=[FIX.word(x) for x in (*bootstrap,-1.)]
            rows[index]=' '.join(fields)
        (d/'driver-bits.dat').write_text('\n'.join(rows)+'\n')
        (d/'bootstrap-values.dat').write_text(''.join(f'1 1 {order} 120 '+' '.join(map(str,(*bootstrap,-1.)))+'\n'
                                                    for order in [0,1]))
        FIX.reseal(d)
        cwd=self.base/'workers'/r['id']/'SubProcesses/P0_epem_mupmum';cwd.mkdir(parents=True)
        cards=cwd.parents[1]/'Cards';cards.mkdir()
        numerical=R.checked(R.HERE/r['card'],R.CARD_SHAS[backend])
        (cards/'MadLoopParams.dat').write_bytes(numerical)
        physical,physical_record=R._binding('physical_card',R.INPUT_SHAS['physical_card'])
        point1,_=R._binding('point1',R.INPUT_SHAS['point1'])
        point20,_=R._binding('point20',R.INPUT_SHAS['point20'])
        (cards/'param_card.dat').write_bytes(physical)
        (cwd/'bootstrap.dat').write_bytes(point1);(cwd/'point.dat').write_bytes(point20)
        spec={'request':r,'cwd':str(cwd),'bootstrap_file':str(cwd/'bootstrap.dat'),'point_file':str(cwd/'point.dat'),
              'numerical_card':R.pin(numerical),'physical_card':R.pin(physical),
              'bootstrap_pin':R.pin(point1),'point_pin':R.pin(point20)}
        (d/'specification.json').write_text(json.dumps(spec))
        return d

    def complete(self,**kwargs):
        self.worker(8,**kwargs);self.worker(6)
        return R.compare_reference_stage(self.root,self.requests)

    def test_valid_reference_gate_and_all_orders(self):
        report=self.complete()
        self.assertTrue(report['passed'])
        self.assertTrue(report['reference_gate_passed'])
        self.assertTrue(report['references_agree'])
        self.assertEqual(report['backend_order'],[8,6])
        self.assertEqual(report['outer_entries_observed'],4)
        self.assertEqual(report['ready_done_maps'],4)
        self.assertEqual(len(report['bootstrap_comparisons']),2)
        self.assertEqual(len(report['measurement_comparisons']),7)
        self.assertTrue(all(len(x['residuals'])==8 for x in report['bootstrap_comparisons']+report['measurement_comparisons']))
        self.assertFalse(report['winner_selected'])
        self.assertFalse(report['independent_accuracy_qualified'])
        self.assertFalse(report['same_native_input_established'])
        json.dumps(report,allow_nan=False)

    def test_nonzero_native_status_precedes_any_column_parser(self):
        d=self.worker(8,log=usage(8,status=1))
        with mock.patch.object(self.legacy,'inspect_worker',side_effect=AssertionError('must not parse columns')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible'])
        self.assertFalse(obs['native_usage_gate_passed'])
        self.assertEqual(obs['raw_rows'],[])
        self.assertEqual(len(obs['native_usage']['nonzero_native_statuses']),2)

    def test_completed_native_failure_retains_execution_evidence_and_opaque_values(self):
        self.worker(8,log=usage(8,status=1),coefs=(123.,2.,-3.,4.),bootstrap=(124.,2.,-3.,4.))
        self.worker(6)
        decoded=[];original=self.legacy.decode64
        def observing(word):
            decoded.append(word)
            return original(word)
        with mock.patch.object(self.legacy,'decode64',side_effect=observing):
            report=R.compare_reference_stage(self.root,self.requests)
        self.assertTrue(report['execution_complete'])
        self.assertFalse(report['native_usage_gate_passed'])
        self.assertFalse(report['passed'])
        self.assertEqual(report['outer_entries_observed'],4)
        self.assertEqual(report['ready_done_maps'],4)
        obs=report['observations']['8']
        self.assertTrue(obs['protocol_complete']);self.assertTrue(obs['structural_complete'])
        self.assertEqual(obs['native_pid'],108)
        self.assertEqual(obs['outer_entries_observed'],2);self.assertEqual(obs['ready_done_maps'],2)
        self.assertFalse(obs['native_usage_gate_passed']);self.assertFalse(obs['measurement_interpretation_allowed'])
        self.assertEqual(obs['raw_rows'],[])
        self.assertNotIn(FIX.word(123.),decoded);self.assertNotIn(FIX.word(124.),decoded)
        blocked=[x for x in report['measurement_comparisons'] if 'reference8_' in x['label'] or x['label']=='NinjaRS8_vs_Ninja6']
        self.assertTrue(all(not x['eligible'] and 'residuals' not in x for x in blocked))
        self.assertFalse(any(x['stage']=='ownership' for x in report['failures']))

    def test_entry_evidence_requires_hash_verification_before_structural_completion(self):
        d=self.worker(8,log=usage(8,status=1))
        (d/'driver-state.dat').write_text('tampered')
        with mock.patch.object(R,'_usage',side_effect=AssertionError('must not parse usage')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['structural_complete']);self.assertEqual(obs['outer_entries_observed'],0)
        self.assertFalse(obs['native_usage_gate_passed']);self.assertEqual(obs['raw_rows'],[])
        self.assertTrue(any('Pinned bytes changed' in x for x in obs['failures']))

    def test_dp_width_or_wrong_digits_block_before_column_parser(self):
        d=self.worker(8,log=usage(8,width=64,digits=53))
        with mock.patch.object(self.legacy,'inspect_worker',side_effect=AssertionError('must not parse columns')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible']);self.assertIn('trace.dat',obs['source_evidence'])
        self.assertTrue(any('precision differs' in x for x in obs['failures']))

    def test_missing_ref_end_blocks_complete_outer_worker(self):
        d=self.worker(8,log='\n'.join(usage(8).splitlines()[:-1])+'\n')
        obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible']);self.assertFalse(obs['native_usage_gate_passed'])
        self.assertEqual(obs['raw_rows'],[])

    def test_trace_hash_checked_before_usage_parser(self):
        d=self.worker(8);(d/'trace.dat').write_text('tampered')
        with mock.patch.object(R,'_usage',side_effect=AssertionError('must not parse')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible'])
        self.assertTrue(any('Pinned bytes changed' in x for x in obs['failures']))

    def test_bootstrap_failure_keeps_measurement_opaque(self):
        self.worker(8,coefs=(123.,2.,-3.,4.),bootstrap=(2.,2.,-3.,4.));self.worker(6)
        decoded=[];original=self.legacy.decode64
        def observing(word):
            decoded.append(word)
            return original(word)
        with mock.patch.object(self.legacy,'decode64',side_effect=observing):
            report=R.compare_reference_stage(self.root,self.requests)
        self.assertFalse(report['passed']);self.assertFalse(report['bootstrap_controls_passed'])
        self.assertFalse(report['observations']['8']['measurement_interpretation_allowed'])
        self.assertNotIn(FIX.word(123.),decoded)
        blocked=[x for x in report['measurement_comparisons'] if 'reference8_' in x['label'] or x['label']=='NinjaRS8_vs_Ninja6']
        self.assertTrue(all(not x['eligible'] and 'residuals' not in x for x in blocked))
        self.assertTrue(all(x['eligible'] for x in report['measurement_comparisons'] if 'reference6_' in x['label']))

    def test_software_flags_block_all_coefficient_decoding(self):
        d=self.worker(8,flags=(0,1))
        with mock.patch.object(self.legacy,'decode64',side_effect=AssertionError('must not decode')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertTrue(obs['native_usage_gate_passed']);self.assertFalse(obs['eligible'])
        self.assertTrue(any('Failed DP/QP' in x for x in obs['failures']))

    def test_w03_blocks_even_zero_native_status(self):
        d=self.worker(8,warning=True);obs=R.inspect_reference_worker(d,request(8))
        self.assertTrue(obs['native_usage_gate_passed']);self.assertFalse(obs['eligible'])
        self.assertIn('Incomplete-contribution warning W03',obs['failures'])

    def test_disagreements_do_not_choose_majority_winner(self):
        report=self.complete(coefs=(1.,3.,-3.,4.))
        self.assertTrue(report['reference_gate_passed'])
        self.assertFalse(report['references_agree']);self.assertFalse(report['passed'])
        self.assertFalse(report['winner_selected'])
        failures=[x for x in report['measurement_comparisons'] if x['eligible'] and not x['passed']]
        self.assertEqual(len(failures),4)
        self.assertTrue(all({r['coefficient'] for r in x['failures']}=={'finite'} for x in failures))

    def test_reference_agreement_does_not_hide_saved_candidate_disagreement(self):
        self.saved_mock.return_value=synthetic_saved(candidate9=(1.,7.,-3.,4.))
        report=self.complete()
        self.assertTrue(report['references_agree']);self.assertTrue(report['reference_gate_passed'])
        self.assertFalse(report['passed']);self.assertFalse(report['winner_selected'])
        failed=[x['label'] for x in report['measurement_comparisons'] if not x['passed']]
        self.assertEqual(failed,['reference8_vs_CMS20_TIRust_candidate_QP','reference6_vs_CMS20_TIRust_candidate_QP'])

    def test_materialized_card_change_blocks_before_native_usage(self):
        d=self.worker(8);spec=json.loads((d/'specification.json').read_text())
        cards=Path(spec['cwd']).parents[1]/'Cards/MadLoopParams.dat';cards.write_bytes(cards.read_bytes()+b'! changed\n')
        with mock.patch.object(R,'_usage',side_effect=AssertionError('must not parse')):
            obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible']);self.assertFalse(obs['native_usage_gate_passed'])

    def test_request_order_and_scope_are_fixed(self):
        with self.assertRaisesRegex(ValueError,'backend8 then backend6'):
            R.compare_reference_stage(self.root,list(reversed(self.requests)))
        wrong=copy.deepcopy(self.requests);wrong[0]['point']=21
        with self.assertRaisesRegex(ValueError,'admitted scope'):
            R.validate_requests(wrong)

    def test_measurement_helper_refuses_failed_bootstrap(self):
        obs=saved_observation('opaque',20);obs['measurement_interpretation_allowed']=False
        with self.assertRaisesRegex(ValueError,'Bootstrap gate failed'):
            R._phase_view(obs,1)

    def test_incomplete_runtime_maps_block_decoding(self):
        d=self.worker(8);native=json.loads((d/'result.json').read_text());native['runtime_maps'].pop()
        (d/'result.json').write_text(json.dumps(native))
        obs=R.inspect_reference_worker(d,request(8))
        self.assertFalse(obs['eligible'])
        self.assertTrue(any('runtime maps' in x for x in obs['failures']))

if __name__=='__main__':
    unittest.main(verbosity=2)
