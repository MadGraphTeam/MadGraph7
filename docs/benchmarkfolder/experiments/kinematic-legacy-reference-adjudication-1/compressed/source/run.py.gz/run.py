#!/usr/bin/env python3
"""Bounded private reference build/run gates. Default is file-only."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / '.tirust-build/kinematic-invariant-reference-adjudication-executor-1'
WORK, RESULTS = BASE / 'work', BASE / 'results'
OLD = ROOT / '.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA = 'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
P = H = V = PLAN = None
ACTUAL_MAKE_TRANSFORMS = []


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def verify_source(expected):
    global P, H, V, PLAN
    if V is None:
        V = load('reference_verify', HERE / 'verify.py')
    verified = V.verify(expected)
    if P is None:
        P = load('reference_retained_controller', OLD / 'run.py')
        H = load('reference_retained_build', OLD / 'build_stage.py')
        P.R, P.G, P.B, P.PLAN, P.TOOLCHAIN, protected = P.verify_source(OLD_SHA)
        P.BASE, P.WORK, P.RESULTS = BASE, WORK, RESULTS
    else:
        *_, protected = P.verify_source(OLD_SHA)
    PLAN = read(HERE / 'validation-plan.json')
    require([x['backend'] for x in PLAN['requests']] == [8, 6], 'Reference order differs')
    require(all(x['requested_mode'] == 4 and x['point'] == 20 and
                x['bootstrap_calls'] == x['measurement_calls'] == 1 and
                x['outer_entries_max'] == 2 for x in PLAN['requests']), 'Reference scope differs')
    return {'upstream': protected, 'source_index': V.pin(HERE / 'index.json'),
            'bindings': V.pin(HERE / 'bindings.json'), 'verified': verified}


def setup_owned(stage):
    L = P.setup_owned(stage)
    L.STAGES = ('build', 'run')
    L.CURRENT_STAGE = stage
    L.CPU = 12
    original = L.command

    def command(args, label, cwd=ROOT, timeout=600, cpu=True):
        args = [str(x) for x in args]
        if args and args[0] == 'make':
            changed = ['-j1' if x == '-j2' else x for x in args]
            if changed != args:
                ACTUAL_MAKE_TRANSFORMS.append({'label': label, 'inherited_request': args,
                                               'actual_argv': changed})
            args = changed
        return original(args, label, cwd, timeout, cpu)

    L.command = command
    P.R.PC_SAVE = save
    return L


def dependency_preflight(stage):
    L = setup_owned(stage)

    def forbidden(*args, **kwargs):
        raise ValueError('Native action forbidden in file-only dependency preflight')

    L.command = forbidden
    L.runtime = forbidden
    snapshot = P.R.dependency_snapshot()
    expected = P.B['external_private_files']
    require(all(snapshot.get(name) == value for name, value in expected.items()),
            'Inherited size/bytes dependency adapter differs')
    return {'native_actions': 0, 'files': len(snapshot), 'private_records': len(expected)}


def donor():
    binding = read(HERE / 'bindings.json')['files']['original_build']
    V.checked(ROOT / binding['path'], binding)
    item = read(ROOT / binding['path'])
    P.R.exact_inventory(Path(item['output']), item['sources'])
    P.R.L.q.verify_hashes(item['prelink_bound'])
    P.R.L.q.verify_hashes(item['runtime']['files'])
    V.checked(item['executable'], item['executable_pin'])
    for name, value in item['all_objects_after'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['reused_libraries'].items():
        V.checked(Path(item['output']) / name, value)
    return item


def literal_cards(output, request):
    for name, key in [('param_card.dat', 'physical_card'), ('MadLoopParams.dat', 'card')]:
        paths = {output / 'Cards' / name, *((output / 'SubProcesses').rglob(name))}
        for path in paths:
            H.write_private(output, path, (HERE / request[key]).read_bytes())


def build():
    original = donor()
    output = WORK / 'builds' / 'cms' / 'reference'
    require(not output.parent.exists(), 'Fresh build required; no retry')
    output.parent.mkdir(parents=True)
    dependencies = P.R.dependency_snapshot()
    H.clone(P.R, Path(original['output']), output)
    directory = output / 'SubProcesses' / H.SUBPROCESS
    literal_cards(output, PLAN['requests'][0])
    H.write_private(output, directory / 'check_sa.f', (HERE / 'driver-reference.f').read_bytes())
    H.write_private(output, directory / 'CT_interface.f', (HERE / 'CT_interface.f').read_bytes())
    make = (Path(original['output']) / 'SubProcesses' / H.SUBPROCESS / 'makefile').read_bytes()
    H.write_private(output, directory / 'makefile', make + b'\n.PHONY: pc-objects\npc-objects: check_sa.o CT_interface.o\n')
    stages_path = ROOT / P.B['current_stages']['path']
    V.checked(stages_path, P.B['current_stages'])
    stages = P.R.load('reference_retained_stages', stages_path)
    receipt = H.link_one(P.R, stages, output, 'reference', original,
                         ('check_sa.o', 'CT_interface.o'))
    H.preserved_objects(original['all_objects_after'], receipt['all_objects_after'],
                        {'check_sa.o', 'CT_interface.o'})
    require(P.QUERIES == ['reference'], 'Build requires exactly one loader query')
    require(dependencies == P.R.dependency_snapshot(), 'Dependencies changed during build')
    save(RESULTS / 'build-summary.json', {
        'executables': 1, 'compiled_objects': ['check_sa.o', 'CT_interface.o'],
        'reference_build': V.pin(RESULTS / 'builds/reference/build.json'),
        'executable': receipt['executable'], 'executable_pin': receipt['executable_pin'],
        'inherited_make_job_requests_and_actual_transform': ACTUAL_MAKE_TRANSFORMS,
        'actual_make_jobs': 1, 'native_main_calls': 0, 'tensor_calls': 0,
        'scientific_library_rebuilds': False, 'numerical_expressions_changed': False})


def reviewed_build(expected):
    require(expected, 'Explicit closed-build review required')
    require(V.pin(RESULTS / 'build-closure.json')['sha256'] == expected, 'Build closure differs')
    closure = read(RESULTS / 'build-closure.json')
    require(closure['passed'] and closure['source_index_sha256'] == V.pin(HERE / 'index.json')['sha256'],
            'Closed build failed or belongs to another source')
    for name, value in closure['payloads'].items():
        V.checked(RESULTS / name, value)
    item = read(RESULTS / 'builds/reference/build.json')
    V.checked(item['executable'], item['executable_pin'])
    P.R.exact_inventory(Path(item['output']), item['sources'])
    P.R.L.q.verify_hashes(item['prelink_bound'])
    P.R.L.q.verify_hashes(item['runtime']['files'])
    for name, value in item['all_objects_after'].items():
        V.checked(Path(item['output']) / name, value)
    for name, value in item['reused_libraries'].items():
        V.checked(Path(item['output']) / name, value)
    return item


def run_reference(build_sha, source_sha):
    item = reviewed_build(build_sha)
    completed, failure = [], None
    try:
        for request in PLAN['requests']:
            P.R.L.remaining(600)
            P.R.L.q.verify_hashes(item['prelink_bound'])
            output = H.clone(P.R, Path(item['output']), WORK / 'workers' / request['id'])
            literal_cards(output, request)
            directory = output / 'SubProcesses' / H.SUBPROCESS
            evidence = RESULTS / 'runs' / request['id']
            evidence.mkdir(parents=True, exist_ok=False)
            V.checked(directory / 'check', item['executable_pin'])
            runtime = P.runtime(directory / 'check', item['prelink_bound'], request['id'], item['runtime'])
            expected = {**runtime['files'], str((directory / 'check').resolve()): item['executable_pin']['sha256']}
            for key in ('bootstrap', 'measurement'):
                shutil.copyfile(HERE / request[key], directory / (key + '-input.dat'))
            specification = {'request': request, 'cwd': str(directory), 'expected_runtime': expected,
                'bootstrap_file': str(directory / 'bootstrap-input.dat'),
                'point_file': str(directory / 'measurement-input.dat'),
                'bootstrap_pin': V.pin(directory / 'bootstrap-input.dat'),
                'point_pin': V.pin(directory / 'measurement-input.dat'),
                'executable': str(directory / 'check'), 'executable_pin': item['executable_pin'],
                'evidence': str(evidence), 'source_index_sha256': source_sha,
                'numerical_card': V.pin(output / 'Cards/MadLoopParams.dat'),
                'physical_card': V.pin(output / 'Cards/param_card.dat')}
            specpath = evidence / 'specification.json'
            save(specpath, specification)
            P.R.command([sys.executable, '-B', HERE / 'worker_entry.py', specpath,
                         V.pin(specpath)['sha256'], source_sha], 'worker-' + request['id'], directory, 600)
            require(read(evidence / 'result.json')['orchestration_complete'], 'Incomplete worker retained')
            completed.append(request['id'])
        comparator = load('reference_comparator', HERE / 'reference_compare.py')
        comparison = comparator.compare_reference_stage(RESULTS / 'runs', PLAN['requests'])
        save(RESULTS / 'reference-comparison.json', comparison)
        require(comparison['passed'], 'Reference eligibility/agreement failed; evidence retained')
    except BaseException as exc:
        failure = repr(exc)
        raise
    finally:
        save(RESULTS / 'run-requests.json', {'requests': PLAN['requests'], 'completed': completed,
            'not_completed': [x for x in PLAN['requests'] if x['id'] not in completed],
            'failure': failure, 'maximum_outer_entries': 4, 'performance_measurement': False})


def payloads(stage):
    paths = {RESULTS / name for name in (f'stage-{stage}.json', f'{stage}-before.json', f'{stage}-after.json')}
    for label in P.COMMANDS:
        paths.update({RESULTS / 'execution' / (label + '.json'), RESULTS / 'execution' / (label + '.txt')})
    for label in P.QUERIES:
        paths.add(RESULTS / 'runtime' / (label + '.json'))
    if stage == 'build':
        paths.add(RESULTS / 'build-summary.json')
        folder = RESULTS / 'builds/reference'
        if folder.exists():
            paths.update(p for p in folder.rglob('*') if p.is_file())
    else:
        paths.update({RESULTS / 'reference-comparison.json', RESULTS / 'run-requests.json'})
        for request in PLAN['requests']:
            folder = RESULTS / 'runs' / request['id']
            if folder.exists():
                paths.update(p for p in folder.rglob('*') if p.is_file())
    return {str(p.relative_to(RESULTS)): V.pin(p) for p in sorted(paths) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('build', 'run'))
    parser.add_argument('--reviewed-source-index', required=True)
    parser.add_argument('--reviewed-build-sha256')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(Path.cwd() == ROOT, 'Run from repository root')
    before = verify_source(args.reviewed_source_index)
    preflight = dependency_preflight(args.stage)
    if not args.execute:
        print(json.dumps({'passed': True, 'stage': args.stage, 'dependency_preflight': preflight}))
        return
    require(not (RESULTS / ('stage-' + args.stage + '.json')).exists(), 'Append-only stage; no retry')
    if args.stage == 'run':
        require(args.reviewed_build_sha256, 'Separate closed-build review required')
    save(RESULTS / (args.stage + '-before.json'), before)
    L = setup_owned(args.stage)
    started = time.monotonic()
    failure = postfailure = lock = active = None
    with L.cleanup.SignalRequests() as signals:
        L.REQUESTS = P.R.BudgetRequests(signals)
        try:
            lock = P.R.acquire(signals)
            active = time.monotonic()
            with L.Deadline(PLAN[args.stage]['seconds_total'] - 60):
                if args.stage == 'build':
                    build()
                else:
                    run_reference(args.reviewed_build_sha256, args.reviewed_source_index)
        except BaseException as exc:
            failure = exc
        finally:
            if lock is not None:
                lock.close()
            try:
                after = verify_source(args.reviewed_source_index)
                require(after == before, 'Protected inputs changed')
                save(RESULTS / (args.stage + '-after.json'), after)
            except BaseException as exc:
                postfailure = exc
            result = {'stage': args.stage, 'passed': failure is None and postfailure is None,
                'failure': None if failure is None else repr(failure),
                'postcheck_failure': None if postfailure is None else repr(postfailure),
                'source_index_sha256': args.reviewed_source_index,
                'reviewed_build_sha256': args.reviewed_build_sha256,
                'owned_command_count': len(P.COMMANDS), 'loader_query_count': len(P.QUERIES),
                'elapsed_seconds': time.monotonic() - started,
                'elapsed_after_lock': None if active is None else time.monotonic() - active,
                'performance_measurement': False, 'host_stability_qualified': False}
            save(RESULTS / ('stage-' + args.stage + '.json'), result)
            save(RESULTS / (args.stage + '-closure.json'), {**result, 'payloads': payloads(args.stage)})
    if failure is not None:
        raise failure
    if postfailure is not None:
        raise postfailure


if __name__ == '__main__':
    main()
