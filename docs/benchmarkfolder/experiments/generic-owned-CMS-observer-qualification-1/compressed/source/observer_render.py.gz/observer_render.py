"""Pure-import, source-only composition on the exact CLOSED CMS BUILD2 inputs.

No compiler, loader, CLI generation or native stage is implemented here.
compose() returns text; generate() explicitly writes only a fresh source overlay.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import types

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'generic-owned-CMS-qualification-proposal-1'
CLOSED=HERE.parent/'generic-owned-CMS-plain-build-work-2/build'
CANONICAL=HERE.parent/'generic-owned-composite-source-2/candidate-2/SubProcesses/P0_epem_mupmum'
SUBPROCESS='SubProcesses/P0_epem_mupmum/'
RESULT_SHA='a3085e4db3ad63f4484e73c37c73ee24ce9ac06efaf7c65b25715a9e0144e072'
TERMINAL_SHA='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
PINS={'observer.f90':'64a490c1a21f84669ee617dc2351a4f04662654f5dc7cad6c9023c0d67410f9a',
      'observer_matrix.py':'6578ddf4a16d220c1bd2a9e16c0d7ce3c688759e2eafd8e7cdfcb4ab23f576bf',
      'observer_wire.py':'9fad9574ced2ca9df36e59638118358095fc3b1564318e4c34dd2ec49dce87eb',
      'normal-driver/render.py':'817ec5444409f3368537358ef2d88632d8609b20a9ed1e510da3dce6b5f65b7d',
      'normal-driver/normal_cms_driver.f.in':'8bb95faa6b85f74f9d92e9ce8d277900083187b0dcd8526396714cfcb61a66dc'}
ROLES={'SLOOPMATRIX_RETRY_IMPL':'retry','SLOOPMATRIX':'wrapper','SLOOPMATRIX_THRES':'threshold',
       'MP_COMPUTE_LOOP_COEFS':'mp','HELAS_CALLS_AMPB_1':'dp_batch','MP_HELAS_CALLS_AMPB_1':'qp_batch',
       'LOOP_CT_CALLS_1':'consumer','LOOP_1_2':'loop','LOOP_2':'loop','LOOP_3':'loop','LOOP_4':'loop',
       'TIRLOOP':'tirloop'}


def need(condition,message):
    if not condition:raise ValueError(message)


def identity(data):
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def bound(path,sha):
    data=path.read_bytes();need(identity(data)['sha256']==sha,'source pin changed: '+str(path))
    return data


def load_pure(name,relative):
    data=bound(BASE/relative,PINS[relative]);module=types.ModuleType(name)
    module.__file__=str(BASE/relative);sys.modules[name]=module
    exec(compile(data,str(BASE/relative),'exec'),module.__dict__)
    return module


def inputs():
    result_bytes=bound(CLOSED/'result.json',RESULT_SHA)
    terminal=json.loads(bound(CLOSED/'terminal.json',TERMINAL_SHA))
    result=json.loads(result_bytes)
    need(terminal['status']=='passed' and terminal['returncode']==0 and
         terminal['result_sha256']==RESULT_SHA and result['status']=='passed','BUILD2 not closed passed')
    need(result['native_main_calls']==0 and result['model_calls']==0 and result['reducer_calls']==0,
         'unexpected closed build scope')
    sources={};pins={};plain={}
    for lane in ('legacy','candidate'):
        variant=result['variants'][lane];inventory=variant['source_inventory'];pins[lane]={}
        for relative,expected in inventory.items():
            path=CLOSED/lane/relative;data=path.read_bytes()
            need(identity(data)==expected,'closed source inventory changed: '+str(path))
            pins[lane][relative]=expected
        elf=Path(variant['path']);need(elf==CLOSED/lane/SUBPROCESS/'check','unexpected plain ELF path')
        raw=elf.read_bytes();need(identity(raw)['sha256']==variant['sha256'] and raw[:4]==b'\x7fELF',
                                 'closed plain ELF changed')
        plain[lane]=dict(path=str(elf),**identity(raw))
        sources[lane]={Path(name).name:(CLOSED/lane/name).read_text() for name in inventory
                       if name.startswith(SUBPROCESS) and name.endswith(('.f','.f90'))}
    components={name:identity(bound(BASE/name,sha)) for name,sha in PINS.items()}
    return sources,dict(closed_result_sha256=RESULT_SHA,closed_terminal_sha256=TERMINAL_SHA,
                        source_inventory=pins,plain_ELFs=plain,components=components)


def rename_only(wire,text,names):
    lines,groups=wire._statements(text);replacements={}
    for start,end,statement in groups:
        changed=wire._rename(statement,names)
        if changed!=statement:replacements[start]=(end,wire._fixed(changed))
    output=[];index=0
    while index<len(lines):
        if index in replacements:
            end,value=replacements[index];output.append(value);index=end
        else:output.append(lines[index]);index+=1
    return ''.join(output)


def actual_wire(wire,actual,canonical,lane,diagnostics):
    reference=wire.emit_wired_sources(canonical,lane,diagnostics)
    prefix='ML5_0_'+('PM_' if lane=='candidate' else '')
    clones={};authenticated=[]
    for path,statistics in reference['statistics'].items():
        actual_units=wire._units(actual[path]);known_units=wire._units(canonical[path]);parts=[]
        reference_units=wire._units(reference['clones'][path])
        for row in statistics:
            old=row['routine'];need(actual_units.get(old)==known_units[old],'actual selected unit differs: '+old)
            role=ROLES[old[len(prefix):]]
            clone,_=wire._clone(actual_units[old],old,reference['rename_calls'],role,lane)
            need(clone==reference_units[row['observed']],'actual-source clone replay differs: '+old)
            parts.append(clone);authenticated.append(dict(file=path,routine=old,**identity(actual_units[old].encode())))
        clones[path]='\n'.join(parts)
    return reference,clones,authenticated


def fresh_observer(original):
    need(identity(original.encode())['sha256']==PINS['observer.f90'],'journal parent changed')
    source=original.replace('contains\n','  public :: OBS_DRAIN_SUCCEEDED\ncontains\n',1)
    tail="    write(lun,'(A)',iostat=ios)trim(line)\n    if(ios/=0)call fault(17)\n    ! Failed evidence"
    need(source.count(tail)==1,'exact footer failure anchor changed')
    source=source.replace(tail,"    write(lun,'(A)',iostat=ios)trim(line)\n    if(ios/=0)call fault(17)\n"
                          "    flush(lun,iostat=ios)\n    if(ios/=0)call fault(17)\n    ! Failed evidence",1)
    end='end module ML5_0_CMS_OBSERVER\n';need(source.count(end)==1,'journal module end changed')
    return source.replace(end,'  logical function OBS_DRAIN_SUCCEEDED() result(ok)\n'
        '    ok=.not.enabled.and..not.undrained.and.failed==0\n'
        '  end function OBS_DRAIN_SUCCEEDED\n'+end,1)


def fresh_driver(wire,renderer,lane):
    driver=wire.route_observed_driver(renderer.render_driver(lane,observed=True),lane)
    use='     $ OBS_DISABLE_DRAIN\n';need(driver.count(use)==1,'driver observer import changed')
    driver=driver.replace(use,'     $ OBS_DISABLE_DRAIN,OBS_DRAIN_SUCCEEDED\n',1)
    call='      CALL OBS_DISABLE_DRAIN(75)\n';need(driver.count(call)==1,'driver drain anchor changed')
    driver=driver.replace(call,call+'      IF(.NOT.OBS_DRAIN_SUCCEEDED()) GOTO 800\n',1)
    need(all(len(line)<=72 for line in driver.splitlines() if line and line[0] not in 'Cc*!'),
         'fresh driver fixed width exceeded')
    return driver


def call_graph(wire,files):
    graph={}
    for name,source in files.items():
        if not name.endswith('.f'):continue
        for unit,body in wire._units(source).items():
            need(unit not in graph,'duplicate emitted routine '+unit)
            graph[unit]=[match.group(1).upper() for _,_,statement in wire._statements(body)[1]
                         if (match:=re.match(r'\s*CALL\s*([A-Z][A-Z0-9_]*)\s*\(',statement,re.I))]
    return graph


def reachable(graph,root):
    pending=[root];seen=set()
    while pending:
        node=pending.pop()
        if node in seen:continue
        seen.add(node);pending.extend(graph.get(node,()))
    return seen


def validate_closure(wire,files,entry,required):
    graph=call_graph(wire,files);seen=reachable(graph,entry)
    need(set(required)<=seen,'observed native diagnostic unreachable: '+str(sorted(set(required)-seen)))
    unobserved={n for n in seen if n.startswith('ML5_0_') and n.endswith('TIRUST_TENSOR_DIAGNOSTIC')
                and not n.startswith('ML5_0_OBS_')}
    need(not unobserved,'reachable unobserved TIRust diagnostic '+str(unobserved))
    need('TIRUST_TENSOR_EVALUATE' in seen,'native hook closure absent')
    return graph,seen,unobserved


def compose():
    actual,pins=inputs()
    wire=load_pure('_cms_observer_wire','observer_wire.py')
    matrix=load_pure('_cms_observer_matrix','observer_matrix.py')
    renderer=load_pure('_cms_normal_driver','normal-driver/render.py')
    canonical={name:(CANONICAL/name).read_text() for name in wire.SOURCE_SHA}
    journal=fresh_observer(bound(BASE/'observer.f90',PINS['observer.f90']).decode())
    files={};metadata={}
    for lane in ('legacy','candidate'):
        source=actual[lane]
        need(source['check_sa.f']==renderer.render_driver(lane,observed=False),'closed driver recipe differs')
        original_math=source.get('owned_math.f90','')
        observed=matrix.emit_observer_sources(source['CT_interface.f'],source['TIRUST_interface.f'],original_math,lane)
        reference,clones,authenticated=actual_wire(wire,source,canonical,lane,observed['rename_calls'])
        names=dict(reference['rename_calls']);fallback_clones={}
        # Actual TIRust wrappers are part of the reachable chain, not just the
        # diagnostic definitions. Both precision paths must be rebound.
        wrapper_prefixes=['ML5_0_']+(['ML5_0_PM_'] if lane=='candidate' else [])
        for prefix in wrapper_prefixes:
            for suffix in ('TIRUSTLOOP','MP_TIRUST_LOOP'):
                names[prefix+suffix]=(prefix+suffix).replace('ML5_0_','ML5_0_OBS_',1)
        if lane=='candidate':
            public=matrix.emit_observer_sources(source['CT_interface.f'],source['TIRUST_interface.f'],'','legacy')
            names.update(public['rename_calls'])
            observed['matrix_clones']+='\n'+public['matrix_clones']
            observed['diagnostic_clones']+='\n'+public['diagnostic_clones']
            # Candidate unsupported/unknown paths retain the actual public
            # science, observed distinctly as frame.legacy=true.
            for suffix in ('LOOP_1_2','LOOP_2','LOOP_3','LOOP_4','TIRLOOP'):
                names['ML5_0_'+suffix]='ML5_0_OBS_'+suffix
            for path,suffixes,role in [('CT_interface.f',('LOOP_1_2','LOOP_2','LOOP_3','LOOP_4'),'loop'),
                                       ('TIR_interface.f',('TIRLOOP',),'tirloop')]:
                units=wire._units(source[path]);known=wire._units(canonical[path]);parts=[]
                for suffix in suffixes:
                    old='ML5_0_'+suffix;need(units[old]==known[old],'public fallback source changed')
                    clone,_=wire._clone(units[old],old,names,role,'legacy');parts.append(clone)
                fallback_clones[path]='\n'.join(parts)
        wrappers=[];units=wire._units(source['TIRUST_interface.f'])
        frozen_units=wire._units(matrix.pinned('TIRUST_interface.f'))
        for prefix in wrapper_prefixes:
            for suffix in ('TIRUSTLOOP','MP_TIRUST_LOOP'):
                old=prefix+suffix;need(units[old]==frozen_units[old],'actual native wrapper changed')
                wrappers.append(rename_only(wire,units[old],names))
        lane_files={name:source[name]+'\n'+rename_only(wire,text,names) for name,text in clones.items()}
        for name,text in fallback_clones.items():lane_files[name]+='\n'+text
        lane_files['CT_interface.f']+='\n'+observed['matrix_clones']
        lane_files['TIRUST_interface.f']=source['TIRUST_interface.f']+'\n'+'\n'.join(wrappers)+'\n'+observed['diagnostic_clones']
        lane_files['observer.f90']=journal
        if lane=='candidate':lane_files['observed_math.f90']=observed['observed_math']
        lane_files['check_sa.f']=fresh_driver(wire,renderer,lane)
        entry=reference['entry']
        required=set(observed['rename_calls'].values())
        if lane=='candidate':required.update(public['rename_calls'].values())
        graph,seen,unobserved=validate_closure(wire,lane_files,entry,required)
        files[lane]=lane_files
        metadata[lane]=dict(entry=entry,authenticated_actual_wire_units=authenticated,rename_calls=names,
            required_observed_diagnostics=sorted(required),reachable_diagnostics=sorted(required&seen),
            reachable_unobserved_diagnostics=sorted(unobserved),actual_native_entry_reachable=True,
            defined_observed_externals=sorted(n for n in graph if n.startswith('ML5_0_OBS_')),
            public_fallback_distinguished_by='outer lane plus frame.legacy=true',
            scope='TIRust paths only; other reducers, unexecuted paths and runtime lowering remain unqualified',
            changed_fixed_form=sorted(name for name in clones if name.endswith('.f'))+['TIRUST_interface.f'],
            new_modules=['observer.f90']+(['observed_math.f90'] if lane=='candidate' else []),
            candidate_existing_module_prerequisites=['invariant_bounds.f90','owned_snapshots.f90',
                'owned_exact_geometry.f90','owned_certificate.f90','owned_math.f90','owned_route_data.f90',
                'point_match.f90'] if lane=='candidate' else [],
            compile_order=['observer.f90']+(['observed_math.f90'] if lane=='candidate' else [])+
                ['helas_calls_ampb_1.f','mp_helas_calls_ampb_1.f','mp_compute_loop_coefs.f','loop_CT_calls_1.f',
                 'TIRUST_interface.f','TIR_interface.f','CT_interface.f','loop_matrix.f','check_sa.f'])
    # Detect any mutation of the closed inputs/ELFs during source composition.
    _,after=inputs();need(after==pins,'closed input changed during composition')
    return files,dict(schema='dormant-CMS-observer-source-composition-v1',inputs=pins,lanes=metadata,
        fresh_control_delta='post-footer FLUSH(IOSTAT), readonly OBS_DRAIN_SUCCEEDED, driver GOTO800 before RUN/DONE',
        unchanged_plain_ELFs=True,new_observed_ELFs_to_build=2,generated_cli_calls=0,compiler_calls=0,
        loader_calls=0,native_calls=0,runtime_abi_qualified=False,full_caller_qualified=False,
        scientific_dispatch_enabled=False,build_admitted=False,run_admitted=False)


def generate():
    destination=HERE/'emittedsrc';need(not destination.exists(),'fresh source destination required')
    files,receipt=compose();destination.mkdir()
    outputs={}
    for lane,mapping in files.items():
        directory=destination/lane;directory.mkdir();outputs[lane]={}
        for name,text in mapping.items():
            need(Path(name).name==name,'unexpected source destination')
            with (directory/name).open('x') as stream:stream.write(text)
            outputs[lane][name]=identity((directory/name).read_bytes())
    receipt['outputs']=outputs
    for lane in outputs:receipt['lanes'][lane]['files']=outputs[lane]
    composition=json.dumps(receipt,indent=2,sort_keys=True)+'\n'
    with (HERE/'composition-receipt.json').open('x') as stream:stream.write(composition)
    summary=dict(status='source-emitted',composition_receipt=identity(composition.encode()),outputs=outputs,
                 compiler_calls=0,loader_calls=0,native_calls=0,scientific_dispatch_enabled=False)
    with (HERE/'generation-receipt.json').open('x') as stream:json.dump(summary,stream,indent=2,sort_keys=True);stream.write('\n')
    with (HERE/'source-pins.json').open('x') as stream:json.dump(receipt['inputs'],stream,indent=2,sort_keys=True);stream.write('\n')
    return receipt


if __name__=='__main__':
    need(sys.argv[1:]==['--emit'],'only explicit --emit source operation is supported')
    result=generate()
    print(json.dumps(dict(status='source-emitted',lanes=list(result['outputs']),compiler_calls=0,native_calls=0)))
