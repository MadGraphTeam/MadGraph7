"""Synthetic source-format tests; no Fortran/model/loader execution."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import re
import struct
from fractions import Fraction
import sys
import unittest
FORBIDDEN=[]
def deny(event,args):
    if event.startswith(('subprocess.','ctypes.','socket.')) or event in {'os.system','os.exec','os.posix_spawn','os.fork','pty.spawn'}:
        FORBIDDEN.append(event);raise RuntimeError('forbidden native/process/network')
sys.addaudithook(deny)
HERE=Path(__file__).parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
normal_path=HERE.parent/'generic-owned-CMS-plain-run-proposal-1/normal_run_analysis.py'
if hashlib.sha256(normal_path.read_bytes()).hexdigest()!='a3ad9f0618e1f5601d1824baa552e9da68eaac93fd8965f29bf2dc019ae21743':raise RuntimeError('frozen RAW parser differs')
normal=load('frozen_normal_observer_test',normal_path)
a=load('private_observer_analysis',HERE/'observer_analysis.py')
READY=[0,1,0,0]+[0]*11
INIT=[1,0,0,0]+[0]*11
Z='0'*32

def d(value):return struct.pack('>d',value).hex().upper()
def w(value,width=64):
    if width==64:return '0'*16+d(value)
    # Independent integer fixture, not a DP-to-QP precision claim.
    if value==0:return Z
    if value<0:return f'{(1<<127)|(0x3FE0<<112):032X}'
    return f'{(0x3FFF<<112)|int(value):032X}'
def point(pid,width=64):return [[[w(float(pid*10+leg*4+mu+1),width),Z] for mu in range(4)] for leg in range(4)]
def zeros():return [[[Z,Z] for mu in range(4)] for leg in range(4)]

def raw_frame(phase,index,pid,code=219,cls=2,streak=0,before=READY,after=READY):
    lines=[f'CALL {phase} {index} {pid} {code} {cls} {streak} 4 '+('F' if before is None else 'T')]
    if before is not None:lines+=['BEFORE '+' '.join(map(str,before))]
    lines+=['AFTER '+' '.join(map(str,after)),'MUR '+d(1000.)]
    for leg,col in enumerate(point(pid),1):
        for mu,pair in enumerate(col):lines.append(f'P {mu} {leg} '+pair[0][-16:])
    for order in range(2):
        for mu,value in enumerate((10.,-2.,.2,.01)):lines.append(f'ANS {mu} {order} '+d(value))
    for order in range(2):lines.append(f'ACC {order} '+d(1e-9))
    return '\n'.join(lines+['CALL_END'])+'\n'
def raw(ids=(1,),pid=12345,code=219,cls=2):
    text=f'CMS_DRIVER_RAW64_V1 PID {pid}\nDIMENSIONS 4 1 1 1 9\n'
    text+=raw_frame('LEARN',0,1,139,1,0,None,INIT)
    for index in range(1,13):text+=raw_frame('LEARN',index,index,streak=index,before=INIT if index==1 else READY)
    text+='LEARNED 1 12 12 219\n'
    for index,pointid in enumerate(ids,1):text+=raw_frame('RUN',index,pointid,code,cls)
    return text


def journal(pid=1,seq=2,request=1,width=64,owned=True,veto=True,extra_boundary=None,omit_mp=False,missing_batch=False):
    mode=1 if width==64 else 5;genuine=int(owned and width==128)
    boundaries=[1,10476,10478,30109,300] if width==64 else [1,10476,10478,2,10179,30095,300]
    if not owned:boundaries=[1]
    if omit_mp:boundaries=[x for x in boundaries if x!=2]
    if missing_batch:boundaries=[300 if x in (30109,30095) else x for x in boundaries]
    commit_boundary=len(boundaries)-1
    if extra_boundary is not None:boundaries.append(extra_boundary)
    current={64:point(pid),128:point(pid,128) if genuine else zeros()}
    refs={64:zeros(),128:zeros()};masks={64:[0]*4,128:[0]*4};joins=[[0,0] for _ in range(4)]
    producers=[];pending=zeros()
    if owned:
        for leg in range(4):
            pending[leg]=copy.deepcopy(current[width][leg]);masks[width][leg]=0
            base=[copy.deepcopy(refs[width]),copy.deepcopy(pending),masks[width].copy(),[int(i==leg) for i in range(4)]]
            producers.extend([(1,leg+1,copy.deepcopy(base)),(2,leg+1,copy.deepcopy(base))])
            refs[width][leg]=copy.deepcopy(pending[leg]);pending[leg]=copy.deepcopy(zeros()[leg]);masks[width][leg]=1
            producers.append((3,leg+1,[copy.deepcopy(refs[width]),copy.deepcopy(pending),masks[width].copy(),[0]*4]))
            joins[leg][0 if width==64 else 1]=len(producers)
    out=[]
    def ints(tag,*values):out.append(tag+' '+' '.join(map(str,values)))
    def words(tag,keys,values):out.append(tag+' '+' '.join(map(str,keys))+' '+' '.join(values))
    ints('OBS_BEGIN',seq,request,pid,0,len(producers),1,1,len(boundaries))
    for index,code in enumerate(boundaries,1):ints('OBS_BOUNDARY',index,code)
    for index,(stage,leg,data) in enumerate(producers,1):
        reference,pend,valid,pv=data
        ints('OBS_PRODUCER',index,stage,width,1,leg,commit_boundary,1,genuine,*valid,*pv)
        for ext in range(1,5):
            for mu in range(4):
                words('OBS_PREF',[index,ext,mu],reference[ext-1][mu]);words('OBS_PENDING',[index,ext,mu],pend[ext-1][mu])
    ints('OBS_CONSUMER',1,17,1,mode,len(boundaries),int(owned),genuine,int(owned),genuine,*masks[64],*masks[128])
    for leg in range(1,5):
        ints('OBS_COMMIT_JOIN',1,leg,*joins[leg-1])
        if owned:
            for mu in range(4):
                words('OBS_CREF_DP',[1,leg,mu],refs[64][leg-1][mu]);words('OBS_CREF_QP',[1,leg,mu],refs[128][leg-1][mu])
                words('OBS_CURRENT_DP',[1,leg,mu],current[64][leg-1][mu]);words('OBS_CURRENT_QP',[1,leg,mu],current[128][leg-1][mu])
    ints('OBS_FRAME',1,3,width,1,len(boundaries),width if owned else 0,mode,2,int(not owned),int(owned),int(owned),genuine,
         *(masks[width] if owned else [0]*4),1,1,1,0,int(mode==5),0,1,1)
    for leg in range(1,5):
        for mu in range(4):
            words('OBS_FRAME_REF',[1,leg,mu],refs[width][leg-1][mu] if owned else [Z,Z])
            words('OBS_FRAME_CURRENT',[1,leg,mu],current[width][leg-1][mu] if owned else [Z,Z])
            words('OBS_PLOOP',[1,leg,mu],[Z]);words('OBS_SHIFT',[1,leg,mu],[Z])
        words('OBS_MASS',[1,leg],[Z,Z])
    words('OBS_SCALE',[1],[w(1.,width)])
    for j in range(1,5):
        for i in range(1,5):
            diag=i==j;used=owned and veto and (i,j) in ((2,4),(4,2))
            bits=16383 if used else 1<<13 if diag else (1<<13)|1
            ints('OBS_PAIR',1,i,j,2 if used else 0 if diag else 1,*([0]*4),bits,
                 int(not diag),0,int(used),int(used),int(used),int(used),int(used),int(used),int(used))
            original=[w(-1.,width),Z]
            if not diag:words('OBS_ORIGINAL_RAW',[1,i,j],original)
            if used:words('OBS_ENV',[1,i,j],['0'*31+'1']*2)
            for mu in range(4):
                if used:
                    words('OBS_BUILT_Q',[1,i,j,mu],[w(float(mu+1),width),Z]);words('OBS_CONSUMED_Q',[1,i,j,mu],[w(float(mu+1),width),Z])
            if used:
                words('OBS_BUILT_RAW',[1,i,j],original);words('OBS_CONSUMED_RAW',[1,i,j],original)
            words('OBS_SMAT',[1,i,j],[Z,Z] if diag else original)
            if used:words('OBS_DIRECT',[1,i,j],[original[0]])
            for stage in range(1,4):words('OBS_NATIVE',[1,stage,i,j],[Z if diag else original[0]])
    body=''.join(line+'\n' for line in out)
    return body+f'OBS_END {seq} 0 {len(producers)} 1 1 {len(boundaries)} {len(body)}\n'

def observed(ids=(1,),owned=True,width=64,**kwargs):
    text=raw(ids);parts=text.split('CALL RUN ');out=parts[0]
    for index,tail in enumerate(parts[1:],1):out+=journal(ids[index-1],index+1,index,width,owned,**kwargs)+'CALL RUN '+tail
    return out

def repaired_footer(text):
    body=text[:text.rfind('OBS_END ')];footer=text[text.rfind('OBS_END '):].split()
    footer[-1]=str(len(body));return body+' '.join(footer)+'\n'

class Observer(unittest.TestCase):
    def parse(self,text=None,**kw):return a.parse_journal(journal() if text is None else text,sequence=2,request=1,point_id=1,**kw)
    def analyze(self,obs=None,plain=None,lane='candidate',ids=(1,),**kw):
        return a.analyze_observed(observed(ids) if obs is None else obs,raw(ids,pid=54321) if plain is None else plain,
                lane=lane,request_ids=ids,observed_pid=12345,plain_pid=54321,parse_normal=normal.parse_raw,**kw)
    def test_complete_actual_flags_words_and_h17_retention(self):
        result=self.parse();self.assertEqual(result['observed_veto_count'],2)
        self.assertEqual(result['consumers'][0]['provenance'][64][0]['producer_h'],1)
        self.assertEqual(result['consumers'][0]['h'],17)
        self.assertTrue(result['frames'][0]['producer_lifetime_complete'])
        pair=result['frames'][0]['pairs'][13]
        self.assertTrue(pair['decisions']['exact_equal']);self.assertEqual(pair['built_q'],pair['consumed_q'])
        self.assertFalse(result['scientifically_qualified'])
    def test_public_fallback_has_no_owned_evidence(self):
        result=self.parse(journal(owned=False))
        self.assertEqual(result['owned_frames'],0);self.assertEqual(result['public_fallback_frames'],1)
        self.assertFalse(result['consumers'][0]['snapshot']);self.assertEqual(result['consumers'][0]['reference'][64],[])
        self.assertIsNone(result['frames'][0]['pairs'][1]['decisions']['match'])
        self.assertFalse(result['frames'][0]['producer_lifetime_complete'])
    def test_qp_preserves_full128_bits_and_genuine(self):
        result=self.parse(journal(width=128));f=result['frames'][0]
        self.assertEqual(f['width'],128);self.assertTrue(f['genuine'])
        self.assertNotEqual(f['current'][0][0][0][:16],'0'*16)
        changed=journal(width=128).replace('OBS_FRAME_CURRENT 1 1 0 '+f['current'][0][0][0],
            'OBS_FRAME_CURRENT 1 1 0 '+f'{int(f["current"][0][0][0],16)+1:032X}',1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(changed))
    def test_missing_duplicate_reordered_keys_and_footer_refuse(self):
        text=journal()
        mutations=[text.replace('OBS_PREF 1 1 0','OBS_PREF 1 1 1',1),text.replace('OBS_NATIVE 1 3 1 1','OBS_NATIVE 1 2 1 1',1),
                   text.replace('OBS_END 2 0','OBS_END 2 2048',1),text[:-1],text+'OBS_END 2 0 12 1 1 5 0\n',
                   text.replace('OBS_BEGIN 2 1 1 0','OBS_BEGIN 2 1 1 1',1)]
        for bad in mutations:
            with self.assertRaises(a.ObserverError) as ctx:self.parse(bad)
            self.assertEqual(ctx.exception.raw_text,bad)
    def test_raw_equal_and_consumed_word_spoofs_refuse(self):
        for tag in ('OBS_ORIGINAL_RAW 1 2 4','OBS_BUILT_RAW 1 2 4','OBS_CONSUMED_RAW 1 2 4','OBS_CONSUMED_Q 1 2 4 0'):
            text=journal();line=next(x for x in text.splitlines() if x.startswith(tag+' '));fields=line.split();fields[-2]=f'{int(fields[-2],16)^1:032X}'
            with self.assertRaises(a.ObserverError):self.parse(repaired_footer(text.replace(line,' '.join(fields),1)))
    def test_stage_return_is_not_success_and_unreached_is_none(self):
        result=self.parse(journal(veto=False));pair=result['frames'][0]['pairs'][13]
        self.assertIsNone(pair['decisions']['certifier']);self.assertFalse(pair['used'])
        text=journal();line=next(x for x in text.splitlines() if x.startswith('OBS_PAIR 1 2 4 '));fields=line.split();fields[12]='0'
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(text.replace(line,' '.join(fields),1)))
    def test_reset_unknown_and_prior_inner_entry_do_not_prove_freshness(self):
        for code in (1,2,10476,999999):
            # MP-entry clears QP only; DP may validly survive it.
            if code==2:self.assertTrue(self.parse(journal(extra_boundary=code))['frames'][0]['producer_lifetime_complete'])
            else:
                with self.assertRaises(a.ObserverError):self.parse(journal(extra_boundary=code))
        with self.assertRaises(a.ObserverError):self.parse(journal(width=128,extra_boundary=2))
    def test_prepare_normal_return_commit_and_valid_join_required(self):
        text=journal();bad=text.replace('OBS_PRODUCER 2 2 64','OBS_PRODUCER 2 1 64',1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(bad))
        bad=text.replace('OBS_COMMIT_JOIN 1 1 3 0','OBS_COMMIT_JOIN 1 1 0 0',1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(bad))
    def test_dp_zeroextension_and_payload_presence(self):
        text=journal();line=next(x for x in text.splitlines() if x.startswith('OBS_NATIVE 1 1 1 1 '));bad=text.replace(line,line[:-32]+'1'+'0'*31,1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(bad))
        bad=text.replace('OBS_BUILT_RAW 1 2 4','OBS_UNUSED_RAW 1 2 4',1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(bad))
    def test_native_stage_copy_and_view_agreement(self):
        text=journal()
        for tag in ('OBS_NATIVE 1 3 2 4','OBS_SHIFT 1 1 0'):
            line=next(x for x in text.splitlines() if x.startswith(tag+' '));bad=text.replace(line,line[:-32]+w(1.),1)
            with self.assertRaises(a.ObserverError):self.parse(repaired_footer(bad))
    def test_full_raw_parity_and_full_digest(self):
        text=observed();result=self.analyze(text)
        self.assertEqual(result['raw_sha256'],hashlib.sha256(text.encode()).hexdigest())
        self.assertEqual(result['normalized_raw_sha256'],hashlib.sha256(raw().encode()).hexdigest())
        self.assertTrue(result['parity']['all15_state_fields_compared'])
        self.assertNotIn('driver_sha256_required',result)
        self.assertIn('driver_sha256_required',result['normal_analysis'])
        self.assertTrue(result['journal_schema_complete']);self.assertTrue(result['journal_provenance_complete'])
        json.dumps(result,allow_nan=False)
    def test_all_state_differences_including_after_prior_drain_refuse(self):
        ids=(1,7);text=observed(ids);pos=text.index('CALL RUN 2 7 ')
        suffix=text[pos:];old='BEFORE '+' '.join(map(str,READY));state=READY.copy();state[8]=1
        bad=text[:pos]+suffix.replace(old,'BEFORE '+' '.join(map(str,state)),1)
        with self.assertRaises(a.ObserverError) as ctx:self.analyze(bad,ids=ids)
        self.assertIn('parity',str(ctx.exception));self.assertTrue(ctx.exception.evidence['parity_differences'])
    def test_missing_journal_pid_and_early_learning_journal_refuse(self):
        with self.assertRaises(a.ObserverError):self.analyze(raw())
        with self.assertRaises(a.ObserverError):self.analyze(observed().replace('PID 12345','PID 777',1))
        with self.assertRaises(a.ObserverError):self.analyze(journal()+raw())
    def test_legacy_expected_failure_still_cannot_bypass_bad_observer(self):
        plain=raw((20,),pid=54321,code=419,cls=0);base=raw((20,),code=419,cls=0)
        pos=base.index('CALL RUN ');obs=base[:pos]+journal(20,owned=False)+base[pos:]
        result=self.analyze(obs,plain,lane='legacy',ids=(20,));self.assertTrue(result['expected_legacy_critical_failure'])
        self.assertFalse(result['journal_provenance_complete'])
        with self.assertRaises(a.ObserverError):self.analyze(obs.replace('OBS_END 2 0','OBS_END 2 2048'),plain,lane='legacy',ids=(20,))
    def test_learning_only_has_no_observer_positive_claim(self):
        obs=raw(())
        result=self.analyze(obs,raw((),pid=54321),ids=())
        self.assertTrue(result['learning']['ready']);self.assertEqual(result['journals'],[])
        self.assertFalse(result['journal_provenance_complete'])
    def test_successful_commit_requires_actual_successful_prepare(self):
        text=journal()
        for field in (7,13):
            # tag,index,stage,width,h,leg,boundary,ok,genuine,valid4,pv4
            changed=text
            for producer in (1,2):
                line=next(x for x in changed.splitlines() if x.startswith(f'OBS_PRODUCER {producer} '))
                parts=line.split();parts[field]='0';changed=changed.replace(line,' '.join(parts),1)
            with self.assertRaises(a.ObserverError):self.parse(repaired_footer(changed))
    def test_native_delta_report_requires_exact_cohorts(self):
        left=self.analyze(observed(owned=False),lane='legacy')
        right=self.analyze()
        report=a.compare_native(left,right)
        self.assertTrue(report['comparison_complete']);self.assertFalse(report['scientifically_qualified'])
        for evidence in (copy.deepcopy(left),copy.deepcopy(right)):
            evidence['journals']=[]
            with self.assertRaises(ValueError):a.compare_native(evidence,right) if evidence['lane']=='legacy' else a.compare_native(left,evidence)
        bad=copy.deepcopy(right);bad['measurements'][0]['rawP'][0][0]=d(999.)
        with self.assertRaises(ValueError):a.compare_native(left,bad)
    def test_qp_requires_actual_mp_entry_and_source_batch_edge(self):
        with self.assertRaises(a.ObserverError):self.parse(journal(width=128,omit_mp=True))
        for width in (64,128):
            with self.assertRaises(a.ObserverError):self.parse(journal(width=width,missing_batch=True))
    def test_precision_dispatch_cannot_be_spoofed_by_consistent_mode_flags(self):
        text=journal()
        line=next(x for x in text.splitlines() if x.startswith('OBS_CONSUMER 1 '));parts=line.split();parts[4]='5';text=text.replace(line,' '.join(parts),1)
        line=next(x for x in text.splitlines() if x.startswith('OBS_FRAME 1 '));parts=line.split();parts[7]='5';parts[21]='1';text=text.replace(line,' '.join(parts),1)
        with self.assertRaises(a.ObserverError):self.parse(repaired_footer(text))
    def test_no_forbidden_events(self):self.assertEqual(FORBIDDEN,[])

if __name__=='__main__':
    result=unittest.main(exit=False,verbosity=2).result
    print('FORBIDDEN_ATTEMPTS',len(FORBIDDEN))
    raise SystemExit(not result.wasSuccessful() or bool(FORBIDDEN))
