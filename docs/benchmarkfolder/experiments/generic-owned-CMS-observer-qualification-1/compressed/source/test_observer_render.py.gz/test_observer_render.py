"""Pure source composition checks; no compiler, loader or physics evaluation."""
from pathlib import Path
import builtins
from contextlib import ExitStack
import io
import json
import os
import subprocess
import sys
import types
import unittest

HERE=Path(__file__).resolve().parent
render=types.ModuleType('_cms_observer_render_test');render.__file__=str(HERE/'observer_render.py')
exec(compile((HERE/'observer_render.py').read_bytes(),render.__file__,'exec'),render.__dict__)


class Composition(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files,cls.receipt=render.compose()
        cls.wire=render.load_pure('_cms_wire_composition_tests','observer_wire.py')

    def test_exact_closed_build_and_unchanged_plain_executables(self):
        receipt=self.receipt
        self.assertEqual(receipt['inputs']['closed_result_sha256'],render.RESULT_SHA)
        self.assertEqual(receipt['inputs']['plain_ELFs']['legacy']['sha256'],
                         '32009f2611608f00559e516d87c7d72811313a4890caff3d5068675d732d06ad')
        self.assertEqual(receipt['inputs']['plain_ELFs']['candidate']['sha256'],
                         'eaf4daa4f5b422aee74a07d5341760692f0ded372ae0652eeba1522ab4571d63')
        self.assertTrue(receipt['unchanged_plain_ELFs']);self.assertEqual(receipt['new_observed_ELFs_to_build'],2)

    def test_flat_overlays_keep_every_actual_scientific_source_as_exact_prefix(self):
        for lane,files in self.files.items():
            meta=self.receipt['lanes'][lane]
            self.assertEqual(len(meta['changed_fixed_form']),8)
            self.assertEqual(len(files),11 if lane=='candidate' else 10)
            for name in meta['changed_fixed_form']:
                actual=(render.CLOSED/lane/render.SUBPROCESS/name).read_text()
                self.assertTrue(files[name].startswith(actual),(lane,name))
            self.assertEqual(meta['new_modules'][0],'observer.f90')
            self.assertEqual(meta['compile_order'][0],'observer.f90')

    def test_actual_legacy_units_are_authenticated_not_full_pin_relaxations(self):
        for lane in ('legacy','candidate'):
            auth=self.receipt['lanes'][lane]['authenticated_actual_wire_units']
            self.assertEqual(len(auth),12)
            self.assertTrue(all(row['bytes']>0 and len(row['sha256'])==64 for row in auth))
        wire=self.wire;canonical={n:(render.CANONICAL/n).read_text() for n in wire.SOURCE_SHA}
        actual={n:(render.CLOSED/'legacy'/render.SUBPROCESS/n).read_text() for n in wire.SOURCE_SHA}
        actual['loop_matrix.f']=actual['loop_matrix.f'].replace('ML5_0_SLOOPMATRIX_RETRY_IMPL(',
                                                               'ML5_0_BAD_RETRY_IMPL(',1)
        diag={'ML5_0_TIRUST_TENSOR_DIAGNOSTIC':'ML5_0_OBS_TIRUST_TENSOR_DIAGNOSTIC',
              'ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC':'ML5_0_OBS_MP_TIRUST_TENSOR_DIAGNOSTIC'}
        with self.assertRaisesRegex(ValueError,'actual selected unit differs'):
            render.actual_wire(wire,actual,canonical,'legacy',diag)

    def test_real_dp_qp_wrapper_paths_reach_observed_native_diagnostics(self):
        for lane,files in self.files.items():
            meta=self.receipt['lanes'][lane]
            graph,seen,unobserved=render.validate_closure(self.wire,files,meta['entry'],meta['required_observed_diagnostics'])
            self.assertFalse(unobserved);self.assertIn('TIRUST_TENSOR_EVALUATE',seen)
            for prefix in ['ML5_0_']+(['ML5_0_PM_'] if lane=='candidate' else []):
                for wrapper,diag in [('TIRUSTLOOP','TIRUST_TENSOR_DIAGNOSTIC'),
                                     ('MP_TIRUST_LOOP','MP_TIRUST_TENSOR_DIAGNOSTIC')]:
                    observed=(prefix+wrapper).replace('ML5_0_','ML5_0_OBS_',1)
                    target=(prefix+diag).replace('ML5_0_','ML5_0_OBS_',1)
                    self.assertIn(observed,seen);self.assertIn(target,graph[observed])

    def test_missing_wrapper_or_plain_fallback_cannot_pass_closure(self):
        lane='candidate';meta=self.receipt['lanes'][lane];files=dict(self.files[lane])
        old='ML5_0_OBS_PM_TIRUST_TENSOR_DIAGNOSTIC'
        files['TIRUST_interface.f']=files['TIRUST_interface.f'].replace(old,'ML5_0_PM_TIRUST_TENSOR_DIAGNOSTIC')
        with self.assertRaises(ValueError):
            render.validate_closure(self.wire,files,meta['entry'],meta['required_observed_diagnostics'])
        files=dict(self.files[lane])
        units=self.wire._units(files['CT_interface.f']);old=units['ML5_0_OBS_PM_LOOP_4']
        changed=render.rename_only(self.wire,old,{'ML5_0_OBS_LOOP_4':'ML5_0_LOOP_4'})
        self.assertNotEqual(old,changed)
        files['CT_interface.f']=files['CT_interface.f'].replace(old,changed,1)
        with self.assertRaisesRegex(ValueError,'reachable unobserved'):
            render.validate_closure(self.wire,files,meta['entry'],meta['required_observed_diagnostics'])

    def test_public_candidate_fallback_is_distinct_and_keeps_legacy_builder(self):
        meta=self.receipt['lanes']['candidate'];files=self.files['candidate']
        graph=render.call_graph(self.wire,files)
        self.assertIn('ML5_0_OBS_LOOP_4',graph['ML5_0_OBS_PM_LOOP_4'])
        self.assertIn('ML5_0_OBS_BUILD_KINEMATIC_MATRIX',graph['ML5_0_OBS_TIRUST_TENSOR_DIAGNOSTIC'])
        self.assertIn('frame.legacy=true',meta['public_fallback_distinguished_by'])
        self.assertIn('CALL OBS_BEGIN_LEGACY_DP',files['CT_interface.f'])

    def test_fresh_query_flush_and_existing_protocol_error_guard(self):
        for lane,files in self.files.items():
            module=files['observer.f90'];driver=files['check_sa.f']
            self.assertIn('public :: OBS_DRAIN_SUCCEEDED',module)
            self.assertIn('ok=.not.enabled.and..not.undrained.and.failed==0',module)
            self.assertIn('flush(lun,iostat=ios)\n    if(ios/=0)call fault(17)',module)
            drain=driver.index('CALL OBS_DISABLE_DRAIN(75)')
            guard=driver.index('IF(.NOT.OBS_DRAIN_SUCCEEDED()) GOTO 800')
            run=driver.index("CALL DRIVER_TRACE(75,'RUN'")
            self.assertLess(drain,guard);self.assertLess(guard,run)
            self.assertIn('800  CONTINUE',driver)
            self.assertIn('ML5_0_OBS_'+('PM_' if lane=='candidate' else '')+'SLOOPMATRIX_THRES',driver)
            self.assertTrue(all(len(line)<=72 for line in driver.splitlines() if line and line[0] not in 'Cc*!'))

    def test_histories_and_no_native_or_scientific_admission(self):
        for lane,files in self.files.items():
            driver=files['check_sa.f']
            for label in ('TRAIN_ID','MEASURE_ID','DRIVER_STATUS_CLASS','DRIVER_INIT_READY'):
                self.assertIn(label,driver)
        for key in ('build_admitted','run_admitted','runtime_abi_qualified','full_caller_qualified','scientific_dispatch_enabled'):
            self.assertIs(self.receipt[key],False)
        for key in ('compiler_calls','loader_calls','native_calls','generated_cli_calls'):
            self.assertEqual(self.receipt[key],0)


def main():
    import ctypes
    from unittest.mock import patch
    attempts=[]
    def deny(*args,**kwargs):attempts.append('process/native/write');raise RuntimeError('source-only composition boundary')
    original=builtins.open;original_io=io.open
    def reader(function):
        def opened(file,mode='r',*args,**kwargs):
            if isinstance(file,int) or any(c in mode for c in 'wax+'):return deny()
            return function(file,mode,*args,**kwargs)
        return opened
    log=io.StringIO()
    with ExitStack() as stack:
        for name in ('Popen','run','call','check_call','check_output'):stack.enter_context(patch.object(subprocess,name,deny))
        for name in ('system','popen','fork','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'):
            if hasattr(os,name):stack.enter_context(patch.object(os,name,deny))
        for name in ('CDLL','PyDLL'):stack.enter_context(patch.object(ctypes,name,deny))
        stack.enter_context(patch.object(ctypes.cdll,'LoadLibrary',deny))
        stack.enter_context(patch.object(builtins,'open',reader(original)))
        stack.enter_context(patch.object(io,'open',reader(original_io)))
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Composition))
    print(log.getvalue(),end='')
    print(json.dumps(dict(status='pass' if result.wasSuccessful() and not attempts else 'fail',tests=result.testsRun,
        forbidden_api_attempts=attempts,compiler_calls=0,loader_calls=0,native_calls=0,scientific_dispatch_enabled=False)))
    return result.wasSuccessful() and not attempts


if __name__=='__main__':raise SystemExit(0 if main() else 1)
