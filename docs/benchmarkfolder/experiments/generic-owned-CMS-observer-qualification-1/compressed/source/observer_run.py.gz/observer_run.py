"""Six observed workers, exact own-plain histories, no additional science calls."""
from pathlib import Path
import hashlib,json,re,types

def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())

def reference_prefixes(text,ids):
    # Caller first validates the entire immutable plain stream with its exact parser.
    lines=text.splitlines(keepends=True);starts=[i for i,line in enumerate(lines) if line.startswith('CALL RUN ')]
    require(len(starts)==len(ids) and bool(ids),'plain request count differs')
    for number,(line,point) in enumerate(zip(starts,ids),1):
        fields=lines[line].split();require(len(fields)==9 and fields[:2]==['CALL','RUN'] and fields[2:4]==[str(number),str(point)],'plain request coordinates differ')
    return [''.join(lines[:starts[i]]) if i<len(ids) else text for i in range(len(ids)+1)]

class AnalysisAdapter:
    def __init__(self,b,request,reference):
        self.b=b;self.request=request;self.reference=reference;self.pid=None
        self.normal=b.local('normal_run_analysis');self.observer=b.local('observer_analysis')
        source=b.ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run/evidence'/request['id']/'driver.raw64'
        require(digest(source)==reference['raw_sha256'],'plain request raw changed')
        raw=source.read_text();words=b.local('cms_run').point_words(b.HERE/'inputs/training.dat',b.HERE/request['measurement'])
        full=self.normal.parse_raw(raw,lane=request['lane'],request_ids=request['ids'],expected_points=words)
        require(full==reference['analysis'],'closed plain analysis differs from exact replay')
        self.prefixes=reference_prefixes(raw,request['ids']);self.driver_sha=digest(b.HERE/'emittedsrc'/request['lane']/'check_sa.f')
    def bind(self,pid):
        require(type(pid) is int and pid>0 and (self.pid is None or self.pid==pid),'observed authenticated PID changed');self.pid=pid
    def parse_raw(self,text,*,lane,request_ids,expected_points=None):
        require(self.pid is not None and lane==self.request['lane'],'actual READY mapping must precede analysis')
        ids=list(request_ids);require(ids==self.request['ids'][:len(ids)] and len(ids)<=len(self.request['ids']),'unexpected observed request prefix')
        # Any parity/schema/journal refusal raises; expected legacy failure cannot bypass it.
        result=self.observer.analyze_observed(text,self.prefixes[len(ids)],lane=lane,request_ids=ids,
            observed_pid=self.pid,plain_pid=self.reference['analysis']['pid'],parse_normal=self.normal.parse_raw,expected_points=expected_points)
        require(result['parity']['passed'] and result['journal_schema_complete'],'observed evidence refused')
        result['observed_driver_source_sha256']=self.driver_sha
        result['observed_driver_identity_bound_by_actual_ELF_maps']=True
        return result

def command_metadata(value,expected,observed_build,observed_elf):
    plain='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
    require(value==expected and expected.get('reviewed_build')==plain,'unexpected inherited command record')
    require(type(observed_build) is str and re.fullmatch('[0-9a-f]{64}',observed_build) and type(observed_elf) is str and re.fullmatch('[0-9a-f]{64}',observed_elf),'exact observed BUILD/ELF hashes required')
    result=dict(value);result['reviewed_build']=observed_build;result['plain_reference_BUILD_terminal']=plain;result['observed_ELF_sha256']=observed_elf
    return result

def compact_result(path,result):
    a=result['analysis'];journals=a['journals']
    return {'result_path':str(path),'result_sha256':digest(path),'raw_sha256':result['raw_sha256'],'pid':result['pid'],'returncode':result['returncode'],
        'request':result['request'],'parity':a['parity'],'journal_schema_complete':a['journal_schema_complete'],
        'journal_provenance_complete':a['journal_provenance_complete'],'observed_veto_count':a['observed_veto_count'],
        'expected_legacy_critical_failure':a['expected_legacy_critical_failure'],
        'learning_outer_calls':a['learning']['outer_calls'],'learning_ready':a['learning']['ready'],'learning_streak':a['learning']['streak'],
        'measurements':[{'point_id':x['point_id'],'code':x['code'],'class':x['class'],'rawANS':x['rawANS'],'rawACC':x['rawACC'],'status':x['status']} for x in a['measurements']],
        'journal_counts':[{'point_id':j['point_id'],'frames':len(j['frames']),'producers':len(j['producers']),'consumers':len(j['consumers']),
                           'observed_veto_count':j['observed_veto_count'],'coverage_complete':j['coverage_complete']} for j in journals]}

def run(b,directory):
    source=b.local('observer_build');built=source.verified_build(b);plain=read(b.ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run/result.json')
    old=b.local('cms_run');normal=b.local('normal_run_analysis');analysis=b.local('observer_analysis');before=b.protected()
    results={};native_deltas={};ordinary=None
    b.dump(directory/'runtime-card-policy.json',old.runtime_policy(b))
    for request in old.request_matrix():
        adapter=AnalysisAdapter(b,request,plain['requests'][request['id']]);proxy=types.SimpleNamespace(**vars(b));original_local=b.local
        def local(name):return adapter if name=='normal_run_analysis' else original_local(name)
        def mapped(process,row,started):
            value=b.mapped(process,row,started);adapter.bind(process.pid);return value
        target=directory/'evidence'/request['id']/'command.json'
        case=directory/'workers'/request['id']/source.SUB
        expected_command={'argv':[str(case/'check'),str(case/'training.dat'),str(case/'measurement.dat'),str(case/'native-protocol.fifo'),str(target.parent/'driver.raw64')],
            'cwd':str(case),'source_index_sha256':b.EXPECTED_SOURCE,'reviewed_build':source.PLAIN_TERMINAL,'request':request,'new_session':False}
        def dump(path,value):
            if Path(path)==target:value=command_metadata(value,expected_command,b.REVIEWED_BUILD,built['variants'][request['lane']]['sha256'])
            return b.dump(path,value)
        proxy.local=local;proxy.mapped=mapped;proxy.dump=dump
        full=old.one(proxy,directory,request,built['variants'][request['lane']])
        result_path=directory/'evidence'/request['id']/'result.json';results[request['id']]=compact_result(result_path,full)
        if request['lane']=='candidate':
            left_path=directory/'evidence'/('legacy-'+request['cohort'])/'result.json'
            require(digest(left_path)==results['legacy-'+request['cohort']]['result_sha256'],'observed legacy evidence changed')
            left=read(left_path)['analysis'];right=full['analysis']
            delta=analysis.compare_native(left,right);native_deltas[request['cohort']]=delta
            b.dump(directory/('native-delta-'+request['cohort']+'.json'),delta)
            if request['cohort']=='controls':
                ordinary=normal.compare_ordinary(left,right);b.dump(directory/'ordinary-comparison.json',ordinary)
                require(ordinary['passed'],'observed ordinary consistency gate failed; no further candidate requests')
        del full,adapter,proxy
    require(ordinary is not None and ordinary['passed'],'observed ordinary gate missing')
    require(b.protected()==before,'protected source/provider changed');source.verified_build(b)
    for key,row in results.items():require(digest(Path(row['result_path']))==row['result_sha256'],'retained worker result changed')
    b.dump(directory/'result.json',{'status':'passed','source_index_sha256':b.EXPECTED_SOURCE,'reviewed_build_sha256':b.REVIEWED_BUILD,
        'plain_reference_RUN_terminal':source.PLAIN_RUN_TERMINAL,'plain_reference_RUN_result':source.PLAIN_RUN_RESULT,
        'requests':results,'ordinary_comparison':ordinary,'native_deltas':native_deltas,'native_processes':6,'compiler_calls':0,'loader_queries':0,
        'all_plain_observer_parity_passed':all(x['parity']['passed'] for x in results.values()),
        'expected_legacy_critical_failures':[key for key,row in results.items() if row['expected_legacy_critical_failure']],
        'all_requests_numerically_valid':not any(row['expected_legacy_critical_failure'] for row in results.values()),
        'observed_veto_count':sum(row['observed_veto_count'] for row in results.values()),
        'experimental_observed_ELFs_executed':True,'independent_finite_truth':False,'full_caller_qualified':False,
        'numerator_lifetime_qualified':False,'final_dot_IEEE_lowering_qualified':False,'scientific_dispatch_enabled':False,'performance_qualified':False,
        'scope':'Observed source-bound branch/word evidence plus exact own-plain parity; no promotion of unexecuted paths or independent physical truth.'})
