"""Observed-only compile hooks; exact closed plain ELFs remain references."""
from pathlib import Path
import hashlib,json,re,shlex,types
PLAIN_TERMINAL='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
COMPILED_SOURCE_INDEX='2333cb5216b178da1d77083de30ee4c72226d2b82ec6753d0ddc1fd6459b9e29'
COMPILED_COMPOSITION_SHA='9d239323670d19e309746721352ae0c584148b7010176bd6cb2ba691fef2bd76'
PLAIN_RUN_TERMINAL='182714a03f54cea2ea344e92bb31922a86cb603615176fb5aef8b060eda041bc'
PLAIN_RUN_RESULT='b0a3eb3596a8c183775d37a1a791a2aee3e3ca671958f8e2884776d79cb042eb'
SUB=Path('SubProcesses/P0_epem_mupmum')
CHANGED={'loop_matrix.f','mp_compute_loop_coefs.f','helas_calls_ampb_1.f','mp_helas_calls_ampb_1.f','loop_CT_calls_1.f','CT_interface.f','TIR_interface.f','TIRUST_interface.f'}
MODULES=('invariant_bounds.f90','owned_snapshots.f90','owned_exact_geometry.f90','owned_certificate.f90','owned_math.f90','owned_route_data.f90','point_match.f90')
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def read(p):return json.loads(Path(p).read_text())

def verified_plain(b):
    # Separate immutable plain reference admission from the new BUILD/RUN SHA.
    proxy=types.SimpleNamespace(**vars(b));proxy.REVIEWED_BUILD=PLAIN_TERMINAL
    result=b.local('cms_run').verified_build(proxy)
    folder=b.ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run'
    require(digest(folder/'terminal.json')==PLAIN_RUN_TERMINAL and digest(folder/'result.json')==PLAIN_RUN_RESULT,'closed normal plain RUN changed')
    term=read(folder/'terminal.json');run=read(folder/'result.json')
    require(term['status']=='passed' and term['returncode']==0 and not term['cleanup']['survivors'],'plain reference not closed')
    require(run['source_index_sha256']=='7cc733efccfcfca4aa9a84a36ef3c64ea3cc4471f71e7a48bafaa16ebef3f925' and len(run['requests'])==6,'wrong plain histories')
    for name,row in run['requests'].items():
        raw=folder/'evidence'/name/'driver.raw64'
        require(digest(raw)==row['raw_sha256']==row['analysis']['raw_sha256'],'plain reference raw changed')
    return result

def emission_contract(b):
    receipt=read(b.HERE/'composition-receipt.json');require(set(receipt['lanes'])=={'legacy','candidate'},'exact two observed lanes required')
    for lane,row in receipt['lanes'].items():
        root=b.HERE/'emittedsrc'/lane
        expected=CHANGED|{'check_sa.f','observer.f90'}|({'observed_math.f90'} if lane=='candidate' else set())
        require(set(row['files'])==expected and {p.name for p in root.iterdir() if p.is_file()}==expected,'unexpected observed source family')
        require(set(row['changed_fixed_form'])==CHANGED,'unexpected changed carrier set')
        for name,pin in row['files'].items():
            require(not (root/name).is_symlink() and identity(root/name)==pin,'emitted source changed')
        require(len(row['defined_observed_externals'])==len(set(row['defined_observed_externals'])) and row['entry'] in row['defined_observed_externals'],'observed symbols/entry incomplete')
        expected_modules=['observer.f90']+(['observed_math.f90'] if lane=='candidate' else [])
        require(row['new_modules']==expected_modules,'unexpected observed module list/order')
    return receipt

def fresh_module_sources(base,case,names,output):
    # Regenerate private .mod files rather than trusting unbound old .mod outputs.
    for name in names:
        body=(case/name).read_text()
        modules=re.findall(r'^\s*module\s+([A-Za-z][A-Za-z0-9_]*)\s*$',body,re.M|re.I)
        require(len(modules)==1,'one actual module definition required')
        for suffix in ('.mod','.o'):
            target=case/(modules[0].lower()+suffix) if suffix=='.mod' else case/Path(name).with_suffix('.o')
            require(not target.is_symlink() and target.parent.resolve().is_relative_to(output.resolve()),'unsafe private module output')
            target.unlink(missing_ok=True)

def build(b,directory):
    import clone_aliases
    before=b.protected();plain=verified_plain(b);emitted=emission_contract(b)
    data=read(b.HERE/'input-pins.json');base=b.local('cms_build');original=read(b.ROOT/data['original_receipt'])
    recipes=base.compile_recipes(original);fc=recipes['CT_interface.f'][0]
    require(fc==read(b.HERE/'toolchain-pins.json')['required_tools']['gfortran']['path'],'original compiler differs')
    flags=recipes['CT_interface.f'][1:recipes['CT_interface.f'].index('-c')]
    process=[Path(x).name for x in original['objects']];require(len(process)==19,'exact19 process objects required')
    loader=b.support(b.LOADER_PATH);runtime=b.local('cms_runtime');results={}
    for lane in ('legacy','candidate'):
        reference=plain['variants'][lane];source=Path(reference['path']).parent.parent.parent;output=directory/lane
        clone_aliases.clone(source,output,data['donor'],data['shared_aliases'],data['original_links'])
        require(base.source_inventory(output)==reference['source_inventory'],'closed source/include copy changed before overlay')
        for name,pin in reference['objects'].items():require(identity(output/name)==pin,'closed object copy changed')
        case=output/SUB;logs=case/'owned-build-commands';logs.mkdir()
        for name,pin in emitted['lanes'][lane]['files'].items():
            source_file=b.HERE/'emittedsrc'/lane/name;require(identity(source_file)==pin,'observed source changed before overlay')
            base.replace_source(case/name,source_file.read_bytes(),output)
        require((case/'tir_cache_size.inc').read_bytes()==b'      PARAMETER(TIR_CACHE_SIZE=0)\n','Fortran cache must remain zero')
        for name,pin in {**data['libraries'],**data['module_inputs']}.items():base.check(output/name,pin)
        selected=sorted(CHANGED|{'check_sa.f'})
        regenerated=[*MODULES] if lane=='candidate' else []
        new_modules=['observer.f90']+(['observed_math.f90'] if lane=='candidate' else [])
        excluded={str(SUB/Path(name).with_suffix('.o')) for name in selected+regenerated}
        preserved={name:pin for name,pin in reference['objects'].items() if name not in excluded}
        for name in selected:(case/Path(name).with_suffix('.o')).unlink(missing_ok=True)
        fresh_module_sources(base,case,new_modules+regenerated,output)
        # Observer before all imports; original private modules in their proven order.
        module_order=['observer.f90',*regenerated]+(['observed_math.f90'] if lane=='candidate' else [])
        for name in module_order:
            b.command(base.compile_argv(recipes['CT_interface.f'],name,str(Path(name).with_suffix('.o'))),case,logs,'module-'+Path(name).stem)
        for name in selected:b.command(recipes[name],case,logs,'compile-'+Path(name).stem)
        require(all(identity(output/name)==pin for name,pin in preserved.items()),'authenticated unchanged object changed')
        extra=list(reference['extra_objects'])+[str(Path(name).with_suffix('.o')) for name in new_modules]
        require(len(extra)==len(set(extra)),'duplicate linked helper objects')
        (case/'owned-info.mk').write_text('include makefile\n.PHONY: owned-info\nowned-info:\n\t@$(info FC $(FC))$(info FFLAGS $(FFLAGS))$(info LINKLIBS $(LINKLIBS))$(info LDFLAGS $(LDFLAGS)) :\n')
        info=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['make']['path'],'-s','--no-print-directory','-f','owned-info.mk','owned-info'],case,logs,'make-link-info')
        fields={line.split()[0]:shlex.split(line)[1:] for line in info.splitlines() if line.strip()}
        require(set(fields)=={'FC','FFLAGS','LINKLIBS','LDFLAGS'} and fields['FC']==[fc] and fields['FFLAGS']==flags,'original scientific flag policy changed')
        require(fields['LDFLAGS']==data['original_LDFLAGS'] and fields['LINKLIBS'][-len(fields['LDFLAGS']):]==fields['LDFLAGS'],'original LDFLAGS omitted/changed')
        link=[fc,*flags,'-Wl,-Map,owned-link.map,--cref','-o','check',*process,*extra,*fields['LINKLIBS']]
        callback=base.query_callback(b,case,logs,lane,link);pre=loader.prelink(link,case,b.environment(),callback)
        for name,wanted in data['runtime'].items():require(digest(name)==wanted and pre['bound'].get(name,wanted)==wanted,'runtime changed before link')
        pre['bound'].update(data['runtime']);pre['explicit_CMS_runtime_before_link']=dict(data['runtime']);b.dump(case/'owned-prelink.json',pre)
        b.command(link,case,logs,'link');loads=loader.requireactualmap((case/'owned-link.map').read_text(),case,pre,case/'check')
        static=runtime.derive(case/'check',pre,data['runtime'],b.environment()['LD_LIBRARY_PATH']);require(static['files']==data['runtime'],'static runtime differs')
        b.dump(case/'owned-static-runtime.json',static);observed=loader.query_runtime(case/'check',data['runtime'],pre,callback)
        nm=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['nm']['path'],'--defined-only','check'],case,logs,'symbols')
        names=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',nm,re.M)
        expected=[name.lower()+'_' for name in emitted['lanes'][lane]['defined_observed_externals']]
        require(all(names.count(name)==1 for name in expected),'observed external missing/duplicated')
        require(all(names.count(name)==1 for name in data['candidate_symbols']) if lane=='candidate' else all(name not in names for name in data['candidate_symbols']),'original private symbol ownership differs')
        require({name:names.count(name) for name in names if '__mtirust_MOD_' in name}=={name:1 for name in data['mtirust_symbols']},'MTIRUST ownership differs')
        require(all(identity(output/name)==pin for name,pin in preserved.items()),'link changed reused objects')
        results[lane]={'path':str(case/'check'),'sha256':digest(case/'check'),'runtime':observed,'source_inventory':base.source_inventory(output),
            'objects':{str(p.relative_to(output)):identity(p) for p in output.rglob('*.o') if p.is_file()},'actual_link_loads':loads,
            'immutable_shared_aliases':clone_aliases.validate_shared(output,data['shared_aliases']),'preserved_authenticated_objects':preserved,
            'extra_objects':extra,'recompiled_units':selected,'module_compile_order':module_order,'prelink_sha256':digest(case/'owned-prelink.json'),
            'link_map_sha256':digest(case/'owned-link.map'),'static_runtime_sha256':digest(case/'owned-static-runtime.json'),'link_command':link,'native_main_calls':0}
    require(b.protected()==before,'protected input changed');verified_plain(b)
    b.dump(directory/'result.json',{'status':'passed','source_index_sha256':b.EXPECTED_SOURCE,'variants':results,
        'plain_reference_BUILD_terminal':PLAIN_TERMINAL,'plain_reference_RUN_terminal':PLAIN_RUN_TERMINAL,'native_main_calls':0,'model_calls':0,'reducer_calls':0,
        'observer_runtime_qualified':False,'plain_observer_parity_qualified':False,'constructor_owner_qualified':False,'q_at_use_qualified':False,
        'full_caller_qualified':False,'independent_physical_truth':False,'scientific_dispatch_enabled':False,'performance_qualified':False})

def verified_build(b):
    verified_plain(b);emission_contract(b)
    require(digest(b.HERE/'composition-receipt.json')==COMPILED_COMPOSITION_SHA,'compiled Fortran composition must remain exact')
    folder=b.ROOT/'.tirust-build/generic-owned-CMS-observer-qualification-work-1/build';terminal=folder/'terminal.json'
    require(b.REVIEWED_BUILD and digest(terminal)==b.REVIEWED_BUILD,'exact separately reviewed observed BUILD terminal required')
    term=read(terminal);require(term['status']=='passed' and term['returncode']==0 and not term['cleanup']['survivors'],'observed BUILD not closed')
    require(digest(folder/'result.json')==term['result_sha256'],'observed BUILD result changed')
    result=read(folder/'result.json');require(result['source_index_sha256']==COMPILED_SOURCE_INDEX and set(result['variants'])=={'legacy','candidate'},'wrong observed BUILD source/lanes')
    base=b.local('cms_build');data=read(b.HERE/'input-pins.json')
    import clone_aliases
    for lane,row in result['variants'].items():
        output=folder/lane;case=output/SUB
        require(row['path']==str(case/'check') and digest(case/'check')==row['sha256'] and not (case/'check').is_symlink(),'observed ELF changed')
        require(base.source_inventory(output)==row['source_inventory'],'observed source/include inputs changed')
        for name,pin in row['objects'].items():require(identity(output/name)==pin,'observed object changed')
        for name,sha in row['actual_link_loads'].items():require(digest(name)==sha,'observed link input changed')
        for name,key in (('owned-prelink.json','prelink_sha256'),('owned-link.map','link_map_sha256'),('owned-static-runtime.json','static_runtime_sha256')):
            require(digest(case/name)==row[key],'observed link/runtime proof changed')
        require(row['runtime']['files']==data['runtime'],'observed runtime differs')
        for name,sha in data['runtime'].items():require(digest(name)==sha,'observed provider changed')
        require(clone_aliases.validate_shared(output,data['shared_aliases'])==row['immutable_shared_aliases'],'observed immutable aliases changed')
    return result
