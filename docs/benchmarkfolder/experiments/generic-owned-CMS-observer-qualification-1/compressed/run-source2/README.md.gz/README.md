# Run-only typed observer parser successor

This source-only successor corrects one demonstrated analyzer contract defect. The first observed RUN remains CLOSED FAILED under its original source2333cb and strict parser. Three legacy workers completed exact parity; candidate point1 returned219 and matched its plain normal stream, then journal validation refused it. Later candidate points and both candidate critical workers were not attempted. Source1, its BUILD, raw evidence, failure, and independent reviews remain unchanged.

## Width-specific meaning

The four actual compiled DP routes pass a literal .TRUE. compatibility/precision-eligibility argument through OS_GENUINE_QP; the separate consumer field records actual MP construction and is correctly false in DP mode. The original parser incorrectly required equality between these distinct meanings. Both actual failed frames match every reference/current word, full mask, selected OK flag and mode; only that semantic comparison differs. The independent source receipt04f6df9b and diagnosis3f9a5f52 bind the exact words and caller coordinates.

The corrected analyzer requires actual compiled CT_interface.f bytes with SHA5dbe44e6 before interpreting any owned frame. Missing, non-byte, changed or unknown source refuses. DP frame eligibility must be TRUE as fixed by those compiled routes; it never claims genuine QP. The actual consumer MP-genuine flag remains separately visible. QP requires the original exact frame/consumer genuine equality and actual MP-entry/constructor/lifetime evidence. Every reference/current/mask/OK/reset/raw/equality/certificate guard remains intact. This is a typed source binding, not a blanket ignore of a genuine flag.

## Exact numerical identity and bounds

No Fortran, observer module, math, driver, model, card or bridge byte changes. All21 compiled emission files remain byte-identical to composition9d239323 and closed source2333cb/BUILDc04a3784; the two observed ELFs and two plain ELFs are preserved. New Python/analyzer source identity is recorded separately from compiled-source identity. The successor CLI accepts RUN only and rejects BUILD; it cannot trigger a recompile. Existing Rust/C bridge ABI is unchanged; private Fortran observer interfaces compiled in the old BUILD still require complete RUN parity.

Future execution requires a fresh exact root admission and fresh work2/run. The six observed requests, own closed RUN4 learning/measured history parity, fifteen-provider mapping checks, resource layout, strict1e-6 runtime card, both caches0/full finite, raw terminal joins and failure cleanup policy are unchanged. Limits remain1800 seconds total including60cleanup,180 per protocol reply,16GiB address space,256MiB per file, core0, nonexclusive CPU12 and shared numerical mutex. No retries, compile, promotion, timing or point-ID scientific branches are admitted by preparation.

Pure replay of retained candidate point1 may describe only that partial evidence under the corrected analyzer. It does not complete missing calls, alter the original failure, prove candidate critical behavior, or authorize another native attempt. Independent physical truth, full caller/numerator lifetime, q/final-dot IEEE lowering, production activation and performance remain unqualified.
