"""Pure actual-reference prefix and mapped-PID adapter controls."""
from pathlib import Path
import hashlib,importlib.util,json,sys,types,unittest
import observer_run as r
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-plain-run-proposal-4'
def frozen(name):
    index=json.loads((PARENT/'source-index.json').read_text())
    if hashlib.sha256((PARENT/'source-index.json').read_bytes()).hexdigest()!='7cc733efccfcfca4aa9a84a36ef3c64ea3cc4471f71e7a48bafaa16ebef3f925':raise ValueError('frozen source changed')
    p=PARENT/(name+'.py')
    if hashlib.sha256(p.read_bytes()).hexdigest()!=index['files'][name+'.py']['sha256']:raise ValueError('frozen helper changed')
    spec=importlib.util.spec_from_file_location('observer_test_frozen_'+name,p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
class ObservedRun(unittest.TestCase):
    def test_actual_all_six_plain_stream_prefixes_parse_with_frozen_parser(self):
        normal=frozen('normal_run_analysis');old=frozen('cms_run')
        result=json.loads((ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run/result.json').read_text())
        for request in old.request_matrix():
            source=ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run/evidence'/request['id']/'driver.raw64'
            raw=source.read_text();prefixes=r.reference_prefixes(raw,request['ids'])
            self.assertEqual(len(prefixes),len(request['ids'])+1)
            words=old.point_words(HERE/'inputs/training.dat',HERE/request['measurement'])
            for n,text in enumerate(prefixes):
                value=normal.parse_raw(text,lane=request['lane'],request_ids=request['ids'][:n],expected_points=words)
                self.assertTrue(value['learning']['ready']);self.assertEqual(len(value['measurements']),n)
            self.assertEqual(value,result['requests'][request['id']]['analysis'])
    def test_actual_learning_prefix_runs_complete_adapter_without_native(self):
        import observer_analysis
        old=frozen('cms_run');normal=frozen('normal_run_analysis')
        request=next(x for x in old.request_matrix() if x['id']=='candidate-controls')
        reference=json.loads((ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-4/run/result.json').read_text())['requests'][request['id']]
        modules={'cms_run':old,'normal_run_analysis':normal,'observer_analysis':observer_analysis}
        b=types.SimpleNamespace(ROOT=ROOT,HERE=HERE,local=lambda name:modules[name])
        adapter=r.AnalysisAdapter(b,request,reference)
        with self.assertRaisesRegex(ValueError,'actual READY'):adapter.parse_raw(adapter.prefixes[0],lane='candidate',request_ids=[])
        adapter.bind(reference['pid'])
        words=old.point_words(HERE/'inputs/training.dat',HERE/request['measurement'])
        value=adapter.parse_raw(adapter.prefixes[0],lane='candidate',request_ids=[],expected_points=words)
        self.assertTrue(value['parity']['passed']);self.assertTrue(value['learning']['ready'])
        self.assertTrue(value['journal_schema_complete']);self.assertFalse(value['journal_provenance_complete'])
        self.assertEqual(value['journals'],[])
        self.assertEqual(value['raw_sha256'],hashlib.sha256(adapter.prefixes[0].encode()).hexdigest())
        self.assertEqual(value['observed_driver_source_sha256'],hashlib.sha256((HERE/'emittedsrc/candidate/check_sa.f').read_bytes()).hexdigest())
    def test_reference_count_and_coordinates_refuse(self):
        raw='CALL RUN 1 20 323 2 0 4 T\nCALL_END\n'
        self.assertEqual(len(r.reference_prefixes(raw,[20])),2)
        for ids in ([],[21],[20,21]):
            with self.assertRaises(ValueError):r.reference_prefixes(raw,ids)
        with self.assertRaises(ValueError):r.reference_prefixes(raw.replace('RUN 1','RUN 2'),[20])
    def test_adapter_requires_actual_ready_pid_binding(self):
        a=r.AnalysisAdapter.__new__(r.AnalysisAdapter);a.pid=None
        for pid in (None,0,-1,True):
            with self.assertRaises(ValueError):a.bind(pid)
        a.bind(123);a.bind(123)
        with self.assertRaises(ValueError):a.bind(124)
    def test_adapter_full_raw_digest_and_failure_gate_are_not_bypassed(self):
        text=(HERE/'observer_run.py').read_text()
        self.assertIn('actual READY mapping must precede analysis',text)
        self.assertIn("value=b.mapped(process,row,started);adapter.bind(process.pid)",text)
        self.assertIn('Any parity/schema/journal refusal raises',text)
        self.assertIn("result['journal_schema_complete']",text)
        self.assertIn('full=old.one(proxy,directory',text)
    def test_command_record_binds_observed_build_and_retains_plain_reference(self):
        plain='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
        expected={'reviewed_build':plain,'argv':['actual-private-check'],'cwd':'private','new_session':False}
        value=r.command_metadata(dict(expected),expected,'a'*64,'b'*64)
        self.assertEqual(value['reviewed_build'],'a'*64)
        self.assertEqual(value['plain_reference_BUILD_terminal'],plain)
        self.assertEqual(value['observed_ELF_sha256'],'b'*64)
        self.assertEqual(value['compiled_source_index_sha256'],'2333cb5216b178da1d77083de30ee4c72226d2b82ec6753d0ddc1fd6459b9e29')
        self.assertEqual(value['argv'],expected['argv']);self.assertEqual(expected['reviewed_build'],plain)
        for changed in ({**expected,'argv':['different']},{**expected,'extra':1}):
            with self.assertRaises(ValueError):r.command_metadata(changed,expected,'a'*64,'b'*64)
        with self.assertRaises(ValueError):r.command_metadata(expected,expected,'not-a-hash','b'*64)
    def test_all_normal_learning_resource_cleanup_rules_are_reused(self):
        text=(HERE/'observer_run.py').read_text()
        self.assertIn("old.request_matrix()",text)
        self.assertIn("'native_processes':6,'compiler_calls':0,'loader_queries':0",text)
        self.assertIn("source.verified_build(b)",text)
        self.assertNotIn('Popen(',text);self.assertNotIn('os.system(',text)
        self.assertIn("del full,adapter,proxy",text)
