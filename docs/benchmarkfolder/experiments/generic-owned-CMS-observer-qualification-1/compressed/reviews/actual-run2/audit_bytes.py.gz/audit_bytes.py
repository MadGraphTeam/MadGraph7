"""Independent retained-data joins only; no project import or FP operations."""
from pathlib import Path
import collections
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.tirust-build/generic-owned-CMS-observer-qualification-work-2/run'
PLAIN = ROOT / '.tirust-build/generic-owned-CMS-plain-run-work-4/run/evidence'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def split_raw(raw):
    lines = raw.decode('ascii').splitlines(keepends=True)
    normal, blocks, i = [], [], 0
    while i < len(lines):
        if lines[i].startswith('OBS_BEGIN '):
            assert any(l.startswith('LEARNED ') for l in normal)
            start = i
            i += 1
            while not lines[i].startswith('OBS_END '):
                assert not lines[i].startswith('OBS_BEGIN ')
                i += 1
            i += 1
            assert lines[i].startswith('CALL RUN ')
            blocks.append(''.join(lines[start:i]))
        else:
            assert not lines[i].startswith('OBS_')
            normal.append(lines[i])
            i += 1
    return ''.join(normal), blocks

def journal_tokens(j, block):
    """Re-serialize the retained parsed fields; compare every raw token."""
    rows = []
    def emit(tag, *args):
        rows.append([tag] + [str(int(v)) if type(v) is bool else str(v) for v in args])
    ps, cs, fs, bs = j['producers'], j['consumers'], j['frames'], j['boundaries']
    emit('OBS_BEGIN', j['sequence'], j['request'], j['point_id'], 0, len(ps), len(cs), len(fs), len(bs))
    for n, code in enumerate(bs, 1):
        emit('OBS_BOUNDARY', n, code)
    for p in ps:
        n = p['index']
        emit('OBS_PRODUCER', n, p['stage'], p['width'], p['h'], p['leg'], p['boundary'], p['ok'], p['genuine'], *p['valid'], *p['pending_valid'])
        for leg in range(4):
            for mu in range(4):
                emit('OBS_PREF', n, leg+1, mu, *p['reference'][leg][mu])
                emit('OBS_PENDING', n, leg+1, mu, *p['pending'][leg][mu])
    for c in cs:
        n = c['index']
        emit('OBS_CONSUMER', n, c['h'], c['so'], c['ctmode'], c['boundary'], c['snapshot'], c['genuine'], c['ok']['64'], c['ok']['128'], *c['masks']['64'], *c['masks']['128'])
        for leg in range(4):
            emit('OBS_COMMIT_JOIN', n, leg+1, *c['joins'][leg])
            if c['snapshot']:
                for mu in range(4):
                    for tag, field, width in [('OBS_CREF_DP','reference','64'), ('OBS_CREF_QP','reference','128'), ('OBS_CURRENT_DP','current','64'), ('OBS_CURRENT_QP','current','128')]:
                        emit(tag, n, leg+1, mu, *c[field][width][leg][mu])
    for f in fs:
        n = f['index']
        emit('OBS_FRAME', n, f['group'], f['width'], f['consumer'], f['boundary'], f['refwidth'], f['ctmode'], f['rank'], f['legacy'], f['ready'], f['current_ok'], f['genuine'], *f['mask'], *f['native_present'], f['native_status'], f['check_pass'], f['cache_enabled'], f['matrix_done'], f['native_returned'])
        for leg in range(4):
            for mu in range(4):
                for tag, field in [('OBS_FRAME_REF','reference'), ('OBS_FRAME_CURRENT','current')]:
                    emit(tag, n, leg+1, mu, *f[field][leg][mu])
                for tag, field in [('OBS_PLOOP','ploop'), ('OBS_SHIFT','shifts')]:
                    emit(tag, n, leg+1, mu, f[field][leg][mu])
            emit('OBS_MASS', n, leg+1, *f['masses'][leg])
        emit('OBS_SCALE', n, f['scale'])
        for p in f['pairs']:
            i, k = p['i'], p['j']
            emit('OBS_PAIR', n, i, k, p['class'], *p['coeff'], p['stage_bits'], *[p[x] for x in ['mass_present','mass_snap','cert_ok','final_ok','used','env_present','env_ok','built_present','consumed_present']])
            if p['stage'][0]:
                emit('OBS_ORIGINAL_RAW', n, i, k, *p['original'])
            if p['env_present']:
                emit('OBS_ENV', n, i, k, *p['env'])
            for mu in range(4):
                if p['built_present']:
                    emit('OBS_BUILT_Q', n, i, k, mu, *p['built_q'][mu])
                if p['consumed_present']:
                    emit('OBS_CONSUMED_Q', n, i, k, mu, *p['consumed_q'][mu])
            if p['built_present']:
                emit('OBS_BUILT_RAW', n, i, k, *p['built_raw'])
            if p['consumed_present']:
                emit('OBS_CONSUMED_RAW', n, i, k, *p['consumed_raw'])
            if p['stage'][13]:
                emit('OBS_SMAT', n, i, k, *p['smat'])
            if p['stage'][12]:
                emit('OBS_DIRECT', n, i, k, p['direct'])
            for stage in range(3):
                emit('OBS_NATIVE', n, stage+1, i, k, f['native'][stage][k-1][i-1])
    emit('OBS_END', j['sequence'], 0, len(ps), len(cs), len(fs), len(bs), len(block.rsplit('OBS_END ', 1)[0].encode('ascii')))
    actual = [line.split() for line in block.splitlines()]
    assert rows == actual
    assert sha(block.encode()) == j['raw_sha256'] and len(block) == j['raw_bytes']
    return collections.Counter(row[0] for row in actual)

def main():
    totals, workers = collections.Counter(), []
    top = json.loads((WORK / 'result.json').read_bytes())
    for case in sorted((WORK / 'evidence').iterdir()):
        if not case.is_dir():
            continue
        result_bytes = (case / 'result.json').read_bytes()
        result = json.loads(result_bytes)
        a = result['analysis']
        raw = (case / 'driver.raw64').read_bytes()
        assert sha(result_bytes) == top['requests'][case.name]['result_sha256']
        assert sha(raw) == result['raw_sha256'] == a['raw_sha256']
        assert result['returncode'] == 0 and result['no_retry'] and result['orchestration_closed']
        normal, blocks = split_raw(raw)
        plain = (PLAIN / case.name / 'driver.raw64').read_text()
        assert normal == a['normalized_raw']
        assert normal.split('\n', 1)[1] == plain.split('\n', 1)[1]
        assert sha(normal.encode()) == a['normalized_raw_sha256']
        assert a['normal_analysis']['learning'] == a['plain_analysis']['learning']
        assert a['normal_analysis']['measurements'] == a['plain_analysis']['measurements']
        assert len(blocks) == len(a['journals']) == len(result['request']['ids'])
        counts = collections.Counter(line.split()[0] for line in normal.splitlines() if line)
        assert counts['CALL_END'] == counts['CALL'] == 16 + len(blocks)
        assert counts['BEFORE'] == counts['CALL'] - 1 and counts['AFTER'] == counts['CALL']
        for block, j in zip(blocks, a['journals']):
            totals.update(journal_tokens(j, block))
            totals.update(journals=1, producers=len(j['producers']), consumers=len(j['consumers']), frames=len(j['frames']), vetoes=j['observed_veto_count'])
        totals.update(workers=1, outer_CALLs=counts['CALL'], learning_CALLs=16, measurement_CALLs=len(blocks))
        workers.append({'case':case.name, 'pid':result['pid'], 'raw_sha256':sha(raw), 'raw_bytes':len(raw), 'outer_CALLs':counts['CALL'], 'learning':a['learning']['outer_calls'], 'ready':a['learning']['ready'], 'streak':a['learning']['streak'], 'points':result['request']['ids'], 'codes':[m['code'] for m in a['measurements']], 'vetoes':a['observed_veto_count'], 'journals':len(blocks), 'exact_own_plain_normal_bytes_except_PID_header':True, 'all_raw_journal_tokens_equal_retained_analysis':True})
    deltas = {}
    for cohort in ['controls', 'critical20', 'critical21']:
        read = lambda lane: json.loads((WORK / 'evidence' / (lane+'-'+cohort) / 'result.json').read_bytes())['analysis']
        left, right = read('legacy'), read('candidate')
        changes, stages = [], collections.Counter()
        for lj, rj in zip(left['journals'], right['journals']):
            def keyed(journal):
                counts, result = collections.Counter(), {}
                for f in journal['frames']:
                    c = journal['consumers'][f['consumer']-1]
                    key = (f['width'], f['ctmode'], f['rank'], f['check_pass'], c['so'], c['h'])
                    counts[key] += 1
                    result[key+(counts[key],)] = f
                return result
            lm, rm = keyed(lj), keyed(rj)
            assert set(lm) == set(rm)
            for key in sorted(lm):
                l, r = lm[key], rm[key]
                for s in range(3):
                    for j in range(4):
                        for i in range(4):
                            if l['native'][s][j][i] != r['native'][s][j][i]:
                                stages[s+1] += 1
                                if s == 2:
                                    p = next(p for p in r['pairs'] if [p['i'],p['j']] == [i+1,j+1])
                                    upper = next(p for p in r['pairs'] if [p['i'],p['j']] == [min(i+1,j+1),max(i+1,j+1)])
                                    changes.append({'point_id':lj['point_id'], 'key':list(key), 'i':i+1, 'j':j+1, 'legacy_word':l['native'][2][j][i], 'candidate_word':r['native'][2][j][i], 'candidate_coefficients':p['coeff'], 'candidate_pair_class':p['class'], 'candidate_veto_observed':p['used'], 'candidate_source_upper_veto_observed':upper['used'], 'candidate_frame_public_fallback':r['legacy'], 'upper_native_consumed':i<j})
        assert changes == top['native_deltas'][cohort]['changes']
        assert not top['native_deltas'][cohort]['unmatched_frames']
        deltas[cohort] = {'final_native_word_changes':len(changes), 'changes_by_native_stage':dict(stages), 'upper_consumed_changes':sum(c['upper_native_consumed'] for c in changes), 'pairs':sorted({(c['i'],c['j']) for c in changes}), 'exact_changes_equal_top_result':True}
        if cohort == 'controls':
            assert [m['rawANS'] for m in left['measurements']] == [m['rawANS'] for m in right['measurements']]
            assert [m['rawACC'] for m in left['measurements']] == [m['rawACC'] for m in right['measurements']]
            assert all(m['code']==219 for a in [left,right] for m in a['measurements'])
            deltas[cohort].update(bit_identical_amplitude_words=24, bit_identical_accuracy_words=6)
    print(json.dumps({'scope':'integer/string data joins only; no project import, numerical expression or target execution', 'totals':dict(totals), 'workers':workers, 'native_deltas':deltas}, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
