#!/usr/bin/env python3
"""Exact source transforms and a read-only n1 input inventory. No native calls."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
CAMPAIGN = 'entry-latch-cache-guard-1'
CASE_ID = 'qcd_n1_uux_z'
CASE = ROOT / '.benchmark-work/tirust/campaigns' / CAMPAIGN / 'outputs/candidate' / CASE_ID
PROC = CASE / 'SubProcesses/P0_uux_z'
SOURCE = {
    'TIRUST_interface.f': (PROC / 'TIRUST_interface.f', 'c740fdb22e1347ff2c3f6bcacc2a4d22085fd94bf3ca022e24da3f821cfb9bda'),
    'TIR_interface.f': (PROC / 'TIR_interface.f', 'b5d5487df140ea69aed722086dc853e5fa26cdacdd5af7785efa3590ef3c2d5f'),
    'check_sa.f': (PROC / 'check_sa.f', 'e1e0334777c59a2e673722ad2fa3b631089e52c332b6bfd79621404f49cbaf17'),
    'mtirust.f90': (ROOT / 'vendor/tirust/mtirust.f90', '3cb9cf98e82965e546365b293fdfd622cbae2ec09a7ae3d364de3ccf9b9bd56f'),
}
FLAGS = ROOT / 'docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/worker_flags.py'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Expected one unchanged source anchor: ' + repr(old))
    return text.replace(old, new, 1)


def routine(text, name, transform):
    matches = list(re.finditer(r'^      SUBROUTINE ' + name + r'\(.*?^      END\n', text, re.M | re.S))
    if len(matches) != 1:
        raise ValueError('Ambiguous routine: ' + name)
    match = matches[0]
    return text[:match.start()] + transform(match.group()) + text[match.end():]


def call(text, name):
    matches = list(re.finditer(r'^      CALL ' + name + r'\([^\n]*(?:\n     \$[^\n]*)*\n', text, re.M))
    if len(matches) != 1:
        raise ValueError('Ambiguous call: ' + name)
    return matches[0].group()


START = '      CALL DP_PROFILE_START(DP_TICK)\n'


def end(stage):
    return f'      CALL DP_PROFILE_END({stage},DP_TICK)\n'


def adapter(text):
    def diagnostic(body):
        body = once(body, '      USE MTIRUST\n', '      USE DP_PROFILE_STATE\n      USE MTIRUST\n')
        body = once(body, '      IMPLICIT NONE\n', '      IMPLICIT NONE\n      INTEGER*8 DP_TICK\n')
        body = once(body, '      STABLE=.FALSE.\n',
                    '      CALL DP_PROFILE_BEGIN(CTMODE,NLOOPLINE,RANK)\n' + START + '      STABLE=.FALSE.\n')
        body = once(body, '      PDEN_DUMMY=0\n', end(1) + START + '      PDEN_DUMMY=0\n')
        native = call(body, 'TIRUST_TENSOR_EVALUATE')
        body = once(body, native, end(2) + START + native + end(3) + START)
        body = once(body, '      STABLE=.TRUE.\n', end(5) + '      STABLE=.TRUE.\n')
        return body
    text = routine(text, 'ML5_0_TIRUST_TENSOR_DIAGNOSTIC', diagnostic)
    def wrapper(body):
        body = once(body, '      IMPLICIT NONE\n', '      USE DP_PROFILE_STATE\n      IMPLICIT NONE\n')
        body = once(body, '      END\n', '      CALL DP_PROFILE_FINISH(STABLE)\n      END\n')
        return body
    return routine(text, 'ML5_0_TIRUSTLOOP', wrapper)


def contraction(text):
    def instrument(body):
        body = once(body, '      USE, INTRINSIC :: IEEE_ARITHMETIC',
                    '      USE DP_PROFILE_STATE\n      USE, INTRINSIC :: IEEE_ARITHMETIC')
        body = once(body, '      INTEGER I_SQSO,I_LOOPGROUP,I_LIB\n',
                    '      INTEGER I_SQSO,I_LOOPGROUP,I_LIB\n      INTEGER*8 DP_TICK\n')
        marker = '      DO I=1,3\n        RES(I)=(0.0D0,0.0D0)\n'
        body = once(body, marker, '      IF(MLREDUCTIONLIB(I_LIB).EQ.9) THEN\n' + START + '      ENDIF\n' + marker)
        # All normalization and postcontraction finite tests remain in scope.
        return once(body, '      END\n', '      IF(MLREDUCTIONLIB(I_LIB).EQ.9) THEN\n' + end(6) + '      ENDIF\n      END\n')
    return routine(text, 'ML5_0_TIRLOOP', instrument)


def transport(text):
    text = once(text, '\nmodule mtirust\n', '\nmodule mtirust\n  use dp_profile_state\n')
    start = text.index('  subroutine tensor_dp(')
    stop = text.index('  end subroutine\n', start) + len('  end subroutine\n')
    body = text[start:stop]
    body = once(body, '    integer(c_int) :: poles,finite,check,cache\n',
                '    integer(c_int) :: poles,finite,check,cache\n    integer(c_int64_t) :: dp_tick\n')
    marker = '    status = evaluate_dp('
    body = once(body, marker, '    call dp_profile_start(dp_tick)\n' + marker)
    marker = '    if (status /= TIRUST_SUCCESS) coefs = cmplx(0,0,kind=KI_TIR)\n'
    body = once(body, marker, '    call dp_profile_end(4,dp_tick)\n    call dp_profile_native_status(status)\n' + marker)
    text = text[:start] + body + text[stop:]
    old = '    integer :: result\n    call ensure_context(result)\n    if (result == TIRUST_SUCCESS) result = clear_cache(context)\n'
    new = '    integer :: result\n    integer(c_int64_t) :: dp_tick\n    call dp_profile_start(dp_tick)\n    call ensure_context(result)\n    if (result == TIRUST_SUCCESS) result = clear_cache(context)\n    call dp_profile_end(7,dp_tick,0)\n'
    return once(text, old, new)


def worker(text):
    """Identical observer/command harness for both numerical-source variants."""
    capture = load('dp_n1_flags', FLAGS).CAPTURE.replace('QP_CAPTURE_FP', 'DP_CAPTURE_FP')
    # The file also contains unchanged external helper routines.
    first, rest = text.split('      END\n', 1)
    first = once(first, '      IMPLICIT NONE\n', '      USE DP_PROFILE_STATE\n      IMPLICIT NONE\n')
    text = first + '      END\n' + rest
    declarations = '''      INTEGER DP_MODE,DP_PHASE,DP_FP_FLAGS(5,2)
      INTEGER DP_FP_HALTING(5,2),DP_FP_ROUND(2)
      INTEGER*8 DP_WORDS(5)
      LOGICAL DP_ACTIVE
'''
    text = once(text, '      CHARACTER*16 COMMAND\n', '      CHARACTER*16 COMMAND\n' + declarations)
    text = once(text, '      PREVIOUS_SEQUENCE=0\n', '      PREVIOUS_SEQUENCE=0\n      DP_ACTIVE=.FALSE.\n')
    branch = '''C     Untimed full-cohort exact words and actual IEEE observations.
      IF(TRIM(COMMAND).EQ.'DPTEST') THEN
         IF(SEQUENCE.NE.PREVIOUS_SEQUENCE+1) GOTO 800
         IF(NLOOPS.LT.0.OR.NLOOPS.GT.2) GOTO 800
         PREVIOUS_SEQUENCE=SEQUENCE
         DP_MODE=NLOOPS
         CALL DP_PROFILE_RESET(DP_MODE)
         OPEN(76,FILE='dp-exact.dat',STATUS='NEW')
         OPEN(77,FILE='dp-ieee.dat',STATUS='NEW')
         DO K=1,NPOINTS
            P=POINTS(:,:,K)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL DP_CAPTURE_FP(DP_FP_FLAGS(:,1),
     $           DP_FP_HALTING(:,1),DP_FP_ROUND(1))
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            CALL DP_CAPTURE_FP(DP_FP_FLAGS(:,2),
     $           DP_FP_HALTING(:,2),DP_FP_ROUND(2))
            DO DP_PHASE=1,2
               WRITE(77,'(3I8,11I4)') K,DP_PHASE,
     $              DP_FP_ROUND(DP_PHASE),
     $              DP_FP_FLAGS(:,DP_PHASE),
     $              DP_FP_HALTING(:,DP_PHASE)
            ENDDO
            DO J=0,NDIM
               DP_WORDS(1:4)=TRANSFER(ANS(:,J),DP_WORDS(1:4))
               DP_WORDS(5)=TRANSFER(ACC(MIN(J,NSO)),DP_WORDS(5))
               WRITE(76,'(3I8,5(1X,Z16.16))') K,J,CODE,DP_WORDS
            ENDDO
         ENDDO
         CLOSE(76)
         CLOSE(77)
         CALL DP_PROFILE_FLUSH('dp-parity-timers.tsv')
         WRITE(74,'(A,2I12)') 'DPTESTED ',SEQUENCE,DP_MODE
         FLUSH(74)
         GOTO 100
      ENDIF
      DP_ACTIVE=TRIM(COMMAND).EQ.'DPRUN0'.OR.
     $ TRIM(COMMAND).EQ.'DPRUN1'.OR.TRIM(COMMAND).EQ.'DPRUN2'
      IF(DP_ACTIVE) THEN
         DP_MODE=IACHAR(COMMAND(6:6))-IACHAR('0')
         CALL DP_PROFILE_RESET(DP_MODE)
         COMMAND='RUN'
      ENDIF
'''
    text = once(text, "      IF(TRIM(COMMAND).NE.'RUN') GOTO 800\n", branch + "      IF(TRIM(COMMAND).NE.'RUN') GOTO 800\n")
    text = once(text, "      WRITE(74,'(A,2I12)') 'DONE ',SEQUENCE,NLOOPS\n",
                '''      IF(DP_ACTIVE) THEN
         OPEN(76,FILE='dp-timed-exact.dat',STATUS='REPLACE')
         OPEN(77,FILE='dp-timed-ieee.dat',STATUS='REPLACE')
         DO DP_PHASE=1,2
            WRITE(77,'(3I8,11I4)') 0,DP_PHASE,
     $           DP_FP_ROUND(DP_PHASE),DP_FP_FLAGS(:,DP_PHASE),
     $           DP_FP_HALTING(:,DP_PHASE)
         ENDDO
         DO K=1,NPOINTS
            DO J=0,NDIM
               DP_WORDS(1:4)=TRANSFER(VALUES(:,J,K),DP_WORDS(1:4))
               DP_WORDS(5)=TRANSFER(ACCURACIES(MIN(J,NSO),K),
     $              DP_WORDS(5))
               WRITE(76,'(3I8,5(1X,Z16.16))') K,J,CODES(K),DP_WORDS
            ENDDO
         ENDDO
         CLOSE(76)
         CLOSE(77)
         CALL DP_PROFILE_FLUSH('dp-timers.tsv')
      ENDIF
''' +
                "      WRITE(74,'(A,2I12)') 'DONE ',SEQUENCE,NLOOPS\n")
    text = once(text, '      TIMED_CODES=0\n      CALL SYSTEM_CLOCK(T0)\n',
                '''      TIMED_CODES=0
      IF(DP_ACTIVE) CALL DP_CAPTURE_FP(DP_FP_FLAGS(:,1),
     $ DP_FP_HALTING(:,1),DP_FP_ROUND(1))
      CALL SYSTEM_CLOCK(T0)
''')
    text = once(text, '      CALL SYSTEM_CLOCK(T1)\n      ELAPSED=DBLE(T1-T0)/DBLE(RATE)\n',
                '''      CALL SYSTEM_CLOCK(T1)
      IF(DP_ACTIVE) CALL DP_CAPTURE_FP(DP_FP_FLAGS(:,2),
     $ DP_FP_HALTING(:,2),DP_FP_ROUND(2))
      ELAPSED=DBLE(T1-T0)/DBLE(RATE)
''')
    # Probe runs only after the full100 parity observation, before RUN timing.
    text = once(text, "         CALL DP_PROFILE_FLUSH('dp-parity-timers.tsv')\n",
                "         CALL DP_PROFILE_FLUSH('dp-parity-timers.tsv')\n" +
                "         CALL DP_PROFILE_PROBE('dp-probe.tsv')\n")
    # Do not collide with module state, and keep intent(in) reset arguments
    # distinct from the module variable that reset itself defines.
    probe_loop = '''
      SUBROUTINE DP_EMPTY_PROBE_LOOP(REPETITIONS,WHOLE,RATE)
C     Separate compilation unit: same module call boundary as physics hooks.
      USE DP_PROFILE_STATE
      IMPLICIT NONE
      INTEGER REPETITIONS,I
      INTEGER*8 WHOLE,RATE,START,FINISH,TICK
      CALL SYSTEM_CLOCK(START,RATE)
      DO I=1,REPETITIONS
         CALL DP_PROFILE_START(TICK)
         CALL DP_PROFILE_END(8,TICK)
      ENDDO
      CALL SYSTEM_CLOCK(FINISH)
      WHOLE=FINISH-START
      END
'''
    return re.sub(r'\bDP_MODE\b','DP_REQUEST_MODE',text) + capture + probe_loop


def derive(original):
    baseline = dict(original)
    baseline['check_sa.f'] = worker(original['check_sa.f'])
    observed = dict(baseline)
    observed['TIRUST_interface.f'] = adapter(original['TIRUST_interface.f'])
    observed['TIR_interface.f'] = contraction(original['TIR_interface.f'])
    observed['mtirust.f90'] = transport(original['mtirust.f90'])
    return baseline, observed


def originals():
    result = {}
    for name, (path, expected) in SOURCE.items():
        if digest(path) != expected:
            raise ValueError('Frozen current n1 source changed: ' + str(path))
        result[name] = path.read_text()
    return result


def write_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(value)


def snapshot():
    """Exact current export, object and provider identities; pure file reads."""
    sys.path.insert(0, str(ROOT / 'tools'))
    import tirust_benchmark as bench
    generation = json.loads((CASE / 'generation.json').read_text())
    compilation = json.loads((CASE / 'compilation.json').read_text())
    closed = ROOT / 'docs/benchmarkfolder/campaigns' / CAMPAIGN / 'experiments/numerical' / ('full100-warmup-'+CASE_ID+'-1') / 'candidate-9'
    lane = json.loads((closed / 'candidate-inputs.json').read_text())
    after = json.loads((closed / 'inputs-after.json').read_text())
    if lane['generation'] != generation or lane['compilation'] != compilation:
        raise ValueError('Closed current n1 build does not match the original export')
    if bench.generated_sources(CASE) != compilation['sources'] or digest(PROC / 'check') != compilation['executable_sha256']:
        raise ValueError('Current n1 source/executable has changed')
    if bench.numerical_card_inputs(CASE) != lane['numerical_cards']:
        raise ValueError('Current n1 card inventory changed')
    if any(lane['runtime'][s] != after['runtime'][s] for s in ('libraries','archives','metadata')):
        raise ValueError('Closed runtime postcheck differs')
    files = {}
    paths = [CASE/'generation.json', CASE/'compilation.json', PROC/'check', PROC/'makefile',
             CASE/'Cards/param_card.dat', ROOT/'vendor/tirust/mtirust.f90']
    paths += [ROOT/'docs/benchmarkfolder/campaigns'/CAMPAIGN/'points'/(CASE_ID+s) for s in ('.dat','.json')]
    paths += [closed/n for n in ('candidate-inputs.json','inputs-after.json','result.json','raw/observation.json','raw/warmup.dat')]
    paths += [CASE/n for n in lane['numerical_cards']]
    for section in ('libraries','archives','metadata'):
        paths += [Path(n) for n in lane['runtime'][section]]
    for path in paths:
        name = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        files[name] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    return {'schema':'current-n1-dp-profile-inputs-v1','case':CASE_ID,'output':str(CASE),'subprocess':PROC.name,
            'generated_sources':bench.generated_sources(CASE),'numerical_objects':bench.numerical_objects(CASE),
            'links':{str(p.relative_to(CASE)):{'target':str(p.readlink()),'resolved':str(p.resolve())}
                     for p in sorted(CASE.rglob('*')) if p.is_symlink()},
            'files':files,'runtime':lane['runtime'],'closed_input':str(closed/'candidate-inputs.json'),
            'closed_observation':str(closed/'raw/observation.json'),
            'points':str(ROOT/'docs/benchmarkfolder/campaigns'/CAMPAIGN/'points'/(CASE_ID+'.dat')),
            'settings':lane['settings'],'numerical_cards':lane['numerical_cards'],
            'compiler_flags':compilation['effective_compiler_flags'],
            'native_executions':0,'compiler_invocations':0}


def main():
    original = originals()
    baseline, observed = derive(original)
    for folder, files in (('original-source', original), ('baseline-source', baseline), ('observed-source', observed)):
        (HERE / folder).mkdir(exist_ok=False)
        for name, text in files.items():
            write_new(HERE / folder / name, text)
    diff = ''.join(''.join(difflib.unified_diff(baseline[n].splitlines(True), observed[n].splitlines(True),
                                              fromfile='baseline/'+n, tofile='observed/'+n)) for n in original)
    write_new(HERE / 'instrumentation.diff', diff)
    write_new(HERE / 'input-pins.json', json.dumps(snapshot(),indent=2,sort_keys=True)+'\n')


if __name__ == '__main__':
    main()
