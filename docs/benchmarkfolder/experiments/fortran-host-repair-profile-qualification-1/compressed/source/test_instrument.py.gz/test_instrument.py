"""Source checks only; no Fortran compilation or native execution."""
from pathlib import Path
import re
import unittest
import instrument

SOURCE=Path(__file__).resolve().parent/'original-source/improve_ps.f'


class InstrumentChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original=SOURCE.read_text()
        cls.observed=instrument.instrument(cls.original)
        cls.module=(Path(__file__).resolve().parent/'repair_profile.f90').read_text()

    def test_exact_original_reconstruction(self):
        self.assertEqual(instrument.reconstruct(self.observed),self.original)

    def test_only_two_original_header_names_change(self):
        actual=self.observed.split(instrument.MARKER)[0]
        expected=self.original
        for old,new in ((instrument.DP_PUBLIC,instrument.DP_BODY),(instrument.MP_PUBLIC,instrument.MP_BODY)):
            expected=expected.replace('SUBROUTINE '+old+'(', 'SUBROUTINE '+new+'(',1)
        self.assertEqual(actual,expected)

    def test_public_dp_calls_public_mp(self):
        prefix=self.observed.split(instrument.MARKER)[0]
        self.assertEqual(prefix.count('CALL '+instrument.MP_PUBLIC+'('),1)
        self.assertNotIn('CALL '+instrument.MP_BODY+'(',prefix)

    def test_public_wrapper_argument_and_kind_preservation(self):
        suffix=self.observed.split(instrument.MARKER)[1]
        self.assertEqual(suffix.count('LOGICAL KEEP_OFFSHELL_MASS(NEXTERNAL)'),2)
        self.assertEqual(suffix.count('PARAMETER(NEXTERNAL=3)'),2)
        self.assertEqual(suffix.count('DOUBLE PRECISION P(0:3,NEXTERNAL)'),1)
        self.assertEqual(suffix.count('REAL*16 P(0:3,NEXTERNAL)'),1)
        for stage,body in ((1,instrument.DP_BODY),(2,instrument.MP_BODY)):
            fragment=('CALL REPAIR_PROFILE_BEGIN('+str(stage)+',TICK)\n'
                      '      CALL '+body+'(KEEP_OFFSHELL_MASS,P)\n'
                      '      CALL REPAIR_PROFILE_END('+str(stage)+',TICK)')
            self.assertIn(fragment,suffix)
        self.assertTrue(all(len(line)<=72 for line in suffix.splitlines()))

    def test_no_original_body_return_hook_insertion(self):
        prefix=self.observed.split(instrument.MARKER)[0]
        self.assertNotIn('REPAIR_PROFILE_BEGIN',prefix)
        self.assertNotIn('REPAIR_PROFILE_END',prefix)

    def test_entry_and_nonreturning_stop_refused(self):
        for statement in ('      ENTRY OTHER(P)\n','      STOP 9\n','      ERROR STOP\n'):
            broken=self.original.replace('      IMPLICIT NONE\n',statement+'      IMPLICIT NONE\n',1)
            with self.assertRaises(ValueError):instrument.instrument(broken)

    def test_changed_args_and_source_and_double_instrumentation_refused(self):
        for broken in (self.original.replace('KEEP_OFFSHELL_MASS,','KEEP_OFFSHELL_MASS,X,',1),
                       self.original.replace('NEXTERNAL=3','NEXTERNAL=4',1),
                       self.original[:-1],self.observed):
            with self.assertRaises(ValueError):instrument.instrument(broken)

    def test_reconstruction_rejects_science_mutation(self):
        with self.assertRaises(ValueError):
            instrument.reconstruct(self.observed.replace('QP_P(J,I)=P(J,I)','QP_P(J,I)=P(J,I)+1',1))

    def test_module_has_integer_state_and_no_fp_or_ieee_write(self):
        active='\n'.join(line for line in self.module.splitlines() if not line.lstrip().startswith('!')).lower()
        self.assertNotRegex(active,r'\b(?:real|complex|double\s+precision|ieee_set_\w*)\b')
        self.assertNotRegex(active,r'\b(?:allocate|deallocate|cpu_time)\b')
        self.assertEqual(active.count('call repair_empty_probe_loop('),1)
        self.assertIn('if (profile_mode==0) return',active)

    def test_actual_nested_and_direct_counts_not_assumed(self):
        self.assertIn('stage==2.and.active(1)==1',self.module)
        self.assertIn('nested(stage)=nested(stage)+1_int64',self.module)
        self.assertIn('direct(stage)=direct(stage)+1_int64',self.module)
        self.assertNotIn('nexternal',self.module.lower())
        self.assertIn('if (any(begins/=nested+direct)) stop',self.module)

    def test_flush_and_probe_schema(self):
        self.assertIn('# schema host-repair-profile-v1',self.module)
        self.assertIn('# fields stage begin_count end_count ticks nested_count direct_count',self.module)
        self.assertIn("write(lun,'(6(I0,1X))') stage,begins(stage),ends(stage),ticks(stage),nested(stage),direct(stage)",self.module)
        self.assertIn("write(lun,'(4(I0,1X))') repetitions,rate,whole,ticks(3)",self.module)
        self.assertIn('integer, parameter :: repetitions=100000',self.module)


if __name__=='__main__':unittest.main()
