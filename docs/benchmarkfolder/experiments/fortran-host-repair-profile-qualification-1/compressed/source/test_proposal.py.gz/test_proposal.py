"""Pure current-source, parser, policy and object-alias regression checks."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest import mock

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def load(name):
    spec=importlib.util.spec_from_file_location('host_test_'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module


def journal(mode=2,dp=100,direct=0,dp_ticks=10000,mp_ticks=7000):
    enabled=mode>0
    dp=dp if enabled else 0;direct=direct if enabled else 0
    dp_ticks=dp_ticks if mode==2 and enabled else 0;mp_ticks=mp_ticks if mode==2 and enabled else 0
    return ('# schema host-repair-profile-v1\n# mode '+str(mode)+'\n# clock_rate 1000000000\n'
            '# fields stage begin_count end_count ticks nested_count direct_count\n'
            f'1 {dp} {dp} {dp_ticks} 0 {dp}\n2 {dp+direct} {dp+direct} {mp_ticks} {dp} {direct}\n'
            '3 0 0 0 0 0\n# active 0 0 0\n')


class SourceTests(unittest.TestCase):
    def test_exact_source_derivation(self):
        proof=load('prepare').verify_materialized()
        self.assertTrue(proof['original_bodies_reconstructed_exactly'])
        self.assertTrue(proof['public_ABIs_preserved'])
        self.assertTrue(proof['driver_common'])

    def test_only_repair_and_driver_sources_change(self):
        before={p.name:p.read_bytes() for p in (HERE/'baseline-source').iterdir()}
        after={p.name:p.read_bytes() for p in (HERE/'observed-source').iterdir()}
        self.assertEqual(set(before),{'check_sa.f','improve_ps.f'})
        self.assertEqual(before['check_sa.f'],after['check_sa.f'])
        self.assertNotEqual(before['improve_ps.f'],after['improve_ps.f'])
        for text in after.values():
            self.assertTrue(all(len(line)<=132 or not line or line[0] in 'Cc*!' for line in text.decode().splitlines()))

    def test_controller_dormant_caps_and_destinations(self):
        c=load('controller')
        self.assertEqual(c.ROOT,ROOT)
        self.assertEqual(c.CAPS,{'build':600.,'parity':300.,'profile':600.})
        self.assertEqual(c.CLEANUP,60.)
        self.assertEqual(c.LANES,('baseline','observed-0','observed-1','observed-2'))
        self.assertEqual(c.LOOPS,128);self.assertEqual(c.CYCLES,7)
        self.assertEqual(c.WORK,ROOT/'.tirust-build/fortran-host-repair-profile-work-1')
        self.assertEqual(c.REPORT,ROOT/'.tirust-build/fortran-host-repair-profile-execution-1')

    def test_actual_improve_policy_and_card(self):
        pin=json.loads((HERE/'input-pins.json').read_text())
        recipe=pin['compiler_flags']['scopes']['process']['recipes']['improve_ps.f']
        self.assertEqual(recipe['flags'],['-w','-fPIC','-ffixed-line-length-132'])
        card=(Path(pin['output'])/'Cards/MadLoopParams.dat').read_text()
        self.assertEqual(card.split('#ImprovePSPoint\n',1)[1].splitlines()[0],'2')

    def test_real_retained_directory_alias_join(self):
        c=load('controller');pin=c.read(HERE/'input-pins.json')
        fixture=ROOT/'.tirust-build/fortran-dp-n1-profile-2/build/baseline'
        actual=c.modules()[0].numerical_objects(fixture)
        expected=copy.deepcopy(pin)
        # This is a read-only older profiling fixture, including its own four
        # profile objects. Extend only the fixture inventory, never live pins.
        expected['numerical_objects']=dict(actual)
        for name,value in pin['numerical_objects'].items():
            if name.startswith('lib/'):expected['numerical_objects'][name]=value
        self.assertEqual(len(expected['numerical_objects'])-len(actual),5)
        original_read=c.read
        with mock.patch.object(c,'read',side_effect=lambda p:expected if Path(p).name=='input-pins.json' else original_read(p)):
            joined=c.canonical_objects(fixture,False)
        self.assertEqual(joined,expected['numerical_objects'])

    def test_wrong_directory_alias_is_rejected(self):
        c=load('controller');pin=c.read(HERE/'input-pins.json')
        fixture=ROOT/'.tirust-build/fortran-dp-n1-profile-2/build/baseline'
        wrong=copy.deepcopy(pin);wrong['output']=str(ROOT/'.tirust-build/nonexistent-foreign-original')
        original_read=c.read
        with mock.patch.object(c,'read',side_effect=lambda p:wrong if Path(p).name=='input-pins.json' else original_read(p)):
            with self.assertRaisesRegex(ValueError,'alias target'):c.canonical_objects(fixture,False)


class ParserTests(unittest.TestCase):
    def test_clock_and_counter_scopes(self):
        a=load('analyze')
        clock=a.profile(journal(),2,100,True);counter=a.profile(journal(mode=1),1,100,True)
        self.assertEqual(clock['scopes'][0]['count'],100)
        self.assertEqual(clock['scopes'][1]['nested_count'],100)
        self.assertEqual(counter['scopes'][0]['ticks'],0)

    def test_actual_counts_not_assumed_one(self):
        a=load('analyze');r=a.profile(journal(dp=200),2,100,True)
        self.assertEqual(r['scopes'][0]['count'],200)

    def test_direct_MP_ticks_are_not_called_nested(self):
        a=load('analyze');r=a.profile(journal(direct=5,mp_ticks=12000),2,100,True)
        self.assertIn('All MP core',r['MP_core_scope'])

    def test_uninstrumented_and_disabled_zero(self):
        a=load('analyze');self.assertEqual(a.profile(journal(mode=0),0,100,True)['scopes'][0]['count'],0)
        empty=journal(mode=2,dp=0,dp_ticks=0,mp_ticks=0)
        a.profile(empty,2,100,False)
        with self.assertRaises(ValueError):a.profile(journal(),2,100,False)

    def test_incomplete_reordered_overflow_and_unmatched_rejected(self):
        a=load('analyze')
        invalid=[journal().replace('# active 0 0 0','# active 1 0 0'),
                 journal().replace('1 100 100 10000 0 100','1 100 99 10000 0 100'),
                 journal().replace('2 100 100 7000 100 0','2 100 100 7000 99 1'),
                 journal().replace('3 0 0 0 0 0','3 0 0 1 0 0'),
                 journal().replace('10000',str(2**63)),journal()+'extra\n',journal(mode=1).replace('1 100 100 0','1 100 100 1')]
        for text in invalid:
            with self.assertRaises(ValueError):a.profile(text,1 if '# mode 1\n' in text else 2,100,True)

    def test_seven_cycle_summary_joins_counts(self):
        a=load('analyze');cycles=[]
        for index in range(1,8):
            lanes={name:{'seconds':1.0+i*.01,'profile':a.profile(journal(mode=mode,dp=100 if observed else 0,dp_ticks=10000 if observed else 0,mp_ticks=7000 if observed else 0),mode,100,observed)}
                   for i,(name,mode,observed) in enumerate((('baseline',2,False),('observed-0',0,True),('observed-1',1,True),('observed-2',2,True)))}
            cycles.append({'cycle':index,'lanes':lanes})
        r=a.summary(cycles);self.assertEqual(r['actual_DP_calls_per_amplitude'],[1.0]*7)
        self.assertFalse(r['performance_acceptance']);self.assertFalse(r['all_five_backends_qualified'])
        cycles[0]['lanes']['observed-2']['profile']['scopes'][0]['begin_count']=101
        with self.assertRaises(ValueError):a.summary(cycles)

    def test_empty_probe_is_never_subtracted(self):
        a=load('analyze');r=a.probe('# raw\n100000 1000000000 10000000 7000000\n')
        self.assertEqual(r['repetitions'],100000)
        self.assertIn('never subtracted',r['interpretation'])


class PolicyTests(unittest.TestCase):
    def test_all_original_recipes_exact(self):
        c=load('controller');policy=load('policy');original=c.read(HERE/'input-pins.json')['compiler_flags']
        actual=copy.deepcopy(original)
        actual['scopes']['process']['recipes']['repair_profile.f90']=copy.deepcopy(actual['scopes']['process']['recipes']['improve_ps.f'])
        result=policy.verify_policy(original,actual,c.modules()[1]);self.assertTrue(result['all_original_recipes_preserved'])
        actual['scopes']['process']['recipes']['improve_ps.f']['flags'].append('-O3')
        with self.assertRaises(ValueError):policy.verify_policy(original,actual,c.modules()[1])

    def test_exact_three_unit_selection_and_archive(self):
        c=load('controller');policy=load('policy');compiler=c.tool('gfortran')
        lines=[compiler+' -w -fPIC -ffixed-line-length-132 -c '+name+' -o '+Path(name).stem+'.o' for name in policy.NEEDED]
        lines.append(compiler+' -w -fPIC -ffixed-line-length-132 -o check check_sa.o repair_profile.o improve_ps.o -ltirust')
        chosen,link=policy.select_commands('\n'.join(lines),compiler,c.environment())
        self.assertEqual([name for name,_ in chosen],list(policy.NEEDED))
        with self.assertRaises(ValueError):policy.select_commands('\n'.join(lines).replace('-ltirust','mtirust.o -ltirust'),compiler,c.environment())

    def test_makefile_only_adds_profile_link_and_dependencies(self):
        c=load('controller');policy=load('policy');pin=c.read(HERE/'input-pins.json')
        old=(Path(pin['output'])/'SubProcesses/P0_uux_z/makefile').read_text();new=policy.private_makefile(old)
        self.assertEqual(new.count('repair_profile.o'),3)
        self.assertNotIn('-O3',new[len(old):])
        self.assertIn('check_sa.o improve_ps.o: repair_profile.o',new)




class FailureCleanupTests(unittest.TestCase):
    def test_raw_root_only_cleanup_is_bounded_and_never_qualified(self):
        o=load('ownership')
        record={'pid':99,'process_group':99,'session':99}
        process=mock.Mock(pid=99,returncode=0)
        process.poll.side_effect=[None,0,0,0]
        cleanup=mock.Mock();cleanup.matches.return_value=True
        with mock.patch.object(o.os,'killpg') as kill:
            r=o.raw_cleanup(process,record,cleanup,1.e30)
        kill.assert_called_once_with(99,o.signal.SIGTERM)
        self.assertTrue(r['uncertainty_blocks_later_stages'])

    def test_exited_before_capture_still_blocks_later_stage(self):
        o=load('ownership');process=mock.Mock(returncode=0);process.poll.return_value=0
        cleanup=mock.Mock();cleanup.identity.return_value=None
        with mock.patch.object(o.os,'killpg') as kill:
            r=o.raw_cleanup(process,None,cleanup,1.e30)
        kill.assert_not_called();self.assertTrue(r['uncertainty_blocks_later_stages'])

    def test_controller_retains_raw_handle_before_ownership(self):
        c=(HERE/'controller.py').read_text()
        self.assertIn('owned=None;process=None;raw_record=None;cleaned=False',c)
        self.assertIn('raw_record=cleanup.identity(process.pid)\n                    owned=cleanup.OwnedChild(process)',c)
        self.assertIn('ownership.raw_cleanup(process,raw_record,cleanup',c)

if __name__=='__main__':unittest.main(verbosity=2)
