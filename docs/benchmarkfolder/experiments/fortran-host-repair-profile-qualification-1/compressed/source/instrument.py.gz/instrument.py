"""Pinned n1 phase-space-repair wrappers; no native code is executed here.

Only the two original public routine-header names change. All original body
bytes, including the DP body's call to the public MP entry, remain exact.
Public wrappers append begin/body/end calls so every normal body return passes
the end hook. This deliberately supports one frozen actual CLI source only.
"""
import hashlib
import re

SOURCE_SHA256 = 'd511a2b32b286067c387fc2fc9b1e3d53600f8f7aaf107a53b98e18ec9a53260'
DP_PUBLIC = 'ML5_0_IMPROVE_PS_POINT_PRECISION'
MP_PUBLIC = 'ML5_0_MP_IMPROVE_PS_POINT_PRECISION'
DP_BODY = 'ML5_0_HOST_REPAIR_DP_BODY'
MP_BODY = 'ML5_0_HOST_REPAIR_MP_BODY'
MARKER = 'C HOST_REPAIR_PROFILE_PUBLIC_WRAPPERS_V1\n'


def require(value, message):
    if not value:
        raise ValueError(message)


def _blocks(source):
    """Read executable fixed-form statements without changing physical bytes."""
    lines = source.splitlines(keepends=True)
    index = 0
    while index < len(lines):
        start = index
        line = lines[index]
        index += 1
        if not line.strip() or line[0] in 'Cc*!':
            continue
        require(not line[132:].strip(), 'Executable text beyond column132')
        statement = line[6:132].strip()
        while index < len(lines) and len(lines[index]) > 5 and lines[index][0] not in 'Cc*!' and lines[index][5] not in ' 0\n':
            require(not lines[index][132:].strip(), 'Continuation beyond column132')
            statement += ' ' + lines[index][6:132].strip()
            index += 1
        yield start, index, statement


def _proof(source):
    require(isinstance(source, str) and source.endswith('\n'), 'Complete text source required')
    require('\r' not in source and '\x00' not in source, 'Unsupported source encoding')
    require(MARKER not in source and DP_BODY not in source and MP_BODY not in source,
            'Source is already instrumented or has private-name collisions')
    expected = [DP_PUBLIC, MP_PUBLIC]
    headers = []
    bodies = []
    current = None
    for first, last, statement in _blocks(source):
        upper = statement.upper()
        match = re.fullmatch(r'SUBROUTINE\s+(\w+)\s*\((.*)\)', upper)
        if match and len(headers) < 2:
            require(current is None and match[1] == expected[len(headers)],
                    'The first two routines must be the actual DP/MP entries')
            require(re.sub(r'\s+', '', match[2]) == 'KEEP_OFFSHELL_MASS,P',
                    'Public repair argument list changed')
            current = len(headers)
            headers.append((first, last, match[1]))
            bodies.append([])
        elif current is not None:
            require(not upper.startswith('ENTRY '), 'Alternate ENTRY bypasses public wrappers')
            require(not re.match(r'(?:ERROR\s+)?STOP(?:\s|$)', upper),
                    'Nonreturning original repair entry is outside this scope')
            bodies[current].append(upper)
            if upper == 'END':
                current = None
                if len(headers) == 2:
                    break
    require(len(headers) == 2 and current is None, 'Incomplete repair entry routines')
    require(sum(s.startswith('CALL '+MP_PUBLIC+'(') for s in bodies[0]) == 1,
            'DP entry must call the public MP entry exactly once')
    require(not any(s.startswith('CALL '+DP_PUBLIC+'(') or s.startswith('CALL '+MP_PUBLIC+'(')
                    for s in bodies[1]), 'Recursive public repair call is unsupported')
    return headers


def _wrapper(header, body, stage, kind):
    lines = [header,
        '      USE HOST_REPAIR_PROFILE_STATE, ONLY: REPAIR_PROFILE_BEGIN,\n',
        '     $ REPAIR_PROFILE_END\n',
        '      USE ISO_FORTRAN_ENV, ONLY: INT64\n',
        '      IMPLICIT NONE\n',
        '      INTEGER NEXTERNAL\n',
        '      PARAMETER(NEXTERNAL=3)\n',
        '      LOGICAL KEEP_OFFSHELL_MASS(NEXTERNAL)\n',
        '      '+kind+' P(0:3,NEXTERNAL)\n',
        '      INTEGER(INT64) TICK\n',
        '      CALL REPAIR_PROFILE_BEGIN('+str(stage)+',TICK)\n',
        '      CALL '+body+'(KEEP_OFFSHELL_MASS,P)\n',
        '      CALL REPAIR_PROFILE_END('+str(stage)+',TICK)\n',
        '      END\n']
    result = ''.join(lines)
    require(all(len(line) <= 72 for line in result.splitlines()), 'Wrapper fixed-form width exceeded')
    return result


def instrument(source):
    headers = _proof(source)
    require(hashlib.sha256(source.encode('utf-8')).hexdigest() == SOURCE_SHA256,
            'Only the frozen actual n1 repair source is supported')
    lines = source.splitlines(keepends=True)
    originals = []
    for (first, last, public), private in zip(headers, (DP_BODY, MP_BODY), strict=True):
        originals.append(''.join(lines[first:last]))
        require(lines[first].count(public) == 1, 'Ambiguous routine header name')
        lines[first] = lines[first].replace(public, private, 1)
    transformed = ''.join(lines)
    result = transformed + MARKER + _wrapper(originals[0], DP_BODY, 1, 'DOUBLE PRECISION') + '\n' + _wrapper(originals[1], MP_BODY, 2, 'REAL*16')
    require(reconstruct(result) == source, 'Original body reconstruction failed')
    return result


def reconstruct(observed):
    require(isinstance(observed, str) and observed.count(MARKER) == 1, 'Unique appended wrapper marker required')
    transformed, _ = observed.split(MARKER)
    for private, public in ((DP_BODY, DP_PUBLIC), (MP_BODY, MP_PUBLIC)):
        pattern = re.compile(r'(?m)^(      SUBROUTINE\s+)'+private+r'(?=\()')
        transformed, count = pattern.subn(lambda m: m[1]+public, transformed)
        require(count == 1, 'Unique renamed original header required')
    require(hashlib.sha256(transformed.encode('utf-8')).hexdigest() == SOURCE_SHA256,
            'Original scientific source bytes changed')
    return transformed
