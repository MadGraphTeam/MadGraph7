# Dormant n1 phase-space repair profile

No compiler, make, loader query, reducer, amplitude or new timing has run for
this proposal. It prepares a focused attribution experiment for the existing
host time outside TIRust's measured tensor scopes. It changes no production
source, numerical algorithm, compiler flags, backend defaults or repair policy.
There is no optimization or performance acceptance claim.

The actual frozen process is `u u~ > z [virt=QCD]`, model `loop_sm`, from the
current source campaign `entry-latch-cache-guard-1` / production `0fcd2cd873d6`,
using TIRust DSO `eb3d67fd…`. Its 100 saved physical on-shell Z points vary
longitudinal boosts. All remain checked normal evaluations with the existing
learning, helicity/color sums, stability tests and rescue policy. The frozen
card has `ImprovePSPoint=2`, finite evaluation, all poles, backend9 and normal
CT mode selection. `input-pins.json` preserves the full actual generated-source,
60 numerical-object, card, model, point, compiler and runtime identity.

## What is measured

The public DP repair routine promotes the supplied point to REAL*16, calls the
MP repair routine and narrows the result. The MP routine includes physical and
mass-shell checks, the configured restoration algorithm, its alternative rescue,
warnings and original state. This is actual existing Fortran work, including
ordinary DP amplitude calls; its runtime has not yet been attributed.

`instrument.py` supports only this actual n1 `improve_ps.f` (SHA256 `d511a2b3…`).
It renames the first two original routine headers to distinct private bodies,
leaving every original scientific body byte unchanged. It then appends wrappers
with the original public names, argument order, explicit shapes and DP/QP kinds.
Each wrapper performs begin / original-body call / end. Every normal return of
the original body therefore reaches its end hook. Reconstruction reverses only
the two header names and proves byte equality to the frozen source. ENTRY,
nonreturning primary entries, unexpected signatures and name collisions fail
source preparation. Native ABI and numerical behavior still require the later
BUILD and PARITY gates.

Stage1 measures DP wrapper time inclusive of its nested MP repair and nested
instrumentation. Stage2 measures **all actual MP repair calls**, with separate
nested and direct call counts. It may be described as nested MP core time only
when the observed direct count is zero. The two times must not be added or
subtracted to infer unobserved scopes. Counts come from actual calls; no one-call
per amplitude assumption is imposed. The pinned DP body calls the public MP
entry exactly once, so its nested MP count must equal its actual DP call count.
Counter-only and clocked lanes must agree on actual call histories.

The module uses integer counters and `SYSTEM_CLOCK`. It does not perform
floating arithmetic, write IEEE state, change arguments or touch model/native
cache state. Mode0 disables hooks, mode1 counts, and mode2 counts and clocks.
A separate 100,000-iteration empty bracket loop in `check_sa.o` measures the
module-call/clock/aggregation overhead. Its raw whole-loop and scoped ticks are
reported separately and never subtracted from repair or amplitude timings.

## Common harness and four controls

The successful n1 DP-profile worker supplies the common command, exact-word,
IEEE and timing harness. Its protocol retains the existing `DPTEST` / `DPRUN`
names and `dp-` filenames; these now carry repair scope records. Both physical
executables contain the same driver and new integer profile module. The baseline
keeps the original repair source; the observed executable uses the wrappers.
Four fresh lanes are baseline, observed hooks-disabled, counter-only and clocks.
No historical executable is relabeled as the new baseline.

Every fresh worker clears filters and performs the unchanged bootstrap and full
100-point learning. Every raw learning record must match the retained current
trace. PARITY compares both total/split-order columns for all 100 points:
Born, finite, simple/double poles, accuracy and public status words must be
exactly equal to the new baseline, with matching actual pre/post rounding,
sticky flags and halting observations. All points must keep status219. This
exact instrumentation gate is stronger than the ordinary tolerance comparison;
it is not an independent finite-amplitude truth check. Parity clocks are only
qualification observations, not runtime results.

PROFILE starts four fresh workers, repeating full learning and untimed full100
parity before timing. Seven fixed alternating/rotated cycles use 128 complete
100-point traversals per lane: 12,800 amplitude calls per batch and 358,400 total
across all 28 batches. Every timed status is counted. Raw exact words cover
each batch's final full100 traversal; timed IEEE snapshots are outside the timer.
Complete actual repair counts and ticks cover all calls in each batch.

The four whole-amplitude lanes measure the overhead of wrapper calls, counters
and clocks. They cannot establish an optimization gain. The earlier roughly
71-microsecond unaccounted host interval is motivation only: do not subtract
measurements across separate studies or infer that all of it is repair work.
Initialization remains separate. Sticky equality does not reveal new true-to-true
exceptions or prove trap freedom.

## Build and resource boundary

BUILD performs two private three-unit builds: `repair_profile.f90`,
`improve_ps.f`, `check_sa.f`, then one link each. All original process/MODEL/
DHELAS recipes and compiler-injected environment remain exact; repair and the
new module use `-w -fPIC -ffixed-line-length-132`, without O3 or other arithmetic
changes. All other numerical objects and installed MTIRUST/Rust/NinjaRS archives
remain unchanged. Baseline repair recompilation must match its original object.

The canonical private inventory authenticates the exact shared `lib/` directory
alias and directly hashes all five required libraries/modules omitted by
`Path.rglob`. It is used consistently before/after build and in run copies;
no library is dropped from checks. A read-only regression exercises this rule
on the retained older n1 profile clone. New profile object/module ownership and
the two private repair bodies are explicit. The installed MTIRUST archive must
supply the same 23 definitions as the frozen original executable, with no private
replacement. Actual link LOADs, prebound providers, ELF interpreter runtime and
worker process maps are retained.

The successful pinned tool environment is reused by file hash and resolution;
pure preflight never executes tools or searches the Nix store. Native work is
restricted to separately admitted stages. BUILD cap600s, PARITY300s and PROFILE
600s each include mutex waiting, synchronous checks and a 60s cleanup reserve.
Workers use nonexclusive CPU12, the shared numerical-tests mutex, 16GiB address
space, 512MiB file limit and zero core limit. Failed stages stop without retries.
The supervisor retains a raw child handle/identity before ownership setup and
uses bounded failure-only cleanup if that setup itself fails; uncertainty cannot
become a qualification pass.

All mutable work goes to fresh `.tirust-build/fortran-host-repair-profile-work-1`
and `.tirust-build/fortran-host-repair-profile-execution-1`. Original exports,
reference repositories, production files and Git remain untouched.

## Scope and commands

This is a backend9 n1 diagnostic. The common repair code serves all five
reducers, but this experiment does not qualify their behavior, stress/complex
mass cases, alternative repair branches or performance. It does not combine the
separate dormant repair-O3 or TIRust-wrapper-O3 experiments. Precise performance
acceptance remains Hua-Sheng's local TODO.

Run from `/shared/external/madloop_tirust/madgraph7_madloop_tirust`:

```sh
python3 -B .tirust-build/fortran-host-repair-profile-proposal-1/run_tests.py
python3 -O -B .tirust-build/fortran-host-repair-profile-proposal-1/run_tests.py
python3 -B .tirust-build/fortran-host-repair-profile-proposal-1/controller.py --source SOURCE_INDEX_SHA256
```

After source review, each command admits exactly one separately reviewed stage:

```sh
python3 -B .tirust-build/fortran-host-repair-profile-proposal-1/controller.py --stage build --execute --source SOURCE_INDEX_SHA256
python3 -B .tirust-build/fortran-host-repair-profile-proposal-1/controller.py --stage parity --execute --source SOURCE_INDEX_SHA256 --reviewed-build BUILD_TERMINAL_SHA256
python3 -B .tirust-build/fortran-host-repair-profile-proposal-1/controller.py --stage profile --execute --source SOURCE_INDEX_SHA256 --reviewed-build BUILD_TERMINAL_SHA256 --reviewed-parity PARITY_TERMINAL_SHA256
```

These examples grant no native admission. The first authoring test attempt is
retained: two test expectations were corrected (mock cleanup-poll sequence and
three makefile references versus four), with no native or scientific failure.
Independent review also removed a premature one-DP-call assumption and closed
the supervisor ownership-initialization failure path before source sealing.
