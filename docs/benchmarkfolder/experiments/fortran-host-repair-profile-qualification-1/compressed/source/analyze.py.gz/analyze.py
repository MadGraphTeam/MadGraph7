"""Pure, strict n1 parsers. Reads no live executable and calls no native code."""
import math
import re
import statistics

STAGES={1:'DP_repair_inclusive',2:'MP_repair_all_calls',3:'empty_probe'}


def require(value, message):
    if not value:
        raise ValueError(message)


def exact(text):
    rows = []
    for line in text.splitlines():
        fields = line.split()
        require(len(fields)==8, 'Malformed exact row')
        point,order,status = map(int, fields[:3])
        require(status==219, 'n1 cohort contains failure, initialization or rescue')
        words = [word.upper() for word in fields[3:]]
        require(all(re.fullmatch('[0-9A-F]{16}', w) for w in words), 'Malformed binary64 word')
        require(all((int(w,16)>>52)&2047 != 2047 for w in words), 'Nonfinite exact word')
        require(not (int(words[-1],16)>>63) or int(words[-1],16)&((1<<63)-1)==0,
                'Negative stability estimate')
        rows.append({'point':point,'order':order,'status':status,'words':words})
    require([(r['point'],r['order']) for r in rows]==[(p,o) for p in range(1,101) for o in (0,1)],
            'Exact rows must contain all100 points and both orders once')
    return rows


def ieee(text, timed=False):
    rows = [list(map(int,line.split())) for line in text.splitlines() if line.strip()]
    expected = [[p,phase] for p in ([0] if timed else range(1,101)) for phase in (1,2)]
    require([r[:2] for r in rows]==expected and all(len(r)==13 for r in rows), 'Incomplete IEEE observations')
    require(all(r[2] in range(-1,5) and all(v in (-1,0,1) for v in r[3:]) for r in rows), 'Invalid IEEE observation')
    return rows


def profile(text,mode,calls,observed):
    require(type(mode) is int and mode in (0,1,2),'Invalid requested profiler mode')
    require(type(calls) is int and calls>0,'Positive amplitude-call count required')
    lines=[line for line in text.splitlines() if line.strip()]
    require(len(lines)==8,'Incomplete or extra repair-profile records')
    require(lines[0]=='# schema host-repair-profile-v1' and lines[3]=='# fields stage begin_count end_count ticks nested_count direct_count',
            'Repair profiler schema/layout changed')
    require(lines[1]=='# mode '+str(mode),'Wrong profiler mode')
    match=re.fullmatch(r'# clock_rate ([0-9]+)',lines[2]);require(match is not None,'Invalid clock rate')
    rate=int(match[1]);require(rate>0,'Nonpositive clock rate')
    require(lines[7]=='# active 0 0 0','Uncompleted repair call/probe')
    scopes=[]
    for expected,line in zip((1,2,3),lines[4:7],strict=True):
        require(re.fullmatch(r'[0-9]+(?: +[0-9]+){5} *',line) is not None,'Malformed integer profile row')
        stage,begins,ends,ticks,nested,direct=map(int,line.split())
        require(stage==expected and all(v<2**63 for v in (begins,ends,ticks,nested,direct)) and begins==ends==nested+direct,'Wrong scope/order, overflowing counter or unmatched calls')
        require(mode==2 or ticks==0,'Clock ticks in disabled or counter-only mode')
        require(stage==2 or nested==0,'Unexpected nesting for DP/probe scope')
        scopes.append({'stage':stage,'name':STAGES[stage],'count':begins,'begin_count':begins,'end_count':ends,
                       'ticks':ticks,'nested_count':nested,'direct_count':direct,'seconds':ticks/rate})
    if observed and mode:
        require(scopes[0]['count']>0,'No actual DP repair calls observed in the admitted ImprovePSPoint=2 sample')
        require(scopes[1]['nested_count']==scopes[0]['count'],'Every DP repair must call MP repair exactly once')
        require(scopes[2]['count']==scopes[2]['ticks']==0,'Probe mixed into physics counters')
        if scopes[1]['direct_count']==0:
            require(scopes[0]['ticks']>=scopes[1]['ticks'],'Nested MP time exceeds inclusive DP time')
    else:
        require(all(s['count']==s['ticks']==0 for s in scopes),'Uninstrumented/disabled path recorded hooks')
    return {'mode':mode,'clock_rate':rate,'amplitude_calls':calls,'scopes':scopes,
            'MP_core_scope':'Nested MP core only' if scopes[1]['direct_count']==0 else 'All MP core calls; nested and direct times are not separated',
            'interpretation':'DP time includes nested MP code and hook overhead; no probe subtraction or optimization claim.'}


def probe(text):
    rows = [line.split() for line in text.splitlines() if line.strip() and not line.startswith('#')]
    require(len(rows)==1 and len(rows[0])==4, 'Malformed probe record')
    repetitions,rate,whole,scoped = map(int,rows[0])
    require(repetitions==100000 and rate>0 and whole>=scoped>=0, 'Invalid empty probe counts/ticks')
    return {'repetitions':repetitions,'clock_rate':rate,'whole_loop_ticks':whole,'scoped_ticks':scoped,
            'whole_loop_seconds_per_pair':whole/rate/repetitions,
            'scoped_seconds_per_pair':scoped/rate/repetitions,
            'interpretation':'Whole loop includes calls, aggregation and loop overhead; descriptive, never subtracted.'}


def summary(cycles):
    require(len(cycles)==7 and [r['cycle'] for r in cycles]==list(range(1,8)),'Incomplete seven-cycle profile')
    lanes=('baseline','observed-0','observed-1','observed-2')
    ratios={lane:[] for lane in lanes[1:]};attribution={1:[],2:[]};calls=[];direct=[];DP_counts=[];MP_counts=[]
    for row in cycles:
        require(set(row['lanes'])==set(lanes),'Missing profile lane')
        baseline=row['lanes']['baseline']['seconds'];require(math.isfinite(baseline) and baseline>0,'Bad baseline elapsed')
        for lane in ratios:
            seconds=row['lanes'][lane]['seconds'];require(math.isfinite(seconds) and seconds>0,'Bad observed elapsed')
            ratios[lane].append(seconds/baseline)
        counter=row['lanes']['observed-1']['profile'];clock=row['lanes']['observed-2']['profile']
        require(counter['amplitude_calls']==clock['amplitude_calls'],'Counter/clock physical-call counts differ')
        for left,right in zip(counter['scopes'],clock['scopes'],strict=True):
            require(all(left[key]==right[key] for key in ('stage','begin_count','end_count','nested_count','direct_count')),
                    'Counter/clock actual repair call histories differ')
        n=clock['amplitude_calls'];calls.append(n)
        direct.append(clock['scopes'][1]['direct_count']);DP_counts.append(clock['scopes'][0]['count']);MP_counts.append(clock['scopes'][1]['count'])
        for stage in (1,2):attribution[stage].append(clock['scopes'][stage-1]['seconds']/n)
    return {'paired_cycle_ratios':ratios,'median_ratios':{k:statistics.median(v) for k,v in ratios.items()},
            'repair_seconds_per_amplitude':attribution,'median_repair_seconds_per_amplitude':{k:statistics.median(v) for k,v in attribution.items()},
            'actual_MP_direct_calls_by_cycle':direct,'actual_DP_calls_by_cycle':DP_counts,'actual_MP_calls_by_cycle':MP_counts,'amplitude_calls_by_cycle':calls,
            'actual_DP_calls_per_amplitude':[a/b for a,b in zip(DP_counts,calls,strict=True)],
            'actual_MP_calls_per_amplitude':[a/b for a,b in zip(MP_counts,calls,strict=True)],
            'interpretation':'Actual common host repair scopes and instrumentation overhead; DP includes nested MP, no subtraction.',
            'performance_acceptance':False,'speedup_claimed':False,'all_five_backends_qualified':False}
