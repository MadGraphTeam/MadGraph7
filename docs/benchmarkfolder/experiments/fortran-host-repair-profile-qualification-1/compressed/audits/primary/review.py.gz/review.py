"""Read/hash and strict pure replay of closed repair-profile28 timed batches and fresh qualification."""
from pathlib import Path
import ast,builtins,collections,ctypes,hashlib,io,json,math,os,re,statistics,struct,subprocess,sys,time,types
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/fortran-host-repair-profile-proposal-1';REPORT=ROOT/'.tirust-build/fortran-host-repair-profile-execution-1/profile';BUILD=REPORT.parent/'build';OUT=Path(__file__).resolve().parent
S='97cad155079138419c198599adbbbcc00bb8df0a3ac799b8ef9ec9dd9858bace';B='663b3947123be881864b78179bb8caaa19870277ed654c1232219699a992e5b2';T='39fb1129fa6417ddf9b7950e0eedab3a4484c4a23a314538630a46c4ee33797d';R='b2b12b6cd71aaa91e510fead3fc02fb85361b602c95d81704fb3a7c9a29baa5a'
seen={}
def digest(p):
 p=Path(p).resolve();key=str(p)
 if key not in seen:seen[key]=hashlib.sha256(p.read_bytes()).hexdigest()
 return seen[key]
def read(p):return json.loads(Path(p).read_bytes())
def match(p,h):assert digest(p)==h,str(p)
def defs(text,names,ns):
 nodes=[n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names];assert {n.name for n in nodes}==set(names)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<authenticated pure definitions>','exec'),ns)
start=time.monotonic();match(SRC/'source-index.json',S);seal=read(SRC/'source-index.json')
for n,w in seal['files'].items():match(SRC/n,w['sha256'])
for n,h in seal['support'].items():match(ROOT/n,h)
match(REPORT/'terminal.json',T);match(REPORT/'result.json',R);t=read(REPORT/'terminal.json');r=read(REPORT/'result.json')
assert t['status']==r['status']=='passed' and t['returncode']==0 and not t['cleanup']['survivors']
assert t['source_index_sha256']==r['source_index_sha256']==S and t['result_sha256']==R and r['build_terminal_sha256']==B
assert t['cap_seconds']==600 and t['cleanup_reserve_seconds']==60 and t['cpu']==12 and not t['cpu_reservation']
assert read(REPORT/'actual-limits.json')['actual']=={'address_space_bytes':[16*1024**3]*2,'file_bytes':[512*1024**2]*2,'core_bytes':[0,0]}
match(BUILD/'terminal.json',B);match(BUILD/'result.json',read(BUILD/'terminal.json')['result_sha256']);built=read(BUILD/'result.json')
match(REPORT.parent/'parity/terminal.json','5218212507e983ae8400c6396c32da84d4aed180660addac7436297d5ec761d8');match(REPORT.parent/'parity/result.json','98c2fd869ac47a4f60e075f82f5cfc783f917abbb412f122dc576da2fdd3ebc8');par=read(REPORT.parent/'parity/result.json')
pin=read(SRC/'input-pins.json');prefix='SubProcesses/'+pin['subprocess']+'/';donor=Path(pin['output'])
for n,w in pin['files'].items():match(Path(n) if Path(n).is_absolute() else ROOT/n,w['sha256'])
for n,h in pin['generated_sources'].items():match(donor/n,h)
for n,h in pin['numerical_objects'].items():match(donor/n,h)
closed=read(pin['closed_observation']);historical_warmup=Path(pin['closed_observation']).with_name('warmup.dat').read_text()
assert int(Path(pin['points']).read_text().splitlines()[0])==100
analysis=types.ModuleType('repair_pure_analysis');exec(compile((SRC/'analyze.py').read_bytes(),'<sealed repair parser>','exec'),analysis.__dict__)
worker={'BACKEND_CODES':{(2,1):(1,'DP'),(3,9):(1,'QP'),(2,6):(6,'DP'),(3,8):(6,'QP'),(2,7):(7,'DP'),(2,8):(8,'DP'),(3,2):(8,'QP'),(2,9):(9,'DP'),(3,3):(9,'QP')}}
defs((ROOT/'tools/tirust_benchmark_worker.py').read_text(),{'MeasurementError','validate_status'},worker)
memory={}
class MemoryPath:
 def __init__(self,p):self.name=p.name if isinstance(p,MemoryPath) else str(p)
 def __truediv__(self,p):return MemoryPath(self.name+'/'+p)
 def is_file(self):return self.name in memory
 def open(self,*a,**k):return io.StringIO(memory[self.name])
warm_ns={'math':math,'Path':MemoryPath,'worker':types.SimpleNamespace(validate_status=worker['validate_status']),'MeasurementError':worker['MeasurementError']}
defs((ROOT/'tools/tirust_benchmark_warmup.py').read_text(),{'_call_groups','parse_warmup'},warm_ns)
lanes=('baseline','observed-0','observed-1','observed-2');assert len(r['cycles'])==7 and r['loops_per_batch']==128 and r['points_per_traversal']==100
raw={};bindings={};commands=0
for lane in lanes:
 role='baseline' if lane=='baseline' else 'observed';mode=0 if lane=='baseline' else int(lane[-1]);row=built['variants'][role]
 folder=REPORT/lane;output=ROOT/'.tirust-build/fortran-host-repair-profile-work-1/profile'/lane;proc=output/prefix
 assert not (proc/'worker-protocol.fifo').exists();match(proc/'check',row['executable_sha256'])
 for n,h in row['sources'].items():match(output/n,h)
 for n,h in row['objects'].items():match(output/n,h)
 before=read(folder/'private-before.json');after=read(folder/'private-after.json');assert before==after and before['executable_sha256']==row['executable_sha256']
 for n,h in before['cards'].items():match(output/n,h)
 match(output/'Cards/param_card.dat',before['physical_sha256'])
 runtime=row['runtime']['files'];maps=[]
 for edge in ('before','after'):
  m=read(folder/('maps-'+edge+'.json'));paths=set()
  for line in m['maps'].splitlines():
   fields=line.split(None,5)
   if len(fields)==6 and fields[-1].startswith('/'):
    assert not fields[-1].endswith(' (deleted)');paths.add(str(Path(fields[-1]).resolve()))
  assert paths==set(m['files']);required={**runtime,str((proc/'check').resolve()):row['executable_sha256']};allowed={**required,**seal['allowed_extra_mappings']}
  assert all(m['files'].get(p)==h for p,h in required.items()) and all(allowed.get(p)==h for p,h in m['files'].items())
  for p,h in m['files'].items():match(p,h)
  assert any(x['pid']==m['pid'] for x in t['cleanup']['observed_owned_processes']);maps.append(m)
 assert maps[0]['pid']==maps[1]['pid'] and maps[0]['files']==maps[1]['files']
 for path in (folder/'commands').glob('*.command.json'):
  c=read(path);label=path.name.removesuffix('.command.json');end=read(path.with_name(label+'.terminal.json'));assert end['returncode']==0 and c['argv'][1]=='--list'
  match(path.with_name(label+'.stdout.txt'),end['stdout_sha256']);commands+=1
  providers=set()
  for line in path.with_name(label+'.stdout.txt').read_text().splitlines():
   if not line.strip() or 'linux-vdso' in line:continue
   m=re.search(r'(/[^\s()]+)\s+\(0x',line);assert m;providers.add(str(Path(m[1]).resolve()))
  assert providers==set(runtime)
 log=(folder/'worker.log').read_text();assert not re.search(r'##W03\b',log,re.I)
 warm=read(folder/'warmup.json');assert warm['raw_outputs']['warmup.dat']==historical_warmup==(proc/'warmup.dat').read_text()
 for n,text in warm['raw_outputs'].items():memory[str(folder)+'/'+n]=text
 raw[lane]={'mode':mode,'observed':role=='observed','warm':warm,'ready':read(folder/'ready.json'),'exact':(folder/'exact-before-timing/dp-exact.dat').read_text(),'ieee':(folder/'exact-before-timing/dp-ieee.dat').read_text(),'profile':(folder/'exact-before-timing/dp-parity-timers.tsv').read_text(),'probe':(folder/'exact-before-timing/dp-probe.tsv').read_text()}
 bindings[lane]={'executable_sha256':row['executable_sha256'],'objects':len(row['objects']),'runtime_providers':len(runtime),'mapped_paths':len(maps[0]['files']),'pid':maps[0]['pid'],'W03_records':0}
timed={}
for cycle in range(1,8):
 assert read(REPORT/f'cycle-{cycle}.json')==r['cycles'][cycle-1]
 for lane in lanes:
  folder=REPORT/lane/f'cycle-{cycle}'
  timed[cycle,lane]={n:(folder/n).read_text() for n in ('timing.dat','values.dat','timed_status.dat','dp-timed-exact.dat','dp-timed-ieee.dat','dp-timers.tsv')}
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('External/native API forbidden during numerical replay')
def patch(obj,n):
 if hasattr(obj,n):saved.append((obj,n,getattr(obj,n)));setattr(obj,n,deny)
try:
 for obj,names in [(builtins,['open']),(io,['open','open_code']),(Path,['open','read_bytes','read_text','stat','resolve','write_bytes','write_text']),(os,['open','stat','lstat','listdir','scandir','system','popen','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe']),(subprocess,['Popen','run','call','check_call','check_output']),(ctypes,['CDLL','PyDLL','_dlopen'])]:
  for n in names:patch(obj,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 replayed={};summaries={}
 for lane,d in raw.items():
  warm=warm_ns['parse_warmup'](str(REPORT/lane),9,100,d['ready']);assert warm==d['warm'] and warm['rows']==closed['rows'] and warm['status_counts']=={'219':100}
  parsed={'rows':analysis.exact(d['exact']),'ieee':analysis.ieee(d['ieee']),'profile':analysis.profile(d['profile'],d['mode'],100,d['observed']),'probe':analysis.probe(d['probe'])}
  assert parsed['rows']==par['lanes']['baseline']['rows'] and parsed['ieee']==par['lanes']['baseline']['ieee'];replayed[lane]=parsed
  if lane!='baseline':assert parsed['rows']==replayed['baseline']['rows'] and parsed['ieee']==replayed['baseline']['ieee']
  # Independent raw integer count check, interpreting these observed calls only.
  rows=[list(map(int,line.split())) for line in d['profile'].splitlines() if line.strip() and not line.startswith('#')]
  assert len(rows)==3 and [x[0] for x in rows]==[1,2,3]
  if lane in ('observed-1','observed-2'):
   assert rows[0][1:3]==[100,100] and rows[0][4:]==[0,100]
   assert rows[1][1:3]==[100,100] and rows[1][4:]==[100,0] and rows[2][1:]==[0]*5
  else:assert all(row[1:]==[0]*5 for row in rows)
  if lane!='observed-2':assert all(row[3]==0 for row in rows)
  if lane=='observed-2':assert rows[0][3]>=rows[1][3]>=0
  probe=[line.split() for line in d['probe'].splitlines() if line.strip() and not line.startswith('#')];assert len(probe)==1 and len(probe[0])==4
  n,rate,whole,scoped=map(int,probe[0]);assert n==100000 and rate>0 and whole>=scoped>=0
  summaries[lane]={'actual_DP_repairs':rows[0][1],'actual_MP_repairs':rows[1][1],'actual_MP_nested':rows[1][4],'actual_MP_direct':rows[1][5],'empty_probe_iterations':n,'timing_scope':'Qualification-only clocks/probe; no performance result'}
 from fractions import Fraction
 computed=[];seconds={lane:[] for lane in lanes};dp_scope=[];mp_scope=[];fractions=[];timed_calls=0
 for cycle in range(1,8):
  order=list(lanes);shift=(cycle-1)%4;order=order[shift:]+order[:shift]
  if cycle%2==0:order.reverse()
  assert r['cycles'][cycle-1]['cycle']==cycle and r['cycles'][cycle-1]['order']==order
  row={'cycle':cycle,'order':order,'lanes':{}};cycle_ieee=None
  for lane in order:
   d=timed[cycle,lane];timing=d['timing.dat'].split();assert len(timing)==2
   cold,elapsed=map(float,timing);assert math.isfinite(cold) and math.isfinite(elapsed) and cold>0 and elapsed>0
   exact=analysis.exact(d['dp-timed-exact.dat']);assert exact==par['lanes']['baseline']['rows']
   decimal=[]
   for line in d['values.dat'].splitlines():
    f=line.split();assert len(f)==8
    decimal.append({'point':int(f[0]),'order':int(f[1]),'status':int(f[2]),'words':[struct.pack('>d',float(x)).hex().upper() for x in f[3:]]})
   assert decimal==exact
   status=[list(map(int,l.split())) for l in d['timed_status.dat'].splitlines() if l.strip()];assert status==[[219,12800]];timed_calls+=12800
   flags=analysis.ieee(d['dp-timed-ieee.dat'],timed=True)
   if cycle_ieee is None:cycle_ieee=flags
   assert flags==cycle_ieee
   mode=2 if lane=='baseline' else int(lane[-1]);prof=analysis.profile(d['dp-timers.tsv'],mode,12800,lane!='baseline')
   value={'seconds':elapsed,'timed_status_counts':{'219':12800},'ieee':flags,'profile':prof};assert value==r['cycles'][cycle-1]['lanes'][lane];row['lanes'][lane]=value
   seconds[lane].append(Fraction(timing[1]))
   integers=[list(map(int,l.split())) for l in d['dp-timers.tsv'].splitlines() if l.strip() and not l.startswith('#')]
   rate=int(d['dp-timers.tsv'].splitlines()[2].split()[-1])
   if lane in ('observed-1','observed-2'):
    assert integers[0][1:3]==[12800,12800] and integers[0][4:]==[0,12800]
    assert integers[1][1:3]==[12800,12800] and integers[1][4:]==[12800,0]
   else:assert all(x[1:]==[0]*5 for x in integers)
   if lane=='observed-2':
    dp=Fraction(integers[0][3],rate);mp=Fraction(integers[1][3],rate);assert dp>=mp>=0
    dp_scope.append(dp/12800);mp_scope.append(mp/12800);fractions.append(dp/Fraction(timing[1]))
  computed.append(row)
 assert timed_calls==358400
 summary=analysis.summary(computed);assert json.loads(json.dumps(summary))==r['summary']
 ratios={lane:[float(a/b) for a,b in zip(seconds[lane],seconds['baseline'])] for lane in lanes[1:]}
 for lane,values in ratios.items():assert all(math.isclose(a,b,rel_tol=1e-15,abs_tol=0) for a,b in zip(values,r['summary']['paired_cycle_ratios'][lane]))
 independent={'whole_amplitude_median_us':{lane:float(statistics.median(values)/12800*10**6) for lane,values in seconds.items()},'paired_median_overhead_ratios':{lane:statistics.median(values) for lane,values in ratios.items()},'DP_inclusive_median_us':float(statistics.median(dp_scope)*10**6),'MP_nested_median_us':float(statistics.median(mp_scope)*10**6),'paired_DP_inclusive_fraction_of_clocked_whole_by_cycle':[float(x) for x in fractions],'median_paired_DP_inclusive_fraction_of_clocked_whole':float(statistics.median(fractions)),'ratio_of_DP_and_clocked_whole_medians':float(statistics.median(dp_scope)/(statistics.median(seconds['observed-2'])/12800)),'timed_batches':28,'timed_amplitude_calls':timed_calls,'final_timed_answer_rows':5600,'actual_DP_repairs_per_counted_batch':12800,'actual_nested_MP_repairs_per_counted_batch':12800,'actual_direct_MP_repairs':0,'no_probe_subtraction':True,'no_DP_plus_MP_sum':True}
finally:
 for obj,n,value in reversed(saved):setattr(obj,n,value)
assert not attempts and commands==8 and not r['performance_acceptance'] and not r['optimized']
assert all({k:a[k] for k in ('begin_count','end_count','nested_count','direct_count')}=={k:b[k] for k in ('begin_count','end_count','nested_count','direct_count')} for a,b in zip(replayed['observed-1']['profile']['scopes'],replayed['observed-2']['profile']['scopes']))
receipt={'schema':'independent-host-repair-PROFILE-audit-v1','status':'PASS','source_index_sha256':S,'build_terminal_sha256':B,'profile_terminal_sha256':T,'profile_result_sha256':R,'parity_terminal_sha256':'5218212507e983ae8400c6396c32da84d4aed180660addac7436297d5ec761d8','independently_recomputed':independent,'audit_source_sha256':digest(Path(__file__)),'actual_lanes':bindings,'raw_count_summary':summaries,'fresh_untimed_final_rows':800,'timed_final_rows':5600,'qualified_learning_rows':800,'fresh_full_learning_per_lane':100,'learning_bootstrap_scope':'Complete raw trace matches historical bytes; bootstrap is retained but unqualified.','all_coefficients_accuracy_status_words_equal':True,'all_public_statuses':219,'hardware_IEEE_state_exact':True,'counter_and_clock_call_history_exact':True,'actual_before_after_loader_receipts':8,'cleanup_survivors':0,'forbidden_API_attempts':len(attempts),'new_native_calls':0,'recorded_report_hashes':{str(p.relative_to(REPORT)):digest(p) for p in REPORT.rglob('*') if p.is_file()},'scope':'One current n1/backend9 full100 profile:28 fixed128-traversal batches, actual358400 calls allDP219. Final word buffers cover only each last full100 traversal; counts and scope ticks cover all timed calls. Inclusive DP repair contains nested MP repair and hook cost: do not add scopes, subtract probe overhead or infer optimization gain. Four controls quantify instrumentation overhead with shared-host scatter; roughly6.76percent is descriptive attribution within these clocked batches, not the full unexplained host interval, all-backend qualification or local performance acceptance. Fresh four-lane learning/parity and observed IEEE states held, not trap freedom. No next native stage implied.','elapsed_audit_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_audit_seconds'],'forbidden_attempts':len(attempts)}))
