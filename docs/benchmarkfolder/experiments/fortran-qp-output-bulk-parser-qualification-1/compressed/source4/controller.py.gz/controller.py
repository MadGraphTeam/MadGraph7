"""Bounded SOURCE-only public-decoder qualification controller.

BUILD and RUN require separate exact reviewed source/build hashes. The only C
ABI provider is a recording mock; no Rust, model or physical amplitude is used.
"""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path.cwd()
HERE=Path(__file__).resolve().parent
WORK=ROOT/'.tirust-build/fortran-qp-output-bulk-unit-work-4'
PROPOSAL=ROOT/'.tirust-build/fortran-qp-output-bulk-proposal-1'
PROPOSAL_SHA='600fb55cae10c8f105998c6ae689c09992526765734f33036dd79936261f5150'
CPU=12
CAPS={'run':600.}
BUILD_SOURCE='511225ea5bb4523cbf84012ea424a0710ef6f86b3ec6964ba8e8b41ea08a76d6'
BUILD_WORK=ROOT/'.tirust-build/fortran-qp-output-bulk-unit-work-3/build'
EXACT_BUILD='d4eb1386ce923a16d70666637ff3677091449b30a812b6ebcb90b421c0b3cf9f'
EXACT_RUN='4e70b14200b037f0acf05723f05a29078f26e95bf2871b3be4fc97a4421a815f'
REVIEWED_RUN=None
CLEANUP=60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
SUPPORT={
 'cleanup':('docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py','240d1067a7b7098f056f0f367097def8f374d7979c3001d249c8b1f7cb0bbd84'),
 'loader':('docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py','4b8d035797b0ad742a0b0903228a20cc4bddca922146c4c5ea02ad4f3a011e55'),
}
EXPECTED_SOURCE=None
REVIEWED_BUILD=None

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def now():return datetime.now(timezone.utc).isoformat()
def dump(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
def require(value,message):
    if not value:raise ValueError(message)
def module(name,path,checksum):
    require(digest(path)==checksum,'Changed imported source '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
def support(name):
    path,checksum=SUPPORT[name];return module('bulk_unit_'+name,ROOT/path,checksum)
def source_module(name):
    seal=read(HERE/'source-index.json')
    return module('bulk_unit_'+name,HERE/(name+'.py'),seal['files'][name+'.py']['sha256'])

def check_files(base,files):
    for name,metadata in files.items():
        relative=Path(name)
        require(not relative.is_absolute() and '..' not in relative.parts,'Unsafe indexed path')
        file=base/relative
        require(file.is_file() and not file.is_symlink(),'Missing/nonregular indexed file')
        require(file.stat().st_size==metadata['bytes'] and digest(file)==metadata['sha256'],'Changed indexed file '+name)

def protected():
    pin=read(HERE/'input-pins.json')
    for path,checksum in pin['files'].items():
        q=ROOT/path if not Path(path).is_absolute() else Path(path)
        require(q.is_file() and digest(q)==checksum,'Protected source/tool/runtime changed: '+path)
    return {'input_pins_sha256':digest(HERE/'input-pins.json'),'files_checked':len(pin['files'])}

def verify_source():
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source hash required')
    seal=read(HERE/'source-index.json');check_files(HERE,seal['files'])
    require({str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'},'Source inventory changed')
    require(digest(PROPOSAL/'index.json')==PROPOSAL_SHA,'Frozen proposal changed')
    parent=read(PROPOSAL/'index.json');check_files(PROPOSAL,parent['files'])
    require({str(p.relative_to(PROPOSAL)) for p in PROPOSAL.rglob('*') if p.is_file()}==set(parent['files'])|{'index.json'},'Proposal inventory changed')
    for _,(path,checksum) in SUPPORT.items():require(digest(ROOT/path)==checksum,'Pinned support changed')
    return protected()

def environment():
    current=os.environ.copy();pin=read(HERE/'input-pins.json')
    for key in list(current):
        if key.startswith(('LD_','NIX_')):current.pop(key)
    current.pop('BASH_ENV',None)
    current.pop('ENV',None)
    for key,value in pin['environment'].items():
        if value is None:current.pop(key,None)
        else:current[key]=value
    current.update(PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1',LD_LIBRARY_PATH='',LD_PRELOAD='',
                   OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
                   GFORTRAN_ERROR_BACKTRACE='0',LC_ALL='C',LANG='C',TZ='UTC')
    return current

def preflight():
    before=verify_source();environment()
    require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    corpus=source_module('corpus').build_corpus()
    require(corpus==read(HERE/'corpus.json'),'Frozen corpus differs from source')
    built=verify_build()
    require(REVIEWED_RUN==EXACT_RUN,'Exact reviewed failed RUN3 required')
    replay=source_module('continuation').replay(built,REVIEWED_RUN)
    return {'status':'pure-preflight-passed','source_index_sha256':EXPECTED_SOURCE,'protected':before,
            'retained_replay':replay,'compiler_invocations':0,'native_executions':0,'caps_seconds':CAPS,'resource_limits':LIMITS}

def command(argv,cwd,logs,label,timeout=None,allow_signal=False):
    logs.mkdir(parents=True,exist_ok=True)
    entry={'argv':list(map(str,argv)),'cwd':str(cwd),'started_utc':now(),
           'controller_pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp(),
           'subprocess_new_session':False,'timeout_seconds':timeout}
    dump(logs/(label+'.command.json'),entry)
    with (logs/(label+'.stdout.txt')).open('xb') as output:
        try:
            result=subprocess.run(argv,cwd=cwd,env=environment(),stdout=output,stderr=subprocess.STDOUT,timeout=timeout)
            entry['returncode']=result.returncode
        except subprocess.TimeoutExpired:
            entry.update(timed_out=True,finished_utc=now(),stdout_sha256=digest(logs/(label+'.stdout.txt')))
            dump(logs/(label+'.terminal.json'),entry);raise
    entry.update(finished_utc=now(),stdout_sha256=digest(logs/(label+'.stdout.txt')))
    dump(logs/(label+'.terminal.json'),entry)
    require(result.returncode==0 or (allow_signal and result.returncode==-signal.SIGFPE),'Command failed: '+label)
    return (logs/(label+'.stdout.txt')).read_text(),entry


def verify_build():
    directory=BUILD_WORK;terminal=directory/'terminal.json'
    require(REVIEWED_BUILD==EXACT_BUILD and digest(terminal)==REVIEWED_BUILD,'Separate reviewed closed BUILD hash required')
    closed=read(terminal);require(closed['status']=='passed' and closed['returncode']==0 and not closed['cleanup']['survivors'],'BUILD not closed successfully')
    result=read(directory/'result.json')
    require(digest(directory/'result.json')==closed['result_sha256'] and result['source_index_sha256']==BUILD_SOURCE,'BUILD source/result mismatch')
    for name,checksum in result['objects'].items():require(digest(directory/name)==checksum,'Changed provider object')
    for variant,row in result['executables'].items():
        case=directory/variant
        expected_module=PROPOSAL/('original-mtirust.f90' if variant=='original' else 'candidate-mtirust.f90') if variant in ('original','candidate') else HERE/(variant+'-mtirust.f90')
        require(row['sources']=={'module':digest(expected_module),'driver':digest(HERE/'driver.f90'),'provider':digest(HERE/'provider.c')},'Compiled scientific source differs from continuation')
        require(digest(row['path'])==row['sha256'],'Changed unit executable')
        require(digest(case/'prelink.json')==row['prelink_sha256'] and digest(case/'link.map')==row['link_map_sha256'],'Changed build closure')
        require(digest(case/'unit-runtime-prequery.json')==row['unit_runtime_derivation_sha256'],'Changed static runtime derivation')
        require(source_module('unit_runtime').derive(row['path'],read(case/'prelink.json'))==read(case/'unit-runtime-prequery.json'),'Static runtime derivation changed')
        for name,checksum in row['objects'].items():require(digest(case/name)==checksum,'Changed unit object')
        for name,checksum in {**row['actual_link_loads'],**row['runtime']['files']}.items():require(digest(name)==checksum,'Changed admitted load/provider')
    return result

def run_locked(directory):
    built=verify_build();corpus=read(HERE/'corpus.json');analyzer=source_module('analyze_rejection')
    require(REVIEWED_RUN==EXACT_RUN,'Exact reviewed failed RUN3 required')
    replay=source_module('continuation').replay(built,REVIEWED_RUN)
    dump(directory/'retained-replay.json',replay)
    pending=set(replay['pending_case_ids'])
    results=[]
    for case in corpus['cases']:
        if case['id'] not in pending:continue
        folder=directory/case['id'];folder.mkdir()
        source_module('corpus').write_case(case,folder/'case.txt')
        pair={}
        variants=('forced',) if case['execution']=='forced-hook' else ('original','candidate','observer')
        for variant in variants:
            row=built['executables'][variant]
            require(digest(row['path'])==row['sha256'],'Executable changed before public mock invocation')
            text,terminal=command([row['path'],str(folder/'case.txt')],folder,folder,variant,timeout=10.,allow_signal=bool(case['halt_flag']))
            pair[variant]={'text':text,'terminal':terminal}
        observation=analyzer.compare(case,pair)
        dump(folder/'comparison.json',observation);results.append(observation)
    verify_build();verify_source()
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,'reviewed_build_sha256':REVIEWED_BUILD,
        'case_count':len(results),'cases':results,'retained_replay_sha256':digest(directory/'retained-replay.json'),
        'retained_cases':88,'lexical_only_cases':14,'combined_executed_cases':135,
        'protected':protected(),'actual_tirust_calls':0,'physical_amplitude_calls':0,
        'performance_acceptance':False,'scope':'Public tensor_mp original/candidate plus separate observer/forced hooks, recording ABI only'})

def set_limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited limit too small')
        resource.setrlimit(kind,(value,value))

def child(name):
    set_limits();directory=WORK/name;admit=read(directory/'admission.json')
    require(admit['source_index_sha256']==EXPECTED_SOURCE and admit['stage']==name and admit['reviewed_build_sha256']==REVIEWED_BUILD and admit['reviewed_run_sha256']==REVIEWED_RUN,'Missing exact supervisor admission')
    actual={key:list(resource.getrlimit(kind)) for kind,key in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}
    require(actual=={k:[v,v] for k,v in LIMITS.items()},'Child resource limits differ')
    dump(directory/'limits.json',{'actual':actual,'pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp()})
    verify_source()
    with (ROOT/'.tirust-build/numerical-tests.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        dump(directory/'lock.json',{'acquired_utc':now(),'path':str(Path(lock.name))})
        require(name=='run','This continuation cannot compile')
        run_locked(directory)

def cleanup_owned(owned,end):
    budget=min(55.,max(0.,end-time.monotonic()))
    result=owned.stop(cooperative_seconds=budget*45/55,terminate_seconds=budget*5/55,kill_seconds=budget*5/55)
    require(not result['survivors'],'Owned cleanup unresolved')
    return result

class StageDeadline:
    """One cap covers preflight, execution, cleanup and administrative closure."""
    def __enter__(self):
        self.end=time.monotonic()+self.cap
        self.work_expired=False;self.handoff=False;self.deferred=False
        self.previous=signal.getsignal(signal.SIGALRM)
        signal.signal(signal.SIGALRM,self.expired)
        signal.setitimer(signal.ITIMER_REAL,self.cap-CLEANUP)
        return self
    def __init__(self,cap):self.cap=cap
    def expired(self,number,frame):
        if self.handoff:self.deferred=True;return
        if not self.work_expired:
            self.work_expired=True
            signal.setitimer(signal.ITIMER_REAL,max(.001,self.end-time.monotonic()))
            raise TimeoutError('Unit work cutoff reached; original cleanup reserve starts')
        raise TimeoutError('Original unit all-in cap reached')
    def __exit__(self,*error):
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,self.previous)


def raw_cleanup(process,record,cleanup,end):
    """Failure-only path if OwnedChild construction raised after Popen."""
    events=[]
    if record is None:
        record=cleanup.identity(process.pid)
    if record is None and process.poll() is not None:
        return {'failure_only':True,'returncode':process.returncode,
                'cleanup_scope':'Root exited before identity capture; descendant closure unqualified',
                'uncertainty_blocks_later_stages':True}
    require(record is not None and record['pid']==record['process_group']==record['session'],
            'Raw child session identity unavailable; cleanup uncertainty blocks continuation')
    # The raw handle is retained before ownership construction. Only this
    # positively matched original child session is targeted on this failure path.
    for sig,seconds in ((signal.SIGTERM,2.),(signal.SIGKILL,2.)):
        if process.poll() is not None:break
        require(cleanup.matches(record),'Raw child start identity changed')
        os.killpg(record['process_group'],sig);events.append(signal.Signals(sig).name)
        try:process.wait(timeout=min(seconds,max(.001,end-time.monotonic())))
        except subprocess.TimeoutExpired:continue
    require(process.poll() is not None,'Raw child survived bounded termination')
    return {'failure_only':True,'events':events,'root':record,
            'cleanup_scope':'Raw identified child session; no qualification pass on ownership construction failure',
            'returncode':process.poll(),'uncertainty_blocks_later_stages':True}


def stage(name):
    cleanup=support('cleanup')
    WORK.mkdir(exist_ok=True);directory=WORK/name;directory.mkdir(exist_ok=False)
    entry={'stage':name,'cap_seconds':CAPS[name],'cleanup_reserve_seconds':CLEANUP,'started_utc':now(),'status':'running'}
    owned=None;process=None;raw_record=None;cleaned=False
    with cleanup.SignalRequests() as requests,StageDeadline(CAPS[name]) as deadline:
        entry['deadline_monotonic']=deadline.end
        try:
            requests.check();preflight()
            verify_build()
            argv=[read(HERE/'input-pins.json')['tools']['taskset'],'-c',str(CPU),sys.executable,'-B',str(Path(__file__).relative_to(ROOT)),
                  '--child',name,'--source',EXPECTED_SOURCE]
            argv+=['--reviewed-build',REVIEWED_BUILD,'--reviewed-run',REVIEWED_RUN]
            entry['command']=argv
            dump(directory/'admission.json',{'stage':name,'source_index_sha256':EXPECTED_SOURCE,'reviewed_build_sha256':REVIEWED_BUILD,'reviewed_run_sha256':REVIEWED_RUN,'command':argv,'resource_limits':LIMITS})
            with (directory/'console.log').open('xb') as output:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid)
                    owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['child_pid']=process.pid;dump(directory/'started.json',entry)
                print('START '+name+' child_pid='+str(process.pid),flush=True)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Unit stage failed')
            verify_source();requests.check()
            entry.update(status='passed',finished_utc=now(),result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
        except BaseException as error:
            if process is not None and not cleaned:
                try:
                    entry['cleanup']=cleanup_owned(owned,deadline.end) if owned is not None else raw_cleanup(process,raw_record,cleanup,deadline.end)
                except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
            entry.update(status='failed',error=repr(error),finished_utc=now(),publication_scope='Administrative failure closure, never a qualification pass')
            dump(directory/'terminal.json',entry);raise

def main():
    global EXPECTED_SOURCE,REVIEWED_BUILD,REVIEWED_RUN
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preflight',action='store_true');mode.add_argument('--run',action='store_true')
    mode.add_argument('--child',choices=('run',));parser.add_argument('--source',required=True);parser.add_argument('--reviewed-build',required=True);parser.add_argument('--reviewed-run',required=True)
    args=parser.parse_args();EXPECTED_SOURCE=args.source;REVIEWED_BUILD=args.reviewed_build;REVIEWED_RUN=args.reviewed_run
    require(re.fullmatch('[0-9a-f]{64}',EXPECTED_SOURCE),'Exact source SHA256 required')
    require(REVIEWED_BUILD==EXACT_BUILD and REVIEWED_RUN==EXACT_RUN,'Exact reviewed BUILD3 and failed RUN3 hashes required')
    if args.child:child(args.child);return
    if args.preflight:print(json.dumps(preflight(),sort_keys=True,indent=2));return
    stage('run')

if __name__=='__main__':main()
