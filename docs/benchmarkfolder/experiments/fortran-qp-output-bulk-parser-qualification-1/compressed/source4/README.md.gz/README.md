# Bounded public QP parser qualification — RUN-only source4

Source3 BUILD succeeded: four variants,107 commands, exact five-provider
runtime closure. Its terminal is d4eb1386… and source seal511225ea…. Its RUN
then stopped after87 passing cases at options-f0-p3; failed terminal4e70b142…
remains unchanged. The mock and production Mode::new/guard code return ERROR2
for finite=false with no selected poles. The original oracle incorrectly
expected UNSUPPORTED3 and a local transport-error message.

This owner has no compiler stage. All seven scientific/corpus/provider/observer
files, including the original analyzer, are unchanged. A separately bound
analyze_rejection.py overlay changes exactly two unique source statements:
native rejection expects ERROR2 and its native message. No precision, word,
IEEE, transport-failure, cache or tolerance condition is weakened.

Before any new native invocation, strict file-only replay authenticates the
complete source3/BUILD3/failed-RUN3 inventories, all264 transcripts, exact88
case files, commands, terminals, compiled scientific sources and libraries.
It replays all META/DONE/FINAL, words, statuses, IEEE and cache gates, reproduces
the earlier87 comparison JSONs exactly, and applies the source-defined native
rejection correction to case88. The old failed status and absence of an old
comparison file remain intact. Any missing, incomplete or changed evidence
blocks all new native execution.

Only the exact47 untouched corpus cases may then run. Every variant invocation
is a fresh independent process with its own context and the same five-call
protocol, so there is no cross-case history to reconstruct. No earlier case is
rerun or substituted. The complete corpus remains the identical149 cases:
88retained +47new executed cases +14lexical-only cases. All four compiled
executables are reused unchanged from BUILD3. No automatic retry is available.
The new RUN has the original600s all-in bound, including60s cleanup. CPU12,
shared numerical mutex, one-thread environment and resource caps are unchanged.
A failed retained replay prevents creation of any new unit invocation.

The source-only preparation/tests run no compiler, loader or unit executable.
Both exact reviewed ancestor hashes are mandatory in addition to this source
seal. After root and independent review, use the pinned Python directly:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/fortran-qp-output-bulk-unit-controller-4/controller.py --preflight --source SOURCE_SHA256 --reviewed-build d4eb1386ce923a16d70666637ff3677091449b30a812b6ebcb90b421c0b3cf9f --reviewed-run 4e70b14200b037f0acf05723f05a29078f26e95bf2871b3be4fc97a4421a815f
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/fortran-qp-output-bulk-unit-controller-4/controller.py --run --source SOURCE_SHA256 --reviewed-build d4eb1386ce923a16d70666637ff3677091449b30a812b6ebcb90b421c0b3cf9f --reviewed-run 4e70b14200b037f0acf05723f05a29078f26e95bf2871b3be4fc97a4421a815f
```

The retained original corpus and BUILD3 protocol follows for context. Its old
compile commands are not available in this RUN-only owner. Actual-amplitude
parity, real wire coverage and end-to-end benefit remain separate later gates.
No production promotion or timing acceptance follows from unit parity.

Source2 BUILD failed after linking the original executable because it imposed
the physical-profile runtime closure on this standalone mock. Its 27 compiler
and query commands passed, but validation stopped before the actual PT_INTERP
query or any unit main. `failure-ancestry.json` retains the exact source2 seal,
failed terminal (`87455735…`), all failure files and cleanup closure. Nothing in
that source or build is overwritten, and no parser RUN occurred there.

This successor derives each unit executable's expected runtime from its own
newly linked ELF DT_NEEDED/RUNPATH graph, constrained to exact prebound compiler
and link inputs. The retained source2 original ELF needs five runtime providers;
its linker LOAD includes libquadmath, but runtime DT_NEEDED does not. The old
physical-profile six-provider expectation is retained only as ancestry and a
negative test. It is never accepted as this unit's expected provider set.
`unit_runtime.py` uses pure ELF-byte reads and supports only the current GNU/Nix
ELF64 x86_64 simple SONAME/absolute RUNPATH mechanism. It rejects unsupported
RPATH, ORIGIN, hwcaps or cache/default lookups before a loader call. A derived
set is provisional: actual link LOAD checks and exact subsequent actual
PT_INTERP `--list` equality remain mandatory for every new executable.

This is the completed successor to the paused, unsealed four-file unit draft.
It does not patch production. The exact original module and exact candidate
come from source proposal `600fb55c…`; candidate SHA256 is `256f0d87…`, original
is `3cb9cf98…`. The original proposal's `EQUIVALENCE.md` remains the full later
promotion contract. This first gate qualifies only public decimal transport
with a recording C ABI, not a real Rust evaluator or amplitude.

BUILD compiles the recording mock and four separate GNU Fortran module/driver
executables. Original and candidate use their exact frozen sources. Observer
and forced-failure modules are separately generated, pinned test-only variants:
the observer records the actual selected branch; the forced variant injects an
error before an otherwise eligible bulk read. Neither variant is scientific
candidate evidence. No Rust, reduction archive, generated process or model is
linked. Actual link maps, unique symbols and the prebound ELF interpreter and
derived runtime providers are checked before a program may run. Compiler/loader
discovery occurs inside BUILD and is recorded, rather than source preparation.

RUN has 149 deterministic corpus cases: 133 ordinary public cases run original,
candidate and observer; two dedicated forced-hook cases run only that hook;
14 undefined or platform-specific parser-syntax cases are lexical-only and
never compared using uninitialized public output. The corpus covers all 42
qualified N/rank pairs, the 21 first/middle/last malformed record positions,
39-significant-digit normals, exact signed zero, binary128 tie and last-bit
boundaries, scalar exponent/subnormal/nonfinite fallback, partial/pole modes,
cache bypass/check passes, clear failure, four rounding modes, five entry sticky
flags and five halting modes. A compact pattern expands to the exact complete
64-byte-record batch for every call. No corpus reduction or automatic retries.

Every normal invocation makes five public calls with scale keys 1,1,2,2,1.
Key1 is an intentionally noncanonical valid scalar record batch; key2 carries
the case's frozen wire batch. The provider inserts before public validation.
The analyzer compares statuses, exact error messages, all binary128 words,
rounding probes, pre/post IEEE flags and halting states, cache entries/bytes,
hits/misses/bypasses/clear calls and final context destruction. Defined success
words in nearest mode are independently computed by integer rational conversion
directly to binary128, never through binary64. For non-nearest modes, default
internal-file READ has no explicit ROUND= promise in this experiment. Exact
original/candidate/observer word equality remains a hard gate, but comparisons
with directional integer references are retained separately as unqualified
diagnostics; no directional-input-correctness claim is made. Arithmetic rounding
probes, pre/post modes and IEEE state still have independent hard gates. This
policy was fixed before any compiler/native execution, not selected from an
observed result. Initially sticky flags may not be cleared.
Unexpected read-error injection must retain zero outputs, exact local error,
one cache-clear attempt per failed call and valid-call behavior afterward.

Actual `ABI_ENTER` and observer branch markers use integer-only byte writes.
Halting cases must have matching original/candidate/observer terminal states
and retained structured output. A trap before ABI entry cannot qualify output
fallback; a retained observer `SCALAR_ENTER` identifies actual decoder entry.
Signals are retained and never changed into successes. Partial mock modes
qualify parser/options dispatch only, not physical Laurent pole zeroing.

The source tests and preparation are pure Python file operations. Exact
source, tool/wrapper, compiler environment and closed profile-runtime pins are
bound before BUILD. Current production module, Rust bridge, installed eb3d DSO
and configuration are protected before/after. One BUILD has an all-in 180s cap;
one RUN has 600s. Each reserves 60s inside that cap for identity-checked cleanup
and administrative failure closure. Preflight and reviewed BUILD verification
are inside these deadlines. Shared 8/9 numerical mutex, nonexclusive CPU12,
one-thread environment, 16GiB address-space, 512MiB per-file and zero core are
fixed. Owned cleanup records observed start identities; it does not claim a
cgroup-wide census. Any unresolved cleanup stops dependent stages. A raw child
handle is retained before ownership construction, with a failure-only TERM/KILL
path; ownership uncertainty never qualifies a subsequent run.

No parser parity or speedup is claimed before those stages close. Real wire
eligibility counts, actual unchanged-full100-learning amplitude parity,
full100 physical observation, and paired descriptive end-to-end timing remain
separate later stages under the unchanged original contract. IEEE modes outside
the four compiler-supported modes, exhaustive NUL-position native mechanics,
legacy undefined-null/slash mechanics, and real-cache failure behavior are not
qualified by this limited unit corpus. The optional optimization must still
show measured benefit before production consideration. Precise performance
acceptance remains Hua-Sheng's local TODO.
