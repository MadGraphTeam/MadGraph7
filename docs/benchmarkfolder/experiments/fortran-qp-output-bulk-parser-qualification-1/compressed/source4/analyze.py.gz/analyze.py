"""Strict public word/IEEE/status/cache comparison; no compiler/native calls."""
import importlib.util
from pathlib import Path
import signal

spec=importlib.util.spec_from_file_location('bulk_unit_oracle',Path(__file__).with_name('corpus.py'))
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
ERROR='TIRust returned an invalid or nonfinite binary128 output record.'


def require(value,message):
    if not value:raise ValueError(message)


def parse(text):
    rows={};markers=[]
    for line in text.splitlines():
        fields=line.split()
        if not fields:continue
        tag=fields[0]
        if tag in {'ABI_ENTER','BULK_ENTER','SCALAR_ENTER','FORCED_ENTER'}:
            markers.append(tag);continue
        if tag in {'META','PROBE','PRE','POST','ERROR','WORD','CACHE','COUNTERS','FINAL','DONE'}:
            rows.setdefault(tag,[]).append(fields[1:])
        elif tag=='DRIVER_ERROR':raise ValueError(line)
    require(len(rows.get('META',[]))==1,'Missing/duplicate META')
    return rows,markers


def comparable(rows):
    return {k:([row[:9] for row in v] if k=='COUNTERS' else [row[:8] for row in v] if k=='FINAL' else v)
            for k,v in rows.items()}


def expected_words(case,record_index,rounding):
    override=case.get('expected_decimal_overrides',{}).get(str(record_index))
    text=override if override is not None else bytes.fromhex(oracle.records(case)[record_index]).decode('ascii').strip()
    return oracle.binary128(text,rounding)


def verify_complete(case,rows,variant):
    count=oracle.count_for_rank(case['rank']);size=8*count
    fields=['n','rank','poles','finite','check','cache','clear_fails','rounding','sticky_mask','halt_flag']
    require(rows['META'][0]==[case['id'],str(case['n']),str(case['rank']),str(count),
            *[str(case[k]) for k in fields[2:]]],'Case metadata mismatch')
    require(len(rows.get('DONE',[]))==1 and len(rows.get('FINAL',[]))==1,'Incomplete successful driver')
    for tag in ('PROBE','PRE','POST','ERROR','CACHE','COUNTERS'):
        require(len(rows.get(tag,[]))==5,'Expected five '+tag+' observations')
    require(len(rows.get('WORD',[]))==5*size,'Wrong output word count')
    source_records=oracle.records(case);expected_cache={};source_words=[]
    if case['expected']=='success':
        for index,value in enumerate(source_records):
            text=case.get('expected_decimal_overrides',{}).get(str(index))
            if text is None:text=bytes.fromhex(value).decode('ascii').strip()
            if text not in expected_cache:expected_cache[text]=oracle.binary128(text,case['rounding'])
            source_words.append(expected_cache[text])
    entries={};hits=misses=clears=peak=bypasses=rejects=bulk=scalar=forced=0
    directional_differences=[]
    for call_id,key in enumerate([1,1,2,2,1],1):
        unsupported=not case['finite'] and case['poles']==3
        bad=key==2 and (case['expected']=='error' or variant=='forced')
        status=3 if unsupported else 2 if bad else 0
        mode=case['rounding'];sticky=[int(bool(case['sticky_mask']&(1<<i))) for i in range(5)]
        halts=[int(case['halt_flag']==i+1) for i in range(5)]
        require(list(map(int,rows['PRE'][call_id-1]))==[call_id,key,mode,*sticky,*halts],'Pre IEEE state changed')
        post=list(map(int,rows['POST'][call_id-1]))
        require(post[:3]==[call_id,status,mode] and post[8:]==halts,'Public status/round/halting mismatch')
        require(all(after>=before for after,before in zip(post[3:8],sticky)),'Entry sticky flag cleared')
        probe=rows['PROBE'][call_id-1]
        # All positive probes are exact rationals; avoid decimal double conversion.
        plus=oracle.binary128('1',mode);minus=plus
        if mode==1:plus=(1,0x3fff000000000000)
        if mode in (2,3):minus=((1<<64)-1,0x3ffeffffffffffff)
        require([int(probe[0]),int(probe[1])]==[call_id,mode] and tuple(int(x,16) for x in probe[2:])==(*plus,*minus),'Actual binary128 rounding probe mismatch')
        if unsupported:rejects+=1
        else:
            if case['cache'] and not case['check']:
                if key in entries:hits+=1
                else:
                    misses+=1;entries[key]=True;peak=max(peak,len(entries))
            else:bypasses+=1
            fast=(key==2 and case['finite']==1 and case['poles']==0 and mode==0 and
                  not case['halt_flag'] and case['whole_batch_canonical'])
            if variant in ('observer','forced'):
                if fast:
                    bulk+=1
                    if variant=='forced':forced+=1
                else:scalar+=1
            if bad:
                clears+=1
                if not case['clear_fails']:entries={}
        error=' '.join(rows['ERROR'][call_id-1][1:])
        require(int(rows['ERROR'][call_id-1][0])==call_id and error==(ERROR if status==2 else 'mock native recording provider'),'Public diagnostic mismatch')
        words=rows['WORD'][(call_id-1)*size:call_id*size]
        for index,row in enumerate(words):
            require(list(map(int,row[:2]))==[call_id,index+1],'Tensor record order mismatch')
            expected=(0,0) if status else oracle.binary128('-0.0' if index%2 else '1.25',mode) if key==1 else source_words[index]
            observed=tuple(int(x,16) for x in row[2:])
            if mode==0 or key==1 or status:
                require(observed==expected,f'Binary128 oracle mismatch call{call_id} record{index+1}')
            elif observed!=expected:
                # Default list-directed input has no explicit ROUND= contract.
                # Directional-reference differences are retained diagnostics;
                # exact original/candidate/observer word equality is still a
                # hard gate for every mode, independent of these references.
                directional_differences.append({'call':call_id,'record':index+1,
                    'observed_words':[f'{x:016x}' for x in observed],
                    'directional_reference_words':[f'{x:016x}' for x in expected]})
        cache=list(map(int,rows['CACHE'][call_id-1]))
        require(cache==[call_id,0,hits,misses,len(entries),len(entries)*size*64,0,bypasses],'Mock cache lifecycle mismatch')
        counters=list(map(int,rows['COUNTERS'][call_id-1]))
        require(counters==[call_id,clears,peak,0,0,0,call_id,0,rejects,bulk,scalar,forced],'ABI/observer counters mismatch')
    require(list(map(int,rows['FINAL'][0]))==[clears,peak,0,1,0,5,0,rejects,bulk,scalar,forced],'Finalization count mismatch')
    return {'public_calls':5,'binary128_word_records':5*size,'bulk_calls':bulk,'scalar_calls':scalar,'forced_calls':forced,
            'non_nearest_directional_reference_scope':'Diagnostic only; default internal-file READ ROUND= semantics unqualified',
            'non_nearest_directional_reference_differences':directional_differences}


def compare(case,pair):
    parsed={name:parse(row['text']) for name,row in pair.items()}
    baseline=parsed.get('original')
    if baseline is not None:
        for name,(rows,markers) in parsed.items():
            require(comparable(rows)==comparable(baseline[0]),'Original/'+name+' observable rows differ')
            require([x for x in markers if x=='ABI_ENTER']==[x for x in baseline[1] if x=='ABI_ENTER'],'ABI-entry count differs')
    returns={name:row['terminal']['returncode'] for name,row in pair.items()}
    require(len(set(returns.values()))==1,'Original/candidate terminal states differ')
    returncode=next(iter(returns.values()))
    details={}
    if returncode==0:
        details={name:verify_complete(case,rows,name) for name,(rows,_) in parsed.items()}
    else:
        require(bool(case['halt_flag']) and returncode==-signal.SIGFPE,'Unexpected nonzero/signal terminal')
        require(all('DONE' not in rows for rows,_ in parsed.values()),'Signal after completed driver')
    return {'case':case['id'],'status':'pass','returncodes':returns,'observations':details,
            'markers':{k:v[1] for k,v in parsed.items()},
            'halting_output_phase_observed':bool(case['halt_flag'] and any(x=='SCALAR_ENTER' for x in parsed.get('observer',({},[]))[1])),
            'physical_amplitude_calls':0,'actual_tirust_calls':0,'performance_acceptance':False}
