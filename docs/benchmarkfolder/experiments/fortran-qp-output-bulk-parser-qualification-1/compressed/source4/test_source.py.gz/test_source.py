"""Pure tests only. No compiler/native/document/subprocess work."""
import ast
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import subprocess

HERE=Path(__file__).resolve().parent
def load(name):
    spec=importlib.util.spec_from_file_location('bulk_fixture_test_'+name,HERE/(name+'.py'))
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
corpus=load('corpus');analyze=load('analyze')


class SourceTests(unittest.TestCase):
    def test_all_python_parses(self):
        for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
    def test_exact_binary128_oracle(self):
        self.assertEqual(corpus.binary128('0'),(0,0))
        self.assertEqual(corpus.binary128('-0'),(0,1<<63))
        self.assertEqual(corpus.binary128('1'),(0,0x3fff000000000000))
        self.assertEqual(corpus.binary128('1.25'),(0,0x3fff400000000000))
        self.assertEqual(corpus.binary128('1.5'),(0,0x3fff800000000000))
        self.assertEqual(corpus.binary128(str(1<<113)),(0,0x4070000000000000))
        self.assertEqual(corpus.binary128(str((1<<113)+1)),corpus.binary128(str(1<<113)))
        self.assertEqual(corpus.binary128(str((1<<113)+3)),corpus.binary128(str((1<<113)+4)))
        self.assertEqual(corpus.binary128('1.0e5000'),(0,0x7fff000000000000))
        self.assertEqual(corpus.binary128('1.0e5000',3),((1<<64)-1,0x7ffeffffffffffff))
        self.assertEqual(corpus.binary128('1.0e-5000'),(0,0))
        self.assertEqual(corpus.binary128('1.0e-5000',1),(1,0))
    def test_grammar(self):
        for x in ['0','-0','1.'+'0'*38+'e0','-1.'+'2'*38+'e-4900']:
            self.assertTrue(corpus.canonical(corpus.record(x)),x)
        for x in ['1.25','+0',' 0','1.'+'0'*38+'e+0','1.'+'0'*38+'e-0','1.'+'0'*38+'e4901',b'0\0',b'0\xff']:
            self.assertFalse(corpus.canonical(corpus.record(x)),x)
    def test_corpus_shapes_failures_and_width(self):
        data=corpus.build_corpus();cases=data['cases']
        self.assertEqual(len({(x['n'],x['rank']) for x in cases if x['id'].startswith('shape-')}),42)
        self.assertEqual(len({x['id'] for x in cases}),len(cases))
        for x in cases:
            self.assertEqual(len(corpus.records(x)),8*corpus.count_for_rank(x['rank']))
            self.assertEqual(x['whole_batch_canonical'],all(corpus.canonical(v) for v in corpus.records(x)))
            if x['execution']=='lexical-only':self.assertFalse(x['whole_batch_canonical'])
        for rank in range(7):
            for loc in ['first','middle','last']:
                self.assertTrue(any(x['id']==f'invalid-r{rank}-{loc}' for x in cases))
    def test_case_writer(self):
        case=corpus.build_corpus()['cases'][0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'case.txt';corpus.write_case(case,p)
            lines=p.read_text().splitlines()
            self.assertEqual(len(lines),1+8*corpus.count_for_rank(case['rank']))
            self.assertTrue(all(len(x)==128 for x in lines[1:]))
    def test_analyzer_rejects_missing_or_duplicate_meta(self):
        for value in ['', 'META one\nMETA two\n']:
            with self.assertRaises(ValueError):analyze.parse(value)
    def test_analyzer_hides_only_labeled_observer_counters(self):
        values={'COUNTERS':[['1',*map(str,range(11))]],'WORD':[['1','2','AA','BB']],
                'FINAL':[[*map(str,range(11))]]}
        out=analyze.comparable(values)
        self.assertEqual(len(out['COUNTERS'][0]),9)
        self.assertEqual(len(out['FINAL'][0]),8)
        self.assertEqual(out['WORD'],values['WORD'])
    def test_deadline_and_ownership_confinement(self):
        s=(HERE/'controller.py').read_text()
        self.assertNotIn("support('deadline')",s)
        self.assertIn('process=None;raw_record=None',s)
        self.assertLess(s.index('process=subprocess.Popen'),s.index('raw_record=cleanup.identity'))
        self.assertLess(s.index('raw_record=cleanup.identity'),s.index('owned=cleanup.OwnedChild'))
        stage=s[s.index('def stage(name):'):s.index('def main():')]
        self.assertLess(stage.index('StageDeadline(CAPS[name])'),stage.index('preflight()'))
        self.assertLess(stage.index('StageDeadline(CAPS[name])'),stage.index('verify_build()'))
        self.assertLess(stage.index("except BaseException as error:"),stage.index("dump(directory/'terminal.json',entry);raise"))
    def test_variant_scope(self):
        s=(HERE/'controller.py').read_text()
        self.assertIn("directory=BUILD_WORK",s)
        self.assertIn("Compiled scientific source differs from continuation",s)
        self.assertNotIn('def build_locked',s)
        self.assertNotIn("add_argument('--build'",s)
        self.assertIn("pending=set(replay['pending_case_ids'])",s)
        self.assertIn("if case['id'] not in pending:continue",s)
        self.assertIn("variants=('forced',) if case['execution']=='forced-hook'",s)
        self.assertNotIn('cargo',s.lower())
    def test_provider_scope(self):
        s=(HERE/'provider.c').read_text()
        self.assertNotIn('strtod',s)
        self.assertNotIn('strtof',s)
        self.assertIn('ABI_ENTER',s)
        self.assertIn('SCALAR_ENTER',s)
        self.assertIn('BULK_ENTER',s)
        self.assertIn('FORCED_ENTER',s)
        self.assertIn('static int64_t counters[11]',s)
    def test_raw_cleanup_escalates_after_term_timeout(self):
        controller=load('controller')
        class Process:
            pid=12345
            def __init__(self):self.finished=False;self.waits=0
            def poll(self):return 0 if self.finished else None
            def wait(self,timeout):
                self.waits+=1
                if self.waits==1:raise subprocess.TimeoutExpired('fake-owned-child',timeout)
                self.finished=True;return 0
        class Cleanup:
            @staticmethod
            def matches(record):return True
        p=Process();record=dict(pid=p.pid,process_group=p.pid,session=p.pid)
        with patch.object(controller.os,'killpg') as kill:
            out=controller.raw_cleanup(p,record,Cleanup,controller.time.monotonic()+10)
        self.assertEqual(p.waits,2)
        self.assertEqual([x.args[1] for x in kill.call_args_list],[controller.signal.SIGTERM,controller.signal.SIGKILL])
        self.assertTrue(out['uncertainty_blocks_later_stages'])
    def test_environment_strips_unpinned_loader_injection(self):
        controller=load('controller')
        injected={'LD_AUDIT':'/unreviewed/audit.so','LD_DEBUG':'libs','LD_PRELOAD':'/unreviewed/preload.so',
                  'LD_LIBRARY_PATH':'/unreviewed/libs','NIX_UNDECLARED_TEST_FLAGS':'-fplugin=/unreviewed/x.so',
                  'BASH_ENV':'/unreviewed/shell-init','ENV':'/unreviewed/sh-init'}
        with patch.dict(controller.os.environ,injected):env=controller.environment()
        self.assertNotIn('LD_AUDIT',env)
        self.assertNotIn('LD_DEBUG',env)
        self.assertNotIn('NIX_UNDECLARED_TEST_FLAGS',env)
        self.assertNotIn('BASH_ENV',env)
        self.assertNotIn('ENV',env)
        self.assertEqual(env['LD_PRELOAD'],'')
        self.assertEqual(env['LD_LIBRARY_PATH'],'')
    def test_complete_analyzer_and_corrupted_word(self):
        case=next(x for x in corpus.build_corpus()['cases'] if x['id']=='shape-n1-r0')
        rows={'META':[[case['id'],'1','0','1','0','1','0','1','0','0','0','0']],
              'PROBE':[],'PRE':[],'POST':[],'ERROR':[],'WORD':[],'CACHE':[],'COUNTERS':[],
              'FINAL':[['0','2','0','1','0','5','0','0','0','0','0']],'DONE':[[]]}
        for call,key in enumerate([1,1,2,2,1],1):
            rows['PROBE'].append([str(call),'0','0000000000000000','3FFF000000000000','0000000000000000','3FFF000000000000'])
            rows['PRE'].append(list(map(str,[call,key,0,*([0]*10)])))
            rows['POST'].append(list(map(str,[call,0,0,*([0]*10)])))
            rows['ERROR'].append([str(call),'mock','native','recording','provider'])
            for i in range(8):
                words=corpus.binary128('-0.0' if i%2 else '1.25') if key==1 else corpus.binary128(bytes.fromhex(corpus.records(case)[i]).decode().strip())
                rows['WORD'].append([str(call),str(i+1),*[f'{w:016X}' for w in words]])
            hits,misses,entries=[(0,1,1),(1,1,1),(1,2,2),(2,2,2),(3,2,2)][call-1]
            rows['CACHE'].append(list(map(str,[call,0,hits,misses,entries,entries*512,0,0])))
            rows['COUNTERS'].append(list(map(str,[call,0,1 if call<3 else 2,0,0,0,call,0,0,0,0,0])))
        self.assertEqual(analyze.verify_complete(case,rows,'original')['public_calls'],5)
        rows['WORD'][0][2]='0000000000000001'
        with self.assertRaisesRegex(ValueError,'Binary128 oracle mismatch'):
            analyze.verify_complete(case,rows,'original')


if __name__=='__main__':unittest.main(verbosity=2)
