! Public tensor_mp transport unit driver, intentionally independent of reducers.
! Compile the driver with -O0 -fPIC -fcheck=all -frounding-math. Compile each
! exact compared MTIRUST module separately with its production -O3 -fPIC flags.
! Input: id n rank poles finite check cache clear_fails round sticky_mask halt_flag
! followed by 8*C(rank+4,4) lines, each exactly 128 hex digits (64 raw bytes).
program qp_output_bulk_unit
  use mtirust
  use iso_c_binding
  use iso_fortran_env, only: output_unit
  use ieee_arithmetic
  use ieee_exceptions
  implicit none
  interface
    function mock_load(records, hex, length) bind(C) result(status)
      import c_int, c_char, c_size_t
      integer(c_int), value :: records
      character(c_char), intent(in) :: hex(*)
      integer(c_size_t), value :: length
      integer(c_int) :: status
    end function
    subroutine mock_reset(fail_clear) bind(C)
      import c_int
      integer(c_int), value :: fail_clear
    end subroutine
    function mock_counters(values, count) bind(C) result(status)
      import c_int, c_int64_t, c_size_t
      integer(c_int64_t), intent(out) :: values(*)
      integer(c_size_t), value :: count
      integer(c_int) :: status
    end function
  end interface
  integer, parameter :: keys(5) = [1,1,2,2,1]
  type(ieee_flag_type), parameter :: observed_flags(5) = &
      [ieee_invalid, ieee_divide_by_zero, ieee_overflow, ieee_underflow, ieee_inexact]
  type(ieee_round_type), parameter :: rounds(0:3) = [ieee_nearest, ieee_up, ieee_down, ieee_to_zero]
  type(ieee_status_type) :: original_status
  logical :: original_halts(size(ieee_all))
  real(KI_QTIR), allocatable :: p(:,:), s(:,:)
  complex(KI_QTIR), allocatable :: m(:), coefs(:,:)
  character(kind=c_char), allocatable :: hex(:)
  character(4096) :: filename, line
  character(128) :: case_id
  character(512) :: message
  integer :: unit, ios, n, rank, poles, finite, check, cache, clear_fails
  integer :: rounding, sticky_mask, halt_flag, count, k, j, i, call_id, record_id
  integer :: status, stats_status, post_round, pre_round, pre_flags(5), post_flags(5)
  integer :: pre_halts(5), post_halts(5)
  integer(c_int) :: c_status
  integer(c_int64_t) :: stats(6), counters(11), words(2), probe_plus(2), probe_minus(2)
  real(KI_QTIR) :: scale
  real(KI_QTIR), volatile :: one, step, plus, minus

  call get_command_argument(1, filename)
  call require(len_trim(filename) > 0, 'one case-file argument is required')
  call ieee_get_status(original_status)
  call ieee_get_halting_mode(ieee_all, original_halts)
  call ieee_set_halting_mode(ieee_all, .false.)
  call require(storage_size(scale) == 128 .and. digits(scale) == 113, 'binary128 kind required')
  call require(storage_size(words(1)) == 64, '64-bit transfer words required')
  open(newunit=unit, file=trim(filename), status='old', action='read', iostat=ios)
  call require(ios == 0, 'cannot open case file')
  read(unit, *, iostat=ios) case_id, n, rank, poles, finite, check, cache, clear_fails, &
      rounding, sticky_mask, halt_flag
  call require(ios == 0, 'invalid case header')
  call require(n >= 1 .and. n <= 6 .and. rank >= 0 .and. rank <= 6, 'unsupported case shape')
  call require(poles >= 0 .and. poles <= 3, 'invalid pole mode')
  call require(min(finite,check,cache,clear_fails) >= 0 .and. &
      max(finite,check,cache,clear_fails) <= 1, 'invalid Boolean option')
  call require(rounding >= 0 .and. rounding <= 3 .and. sticky_mask >= 0 .and. &
      sticky_mask < 32 .and. halt_flag >= 0 .and. halt_flag <= 5, 'invalid IEEE control')
  call require(ieee_support_rounding(rounds(rounding), scale), 'unsupported binary128 rounding')
  do i=1,5
    call require(ieee_support_flag(observed_flags(i), scale), 'unsupported IEEE flag')
    if (halt_flag == i) call require(ieee_support_halting(observed_flags(i)), 'unsupported IEEE halting')
  enddo
  count = tirust_coefficient_count(rank)
  allocate(hex(128*8*count), p(0:3,n), s(n,n), m(n), coefs(count,4))
  do k=1,8*count
    read(unit, '(A)', iostat=ios) line
    call require(ios == 0 .and. len_trim(line) == 128, 'missing or non-128-byte hex line')
    do j=1,128
      hex(128*(k-1)+j) = line(j:j)
    enddo
  enddo
  read(unit, '(A)', iostat=ios) line
  call require(ios < 0, 'extra case-file content')
  close(unit)
  c_status = mock_load(int(8*count,c_int), hex, size(hex,kind=c_size_t))
  call require(c_status == 0, 'provider rejected hex records')
  p = 0.0_KI_QTIR
  s = 0.0_KI_QTIR
  m = cmplx(1.0_KI_QTIR, 0.0_KI_QTIR, kind=KI_QTIR)
  call tirust_register_plan(n, rank, status)
  call require(status == TIRUST_SUCCESS, 'context admission failed')
  call mock_reset(int(clear_fails,c_int))
  write(output_unit,'(A,1X,A,11(1X,I0))') 'META', trim(case_id), n, rank, count, poles, &
      finite, check, cache, clear_fails, rounding, sticky_mask, halt_flag
  do call_id=1,5
    scale = real(keys(call_id), kind=KI_QTIR)
    call ieee_set_halting_mode(ieee_all, .false.)
    call ieee_set_rounding_mode(rounds(rounding))
    call ieee_set_flag(ieee_all, .false.)
    ! Volatile operands and destinations prevent compile-time folding. The
    ! arithmetic probes the actual binary128 mode, independently of the getter.
    one = 1.0_KI_QTIR
    step = 2.0_KI_QTIR ** (-114)
    plus = one + step
    minus = one - step
    probe_plus = transfer(plus, probe_plus)
    probe_minus = transfer(minus, probe_minus)
    call capture(pre_flags, pre_halts, pre_round)
    write(output_unit,'(A,2(1X,I0),4(1X,Z16.16))') 'PROBE', call_id, pre_round, probe_plus, probe_minus
    ! Probe arithmetic and its output are outside the measured public state.
    call ieee_set_flag(ieee_all, .false.)
    do i=1,5
      if (btest(sticky_mask,i-1)) call ieee_set_flag(observed_flags(i), .true.)
    enddo
    if (halt_flag /= 0) call ieee_set_halting_mode(observed_flags(halt_flag), .true.)
    call capture(pre_flags, pre_halts, pre_round)
    write(output_unit,'(A,13(1X,I0))') 'PRE', call_id, keys(call_id), pre_round, pre_flags, pre_halts
    flush(output_unit)
    call tirust_tensor_evaluate(n, rank, p, s, m, scale, coefs, status, &
        pole_mode=poles, compute_finite=finite == 1, check_pass=check == 1, cache_enabled=cache == 1)
    call capture(post_flags, post_halts, post_round)
    call ieee_set_halting_mode(ieee_all, .false.)
    ! Read the public message before statistics, whose ensure_context clears it.
    call tirust_error_message(message)
    write(output_unit,'(A,13(1X,I0))') 'POST', call_id, status, post_round, post_flags, post_halts
    write(output_unit,'(A,1X,I0,1X,A)') 'ERROR', call_id, trim(message)
    do j=1,4
      do i=1,count
        record_id = 2*((j-1)*count+i)-1
        words = transfer(real(coefs(i,j),kind=KI_QTIR), words)
        write(output_unit,'(A,2(1X,I0),2(1X,Z16.16))') 'WORD', call_id, record_id, words
        words = transfer(aimag(coefs(i,j)), words)
        write(output_unit,'(A,2(1X,I0),2(1X,Z16.16))') 'WORD', call_id, record_id+1, words
      enddo
    enddo
    call tirust_qp_cache_statistics(stats, stats_status)
    c_status = mock_counters(counters, size(counters,kind=c_size_t))
    call require(c_status == 0, 'counter retrieval failed')
    write(output_unit,'(A,8(1X,I0))') 'CACHE', call_id, stats_status, stats
    write(output_unit,'(A,12(1X,I0))') 'COUNTERS', call_id, counters
    flush(output_unit)
  enddo
  call tirust_finalize(status)
  call require(status == TIRUST_SUCCESS, 'finalization failed')
  c_status = mock_counters(counters, size(counters,kind=c_size_t))
  call require(c_status == 0, 'final counter retrieval failed')
  write(output_unit,'(A,11(1X,I0))') 'FINAL', counters
  write(output_unit,'(A)') 'DONE'
  flush(output_unit)
  call ieee_set_status(original_status)
  call ieee_set_halting_mode(ieee_all, original_halts)
contains
  subroutine require(condition, description)
    logical, intent(in) :: condition
    character(*), intent(in) :: description
    if (.not.condition) then
      write(output_unit,'(A,1X,A)') 'DRIVER_ERROR', description
      flush(output_unit)
      stop 2
    endif
  end subroutine
  subroutine capture(flags, halts, mode)
    integer, intent(out) :: flags(5), halts(5), mode
    logical :: value
    type(ieee_round_type) :: observed
    integer :: index
    do index=1,5
      call ieee_get_flag(observed_flags(index), value)
      flags(index) = merge(1,0,value)
      call ieee_get_halting_mode(observed_flags(index), value)
      halts(index) = merge(1,0,value)
    enddo
    call ieee_get_rounding_mode(observed)
    mode = -1
    do index=0,3
      if (observed == rounds(index)) mode = index
    enddo
  end subroutine
end program qp_output_bulk_unit
