"""Read/hash and pure arithmetic audit of the closed targeted timing stage."""
from collections import Counter
from datetime import datetime
from fractions import Fraction
from pathlib import Path
import builtins,ctypes,hashlib,io,json,math,os,re,statistics,subprocess,time,types

ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SRC=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-proposal-1'
WORK=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-work-1'
HERE=Path(__file__).resolve().parent
SOURCE='8e19ec4f1e422e5022cb3161cfe248bbc3a11cc6a2e3912e3693718ccea571ce'
BUILD='5fe62f2983e1c80e919fb404d167f1cbce2e004a1a89bab06c465d01860c932c'
PARITY='f2623135240aab116af97f27eb09cf64d8a8f30c44db91852f471411d237c656'
TERMINAL='a851754444b8c0e644871df82b8c79173e36a5f5c8229bccf33b498051f80067'
RESULT='e7f1e68f167c6ad82c2155475d0aa361d026802aa1a5400cc0eff201e2e4b9cc'
PROC='SubProcesses/P0_uux_zgg'
seen={}
def digest(p):
    p=Path(p).resolve();s=p.stat();k=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if str(p) not in seen:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1048576),b''):h.update(b)
        seen[str(p)]=(k,h.hexdigest())
    assert seen[str(p)][0]==k
    return seen[str(p)][1]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())
def canon(x):return json.loads(json.dumps(x))

def main():
    start=time.monotonic();p=WORK/'timing';match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    match(SRC/'source-index.json',SOURCE);match(WORK/'build/terminal.json',BUILD);match(WORK/'parity/terminal.json',PARITY)
    terminal=read(p/'terminal.json');result=read(p/'result.json');pin=read(SRC/'input-pins.json');seal=read(SRC/'source-index.json')
    for n,w in seal['files'].items():match(SRC/n,w['sha256'])
    for n,h in pin['files'].items():
        q=Path(n) if Path(n).is_absolute() else ROOT/n
        if h is None:assert not q.exists() and (str(q.readlink()) if q.is_symlink() else None)==pin['null_symlink_targets'].get(n)
        else:match(q,h)
    bt=read(WORK/'build/terminal.json');pt=read(WORK/'parity/terminal.json')
    match(WORK/'build/result.json',bt['result_sha256']);match(WORK/'parity/result.json',pt['result_sha256'])
    built=read(WORK/'build/result.json');parity=read(WORK/'parity/result.json')
    assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
    assert terminal['result_sha256']==RESULT and result['source_index_sha256']==SOURCE and result['reviewed_build_sha256']==BUILD and result['reviewed_parity_sha256']==PARITY
    assert result['status']=='passed' and not result['performance_acceptance'] and not result['candidate_promoted']
    elapsed=(datetime.fromisoformat(terminal['finished_utc'])-datetime.fromisoformat(terminal['started_utc'])).total_seconds()
    assert elapsed<480 and terminal['cap_seconds']==480 and terminal['cleanup_reserve_seconds']==60
    assert read(p/'limits.json')['actual']['address_space_bytes']==[16*1024**3]*2
    assert read(p/'admission.json')['command']==terminal['command']
    assert set(result['anchors'])=={'1','16'} and set(result['raw_files'])=={'original','candidate'}
    analyzer={};exec(compile((SRC/'analyze.py').read_bytes(),str(SRC/'analyze.py'),'exec'),analyzer)
    expected_warm=read(SRC/'expected-warmup.json');raw={};ready={};mapping_receipts={};warm_counts={};commands=[]
    for name in ('original','candidate'):
        report=p/name;export=report/'export';proc=export/PROC;b=built['executables'][name+'-timing']
        actual={str(q.relative_to(report)) for q in report.rglob('*') if q.is_file() and 'export' not in q.relative_to(report).parts}
        assert actual==set(result['raw_files'][name]) and len(actual)==114
        for n,w in result['raw_files'][name].items():q=report/n;assert q.stat().st_size==w['bytes'];match(q,w['sha256'])
        for n,h in b['sources'].items():match(export/n,h)
        for n,h in b['objects'].items():match(export/n,h)
        for n,h in pin['original_objects'].items():
            if n!=PROC+'/check_sa.o':match(export/n,h)
        for n,h in b['card_binding']['numerical_cards'].items():match(export/n,h)
        match(export/'Cards/param_card.dat',b['card_binding']['parameter_card_sha256']);match(proc/'check',b['executable_sha256'])
        assert not (proc/'worker-protocol.fifo').exists()
        expected={**b['runtime']['files'],str(proc/'check'):b['executable_sha256']};assert len(expected)==16
        for edge in ('before','after'):
            m=read(report/('maps-'+edge+'.json'));assert m['ELF_files']==expected
            paths={line.split(None,5)[5]:line.split()[1] for line in m['maps'].splitlines() if len(line.split(None,5))==6 and line.split(None,5)[5].startswith('/')}
            assert set(paths)==set(expected)|set(m['readonly_locale_data']) and not any(n.endswith(' (deleted)') for n in paths)
            for n,h in expected.items():
                match(n,h)
                with Path(n).open('rb') as f:assert f.read(4)==b'\x7fELF'
            for n,h in m['readonly_locale_data'].items():
                match(n,h);assert n.startswith('/nix/store/') and n.endswith('/lib/locale/locale-archive') and paths[n]=='r--p'
                with Path(n).open('rb') as f:assert f.read(4)!=b'\x7fELF'
        process=read(report/'process.json');assert process['affinity']==[12] and not process['cpu_exclusive']
        assert any(x['pid']==process['pid'] and x['start_time_ticks']==process['identity']['start_time_ticks'] for x in terminal['cleanup']['observed_owned_processes'])
        assert not re.search(r'##W03\b',(report/'worker.log').read_text(),re.I)
        ready[name]=read(report/'ready.json');warm=read(report/'warmup.json');assert ready[name]['cold_seconds']==warm['cold_seconds']
        groups=[]
        for line in (proc/'warmup.dat').read_text().splitlines():
            if not line.strip() or line.lstrip().startswith('#'):continue
            fields=line.split();assert len(fields)==9;call=int(fields[0])
            if not groups or groups[-1][0]!=call:
                assert not groups or call>groups[-1][0];groups.append((call,[]))
            groups[-1][1].append(fields)
        window=[g for g in groups if g[0]>0][-100:];assert len(window)==100
        assert [g[0] for g in window]==list(range(window[0][0],window[0][0]+100))
        rows=[];usage=Counter()
        for call,entries in window:
            assert sorted(int(x[2]) for x in entries)==[0,1] and len({x[3] for x in entries})==1
            code=int(entries[0][3]);assert code in (219,323);usage[code]+=1
            for f in entries:
                point,order=int(f[1]),int(f[2]);assert point==1+(call-1)%100
                values=list(map(float,f[4:9]));assert all(math.isfinite(x) for x in values) and values[-1]>=0
                rows.append({'point':point,'order':order,'status':code,'coefficients':values[:4],'accuracy':values[4],'actual_backend':9,'precision':'DP' if code==219 else 'QP'})
        rows.sort(key=lambda x:(x['point'],x['order']));assert rows==warm['rows']==expected_warm['rows'] and usage=={219:87,323:13}
        assert warm['raw_outputs']=={n:(proc/n).read_text() for n in ('warmup.dat','dimensions.dat')}
        warm_counts[name]=dict(usage);mapping_receipts[name]={'before':digest(report/'maps-before.json'),'after':digest(report/'maps-after.json'),'executable_sha256':b['executable_sha256'],'ELF_files_each':16}
        raw[name]={}
        for point in (1,16):
            for label in ('calibration1','calibration2',*[f'pair{i}' for i in range(1,8)]):
                key=f'p{point}-{label}';q=report/key;cmd=read(q/'command.json');resp=read(q/'response.json')
                assert cmd['expected_response']==resp['response']
                for f,h in resp['files'].items():match(q/f,h)
                raw[name][key]={'texts':[(q/f).read_text() for f in ('anchor-timing.dat','anchor-words.dat','anchor-status.dat')], 'measurement':read(q/'measurement.json'),'command':cmd,'response':resp}
                commands.append((datetime.fromisoformat(cmd['before_utc']),datetime.fromisoformat(resp['after_utc']),name,key))
    blocked=[];saved=[]
    def deny(*a,**kw):blocked.append(str(a[:2]));raise RuntimeError('Forbidden API during timing replay')
    try:
        for obj,n in ((builtins,'open'),(io,'open'),(io,'open_code'),(os,'open'),(os,'system'),(os,'popen'),(subprocess,'Popen'),(subprocess,'run'),(subprocess,'call'),(subprocess,'check_call'),(subprocess,'check_output'),(ctypes,'CDLL'),(ctypes,'PyDLL'),(ctypes.cdll,'LoadLibrary'),(ctypes.pydll,'LoadLibrary')):
            saved.append((obj,n,getattr(obj,n)));setattr(obj,n,deny)
        sequence={'original':0,'candidate':0};expected_order=[];measurements={};total_calls=0;independent={}
        def measure(name,point,loops,label):
            nonlocal total_calls
            sequence[name]+=1;seq=sequence[name];key=f'p{point}-{label}';r=raw[name][key];expected_order.append((name,key))
            assert r['command']['command']==f'ANCHORRUN {seq} {point} {loops}'
            assert r['response']['response']==['ANCHORDONE',str(seq),str(point),str(loops)]
            m=analyzer['parse_timing'](*r['texts'],ready[name],seq,point,loops)
            reference=parity['variants']['original-parity']['observations']['values']['1' if point==1 else '2']
            assert m['last_output']['ans_words']==reference['ans_words'] and m['last_output']['status']==reference['status']
            m['accuracy_differs_from_earlier_parity_anchor']=m['last_output']['accuracy_words']!=reference['accuracy_words']
            assert not m['accuracy_differs_from_earlier_parity_anchor'] and canon(m)==r['measurement']
            fields=r['texts'][0].splitlines()[1].split();assert fields[0]=='TIMING'
            ints=list(map(int,fields[1:]));assert ints[:3]==[seq,point,loops]
            seconds=Fraction(ints[4]-ints[3],ints[5]);assert seconds>0 and float(seconds)==m['seconds']
            total_calls+=loops;measurements[(name,key)]=(m,seconds);return m
        for point in (1,16):
            a=result['anchors'][str(point)];first={n:measure(n,point,1,'calibration1') for n in ('original','candidate')}
            pilot=min(1000000,max(1,math.ceil(1/max(measurements[(n,f'p{point}-calibration1')][1] for n in ('original','candidate')))))
            assert pilot==a['pilot_loops'];second={n:measure(n,point,pilot,'calibration2') for n in ('candidate','original')}
            loops=min(1000000,max(1,math.ceil(1/min(measurements[(n,f'p{point}-calibration2')][1]/pilot for n in ('original','candidate')))))
            assert loops==a['fixed_loops'];pairs=[];ratios=[]
            for i in range(7):
                order=['original','candidate'] if i%2==0 else ['candidate','original'];pair={'order':order}
                for n in order:pair[n]=measure(n,point,loops,f'pair{i+1}')
                assert pair['original']['last_output']==pair['candidate']['last_output'];pairs.append(pair)
                ratios.append(measurements[('candidate',f'p{point}-pair{i+1}')][1]/measurements[('original',f'p{point}-pair{i+1}')][1])
            assert canon(first)==a['calibration1'] and canon(second)==a['calibration2'] and canon(pairs)==a['pairs']
            assert analyzer['summarize_pairs'](pairs)==a['summary']
            summary={'fixed_loops':loops,'pilot_loops':pilot,'median_paired_ratio':float(statistics.median(ratios)),
                'ratio_min':float(min(ratios)),'ratio_max':float(max(ratios))}
            assert math.isclose(summary['median_paired_ratio'],a['summary']['median_paired_ratio'],rel_tol=2e-16)
            for n in ('original','candidate'):
                samples=[measurements[(n,f'p{point}-pair{i}')][1]/loops for i in range(1,8)]
                med=statistics.median(samples);mad=statistics.median(abs(x-med) for x in samples)
                summary[n]={'median_seconds_per_call':float(med),'unscaled_MAD_seconds_per_call':float(mad)}
                assert math.isclose(float(med),a['summary'][n]['median_seconds_per_call'],rel_tol=3e-16)
                assert math.isclose(float(mad),a['summary'][n]['unscaled_MAD_seconds_per_call'],rel_tol=1e-12)
            independent[str(point)]=summary
        assert sequence=={'original':18,'candidate':18} and total_calls==260
        ordered=sorted(commands);assert [(x[2],x[3]) for x in ordered]==expected_order
        assert all(x[1]<=y[0] for x,y in zip(ordered,ordered[1:])) and not blocked
    finally:
        for obj,n,value in reversed(saved):setattr(obj,n,value)
    match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    receipt={'schema':'independent-physical-bulk-targeted-timing-audit-v1','status':'pass','source_index_sha256':SOURCE,
        'build_terminal_sha256':BUILD,'parity_terminal_sha256':PARITY,'timing_terminal_sha256':TERMINAL,'timing_result_sha256':RESULT,
        'elapsed_seconds':elapsed,'cap_seconds':480,'cleanup_reserve_seconds':60,'recorded_cleanup_survivors':0,
        'protected_bindings_verified':3539,'warmup_points_each':100,'warmup_status_counts':warm_counts,
        'native_batches':36,'native_post_learning_calls_including_calibration':260,'pairs_each_anchor':7,
        'chronological_order_exact':True,'common_calibrations_and_fixed_counts_rederived':True,'raw_parser_results_exact':True,
        'matched_history_coefficient_accuracy_status_words_exact':True,'accuracy_drift_from_earlier_parity':0,
        'independent_integer_clock_fraction_statistics':independent,'runtime':mapping_receipts,
        'W03_actual_console_records':0,'forbidden_API_attempts':len(blocked),'candidate_promoted':False,
        'performance_acceptance':False,'scope':'Targeted two-anchor shared-host timings; 7 ratios vary above and below 1; no persuasive useful improvement, no full-process or baseline-chain qualification.',
        'audit_native_calls':0,'audit_compiler_calls':0,'audit_loader_calls':0,'audit_source_sha256':digest(Path(__file__)),
        'distinct_resolved_files_live_hashed':len(seen),'distinct_resolved_bytes_live_hashed':sum(x[0][2] for x in seen.values()),
        'audit_elapsed_seconds':time.monotonic()-start}
    out=HERE/'receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'pass','receipt':str(out),'sha256':digest(out),'ratios':{n:x['median_paired_ratio'] for n,x in independent.items()},'elapsed':receipt['audit_elapsed_seconds']},sort_keys=True))

if __name__=='__main__':main()
