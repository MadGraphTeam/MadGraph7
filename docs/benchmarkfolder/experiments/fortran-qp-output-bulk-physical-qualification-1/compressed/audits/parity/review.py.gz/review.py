"""Independent closed physical PARITY replay; native/process APIs prohibited."""
import ast,builtins,ctypes,hashlib,io,json,math,os,re,statistics,struct,subprocess,time,types
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SRC=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-proposal-1'
WORK=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-work-1'
HERE=Path(__file__).resolve().parent
SOURCE='8e19ec4f1e422e5022cb3161cfe248bbc3a11cc6a2e3912e3693718ccea571ce'
BUILD='5fe62f2983e1c80e919fb404d167f1cbce2e004a1a89bab06c465d01860c932c'
TERMINAL='f2623135240aab116af97f27eb09cf64d8a8f30c44db91852f471411d237c656'
RESULT='7e92b0a425df73fd3f9bec5f1c2210ab4decd60fc40c8208728a33db7518dbc1'
PROC='SubProcesses/P0_uux_zgg'
seen={}
def digest(path):
    p=Path(path).resolve();s=p.stat();key=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if str(p) not in seen:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
        seen[str(p)]=(key,h.hexdigest())
    assert seen[str(p)][0]==key
    return seen[str(p)][1]
def match(p,h):assert digest(p)==h,str(p)
def read(p):return json.loads(Path(p).read_text())

class MemoryFile:
    def __init__(self,text):self.text=text
    def is_file(self):return True
    def open(self,*a,**kw):return io.StringIO(self.text)
class MemoryDirectory:
    def __init__(self,data):self.data=data
    def __truediv__(self,name):return MemoryFile(self.data[name])

def main():
    start=time.monotonic();p=WORK/'parity';match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT)
    match(SRC/'source-index.json',SOURCE);match(WORK/'build/terminal.json',BUILD)
    seal=read(SRC/'source-index.json');pin=read(SRC/'input-pins.json')
    for n,w in seal['files'].items():match(SRC/n,w['sha256'])
    terminal=read(p/'terminal.json');result=read(p/'result.json');bt=read(WORK/'build/terminal.json')
    match(WORK/'build/result.json',bt['result_sha256']);built=read(WORK/'build/result.json')
    assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
    assert terminal['result_sha256']==RESULT and result['source_index_sha256']==SOURCE and result['reviewed_build_sha256']==BUILD
    assert result['status']=='passed' and not result['candidate_promoted'] and not result['performance_acceptance']
    elapsed=(datetime.fromisoformat(terminal['finished_utc'])-datetime.fromisoformat(terminal['started_utc'])).total_seconds()
    assert elapsed<600 and terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60
    assert read(p/'limits.json')['actual']['address_space_bytes']==[16*1024**3]*2
    admission=read(p/'admission.json');assert admission['command']==terminal['command']
    assert admission['source_index_sha256']==SOURCE and admission['reviewed_build_sha256']==BUILD
    assert result['full_learning_points']==300 and result['post_learning_physical_calls']==306
    variants=('original-parity','candidate-parity','wire-parity');assert set(result['variants'])==set(variants)
    for n,h in pin['files'].items():
        q=Path(n) if Path(n).is_absolute() else ROOT/n
        if h is None:
            assert not q.exists() and (str(q.readlink()) if q.is_symlink() else None)==pin['null_symlink_targets'].get(n)
        else:match(q,h)
    match(pin['point_path'],pin['point_sha256'])
    raw={};runtime={};counts={}
    for v in variants:
        row=result['variants'][v];report=p/v;export=report/'export';proc=export/PROC;b=built['executables'][v]
        actual={str(q.relative_to(report)) for q in report.rglob('*') if q.is_file() and 'export' not in q.relative_to(report).parts}
        assert actual==set(row['raw_files'])
        for n,w in row['raw_files'].items():
            q=report/n;assert q.stat().st_size==w['bytes'];match(q,w['sha256'])
        assert read(report/'ready.json')==row['initialization']
        assert row['card_binding']==b['card_binding']
        for n,h in row['card_binding']['numerical_cards'].items():match(export/n,h)
        match(export/'Cards/param_card.dat',row['card_binding']['parameter_card_sha256'])
        for n,h in b['sources'].items():match(export/n,h)
        for n,h in b['objects'].items():match(export/n,h)
        for n,h in pin['original_objects'].items():
            if n!=PROC+'/check_sa.o':match(export/n,h)
        exe=proc/'check';match(exe,b['executable_sha256']);assert not (proc/'worker-protocol.fifo').exists()
        expected={**b['runtime']['files'],str(exe):b['executable_sha256']};assert len(expected)==16
        for edge in ('before','after'):
            m=read(report/('maps-'+edge+'.json'));assert m['ELF_files']==expected
            paths={line.split(None,5)[5]:line.split()[1] for line in m['maps'].splitlines() if len(line.split(None,5))==6 and line.split(None,5)[5].startswith('/')}
            assert not any(n.endswith(' (deleted)') for n in paths)
            assert set(paths)==set(expected)|set(m['readonly_locale_data'])
            for n,h in expected.items():
                match(n,h)
                with Path(n).open('rb') as f:assert f.read(4)==b'\x7fELF'
            for n,h in m['readonly_locale_data'].items():
                assert n.startswith('/nix/store/') and n.endswith('/lib/locale/locale-archive') and paths[n]=='r--p';match(n,h)
                with Path(n).open('rb') as f:assert f.read(4)!=b'\x7fELF'
        process=read(report/'process.json');assert process['affinity']==[12] and not process['cpu_exclusive']
        assert any(x['pid']==process['pid'] and x['start_time_ticks']==process['identity']['start_time_ticks'] for x in terminal['cleanup']['observed_owned_processes'])
        command=read(report/'parity/command.json');response=read(report/'parity/response.json')
        assert command['command']=='PARITY 1' and command['expected_response']==response['response']==['PARITYDONE','1']
        for n,h in response['files'].items():match(report/'parity'/n,h);assert (report/'parity'/n).read_bytes()==(proc/n).read_bytes()
        stdout=(report/'worker.log').read_text();assert not re.search(r'##W03\b',stdout,re.I)
        raw[v]={'words':(report/'parity/parity-words.dat').read_text(),'ieee':(report/'parity/parity-ieee.dat').read_text(),
            'warmup':read(report/'warmup.json'),'warmup_files':{n:(proc/n).read_text() for n in ('warmup.dat','dimensions.dat')}}
        if v=='wire-parity':
            raw[v]['wire']=(report/'real-wire.hex').read_text();raw[v]['health']=(report/'wire-health.dat').read_text()
            assert (proc/'real-wire.hex').read_bytes()==(report/'real-wire.hex').read_bytes()
            assert (proc/'wire-health.dat').read_bytes()==(report/'wire-health.dat').read_bytes()
        runtime[v]={'executable_sha256':b['executable_sha256'],'ELF_mappings_each_edge':16,'library_providers':15,
            'maps_before_sha256':digest(report/'maps-before.json'),'maps_after_sha256':digest(report/'maps-after.json'),
            'readonly_locale_data':read(report/'maps-before.json')['readonly_locale_data'],'raw_files':len(actual),
            'W03_console_records':0,'pid':process['pid']}
    # Only pure status decoder + warmup parser definitions are selected; never
    # instantiate/import the worker or an owning controller.
    worker_tree=ast.parse((ROOT/'tools/tirust_benchmark_worker.py').read_bytes())
    worker_tree.body=[n for n in worker_tree.body if isinstance(n,ast.ClassDef) and n.name=='MeasurementError' or isinstance(n,ast.FunctionDef) and n.name=='validate_status' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BACKEND_CODES' for t in n.targets)]
    wn={};exec(compile(worker_tree,'sealed-worker-pure-status','exec'),wn);worker=types.SimpleNamespace(**wn)
    warm_tree=ast.parse((ROOT/'tools/tirust_benchmark_warmup.py').read_bytes())
    warm_tree.body=[n for n in warm_tree.body if isinstance(n,ast.FunctionDef)]
    warm={'math':math,'worker':worker,'MeasurementError':worker.MeasurementError,'Path':lambda x:x}
    exec(compile(warm_tree,'sealed-warmup-pure-definitions','exec'),warm)
    analyzer={};exec(compile((SRC/'analyze.py').read_bytes(),str(SRC/'analyze.py'),'exec'),analyzer)
    expected_warm=read(SRC/'expected-warmup.json');expected_anchors=read(SRC/'expected.json')['rows']
    blocked=[];saved=[]
    def deny(*a,**k):blocked.append(repr(a[:2]));raise RuntimeError('Forbidden API in parity replay')
    def swap(obj,name):saved.append((obj,name,getattr(obj,name)));setattr(obj,name,deny)
    try:
        for obj,name in ((builtins,'open'),(io,'open'),(io,'open_code'),(os,'open'),(os,'system'),(os,'popen'),
            (subprocess,'Popen'),(subprocess,'run'),(subprocess,'call'),(subprocess,'check_call'),(subprocess,'check_output'),
            (ctypes,'CDLL'),(ctypes,'PyDLL'),(ctypes.cdll,'LoadLibrary'),(ctypes.pydll,'LoadLibrary')):swap(obj,name)
        for name in ('fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'):
            if hasattr(os,name):swap(os,name)
        previous=None
        for v in variants:
            ready=result['variants'][v]['initialization'];value=analyzer['parse_parity'](raw[v]['words'],raw[v]['ieee'],ready)
            assert value==result['variants'][v]['observations']
            analyzer['closed_anchor_words'](expected_anchors,value)
            if previous is not None:analyzer['compare_parity'](previous,value)
            previous=value
            learned=warm['parse_warmup'](MemoryDirectory(raw[v]['warmup_files']),9,100,ready)
            assert learned==raw[v]['warmup'] and learned['rows']==expected_warm['rows']
            status=Counter(x['status'] for x in value['values'].values());assert status=={219:88,323:14}
            assert learned['status_counts']=={'219':87,'323':13}
            direct_words=Counter(line.split()[0] for line in raw[v]['words'].splitlines() if line.strip())
            direct_ieee=Counter(line.split()[0] for line in raw[v]['ieee'].splitlines() if line.strip())
            assert direct_words=={'META':1,'ANS':816,'ACC':204} and direct_ieee=={'META':1,'IEEE':204}
            counts[v]={'learning_points':100,'warmup_first_call':learned['warmup_first_call'],'warmup_last_call':learned['warmup_last_call'],
                'learning_status_counts':learned['status_counts'],'post_learning_status_counts':dict(status),
                'post_learning_calls':102,'amplitude_REAL8_words':816,'accuracy_REAL8_words':204,'IEEE_edge_records':204,
                'IEEE_states':dict(Counter(str(edge) for pair in value['ieee'].values() for edge in pair))}
        wire=analyzer['parse_wire'](raw['wire-parity']['wire'],raw['wire-parity']['health'])
        assert wire==result['variants']['wire-parity']['wire']
        assert wire['native_QP_calls']==wire['successful_native_QP_calls']==wire['whole_batch_eligible']==3248
        assert wire['raw_records']==818720
        # Independent raw metadata counting, without the retained parser.
        direct=Counter();statuses=Counter();shapes=Counter();flags=Counter();check=Counter();cache=Counter()
        for line in io.StringIO(raw['wire-parity']['wire']):
            if line.startswith('CALL '):
                w=list(map(int,line.split()[1:]));direct['CALL']+=1;statuses[w[7]]+=1;shapes[str((w[1],w[2]))]+=1;flags[w[-1]]+=1;check[w[5]]+=1;cache[w[6]]+=1
            elif line.startswith('RECORD '):direct['RECORD']+=1
            elif line.startswith('END '):direct['END']+=1
        assert direct=={'CALL':3248,'RECORD':818720,'END':3248} and statuses=={0:3248}
        assert not blocked
    finally:
        for obj,name,value in reversed(saved):setattr(obj,name,value)
    match(p/'terminal.json',TERMINAL);match(p/'result.json',RESULT);match(SRC/'source-index.json',SOURCE)
    receipt={'schema':'independent-physical-bulk-QP-parity-audit-v1','status':'pass','source_index_sha256':SOURCE,
        'reviewed_build_terminal_sha256':BUILD,'parity_terminal_sha256':TERMINAL,'parity_result_sha256':RESULT,
        'closed_elapsed_seconds':elapsed,'cap_seconds':600,'cleanup_reserve_seconds':60,'recorded_cleanup_survivors':0,
        'protected_input_bindings_verified':3539,'variants':counts,'runtime':runtime,'exact_four_component_accuracy_status_IEEE_parity':True,
        'raw_wire_counts':dict(direct),'wire_native_status_counts':dict(statuses),'wire_shapes':dict(shapes),
        'wire_sticky_flags':dict(flags),'wire_check_flags':dict(check),'wire_cache_flags':dict(cache),
        'potential_candidate_bulk_batches':3248,'actual_candidate_branch_count_qualified':False,
        'forbidden_API_attempts':len(blocked),'pure_raw_replay_exact':True,'W03_actual_console_records':0,
        'distinct_resolved_files_live_hashed':len(seen),'distinct_resolved_bytes_live_hashed':sum(x[0][2] for x in seen.values()),
        'timing_prerequisite_barrier_clear':True,'timing_executed_by_audit':False,'candidate_promoted':False,
        'performance_acceptance':False,'audit_compiler_calls':0,'audit_loader_calls':0,'audit_reducer_or_amplitude_calls':0,
        'input_scope':'Pinned saved100 input file plus source-bound worker argument; no separate per-call internal kinematics capture or /proc command-line receipt.',
        'audit_source_sha256':digest(Path(__file__)),'audit_elapsed_seconds':time.monotonic()-start}
    out=HERE/'receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'pass','receipt':str(out),'sha256':digest(out),'elapsed':receipt['audit_elapsed_seconds']},sort_keys=True))

if __name__=='__main__':main()
