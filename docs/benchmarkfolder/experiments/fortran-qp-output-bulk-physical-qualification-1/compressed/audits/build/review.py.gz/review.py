"""Read/hash-only audit of closed physical decoder BUILD; never execute ELF."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import struct
import time
import types

ROOT=Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
SRC=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-proposal-1'
BUILD=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-work-1/build'
HERE=Path(__file__).resolve().parent
SOURCE='8e19ec4f1e422e5022cb3161cfe248bbc3a11cc6a2e3912e3693718ccea571ce'
TERMINAL='5fe62f2983e1c80e919fb404d167f1cbce2e004a1a89bab06c465d01860c932c'
RESULT='933bb657609b6fda31f800b10da0b9e9248e05dcd745bbed8158384b39cc0b12'
PROC='SubProcesses/P0_uux_zgg'
VARIANTS={'original-parity','candidate-parity','wire-parity','original-timing','candidate-timing'}
seen={}

def digest(path):
    path=Path(path).resolve();s=path.stat();key=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if str(path) not in seen:
        h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
        seen[str(path)]=(key,h.hexdigest())
    assert seen[str(path)][0]==key,('changed during audit',str(path))
    return seen[str(path)][1]

def read(path):return json.loads(Path(path).read_text())
def match(path,want):assert digest(path)==want,str(path)

def interpreter(path):
    b=Path(path).read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
    offset=struct.unpack_from('<Q',b,32)[0];size,count=struct.unpack_from('<HH',b,54)
    found=[]
    for i in range(count):
        row=offset+i*size
        if struct.unpack_from('<I',b,row)[0]==3:
            start=struct.unpack_from('<Q',b,row+8)[0];n=struct.unpack_from('<Q',b,row+32)[0]
            found.append(b[start:start+n].rstrip(b'\0').decode())
    assert len(found)==1
    return found[0]

def mp_relocations(path):
    b=Path(path).read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
    off=struct.unpack_from('<Q',b,40)[0];size,count,names=struct.unpack_from('<HHH',b,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(count)]
    ns=sections[names];strings=b[ns[4]:ns[4]+ns[5]]
    def z(s,i):return s[i:s.index(0,i)].decode()
    found=[]
    for sec in sections:
        if sec[1]!=4:continue
        sym=sections[sec[6]];st=sections[sym[6]];ss=b[st[4]:st[4]+st[5]]
        for pos in range(sec[4],sec[4]+sec[5],sec[9]):
            where,info,addend=struct.unpack_from('<QQq',b,pos);symbol=info>>32;kind=info&0xffffffff
            name,_,_,shndx,_,_=struct.unpack_from('<IBBHQQ',b,sym[4]+symbol*sym[9])
            if z(ss,name)=='ml_tirust_evaluate_mp':
                assert shndx==0 and kind==4
                found.append({'section':z(strings,sections[sec[7]][0]),'type':'R_X86_64_PLT32','offset':where})
    assert found
    return found

def main():
    started=time.monotonic();match(SRC/'source-index.json',SOURCE);seal=read(SRC/'source-index.json')
    assert {str(p.relative_to(SRC)) for p in SRC.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'}
    for name,item in seal['files'].items():
        p=SRC/name;assert not p.is_symlink() and p.stat().st_size==item['bytes'];p.read_bytes().decode('utf8');match(p,item['sha256'])
    match(BUILD/'terminal.json',TERMINAL);match(BUILD/'result.json',RESULT)
    terminal=read(BUILD/'terminal.json');result=read(BUILD/'result.json');pin=read(SRC/'input-pins.json')
    assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
    assert terminal['result_sha256']==RESULT and terminal['phase']=='build'
    duration=(datetime.fromisoformat(terminal['finished_utc'])-datetime.fromisoformat(terminal['started_utc'])).total_seconds()
    assert duration<terminal['cap_seconds'] and terminal['cap_seconds']==300 and terminal['cleanup_reserve_seconds']==60
    assert result['status']=='passed' and result['source_index_sha256']==SOURCE
    assert result['Rust_builds']==result['native_amplitude_calls']==0 and result['reused_numerical_objects']
    assert set(result['executables'])==VARIANTS
    assert result['protected']['input_pins_sha256']==digest(SRC/'input-pins.json')
    assert result['protected']['files']==len(pin['files'])==3539
    absences=[]
    for name,want in pin['files'].items():
        path=Path(name) if Path(name).is_absolute() else ROOT/name
        if want is None:
            assert not path.exists()
            assert (str(path.readlink()) if path.is_symlink() else None)==pin['null_symlink_targets'].get(name)
            absences.append(name)
        else:match(path,want)
    case=Path(pin['case_path'])
    for name,h in pin['original_sources'].items():match(case/name,h)
    for name,h in pin['original_objects'].items():match(case/name,h)
    assert len(pin['original_sources'])==195 and len(pin['original_objects'])==144

    logs=BUILD/'commands';commands={};intervals=[]
    expected={'compiler-version'}
    for variant in VARIANTS:
        expected|={variant+'-'+n for n in ('expanded','mtirust.f90-compile','check_sa.f-compile','link','actual-pt-interp-runtime','module-symbols','executable-symbols')}
        expected|={variant+'-prelink-query-'+str(i).zfill(3) for i in range(51)}
    expected.add('wire-parity-wire-compile')
    assert len(expected)==292
    assert {p.name for p in logs.iterdir()}=={n+s for n in expected for s in ('.command.json','.terminal.json','.stdout.txt')}
    for label in sorted(expected):
        c=read(logs/(label+'.command.json'));t=read(logs/(label+'.terminal.json'))
        assert c['argv']==t['argv'] and c['cwd']==t['cwd'] and c['started_utc']==t['started_utc']
        assert t['returncode']==0 and not c['subprocess_new_session'] and c['timeout_seconds'] is None
        match(logs/(label+'.stdout.txt'),t['stdout_sha256'])
        a,z=map(datetime.fromisoformat,(c['started_utc'],t['finished_utc']))
        assert a<=z and a>=datetime.fromisoformat(terminal['started_utc']) and z<=datetime.fromisoformat(terminal['finished_utc'])
        intervals.append((a,z,label));commands[label]=c
    intervals.sort()
    assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:])), 'Nonserial command overlap'

    helpers=types.ModuleType('closed_build_pure_helpers')
    exec(compile((SRC/'build_helpers.py').read_bytes(),str(SRC/'build_helpers.py'),'exec'),helpers.__dict__)
    exe_rows={};shared_runtime=pin['expected_runtime'];assert len(shared_runtime)==15
    for variant,row in result['executables'].items():
        output=Path(row['path']);proc=output/PROC;wire=variant=='wire-parity'
        assert output==BUILD/variant
        match(proc/'check',row['executable_sha256']);match(proc/'prelink.json',row['prelink_sha256']);match(proc/'private-link.map',row['link_map_sha256'])
        module='candidate' if variant.startswith('candidate') else 'original'
        driver='wire' if wire else 'timing' if variant.endswith('timing') else 'parity'
        assert (proc/'mtirust.f90').read_bytes()==(SRC/(module+'-mtirust.f90')).read_bytes()
        assert (proc/'check_sa.f').read_bytes()==(SRC/(driver+'-driver.f')).read_bytes()
        assert (proc/'makefile').read_text()==helpers.private_makefile((case/PROC/'makefile').read_text(),wire)
        if wire:assert (proc/'wire_capture.c').read_bytes()==(SRC/'wire_capture.c').read_bytes()
        suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
        sources={str(p.relative_to(output)):digest(p) for tree in ('Source','SubProcesses') for p in (output/tree).rglob('*') if p.is_file() and (p.suffix.lower() in suffixes or p.name.startswith('makefile') or p.name in ('make_opts','MadLoop_makefile_definitions'))}
        assert sources==row['sources']
        changed={n for n,h in sources.items() if h!=pin['original_sources'].get(n)}
        assert changed=={PROC+'/check_sa.f',PROC+'/makefile',PROC+'/mtirust.f90'}|({PROC+'/wire_capture.c'} if wire else set())
        assert not(set(pin['original_sources'])-set(sources))
        objs={str(p.relative_to(output)):digest(p) for p in output.rglob('*') if p.is_file() and p.suffix.lower() in ('.o','.mod','.a') and 'build-history' not in p.parts and 'worker-raw' not in p.parts}
        assert objs==row['objects']
        for n,h in pin['original_objects'].items():
            if n!=PROC+'/check_sa.o':match(output/n,h)
        for n,h in row['card_binding']['numerical_cards'].items():match(output/n,h)
        match(output/'Cards/param_card.dat',row['card_binding']['parameter_card_sha256'])
        expected_cards=dict(pin['expected_numerical_cards'])
        expected_cards[PROC+'/MadLoop5_resources/MadLoopParams.dat']=expected_cards['SubProcesses/MadLoop5_resources/MadLoopParams.dat']
        assert row['card_binding']['numerical_cards']==expected_cards
        assert row['card_binding']['parameter_card_sha256']==pin['expected_physical_card_sha256']
        pre=read(proc/'prelink.json');assert pre['completed_before_link'] and pre['explicit_frozen_runtime_before_link']==shared_runtime
        assert all(pre['bound'][n]==h for n,h in shared_runtime.items())
        for n,h in pre['bound'].items():match(n,h)
        maps=(proc/'private-link.map').read_text();loads={str((proc/s).resolve()):digest(proc/s) for s in re.findall(r'^LOAD\s+(.+)$',maps,re.M)}
        assert loads==row['actual_link_loads'] and all(pre['bound'].get(n)==h for n,h in loads.items())
        runtime=row['runtime'];assert runtime['files']==shared_runtime
        assert interpreter(proc/'check')==runtime['loader'] and pre['bound'][runtime['loader']]==runtime['loader_sha256']
        paths=set()
        for line in runtime['listing'].splitlines():
            line=line.strip()
            if re.fullmatch(r'linux-vdso\.so\.1\s+\(0x[0-9a-fA-F]+\)',line):continue
            m=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line);assert m,line
            paths.add(str(Path(m[1]).resolve()))
        assert paths==set(shared_runtime)
        listing_label=variant+'-actual-pt-interp-runtime'
        assert commands[listing_label]['argv']==[runtime['loader'],'--list',str(proc/'check')]
        assert (logs/(listing_label+'.stdout.txt')).read_text()==runtime['listing']
        symbols=helpers.verify_symbols((logs/(variant+'-module-symbols.stdout.txt')).read_text(),(logs/(variant+'-executable-symbols.stdout.txt')).read_text(),maps,wire)
        assert symbols==row['symbols']
        for name,argv in row['selected_recipes']:assert commands[variant+'-'+name+'-compile']['argv']==argv
        assert commands[variant+'-link']['argv']==row['link_command']==pre['command']
        assert commands[variant+'-expanded']['argv']==[pin['tools']['make'],'-n','-B','SHELL='+pin['tools']['make_shell'],'check']
        for query in pre['queries']:
            assert commands[variant+'-'+query['label']]['argv']==query['argv']
        assert len(pre['queries'])==51
        if wire:assert commands['wire-parity-wire-compile']['argv']==[pin['tools']['cc'],'-std=c99','-O0','-fPIC','-c','wire_capture.c','-o','wire_capture.o']
        relocations=mp_relocations(proc/'mtirust.o')
        exe_rows[variant]={'executable_sha256':row['executable_sha256'],'private_module_sha256':row['module_sha256'],
            'source_count':len(sources),'generated_object_inventory_count':len(objs),'unchanged_original_object_bindings':143,
            'actual_link_load_count':len(loads),'prebound_file_count':len(pre['bound']),'runtime_provider_count':15,
            'actual_PT_INTERP':runtime['loader'],'MP_external_relocations':relocations,
            'unique_private_module_symbols':len(symbols['definitions']),'wire_wrapper_definitions':symbols['wire_wrapper_definitions']}
    match(BUILD/'terminal.json',TERMINAL);match(BUILD/'result.json',RESULT);match(SRC/'source-index.json',SOURCE)
    receipt={'schema':'independent-physical-bulk-QP-build-audit-v1','status':'pass',
        'source_index_sha256':SOURCE,'build_terminal_sha256':TERMINAL,'build_result_sha256':RESULT,
        'source_payloads':29,'protected_input_bindings':3539,'protected_absences':absences,
        'closed_original_sources':195,'closed_original_objects_and_modules_and_archives':144,
        'successful_serial_tool_commands':292,'command_logs_sha256_verified':292,
        'build_elapsed_seconds':duration,'build_cap_seconds':300,'cleanup_reserve_seconds':60,
        'recorded_cleanup_survivors':0,'executables':exe_rows,
        'distinct_resolved_files_live_hashed':len(seen),'distinct_resolved_bytes_live_hashed':sum(v[0][2] for v in seen.values()),
        'runtime_scope':'Actual retained PT_INTERP --list and map/symbol receipts independently rejoined; all listed binaries/providers freshly byte-hashed; no loader run by audit.',
        'parity_source_boundary_clear':True,'parity_executed_or_qualified_by_audit':False,
        'audit_compiler_calls':0,'audit_loader_calls':0,'audit_reducer_or_amplitude_calls':0,
        'audit_source_sha256':digest(Path(__file__)),'audit_elapsed_seconds':time.monotonic()-started}
    out=HERE/'receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'receipt':str(out),'sha256':digest(out),'status':'pass','commands':292,'executables':5,'elapsed':receipt['audit_elapsed_seconds']},sort_keys=True))

if __name__=='__main__':main()
