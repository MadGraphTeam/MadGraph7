"""Freeze existing physical inputs and generate private source previews only.

No compiler, make, loader, model, Rust or amplitude command runs here. Tool
discovery is limited to finding make in the already frozen unit-test PATH.
The default command writes only the declared source/pin files in this folder;
--verify-only performs the same read-only binding without writing them.
"""
import argparse
import ast
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import types

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PROFILE_REL = "docs/benchmarkfolder/experiments/fortran-qp-transport-profile-qualification-1"
PROFILE_SHA = "4abe6049fea625c567c37668956f3a8d1db71222eb2575bbf13fd32617e087d2"
UNIT_REL = ".tirust-build/fortran-qp-output-bulk-unit-controller-2"
UNIT_SHA = "ad63b2e1128c70085fb282b1a74e1b84aa282c7e5be95514a79a558845817fe4"
UNIT_INPUT_SHA = "e89e90ee22198df44dc99f50db21e79dc7793694e15edd70a81f8f89fb52eeb8"
BULK_REL = ".tirust-build/fortran-qp-output-bulk-proposal-1"
BULK_SHA = "600fb55cae10c8f105998c6ae689c09992526765734f33036dd79936261f5150"
CASE_REL = (".benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/"
            "outputs/candidate/qcd_n3_uux_zgg")
PROC_REL = "SubProcesses/P0_uux_zgg"
DSO_SHA = "eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9"
LOADER_SHA = "4b8d035797b0ad742a0b0903228a20cc4bddca922146c4c5ea02ad4f3a011e55"
CLEANUP_REL = "docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py"
CLEANUP_SHA = "240d1067a7b7098f056f0f367097def8f374d7979c3001d249c8b1f7cb0bbd84"
MAKE_SHELL = "/nix/store/lw117lsr8d585xs63kx5k233impyrq7q-bash-5.3p3/bin/bash"
MAKE_SHELL_SHA = "03b13000ff5011a38d8a3f9575b6807d78cf9936c64a0be28f02abf9be8c9c25"


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def safe(name):
    require(isinstance(name, str) and name and "\\" not in name, "Invalid relative input name")
    p = PurePosixPath(name)
    require(not p.is_absolute() and ".." not in p.parts and str(p) == name, "Unsafe relative input name")
    return name


def merge(files, additions):
    for name, checksum in additions.items():
        require(checksum is None or isinstance(checksum, str) and len(checksum) == 64 and
                all(c in "0123456789abcdef" for c in checksum), "Invalid input checksum")
        require(name not in files or files[name] == checksum, "Conflicting frozen input: " + name)
        files[name] = checksum


def verify_index_payloads(index, read_bytes, index_name):
    names = list(index["files"])
    for name in names:
        safe(name)
        require(name != index_name, "Self-indexed source packet")
    for name, want in index["files"].items():
        raw = read_bytes(name)
        require(len(raw) == want["bytes"] and digest(raw) == want["sha256"],
                "Sealed source payload changed: " + name)


def validate_points(raw, nexternal=5):
    rows = raw.decode("ascii").splitlines()
    require(rows and rows[0].strip() == "100", "Exactly100 saved physical points required")
    require(len(rows) == 1 + 100*nexternal, "Saved point file dimensions changed")
    for row in rows[1:]:
        values = row.split()
        require(len(values) == 4, "Saved momentum must have four components")
        try:
            require(all(Decimal(value).is_finite() for value in values), "Nonfinite saved momentum")
        except InvalidOperation as error:
            raise ValueError("Invalid saved momentum") from error


def timing_plan():
    return {
        "schema": "madloop-tirust-bulk-physical-timing-plan-v1",
        "anchors": [1, 16], "target_seconds": 1.0, "max_loops": 1000000,
        "calibration_pairs": [
            {"id": "initial", "order": ["original", "candidate"], "loops": 1},
            {"id": "common-pilot", "order": ["candidate", "original"],
             "loops_rule": "min(max_loops,max(1,ceil(target_seconds/max(initial_elapsed_original,initial_elapsed_candidate))))"},
        ],
        "fixed_loops_rule": "min(max_loops,max(1,ceil(target_seconds/min(pilot_elapsed_original/pilot_loops,pilot_elapsed_candidate/pilot_loops))))",
        "timed_pairs": [{"pair": i+1, "order": (["original", "candidate"] if i % 2 == 0 else ["candidate", "original"])}
                        for i in range(7)],
        "calibration_policy": "Both variants use the same loop count within each calibration pair; no timing-selected reruns",
        "initialization": "Fresh workers with unchanged full100 learning; READY recorded separately",
        "point_cohort": "One fixed physical anchor per batch; all accepted timed statuses retained",
        "clock_scope": "Raw Fortran SYSTEM_CLOCK ticks around full amplitude loops and common integer status accounting",
        "partial_or_forced_QP": False, "performance_acceptance": False,
        "precision_policy": "Unchanged automatic independent stability/rescue; no fixed-QP substitution",
        "precise_acceptance": "Separate Hua-Sheng local campaign; shared-host observations descriptive",
    }


def _load_source(path):
    module = types.ModuleType("physical_source_" + path.stem)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


def _file_key(path, root):
    return str(path.relative_to(root)) if path.is_relative_to(root) else str(path)


def _pin_file(path, checksum, files, root):
    require(path.is_file(), "Missing protected input: " + str(path))
    require(digest(path.read_bytes()) == checksum, "Changed protected input: " + str(path))
    merge(files, {_file_key(path, root): checksum})


def verify_intentional_absence(path, declared_target=None):
    """Preserve declared dangling links; plain absence must remain unlinked."""
    require(not path.exists(), "Intentionally absent input appeared: " + str(path))
    if declared_target is None:
        require(not path.is_symlink(), "Undeclared dangling input link: " + str(path))
    else:
        require(path.is_symlink() and str(path.readlink()) == declared_target,
                "Declared dangling input link changed: " + str(path))


def pin_fixed_make_shell(files, root):
    """Bind the reviewed make SHELL override; no discovery or execution."""
    path = Path(MAKE_SHELL)
    _pin_file(path, MAKE_SHELL_SHA, files, root)
    return str(path)


def _packet(base, index_name, checksum, files, root):
    raw = (base/index_name).read_bytes()
    require(digest(raw) == checksum, "Changed preserved packet index: " + str(base))
    index = json.loads(raw)
    verify_index_payloads(index, lambda name: (base/name).read_bytes(), index_name)
    actual = {str(p.relative_to(base)) for p in base.rglob("*") if p.is_file()}
    require(actual == set(index["files"]) | {index_name}, "Preserved packet inventory changed")
    _pin_file(base/index_name, checksum, files, root)
    for name, meta in index["files"].items():
        _pin_file(base/name, meta["sha256"], files, root)
    return index


def generated_sources(case):
    suffixes = {".f", ".f90", ".for", ".inc", ".c", ".cc", ".h"}
    return {str(p.relative_to(case)): digest(p.read_bytes())
            for subtree in ("Source", "SubProcesses")
            for p in sorted((case/subtree).rglob("*"))
            if p.is_file() and (p.suffix.lower() in suffixes or p.name.startswith("makefile") or
                               p.name in {"make_opts", "MadLoop_makefile_definitions"})}


def collect_inputs(root=ROOT, here=HERE):
    """Read-only binding. Returned previews are bytes; nothing is published."""
    root, here = Path(root).absolute(), Path(here).absolute()
    files = {}
    profile, unit, bulk, case = (root/rel for rel in [PROFILE_REL, UNIT_REL, BULK_REL, CASE_REL])
    _packet(profile, "index.json", PROFILE_SHA, files, root)
    _packet(unit, "source-index.json", UNIT_SHA, files, root)
    _packet(bulk, "index.json", BULK_SHA, files, root)
    profile_pins = json.loads((profile/"controller3/input-pins.json").read_bytes())
    unit_raw = (unit/"input-pins.json").read_bytes()
    require(digest(unit_raw) == UNIT_INPUT_SHA, "Frozen GNU environment changed")
    unit_pins = json.loads(unit_raw)
    nulls = dict(profile_pins["null_symlink_targets"])
    for inherited in [profile_pins["files"], unit_pins["files"]]:
        for name, checksum in inherited.items():
            path = root/name if not Path(name).is_absolute() else Path(name)
            if checksum is None:
                verify_intentional_absence(path, nulls.get(name))
                merge(files, {_file_key(path, root): None})
            else:
                _pin_file(path, checksum, files, root)
    for name, target in nulls.items():
        path = root/safe(name)
        require(path.is_symlink() and not path.exists() and str(path.readlink()) == target,
                "Protected dangling symlink changed: " + name)
    compilation_raw = (case/"compilation.json").read_bytes()
    compilation = json.loads(compilation_raw)
    original = json.loads((profile/"original-candidate-inputs.json").read_bytes())
    require(compilation == original["compilation"], "Original numerical compilation differs")
    require(compilation["compiler"] == "GNU Fortran (GCC) 15.2.0", "Unqualified numerical compiler")
    require(generated_sources(case) == compilation["sources"], "Original generated source inventory changed")
    sources = dict(compilation["sources"])
    objects = dict(profile_pins["original_objects"])
    for items in [sources, objects]:
        for name, checksum in items.items():
            _pin_file(case/safe(name), checksum, files, root)
    numerical = dict(original["numerical_cards"])
    require(set(numerical) == {"Cards/MadLoopParams.dat", "SubProcesses/MadLoopParams.dat",
                              "SubProcesses/MadLoop5_resources/MadLoopParams.dat"}, "Numerical card paths changed")
    for name, checksum in numerical.items():
        _pin_file(case/name, checksum, files, root)
    physical = original["param_card_sha256"]
    _pin_file(case/"Cards/param_card.dat", physical, files, root)
    point_path = Path(original["points_path"])
    _pin_file(point_path, original["points_sha256"], files, root)
    validate_points(point_path.read_bytes())
    expected = json.loads((profile/"science/expected.json").read_bytes())
    require(expected["point_file"]["sha256"] == original["points_sha256"], "Anchor point cohort differs")
    warmup = json.loads((profile/"original-warmup-reference.json").read_bytes())
    require(warmup["warmup_call_point_order"] == [{"call": k, "point": k} for k in range(1,101)],
            "Original full100 warmup traversal differs")
    require({row["point"] for row in warmup["rows"]} == set(range(1,101)), "Original warmup reference is incomplete")
    runtime = json.loads((profile/"build2/build-result.json").read_bytes())["runtime"]["actual_pt_interp"]["files"]
    require(len(runtime) == 15, "Physical actual PT_INTERP closure changed")
    for name, checksum in runtime.items():
        _pin_file(Path(name), checksum, files, root)
    dsos = [name for name in runtime if Path(name).name == "libmadloop_tirust.so"]
    require(len(dsos) == 1 and runtime[dsos[0]] == DSO_SHA, "Original native TIRust provider changed")
    tools, environment = dict(unit_pins["tools"]), dict(unit_pins["environment"])
    make = shutil.which("make", path=environment["PATH"])
    require(make is not None, "make is absent from the frozen PATH")
    tools["make"] = str(Path(make).resolve())
    tools["make_shell"] = pin_fixed_make_shell(files, root)
    for path in tools.values():
        _pin_file(Path(path), digest(Path(path).read_bytes()), files, root)
    helper_names = ["tools/tirust_benchmark.py", "tools/tirust_benchmark_worker.py",
                    "tools/tirust_benchmark_warmup.py", "tools/tirust_benchmark_compiler.py",
                    "tools/tirust_benchmark_campaign.py", "tools/tirust_benchmark_worker.f"]
    for name in helper_names:
        _pin_file(root/name, digest((root/name).read_bytes()), files, root)
    loader_path = profile/"controller3/loader_checks.py"
    _pin_file(loader_path, LOADER_SHA, files, root)
    _pin_file(root/CLEANUP_REL, CLEANUP_SHA, files, root)
    tree = ast.parse(loader_path.read_bytes())
    assignments = [node for node in tree.body if isinstance(node, ast.Assign) and
                   any(isinstance(t, ast.Name) and t.id == "SUPPORT_PINS" for t in node.targets)]
    require(len(assignments) == 1, "Pinned loader support table is ambiguous")
    support = ast.literal_eval(assignments[0].value)
    support_root = root/"docs/benchmarkfolder/experiments/current-cms-replay-supervisor-1/ownership"
    for name, checksum in support.items():
        _pin_file(support_root/safe(name), checksum, files, root)
    for name in ["workers.py", "wire_driver.py", "build_helpers.py", "wire_capture.c", "prepare.py", "test_prepare.py"]:
        _pin_file(here/name, digest((here/name).read_bytes()), files, root)
    workers = _load_source(here/"workers.py")
    wire_driver = _load_source(here/"wire_driver.py")
    base = (case/PROC_REL/"check_sa.f").read_text()
    parity = workers.parity_driver(base)
    previews = {
        "original-mtirust.f90": (bulk/"original-mtirust.f90").read_bytes(),
        "candidate-mtirust.f90": (bulk/"candidate-mtirust.f90").read_bytes(),
        "parity-driver.f": parity.encode(),
        "timing-driver.f": workers.timings_driver(base).encode(),
        "wire-driver.f": wire_driver.observer_driver(parity).encode(),
        "expected.json": (profile/"science/expected.json").read_bytes(),
        "expected-warmup.json": (profile/"original-warmup-reference.json").read_bytes(),
        "timing-plan.json": encoded(timing_plan()),
    }
    pins = {
        "schema": "madloop-tirust-bulk-physical-inputs-v1", "files": files,
        "null_symlink_targets": nulls, "tools": tools, "environment": environment,
        "original_sources": sources, "original_objects": objects, "expected_runtime": runtime,
        "expected_numerical_cards": numerical, "expected_physical_card_sha256": physical,
        "expected_profile_settings": profile_pins["expected_settings"],
        "case_compilation_sha256": digest(compilation_raw), "case_path": str(case),
        "point_path": str(point_path), "point_sha256": original["points_sha256"],
        "dso_path": dsos[0], "dso_sha256": DSO_SHA, "profile_index_sha256": PROFILE_SHA,
        "unit_source_index_sha256": UNIT_SHA, "unit_input_sha256": UNIT_INPUT_SHA,
        "bulk_proposal_index_sha256": BULK_SHA,
        "generated_inputs": {name: {"bytes": len(raw), "sha256": digest(raw)} for name, raw in previews.items()},
        "compiler_executions": 0, "native_executions": 0, "production_changes": False,
    }
    return pins, previews


def write_new(path, raw):
    require(not path.is_symlink(), "Refusing a symlink output")
    if path.exists():
        require(path.is_file() and path.read_bytes() == raw, "Refusing an unrecorded source replacement: " + str(path))
    else:
        with path.open("xb") as stream:
            stream.write(raw)


def prepare(root=ROOT, here=HERE, verify_only=False):
    pins, previews = collect_inputs(root, here)
    if not verify_only:
        for name, raw in previews.items():
            write_new(Path(here)/name, raw)
        write_new(Path(here)/"input-pins.json", encoded(pins))
    return {"status": "source-only-inputs-verified", "input_pins_sha256": digest(encoded(pins)),
            "protected_files": len(pins["files"]), "original_sources": len(pins["original_sources"]),
            "original_objects": len(pins["original_objects"]), "actual_runtime_files": len(pins["expected_runtime"]),
            "generated_sources_written": 0 if verify_only else len(previews),
            "compiler_executions": 0, "native_executions": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare(verify_only=args.verify_only), sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
