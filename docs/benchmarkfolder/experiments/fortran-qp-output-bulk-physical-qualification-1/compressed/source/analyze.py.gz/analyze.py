"""Pure physical driver/real-wire parsers and predeclared paired statistics."""
import math
import re
import statistics
import struct


def require(value,message):
    if not value:raise ValueError(message)


def finite_word(value):
    require(re.fullmatch('[0-9A-Fa-f]{16}',value) is not None,'Malformed REAL8 word')
    bits=int(value,16)
    require((bits>>52)&0x7ff!=0x7ff,'Nonfinite public amplitude/accuracy')
    return value.lower()


def stable9(code):
    require(isinstance(code,int) and code>=0,'Invalid public status')
    h,t,u=code//100,code//10%10,code%10
    require(t in (1,2) and (h,u) in ((2,9),(3,3)),'Output not a stable explicit TIRust9 result')
    return 'DP' if h==2 else 'QP'


def records(text):
    return [line.split() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]


def parse_words(text,meta,occurrences):
    rows=records(text);require(rows and rows[0]==['META',*map(str,meta)],'Word META differs')
    ndim,nso=meta[-3],meta[-2]
    entries={};cursor=1
    for occurrence,phase,point in occurrences:
        ans={};acc={};codes=set()
        for order in range(ndim+1):
            for component in range(4):
                require(cursor<len(rows),'Incomplete amplitude words')
                row=rows[cursor];cursor+=1
                require(len(row)==9 and row[0]=='ANS','Malformed ANS record')
                integers=list(map(int,row[1:8]))
                require(integers[:6]==[meta[0],occurrence,phase,point,order,component],'ANS sequence/layout differs')
                stable9(integers[6]);codes.add(integers[6]);ans[str(order)+':'+str(component)]=finite_word(row[8])
        for order in range(nso+1):
            require(cursor<len(rows),'Incomplete accuracy words')
            row=rows[cursor];cursor+=1
            require(len(row)==8 and row[0]=='ACC','Malformed ACC record')
            integers=list(map(int,row[1:7]))
            require(integers[:5]==[meta[0],occurrence,phase,point,order],'ACC sequence/layout differs')
            stable9(integers[5]);codes.add(integers[5]);acc[str(order)]=finite_word(row[7])
        require(len(codes)==1,'Split-order public status differs')
        entries[str(occurrence)]={'point':point,'phase':phase,'status':codes.pop(),'ans_words':ans,'accuracy_words':acc}
    require(cursor==len(rows),'Extra word records')
    return entries


def parse_parity(words,ieee,ready,sequence=1):
    require(ready['points']==100 and ready['ndim']==max(ready['nso'],ready['nborn']),'Wrong physical cohort/dimensions')
    meta=[sequence,100,ready['ndim'],ready['nso'],ready['nborn']]
    occurrences=[(1,1,1),(2,2,16)]+[(i+2,3,i) for i in range(1,101)]
    values=parse_words(words,meta,occurrences)
    require(values['1']['status']==219 and values['2']['status']==323,'Required native-DP/automatic-QP anchors changed')
    rows=records(ieee);require(rows and rows[0]==['META',*map(str,meta)],'IEEE META differs')
    states={};cursor=1
    for occurrence,phase,point in occurrences:
        pair=[]
        for edge in (0,1):
            require(cursor<len(rows),'Incomplete IEEE observations')
            row=rows[cursor];cursor+=1
            require(len(row)==17 and row[0]=='IEEE','Malformed IEEE record')
            ints=list(map(int,row[1:]));require(ints[:5]==[sequence,occurrence,phase,point,edge],'IEEE call identity differs')
            require(ints[5] in (-1,0,1,2,3,4) and all(x in (-1,0,1) for x in ints[6:]),'Invalid IEEE observation')
            pair.append(ints[5:])
        require(pair[0][0]==pair[1][0] and pair[0][6:]==pair[1][6:],'Amplitude changed rounding or halting modes')
        states[str(occurrence)]=pair
    require(cursor==len(rows),'Extra IEEE records')
    return {'sequence':sequence,'occurrences':102,'values':values,'ieee':states,
            'word_scope':'Exact public REAL8 amplitude/accuracy outputs after automatic rescue; not internal tensor/numerator words'}


def compare_parity(original,candidate):
    require(candidate==original,'Physical coefficient/accuracy/status/IEEE word parity failed')


def closed_anchor_words(expected_rows,parsed):
    """Compare the two retained closed-profile anchors, preserving order0/1."""
    rows=[]
    for occurrence in (1,2):
        row=parsed['values'][str(occurrence)]
        for order in range(2):
            words=[row['ans_words'][str(order)+':'+str(i)] for i in range(4)]
            accuracy=row['accuracy_words'][str(order)]
            rows.append({'point':row['point'],'order':order,'status':row['status'],'actual_backend':9,
                         'precision':stable9(row['status']),
                         'coefficients':[struct.unpack('>d',bytes.fromhex(word))[0] for word in words],
                         'accuracy':struct.unpack('>d',bytes.fromhex(accuracy))[0],
                         'coefficient_binary64_big_endian_hex':words,
                         'accuracy_binary64_big_endian_hex':accuracy})
    require(rows==expected_rows,'Physical anchors changed from the closed current-source profile')


def parse_timing(timing,words,statuses,ready,sequence,point,loops):
    require(point in (1,16) and 1<=loops<=1000000,'Unexpected timed cohort/loop count')
    meta=[sequence,point,loops,ready['ndim'],ready['nso'],ready['nborn']]
    lines=records(timing);require(len(lines)==2 and lines[0]==['META',*map(str,meta)],'Timing META differs')
    require(len(lines[1])==7 and lines[1][0]=='TIMING','Malformed integer timing')
    values=list(map(int,lines[1][1:]));require(values[:3]==[sequence,point,loops],'Timing command identity differs')
    start,end,rate=values[3:];require(start>=0 and end>start and rate>0,'Invalid/wrapped elapsed clock')
    seconds=(end-start)/rate;require(math.isfinite(seconds) and seconds>0,'Invalid measured elapsed time')
    result=parse_words(words,meta,[(loops,4,point)])[str(loops)]
    lines=records(statuses);require(lines and lines[0]==['META',str(sequence),str(point),str(loops)],'Status META differs')
    counts={}
    for line in lines[1:]:
        require(len(line)==6 and line[0]=='STATUS','Malformed timed status')
        seq,actual_point,actual_loops,code,count=map(int,line[1:])
        require([seq,actual_point,actual_loops]==[sequence,point,loops] and count>0 and code not in counts,'Invalid timed status identity/count')
        stable9(code);counts[code]=count
    require(sum(counts.values())==loops,'Timed status coverage incomplete')
    expected=219 if point==1 else 323
    require(set(counts)=={expected} and result['status']==expected,'Timed accepted precision/backend differs from frozen anchor')
    return {'sequence':sequence,'point':point,'loops':loops,'start_ticks':start,'end_ticks':end,'clock_rate':rate,
            'seconds':seconds,'seconds_per_call':seconds/loops,'accepted_status_counts':counts,'last_output':result}


def canonical_wire(raw):
    if len(raw)!=64:return False
    text=raw.rstrip(b' ')
    if text in (b'0',b'-0'):return True
    match=re.fullmatch(rb'-?[1-9]\.[0-9]{38}e(-?)(0|[1-9][0-9]{0,3})',text)
    return bool(match and not(match[1] and match[2]==b'0') and int(match[2])<=4900)


def parse_wire(text,health):
    health_fields=list(map(int,health.split()));require(len(health_fields)==3 and health_fields[0]==0,'Wire observer capture failed')
    rows=records(text);require(rows and len(rows[0])==3 and rows[0][0]=='ENVCONST','Missing actual C environment constants')
    nearest,mask=map(int,rows[0][1:]);require(mask>0,'Invalid halting flag mask')
    calls=[];cursor=1;record_total=0
    while cursor<len(rows):
        row=rows[cursor];cursor+=1
        require(row[0]=='CALL' and len(row)==13,'Malformed real wire CALL')
        seq,n,rank,poles,finite,check,cache,status,length,rounding,halting,sticky=map(int,row[1:])
        require(seq==len(calls)+1 and 1<=n<=6 and 0<=rank<=6 and poles in range(4) and finite in (0,1) and
                check in (0,1) and cache in (0,1) and status in (0,1,2,3),'Invalid real native call metadata')
        count=(rank+1)*(rank+2)*(rank+3)*(rank+4)//24
        require(length==8*count*64,'Real wire coefficient count/record width differs')
        output=[]
        if status==0:
            for i in range(8*count):
                require(cursor<len(rows),'Truncated native wire batch')
                row=rows[cursor];cursor+=1
                require(len(row)==3 and row[:2]==['RECORD',str(i+1)] and re.fullmatch('[0-9a-f]{128}',row[2]),'Malformed raw native record')
                output.append(bytes.fromhex(row[2]));record_total+=1
        require(cursor<len(rows) and rows[cursor]==['END',str(seq)],'Incomplete native batch boundary');cursor+=1
        spellings=bool(output) and all(canonical_wire(record) for record in output)
        environment=rounding==nearest and halting>=0 and (halting&mask)==0
        calls.append({'sequence':seq,'n':n,'rank':rank,'poles':poles,'finite':finite,'check':check,'cache':cache,'native_status':status,
                      'records':len(output),'all_records_canonical':spellings,'actual_rounding':rounding,'actual_halting':halting,
                      'sticky_flags':sticky,'environment_eligible':environment,
                      'whole_batch_eligible':bool(status==0 and finite==1 and poles==0 and spellings and environment)})
    require(len(calls)==health_fields[1] and record_total==health_fields[2] and len(calls)>0,'Real wire health/count coverage differs')
    return {'native_QP_calls':len(calls),'successful_native_QP_calls':sum(c['native_status']==0 for c in calls),
            'whole_batch_eligible':sum(c['whole_batch_eligible'] for c in calls),'raw_records':record_total,'calls':calls,
            'eligibility_role':'Original native wire/FEnv classification; potential candidate fast path, not instrumented candidate branch counts',
            'scope':'Separate original-module observer, post-full100-learning anchors and full100 parity cohort; no timing instrumentation'}


def common_pilot(first_original,first_candidate,target=1.0):
    require(target==1.0 and first_original>0 and first_candidate>0,'Invalid frozen first calibration')
    return min(1000000,max(1,math.ceil(target/max(first_original,first_candidate))))


def common_fixed(pilot,original,candidate,target=1.0):
    require(1<=pilot<=1000000 and original>0 and candidate>0 and target==1.0,'Invalid second calibration')
    return min(1000000,max(1,math.ceil(target/min(original/pilot,candidate/pilot))))


def summarize_pairs(pairs):
    require(len(pairs)==7,'Exactly seven predeclared pairs required')
    ratios=[]
    for i,pair in enumerate(pairs):
        require(pair['order']==(['original','candidate'] if i%2==0 else ['candidate','original']),'Pair order changed')
        left,right=pair['original'],pair['candidate']
        require(left['point']==right['point'] and left['loops']==right['loops'],'Paired cohort/count differs')
        require(left['last_output']==right['last_output'],'Matched-history coefficient/accuracy/status words differ')
        ratios.append(right['seconds']/left['seconds'])
    median_ratio=statistics.median(ratios)
    summary={'candidate_original_ratios':ratios,'median_paired_ratio':median_ratio,
             'observed_percent_change':100*(median_ratio-1),'scope':'Targeted-anchor shared-host observations only',
             'full_process_claim':False,'baseline_chain_claim':False,'performance_acceptance':False,'candidate_promoted':False}
    for variant in ('original','candidate'):
        values=[pair[variant]['seconds_per_call'] for pair in pairs];median=statistics.median(values)
        summary[variant]={'median_seconds_per_call':median,'unscaled_MAD_seconds_per_call':statistics.median(abs(x-median) for x in values)}
    return summary
