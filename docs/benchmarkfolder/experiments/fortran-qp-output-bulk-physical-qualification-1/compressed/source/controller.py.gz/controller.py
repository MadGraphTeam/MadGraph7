"""Separately admitted private BUILD/PARITY/TIMING; default pure preflight."""
import argparse
from contextlib import ExitStack
from datetime import datetime,timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shlex
import shutil
import subprocess
import sys
import time

ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
WORK=ROOT/'.tirust-build/fortran-qp-output-bulk-physical-work-1'
CASE=ROOT/'.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n3_uux_zgg'
PROC_NAME='P0_uux_zgg';PROC=CASE/'SubProcesses'/PROC_NAME
POINTS=ROOT/'docs/benchmarkfolder/campaigns/entry-latch-cache-guard-1/points/qcd_n3_uux_zgg.dat'
PROPOSAL=ROOT/'.tirust-build/fortran-qp-output-bulk-proposal-1'
PROPOSAL_SHA='600fb55cae10c8f105998c6ae689c09992526765734f33036dd79936261f5150'
CPU=12;CAPS={'build':300.,'parity':600.,'timing':480.};CLEANUP=60.
MAKE_SHELL='/nix/store/lw117lsr8d585xs63kx5k233impyrq7q-bash-5.3p3/bin/bash'
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
EXPECTED_SOURCE=REVIEWED_BUILD=REVIEWED_PARITY=PHASE=None
VARIANTS=('original-parity','candidate-parity','wire-parity','original-timing','candidate-timing')
sys.dont_write_bytecode=True


def require(value,message):
    if not value:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def now():return datetime.now(timezone.utc).isoformat()
def dump(path,value):
    path=Path(path);path.parent.mkdir(exist_ok=True,parents=True)
    with path.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
def load(name,path,checksum):
    require(digest(path)==checksum,'Imported source changed: '+str(path))
    if name in sys.modules:
        previous=sys.modules[name]
        require(Path(previous.__file__).resolve()==Path(path).resolve(),'Imported module name collision')
        return previous
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
def local(name):
    seal=read(HERE/'source-index.json')
    return load('bulk_physical_'+name,HERE/(name+'.py'),seal['files'][name+'.py']['sha256'])
def helper(name):
    pin=read(HERE/'input-pins.json');paths={
      'bench':'tools/tirust_benchmark.py','worker':'tools/tirust_benchmark_worker.py',
      'warmup':'tools/tirust_benchmark_warmup.py','compiler':'tools/tirust_benchmark_compiler.py',
      'loader':'docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/loader_checks.py',
      'cleanup':'docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'}
    if name=='warmup':helper('worker')
    sys.path.insert(0,str(ROOT/'tools'))
    canonical={'worker':'tirust_benchmark_worker','warmup':'tirust_benchmark_warmup'}.get(name,'bulk_physical_support_'+name)
    rel=paths[name];return load(canonical,ROOT/rel,pin['files'][rel])


def environment():
    pin=read(HERE/'input-pins.json');env=os.environ.copy()
    for key in list(env):
        if key.startswith(('LD_','NIX_')):env.pop(key)
    for key in ('BASH_ENV','ENV','GLOBAL_FLAG','MAKEFLAGS','MAKEFILES','MAKEOVERRIDES','MFLAGS'):env.pop(key,None)
    for key,value in pin['environment'].items():
        if value is None:env.pop(key,None)
        else:env[key]=value
    libraries=[ROOT/'HEPTools/ninja/lib',ROOT/'HEPTools/collier',ROOT/'HEPTools/ninjars/lib',Path(pin['dso_path']).parent]
    env.update(LD_LIBRARY_PATH=os.pathsep.join(map(str,libraries)),LD_PRELOAD='',
      OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',RAYON_NUM_THREADS='1',
      PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C',TZ='UTC',GFORTRAN_ERROR_BACKTRACE='0')
    return env


def protected():
    pin=read(HERE/'input-pins.json')
    for name,checksum in pin['files'].items():
        p=Path(name) if Path(name).is_absolute() else ROOT/name
        if checksum is None:
            target=str(p.readlink()) if p.is_symlink() else None
            require(not p.exists() and target==pin['null_symlink_targets'].get(name),'Protected absence changed: '+name)
        else:require(p.is_file() and digest(p)==checksum,'Protected input changed: '+name)
    bench=helper('bench')
    require(bench.generated_sources(CASE)==pin['original_sources'],'Closed process source changed')
    require(bench.numerical_objects(CASE)==pin['original_objects'],'Closed numerical objects changed')
    require(digest(CASE/'compilation.json')==pin['case_compilation_sha256'],'Closed build receipt changed')
    compilation=read(CASE/'compilation.json');compiler=helper('compiler');env=environment()
    names=set(compiler.COMPILER_ENVIRONMENT)|{key for key in env if key.startswith(('NIX_CFLAGS_','NIX_LDFLAGS_'))}
    actual_environment={key:env[key] for key in sorted(names) if key in env}
    require(actual_environment==compilation['effective_compiler_flags']['environment'],'Frozen compiler injected environment differs')
    require(digest(pin['dso_path'])==pin['dso_sha256']=='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9','Native library changed')
    return {'input_pins_sha256':digest(HERE/'input-pins.json'),'files':len(pin['files']),
            'original_objects':len(pin['original_objects']),'dso_sha256':pin['dso_sha256']}


def verify_source():
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source hash required')
    seal=read(HERE/'source-index.json')
    require({str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}==set(seal['files'])|{'source-index.json'},'Source inventory changed')
    for name,want in seal['files'].items():
        p=HERE/name;require(not p.is_symlink() and p.stat().st_size==want['bytes'] and digest(p)==want['sha256'],'Source bytes changed: '+name)
    require(digest(PROPOSAL/'index.json')==PROPOSAL_SHA,'Exact decoder proposal changed')
    return protected()


def preflight():
    before=verify_source();require(CPU in os.sched_getaffinity(0),'CPU12 unavailable')
    plan=read(HERE/'timing-plan.json')
    require(plan['anchors']==[1,16] and plan['target_seconds']==1.0 and plan['max_loops']==1000000 and
            plan['timed_pairs']==[{'pair':i+1,'order':['original','candidate'] if i%2==0 else ['candidate','original']} for i in range(7)],'Frozen timing cohort/pair plan differs')
    if PHASE!='build':verify_build()
    if PHASE=='timing':verify_parity()
    return {'status':'source-only-preflight-passed','phase':PHASE,'source_index_sha256':EXPECTED_SOURCE,
      'protected':before,'caps_seconds':CAPS,'cleanup_reserve_seconds':60,'compiler_invocations':0,'native_executions':0}


def command(argv,cwd,logs,label,timeout=None):
    logs.mkdir(exist_ok=True,parents=True);entry={'argv':list(map(str,argv)),'cwd':str(cwd),
      'started_utc':now(),'subprocess_new_session':False,'timeout_seconds':timeout}
    dump(logs/(label+'.command.json'),entry)
    with (logs/(label+'.stdout.txt')).open('xb') as output:
        try:done=subprocess.run(argv,cwd=cwd,env=environment(),stdout=output,stderr=subprocess.STDOUT,timeout=timeout)
        except subprocess.TimeoutExpired:
            entry.update(timed_out=True,finished_utc=now(),stdout_sha256=digest(logs/(label+'.stdout.txt')))
            dump(logs/(label+'.terminal.json'),entry);raise
    entry.update(returncode=done.returncode,finished_utc=now(),stdout_sha256=digest(logs/(label+'.stdout.txt')))
    dump(logs/(label+'.terminal.json'),entry);require(done.returncode==0,'External command failed: '+label)
    return (logs/(label+'.stdout.txt')).read_text()


def clone(source,destination):
    def ignore(directory,names):
        omitted={n for n in names if n in ('worker-protocol.fifo','worker-raw') or n.endswith(('HelFilter.dat','LoopFilter.dat'))}
        if Path(directory)==source:omitted.add('lib')
        return omitted
    shutil.copytree(source,destination,symlinks=False,ignore=ignore)
    (destination/'lib').symlink_to((source/'lib').resolve(),target_is_directory=True)
    require(not any(p.name.endswith(('HelFilter.dat','LoopFilter.dat')) for p in destination.rglob('*')),'Imported helicity/loop filter')


def cards(output):
    pin=read(HERE/'input-pins.json');bench=helper('bench')
    expected=dict(pin['expected_numerical_cards'])
    expected['SubProcesses/'+PROC_NAME+'/MadLoop5_resources/MadLoopParams.dat']=expected['SubProcesses/MadLoop5_resources/MadLoopParams.dat']
    actual=bench.numerical_card_inputs(output);require(actual==expected,'Private cards/explicit resource alias changed')
    p=bench.resolved_parameter_card(output/'SubProcesses'/PROC_NAME)
    require(p and digest(p)==pin['expected_physical_card_sha256'],'Physical parameter card changed')
    return {'numerical_cards':actual,'parameter_card_sha256':digest(p)}


def reused_objects(output):
    pin=read(HERE/'input-pins.json');excluded='SubProcesses/'+PROC_NAME+'/check_sa.o'
    for name,checksum in pin['original_objects'].items():
        if name==excluded:continue
        require(digest(output/name)==checksum,'Reused numerical object changed: '+name)


def bind_frozen_runtime(prebound,expected):
    """The reused profile's explicit transitive-provider join, before linking."""
    for name,checksum in expected.items():
        require(name not in prebound['bound'] or prebound['bound'][name]==checksum,'Frozen runtime/prelink conflict')
        require(Path(name).is_file() and digest(name)==checksum,'Frozen runtime changed before link')
        prebound['bound'][name]=checksum
    prebound['explicit_frozen_runtime_before_link']=dict(expected)
    return prebound


def build_locked(directory):
    pin=read(HERE/'input-pins.json');tools=pin['tools'];build=local('build_helpers');loader=helper('loader')
    result={};logs=directory/'commands'
    version=command([tools['gfortran'],'--version'],directory,logs,'compiler-version')
    require('15.2.0' in version,'Unqualified compiler')
    original=read(CASE/'compilation.json')['effective_compiler_flags']['scopes']['process']['recipes']['check_sa.f']
    require(len(original['compiler'])==1 and version.strip()==original['compiler'][0]['version'],'Original compiler identity/version differs')
    compiler_cache={str(Path(tools['gfortran']).resolve()):original['compiler'][0]}
    for variant in VARIANTS:
        output=directory/variant;clone(CASE,output);proc=output/'SubProcesses'/PROC_NAME;wire=variant=='wire-parity'
        module='candidate' if variant.startswith('candidate') else 'original'
        shutil.copyfile(HERE/(module+'-mtirust.f90'),proc/'mtirust.f90')
        driver='wire' if wire else 'timing' if variant.endswith('timing') else 'parity'
        shutil.copyfile(HERE/(driver+'-driver.f'),proc/'check_sa.f')
        (proc/'makefile').write_text(build.private_makefile((PROC/'makefile').read_text(),wire=wire))
        if wire:
            shutil.copyfile(HERE/'wire_capture.c',proc/'wire_capture.c')
            command([tools['cc'],'-std=c99','-O0','-fPIC','-c','wire_capture.c','-o','wire_capture.o'],proc,logs,variant+'-wire-compile')
        require(tools['make_shell']==MAKE_SHELL and MAKE_SHELL in pin['files'] and digest(MAKE_SHELL)==pin['files'][MAKE_SHELL],'Pinned make shell changed')
        expanded=command([tools['make'],'-n','-B','SHELL='+MAKE_SHELL,'check'],proc,logs,variant+'-expanded')
        recipes,link=build.select_commands(expanded,tools['gfortran'],environment(),wire=wire)
        # Original model/DHELAS/TIR and numerator recipes are never executed.
        require([name for name,_ in recipes]==['mtirust.f90','check_sa.f'],'Unexpected selected sources')
        compiler=helper('compiler');source_name,recipe=compiler._compile_command(shlex.join(recipes[1][1]),proc,environment(),compiler_cache)
        require(source_name=='check_sa.f','Unexpected compiled driver recipe')
        require(compiler._signature(recipe)==compiler._signature(original),'Worker compile recipe differs from frozen original')
        for name,argv in recipes:command(argv,proc,logs,variant+'-'+name+'-compile')
        callback=lambda argv,label:command(argv,proc,logs,variant+'-'+label)
        pre=loader.prelink(link,proc,environment(),callback)
        bind_frozen_runtime(pre,pin['expected_runtime'])
        dump(proc/'prelink.json',pre)
        command(link,proc,logs,variant+'-link')
        loads=loader.requireactualmap((proc/'private-link.map').read_text(),proc,pre,proc/'check')
        runtime=loader.query_runtime(proc/'check',pin['expected_runtime'],pre,callback)
        own_nm=command([tools['nm'],'--defined-only','mtirust.o'],proc,logs,variant+'-module-symbols')
        exe_nm=command([tools['nm'],'--defined-only','check'],proc,logs,variant+'-executable-symbols')
        symbols=build.verify_symbols(own_nm,exe_nm,(proc/'private-link.map').read_text(),wire=wire)
        reused_objects(output);card=cards(output)
        result[variant]={'path':str(output),'executable_sha256':digest(proc/'check'),
          'module_sha256':digest(proc/'mtirust.f90'),'driver_sha256':digest(proc/'check_sa.f'),
          'sources':helper('bench').generated_sources(output),'objects':helper('bench').numerical_objects(output),
          'card_binding':card,'prelink_sha256':digest(proc/'prelink.json'),'actual_link_loads':loads,
          'runtime':runtime,'symbols':symbols,'link_map_sha256':digest(proc/'private-link.map'),
          'selected_recipes':recipes,'link_command':link}
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,'executables':result,
         'protected':protected(),'reused_numerical_objects':True,'Rust_builds':0,'native_amplitude_calls':0})


def verify_build():
    directory=WORK/'build';require(REVIEWED_BUILD and digest(directory/'terminal.json')==REVIEWED_BUILD,'Exact reviewed BUILD terminal required')
    terminal=read(directory/'terminal.json');require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],'BUILD not closed')
    require(digest(directory/'result.json')==terminal['result_sha256'],'BUILD result changed')
    result=read(directory/'result.json');require(result['source_index_sha256']==EXPECTED_SOURCE and set(result['executables'])==set(VARIANTS),'Wrong build/source variants')
    for variant,row in result['executables'].items():
        output=Path(row['path']);proc=output/'SubProcesses'/PROC_NAME
        require(digest(proc/'check')==row['executable_sha256'] and digest(proc/'prelink.json')==row['prelink_sha256'] and digest(proc/'private-link.map')==row['link_map_sha256'],'Private executable/link proof changed')
        require(helper('bench').generated_sources(output)==row['sources'] and helper('bench').numerical_objects(output)==row['objects'],'Private compiled sources/objects changed')
        for name,checksum in {**row['actual_link_loads'],**row['runtime']['files']}.items():require(digest(name)==checksum,'Bound native provider changed')
        require(cards(output)==row['card_binding'],'Private build card changed');reused_objects(output)
    return result


def mapped(worker,row):
    raw=Path('/proc/'+str(worker.process.pid)+'/maps').read_text();expected=dict(row['runtime']['files'])
    exe=Path(row['path'])/'SubProcesses'/PROC_NAME/'check';expected[str(exe)]=row['executable_sha256']
    actual={};data={}
    for line in raw.splitlines():
        parts=line.split(None,5)
        if len(parts)!=6 or not parts[5].startswith('/'):continue
        name=parts[5];require(not name.endswith(' (deleted)'),'Deleted native mapping')
        path=Path(name);resolved=str(path.resolve())
        with path.open('rb') as stream:header=stream.read(4)
        if header==b'\x7fELF':actual[resolved]=digest(path)
        else:
            require(name.startswith('/nix/store/') and name.endswith('/lib/locale/locale-archive') and parts[1]=='r--p','Unexpected mapped data file')
            data[name]=digest(path)
    require(actual==expected,'Actual worker ELF/runtime mapping differs')
    return {'maps':raw,'ELF_files':actual,'readonly_locale_data':data}


def start_worker(variant,row,directory,stack):
    output=directory/'export';clone(Path(row['path']),output);proc=output/'SubProcesses'/PROC_NAME
    # Runtime ELF is identical but its executable mapping has a new copy path.
    require(digest(proc/'check')==row['executable_sha256'],'Private run copy changed')
    runrow=dict(row,path=str(output));require(cards(output)==row['card_binding'],'Run card changed')
    worker_cls=helper('worker').Worker
    worker=stack.enter_context(worker_cls([str(proc/'check'),str(POINTS)],proc,directory/'worker.log',env=environment(),timeout=180.))
    affinity=sorted(os.sched_getaffinity(worker.process.pid));require(affinity==[12],'Native worker CPU affinity changed')
    dump(directory/'process.json',{'pid':worker.process.pid,'affinity':affinity,'cpu_exclusive':False,
          'identity':helper('cleanup').identity(worker.process.pid),'loadavg_after_READY':Path('/proc/loadavg').read_text()})
    ready={key:getattr(worker,key) for key in ('points','ndim','nso','nborn','cold_seconds')}
    warmup=helper('warmup').parse_warmup(proc,9,100,ready)
    require(warmup['rows']==read(HERE/'expected-warmup.json')['rows'],'Unchanged full100 learning failed closed reference parity')
    dump(directory/'ready.json',ready);dump(directory/'warmup.json',warmup)
    dump(directory/'maps-before.json',mapped(worker,runrow))
    return worker,proc,runrow,ready


def custom(worker,proc,directory,command_line,expected,files):
    directory.mkdir(exist_ok=False,parents=True)
    dump(directory/'command.json',{'command':command_line,'expected_response':expected,'before_utc':now()})
    worker._send(command_line);actual=worker._message();require(actual==expected,'Private worker protocol response differs')
    for name in files:shutil.copyfile(proc/name,directory/name)
    dump(directory/'response.json',{'response':actual,'after_utc':now(),'files':{name:digest(directory/name) for name in files}})


def report_inventory(directory):
    return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':digest(p)}
            for p in sorted(directory.rglob('*')) if p.is_file() and 'export' not in p.relative_to(directory).parts}


def parity_locked(directory):
    built=verify_build();analyzer=local('analyze');results={}
    for variant in ('original-parity','candidate-parity','wire-parity'):
        report=directory/variant;report.mkdir()
        with ExitStack() as stack:
            worker,proc,row,ready=start_worker(variant,built['executables'][variant],report,stack)
            custom(worker,proc,report/'parity','PARITY 1',['PARITYDONE','1'],['parity-words.dat','parity-ieee.dat'])
            value=analyzer.parse_parity((report/'parity/parity-words.dat').read_text(),(report/'parity/parity-ieee.dat').read_text(),ready)
            analyzer.closed_anchor_words(read(HERE/'expected.json')['rows'],value)
            if results:analyzer.compare_parity(results['original-parity']['observations'],value)
            wire=None
            if variant=='wire-parity':
                for name in ('real-wire.hex','wire-health.dat'):shutil.copyfile(proc/name,report/name)
                wire=analyzer.parse_wire((report/'real-wire.hex').read_text(),(report/'wire-health.dat').read_text())
            dump(report/'maps-after.json',mapped(worker,row))
        require(not (proc/'worker-protocol.fifo').exists(),'Worker FIFO survived cleanup')
        results[variant]={'observations':value,'wire':wire,'initialization':ready,'card_binding':cards(Path(row['path'])),
                          'raw_files':report_inventory(report)}
    verify_build();protected()
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,'reviewed_build_sha256':REVIEWED_BUILD,
      'variants':results,'full_learning_points':300,'post_learning_physical_calls':306,'performance_acceptance':False,'candidate_promoted':False})


def verify_parity():
    directory=WORK/'parity';require(REVIEWED_PARITY and digest(directory/'terminal.json')==REVIEWED_PARITY,'Exact reviewed successful PARITY terminal required')
    t=read(directory/'terminal.json');require(t['status']=='passed' and t['returncode']==0 and not t['cleanup']['survivors'],'PARITY not closed')
    require(digest(directory/'result.json')==t['result_sha256'],'PARITY result changed')
    value=read(directory/'result.json');require(value['source_index_sha256']==EXPECTED_SOURCE and value['reviewed_build_sha256']==REVIEWED_BUILD,'PARITY source/build mismatch')
    analyzer=local('analyze')
    for variant,row in value['variants'].items():
        report=directory/variant;require(report_inventory(report)==row['raw_files'],'Reviewed PARITY raw evidence changed')
        observed=analyzer.parse_parity((report/'parity/parity-words.dat').read_text(),(report/'parity/parity-ieee.dat').read_text(),row['initialization'])
        require(observed==row['observations'],'Reviewed PARITY observations differ from raw words')
        if variant=='wire-parity':require(analyzer.parse_wire((report/'real-wire.hex').read_text(),(report/'wire-health.dat').read_text())==row['wire'],'Reviewed wire eligibility differs from raw bytes')
    return value


def timing_locked(directory):
    built=verify_build();parity=verify_parity();analyzer=local('analyze');all_results={}
    load_before=Path('/proc/loadavg').read_text()
    with ExitStack() as stack:
        workers={}
        for name in ('original','candidate'):
            report=directory/name;report.mkdir();variant=name+'-timing'
            workers[name]=start_worker(variant,built['executables'][variant],report,stack)
        require(workers['original'][3]==workers['candidate'][3] or
                {k:v for k,v in workers['original'][3].items() if k!='cold_seconds'}=={k:v for k,v in workers['candidate'][3].items() if k!='cold_seconds'},'Timing dimensions differ')
        sequences={'original':0,'candidate':0}
        def measure(name,point,loops,label):
            worker,proc,row,ready=workers[name];sequences[name]+=1;seq=sequences[name]
            report=directory/name/label
            custom(worker,proc,report,f'ANCHORRUN {seq} {point} {loops}',
                   ['ANCHORDONE',str(seq),str(point),str(loops)],['anchor-timing.dat','anchor-words.dat','anchor-status.dat'])
            result=analyzer.parse_timing(*( (report/f).read_text() for f in ('anchor-timing.dat','anchor-words.dat','anchor-status.dat')),ready,seq,point,loops)
            reference=parity['variants']['original-parity']['observations']['values'][str(1 if point==1 else 2)]
            require(result['last_output']['ans_words']==reference['ans_words'] and result['last_output']['status']==reference['status'],'Timed anchor coefficients/status changed')
            result['accuracy_differs_from_earlier_parity_anchor']=result['last_output']['accuracy_words']!=reference['accuracy_words']
            dump(report/'measurement.json',result);return result
        for point in (1,16):
            first={name:measure(name,point,1,f'p{point}-calibration1') for name in ('original','candidate')}
            pilot=analyzer.common_pilot(first['original']['seconds'],first['candidate']['seconds'])
            second={name:measure(name,point,pilot,f'p{point}-calibration2') for name in ('candidate','original')}
            loops=analyzer.common_fixed(pilot,second['original']['seconds'],second['candidate']['seconds'])
            pairs=[]
            for index in range(7):
                order=['original','candidate'] if index%2==0 else ['candidate','original']
                pair={'order':order}
                for name in order:pair[name]=measure(name,point,loops,f'p{point}-pair{index+1}')
                pairs.append(pair)
            all_results[str(point)]={'calibration1':first,'pilot_loops':pilot,'calibration2':second,'fixed_loops':loops,'pairs':pairs,'summary':analyzer.summarize_pairs(pairs)}
        for name,(worker,proc,row,ready) in workers.items():dump(directory/name/'maps-after.json',mapped(worker,row))
    verify_build();verify_parity();protected()
    dump(directory/'result.json',{'status':'passed','source_index_sha256':EXPECTED_SOURCE,'reviewed_build_sha256':REVIEWED_BUILD,
       'reviewed_parity_sha256':REVIEWED_PARITY,'anchors':all_results,'performance_acceptance':False,'candidate_promoted':False,
       'raw_files':{name:report_inventory(directory/name) for name in ('original','candidate')},
       'loadavg_before':load_before,'loadavg_after':Path('/proc/loadavg').read_text(),
       'scope':'Matched-history targeted-anchor shared-host observations, not full-process or baseline-chain acceptance'})


def set_limits():
    for kind,key in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[key];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited resource limit too small');resource.setrlimit(kind,(value,value))


def child():
    set_limits();directory=WORK/PHASE;admission=read(directory/'admission.json')
    require(admission['source_index_sha256']==EXPECTED_SOURCE and admission['phase']==PHASE and admission['reviewed_build_sha256']==REVIEWED_BUILD and admission['reviewed_parity_sha256']==REVIEWED_PARITY,'Child admission differs')
    dump(directory/'limits.json',{'actual':{key:list(resource.getrlimit(kind)) for kind,key in
        ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes'))}})
    preflight()
    with (ROOT/'.tirust-build/numerical-tests.lock').open('a') as mutex:
        fcntl.flock(mutex,fcntl.LOCK_EX)
        {'build':build_locked,'parity':parity_locked,'timing':timing_locked}[PHASE](directory)


def stage():
    cleanup=helper('cleanup');ownership=local('ownership');WORK.mkdir(exist_ok=True);directory=WORK/PHASE;directory.mkdir(exist_ok=False)
    entry={'phase':PHASE,'cap_seconds':CAPS[PHASE],'cleanup_reserve_seconds':60,'started_utc':now(),'status':'running'}
    owned=process=raw_record=None;cleaned=False
    with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAPS[PHASE]) as deadline:
        try:
            preflight();requests.check()
            argv=[read(HERE/'input-pins.json')['tools']['taskset'],'-c','12',sys.executable,'-B',str(Path(__file__).relative_to(ROOT)),
                  '--child','--phase',PHASE,'--source',EXPECTED_SOURCE]
            if REVIEWED_BUILD:argv+=['--reviewed-build',REVIEWED_BUILD]
            if REVIEWED_PARITY:argv+=['--reviewed-parity',REVIEWED_PARITY]
            entry['command']=argv
            dump(directory/'admission.json',{'phase':PHASE,'source_index_sha256':EXPECTED_SOURCE,'reviewed_build_sha256':REVIEWED_BUILD,'reviewed_parity_sha256':REVIEWED_PARITY,'command':argv,'resource_limits':LIMITS})
            with (directory/'console.log').open('xb') as output:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['child_pid']=process.pid;dump(directory/'started.json',entry);print('START '+PHASE+' child_pid='+str(process.pid),flush=True)
                entry['returncode']=owned.wait(requests);requests.check();entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0,'Physical gate stage failed');verify_source();requests.check()
            entry.update(status='passed',finished_utc=now(),result_sha256=digest(directory/'result.json'));dump(directory/'terminal.json',entry)
        except BaseException as error:
            if process is not None and not cleaned:
                try:entry['cleanup']=ownership.cleanup_owned(owned,deadline.end) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,deadline.end)
                except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
            entry.update(status='failed',error=repr(error),finished_utc=now());dump(directory/'terminal.json',entry);raise


def main():
    global EXPECTED_SOURCE,REVIEWED_BUILD,REVIEWED_PARITY,PHASE
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preflight',action='store_true');mode.add_argument('--execute',action='store_true');mode.add_argument('--child',action='store_true')
    parser.add_argument('--phase',choices=tuple(CAPS),required=True);parser.add_argument('--source',required=True)
    parser.add_argument('--reviewed-build');parser.add_argument('--reviewed-parity');args=parser.parse_args()
    EXPECTED_SOURCE=args.source;REVIEWED_BUILD=args.reviewed_build;REVIEWED_PARITY=args.reviewed_parity;PHASE=args.phase
    require(re.fullmatch('[0-9a-f]{64}',EXPECTED_SOURCE),'Exact reviewed source required')
    if PHASE!='build':require(REVIEWED_BUILD and re.fullmatch('[0-9a-f]{64}',REVIEWED_BUILD),'Separate reviewed BUILD required')
    if PHASE=='timing':require(REVIEWED_PARITY and re.fullmatch('[0-9a-f]{64}',REVIEWED_PARITY),'Separate reviewed PARITY required')
    if args.preflight:print(json.dumps(preflight(),sort_keys=True,indent=2));return
    if args.child:child();return
    stage()


if __name__=='__main__':main()
