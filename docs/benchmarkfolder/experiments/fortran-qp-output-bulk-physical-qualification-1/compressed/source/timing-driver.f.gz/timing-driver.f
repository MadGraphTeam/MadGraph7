C     Persistent benchmark template. Expand ML5_0_, 5, 1.
C     Usage: check --masses, or check points.dat protocol.fifo.
      PROGRAM BENCHMARK_MADLOOP_WORKER
      IMPLICIT NONE
      INTEGER NEXTERNAL
      PARAMETER(NEXTERNAL=5)
      INCLUDE 'coupl.inc'
      INTEGER NSQSO_BORN
      PARAMETER(NSQSO_BORN=1)
      REAL*8 ZERO
      PARAMETER(ZERO=0D0)
      REAL*8 PMASS(NEXTERNAL)
      REAL*8, ALLOCATABLE :: POINTS(:,:,:),ANS(:,:),ACC(:)
      REAL*8, ALLOCATABLE :: VALUES(:,:,:),ACCURACIES(:,:)
      INTEGER, ALLOCATABLE :: CODES(:)
      REAL*8 P(0:3,NEXTERNAL),TOTAL(0:3),COLD,ELAPSED
      INTEGER NPOINTS,NDIM,NSO,I,J,K,L,NLOOPS,CODE
      INTEGER TENS,WARM_POINTS,WARM_POINT,IOS,SEQUENCE
      INTEGER PREVIOUS_SEQUENCE
      LOGICAL BENCHMARK_WARM_STATUS
      INTEGER*8 TIMED_CODES(0:499),T0,T1,RATE
      CHARACTER*1024 ARG
      CHARACTER*16 COMMAND
      CHARACTER*4096 BULK_COMMAND_LINE
      INTEGER BULK_VALUES(3),BULK_IOS
      INTEGER BULK_POINT,BULK_OCCURRENCE,BULK_PHASE

      CALL SETPARA('param_card.dat')
      INCLUDE 'pmass.inc'
      CALL GET_COMMAND_ARGUMENT(1,ARG)
      IF(TRIM(ARG).EQ.'--masses') THEN
         OPEN(73,FILE='masses.dat',STATUS='REPLACE')
         WRITE(*,'(A,I8)') 'MASSES ',NEXTERNAL
         DO I=1,NEXTERNAL
            WRITE(*,'(I8,ES26.17E3)') I,PMASS(I)
            WRITE(73,'(ES26.17E3)') PMASS(I)
         ENDDO
         CLOSE(73)
         STOP
      ENDIF
C     A dedicated FIFO carries protocol; stdout is diagnostic only.
      CALL GET_COMMAND_ARGUMENT(2,ARG)
      OPEN(74,FILE=TRIM(ARG),STATUS='OLD',ACTION='WRITE')
      CALL ML5_0_GET_ANSWER_DIMENSION(NDIM)
      CALL ML5_0_GET_NSQSO_LOOP(NSO)
      IF(NDIM.NE.MAX(NSO,NSQSO_BORN)) STOP 2
      OPEN(73,FILE='dimensions.dat',STATUS='REPLACE')
      WRITE(73,*) NDIM,NSO,NSQSO_BORN
      CLOSE(73)
      CALL GET_COMMAND_ARGUMENT(1,ARG)
      OPEN(73,FILE=TRIM(ARG),STATUS='OLD')
      READ(73,*) NPOINTS
      IF(NPOINTS.LE.0) STOP 1
      ALLOCATE(POINTS(0:3,NEXTERNAL,NPOINTS))
      DO K=1,NPOINTS
         DO I=1,NEXTERNAL
            READ(73,*) POINTS(:,I,K)
         ENDDO
      ENDDO
      CLOSE(73)
      ALLOCATE(ANS(0:3,0:NDIM),ACC(0:NSO))
      ALLOCATE(VALUES(0:3,0:NDIM,NPOINTS))
      ALLOCATE(ACCURACIES(0:NSO,NPOINTS),CODES(NPOINTS))
      ANS=0D0
      ACC=-1D0
      VALUES=0D0
      OPEN(75,FILE='warmup.dat',STATUS='REPLACE')
      WRITE(75,'(A)')
     $ '# call point order status Born finite single double accuracy'
      CALL ML5_0_FORCE_STABILITY_CHECK(.TRUE.)
      P=POINTS(:,:,1)
      TOTAL=P(:,1)+P(:,2)
      MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
      CALL UPDATE_AS_PARAM()
      CALL SYSTEM_CLOCK(T0,RATE)
      IF(RATE.LE.0) STOP 5
      CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
C     The first call bootstraps MadLoop and may have an unknown status.
C     Retain it, but require a recognized status on every later call.
      CALL BENCHMARK_TRACE_WARMUP(75,0,1,NDIM,NSO,CODE,ANS,ACC)
      WARM_POINTS=0
      DO K=1,1000+NPOINTS
         WARM_POINT=1+MOD(K-1,NPOINTS)
         P=POINTS(:,:,WARM_POINT)
         TOTAL=P(:,1)+P(:,2)
         MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
         CALL UPDATE_AS_PARAM()
         ANS=0D0
         ACC=-1D0
         CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
         CALL BENCHMARK_TRACE_WARMUP(75,K,WARM_POINT,NDIM,NSO,
     $        CODE,ANS,ACC)
         IF(.NOT.BENCHMARK_WARM_STATUS(CODE)) THEN
            WRITE(74,'(A,2I12)') 'ERROR warmup-status ',
     $           WARM_POINT,CODE
            FLUSH(74)
            CLOSE(75)
            CALL ML5_0_EXIT_MADLOOP()
            STOP 3
         ENDIF
         TENS=MOD(CODE,100)/10
         IF(TENS.EQ.1.OR.TENS.EQ.2) THEN
            WARM_POINTS=WARM_POINTS+1
         ELSE
            WARM_POINTS=0
         ENDIF
         IF(WARM_POINTS.GE.NPOINTS) EXIT
      ENDDO
      IF(WARM_POINTS.LT.NPOINTS) THEN
         WRITE(74,'(A,2I12)') 'ERROR warmup-limit ',WARM_POINT,CODE
         FLUSH(74)
         CLOSE(75)
         CALL ML5_0_EXIT_MADLOOP()
         STOP 3
      ENDIF
      CLOSE(75)
      CALL SYSTEM_CLOCK(T1)
      COLD=DBLE(T1-T0)/DBLE(RATE)
C     Keep exactly the same diagnostic policy for every measured backend.
      OPEN(6,FILE='/dev/null',STATUS='OLD')
      WRITE(74,'(A,5I12,ES26.17E3)') 'READY ',1,NPOINTS,
     $ NDIM,NSO,NSQSO_BORN,COLD
      FLUSH(74)
      PREVIOUS_SEQUENCE=0

 100  CONTINUE
      READ(5,'(A)',IOSTAT=IOS) BULK_COMMAND_LINE
      IF(IOS.LT.0) GOTO 900
      IF(IOS.NE.0) GOTO 800
      READ(BULK_COMMAND_LINE,*,IOSTAT=IOS) COMMAND
      IF(IOS.NE.0) GOTO 800
      IF(TRIM(COMMAND).EQ.'STOP') GOTO 900
      IF(TRIM(COMMAND).EQ.'ANCHORRUN') THEN
         CALL BENCHMARK_BULK_PARSE(BULK_COMMAND_LINE,'ANCHORRUN',
     $        3,BULK_VALUES,BULK_IOS)
         IF(BULK_IOS.NE.0.OR.NPOINTS.NE.100) GOTO 800
         IF(PREVIOUS_SEQUENCE.GE.2000000000) GOTO 800
         SEQUENCE=BULK_VALUES(1)
         BULK_POINT=BULK_VALUES(2)
         NLOOPS=BULK_VALUES(3)
         IF(SEQUENCE.LE.0.OR.
     $        SEQUENCE.NE.PREVIOUS_SEQUENCE+1) GOTO 800
         IF(BULK_POINT.LT.1.OR.BULK_POINT.GT.NPOINTS) GOTO 800
         IF(NLOOPS.LT.1.OR.NLOOPS.GT.1000000) GOTO 800
         PREVIOUS_SEQUENCE=SEQUENCE
         TIMED_CODES=0
C     BULK_ANCHOR_CLOCK_BEGIN
         CALL SYSTEM_CLOCK(T0)
         DO L=1,NLOOPS
            P=POINTS(:,:,BULK_POINT)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            IF(CODE.LT.0.OR.CODE.GT.499) STOP 4
            IF(.NOT.BENCHMARK_WARM_STATUS(CODE)) STOP 4
            TENS=MOD(CODE,100)/10
            IF(TENS.NE.1.AND.TENS.NE.2) STOP 4
            TIMED_CODES(CODE)=TIMED_CODES(CODE)+1
         ENDDO
         CALL SYSTEM_CLOCK(T1)
C     BULK_ANCHOR_CLOCK_END
         IF(T1.LT.T0.OR.RATE.LE.0) STOP 5
         OPEN(76,FILE='anchor-timing.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(76,'(A,6I12)') 'META ',SEQUENCE,BULK_POINT,
     $        NLOOPS,NDIM,NSO,NSQSO_BORN
         WRITE(76,'(A,3I12,3I24)') 'TIMING ',SEQUENCE,
     $        BULK_POINT,NLOOPS,T0,T1,RATE
         CLOSE(76)
         OPEN(77,FILE='anchor-words.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(77,'(A,6I12)') 'META ',SEQUENCE,BULK_POINT,
     $        NLOOPS,NDIM,NSO,NSQSO_BORN
         CALL BENCHMARK_BULK_WORDS(77,SEQUENCE,NLOOPS,4,
     $        BULK_POINT,NDIM,NSO,CODE,ANS,ACC)
         CLOSE(77)
         OPEN(78,FILE='anchor-status.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(78,'(A,3I12)') 'META ',SEQUENCE,BULK_POINT,NLOOPS
         DO I=0,499
            IF(TIMED_CODES(I).GT.0) THEN
               WRITE(78,'(A,4I12,I24)') 'STATUS ',SEQUENCE,
     $              BULK_POINT,NLOOPS,I,TIMED_CODES(I)
            ENDIF
         ENDDO
         CLOSE(78)
         WRITE(74,'(A,3I12)') 'ANCHORDONE ',SEQUENCE,
     $        BULK_POINT,NLOOPS
         FLUSH(74)
         GOTO 100
      ENDIF
      READ(BULK_COMMAND_LINE,*,IOSTAT=IOS)
     $ COMMAND,SEQUENCE,NLOOPS
      IF(IOS.NE.0) GOTO 800
      IF(TRIM(COMMAND).NE.'RUN') GOTO 800
      IF(SEQUENCE.NE.PREVIOUS_SEQUENCE+1.OR.NLOOPS.LE.0) GOTO 800
      PREVIOUS_SEQUENCE=SEQUENCE
      TIMED_CODES=0
      CALL SYSTEM_CLOCK(T0)
      DO L=1,NLOOPS
         DO K=1,NPOINTS
            P=POINTS(:,:,K)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            IF(CODE.LT.0.OR.CODE.GT.499) STOP 4
            TIMED_CODES(CODE)=TIMED_CODES(CODE)+1
C           The final timed traversal supplies numerical evidence.
            IF(L.EQ.NLOOPS) THEN
               VALUES(:,:,K)=ANS
               ACCURACIES(:,K)=ACC
               CODES(K)=CODE
            ENDIF
         ENDDO
      ENDDO
      CALL SYSTEM_CLOCK(T1)
      ELAPSED=DBLE(T1-T0)/DBLE(RATE)
      OPEN(73,FILE='timing.dat',STATUS='REPLACE')
      WRITE(73,'(2ES26.17E3)') COLD,ELAPSED
      CLOSE(73)
      OPEN(73,FILE='values.dat',STATUS='REPLACE')
      DO K=1,NPOINTS
         DO J=0,NDIM
            IF(J.LE.NSO) THEN
               WRITE(73,'(3I8,5ES26.17E3)') K,J,CODES(K),
     $              VALUES(:,J,K),ACCURACIES(J,K)
            ELSE
C              Born-only columns have no per-order loop accuracy.
               WRITE(73,'(3I8,5ES26.17E3)') K,J,CODES(K),
     $              VALUES(:,J,K),ACCURACIES(0,K)
            ENDIF
         ENDDO
      ENDDO
      CLOSE(73)
      OPEN(73,FILE='timed_status.dat',STATUS='REPLACE')
      DO I=0,499
         IF(TIMED_CODES(I).GT.0) WRITE(73,'(I5,1X,I20)')
     $        I,TIMED_CODES(I)
      ENDDO
      CLOSE(73)
      WRITE(74,'(A,2I12)') 'DONE ',SEQUENCE,NLOOPS
      FLUSH(74)
      GOTO 100

 800  CONTINUE
      WRITE(74,'(A)') 'ERROR invalid-command'
      FLUSH(74)
      CALL ML5_0_EXIT_MADLOOP()
      STOP 8
 900  CONTINUE
      CALL ML5_0_EXIT_MADLOOP()
      WRITE(74,'(A)') 'BYE'
      FLUSH(74)
      CLOSE(74)
      END

      LOGICAL FUNCTION BENCHMARK_WARM_STATUS(CODE)
C     T=3 is the only allowed continuing initialization state for this
C     CTModeInit=1 campaign. T=4, unknown/failing reductions, and backend
C     aliases outside the five qualified libraries fail immediately.
      IMPLICIT NONE
      INTEGER CODE,H,T,U
      LOGICAL STABLE_ALIAS
      BENCHMARK_WARM_STATUS=.FALSE.
      IF(CODE.LT.0.OR.CODE.GT.499) RETURN
      H=CODE/100
      T=MOD(CODE,100)/10
      U=MOD(CODE,10)
      IF(T.NE.1.AND.T.NE.2.AND.T.NE.3) RETURN
      IF(U.EQ.0.OR.H.EQ.4) RETURN
      STABLE_ALIAS=(H.EQ.2.AND.(U.EQ.1.OR.U.EQ.6.OR.U.EQ.7
     $ .OR.U.EQ.8.OR.U.EQ.9)).OR.(H.EQ.3.AND.(U.EQ.9
     $ .OR.U.EQ.8.OR.U.EQ.2.OR.U.EQ.3))
      BENCHMARK_WARM_STATUS=STABLE_ALIAS.OR.(T.EQ.3.AND.H.EQ.1
     $ .AND.(U.EQ.1.OR.U.EQ.6.OR.U.EQ.7.OR.U.EQ.8.OR.U.EQ.9))
      END

      SUBROUTINE BENCHMARK_TRACE_WARMUP(LUN,CALL_INDEX,POINT_INDEX,
     $ NDIM,NSO,CODE,ANS,ACC)
C     Every answer column and accuracy is retained outside timed runs.
      IMPLICIT NONE
      INTEGER LUN,CALL_INDEX,POINT_INDEX,NDIM,NSO,CODE,J
      REAL*8 ANS(0:3,0:NDIM),ACC(0:NSO),ESTIMATE
      DO J=0,NDIM
         ESTIMATE=ACC(0)
         IF(J.LE.NSO) ESTIMATE=ACC(J)
         WRITE(LUN,'(4I12,5ES26.17E3)') CALL_INDEX,POINT_INDEX,J,
     $        CODE,ANS(:,J),ESTIMATE
      ENDDO
      FLUSH(LUN)
      END

      PURE SUBROUTINE BENCHMARK_BULK_PARSE(LINE,EXPECTED,
     $ NFIELDS,VALUES,STATUS)
C     New commands admit only whitespace-separated unsigned integers.
C     No null/repetition/slash/exponent or cross-record list syntax.
      IMPLICIT NONE
      CHARACTER*(*),INTENT(IN) :: LINE,EXPECTED
      INTEGER,INTENT(IN) :: NFIELDS
      INTEGER,INTENT(OUT) :: VALUES(3),STATUS
      CHARACTER*64 TOKENS(4)
      INTEGER I,J,K,LAST,FIRST,NTOKENS,DIGIT,VALUE
      VALUES=0
      TOKENS=' '
      STATUS=1
      IF(NFIELDS.LT.1.OR.NFIELDS.GT.3) RETURN
      I=1
      NTOKENS=0
      LAST=LEN_TRIM(LINE)
      DO WHILE(I.LE.LAST)
         IF(LINE(I:I).EQ.' '.OR.IACHAR(LINE(I:I)).EQ.9) THEN
            I=I+1
            CYCLE
         ENDIF
         IF(NTOKENS.GE.NFIELDS+1) RETURN
         FIRST=I
         DO WHILE(I.LE.LAST)
            IF(LINE(I:I).EQ.' '.OR.IACHAR(LINE(I:I)).EQ.9) EXIT
            I=I+1
         ENDDO
         IF(I-FIRST.GT.64) RETURN
         NTOKENS=NTOKENS+1
         TOKENS(NTOKENS)=LINE(FIRST:I-1)
      ENDDO
      IF(NTOKENS.NE.NFIELDS+1) RETURN
      IF(TRIM(TOKENS(1)).NE.TRIM(EXPECTED)) RETURN
      DO J=1,NFIELDS
         VALUE=0
         DO K=1,LEN_TRIM(TOKENS(J+1))
            DIGIT=IACHAR(TOKENS(J+1)(K:K))-IACHAR('0')
            IF(DIGIT.LT.0.OR.DIGIT.GT.9) RETURN
            IF(VALUE.GT.(2000000000-DIGIT)/10) RETURN
            VALUE=VALUE*10+DIGIT
         ENDDO
         VALUES(J)=VALUE
      ENDDO
      STATUS=0
      END

      SUBROUTINE BENCHMARK_BULK_WORDS(LUN,SEQUENCE,OCCURRENCE,
     $ PHASE,POINT,NDIM,NSO,CODE,ANS,ACC)
C     Exact public REAL*8 words, including signed zero and nonfinites.
      IMPLICIT NONE
      INTEGER LUN,SEQUENCE,OCCURRENCE,PHASE,POINT,NDIM,NSO,CODE
      INTEGER I,J
      INTEGER*8 WORD
      REAL*8 ANS(0:3,0:NDIM),ACC(0:NSO)
      DO J=0,NDIM
         DO I=0,3
            WORD=TRANSFER(ANS(I,J),WORD)
            WRITE(LUN,'(A,7I12,1X,Z16.16)') 'ANS ',SEQUENCE,
     $           OCCURRENCE,PHASE,POINT,J,I,CODE,WORD
         ENDDO
      ENDDO
      DO J=0,NSO
         WORD=TRANSFER(ACC(J),WORD)
         WRITE(LUN,'(A,6I12,1X,Z16.16)') 'ACC ',SEQUENCE,
     $        OCCURRENCE,PHASE,POINT,J,CODE,WORD
      ENDDO
      END
