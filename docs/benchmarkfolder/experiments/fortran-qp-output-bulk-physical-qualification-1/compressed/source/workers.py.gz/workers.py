"""Pure exact-base worker transforms; no compiler, subprocess or file access.

The original full warmup and RUN body are retained verbatim. New commands are
line-oriented and use a strict integer-only parser. Returned amplitude/accuracy
words are the public REAL*8 results, including results produced by QP rescue;
they do not claim to expose the internal binary128 tensor/numerator words.
"""
import hashlib

BASE_SHA256 = "f9f1679df57dea235518a9f50570c4a2a1f975b32136114c71cf6222e2a62093"
TEMPLATE_SHA256 = "7cc01cc4a0cfb5478b0f77f713c403d8eee30d52cfcb0926752b12aaa157d5b9"
PREFIX = "ML5_0_"
POINTS = 100
ANCHORS = (1, 16)
MAX_SEQUENCE = 2000000000
MAX_ANCHOR_LOOPS = 1000000

READ_PREFIX = """      READ(5,*,IOSTAT=IOS) COMMAND,SEQUENCE,NLOOPS
      IF(IOS.LT.0) GOTO 900
      IF(IOS.NE.0) GOTO 800
      IF(TRIM(COMMAND).EQ.'STOP') GOTO 900
"""

COMMON_DECLARATIONS = """      CHARACTER*4096 BULK_COMMAND_LINE
      INTEGER BULK_VALUES(3),BULK_IOS
      INTEGER BULK_POINT,BULK_OCCURRENCE,BULK_PHASE
"""

PARITY_DECLARATIONS = """      INTEGER BULK_PRE_FLAGS(5),BULK_POST_FLAGS(5)
      INTEGER BULK_PRE_HALTS(5),BULK_POST_HALTS(5)
      INTEGER BULK_PRE_ROUND,BULK_POST_ROUND
"""

PARITY_COMMAND = """      IF(TRIM(COMMAND).EQ.'PARITY') THEN
         CALL BENCHMARK_BULK_PARSE(BULK_COMMAND_LINE,'PARITY',1,
     $        BULK_VALUES,BULK_IOS)
         IF(BULK_IOS.NE.0.OR.NPOINTS.NE.100) GOTO 800
         IF(PREVIOUS_SEQUENCE.GE.2000000000) GOTO 800
         SEQUENCE=BULK_VALUES(1)
         IF(SEQUENCE.LE.0.OR.
     $        SEQUENCE.NE.PREVIOUS_SEQUENCE+1) GOTO 800
         PREVIOUS_SEQUENCE=SEQUENCE
         OPEN(76,FILE='parity-words.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         OPEN(77,FILE='parity-ieee.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(76,'(A,5I12)') 'META ',SEQUENCE,NPOINTS,
     $        NDIM,NSO,NSQSO_BORN
         WRITE(77,'(A,5I12)') 'META ',SEQUENCE,NPOINTS,
     $        NDIM,NSO,NSQSO_BORN
C     BULK_PARITY_BEGIN
         DO BULK_OCCURRENCE=1,NPOINTS+2
            IF(BULK_OCCURRENCE.EQ.1) THEN
               BULK_PHASE=1
               BULK_POINT=1
            ELSEIF(BULK_OCCURRENCE.EQ.2) THEN
               BULK_PHASE=2
               BULK_POINT=16
            ELSE
               BULK_PHASE=3
               BULK_POINT=BULK_OCCURRENCE-2
            ENDIF
            P=POINTS(:,:,BULK_POINT)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            ACC=-1D0
            CALL BENCHMARK_BULK_IEEE(BULK_PRE_FLAGS,
     $           BULK_PRE_HALTS,BULK_PRE_ROUND)
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            CALL BENCHMARK_BULK_IEEE(BULK_POST_FLAGS,
     $           BULK_POST_HALTS,BULK_POST_ROUND)
            CALL BENCHMARK_BULK_WORDS(76,SEQUENCE,
     $           BULK_OCCURRENCE,BULK_PHASE,BULK_POINT,
     $           NDIM,NSO,CODE,ANS,ACC)
            CALL BENCHMARK_BULK_WRITE_IEEE(77,SEQUENCE,
     $           BULK_OCCURRENCE,BULK_PHASE,BULK_POINT,0,
     $           BULK_PRE_ROUND,BULK_PRE_FLAGS,BULK_PRE_HALTS)
            CALL BENCHMARK_BULK_WRITE_IEEE(77,SEQUENCE,
     $           BULK_OCCURRENCE,BULK_PHASE,BULK_POINT,1,
     $           BULK_POST_ROUND,BULK_POST_FLAGS,BULK_POST_HALTS)
         ENDDO
C     BULK_PARITY_END
         CLOSE(76)
         CLOSE(77)
         WRITE(74,'(A,I12)') 'PARITYDONE ',SEQUENCE
         FLUSH(74)
         GOTO 100
      ENDIF
"""

TIMING_COMMAND = """      IF(TRIM(COMMAND).EQ.'ANCHORRUN') THEN
         CALL BENCHMARK_BULK_PARSE(BULK_COMMAND_LINE,'ANCHORRUN',
     $        3,BULK_VALUES,BULK_IOS)
         IF(BULK_IOS.NE.0.OR.NPOINTS.NE.100) GOTO 800
         IF(PREVIOUS_SEQUENCE.GE.2000000000) GOTO 800
         SEQUENCE=BULK_VALUES(1)
         BULK_POINT=BULK_VALUES(2)
         NLOOPS=BULK_VALUES(3)
         IF(SEQUENCE.LE.0.OR.
     $        SEQUENCE.NE.PREVIOUS_SEQUENCE+1) GOTO 800
         IF(BULK_POINT.LT.1.OR.BULK_POINT.GT.NPOINTS) GOTO 800
         IF(NLOOPS.LT.1.OR.NLOOPS.GT.1000000) GOTO 800
         PREVIOUS_SEQUENCE=SEQUENCE
         TIMED_CODES=0
C     BULK_ANCHOR_CLOCK_BEGIN
         CALL SYSTEM_CLOCK(T0)
         DO L=1,NLOOPS
            P=POINTS(:,:,BULK_POINT)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            IF(CODE.LT.0.OR.CODE.GT.499) STOP 4
            IF(.NOT.BENCHMARK_WARM_STATUS(CODE)) STOP 4
            TENS=MOD(CODE,100)/10
            IF(TENS.NE.1.AND.TENS.NE.2) STOP 4
            TIMED_CODES(CODE)=TIMED_CODES(CODE)+1
         ENDDO
         CALL SYSTEM_CLOCK(T1)
C     BULK_ANCHOR_CLOCK_END
         IF(T1.LT.T0.OR.RATE.LE.0) STOP 5
         OPEN(76,FILE='anchor-timing.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(76,'(A,6I12)') 'META ',SEQUENCE,BULK_POINT,
     $        NLOOPS,NDIM,NSO,NSQSO_BORN
         WRITE(76,'(A,3I12,3I24)') 'TIMING ',SEQUENCE,
     $        BULK_POINT,NLOOPS,T0,T1,RATE
         CLOSE(76)
         OPEN(77,FILE='anchor-words.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(77,'(A,6I12)') 'META ',SEQUENCE,BULK_POINT,
     $        NLOOPS,NDIM,NSO,NSQSO_BORN
         CALL BENCHMARK_BULK_WORDS(77,SEQUENCE,NLOOPS,4,
     $        BULK_POINT,NDIM,NSO,CODE,ANS,ACC)
         CLOSE(77)
         OPEN(78,FILE='anchor-status.dat',STATUS='REPLACE',
     $        ACTION='WRITE',IOSTAT=IOS)
         IF(IOS.NE.0) GOTO 800
         WRITE(78,'(A,3I12)') 'META ',SEQUENCE,BULK_POINT,NLOOPS
         DO I=0,499
            IF(TIMED_CODES(I).GT.0) THEN
               WRITE(78,'(A,4I12,I24)') 'STATUS ',SEQUENCE,
     $              BULK_POINT,NLOOPS,I,TIMED_CODES(I)
            ENDIF
         ENDDO
         CLOSE(78)
         WRITE(74,'(A,3I12)') 'ANCHORDONE ',SEQUENCE,
     $        BULK_POINT,NLOOPS
         FLUSH(74)
         GOTO 100
      ENDIF
"""

PARSE_HELPER = """
      PURE SUBROUTINE BENCHMARK_BULK_PARSE(LINE,EXPECTED,
     $ NFIELDS,VALUES,STATUS)
C     New commands admit only whitespace-separated unsigned integers.
C     No null/repetition/slash/exponent or cross-record list syntax.
      IMPLICIT NONE
      CHARACTER*(*),INTENT(IN) :: LINE,EXPECTED
      INTEGER,INTENT(IN) :: NFIELDS
      INTEGER,INTENT(OUT) :: VALUES(3),STATUS
      CHARACTER*64 TOKENS(4)
      INTEGER I,J,K,LAST,FIRST,NTOKENS,DIGIT,VALUE
      VALUES=0
      TOKENS=' '
      STATUS=1
      IF(NFIELDS.LT.1.OR.NFIELDS.GT.3) RETURN
      I=1
      NTOKENS=0
      LAST=LEN_TRIM(LINE)
      DO WHILE(I.LE.LAST)
         IF(LINE(I:I).EQ.' '.OR.IACHAR(LINE(I:I)).EQ.9) THEN
            I=I+1
            CYCLE
         ENDIF
         IF(NTOKENS.GE.NFIELDS+1) RETURN
         FIRST=I
         DO WHILE(I.LE.LAST)
            IF(LINE(I:I).EQ.' '.OR.IACHAR(LINE(I:I)).EQ.9) EXIT
            I=I+1
         ENDDO
         IF(I-FIRST.GT.64) RETURN
         NTOKENS=NTOKENS+1
         TOKENS(NTOKENS)=LINE(FIRST:I-1)
      ENDDO
      IF(NTOKENS.NE.NFIELDS+1) RETURN
      IF(TRIM(TOKENS(1)).NE.TRIM(EXPECTED)) RETURN
      DO J=1,NFIELDS
         VALUE=0
         DO K=1,LEN_TRIM(TOKENS(J+1))
            DIGIT=IACHAR(TOKENS(J+1)(K:K))-IACHAR('0')
            IF(DIGIT.LT.0.OR.DIGIT.GT.9) RETURN
            IF(VALUE.GT.(2000000000-DIGIT)/10) RETURN
            VALUE=VALUE*10+DIGIT
         ENDDO
         VALUES(J)=VALUE
      ENDDO
      STATUS=0
      END
"""

WORDS_HELPER = """
      SUBROUTINE BENCHMARK_BULK_WORDS(LUN,SEQUENCE,OCCURRENCE,
     $ PHASE,POINT,NDIM,NSO,CODE,ANS,ACC)
C     Exact public REAL*8 words, including signed zero and nonfinites.
      IMPLICIT NONE
      INTEGER LUN,SEQUENCE,OCCURRENCE,PHASE,POINT,NDIM,NSO,CODE
      INTEGER I,J
      INTEGER*8 WORD
      REAL*8 ANS(0:3,0:NDIM),ACC(0:NSO)
      DO J=0,NDIM
         DO I=0,3
            WORD=TRANSFER(ANS(I,J),WORD)
            WRITE(LUN,'(A,7I12,1X,Z16.16)') 'ANS ',SEQUENCE,
     $           OCCURRENCE,PHASE,POINT,J,I,CODE,WORD
         ENDDO
      ENDDO
      DO J=0,NSO
         WORD=TRANSFER(ACC(J),WORD)
         WRITE(LUN,'(A,6I12,1X,Z16.16)') 'ACC ',SEQUENCE,
     $        OCCURRENCE,PHASE,POINT,J,CODE,WORD
      ENDDO
      END
"""

IEEE_HELPERS = """
      SUBROUTINE BENCHMARK_BULK_IEEE(FLAGS,HALTS,ROUNDING)
C     Read-only observations; unsupported inquiries are recorded as -1.
      USE, INTRINSIC :: IEEE_ARITHMETIC
      USE, INTRINSIC :: IEEE_EXCEPTIONS
      IMPLICIT NONE
      INTEGER FLAGS(5),HALTS(5),ROUNDING,I
      LOGICAL VALUE
      TYPE(IEEE_FLAG_TYPE),PARAMETER :: OBSERVED(5)=
     $ [IEEE_INVALID,IEEE_DIVIDE_BY_ZERO,IEEE_OVERFLOW,
     $ IEEE_UNDERFLOW,IEEE_INEXACT]
      TYPE(IEEE_ROUND_TYPE) MODE
      FLAGS=-1
      HALTS=-1
      DO I=1,5
         IF(IEEE_SUPPORT_FLAG(OBSERVED(I),0D0)) THEN
            CALL IEEE_GET_FLAG(OBSERVED(I),VALUE)
            FLAGS(I)=0
            IF(VALUE) FLAGS(I)=1
         ENDIF
         IF(IEEE_SUPPORT_HALTING(OBSERVED(I))) THEN
            CALL IEEE_GET_HALTING_MODE(OBSERVED(I),VALUE)
            HALTS(I)=0
            IF(VALUE) HALTS(I)=1
         ENDIF
      ENDDO
      CALL IEEE_GET_ROUNDING_MODE(MODE)
      ROUNDING=-1
      IF(MODE.EQ.IEEE_NEAREST) ROUNDING=0
      IF(MODE.EQ.IEEE_UP) ROUNDING=1
      IF(MODE.EQ.IEEE_DOWN) ROUNDING=2
      IF(MODE.EQ.IEEE_TO_ZERO) ROUNDING=3
      IF(MODE.EQ.IEEE_OTHER) ROUNDING=4
      END

      SUBROUTINE BENCHMARK_BULK_WRITE_IEEE(LUN,SEQUENCE,
     $ OCCURRENCE,PHASE,POINT,EDGE,ROUNDING,FLAGS,HALTS)
      IMPLICIT NONE
      INTEGER LUN,SEQUENCE,OCCURRENCE,PHASE,POINT,EDGE,ROUNDING
      INTEGER FLAGS(5),HALTS(5)
      WRITE(LUN,'(A,16I12)') 'IEEE ',SEQUENCE,OCCURRENCE,
     $ PHASE,POINT,EDGE,ROUNDING,FLAGS,HALTS
      END
"""


def _replace(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Worker source anchor is not unique")
    return text.replace(old, new, 1)


def _transform(base, command, declarations, suffix):
    if not isinstance(base, str):
        raise TypeError("Expected the exact UTF-8 worker text")
    if hashlib.sha256(base.encode("utf-8")).hexdigest() != BASE_SHA256:
        raise ValueError("Frozen generated worker source changed")
    result = _replace(base, "      CHARACTER*16 COMMAND\n",
                      "      CHARACTER*16 COMMAND\n" +
                      COMMON_DECLARATIONS + declarations)
    dispatch = """      READ(5,'(A)',IOSTAT=IOS) BULK_COMMAND_LINE
      IF(IOS.LT.0) GOTO 900
      IF(IOS.NE.0) GOTO 800
      READ(BULK_COMMAND_LINE,*,IOSTAT=IOS) COMMAND
      IF(IOS.NE.0) GOTO 800
      IF(TRIM(COMMAND).EQ.'STOP') GOTO 900
""" + command + """      READ(BULK_COMMAND_LINE,*,IOSTAT=IOS)
     $ COMMAND,SEQUENCE,NLOOPS
      IF(IOS.NE.0) GOTO 800
"""
    result = _replace(result, READ_PREFIX, dispatch)
    result += PARSE_HELPER + WORDS_HELPER + suffix
    for line in result.splitlines():
        if line and line[0] not in "Cc*!" and len(line) > 72:
            raise ValueError("Fixed-form code exceeds column72")
    return result


def parity_driver(base):
    """Add PARITY seq; exactly anchors1/16 followed by all100 saved points."""
    return _transform(base, PARITY_COMMAND, PARITY_DECLARATIONS, IEEE_HELPERS)


def timings_driver(base):
    """Add ANCHORRUN seq point loops; no IEEE or wire observer instrumentation."""
    return _transform(base, TIMING_COMMAND, "", "")
