"""Small synthetic source fixtures only. No MG module or CLI is imported."""
from contextlib import ExitStack
import hashlib
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pure_bootstrap_closure', HERE/'bootstrap_closure.py')
B = importlib.util.module_from_spec(spec)
spec.loader.exec_module(B)


class Bootstrap(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        for module, names in ((subprocess, ('run', 'Popen', 'check_output', 'check_call', 'call')),
                              (os, ('system', 'popen', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp',
                                    'execl', 'execle', 'execlp', 'execlpe', 'execv', 'execve', 'execvp', 'execvpe'))):
            for name in names:
                if hasattr(module, name):
                    self.stack.enter_context(mock.patch.object(module, name, side_effect=AssertionError('External execution forbidden')))
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='bootstrap-test-', dir=HERE)))

    def files(self, source):
        for name, text in source.items():
            path = self.root/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(text.encode())
        return set(source)

    def test_absolute_relative_and_package_initializers(self):
        declared = self.files({'bin/madgraph': 'import pkg.sub.main\n',
            'pkg/__init__.py': 'from . import seed\n', 'pkg/seed.py': 'VALUE=1\n',
            'pkg/sub/__init__.py': '', 'pkg/sub/main.py': 'from .. import sibling\n', 'pkg/sibling.py': ''})
        report = B.analyze(self.root, declared, set(), {})
        self.assertEqual(report['visited_count'], 6)
        self.assertEqual(report['missing_local_files'], [])
        self.assertTrue(report['declared_local_import_closure_pass'])
        self.assertEqual(report['visited_files']['pkg/sibling.py']['sha256'], hashlib.sha256(b'').hexdigest())

    def test_lazy_imports_are_conservative_and_scope_labelled(self):
        source = {'bin/madgraph': 'import pkg\n', 'pkg/__init__.py': 'def unused():\n import pkg.lazy\n',
                  'pkg/lazy.py': 'raise RuntimeError("Never execute this fixture")\n'}
        declared = self.files(source)
        report = B.analyze(self.root, declared-{'pkg/lazy.py'}, set(), {})
        self.assertEqual(report['missing_local_files'], ['pkg/lazy.py'])
        self.assertEqual(report['missing_count'], 1)
        self.assertFalse(report['declared_local_import_closure_pass'])
        self.assertTrue(any(row['scope'] == 'function:unused' and row['target_file'] == 'pkg/lazy.py' for row in report['edges']))
        successor = B.analyze(self.root, declared-{'pkg/lazy.py'}, {'pkg/lazy.py'}, {})
        self.assertEqual(successor['missing_count'], 0)

    def test_transitive_missing_catalogue_sources_are_read_without_execution(self):
        declared = self.files({'bin/madgraph': 'import pkg.first\n', 'pkg/__init__.py': '',
            'pkg/first.py': 'import pkg.second\n', 'pkg/second.py': 'assert False\n'})
        report = B.analyze(self.root, {'bin/madgraph'}, set(), {})
        self.assertEqual(report['missing_local_files'], ['pkg/__init__.py', 'pkg/first.py', 'pkg/second.py'])
        self.assertEqual(report['visited_count'], 4)

    def test_overlay_bytes_are_authoritative_for_import_edges(self):
        declared = self.files({'bin/madgraph': 'import pkg.worker\n', 'pkg/__init__.py': '',
            'pkg/worker.py': '', 'pkg/extra.py': '', 'candidate/worker.py': 'from . import extra\n'})
        declared -= {'candidate/worker.py', 'pkg/extra.py'}
        report = B.analyze(self.root, declared, set(), {'pkg/worker.py': {'source': 'candidate/worker.py'}})
        self.assertEqual(report['missing_local_files'], ['pkg/extra.py'])
        self.assertEqual(report['visited_files']['pkg/worker.py']['source'], 'candidate/worker.py')
        self.assertEqual(report['visited_files']['pkg/worker.py']['origin'], 'overlay')

    def test_from_package_attribute_does_not_invent_module(self):
        declared = self.files({'bin/madgraph': 'from pkg import VALUE\n', 'pkg/__init__.py': 'VALUE=3\n'})
        report = B.analyze(self.root, declared, set(), {})
        self.assertEqual(report['visited_count'], 2)
        self.assertEqual(report['missing_local_files'], [])

    def test_fixed_trex_import_and_find_spec_alias_policy_is_explicit(self):
        declared = self.files({'bin/madgraph': 'import madmatrix.trex\n', 'madmatrix/__init__.py': '',
            'madmatrix/trex.py': "__import__('%s.output'%PLUGIN_NAME)\n__import__('%s.model_handling'%PLUGIN_NAME)\nimportlib.util.find_spec('madgraph.iolibs.export_cpp')\nSPEC_EXPORTCPP.loader.exec_module(PLUGIN_export_cpp)\n",
            'madmatrix/output.py': '', 'madmatrix/model_handling.py': '', 'madgraph/__init__.py': '',
            'madgraph/iolibs/__init__.py': '', 'madgraph/iolibs/export_cpp.py': ''})
        report = B.analyze(self.root, declared, set(), {})
        self.assertEqual(report['visited_count'], 8)
        self.assertEqual(len(report['dynamic_imports']), 4)
        self.assertTrue(all(row['policy'] and not row['execution_observed'] for row in report['dynamic_imports']))
        self.assertEqual(report['missing_local_files'], [])
        self.assertFalse(report['executed_import_completeness_claimed'])

    def test_unresolved_nonliteral_imports_are_retained(self):
        declared = self.files({'bin/madgraph': '__import__(requested_name)\n', 'pkg/__init__.py': ''})
        report = B.analyze(self.root, declared, set(), {})
        self.assertEqual(report['nonliteral_import_count'], 1)
        self.assertIsNone(report['dynamic_imports'][0]['policy'])
        self.assertEqual(report['dynamic_imports'][0]['expression'], '__import__(requested_name)')

    def test_invalid_declarations_and_syntax_are_not_passes(self):
        declared = self.files({'bin/madgraph': 'import pkg\n', 'pkg/__init__.py': 'bad +\n'})
        report = B.analyze(self.root, declared, set(), {})
        self.assertEqual(len(report['errors']), 1)
        self.assertFalse(report['declared_local_import_closure_pass'])
        with self.assertRaises(ValueError):
            B.analyze(self.root, declared, {'pkg/__init__.py'}, {})
        with self.assertRaises(ValueError):
            B.analyze(self.root, declared, set(), {'pkg/__init__.py': {'source': '../outside.py'}})


if __name__ == '__main__':
    unittest.main()
