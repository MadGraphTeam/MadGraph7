"""Conservative local Python import inventory, using source bytes and AST only.

The root must be a complete checkout used as a module catalogue. The declared
scientific/bootstrap/overlay union is audited against that catalogue, including
missing declared modules' source, to expose transitive omissions in one pass.
No imported program, package initializer, loader or CLI is executed.
"""
import ast
import hashlib
from pathlib import Path, PurePosixPath


def require(value, message):
    if not value:
        raise ValueError(message)


def relative_path(value):
    require(isinstance(value, str) and value and '\\' not in value, 'Expected relative POSIX path')
    path = PurePosixPath(value)
    require(not path.is_absolute() and '..' not in path.parts and str(path) == value,
            'Source path must remain beneath the checkout')
    return value


def source_bytes(root, relative):
    path = root / relative_path(relative)
    require(path.resolve().is_relative_to(root), 'Source symlink escapes checkout: ' + relative)
    return path.read_bytes()


def module_catalog(root):
    modules = {}
    packages = []
    for directory in sorted(root.iterdir()):
        if not directory.is_dir() or directory.name.startswith('.') or not (directory/'__init__.py').is_file():
            continue
        packages.append(directory.name)
        for path in sorted(directory.rglob('*.py')):
            require(path.resolve().is_relative_to(root), 'Module catalogue symlink escapes checkout')
            relative = path.relative_to(root).as_posix()
            name = relative[:-3].replace('/', '.')
            if name.endswith('.__init__'):
                name = name[:-9]
            require(name not in modules, 'Ambiguous local module: ' + name)
            modules[name] = relative
    return modules, packages


class SourceImports(ast.NodeVisitor):
    """Collect every import, even in lazy functions and untaken branches."""
    def __init__(self):
        self.imports = []
        self.dynamic = []
        self.scope = []

    def visit_Import(self, node):
        self.imports.append((node, 'module' if not self.scope else '/'.join(self.scope)))

    visit_ImportFrom = visit_Import

    def definition(self, node, kind):
        self.scope.append(kind + ':' + node.name)
        self.generic_visit(node)
        self.scope.pop()

    def visit_FunctionDef(self, node):
        self.definition(node, 'function')

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.definition(node, 'class')

    def visit_Call(self, node):
        function = ast.unparse(node.func)
        if ((isinstance(node.func, ast.Name) and node.func.id == '__import__') or
                (isinstance(node.func, ast.Attribute) and node.func.attr in
                 ('import_module', 'find_spec', 'spec_from_file_location', 'exec_module', 'load_module'))):
            self.dynamic.append((node, function, 'module' if not self.scope else '/'.join(self.scope)))
        self.generic_visit(node)


def requested_modules(node, importer):
    if isinstance(node, ast.Import):
        return [item.name for item in node.names]
    package = importer[:-9] if importer.endswith('.__init__') else importer.rsplit('.', 1)[0]
    if node.level:
        parts = package.split('.')
        require(node.level <= len(parts), 'Relative import escapes local package')
        base = '.'.join(parts[:len(parts)-node.level+1])
        if node.module:
            base += '.' + node.module
    else:
        base = node.module or ''
    return [base] + [base + '.' + item.name for item in node.names if item.name != '*']


def finite_dynamic_targets(relative, node, function):
    """Two exact source-visible trex imports and its export_cpp loader alias.

    This policy describes dependency names, not execution safety or semantics.
    Arbitrary plugin/model names and native wrappers remain unresolved below.
    """
    if relative == 'madmatrix/trex.py':
        if (function == '__import__' and node.args and isinstance(node.args[0], ast.BinOp)
                and isinstance(node.args[0].op, ast.Mod) and isinstance(node.args[0].left, ast.Constant)
                and isinstance(node.args[0].right, ast.Name) and node.args[0].right.id == 'PLUGIN_NAME'):
            value = node.args[0].left.value
            if value in ('%s.output', '%s.model_handling'):
                return [value.replace('%s', 'madmatrix')], 'fixed-madmatrix-package-name-v1'
        if (function == 'importlib.util.find_spec' and len(node.args) == 1
                and isinstance(node.args[0], ast.Constant) and node.args[0].value == 'madgraph.iolibs.export_cpp'):
            return ['madgraph.iolibs.export_cpp'], 'fixed-export-cpp-spec-v1'
        if function == 'SPEC_EXPORTCPP.loader.exec_module':
            if len(node.args) == 1 and isinstance(node.args[0], ast.Name) and node.args[0].id == 'PLUGIN_export_cpp':
                return ['madgraph.iolibs.export_cpp'], 'fixed-export-cpp-loader-alias-v1'
    if (node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str)
            and (function == '__import__' or function.endswith(('.import_module', '.find_spec')))):
        return [node.args[0].value], 'literal-import-name-v1'
    return [], None


def analyze(root, scientific_files, bootstrap_files, overlay_files):
    """Return JSON-safe audit. Callers MUST reject missing_local_files/errors.

    Maps/sets are interpreted by their relative destination keys. Each overlay
    value must additionally supply a checkout-relative candidate `source` path.
    """
    root = Path(root).resolve()
    scientific = {relative_path(name) for name in scientific_files}
    bootstrap = {relative_path(name) for name in bootstrap_files}
    overlay = {relative_path(name): row for name, row in overlay_files.items()}
    require(scientific.isdisjoint(bootstrap), 'Scientific and bootstrap declarations overlap')
    for name, row in overlay.items():
        require(isinstance(row, dict) and isinstance(row.get('source'), str), 'Overlay requires source path: ' + name)
        relative_path(row['source'])
    declared = scientific | bootstrap | set(overlay)
    catalog, package_roots = module_catalog(root)
    entrypoint = 'bin/madgraph'
    todo = [entrypoint]
    visited = {}
    missing = set()
    edges = {}
    dynamics = []
    errors = []

    def edge(importer, line, target, syntax, scope, kind='static-import'):
        parts = target.split('.')
        for count in range(1, len(parts)+1):
            module = '.'.join(parts[:count])
            if module not in catalog:
                continue  # from-package attributes need not be submodules.
            destination = catalog[module]
            record = {'importer': importer, 'line': line, 'module': module,
                      'target_file': destination, 'syntax': syntax, 'scope': scope, 'kind': kind}
            edges[(importer, line, module, kind)] = record
            if destination not in visited:
                todo.append(destination)

    while todo:
        relative = todo.pop()
        if relative in visited:
            continue
        if relative not in declared:
            missing.add(relative)
        path = overlay.get(relative, {}).get('source', relative)
        data = source_bytes(root, path)
        origin = 'overlay' if relative in overlay else 'scientific' if relative in scientific else 'bootstrap' if relative in bootstrap else 'undeclared-catalogue-source'
        visited[relative] = {'source': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                             'declared': relative in declared, 'origin': origin}
        try:
            tree = ast.parse(data, filename=relative)
        except (SyntaxError, UnicodeError) as error:
            errors.append({'file': relative, 'error': str(error)})
            continue
        visitor = SourceImports()
        visitor.visit(tree)
        module_name = relative[:-3].replace('/', '.') if relative.endswith('.py') else relative.replace('/', '.')
        for node, scope in visitor.imports:
            for target in requested_modules(node, module_name):
                edge(relative, node.lineno, target, ast.unparse(node), scope)
        for node, function, scope in visitor.dynamic:
            targets, policy = finite_dynamic_targets(relative, node, function)
            record = {'file': relative, 'line': node.lineno, 'scope': scope, 'expression': ast.unparse(node),
                      'targets': targets, 'policy': policy, 'execution_observed': False,
                      'nonliteral_or_unresolved': policy is None}
            dynamics.append(record)
            for target in targets:
                edge(relative, node.lineno, target, record['expression'], scope, 'finite-dynamic-name-policy')
    return {'schema': 'source-only-CLI-bootstrap-import-closure-v1', 'entrypoint': entrypoint,
            'scope': 'Conservative all-AST local import names, including lazy functions and untaken branches; no Python package executed.',
            'catalog_package_roots': package_roots, 'catalog_module_count': len(catalog),
            'declaration_counts': {'scientific': len(scientific), 'bootstrap': len(bootstrap),
                                   'overlay': len(overlay), 'union': len(declared)},
            'visited_count': len(visited), 'missing_count': len(missing),
            'missing_local_files': sorted(missing), 'errors': errors,
            'declared_local_import_closure_pass': not missing and not errors,
            'visited_files': dict(sorted(visited.items())),
            'edges': sorted(edges.values(), key=lambda row: (row['importer'], row['line'], row['module'], row['kind'])),
            'dynamic_imports': sorted(dynamics, key=lambda row: (row['file'], row['line'], row['expression'])),
            'nonliteral_import_count': sum(row['nonliteral_or_unresolved'] for row in dynamics),
            'executed_import_completeness_claimed': False, 'MG_imports_executed': 0,
            'compiler_calls': 0, 'native_calls': 0,
            'limitations': ['Catalogue discovery requires a complete source checkout, not an already truncated staging directory.',
                'Known local imports are discovered from source files; absent filesystem modules and from-package attribute ambiguities cannot be resolved in general.',
                'Nonliteral plugin/model/native-wrapper imports remain recorded limitations. This does not prove that every runtime import succeeds.',
                'Optional MadSpin and madmatrix routes are included conservatively; no claim they execute during the requested n3 generation.',
                'The empty PLUGIN directory and non-Python startup/model/template assets need separate declared inventory checks.',
                'Third-party/standard-library availability, module-level side effects and native loaders are not executed or qualified.']}
