"""Pure preflight/contract tests; no CLI or compiler execution."""
import hashlib
import builtins
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from contextlib import nullcontext
from unittest.mock import Mock, patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qpmass_cli_tested',HERE/'controller.py')
controller=importlib.util.module_from_spec(spec)
spec.loader.exec_module(controller)


class ControllerTests(unittest.TestCase):
    def test_actual_preflight_process_creation_blocked(self):
        controller.EXPECTED=controller.sha(HERE/'source-index.json')
        original_import=builtins.__import__
        def import_guard(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','mg5decay','MadSpin','madmatrix','aloha','PLUGIN'}:
                raise AssertionError('MG package import execution blocked: '+name)
            return original_import(name,*args,**kwargs)
        with patch.object(subprocess,'Popen',side_effect=AssertionError('process creation blocked')), \
             patch.object(os,'system',side_effect=AssertionError('system blocked')), \
             patch.object(os,'fork',side_effect=AssertionError('fork blocked')), \
             patch.object(os,'execv',side_effect=AssertionError('exec blocked')), \
             patch.object(os,'execve',side_effect=AssertionError('exec blocked')), \
             patch.object(builtins,'__import__',side_effect=import_guard):
            result=controller.verify_source()
        self.assertEqual(result['source_bindings'],2666)
        self.assertEqual(result['CLI_invocations'],0)
        self.assertEqual(result['compiler_queries'],0)
        self.assertEqual(result['scientific_native_calls'],0)
        self.assertEqual(result['bootstrap_bindings'],12)
        self.assertEqual(result['bootstrap_static_closure']['visited_count'],129)
        self.assertEqual(result['bootstrap_static_closure']['missing_count'],0)
        self.assertEqual(result['bootstrap_static_closure']['errors'],[])

    def test_exact_numerical_scope(self):
        rows=(HERE/'generate.mg5').read_text().splitlines()
        self.assertEqual(rows[-4:-2],['import model loop_sm','generate u u~ > z g g [virt=QCD]'])
        self.assertEqual(sum(x.startswith('output ') for x in rows),1)
        self.assertTrue(rows[-2].endswith(' -nojpeg'))
        self.assertFalse(any(x.startswith(('launch','check','install')) for x in rows))
        self.assertTrue(all(x.endswith(' --no_save') for x in rows if x.startswith('set ')))
        self.assertIn('set nb_core 1 --no_save',rows)

    def test_frozen_caps_and_no_source_staging_in_default_preflight(self):
        self.assertEqual((controller.CPU,controller.CAP,controller.CLEANUP),(12,300.,60.))
        self.assertEqual(controller.LIMITS,{'address_space_bytes':16*1024**3,
            'file_bytes':512*1024**2,'core_bytes':0})
        self.assertFalse(controller.WORK.exists())
        self.assertFalse(controller.REPORT.exists())

    def test_real_overlay_counts(self):
        row=controller.pin()
        self.assertEqual(row['overlay_counts'],{'existing_payloads':7,'new_payloads':2,
            'changed_existing_payloads':3,'unchanged_existing_payloads':4})
        self.assertEqual(len(row['overlay_files']),9)
        self.assertEqual(sum(p['sha256'] is None for p in row['source_files'].values()),2)

    def test_additional_bootstrap_is_separate_and_git_authenticated(self):
        row=controller.pin();extra=row['bootstrap_files']
        self.assertEqual(len(extra),12)
        self.assertFalse(set(extra)&set(row['source_files']))
        self.assertEqual({name for name in extra if name.startswith('mg5decay/')},
            {'mg5decay/__init__.py','mg5decay/decay_objects.py'})
        self.assertEqual(sum(name.startswith('MadSpin/') for name in extra),3)
        self.assertEqual(sum(name.startswith('madmatrix/') for name in extra),6)
        self.assertEqual(extra['PLUGIN/__init__.py']['bytes'],0)
        for name,record in extra.items():
            data=(controller.ROOT/name).read_bytes()
            self.assertEqual(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),
                record['git_blob_sha1'])
            self.assertEqual(record['anchor'],'0fcd2cd873d61d134837e1d9e87afb13a47824fd')

    def test_strict_record_and_missing_link_checks(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'file';path.write_text('proof')
            record={'sha256':hashlib.sha256(b'proof').hexdigest(),'bytes':5}
            controller.verify_record(path,record)
            with self.assertRaises(ValueError):controller.verify_record(path,{**record,'sha256':'0'*64})
            link=Path(directory)/'missing';link.symlink_to('absent')
            controller.verify_record(link,{'sha256':None,'link':'absent'})
            with self.assertRaises(ValueError):controller.verify_record(link,{'sha256':None,'link':'other'})

    def test_exact_inventory_rejects_extras_aliases_and_empty_directories(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'source-index.json').write_text('{}')
            (root/'one.py').write_text('source')
            index={'files':{'one.py':{}}}
            with patch.object(controller,'HERE',root):
                controller.verify_payload_inventory(index)
                (root/'extra').write_text('extra')
                with self.assertRaises(ValueError):controller.verify_payload_inventory(index)
                (root/'extra').unlink()
                (root/'one.py').unlink();(root/'one.py').symlink_to('source-index.json')
                with self.assertRaises(ValueError):controller.verify_payload_inventory(index)
                (root/'one.py').unlink();(root/'one.py').write_text('source')
                (root/'empty').mkdir()
                with self.assertRaises(ValueError):controller.verify_payload_inventory(index)
                (root/'empty').rmdir();(root/'one.py').unlink()
                with self.assertRaises(ValueError):controller.verify_payload_inventory(index)

    def test_successful_popen_then_owned_init_failure_runs_raw_fallback(self):
        process=Mock(pid=123)
        record={'pid':123,'process_group':123,'session':123,'start_time':999}
        cleanup=Mock()
        cleanup.SignalRequests.side_effect=lambda:nullcontext(Mock())
        cleanup.identity.return_value=record
        cleanup.OwnedChild.side_effect=RuntimeError('owned constructor failure')
        deadline=types.SimpleNamespace(end=1.e30,handoff=False,deferred=False)
        clock=types.SimpleNamespace(StageDeadline=lambda:nullcontext(deadline))
        ownership=types.SimpleNamespace(raw_cleanup=Mock(return_value={
            'failure_only':True,'uncertainty_blocks_later_stages':True}))
        def helper(name,path):
            return {controller.CLEANUP_HELPER:cleanup,controller.DEADLINE_HELPER:clock,
                str(controller.HERE/'ownership.py'):ownership}[str(path.relative_to(controller.ROOT))
                    if path.is_relative_to(controller.ROOT) and path.name!='ownership.py' else str(path)]
        with tempfile.TemporaryDirectory() as directory:
            report=Path(directory)/'execution'
            with patch.object(controller,'REPORT',report), \
                 patch.object(controller,'WORK',Path(directory)/'work'), \
                 patch.object(controller,'EXPECTED','sealed-test'), \
                 patch.object(controller,'load',side_effect=helper), \
                 patch.object(controller,'limits'), \
                 patch.object(controller,'verify_source',return_value={}), \
                 patch.object(controller,'environment',return_value={}), \
                 patch.object(controller,'tool',side_effect=lambda name:'/pinned/'+name), \
                 patch.object(subprocess,'Popen',return_value=process) as popen:
                with self.assertRaisesRegex(RuntimeError,'owned constructor failure'):
                    controller.supervise()
            popen.assert_called_once()
            self.assertTrue(popen.call_args.kwargs['start_new_session'])
            cleanup.identity.assert_called_once_with(123)
            cleanup.OwnedChild.assert_called_once_with(process)
            ownership.raw_cleanup.assert_called_once_with(process,record,cleanup,deadline.end)
            terminal=json.loads((report/'terminal.json').read_text())
            self.assertEqual(terminal['status'],'failed')
            self.assertTrue(terminal['cleanup']['failure_only'])
            self.assertTrue(terminal['cleanup']['uncertainty_blocks_later_stages'])
            self.assertFalse((report/'result.json').exists())


if __name__=='__main__':
    unittest.main()
