"""Independent fixed-form source correspondence; no MG imports or native calls."""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[2]
PROPOSAL=ROOT/'.tirust-build/qp-mass-cli-generation-proposal-3'
EXECUTION=ROOT/'.tirust-build/qp-mass-cli-generation-execution-3'
FILES=('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f')


def require(value,message):
    if not value:raise ValueError(message)


def canon(value):
    """Only external blanks/case disappear; quoted literal bytes remain exact."""
    output=[];quote=None;i=0
    while i<len(value):
        c=value[i]
        if quote is not None:
            output.append(c)
            if c==quote:
                if i+1<len(value) and value[i+1]==quote:
                    output.append(value[i+1]);i+=1
                else:quote=None
        elif c in "'\"":quote=c;output.append(c)
        elif not c.isspace():output.append(c.upper())
        i+=1
    require(quote is None,'Unterminated quoted literal')
    return ''.join(output)


def statements(text):
    """Read fixed columns, preserving every numeric label and statement order."""
    rows=[];active=None
    for line_number,line in enumerate(text.splitlines(keepends=True),1):
        raw=line.rstrip('\r\n')
        if not raw.strip():continue
        if raw[0] in 'Cc*!':
            require(not raw.startswith(('C$','c$','!$','*$')),'Directive needs separate review')
            continue
        require('\t' not in raw,'Tabs need separate fixed-column review')
        require(not raw[132:].strip(),'Executable content past column132')
        require(len(raw)>=6,'Short executable fixed-form line')
        label=raw[:5].strip();continuation=raw[5] not in ' 0'
        require(not label or label.isdigit(),'Invalid statement label')
        payload=raw[6:132].strip()
        # Reject cross-physical-line character literals rather than silently
        # assume padding/continuation semantics from a whitespace canonicalizer.
        canon(payload)
        if continuation:
            require(active is not None and not label,'Orphan/labeled continuation')
            active['physical'].append(line_number);active['parts'].append(payload)
        else:
            active={'label':label,'parts':[payload],'physical':[line_number]};rows.append(active)
    for row in rows:row['code']=canon(' '.join(row.pop('parts')))
    return rows


def units(text):
    records=statements(text);found={};active=None;raw=text.splitlines(keepends=True)
    for row in records:
        code=row['code']
        match=re.fullmatch(r'SUBROUTINE([A-Z0-9_]+)\((.*)\)',code)
        block=re.fullmatch(r'BLOCKDATA([A-Z0-9_]+)',code)
        if match or block:
            require(active is None,'Nested Fortran unit')
            name=(match or block)[1];require(name not in found,'Duplicate unit')
            active={'name':name,'rows':[],'first':row['physical'][0],
                'args':arguments(match[2]) if match else []}
        require(active is not None,'Executable statement outside reviewed unit')
        active['rows'].append(row)
        if code=='END':
            active['raw']=''.join(raw[active['first']-1:row['physical'][-1]])
            found[active['name']]=active;active=None
    require(active is None,'Unterminated unit')
    return found


def arguments(text):
    result=[];level=0;start=0;quote=None;i=0
    while i<len(text):
        c=text[i]
        if quote:
            if c==quote:
                if i+1<len(text) and text[i+1]==quote:i+=1
                else:quote=None
        elif c in "'\"":quote=c
        elif c=='(':level+=1
        elif c==')':level-=1;require(level>=0,'Unbalanced call arguments')
        elif c==',' and level==0:result.append(text[start:i]);start=i+1
        i+=1
    require(not quote and level==0,'Unbalanced final call argument')
    return result+[text[start:]]


def signature(row):return [(item['label'],item['code']) for item in row['rows']]


def review():
    pins=json.loads((PROPOSAL/'input-pins.json').read_text())
    actual=ROOT/'.tirust-build/qp-mass-cli-generation-work-3/output/qcd_n3_uux_zgg/SubProcesses/P0_uux_zgg'
    old=Path(pins['original_generated_dir']);expected=Path(pins['preview_candidate_dir'])
    report={'schema':'independent-fixed-form-QP-mass-source-correspondence-v1',
        'scope':'Only the three special mass-transport units; complete195-unit change/build scope is separate.',
        'public':{},'private':{},'caller':{},'MG_imports':0,'native_calls':0}
    actual_units={name:units((actual/name).read_bytes().decode()) for name in FILES}
    old_units={name:units((old/name).read_bytes().decode()) for name in FILES}
    interleaved=[]
    for symbol in old_units[FILES[0]]:
        interleaved.append(symbol)
        if re.fullmatch(r'ML5_0_LOOP_\d+(?:_\d+)?',symbol):interleaved.append(symbol+'_QPMASS')
    require(list(actual_units[FILES[0]])==interleaved,'Private helper interleaving differs')
    report['CT_private_interleaving_only_routine_order_change']=True
    for name in FILES[:2]:
        observed=actual_units[name];baseline=old_units[name];materialized=units((expected/name).read_bytes().decode())
        require(set(baseline)<=set(observed),'Missing public legacy unit')
        for symbol,unit in baseline.items():
            require(unit['raw']==observed[symbol]['raw'],'Public legacy raw bytes changed: '+symbol)
            report['public'][symbol]={'raw_bytes_exact':True,'statement_count':len(unit['rows'])}
        require(set(observed)-set(baseline)==set(materialized)-set(baseline),'Private name family changed')
        for symbol in set(observed)-set(baseline):
            require(signature(observed[symbol])==signature(materialized[symbol]),'Private labeled/literal statement mismatch: '+symbol)
            report['private'][symbol]={'labels_literals_statements_control_order_exact':True,
                'raw_bytes_exact':observed[symbol]['raw']==materialized[symbol]['raw'],
                'statement_count':len(observed[symbol]['rows'])}
    original_caller=next(iter(old_units[FILES[2]].values()))
    current_caller=next(iter(actual_units[FILES[2]].values()))
    expected_caller=next(iter(units((expected/FILES[2]).read_bytes().decode()).values()))
    require(signature(current_caller)==signature(expected_caller),'Caller labeled/literal statement mismatch')
    records=current_caller['rows'];stripped=[];calls=[];masses=collections.Counter();i=0
    while i<len(records):
        row=records[i]
        if row['code']=='IF(CTMODE.LT.4)THEN':
            require(i+4<len(records),'Truncated guard')
            group=records[i:i+5];require(all(not x['label'] for x in group),'Guard labels need separate review')
            require(group[2]['code']=='ELSE' and group[4]['code']=='ENDIF','Guard branch structure differs')
            match=re.fullmatch(r'CALL(ML5_0_LOOP_\d+(?:_\d+)?)\((.*)\)',group[1]['code'])
            require(match,'Missing original DP call')
            symbol=match[1];args=arguments(match[2]);formals=old_units[FILES[0]][symbol]['args'];require(len(args)==len(formals),'DP argument arity differs')
            n=int(re.search(r'_LOOP_(\d+)',symbol)[1]);paired=[];pairs=[]
            for formal,arg in zip(formals,args,strict=True):
                paired.append(arg)
                if re.fullmatch(r'M\d+',formal):
                    mass=re.fullmatch(r'DCMPLX\((ZERO|MDL_MB|MDL_MT)\)',arg)
                    require(mass,'Unexpected physical mass expression')
                    mp='CMPLX(MP__'+mass[1]+',KIND=16)';paired.append(mp)
                    pairs.append({'formal':formal,'DP':arg,'MP':mp});masses[mass[1]]+=1
            require(len(pairs)==n,'Not all denominator masses paired')
            require(group[3]['code']=='CALL'+symbol+'_QPMASS('+','.join(paired)+')','QP call argument/symbol order differs')
            calls.append({'id':int(args[-1]),'entrypoint':symbol,'rank':int(args[-3]),'n':n,'mass_pairs':pairs})
            stripped.append(group[1]);i+=5;continue
        if row['code'] in ('REAL*8LSCALE','INTEGERCTMODE','COMMON/ML5_0_CT/LSCALE,CTMODE'):
            i+=1;continue
        stripped.append(row);i+=1
    require([(r['label'],r['code']) for r in stripped]==signature(original_caller),
        'Caller outside reviewed guards/three COMMON declarations changed')
    require(len(calls)==116 and sorted(c['id'] for c in calls)==list(range(1,117)),'Incomplete guarded group coverage')
    require(masses=={'ZERO':293,'MDL_MB':43,'MDL_MT':43},'Physical mass argument inventory changed')
    helpers={}
    for symbol,unit in actual_units[FILES[0]].items():
        if not symbol.endswith('_QPMASS'):continue
        n=int(re.search(r'_LOOP_(\d+)',symbol)[1]);code=[r['code'] for r in unit['rows']]
        choose=next(i for i,v in enumerate(code) if v.startswith('CALLML5_0_CHOOSE_LOOPLIB('))
        expected_squares=['IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.9)THEN',
            'MP_M2L(1)=MP_M'+str(n)+'**2']+['MP_M2L('+str(j)+')=MP_M'+str(j-1)+'**2' for j in range(2,n+1)]+['ENDIF']
        require(code[choose+1:choose+len(expected_squares)+1]==expected_squares,
            'Actual-selected-backend cyclic QP square block differs')
        original=old_units[FILES[0]][symbol.removesuffix('_QPMASS')]
        old_calls=[r['code'] for r in original['rows'] if r['code'].startswith('CALL')]
        new_calls=[];delegation=0
        for statement in code:
            if not statement.startswith('CALL'):continue
            if statement.startswith('CALL'+symbol.removesuffix('_QPMASS')+'('):
                require(statement=='CALL'+symbol.removesuffix('_QPMASS')+'('+','.join(original['args'])+')',
                    'Defensive DP delegation arguments differ')
                delegation+=1;continue
            if statement.startswith('CALLML5_0_MP_TIRUST_LOOP_QPMASS('):
                statement=statement.replace('MP_TIRUST_LOOP_QPMASS(', 'MP_TIRUST_LOOP(').replace(
                    ',MP_PL,MP_M2L,RANK',',MP_PL,M2L,RANK')
            new_calls.append(statement)
        require(delegation==1 and old_calls==new_calls,'Legacy backend call ordering/arguments differ')
        helpers[symbol]={'n':n,'selected_backend9_guard_after_choose':True,'cyclic_square_order':[n]+list(range(1,n)),
            'all_legacy_backend_call_arguments_and_order_preserved_except_intentional_TIRust_QP_mass_route':True,
            'single_exact_defensive_DP_delegation':True}
    report['helpers']=helpers;report['caller']={'guarded_groups':len(calls),'group_ids_1_through116':True,
        'all_original_DP_and_paired_QP_actuals_exact':True,'outside_guard_and_three_declaration_statements_exact':True,
        'labels_literals_statement_order_exact_to_materialization':True,'mass_argument_counts':dict(masses),'groups':calls}
    report['counts']={'public_raw_exact':len(report['public']),'private_statement_exact':len(report['private']),
        'private_helpers':len(helpers),'caller_groups':len(calls)}
    require(report['counts']=={'public_raw_exact':25,'private_statement_exact':9,'private_helpers':7,'caller_groups':116},'Unexpected reviewed unit counts')
    report['source_correspondence_pass']=True
    report['limits']=['This concrete fixed-form statement correspondence is not a compiler result, physical/numerical qualification, complete195-unit semantic audit, or native admission.',
        'Raw private/caller/whole-file differences remain retained. Only full-line ordinary comments and external blanks/case are absent in this independent logical record; labels, quoted literal bytes and all statements/order remain exact.',
        'Cross-physical-line character literals, tabs, directives and source beyond column132 reject rather than silently normalize.']
    return report


if __name__=='__main__':print(json.dumps(review(),indent=2,sort_keys=True))
