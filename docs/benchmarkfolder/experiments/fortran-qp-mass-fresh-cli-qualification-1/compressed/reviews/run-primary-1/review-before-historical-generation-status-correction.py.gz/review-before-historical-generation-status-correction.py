from pathlib import Path
import ast,collections,ctypes,hashlib,importlib.util,json,math,os,re,struct,subprocess,sys,time
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-proposal-1';REPORT=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-execution-1/run';OUT=ROOT/'.tirust-build/qp-mass-fresh-cli-run-independent-audit-1'
SOURCE='c2acf316159ab0c12ab775b4ca92ff0d0eaa122a29db602deb629bae93da4450';BUILD='6357ea74762033e7f5b00c897dc415179ce1b2f10c079f60333169ab1512ee41';TERMINAL='3984b95e5b981b9b4dabbb7d50a00494a9020b560664433c701ba8fc5b4cba79';RESULT='fc79a0217f1e851fa71b9b7faea2731c55592d3bbf93fd1aaa389c74f62fb0f3'
GEN_SOURCE='044c90afa64f3c65a6f96a46d67c781b8d643aec39e1e9506611299b3e59021b';GEN_TERMINAL='3cfd82b4437220bfa21aae773af318457c86ff405bfb69b5ec570a9e8bf7c3c8';GEN_RESULT='9b295b787f2d0cd4d221bb41c81163e3cfaf06bdd55a1ac1597275b394f69160'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
start=time.monotonic();assert digest(SRC/'source-index.json')==SOURCE and digest(REPORT/'terminal.json')==TERMINAL and digest(REPORT/'result.json')==RESULT
buildaudit=ROOT/'.tirust-build/qp-mass-fresh-cli-build-independent-audit-1/receipt.json';assert digest(buildaudit)=='f776fb1fa15a754fc08dabfa98185407f12c3cd21eff3f394b7ce01403732e6a'
before={str(p.relative_to(REPORT)):digest(p) for p in REPORT.rglob('*') if p.is_file()}
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('Audit forbids native/process execution')
def patch(o,n):
 if hasattr(o,n):saved.append((o,n,getattr(o,n)));setattr(o,n,deny)
try:
 for n in ('Popen','run','call','check_call','check_output'):patch(subprocess,n)
 for n in ('system','popen','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe','fork','forkpty'):patch(os,n)
 for n in ('CDLL','PyDLL','_dlopen'):patch(ctypes,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 c=load('fresh_cli_run_independent_controller',SRC/'controller.py');c.EXPECTED=SOURCE;c.REVIEWED_BUILD=BUILD;c.verify_source();protected=c.protected();built=c.verified_build();baseline=c.read_baseline();p=c.pins();case=p['case']
 result=read(REPORT/'result.json');terminal=read(REPORT/'terminal.json');folder=REPORT/'candidate';work=c.WORK/'run/candidate';proc=c.proc(work)
 assert c.sources(work)==built['sources'] and c.canonical_objects(work)==built['objects'] and digest(proc/'check')==built['executable_sha256'];cards=c.cards(work)
 analysis=c.local('base_analysis');rows=analysis.exact((folder/'exact-words.dat').read_text(),case['expected_codes']);ieee=analysis.ieee((folder/'exact-ieee.dat').read_text());software=c.software((folder/'software-flags.dat').read_text())
 comparator={};tree=ast.parse((ROOT/'tools/tirust_benchmark.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare_rows'];assert len(nodes)==1
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<exact unchanged comparator>','exec'),comparator)
 def compare(left,right):
  value=analysis.compare_variants(left,right,comparator['compare_rows']);assert value['passed'];changed=[]
  for a,b in zip(left,right,strict=True):
   assert a['status']==b['status']
   if a['status']==219:assert a==b
   elif a['words']!=b['words']:changed.append({'point':a['point'],'order':a['order'],'baseline_words':a['words'],'fresh_words':b['words']})
  return {**value,'DP_exact':True,'QP_word_accuracy_differences':changed}
 comparison=compare(baseline['lanes']['candidate']['rows'],rows);assert comparison==result['comparison']
 lane={'rows':rows,'ieee':ieee,'software':software};assert lane==result['lane'] and all(lane[k]==baseline['lanes']['candidate'][k] for k in lane)
 # Independent strict decimal parse of the complete learning chronology, with
 # bootstrap retained separately and exactly100 consecutive steady calls.
 warmtext=(folder/'warmup.dat').read_text();fields=[line.split() for line in warmtext.splitlines() if line.strip() and not line.lstrip().startswith('#')]
 assert all(len(f)==9 for f in fields);history=[list(map(int,f[:4])) for f in fields]
 assert history==baseline['learning']['candidate']['history']==result['learning']['history']
 grouped=collections.OrderedDict()
 for f in fields:grouped.setdefault(int(f[0]),[]).append(f)
 assert list(grouped)==list(range(101)) and len(grouped[0])==2 and all(len(v)==2 for v in grouped.values())
 learning_rows=[];steady_float=[]
 for call in range(1,101):
  assert [int(f[2]) for f in grouped[call]]==[0,1]
  for f in grouped[call]:
   point,order,status=map(int,f[1:4]);assert point==call and status==case['expected_codes'][str(point)]
   values=[float(x.replace('D','E').replace('d','e')) for x in f[4:]];assert all(math.isfinite(x) for x in values) and values[-1]>=0
   learning_rows.append({'point':point,'order':order,'status':status,'words':[struct.pack('>d',x).hex().upper() for x in values]})
   steady_float.append({'point':point,'order':order,'status':status,'coefficients':values[:4],'accuracy':values[-1],'actual_backend':9,'precision':'DP' if status==219 else 'QP'})
 learning_comparison=compare(baseline['learning']['candidate']['rows'],learning_rows)
 assert learning_comparison==result['learning']['comparison'] and learning_rows==result['learning']['rows']==baseline['learning']['candidate']['rows']
 stored=read(folder/'learning.json');ready=read(folder/'ready.json')
 assert stored['rows']==steady_float and stored['warmup_first_call']==1 and stored['warmup_last_call']==100 and stored['warmup_call_point_order']==[{'call':i,'point':i} for i in range(1,101)]
 assert stored['raw_outputs']=={'warmup.dat':warmtext,'dimensions.dat':(folder/'dimensions.dat').read_text()} and stored['cold_seconds']==ready['cold_seconds']
 assert ready['points']==100 and ready['ndim']==ready['nso']==ready['nborn']==1 and math.isfinite(ready['cold_seconds']) and ready['cold_seconds']>0
 assert stored['status_counts']=={'219':87,'323':13} and stored['backend_precision_counts']=={'9:DP':87,'9:QP':13} and stored['performance_eligible'] is False and stored['seconds'] is None
 assert read(folder/'exact-command.json')['command']==['EXACT',1,0]
finally:
 for o,n,v in reversed(saved):setattr(o,n,v)
assert not attempts
assert result['status']==terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['result_sha256']==RESULT
assert terminal['source_index_sha256']==result['source_index_sha256']==SOURCE and terminal['reviewed_build']==result['reviewed_build']==BUILD and result['baseline']==p['baseline']
assert result['full100_learning'] and result['final_points']==100 and result['DP_points']==87 and result['automatic_QP_points']==13 and result['cache']==0
assert all(result[k] is False for k in ('candidate_promoted','performance_acceptance','independent_physical_finite_truth_qualified'))
assert terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60 and terminal['cpu']==12 and terminal['cpu_reservation'] is False
assert terminal['resource_limits']=={'address_space_bytes':17179869184,'file_bytes':536870912,'core_bytes':0}
for n,h in result['raw_files'].items():assert digest(REPORT/n)==h
assert collections.Counter(r['status'] for r in rows)=={219:174,323:26}
assert all(comparison[k] is True for k in ('all_coefficient_words_equal','all_accuracy_words_equal','regression_passed','ordinary_target_passed','DP_exact')) and comparison['coefficient_values_compared']==800
assert comparison['regression_tolerance']==3e-6 and comparison['ordinary_target_tolerance']==1e-8 and not comparison['QP_word_accuracy_differences']
for n in ('worker.log',):assert not re.search(r'##W03\b',(folder/n).read_text(),re.I)
assert not re.search(r'##W03\b',(REPORT/'console.log').read_text(),re.I) and not (proc/'worker-protocol.fifo').exists()
mapping=[];runtime=built['runtime']['files'];allowed_extra=read(SRC/'source-index.json')['allowed_extra_mappings'];exe=str((proc/'check').resolve());expected_files={**runtime,exe:built['executable_sha256']};allfiles={}
for edge in ('before','after'):
 m=read(folder/f'maps-{edge}.json');rawpaths=set()
 for line in m['maps'].splitlines():
  f=line.split(None,5)
  if len(f)==6 and f[5].startswith('/'):
   assert not f[5].endswith(' (deleted)');rawpaths.add(str(Path(f[5]).resolve()))
 assert rawpaths==set(m['files']);allow={**expected_files,**allowed_extra}
 assert all(m['files'].get(n)==h for n,h in expected_files.items()) and all(allow.get(n)==h for n,h in m['files'].items())
 for n,h in m['files'].items():assert digest(n)==h;allfiles[n]=h
 assert any(r['pid']==m['pid'] and r['parent_pid']==terminal['pid'] for r in terminal['cleanup']['observed_owned_processes']);mapping.append(m)
assert mapping[0]['pid']==mapping[1]['pid'] and mapping[0]['files']==mapping[1]['files'] and len(runtime)==15
commands=list((folder/'commands').glob('*.command.json'));assert len(commands)==2
for f in commands:
 name=f.name[:-len('.command.json')];cmd=read(f);closed=read(f.with_name(name+'.terminal.json'));assert closed['returncode']==0 and closed['stdout_sha256']==digest(f.with_name(name+'.stdout.txt'))
 assert cmd['argv']==[built['runtime']['loader'],'--list',str(proc/'check')]
 listing=f.with_name(name+'.stdout.txt').read_text();providers={str(Path(m[1]).resolve()) for line in listing.splitlines() if 'linux-vdso' not in line and (m:=re.search(r'(/[^\s()]+)\s+\(0x',line))};assert providers==set(runtime)
# Exact immutable actual GEN3 -> fresh source family -> selected-unit BUILD ->
# executable RUN chain; this audit does not rerun MG, compiler or provider.
gen=ROOT/'.tirust-build/qp-mass-cli-generation-execution-3';gsource=ROOT/'.tirust-build/qp-mass-cli-generation-proposal-3/source-index.json'
assert digest(gsource)==GEN_SOURCE and digest(gen/'terminal.json')==GEN_TERMINAL and digest(gen/'result.json')==GEN_RESULT
gt=read(gen/'terminal.json');gr=read(gen/'result.json');assert gt['status']==gr['status']=='passed' and gt['returncode']==0 and not gt['cleanup']['survivors'] and gt['result_sha256']==GEN_RESULT
assert gt['source_sha256']==gr['source_sha256']==GEN_SOURCE and gr['actual_CLI_invocations']==1 and gr['amplitude_evaluations']==0
assert {n:r['sha256'] for n,r in gr['source_inventory'].items()}==p['fresh_sources'] and len(gr['source_inventory'])==195
assert read(ROOT/'.tirust-build/qp-mass-fresh-cli-build-independent-audit-1/receipt.json')['selected_actual_recipes']==list(read(SRC/'input-pins.json')['selected_sources'])
assert built['native_amplitude_calls']==0 and len(built['selected_recipes'])==7 and len(built['objects'])==144
assert before=={str(p.relative_to(REPORT)):digest(p) for p in REPORT.rglob('*') if p.is_file()}
receipt={'schema':'independent-fresh-CLI-QP-mass-run-audit-v1','status':'PASS','audit_source_sha256':digest(__file__),'source_index_sha256':SOURCE,'build_terminal_sha256':BUILD,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'actual_GEN3_chain':{'source_sha256':GEN_SOURCE,'terminal_sha256':GEN_TERMINAL,'result_sha256':GEN_RESULT,'actual_CLI_invocations':1,'amplitude_calls_in_generation':0,'fresh_source_bindings':195,'selected_fresh_compiles_in_BUILD':7},'baseline':p['baseline'],'baseline_arm':'candidate corrected mass CACHE0','full100_learning_rows':200,'separate_bootstrap_rows_retained_unqualified':2,'final_answer_rows':200,'coefficient_values_compared':800,'accuracy_words_compared':200,'all_final_and_learning_words_exact_to_baseline':True,'checked_DP_points':87,'automatic_QP_points':13,'unchanged_regression_threshold':3e-6,'unchanged_target_threshold':1e-8,'IEEE_and_software_records_exact':True,'W03_records_in_runtime_logs':0,'runtime_providers':15,'runtime_ELF_including_executable':16,'actual_mapped_file_hashes':allfiles,'loader_receipts':2,'worker_pid':mapping[0]['pid'],'owned_identities':len(terminal['cleanup']['observed_owned_processes']),'survivors':[],'cap_seconds':600,'cleanup_reserve_seconds':60,'resource_limits':terminal['resource_limits'],'forbidden_process_native_API_attempts':len(attempts),'new_native_calls':0,'evidence_unchanged':True,'scope':'One actual fresh stock-CLI loop_sm u u~ > z g g QCD export with selected six numerical units plus qualified driver compiled; normal mode/cache0 exact100-point learning+final traversal agrees bitwise with closed corrected-mass candidate. This adds actual export/build/run correspondence for this case, not independent finite-term truth, all-five-backend/CMS/EW/dynamic-mass/false-integrand coverage, performance acceptance or production promotion. Earlier GEN2 failure and prior mass packet are not modified or reclassified; no new native execution by audit.','public_or_git_mutations':0,'elapsed_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_seconds'],'final_rows':200,'learning_rows':200,'coefficient_values':800,'forbidden_attempts':len(attempts)}))
