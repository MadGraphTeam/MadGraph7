from pathlib import Path
import collections,ctypes,hashlib,importlib.util,json,os,re,subprocess,sys,time
ROOT=Path.cwd();SRC=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-proposal-1';REPORT=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-execution-1/build';OUT=ROOT/'.tirust-build/qp-mass-fresh-cli-build-independent-audit-1'
SOURCE='c2acf316159ab0c12ab775b4ca92ff0d0eaa122a29db602deb629bae93da4450';TERMINAL='6357ea74762033e7f5b00c897dc415179ce1b2f10c079f60333169ab1512ee41';RESULT='f6af9e96508160be42afc3e88d1b6f559a2fdbfb795834c29cde1637b1dc671d'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
start=time.monotonic();assert digest(SRC/'source-index.json')==SOURCE and digest(REPORT/'terminal.json')==TERMINAL and digest(REPORT/'result.json')==RESULT
saved=[];attempts=[]
def deny(*a,**k):attempts.append(repr(a[:1]));raise RuntimeError('Independent audit forbids native/process APIs')
def patch(o,n):
 if hasattr(o,n):saved.append((o,n,getattr(o,n)));setattr(o,n,deny)
try:
 for n in ('Popen','run','call','check_call','check_output'):patch(subprocess,n)
 for n in ('system','popen','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe','fork','forkpty'):patch(os,n)
 for n in ('CDLL','PyDLL','_dlopen'):patch(ctypes,n)
 if '_ctypes' in sys.modules:patch(sys.modules['_ctypes'],'dlopen')
 c=load('fresh_cli_build_independent_controller',SRC/'controller.py');c.EXPECTED=SOURCE;c.REVIEWED_BUILD=TERMINAL
 c.verify_source();protected=c.protected();built=c.verified_build();assert protected==built['protected']
 p=c.pins();case=p['case'];output=Path(built['output']);directory=c.proc(output);policy=c.local('policy')
 recipes,link=policy.select_commands((REPORT/'commands/expanded-check.stdout.txt').read_text(),c.tool('gfortran'),c.environment())
 assert json.loads(json.dumps(recipes))==built['selected_recipes'] and link==built['link_command']
 compiler_path=ROOT/'tools/tirust_benchmark_compiler.py';assert p['support_files']['tools/tirust_benchmark_compiler.py']['sha256']==digest(compiler_path)
 compiler=load('fresh_cli_build_independent_compiler',compiler_path)
 assert policy.verify_policy(case['compiler_flags'],built['compiler_flags'],compiler)==built['policy_evidence']
 loader=c.support('loader');pre=read(REPORT/'prelink.json')
 assert loader.requireactualmap((directory/'private-link.map').read_text(),directory,pre,directory/'check')==built['actual_link_loads']
 card_binding=c.cards(output);baseline=c.read_baseline()
finally:
 for o,n,v in reversed(saved):setattr(o,n,v)
assert not attempts
terminal=read(REPORT/'terminal.json');assert terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['source_index_sha256']==SOURCE and terminal['result_sha256']==RESULT
assert terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60 and terminal['cpu']==12 and terminal['cpu_reservation'] is False
assert terminal['resource_limits']=={'address_space_bytes':17179869184,'file_bytes':536870912,'core_bytes':0}
assert built['native_amplitude_calls']==0 and built['candidate_promoted'] is False and built['original_Rust_and_wrapper_retained'] is True
assert len(built['sources'])==195 and len(built['objects'])==144 and len(built['actual_link_loads'])==54 and len(built['runtime']['files'])==15
prefix='SubProcesses/'+case['subprocess']+'/'
selected=('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','coef_construction_1.f','helas_calls_ampb_1.f','helas_calls_uvct_1.f','check_sa.f')
assert tuple(policy.NEEDED)==selected and set(built['selected_sources'])==set(selected)
changed={n for n,h in p['fresh_sources'].items() if case['generated_sources'][n]!=h}
assert changed=={prefix+n for n in selected}|{'Source/make_opts','SubProcesses/makefile',prefix+'makefile'} and len(changed)==10
expected_sources=dict(p['fresh_sources']);expected_sources[prefix+'check_sa.f']=p['driver']['sha256'];expected_sources[prefix+'makefile']=hashlib.sha256(policy.private_makefile((Path(p['fresh_output'])/prefix/'makefile').read_text()).encode()).hexdigest()
assert built['sources']==expected_sources
# Every changed numerical source gets a fresh exact generated recipe; includes
# and all other source records remain bound. The controlled driver is separate.
replaced={prefix+Path(n).with_suffix('.o').name for n in selected}
unchanged={n:h for n,h in case['numerical_objects'].items() if n not in replaced}
assert len(unchanged)==137 and all(built['objects'][n]==h for n,h in unchanged.items())
source_objects={n:h for n,h in p['fresh_objects'].items() if n.startswith('Source/')};assert len(source_objects)==116 and sum(n.endswith('.o') for n in source_objects)==112 and sum(n.endswith('.mod') for n in source_objects)==4
assert all(built['objects'][n]==h==case['numerical_objects'][n] for n,h in source_objects.items())
assert len(p['reuse_subprocess_objects'])==15
for n,record in p['reuse_subprocess_objects'].items():
 assert built['objects'][n]==record['sha256']==case['numerical_objects'][n]
 assert p['fresh_sources'][record['source']]==case['generated_sources'][record['source']]
 assert record['recipe_name'] in case['compiler_flags']['scopes']['process']['recipes']
assert p['reuse_subprocess_objects'][prefix+'ml5_0_polynomial_constants.mod']['source']==prefix+'polynomial.f'
commands={}
for f in (REPORT/'commands').glob('*.command.json'):
 name=f.name[:-len('.command.json')];cmd=read(f);closed=read(f.with_name(name+'.terminal.json'));assert closed['returncode']==0
 assert closed['stdout_sha256']==digest(f.with_name(name+'.stdout.txt'))
 if 'stderr_sha256' in closed:assert closed['stderr_sha256']==digest(f.with_name(name+'.stderr.txt'))
 commands[name]=cmd
assert len(commands)==70
for i,(name,argv) in enumerate(recipes):
 cmd=commands[f'{i:02d}-compile-'+name];assert cmd['argv']==argv and cmd['cwd']==str(directory)
 assert argv[:4]==[c.tool('gfortran'),'-w','-fPIC','-ffixed-line-length-132'] and argv[argv.index('-c')+1]==name and argv[argv.index('-o')+1]==Path(name).with_suffix('.o').name
 assert not any(x.startswith('-O') or x=='-ffast-math' for x in argv)
assert commands['link']['argv']==link and commands['link']['cwd']==str(directory)
assert sum('-compile-' in n for n in commands)==7
assert 'SHELL='+c.tool('bash') in commands['expanded-check']['argv']
for i in range(1,5):
 before_cmd=commands[f'policy-before-{i:02d}']['argv'];after_cmd=commands[f'policy-after-{i:02d}']['argv'];assert before_cmd==after_cmd
 if i==2:assert before_cmd==[c.tool('gfortran'),'--version']
 else:assert before_cmd[:4]==['make','--no-print-directory','--dry-run','--always-make']
symbols=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',(REPORT/'commands/symbols.stdout.txt').read_text(),re.M)
assert len(p['expected_mtirust_symbols'])==23 and all(symbols.count(n)==1 for n in p['expected_mtirust_symbols'])
assert len(p['expected_private_symbols'])==9 and all(symbols.count(n)==1 for n in p['expected_private_symbols']) and set(built['private_definitions'])==set(p['expected_private_symbols'])
assert not (directory/'mtirust.o').exists() and 'libtirust.a(' in (directory/'private-link.map').read_text()
assert pre['explicit_current_runtime_before_link']==built['runtime']['files']==p['expected_runtime']['files']
for name,h in {**built['actual_link_loads'],**built['runtime']['files']}.items():assert pre['bound'][name]==h and digest(name)==h
tirust=[(n,h) for n,h in built['runtime']['files'].items() if n.endswith('/libmadloop_tirust.so')];assert len(tirust)==1 and tirust[0][1]=='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9'
assert baseline['source_index_sha256']=='3c0f53a6e5526535b6fae98b0f055466b429a9a9cfc863fb22fb999a5c8a0815' and baseline['stage']=='cache0' and baseline['cache']==0
assert baseline['DP_points']==87 and baseline['QP_points']==13 and len(baseline['lanes']['candidate']['rows'])==200
driver_source=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2/source-preview/candidate/check_sa.f'
assert digest(SRC/'check_sa.f')==digest(driver_source)==p['driver']['sha256']
ids=terminal['cleanup']['observed_owned_processes'];assert len({(x['pid'],x['start_time_ticks']) for x in ids})==len(ids)
receipt={'schema':'independent-fresh-CLI-QP-mass-build-audit-v1','status':'PASS','audit_source_sha256':digest(__file__),'source_index_sha256':SOURCE,'terminal_sha256':TERMINAL,'result_sha256':RESULT,'executable_sha256':built['executable_sha256'],'selected_actual_recipes':[x[0] for x in recipes],'complete_source_bindings':195,'raw_source_equal_to_original':185,'raw_source_changed_classified':sorted(changed),'canonical_object_bindings':144,'unchanged_unselected_objects':137,'GEN3_Source_objects_reused_exact':112,'GEN3_Source_modules_reused_exact':4,'source_recipe_bound_subprocess_objects_reused':15,'closed_commands':70,'actual_LOAD_paths':54,'actual_runtime_providers':15,'MTIRUST_unique_definitions':23,'QPMASS_unique_definitions':9,'original_compiler_flags':built['policy_evidence'],'native_library':dict(tirust),'baseline_terminal_sha256':p['baseline']['terminal']['sha256'],'baseline_result_sha256':p['baseline']['result']['sha256'],'source_case':'loop_sm u u~ > z g g [virt=QCD], exact frozen full100 points; corrected-mass CACHE0 candidate reference','cap_seconds':600,'cleanup_reserve_seconds':60,'resource_limits':terminal['resource_limits'],'resource_evidence_scope':'Supervisor sets and child verifies exact rlimits before build; closed terminal binds configured values. No separate live rlimit query by audit.','recorded_wall_duration_available':False,'owned_identities':len(ids),'survivors':[],'forbidden_process_native_API_attempts':len(attempts),'new_native_calls':0,'readiness':'One separately admitted fresh plain cache0 full100 learning/final100 worker,87DP/13automaticQP; no numerical result inferred from BUILD.','scope':'Actual source3 CLI sources and exact six changed numerical units plus qualified benchmark driver compiled. All other source/build deltas classified, transitive include family unchanged, original flags/providers/wrapper retained. No five-backend, CMS/dynamic-mass, independent finite-truth, performance or production promotion qualification. Earlier failed CLI attempts remain separate; no regeneration or new native execution by audit.','public_or_git_mutations':0,'elapsed_seconds':time.monotonic()-start}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','receipt_sha256':digest(OUT/'receipt.json'),'elapsed_seconds':receipt['elapsed_seconds'],'commands':70,'forbidden_attempts':len(attempts)}))
