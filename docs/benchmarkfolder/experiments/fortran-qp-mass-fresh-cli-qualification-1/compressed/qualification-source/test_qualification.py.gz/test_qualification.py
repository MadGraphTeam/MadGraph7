"""Source/file-only regressions; scientific executables and MG imports blocked."""
import builtins
from contextlib import nullcontext
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_cli_qualified_test',HERE/'controller.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


class Qualification(unittest.TestCase):
    def setUp(self):
        self.guards=[]
        for module,name in ((subprocess,'Popen'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve')):
            guard=patch.object(module,name,side_effect=AssertionError('process/native execution blocked'))
            guard.start();self.guards.append(guard)
        original=builtins.__import__
        def import_guard(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','mg5decay','MadSpin','madmatrix','aloha','PLUGIN'}:
                raise AssertionError('MG package import blocked: '+name)
            return original(name,*args,**kwargs)
        guard=patch.object(builtins,'__import__',side_effect=import_guard)
        guard.start();self.guards.append(guard)

    def tearDown(self):
        for guard in reversed(self.guards):guard.stop()

    def test_actual_pure_source_and_protected_closure(self):
        c.EXPECTED=c.digest(HERE/'source-index.json');c.verify_source()
        result=c.protected()
        self.assertEqual(result['fresh_source_bindings'],195)
        self.assertEqual(result['fresh_object_bindings'],122)
        self.assertEqual(result['reused_subprocess_objects'],15)
        self.assertEqual(len(result['selected_sources']),7)
        self.assertEqual(result['native_calls'],0)
        self.assertEqual(result['compiler_queries'],0)

    def test_every_shared_split_declaration_unit_selected(self):
        expected={'CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f',
            'coef_construction_1.f','helas_calls_ampb_1.f','helas_calls_uvct_1.f','check_sa.f'}
        self.assertEqual(set(c.local('policy').NEEDED),expected)
        self.assertEqual(set(c.pins()['selected_sources']),expected)
        pins=copy.deepcopy(c.pins());pins['selected_sources'].remove('coef_construction_1.f')
        with patch.object(c,'pins',return_value=pins):
            with self.assertRaises(ValueError):c.protected()

    def test_changed_donor_object_rejected_without_mutating_it(self):
        pins=copy.deepcopy(c.pins())
        name=next(iter(pins['reuse_subprocess_objects']))
        pins['reuse_subprocess_objects'][name]['sha256']='0'*64
        with patch.object(c,'pins',return_value=pins):
            with self.assertRaises(ValueError):c.protected()

    def test_wrong_original_recipe_rejected(self):
        pins=copy.deepcopy(c.pins());name=next(iter(pins['reuse_subprocess_objects']))
        pins['reuse_subprocess_objects'][name]['recipe_name']='not_a_qualified_recipe.f'
        with patch.object(c,'pins',return_value=pins):
            with self.assertRaises(ValueError):c.protected()

    def test_fresh_source_or_link_inventory_mutation_rejected(self):
        for field in ('fresh_sources','fresh_links'):
            pins=copy.deepcopy(c.pins());key=next(iter(pins[field]))
            if field=='fresh_sources':pins[field][key]='0'*64
            else:pins[field][key]['target']='unrelated'
            with patch.object(c,'pins',return_value=pins):
                with self.assertRaises(ValueError):c.protected()

    def test_numerical_baseline_exact_rows_pass(self):
        rows=c.read_baseline()['lanes']['candidate']['rows']
        result=c.compare_rows(rows,copy.deepcopy(rows))
        self.assertTrue(result['passed']);self.assertTrue(result['DP_exact'])
        self.assertEqual(result['QP_word_accuracy_differences'],[])

    def test_QP_coefficient_change_fails_hard_scientific_gate(self):
        rows=c.read_baseline()['lanes']['candidate']['rows'];other=copy.deepcopy(rows)
        row=next(row for row in other if row['status']==323)
        value=struct.unpack('>d',bytes.fromhex(row['words'][0]))[0]
        row['words'][0]=struct.pack('>d',value*2 if value else 1.).hex().upper()
        with self.assertRaises(ValueError):c.compare_rows(rows,other)

    def test_QP_accuracy_only_change_retained_as_diagnostic(self):
        rows=c.read_baseline()['lanes']['candidate']['rows'];other=copy.deepcopy(rows)
        row=next(row for row in other if row['status']==323)
        value=struct.unpack('>d',bytes.fromhex(row['words'][-1]))[0]
        row['words'][-1]=struct.pack('>d',value*2+1.e-12).hex().upper()
        result=c.compare_rows(rows,other)
        self.assertTrue(result['passed'])
        self.assertEqual(len(result['QP_word_accuracy_differences']),1)

    def test_DP_accuracy_word_change_rejected(self):
        rows=c.read_baseline()['lanes']['candidate']['rows'];other=copy.deepcopy(rows)
        row=next(row for row in other if row['status']==219)
        row['words'][-1]=f'{int(row["words"][-1],16)^1:016X}'
        with self.assertRaises(ValueError):c.compare_rows(rows,other)

    def test_changed_status_cohort_rejected(self):
        rows=c.read_baseline()['lanes']['candidate']['rows'];other=copy.deepcopy(rows)
        next(row for row in other if row['status']==219)['status']=323
        with self.assertRaises(ValueError):c.compare_rows(rows,other)

    def test_exact_payload_inventory_rejects_extra_or_alias(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);source=root/'source.py';source.write_text('text')
            index={'files':{'source.py':{'sha256':hashlib.sha256(b'text').hexdigest(),'bytes':4}}}
            (root/'source-index.json').write_text(json.dumps(index));seal=c.digest(root/'source-index.json')
            with patch.object(c,'HERE',root),patch.object(c,'EXPECTED',seal):
                c.verify_source();(root/'extra').write_text('extra')
                with self.assertRaises(ValueError):c.verify_source()
                (root/'extra').unlink();source.unlink();source.symlink_to('source-index.json')
                with self.assertRaises(ValueError):c.verify_source()

    def test_card_verification_is_read_only_and_binds_all_four_aliases(self):
        row=c.case();names=list(row['numerical_cards'])+[
            'SubProcesses/'+row['subprocess']+'/MadLoop5_resources/MadLoopParams.dat']
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for name in names:
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes((HERE/'cards/cache0.dat').read_bytes())
            (root/'Cards/param_card.dat').write_bytes((Path(row['output'])/'Cards/param_card.dat').read_bytes())
            binding=c.cards(root)
            self.assertEqual(set(binding['numerical_cards']),set(names))
            changed=root/names[-1];changed.write_text('changed card')
            with self.assertRaises(ValueError):c.cards(root)
            self.assertEqual(changed.read_text(),'changed card')

    def test_separate_build_review_required_for_run(self):
        with patch.object(c,'REVIEWED_BUILD',None):
            with self.assertRaises(ValueError):c.verified_build()
        self.assertEqual(c.CAPS,{'build':600.,'run':600.})
        self.assertEqual((c.CPU,c.CLEANUP),(12,60.))
        self.assertFalse(c.WORK.exists());self.assertFalse(c.REPORT.exists())

    def test_reviewed_build_must_belong_to_this_source(self):
        with tempfile.TemporaryDirectory() as directory:
            report=Path(directory);stage=report/'build';stage.mkdir()
            result=stage/'result.json';result.write_text('{}')
            terminal=stage/'terminal.json';terminal.write_text(json.dumps({
                'status':'passed','returncode':0,'cleanup':{'survivors':[]},
                'source_index_sha256':'foreign-source','result_sha256':c.digest(result)}))
            with patch.object(c,'REPORT',report),patch.object(c,'EXPECTED','this-source'), \
                 patch.object(c,'REVIEWED_BUILD',c.digest(terminal)):
                with self.assertRaises(ValueError):c.verified_build()

    def test_owned_init_failure_after_popen_uses_bounded_raw_fallback(self):
        process=Mock(pid=123);record={'pid':123,'process_group':123,'session':123,'start_time_ticks':7}
        cleanup=Mock();cleanup.SignalRequests.side_effect=lambda:nullcontext(Mock())
        cleanup.identity.return_value=record;cleanup.OwnedChild.side_effect=RuntimeError('owned init failure')
        deadline=types.SimpleNamespace(end=1.e30,handoff=False,deferred=False)
        clock=types.SimpleNamespace(StageDeadline=lambda:nullcontext(deadline))
        ownership=types.SimpleNamespace(raw_cleanup=Mock(return_value={
            'failure_only':True,'uncertainty_blocks_later_stages':True}))
        with tempfile.TemporaryDirectory() as directory:
            report=Path(directory)/'execution'
            with patch.object(c,'REPORT',report),patch.object(c,'WORK',Path(directory)/'work'), \
                 patch.object(c,'EXPECTED','test-seal'),patch.object(c,'REVIEWED_BUILD',None), \
                 patch.object(c,'support',side_effect=lambda name:{'cleanup':cleanup,'deadline':clock}[name]), \
                 patch.object(c,'local',return_value=ownership),patch.object(c,'limits'), \
                 patch.object(c,'verify_source'),patch.object(c,'protected',return_value={}), \
                 patch.object(c,'environment',return_value={}), \
                 patch.object(c,'tool',side_effect=lambda name:'/pinned/'+name), \
                 patch.object(subprocess,'Popen',return_value=process) as popen:
                with self.assertRaisesRegex(RuntimeError,'owned init failure'):c.supervise('build')
            popen.assert_called_once();cleanup.identity.assert_called_once_with(123)
            ownership.raw_cleanup.assert_called_once_with(process,record,cleanup,deadline.end)
            terminal=json.loads((report/'build/terminal.json').read_text())
            self.assertEqual(terminal['status'],'failed')
            self.assertTrue(terminal['cleanup']['failure_only'])
            self.assertTrue(terminal['cleanup']['uncertainty_blocks_later_stages'])
            self.assertFalse((report/'build/result.json').exists())


if __name__=='__main__':unittest.main()
