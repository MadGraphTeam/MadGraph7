#!/usr/bin/env python3
"""Dormant fresh-CLI BUILD/RUN; default mode reads and hashes inputs only."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import struct
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-work-1'
REPORT=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-execution-1'
CPU=12;CLEANUP=60.
CAPS={'build':600.,'run':600.}
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
LIBRARY_LEAVES=('libcts.a','libdhelas.a','libiregi.a','libmodel.a','mpmodule.mod')
EXPECTED=None
REVIEWED_BUILD=None


def require(value,message):
    if not value:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pins():return read(HERE/'input-pins.json')
def case():return pins()['case']
def proc(output):return Path(output)/'SubProcesses'/case()['subprocess']
def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def check_record(path,record):
    path=Path(path)
    require(path.is_file() and digest(path)==record['sha256'] and path.stat().st_size==record['bytes'],
        'Pinned file changed: '+str(path))


def load(name,path):
    path=Path(path)
    if not path.is_relative_to(HERE):
        key=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        check_record(path,pins()['support_files'][key])
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module


def local(name):return load('fresh_qpmass_'+name,HERE/(name+'.py'))
def support(name):return load('fresh_qpmass_support_'+name,ROOT/pins()['support_paths'][name])


def legacy():
    module=support('legacy_controller')
    # Reuse only the closed helper implementations, never its stage dispatcher,
    # source continuation, canonical-object alias rules or physical variants.
    module.command=command;module.environment=environment;module.tool=tool
    return module


def environment():
    p=pins()
    return local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),
        p['compiler_environment_names'],{},p['library_paths'])


def sources(output):
    output=Path(output);suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
    return {str(path.relative_to(output)):digest(path)
        for subtree in ('Source','SubProcesses') for path in sorted((output/subtree).rglob('*'))
        if path.is_file() and (path.suffix.lower() in suffixes or path.name.startswith('makefile')
            or path.name in ('make_opts','MadLoop_makefile_definitions'))}


def numerical_objects(output):
    output=Path(output)
    return {str(path.relative_to(output)):digest(path) for path in sorted(output.rglob('*'))
        if path.is_file() and path.suffix.lower() in ('.o','.mod','.a')
            and 'build-history' not in path.parts and 'worker-raw' not in path.parts}


def links(output):
    output=Path(output)
    return {str(path.relative_to(output)):{'target':str(path.readlink()),'resolved':str(path.resolve())}
        for path in sorted(output.rglob('*')) if path.is_symlink()}


def verify_source():
    require(Path.cwd()==ROOT,'Run only from the working MadGraph repository')
    require(EXPECTED and digest(HERE/'source-index.json')==EXPECTED,'Exact reviewed source seal required')
    index=read(HERE/'source-index.json');expected=set(index['files'])|{'source-index.json'}
    directories={str(parent) for name in expected for parent in Path(name).parents if str(parent)!='.'}
    actual=set()
    for path in HERE.rglob('*'):
        name=str(path.relative_to(HERE))
        require(not path.is_symlink() and path.resolve().is_relative_to(HERE),'Proposal alias/escape forbidden')
        if path.is_file():actual.add(name)
        else:require(path.is_dir() and name in directories,'Unexpected proposal directory: '+name)
    require(actual==expected,'Exact proposal payload inventory changed')
    for name,record in index['files'].items():check_record(HERE/name,record)


def protected():
    p=pins();row=case();fresh=Path(p['fresh_output']);old=Path(row['output'])
    for group in ('support_files','protected_files'):
        for name,record in p[group].items():check_record(Path(name) if Path(name).is_absolute() else ROOT/name,record)
    require(sources(fresh)==p['fresh_sources'] and numerical_objects(fresh)==p['fresh_objects']
        and links(fresh)==p['fresh_links'],'Closed actual GEN3 source/object/alias inventory changed')
    require(sources(old)==row['generated_sources'] and numerical_objects(old)==row['numerical_objects'],
        'Original qualified source/object family changed')
    require(not list(fresh.rglob('worker-protocol.fifo')) and not list(old.rglob('worker-protocol.fifo')),
        'A protected donor worker is active')
    required=set(local('policy').NEEDED)
    require(required==set(p['selected_sources']) and len(required)==7,'Every changed numerical unit and driver must be selected')
    prefix='SubProcesses/'+row['subprocess']+'/'
    require(set(p['fresh_sources'])==set(row['generated_sources']) and len(p['fresh_sources'])==195,
        'Complete195-entry original/fresh source family differs')
    changed={name for name in p['fresh_sources'] if p['fresh_sources'][name]!=row['generated_sources'][name]}
    metadata={'Source/make_opts','SubProcesses/makefile',prefix+'makefile'}
    require(changed=={prefix+name for name in required}|metadata,
        'Unclassified source/build-input delta or omitted changed Fortran unit')
    for name in ('coef_construction_1.f','helas_calls_ampb_1.f','helas_calls_uvct_1.f'):
        before=(proc(old)/name).read_text();after=(proc(fresh)/name).read_text()
        anchor="      INCLUDE 'coupl.inc'\n"
        addition='      REAL*8 LSCALE\n      INTEGER CTMODE\n      COMMON/ML5_0_CT/LSCALE,CTMODE\n'
        require(before.count(anchor)==1 and after==before.replace(anchor,anchor+addition,1),
            'Additional split unit differs beyond its three new COMMON declarations: '+name)
    original_opts=(old/'Source/make_opts').read_text();fresh_opts=(fresh/'Source/make_opts').read_text()
    expected_opts=original_opts.replace('DEFAULT_CPP_COMPILER=g++\n','DEFAULT_CPP_COMPILER='+tool('g++')+'\n').replace(
        'DEFAULT_F_COMPILER=gfortran\n','DEFAULT_F_COMPILER='+tool('gfortran')+'\n')
    require(fresh_opts==expected_opts and expected_opts!=original_opts,'Fresh compiler policy differs beyond pinned selectors')
    require(digest(fresh/'SubProcesses/makefile')==digest(proc(fresh)/'makefile'),
        'Generated makefile alias and physical source differ')
    selected={prefix+Path(name).with_suffix('.o').name for name in required}
    expected_reuse={name for name in row['numerical_objects'] if name.startswith(prefix)
        and name not in selected and name not in p['fresh_objects']}
    require(set(p['reuse_subprocess_objects'])==expected_reuse,'Unmodified subprocess object reuse closure differs')
    for name,record in p['reuse_subprocess_objects'].items():
        check_record(record['donor'],record)
        require(Path(record['donor']).resolve()==(old/name).resolve()
            and record['sha256']==row['numerical_objects'][name],'Wrong reused object donor')
        source=record['source']
        require(p['fresh_sources'][source]==row['generated_sources'][source]
            and Path(source).name==record['recipe_name'],'Reused object source was changed')
        require(record['recipe_name'] in row['compiler_flags']['scopes']['process']['recipes'],
            'Reused object has no original compilation recipe')
    require(all(row['numerical_objects'].get(name)==checksum for name,checksum in p['fresh_objects'].items()),
        'Fresh Source objects/modules/library leaves differ from qualified original hashes')
    check_record(p['driver']['path'],p['driver'])
    for name,wanted in p['expected_runtime']['files'].items():require(digest(name)==wanted,'Runtime provider changed')
    bound=local('tool_environment').validate(read(HERE/'toolchain-pins.json'),environment())
    baseline=read_baseline()
    return {'fresh_source_bindings':len(p['fresh_sources']),'raw_identical_source_bindings':195-len(changed),
        'classified_changed_sources':sorted(changed),'fresh_object_bindings':len(p['fresh_objects']),
        'reused_subprocess_objects':len(expected_reuse),'selected_sources':sorted(required),
        'baseline_source':baseline['source_index_sha256'],'tool_admission':bound,'native_calls':0,'compiler_queries':0}


def read_baseline():
    base=pins()['baseline'];check_record(base['terminal']['path'],base['terminal']);check_record(base['result']['path'],base['result'])
    terminal=read(base['terminal']['path']);result=read(base['result']['path'])
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'],
        'Closed corrected-mass CACHE0 baseline did not pass/close')
    require(terminal['result_sha256']==base['result']['sha256'] and result['status']=='passed'
        and result['stage']=='cache0' and result['cache']==0,'Corrected-mass CACHE0 result binding differs')
    return result


def command(argv,cwd,logs,name):
    logs=Path(logs);logs.mkdir(parents=True,exist_ok=True);argv=list(map(str,argv));env=environment();env['PWD']=str(cwd)
    dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd),'controller_pid':os.getpid(),
        'session':os.getsid(0),'process_group':os.getpgrp(),'subprocess_new_session':False})
    with (logs/(name+'.stdout.txt')).open('xb') as stream:
        done=subprocess.run(argv,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))})
    require(done.returncode==0,'Admitted command failed; no retry: '+name)
    return (logs/(name+'.stdout.txt')).read_text()


def clone(source,target):
    source=Path(source);target=Path(target)
    observations={'worker-protocol.fifo','worker-raw','warmup.dat','dimensions.dat','values.dat','timing.dat',
        'timed_status.dat','exact-words.dat','exact-ieee.dat','software-flags.dat'}
    def ignore(directory,names):
        result={name for name in names if name in observations or name.endswith(('HelFilter.dat','LoopFilter.dat'))}
        if Path(directory)==source:result.add('lib')
        return result
    shutil.copytree(source,target,symlinks=False,ignore=ignore)
    (target/'lib').symlink_to((source/'lib').resolve(),target_is_directory=True)
    require(all(not path.is_symlink() or path==target/'lib' for path in target.rglob('*')),'Mutable private alias remains')


def canonical_objects(output):
    output=Path(output);p=pins();library=output/'lib';intended=(Path(p['fresh_output'])/'lib').resolve()
    require(library.is_symlink() and str(library.readlink())==str(intended) and library.resolve()==intended,
        'Private lib directory is not the exact closed GEN3 lib directory')
    require(all(not path.is_symlink() or path==library for path in output.rglob('*')),'Unexpected private alias')
    actual=numerical_objects(output)
    require(not any(name.startswith('lib/') for name in actual),'Directory-alias enumeration policy changed')
    require({name for name in p['fresh_objects'] if name.startswith('lib/')}=={'lib/'+name for name in LIBRARY_LEAVES},
        'Fresh GEN3 mandatory library leaf set changed')
    for name in LIBRARY_LEAVES:
        key='lib/'+name;path=output/key
        require(path.is_file() and path.resolve()==(Path(p['fresh_output'])/key).resolve()
            and digest(path)==p['fresh_objects'][key],'Mandatory GEN3 library leaf changed: '+key)
        actual[key]=digest(path)
    require(set(actual)==set(case()['numerical_objects']),'Unexpected private object/module/archive set')
    return actual


def cards(output,install=False):
    output=Path(output);row=case();checksum=digest(HERE/'cards/cache0.dat')
    aliases=list(row['numerical_cards'])+['SubProcesses/'+row['subprocess']+'/MadLoop5_resources/MadLoopParams.dat']
    for name in aliases:
        path=output/name
        require(path.is_file() and path.resolve().is_relative_to(output.resolve()),'Mutable numerical card escaped export')
        if install:path.write_bytes((HERE/'cards/cache0.dat').read_bytes())
    numeric_hashes={str(path.relative_to(output)):digest(path) for path in
        [output/'Cards/MadLoopParams.dat',*(output/'SubProcesses').rglob('MadLoopParams.dat')] if path.is_file()}
    require(numeric_hashes=={name:checksum for name in aliases},'Unexpected numerical card alias set')
    require(digest(output/'Cards/param_card.dat')==row['param_card_sha256'],'Physical card changed')
    directory=proc(output)
    candidates=[directory/'param_card.dat']+[directory.joinpath(*(['..']*level),'Cards/param_card.dat') for level in range(6)]
    physical_path=next((path for path in candidates if path.is_file()),None)
    require(physical_path is not None and physical_path.resolve().is_relative_to(output.resolve())
        and digest(physical_path)==row['param_card_sha256'],'Actual resolved physical card changed/escaped clone')
    return {'numerical_cards':numeric_hashes,'physical_card_sha256':row['param_card_sha256'],'cache':0}


def inventory(directory):
    return {str(path.relative_to(directory)):digest(path) for path in sorted(Path(directory).rglob('*'))
        if path.is_file() and path.name not in {'result.json','terminal.json'}}


def build():
    p=pins();before=protected();output=WORK/'build/candidate';clone(p['fresh_output'],output);directory=proc(output)
    for name,record in p['reuse_subprocess_objects'].items():
        target=output/name;require(not target.exists(),'Fresh GEN3 unexpectedly has a subprocess object')
        shutil.copy2(record['donor'],target);check_record(target,record)
    (directory/'check_sa.f').write_bytes(Path(p['driver']['path']).read_bytes())
    policy=local('policy');(directory/'makefile').write_text(policy.private_makefile((directory/'makefile').read_text()))
    expected=dict(p['fresh_sources']);prefix='SubProcesses/'+case()['subprocess']+'/'
    expected[prefix+'check_sa.f']=p['driver']['sha256'];expected[prefix+'makefile']=digest(directory/'makefile')
    require(sources(output)==expected,'Private BUILD changed an unselected source/build input')
    cards(output,install=True);logs=REPORT/'build/commands';old=legacy();bench,compiler,*_=old.modules()
    before_policy=old.capture_policy(directory,logs,'policy-before');policy.verify_policy(case()['compiler_flags'],before_policy,compiler)
    expanded=command([tool('make'),'--no-print-directory','--dry-run','--always-make','SHELL='+tool('bash'),'check'],directory,logs,'expanded-check')
    recipes,link=policy.select_commands(expanded,tool('gfortran'),environment())
    require({name for name,_ in recipes}==set(p['selected_sources']),'Selected actual-source compilation closure differs')
    for index,(name,argv) in enumerate(recipes):command(argv,directory,logs,f'{index:02d}-compile-'+name)
    loader=support('loader');pre=loader.prelink(link,directory,environment(),lambda a,n:command(a,directory,logs,n))
    for path,wanted in p['expected_runtime']['files'].items():
        require(path not in pre['bound'] or pre['bound'][path]==wanted,'Runtime/prelink conflict')
        require(digest(path)==wanted,'Prebound runtime changed');pre['bound'][path]=wanted
    pre['explicit_current_runtime_before_link']=p['expected_runtime']['files'];dump(REPORT/'build/prelink.json',pre)
    command(link,directory,logs,'link')
    loads=loader.requireactualmap((directory/'private-link.map').read_text(),directory,pre,directory/'check')
    runtime=loader.query_runtime(directory/'check',p['expected_runtime']['files'],pre,lambda a,n:command(a,directory,logs,n))
    after_policy=old.capture_policy(directory,logs,'policy-after');evidence=policy.verify_policy(case()['compiler_flags'],after_policy,compiler)
    require(bench.same_compiler_policy(before_policy,after_policy),'Compilation policy changed during BUILD')
    nm=command([tool('nm'),'--defined-only','check'],directory,logs,'symbols')
    require(old.symbols(nm)=={name:1 for name in p['expected_mtirust_symbols']},'Installed MTIRUST definitions changed/duplicated')
    private={line.split()[-1] for line in nm.splitlines() if line.split() and '_qpmass_' in line.split()[-1]}
    require(private==set(p['expected_private_symbols']),'Actual private QP-mass symbol ownership differs')
    require(not (directory/'mtirust.o').exists() and 'libtirust.a(' in (directory/'private-link.map').read_text(),
        'Original installed wrapper archive must remain in use')
    objects=canonical_objects(output);replaced={prefix+Path(name).with_suffix('.o').name for name in p['selected_sources']}
    require(all(objects[name]==wanted for name,wanted in case()['numerical_objects'].items() if name not in replaced),
        'Unselected physics object changed')
    require(protected()==before,'Protected sources/objects/dependencies changed during BUILD')
    dump(REPORT/'build/result.json',{'status':'passed','stage':'build','source_index_sha256':EXPECTED,
        'output':str(output),'sources':sources(output),'objects':objects,'selected_sources':p['selected_sources'],
        'selected_recipes':recipes,'link_command':link,'compiler_flags':after_policy,'policy_evidence':evidence,
        'executable_sha256':digest(directory/'check'),'link_map_sha256':digest(directory/'private-link.map'),
        'prelink_sha256':digest(REPORT/'build/prelink.json'),'actual_link_loads':loads,'runtime':runtime,
        'MTIRUST_definitions':p['expected_mtirust_symbols'],'private_definitions':sorted(private),
        'native_amplitude_calls':0,'original_Rust_and_wrapper_retained':True,'protected':before,
        'raw_files':inventory(REPORT/'build'),'candidate_promoted':False})


def verified_build():
    require(REVIEWED_BUILD and digest(REPORT/'build/terminal.json')==REVIEWED_BUILD,'Separately reviewed exact BUILD required')
    terminal=read(REPORT/'build/terminal.json');built=read(REPORT/'build/result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
        and terminal['source_index_sha256']==EXPECTED and terminal['result_sha256']==digest(REPORT/'build/result.json'),
        'Reviewed BUILD failed, remained active or changed')
    require(built['status']=='passed' and built['stage']=='build' and built['source_index_sha256']==EXPECTED,'Wrong BUILD result')
    for name,wanted in built['raw_files'].items():require(digest(REPORT/'build'/name)==wanted,'BUILD raw evidence changed')
    output=Path(built['output']);directory=proc(output)
    require(sources(output)==built['sources'] and canonical_objects(output)==built['objects']
        and digest(directory/'check')==built['executable_sha256'],'Reviewed BUILD source/object/ELF changed')
    require(digest(directory/'private-link.map')==built['link_map_sha256']
        and digest(REPORT/'build/prelink.json')==built['prelink_sha256'],'Reviewed link proof changed')
    for name,wanted in {**built['actual_link_loads'],**built['runtime']['files']}.items():
        require(digest(name)==wanted,'Reviewed actual provider changed')
    return built


def float_rows(values):
    return [{'point':row['point'],'order':row['order'],'status':row['status'],
        'words':[struct.pack('>d',value).hex().upper() for value in row['coefficients']+[row['accuracy']]]} for row in values]


def compare_rows(expected,actual):
    analysis=local('base_analysis');bench=legacy().modules()[0]
    result=analysis.compare_variants(expected,actual,bench.compare_rows)
    require(result['passed'],'Existing3e-6 and hard1e-8 scientific coefficient gates failed')
    changed=[]
    for left,right in zip(expected,actual,strict=True):
        require(left['status']==right['status'],'Accepted DP/QP status cohort changed')
        if left['status']==219:require(left==right,'DP coefficient/status/accuracy words changed')
        elif left['words']!=right['words']:changed.append({'point':left['point'],'order':left['order'],
            'baseline_words':left['words'],'fresh_words':right['words']})
    return {**result,'DP_exact':True,'QP_word_accuracy_differences':changed}


def software(text):
    rows=[list(map(int,line.split())) for line in text.splitlines() if line.strip()]
    require(len(rows)==200 and [row[:2] for row in rows]==[[point,phase] for point in range(1,101) for phase in (1,2)],
        'Incomplete software-latch observations')
    require(all(len(row)==4 and all(x in (0,1) for x in row[2:]) for row in rows),'Invalid software flags')
    return rows


def maps(worker):
    raw=Path('/proc/'+str(worker.process.pid)+'/maps').read_text();files={}
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'Deleted runtime mapping')
            name=str(Path(fields[-1]).resolve());files[name]=digest(name)
    expected=pins()['expected_runtime']['files'];exe=(worker.directory/'check').resolve()
    allowed={**expected,**read(HERE/'source-index.json')['allowed_extra_mappings'],str(exe):digest(exe)}
    require(all(files.get(name)==wanted for name,wanted in expected.items()) and files.get(str(exe))==digest(exe),
        'Required initialized runtime mapping missing')
    require(all(allowed.get(name)==wanted for name,wanted in files.items()),'Unexpected initialized provider')
    return {'pid':worker.process.pid,'maps':raw,'files':files}


def run():
    before=protected();built=verified_build();baseline=read_baseline();output=WORK/'run/candidate'
    clone(built['output'],output);directory=proc(output);binding=cards(output,install=True);report=REPORT/'run/candidate';report.mkdir(parents=True)
    require(sources(output)==built['sources'] and canonical_objects(output)==built['objects']
        and digest(directory/'check')==built['executable_sha256'],'Fresh RUN clone differs from reviewed BUILD')
    loader=support('loader');pre=read(REPORT/'build/prelink.json')
    initial=loader.query_runtime(directory/'check',pins()['expected_runtime']['files'],pre,
        lambda a,n:command(a,directory,report/'commands','before-'+n))
    _,_,Worker,_,parse_warmup=legacy().modules()
    with ExitStack() as stack:
        worker=stack.enter_context(Worker([tool('taskset'),'-c',str(CPU),str(directory/'check'),case()['points']],
            directory,report/'worker.log',env=environment(),timeout=240.))
        require(os.sched_getaffinity(worker.process.pid)=={CPU},'Worker CPU changed')
        ready={name:getattr(worker,name) for name in ('points','ndim','nso','nborn','cold_seconds')}
        require([ready[name] for name in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong full100 physical dimensions')
        learning=parse_warmup(directory,9,100,ready);learning_rows=float_rows(learning['rows'])
        def history(text):
            rows=[]
            for line in text.splitlines():
                if not line.strip() or line.lstrip().startswith('#'):continue
                fields=line.split();require(len(fields)==9,'Malformed learning record');rows.append(list(map(int,fields[:4])))
            return rows
        current_history=history((directory/'warmup.dat').read_text())
        require(current_history==baseline['learning']['candidate']['history'],'Full100 learning call/status history changed')
        learning_comparison=compare_rows(baseline['learning']['candidate']['rows'],learning_rows)
        dump(report/'ready.json',ready);dump(report/'learning.json',learning)
        for name in ('warmup.dat','dimensions.dat'):shutil.copyfile(directory/name,report/name)
        dump(report/'maps-before.json',maps(worker))
        worker.sequence+=1;require(worker.sequence==1,'Only one final full100 traversal admitted')
        dump(report/'exact-command.json',{'command':['EXACT',1,0]});worker._send('EXACT 1 0')
        require(worker._message()==['EXACTED','1'],'Full100 worker failed')
        for name in ('exact-words.dat','exact-ieee.dat','software-flags.dat'):shutil.copyfile(directory/name,report/name)
        analysis=local('base_analysis');rows=analysis.exact((report/'exact-words.dat').read_text(),case()['expected_codes'])
        require(sum(row['status']==219 for row in rows)==174 and sum(row['status']==323 for row in rows)==26,
            'Required87DP/13automaticQP cohort changed')
        lane={'rows':rows,'ieee':analysis.ieee((report/'exact-ieee.dat').read_text()),
            'software':software((report/'software-flags.dat').read_text())}
        comparison=compare_rows(baseline['lanes']['candidate']['rows'],rows)
        require(lane['ieee']==baseline['lanes']['candidate']['ieee']
            and lane['software']==baseline['lanes']['candidate']['software'],'Observed IEEE/software state changed')
        dump(report/'maps-after.json',maps(worker))
        require(cards(output)==binding and sources(output)==built['sources'] and canonical_objects(output)==built['objects'],
            'RUN mutated source/object/card bindings')
    require(not (directory/'worker-protocol.fifo').exists(),'Worker FIFO survived cleanup')
    final=loader.query_runtime(directory/'check',pins()['expected_runtime']['files'],pre,
        lambda a,n:command(a,directory,report/'commands','after-'+n))
    require(all(initial[name]==final[name] for name in ('loader','loader_sha256','files')),'Runtime changed during RUN')
    require(protected()==before,'Protected inputs changed during RUN')
    dump(REPORT/'run/result.json',{'status':'passed','stage':'run','source_index_sha256':EXPECTED,
        'reviewed_build':REVIEWED_BUILD,'baseline':pins()['baseline'],'lane':lane,'comparison':comparison,
        'learning':{'history':current_history,'rows':learning_rows,'comparison':learning_comparison},
        'full100_learning':True,'final_points':100,'DP_points':87,'automatic_QP_points':13,'cache':0,
        'observed_IEEE_scope':'Raw host-state observations; no trap-freedom or independent finite-truth claim',
        'candidate_promoted':False,'performance_acceptance':False,'independent_physical_finite_truth_qualified':False,
        'raw_files':inventory(REPORT/'run')})


def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard resource limit too small');resource.setrlimit(kind,(value,value))


def child(stage):
    admission=read(REPORT/stage/'admission.json')
    require(admission['parent_pid']==os.getppid() and admission['source_index_sha256']==EXPECTED
        and admission['stage']==stage and admission['reviewed_build']==REVIEWED_BUILD,'Missing exact supervisor admission')
    require(os.sched_getaffinity(0)=={CPU},'Child affinity changed')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limits changed')
    verify_source();protected()
    (build if stage=='build' else run)()


def supervise(stage):
    cleanup=support('cleanup');clock=support('deadline');ownership=local('ownership')
    clock.STAGE_SECONDS=CAPS[stage];clock.CLEANUP_RESERVE=CLEANUP
    directory=REPORT/stage;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':stage,'source_index_sha256':EXPECTED,'reviewed_build':REVIEWED_BUILD,
        'cap_seconds':CAPS[stage],'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,
        'cpu':CPU,'cpu_reservation':False,'status':'running'}
    owned=None;process=None;raw_record=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,clock.StageDeadline() as deadline:
            entry['deadline_monotonic']=deadline.end;limits();verify_source();protected();requests.check()
            if stage=='build':require(not WORK.exists(),'Fresh BUILD destination required')
            else:verified_build()
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(HERE/'controller.py'),
                '--source',EXPECTED,'--child',stage]
            if REVIEWED_BUILD:argv+=['--reviewed-build',REVIEWED_BUILD]
            dump(directory/'admission.json',{**entry,'parent_pid':os.getpid(),'command':argv})
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'Admitted phase failed; no automatic retry')
            protected();verify_source();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'))
            dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:
                entry['cleanup']=ownership.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else \
                    ownership.raw_cleanup(process,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));dump(directory/'terminal.json',entry);raise


def main():
    global EXPECTED,REVIEWED_BUILD
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source',required=True)
    parser.add_argument('--stage',choices=tuple(CAPS));parser.add_argument('--execute',action='store_true')
    parser.add_argument('--reviewed-build');parser.add_argument('--child',choices=tuple(CAPS),help=argparse.SUPPRESS)
    args=parser.parse_args();EXPECTED=args.source;REVIEWED_BUILD=args.reviewed_build
    if args.child:child(args.child)
    elif args.execute:
        require(args.stage,'Separate explicit BUILD or RUN phase required')
        require(bool(REVIEWED_BUILD)==(args.stage=='run'),'Only RUN requires reviewed BUILD')
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise(args.stage)
    else:
        verify_source();print(json.dumps({'status':'source-only-preflight-passed','source_index_sha256':EXPECTED,
            'protected':protected(),'caps_seconds':CAPS,'cleanup_reserve_seconds':CLEANUP,'limits':LIMITS,
            'native_calls':0,'compiler_queries':0,'MG_import_execution':0},sort_keys=True))


if __name__=='__main__':main()
