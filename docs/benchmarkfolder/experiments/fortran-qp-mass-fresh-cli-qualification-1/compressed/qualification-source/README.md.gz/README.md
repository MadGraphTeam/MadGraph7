# Dormant qualification of the actual fresh QP-mass CLI export

The real stock CLI export now closes successfully at source3
`044c90afa64f3c65a6f96a46d67c781b8d643aec39e1e9506611299b3e59021b`.
Its terminal `3cfd82b4…`, result `9b295b78…`, raw comparison `6c7eb65b…`
and compiler-source policy `57f1a3ed…` remain unchanged. The earlier GEN2
startup failure is retained. This proposal does not repeat generation.

Independent source review `21084caa…` checks exact public bodies and explicit
fixed-form statement/label/literal/control-order correspondence:25 public
routines are byte-identical; nine private routines and all116 guarded calls
match the reviewed materialized source, including ZERO293/MB43/MT43 actuals,
model symbols, cyclic squares and post-CHOOSE backend9 selection. Raw layout,
comment, wrapping and caller differences remain retained; no blanket whitespace
normalization or generic semantic-equivalence claim is used.

The separate complete195-entry audit `ee61695e…` found185 identical inputs and
ten raw differences. The shared split-call template also changes three units
that were not changed by the earlier source continuation. Therefore this
proposal compiles **all six changed numerical Fortran units**, not just the
originally expected three:

* CT_interface.f
* TIRUST_interface.f
* loop_CT_calls_1.f
* coef_construction_1.f
* helas_calls_ampb_1.f
* helas_calls_uvct_1.f

The latter three add the exact LSCALE/CTMODE COMMON declarations. Their addition
is a provenance rebuild requirement, not an observed numerical bug. The seventh
changed Fortran input is the fresh stock check_sa.f versus the donor's custom
benchmark driver. It is explicitly replaced by the already qualified plain
benchmark driver and compiled separately. The other three input differences
are Source/make_opts's two compiler-selector paths and the single physical
SubProcesses/makefile (also seen through its P0 alias), whose f2py/resource rule
ordering differs. Raw differences are preserved; the real build must freshly
compare every effective compilation policy before compiling anything.

## Source-only scope and reuse evidence

No compiler query, compilation, loader, reducer or amplitude has run for this
proposal. Default mode verifies exact source/payload/input hashes only. Separate
future BUILD and RUN admissions are required; source preparation is not either
admission. The native TIRust library remains `eb3d67fd…`; no Fortran wrapper,
Rust, scalar provider, precision, cache policy or installation is rebuilt.

The candidate clone starts from the actual GEN3 output, with its complete195
generated-source/build-input bindings,122 numerical object/module/archive
bindings and35 link bindings. Its112 Source objects (13 MODEL and99 DHELAS)
and both libmodel.a/libdhelas.a are byte-identical to the frozen original
qualified hashes. Their source bytes are also identical, and the retained
Source/make_opts policy differs only in the two explicit compiler selectors.
The new build still checks all original effective recipes and compiler
identities. These actual GEN3 Source objects remain the reused ones.

Fifteen unchanged subprocess object/module bindings are copied from the
original qualified donor only after exact source, object and original recipe
joins. polynomial_constants.mod is explicitly tied to polynomial.f; it is not
assigned an invented same-stem source. The existing exported mpmodule.mod is
already an actual GEN3 binding. Six numerical recompilations plus check_sa.o
complete the original144-key numerical-object/module/archive scope. Every
unselected binding must remain exact, and extra objects/modules are rejected.

The private lib directory may alias only the exact protected actual-GEN3 lib
directory, with all five direct numerical leaves separately bound. Mutable
source/resource aliases are dereferenced. No copied old CT/TIRust/caller or
additional split-call object may survive as a substitute for its new source.
No local mtirust.o or second wrapper is introduced.

The seven selected compile recipes preserve the original flags
`-w -fPIC -ffixed-line-length-132` and generated include/module paths. No O3
experiment or fast-math change is included. The original polynomial recipe
remains untouched. Actual linker LOADs, link map, installed wrapper symbols,
nine private QP-mass definitions, actual PT_INTERP and provider hashes bind the
new executable before any amplitude can run. Build-time loader listings query
runtime dependencies; they do not call an amplitude or reduction entrypoint.

## Future phases and scientific gate

BUILD has one candidate, seven explicit compiles and one explicit link. It
records dry-run/version/policy helper queries too, without claiming to record
every make-internal child. It retains pre/post recipe comparisons, source and
object inventories, symbol ownership, actual LOAD/prelink records and runtime
closure. It performs no numerical worker or recording unit execution.

Only after a separate closed BUILD review, RUN starts one fresh plain candidate
worker with the pinned physical card, cache0 numerical card and100 saved
physical points. It preserves the complete100-point learning sequence and then
performs one final100-point EXACT traversal. Its reference is the **closed
corrected-mass CACHE0 candidate**, rather than the legacy DP-square amplitude.
The baseline result, terminal, raw learning/final records and proofs are pinned.

The expected cohort remains87 checked DP219 and13 automatic QP323 points.
Learning call/point/order/status histories must match. Born and all three
Laurent coefficients at all points/orders pass the unchanged MadLoop3e-6
criterion and hard1e-8 comparison; DP coefficient/status/accuracy words remain
exact. QP word and accuracy differences are retained as diagnostics, including
finite/nonnegative accuracy validation, with no post-outcome threshold change.
Rounding/halting controls and observed IEEE/software-latch records must match
the closed baseline exactly. IEEE observations do not imply trap freedom or
independent proof that no arithmetic exception occurred.

No timing, poles-only mode, observer, unchecked positive-mode result, additional
backend campaign or second worker is included. This gate does not establish
independent physical finite-term truth, general derived/CMS/dynamic mass
qualification, False integrand-policy behavior, mixed rescue chains, broad EW
or five-backend regressions, or performance acceptance. Those items remain open.
Precise local timings remain Hua-Sheng's TODO. Nothing is promoted automatically.

Both phases use the pinned successful compiler/tool environment, single-job
make, single-thread libraries, nonexclusive CPU12, the existing numerical mutex
(fail if busy),16GiB address space,512MiB file limit and zero core dumps. Each
has600s total with60s cleanup reserve and the already qualified raw-child
ownership fallback. First failure stops, all evidence remains, and there is no
retry or implicit continuation. Work/report roots are fresh
`.tirust-build/qp-mass-fresh-cli-qualification-{work,execution}-1` directories.

From `/shared/external/madloop_tirust/madgraph7_madloop_tirust`, use the pinned
Python with `-B` and the exact final source seal. The default command is pure:

```text
<pinned Python> -B .tirust-build/qp-mass-fresh-cli-qualification-proposal-1/controller.py --source SOURCE_SHA
```

Only separately admitted actions use `--stage build --execute`, then
`--stage run --execute --reviewed-build BUILD_TERMINAL_SHA`. No phase is admitted
by this README or by a source-only test. Pure tests and independent review must
close before either concrete command is proposed for native admission.
