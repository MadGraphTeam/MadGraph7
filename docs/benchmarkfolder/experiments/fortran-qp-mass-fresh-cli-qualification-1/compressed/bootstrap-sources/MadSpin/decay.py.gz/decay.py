#!/usr/bin/env python

from __future__ import division
from __future__ import absolute_import
from madgraph.interface import reweight_interface
try:
    import numpy as np
except ImportError:
    np = None
import pickle

################################################################################
#
# Copyright (c) 2009 The MadGraph7 Development team and Contributors
#
# This file is a part of the MadGraph7 project, an application which 
# automatically generates Feynman diagrams and matrix elements for arbitrary
# high-energy processes in the Standard Model and beyond.
#
# It is subject to the MadGraph7 license which should accompany this 
# distribution.
#
# For more information, visit madgraph.phys.ucl.ac.be and amcatnlo.web.cern.ch
#
###############################################################################
"""
####################################################################
#
#    Routine to decay prodution events in a generic way, 
#    including spin correlation effects
#
#    Ref: S. Frixione, E. Laenen, P. Motylinski, B. R. Webber
#             JHEP 04 (2007) 081
#
#
#####################################################################
"""
import collections
import re
import os
import shutil
import logging
import time
import cmath
import copy
pjoin = os.path.join
from subprocess import Popen, PIPE, STDOUT

os.sys.path.append("../.")
import string
import itertools
#import madgraph.core.base_objects as base_objects
#import madgraph.core.helas_objects as helas_objects
#import madgraph.core.diagram_generation as diagram_generation

import madgraph.models.import_ufo as import_ufo
#import madgraph.various.process_checks as process_checks
#from time import strftime
#from madgraph.interface.madgraph_interface import MadGraphCmd
import madgraph.interface.master_interface as Cmd
import madgraph.interface.madevent_interface as me_interface
import madgraph.interface.common_run_interface as common_run_interface
import madgraph.iolibs.save_load_object as save_load_object
import madgraph.iolibs.files as files
import madgraph.fks.fks_common as fks_common
import aloha
logger = logging.getLogger('decay.stdout') # -> stdout
logger_stderr = logging.getLogger('decay.stderr') # ->stderr

import random 
import math
from madgraph import MG5DIR, MadGraph5Error
import madgraph.various.misc as misc
import madmatrix.density as madmatrix_density
#import time

MAX_COMPAT_FLAVS = 500


def density_libtag(run_id, side):
    """The LIBTAG the madmatrix density libraries of MadSpin run run_id are
    built and loaded with, side 'p' (production) or 'd' (decay). Production and
    decay live in one process, as do the trees of a second MadSpin run, and the
    loader tells libraries apart by their name only."""
    return '_ms%d%s' % (run_id, side)

# Optimisation flag the matrix elements are compiled with. It is the
# GLOBAL_FLAG of the tree's Source/make_opts, which every makefile of the tree
# (DHELAS, MODEL, the P directories, MadSpin/src/makefile_*) adds to FFLAGS;
# ``output standalone`` leaves it empty, i.e. -O0.
MS_GLOBAL_FLAG = '-O2'
# ... used only when a production process has at least this many particles to
# decay. -O2 costs ~2 s of compilation per run and only pays off when the
# matrix elements dominate: measured on 10^4 events (the MG7 paper's MadSpin
# timing setup), x1.05-1.07 for t t~ t t~ and x1.25 for W+W-W+W-, but 3-7%
# slower for WH, t t~, ZZ and t t~ Z.
MS_GLOBAL_FLAG_MIN_DECAYS = 4


class MadSpinError(MadGraph5Error):
    pass


def set_global_flag(tree, flag=MS_GLOBAL_FLAG):
    """Have the standalone tree ``tree`` compiled with ``flag``.

    ``output standalone`` has already built Source/DHELAS and Source/MODEL
    with the empty default flag, and make does not track flags: when the flag
    has to change, their objects and libraries are removed so that the next
    make rebuilds them with it. Nothing is removed when it is already set.
    """
    make_opts = pjoin(tree, 'Source', 'make_opts')
    if not common_run_interface.CommonRunCmd.update_make_opts_full(
                                            make_opts, {'GLOBAL_FLAG': flag}):
        return
    for lib in ('DHELAS', 'MODEL'):
        misc.compile(arg=['clean'], cwd=pjoin(tree, 'Source', lib),
                     mode='fortran')


def bw_retained_fraction(pole, width, bw_cut):
    """The fraction of a resonance's Breit-Wigner that a ``+- bw_cut * width``
    mass window keeps.

    MadSpin samples a virtuality only inside that window but normalises the
    sample with the *full* width -- ``sigma_prod * BR`` on the density side, the
    param-card BR of the whole chain on the v1 side. The events it writes
    therefore hold only the part of the Breit-Wigner that fits inside the
    window, while the number it reports is the whole rate; without this factor
    ``sigma`` comes out identical for every value of ``BW_cut``, which is wrong
    and measurable (see ``MadSpin/validation/mtt_threshold/RESULTS.md``).

    This is *the sampler's own normalisation*, not an approximation of it. Both
    generators draw m^2 flat in ``R = atan((m^2 - M^2)/(M.Gamma))``, whose full
    range is pi -- ``MadSpinInterface._mass_window`` returns exactly this
    quantity as its ``gap/pi`` jacobian, and ``generate_inv_mass_sch`` in
    ``src/driver.f`` computes it as ``bwdelf``. Integrating the sampled density
    over the sampled window is therefore closed-form and exact, so there is no
    reason to fall back on the linearised ``2/pi * atan(2N)`` that the
    ``m^2 - M^2 ~ 2M(m-M)`` substitution gives (0.97879 against the 0.97869 here,
    for a top at ``N = 15``): the difference is the m -> m^2 mapping at the
    window edges, and this form tracks it.

    What no self-consistent calculation can supply is the *numerator*. The rate
    integrand is BW(m^2) times the decay matrix element and its phase space, and
    the retained fraction of the product needs the numerator's integral over the
    part of the Breit-Wigner that was never sampled. ``m.Gamma(m)/(m_t.Gamma_t)``
    alone runs 0.52 to 1.71 across a +-15 Gamma window for a top, and putting it
    in moves the t t~ pair factor from the 0.95785 this returns to 0.96249. (The
    validation study evaluated the same integral four ways; this form reproduces
    its fixed-width-relativistic row to the digit, which is the one that matches
    what the samplers draw.) So this correction
    carries a residual of a few tenths of a percent -- measured against a truth
    sample, +0.4 % to +1.0 % for a t t~ pair at ``BW_cut = 15``
    (``RESULTS.md`` section 1a). It is the propagator part, which is the
    dominant and the ``BW_cut``-dependent part.

    A stable particle (``width == 0``) has no window and no truncation, so the
    fraction is 1; ``bw_cut <= 0`` means the caller is not cutting at all.
    """
    if not width or width <= 0 or pole <= 0 or bw_cut <= 0:
        return 1.0
    # the window is linear in m in both samplers, floored at 0 (a resonance
    # broad enough that M - N.Gamma goes negative is cut only from above)
    min_mass = max(pole - bw_cut * width, 0.0)
    max_mass = pole + bw_cut * width
    gap = math.atan((pole ** 2 - min_mass ** 2) / pole / width)
    gap += math.atan((max_mass ** 2 - pole ** 2) / pole / width)
    return gap / math.pi


class Event:
    """ class to read an event, record the information, write down the event in the lhe format.
            This class is used both for production and decayed events"""

    def __init__(self, inputfile=None, banner=None, model=None):
        """Store the name of the event file """
        self.inputfile=inputfile
        self.particle={}
        self.banner = banner
        # Optional model reference used by get_tag() to remap actual PDG codes
        # to merged-particle IDs so that all_ME key lookups succeed.
        self.model = model

    @property
    def model(self):
        return self._model

    @model.setter
    def model(self, model):
        # The reverse map of _get_pdg_to_merged is built from this model, so it
        # belongs to this event object and is dropped whenever the model
        # changes. It used to be a single cache on the class: an Event without
        # a model then silently borrowed the map of whichever Event had built
        # one first, from whatever model -- which is how run_from_pickle could
        # forget the model and still work when the ms_dir was reused in the
        # process that had built it.
        self._model = model
        self._pdg_to_merged = None

    def give_momenta(self, map_event=None):
        """ return the set of external momenta of the event, 
                in two different formats:
                p is list momenta, with each momentum a list [E,px,py,pz]
                string is a string
        """
        
        if not map_event:
            map_event = {}
            for part in range(len(self.particle)):
                map_event[part] = part
                
        p=[]
        string=""
        for id in range(len(self.particle)):
            particle = self.particle[map_event[id] + 1]
            if particle["istup"] < 2:
                mom = particle["momentum"]
                p.append(mom)
                string+= '%s %s %s %s \n' % (mom.E, mom.px, mom.py, mom.pz)

        return p, string 
    
    def change_wgt(self, value=None, factor=None):
        
        if value:
            self.wgt = value
        elif factor:
            self.wgt *= factor
            # change the wgt associate to the additional weight
            start, stop = self.rwgt.find('<rwgt>'), self.rwgt.find('</rwgt>')
            if start != -1 != stop :
                pattern = re.compile(r'''<\s*wgt id=[\'\"](?P<id>[^\'\"]+)[\'\"]\s*>\s*(?P<val>[\ded+-.]*)\s*</wgt>''')
                data = pattern.findall(self.rwgt)
                if len(data)==0:
                    print(self.rwgt)
                try:
                    text = ''.join('   <wgt id=\'%s\'> %+15.7e </wgt>\n' % (pid, float(value) * factor)
                                     for (pid,value) in data) 
                except ValueError as error:
                    raise Exception('Event file has an invalid weight. %s' % error)
                self.rwgt = self.rwgt[:start] + '<rwgt>\n'+ text + self.rwgt[stop:]          

    def string_event_compact(self):
        """ return a string with the momenta of the event written 
                in an easy readable way
        """
        line=[]
        for part in range(1,len(self.particle)+1):
            pid = self.particle[part]["pid"]
            m = self.particle[part]["momentum"]
            line.append("%i %s %.7g %.7g %.7g %.7g" % 
                        (pid, m.px, m.py, m.pz, m.E, m.m))
        line.append('')
        return "\n".join(line)
    
    def _get_pdg_to_merged(self):
        """Build (and cache) a reverse map from real PDG code to merged-particle PDG.

        For example, if merged_particles = {81: [1, 2, 3, 4], 82: [11, 13]},
        the map contains {1: 81, 2: 81, 3: 81, 4: 81, -1: -81, -2: -81, ...}.
        Particle 21 (gluon, self-antipart) would map both 21 -> 81 and -21 -> -81
        only if 21 is a member of the group.

        The map is empty without a model: the tags are then the physical PDG
        codes, which only match an AllMatrixElement built without flavour
        grouping.
        """
        if self._pdg_to_merged is None:
            self._pdg_to_merged = {}
            merged = self.model.get('merged_particles') if self.model else None
            for merged_pdg, members in (merged or {}).items():
                for pid in members:
                    self._pdg_to_merged[pid] = merged_pdg
                    self._pdg_to_merged[-pid] = -merged_pdg
        return self._pdg_to_merged

    def get_tag(self):
        """Return the production tag and particle ordering for this event.

        The tag is a pair of sorted tuples (initial_pdgs, final_pdgs) where
        particle PDG codes that belong to a merged-particle group are replaced
        by the corresponding merged-particle ID.  This ensures that the tag
        matches the keys stored in AllMatrixElement (which are built from the
        process legs and therefore use merged-particle IDs).
        """
        pdg_to_merged = self._get_pdg_to_merged()
        initial = []
        final = []
        order = [[],[]]
        for part in self.particle.values():
            pid = part['pid']
            mother1 = part['mothup1']
            mother2 = part['mothup2']
            # Remap actual PDG code to merged-particle ID if applicable.
            # Both the tag tuples and the order lists use merged IDs so that
            # they are consistent with P_order (from tag2order, which is built
            # from process legs and therefore always uses merged IDs).
            tag_pid = pdg_to_merged.get(pid, pid)
            if 0 == mother1 == mother2:
                initial.append(tag_pid)
                order[0].append(tag_pid)
            else:
                final.append(tag_pid)
                order[1].append(tag_pid)
        initial.sort()
        final.sort()

        return (tuple(initial), tuple(final)), order

    def get_flavor_index(self, flavor_groups, event_map):
        """Determine the 1-based flavor_index for this event.

        flavor_groups is a list of lists of PDG-code tuples (as returned by
        get_flavor_data_from_me and stored in all_ME/all_decay as
        'flavor_groups_prod', 'flavor_groups_full', or 'flavor_groups_decay').
        Each outer list corresponds to one flavor_index; the inner list contains
        all PDG-code tuples that share the same coupling structure for that index.

        event_map maps ME particle position (0-based) to event particle position
        (0-based, same convention as used by loadfortran / give_momenta).

        The matching rule: for ME position j, the event pid (absolute value) is
        compared to the unsigned group member stored in the flavor tuple at
        position j.  This works because merged-particle groups are identified by
        their absolute PDG code; the sign (particle vs anti-particle) is already
        captured by the process definition and therefore the same within every
        member of a flavor_groups entry.

        Returns the 1-based flavor_index, or 1 if no match is found (safe
        fallback for processes without merged particles).
        """
        pdg_to_merged = self._get_pdg_to_merged()
        if not flavor_groups:
            return 1

        # helper for creating unittest
        if False:        
            misc.sprint(event_map)
            misc.sprint(flavor_groups)
            id = {}
            n_parts = len(flavor_groups[0][0])  # number of particles in the process (length of each flavor tuple)
            event_flav = []
            for me_pos in range(n_parts):
                pid = self.particle[event_map[me_pos] + 1]['pid']   # particle dict is 1-indexed
                id[me_pos] = {'pid': pid}
            misc.sprint(id)

        n_parts = len(flavor_groups[0][0])  # number of particles in the process (length of each flavor tuple)
        event_flav = []
        for me_pos in range(n_parts):
            evt_pos = event_map.get(me_pos)
            if evt_pos is None:
                return 1
            pid = self.particle[evt_pos + 1]['pid']   # particle dict is 1-indexed

            if pid not in pdg_to_merged:
                flav = 1
            else:
                flav = self.model.get('merged_particles')[abs(pdg_to_merged[pid])].index(abs(pid)) + 1
            event_flav.append(flav)

        # note that that flavor group can have more than one tuple (not sure when this happens)
        # so not using a simple index search here. (or one should change flavor_groups to be a dict of tuple:flavor_index)
        for group_idx, groupflav_tuples in enumerate(flavor_groups):
            for flav_tuple in groupflav_tuples:
                if tuple(flav_tuple) == tuple(event_flav):
                    return group_idx + 1  # 1-based
        raise Exception('No matching flavor index found for event with PIDs %s and flavor groups %s' %                         (event_flav, flavor_groups))

    @staticmethod
    def get_selected_flavor_tuple(flavor_data, flavor_index):
        """Return the concrete PDG tuple selected by a 1-based flavor index."""
        if not flavor_data or flavor_index is None:
            return None
        try:
            _, flavor_combos, _ = flavor_data
        except (TypeError, ValueError):
            return None
        if not flavor_combos or flavor_index < 1 or flavor_index > len(flavor_combos):
            return None
        return flavor_combos[flavor_index - 1]
    

    def string_event(self):
        """ return a string with the information of the event written 
                in the lhe format.
        """
        line=self.event_init_line         # This is the <event> line
        line1=' %2d %6d %+13.7e %14.8e %14.8e %14.8e' % \
        (self.nexternal,self.ievent,self.wgt,self.scale,self.aqed,self.aqcd)
        line+=line1+"\n"
        scales= []
        for item in range(1,len(list(self.event2mg.keys()))+1):
            part=self.event2mg[item]
            if part>0:
                particle_line=self.get_particle_line(self.particle[part])
                if abs(self.particle[part]["istup"]) == 1 or abs(self.particle[part]["istup"]) == 2:
                    if "pt_scale" in self.particle[part]:
                        scales.append(self.particle[part]["pt_scale"])
                    else:
                        scales.append(None)
            else:
                particle_line=self.get_particle_line(self.resonance[part])
            line+=particle_line        
        
        if self.diese:
            line += self.diese
        if self.rwgt:
            line += self.rwgt
        if any(scales):
            sqrts = self.particle[1]["pt_scale"]
            line += "<scales %s></scales>\n" % ' '.join(['pt_clust_%i=\"%s\"'
                                                        %(i+1,s if s else self.scale)
                                                       for i,s in enumerate(scales)
                                                       if i>1])
        line+="</event> \n"
        return line


    def get_particle_line(self,leg):

        line=" %8d %2d %4d %4d %4d %4d %+18.11e %+18.11e %+18.11e %18.11e %18.11e %10.4e %10.4e" \
            % (leg["pid"], leg["istup"],leg["mothup1"],leg["mothup2"],\
               leg["colup1"],leg["colup2"],leg["momentum"].px,leg["momentum"].py,\
                leg["momentum"].pz,leg["momentum"].E, leg["mass"],\
                 0.0,float(leg["helicity"]) )
        line+="\n"
        return line


    def reshuffle_resonances(self,mother):
        """ reset the momentum of each resonance in the production event
                to the sum of momenta of the daughters
        """

        daughters=[]
        for part in self.event2mg.keys():
            index=self.event2mg[part]
            if index>0:
                if self.particle[index]["mothup1"]==mother:
                    daughters.append(index)
            if index<0:
                if self.resonance[index]["mothup1"]==mother:
                    daughters.append(index)

#        if len(daughters)!=2:
#            logger.info("Got more than 2 (%s) daughters for one particles" % len(daughters))
#            logger.info("in one production event (before decay)")


        if daughters[0]>0:
            momentum_mother=self.particle[daughters[0]]["momentum"].copy()
        else:
            momentum_mother=self.resonance[daughters[0]]["momentum"].copy()

#       there might be more than 2 daughters, add all their momentum to get the momentum of the mother
        for index in range(1,len(daughters)):
            if daughters[index]>0:
                momentum_mother=momentum_mother.add(self.particle[daughters[index]]["momentum"])
            else:
                momentum_mother=momentum_mother.add(self.resonance[daughters[index]]["momentum"])

        res=self.event2mg[mother]
        del self.resonance[res]["momentum"]
        self.resonance[res]["momentum"]=momentum_mother.copy()

#     recurrence:
        if self.resonance[res]["mothup1"]>2:
            self.reshuffle_resonances(self.resonance[res]["mothup1"])             


    def reset_resonances(self):
        """ re-evaluate the momentum of each resonance, based on the momenta
                of the external particles 
        """

        mothers=[]
        for part in self.particle.keys():
            if self.particle[part]["mothup1"]>2 and \
                    self.particle[part]["mothup1"] not in mothers :
                mothers.append(self.particle[part]["mothup1"])
                self.reshuffle_resonances(self.particle[part]["mothup1"]) 

    def assign_scale_line(self, line):
        """read the line corresponding to global event line
        format of the line is:
        Nexternal IEVENT WEIGHT SCALE AEW AS
        """
        line = line.replace('d','e').replace('D','e')
        inputs = line.split()
        assert len(inputs) == 6
        self.nexternal=int(inputs[0])
        self.ievent=int(inputs[1])
        self.wgt=float(inputs[2])
        self.scale=float(inputs[3])
        self.aqed=float(inputs[4])
        self.aqcd=float(inputs[5])        
        
        

    def get_next_event(self):
        """ read next event in the lhe event file """
        line_type = 'none' # support type: init / event / rwgt
        self.diese = ''
        for line in self.inputfile:
            origline = line
            line = line.lower()
            if line.strip()=="":
                continue 
            # Find special tag in the line
            if line[0]=="#":
                self.diese+=origline
                continue
            if '<event' in line:
                #start new_event
                #Get the right attributes (e.g. <event id='123' npNLO='-1'>)
                self.event_init_line=line.lstrip().replace('nplo','npLO').replace('npnlo','npNLO')
                line_type = 'init'
                continue
            elif '<rwgt>' in line:
                #re-weighting information block
                line_type = 'rwgt'
                #No Continue! need to keep track of this line
            elif '</event>' in line:
                if not self.particle:
                    continue
                self.shat=self.particle[1]["momentum"].dot(self.particle[2]["momentum"])
                return 1
            elif line_type == 'rwgt' and 'wgt' in line:
                # force to continue to be in rwgt line up to </rwgt>
                line_type = 'rwgt'
            elif "pt_clust_" in line:
                line_type="clusteringv3" 
            
            elif '<' in line:
                line_type = 'other_block'
            
            
            if line_type == 'none':
                continue
            elif line_type == 'other_block':
                self.diese += origline
            # read the line and assign the date accordingly                
            elif line_type == 'init':
                line_type = 'event'
                self.assign_scale_line(line)         
                # initialize some local variable
                index_prod=0
                index_external=0
                index_resonance=0
                self.particle={}
                self.resonance={}
                self.max_col=500
                self.diese=""
                self.rwgt=""
                self.event2mg={} # dict. event-like label <-> "madgraph-like" label
                                                            # in "madgraph-like", resonances are labeled -1, -2, ...
            elif line_type == 'rwgt': #special aMC@NLO information
                self.rwgt += line
                if '</rwgt>' in line:
                    line_type = 'event'
            elif line_type == 'event':
                index_prod+=1
                line=line.replace("\n","")
                line = line.replace('d','e').replace('D','e')
                inputs=line.split()
                pid=int(inputs[0])
                istup=int(inputs[1])
                mothup1=int(inputs[2])
                mothup2=int(inputs[3])
                colup1=int(inputs[4])
                if colup1>self.max_col:
                    self.max_col=colup1 
                colup2=int(inputs[5])
                if colup2>self.max_col:
                    self.max_col=colup2 
                mom=momentum(float(inputs[9]),float(inputs[6]),float(inputs[7]),float(inputs[8]))
                mass=float(inputs[10])
                helicity=float(inputs[12])
                if abs(istup)==1:
                    index_external+=1
                    self.event2mg[index_prod]=index_external
                    self.particle[index_external]={"pid":pid,"istup":istup,"mothup1":mothup1,\
                    "mothup2":mothup2,"colup1":colup1,"colup2":colup2,"momentum":mom,"mass":mass,"helicity":helicity}
                elif istup==2:
                    index_resonance=index_resonance-1
                    self.event2mg[index_prod]=index_resonance
                    self.resonance[index_resonance]={"pid":pid,"istup":istup,"mothup1":mothup1,\
                    "mothup2":mothup2,"colup1":colup1,"colup2":colup2,"momentum":mom,"mass":mass,"helicity":helicity}
                else: 
                    logger.warning('unknown status in lhe file')
            elif line_type == "clusteringv3":
                scales = re.findall(r"""pt_clust_(\d+)=\"([e\+\-.\d]+)\"""", line)
                scales = sorted(scales, key= lambda x: -1*int(x[0]))
                for index in range(1,len(self.particle)+1):
                    if self.particle[index]["istup"] == 1:
                        self.particle[index]["pt_scale"] = scales.pop()[1]
                if not self.banner:
                    self.particle[1]["pt_scale"] = self.particle[1]["momentum"].E + self.particle[2]["momentum"].E
                else:
                    self.particle[1]["pt_scale"] = float(self.banner.get('run_card', 'ebeam1'))+float(self.banner.get('run_card', 'ebeam2'))
                
        return "no_event"

class pid2label(dict):
    """ dico pid:label for a given model"""

    def __init__(self,model):
        
        for particle in model["particles"]:
            self[particle["pdg_code"]]=particle["name"]
            self[-particle["pdg_code"]]=particle["antiname"]

class pid2color(dict):
    """ dico pid:color rep. for a given model (ex: 5:-3 )"""

    def __init__(self,model):

        for particle in model["particles"]:
            self[particle["pdg_code"]]=particle["color"]
            if particle["color"] not in [1,8]:
                self[-particle["pdg_code"]]=-particle["color"]
            else:
                self[-particle["pdg_code"]]=particle["color"]
class label2pid(dict):
    """ dico label:pid for a given model"""

    def __init__(self,model):
        
        for particle in model["particles"]:
            self[particle["name"]]=particle.get_pdg_code()
            self[particle["antiname"]]=-particle.get_pdg_code()
            if particle['self_antipart']:
                self[particle["name"]]=abs(self[particle["name"]])
                self[particle["antiname"]]=abs(self[particle["antiname"]])

class dc_branch_from_me(dict):
    """ A dictionary to record information necessary to decay particles 
            { -1 : {"d1": { "label": XX , "nb": YY },    "d2": { "label": XX , "nb": YY }    },    
                -2 : {"d1": { "label": XX , "nb": YY },    "d2": { "label": XX , "nb": YY }    },
                ....
            }
    """

    def __init__(self, process):
        """ """
        self.model = process.get('model')
        
        self["tree"]={}
        self.nexternal = 0
        self.nb_decays = 1
        
        #define a function to allow recursion.
        def add_decay(proc, propa_id=-1):
            # see what need to be decayed
            to_decay = {}
            for dec in proc.get('decay_chains'):
                pid =  dec.get('legs')[0].get('id')
                if pid  in to_decay:
                    to_decay[pid].append(dec)
                else:
                    to_decay[pid] = [dec]
            #done
            self['tree'][propa_id] = {'nbody': len(proc.get('legs'))-1,\
                                      'label':proc.get('legs')[0].get('id')}
            # loop over the child
            child_propa_id = propa_id
            for c_nb,leg in enumerate(proc.get('legs')):
                if c_nb == 0:
                    continue
                self["tree"][propa_id]["d%s" % c_nb] = {}
                c_pid = leg.get('id')
                self["tree"][propa_id]["d%s" % c_nb]["label"] = c_pid
                self["tree"][propa_id]["d%s" % c_nb]["labels"] = [c_pid]
                if c_pid in to_decay:
                    child_propa_id -= 1
                    self["tree"][propa_id]["d%s" % c_nb]["index"] = child_propa_id
                    self.nb_decays += 1
                    # FIFO, as in get_full_process_structure: the n-th child of
                    # a given pid takes the n-th sub-decay written for it, which
                    # is how MG orders the legs of the full matrix element
                    # (h > z z, z > e+ e-, z > u u~ has e+ e- before u u~).
                    child_propa_id = add_decay(to_decay[c_pid].pop(0), child_propa_id)
                else:
                    self.nexternal += 1
                    self["tree"][propa_id]["d%s" % c_nb]["index"] = self.nexternal
            return child_propa_id
        
        # launch the recursive loop
        add_decay(process)

    @classmethod
    def from_dict(cls, data):
        """Rebuild the object from its dict content, which is all the repr of
        save_status_to_pickle keeps: nb_decays and nexternal follow from the
        tree (one node per decay, one positive index per external leg)."""
        new = cls.__new__(cls)
        dict.update(new, data)
        new.model = None
        new.nb_decays = len(new['tree'])
        new.nexternal = sum(1 for node in new['tree'].values()
                            for key, child in node.items()
                            if key.startswith('d') and child['index'] > 0)
        return new

    def get_leaf_pids(self):
        """Return a list of the leaf (final-state) PDG codes for this decay branch.

        Traverses the decay tree starting at the root (-1) and collects the
        'label' of every daughter node whose 'index' is positive (i.e. it is an
        external final-state particle, not an intermediate resonance).  The list
        is returned in depth-first tree order, which matches the ordering used
        when building the full-ME external-particle array.
        """
        leaves = []

        def collect(res_id):
            tree_node = self['tree'][res_id]
            for key in sorted(k for k in tree_node if k.startswith('d')):
                daughter = tree_node[key]
                if daughter['index'] > 0:   # external / leaf
                    leaves.append(daughter['label'])
                else:                         # intermediate resonance – recurse
                    collect(daughter['index'])

        collect(-1)
        return leaves

    def generate_momenta(self,mom_init,ran, pid2width,pid2mass,BW_cut,E_collider, sol_nb=None):
        """Generate the momenta in each decay branch 
             If ran=1: the generation is random, with 
                                     a. p^2 of each resonance generated according to a BW distribution 
                                     b. cos(theta) and phi (angles in the rest frame of the decaying particle)
                                            are generated according to a flat distribution (no grid)
                                 the phase-space weight is also return (up to an overall normalization)
                                 since it is needed in the unweighting procedure

             If ran=0: evaluate the momenta based on the previously-generated p^2, cos(theta) 
                                 and phi in each splitting.    
                                 This is used in the reshuffling phase (e.g. when we give a mass to gluons 
                                 in the decay chain )
        """
        
        index2mom={}
#      pid2mom={}    # a dict { pid : {"status":status, "momentum":momentum}    }

        assert isinstance(mom_init, momentum)
        index2mom[-1] = {}
        index2mom[-1]["momentum"] = mom_init 
        
        if index2mom[-1]['momentum'].m < 1e-3:
            logger.warning('Decaying particle with m< 1e-3 GeV in generate_momenta')
        index2mom[-1]["pid"] = self['tree'][-1]["label"]
        index2mom[-1]["status"] = 2
        weight=1.0
        for res in range(-1,-self.nb_decays-1,-1):
            tree =  self["tree"][res]
            #     Here mA^2 has to be set to p^2:
            # 
            #     IF res=-1:
            #         p^2 has been either fixed to the value in the 
            #         production lhe event, or generated according to a    Breit-Wigner distr. 
            #         during the reshuffling phase of the production event
            #         -> we just need to read the value here
            #     IF res<-1:
            #         p^2 has been generated during the previous iteration of this loop 
            #         -> we just need to read the value here

            mA=index2mom[res]["momentum"].m
            if mA < 1.0e-3:
                logger.debug('Warning: decaying parting with m<1 MeV in generate_momenta ')

            mass_sum = mA
            all_mass = []
            for i in range(tree["nbody"]):
                tag =  "d%s" % (i+1)
                d = tree[tag]["index"]
                # For the daughters, the mass is either generate (intermediate leg + BW mode on)
                # or set to the pole mass (external leg or BW mode off)
                # If ran=0, just read the value from the previous generation of momenta 
                #(this is used for reshuffling purposes) 
                if d>0 or not BW_cut :
                    m = pid2mass(tree[tag]["label"])
                elif ran==0:    # reshuffling phase
                    m= tree[tag]["mass"]
                else:
                    pid=tree[tag]["label"]
                    # NOTE: here pole and width are normalized by 4.0*mB**2,
                    # Just a convention
                    pole=0.25         #pid2mass[pid]**2/mA**2
                    w=pid2width(pid)
                    mpole=pid2mass(pid)
                    width=pid2width(pid)*pid2mass(pid)/(4.0*pid2mass(pid)**2)     #/mA**2

                    m_min=max(mpole-BW_cut*w, 0.5)
                    m_max=mpole+BW_cut*w 
                    if E_collider>0: m_max=min(m_max,0.99*E_collider)

                    zmin=math.atan(m_min**2/w/mpole-mpole/w)/width
                    zmax=math.atan(m_max**2/w/mpole-mpole/w)/width

                    m, jac=self.transpole(pole,width, zmin,zmax)
                    m = math.sqrt(m * 4.0 * mpole**2)
                    # record the mass for the reshuffling phase, 
                    # in case the point passes the reweighting criteria
                    tree[tag]["mass"] = m
                    #update the weight of the phase-space point
                    weight=weight*jac
                # for checking conservation of energy
                mass_sum -= m
                all_mass.append(m)
                if mass_sum < 0:
                    logger.debug('mA<mB+mC in generate_momenta')
                    logger.debug('mA = %s' % mA)
                    return 0, 0, 0 # If that happens, throw away the DC phase-space point ...
                    # I don't expect this to be inefficient, since there is a BW cut                                    

            if tree["nbody"] > 2:
                raise Exception('Phase Space generator not yet ready for 3 body decay')

            if ran==1:
                decay_mom=generate_2body_decay(index2mom[res]["momentum"],mA, all_mass[0],all_mass[1])
#             record the angles for the reshuffling phase, 
#             in case the point passes the reweighting criteria
                tree["costh"]=decay_mom.costh
                tree["sinth"]=decay_mom.sinth
                tree["cosphi"]=decay_mom.cosphi
                tree["sinphi"]=decay_mom.sinphi
            else:
#             we are in the reshuffling phase, 
#             so we read the angles that have been stored from the 
#             previous phase-space point generation
                costh=self["tree"][res]["costh"]
                sinth=self["tree"][res]["sinth"]
                cosphi=self["tree"][res]["cosphi"]
                sinphi=self["tree"][res]["sinphi"]
                decay_mom=generate_2body_decay(index2mom[res]["momentum"],mA, all_mass[0],all_mass[1],\
                                 costh_val=costh, sinth_val=sinth, cosphi_val=cosphi, \
                                 sinphi_val=sinphi)

            # record the momenta for later use
            index2mom[self["tree"][res]["d1"]["index"]]={}
            index2mom[self["tree"][res]["d1"]["index"]]["momentum"]=decay_mom.momd1
            if sol_nb is None:   
                sol_nb = random.randint(0,len(self["tree"][res]["d1"]["labels"])-1)
#                print self["tree"][res]["d1"]["labels"]
#                print '584 get sol_nb', sol_nb,'=>',self["tree"][res]["d1"]["labels"][sol_nb],self["tree"][res]["d2"]["labels"][sol_nb]
#            else:
#                print sol_nb, sol_nb is None, 
#                print 'take back', sol_nb,'=>',self["tree"][res]["d1"]["labels"][sol_nb],self["tree"][res]["d2"]["labels"][sol_nb]
            index2mom[self["tree"][res]["d1"]["index"]]["pid"]=self["tree"]\
                                                   [res]["d1"]["labels"][sol_nb]

            index2mom[self["tree"][res]["d2"]["index"]]={}
            index2mom[self["tree"][res]["d2"]["index"]]["momentum"]=decay_mom.momd2
            index2mom[self["tree"][res]["d2"]["index"]]["pid"]=self["tree"]\
                                                   [res]["d2"]["labels"][sol_nb]

            if (self["tree"][res]["d1"]["index"]>0):
                index2mom[self["tree"][res]["d1"]["index"]]["status"]=1
            else:
                index2mom[self["tree"][res]["d1"]["index"]]["status"]=2
            if (self["tree"][res]["d2"]["index"]>0):
                index2mom[self["tree"][res]["d2"]["index"]]["status"]=1
            else:
                index2mom[self["tree"][res]["d2"]["index"]]["status"]=2

        return index2mom, weight, sol_nb
        
    def transpole(self,pole,width, zmin, zmax):

        """ routine for the generation of a p^2 according to 
            a Breit Wigner distribution
            the generation window is 
            [ M_pole^2 - 30*M_pole*Gamma , M_pole^2 + 30*M_pole*Gamma ] 
        """

        z=zmin+(zmax-zmin)*random.random()
        y = pole+width*math.tan(width*z)

        jac=(width/math.cos(width*z))**2*(zmax-zmin)
        return y, jac
    
    def add_decay_ids(self, proc_list):
        """ """
 
        #define a function to allow recursion.
        def add_decay(proc, propa_id=-1):
            # see what need to be decayed
            to_decay = {}
            for dec in proc.get('decay_chains'):
                pid =  dec.get('legs')[0].get('id')
                if pid  in to_decay:
                    to_decay[pid].append(dec)
                else:
                    to_decay[pid] = [dec]

            # loop over the child
            # resonances are numbered as in __init__: a decaying child takes
            # the next free id after the whole subtree of its previous
            # sibling (propa_id-1 for every child sent two decaying z's of
            # h > z z to the same resonance)
            child_propa_id = propa_id
            for c_nb,leg in enumerate(proc.get('legs')):
                if c_nb == 0:
                    continue
#                self["tree"][propa_id]["d%s" % c_nb] = {}
                c_pid = leg.get('id')
                self["tree"][propa_id]["d%s" % c_nb]["labels"].append(c_pid)
                if c_pid in to_decay:
                    child_propa_id -= 1
                    # FIFO, same pairing as in __init__
                    child_propa_id = add_decay(to_decay[c_pid].pop(0), child_propa_id)
            return child_propa_id
        
        # launch the recursive loop
        for proc in proc_list:
            add_decay(proc)        

class momentum:
    """A class to handle 4-vectors and the associated operations """
    def __init__(self,E,px,py,pz):
        self.px=px
        self.py=py
        self.pz=pz
        self.E=E
        self.mod2=px**2+py**2+pz**2
        self.sq=E**2-self.mod2
        control = E**2+self.mod2
        if not control:
            self.m = 0
        elif self.sq/control < 1e-8:
            self.m=0.0
        else:
            self.m=math.sqrt(self.sq)
        

    def dot3(self,q):
        """ return |p|^2 (spatial components only) """
        return self.px*q.px+self.py*q.py+self.pz*q.pz

    def dot(self,q):
        """ Minkowski inner product """
        return self.E*q.E-self.px*q.px-self.py*q.py-self.pz*q.pz

    def subtract(self,q):
        tot=momentum(self.E-q.E,self.px-q.px,self.py-q.py,self.pz-q.pz)
        return tot

    def add(self,q):
        tot=momentum(self.E+q.E,self.px+q.px,self.py+q.py,self.pz+q.pz)
        return tot
    
    __add__ = add

    def nice_string(self):
        return str(self.E)+" "+str(self.px)+" "+str(self.py)+" "+str(self.pz)

    __str__ = nice_string
    def boost(self, q):
        """ boost a vector from a frame where q is at rest to a frame where q is given 
                This routine has been taken from HELAS
        """
        qq = q.mod2

        if (qq > 1E-10*abs(q.E)):
            pq=self.dot3(q)
            m=q.m
            #if (abs(m-self.mA)>1e-6): print "warning: wrong mass"
            lf=((q.E-m)*pq/qq+self.E)/m
            pboost=momentum((self.E*q.E+pq)/m, self.px+q.px*lf,\
                            self.py+q.py*lf,self.pz+q.pz*lf)            
        else:
            pboost=momentum(self.E,self.px,self.py,self.pz)

        return pboost 

    def copy(self):
        copy_mom=momentum(self.E,self.px,self.py,self.pz)
        return copy_mom

    def invrot(self,q):
        # inverse of the "rot" operation 

        ppE=self.E
        qt2 = (q.px)**2 + (q.py)**2

        if(qt2==0.0):
            if ( q.pz>0 ):
                ppx = self.px
                ppy = self.py
                ppz = self.pz
            else:
                ppx = -self.px
                ppy = -self.py
                ppz = -self.pz
        else:
            qq = math.sqrt(qt2+q.pz**2)
            qt=math.sqrt(qt2)
            ppy=-q.py/qt*self.px+q.px/qt*self.py
            if (q.pz==0):
                ppx=-qq/qt*self.pz
                if (q.py!=0):
                    ppz=(self.py-q.py*q.pz/qq/qt-q.px/qt*ppy)*qq/q.py
                else:
                    ppz=(self.px-q.px*q.pz/qq/qt*ppx+q.py/qt*ppy)*qq/q.px
            else:
                if (q.py!=0):
                    ppz=(qt**2*self.py+q.py*q.pz*self.pz-q.px*qt*ppy)/qq/q.py
                else:
                    ppz=(q.px*self.px+q.pz*self.pz)/qq
                ppx=(-self.pz+q.pz/qq*ppz)*qq/qt
        pp=momentum(ppE,ppx,ppy,ppz)
        return pp 


    def rot(self, q):
        """ rotate the spatial components of the vector from a frame where q is 
                aligned with the z axis to a frame where the direction of q is specified 
                as an argument
                Taken from HELAS
        """
        protE =self.E
        qt2 = (q.px)**2 + (q.py)**2

        if(qt2==0.0):
            if ( q.pz>0 ):
                protx = self.px
                proty = self.py
                protz = self.pz
            else:
                protx = -self.px
                proty = -self.py
                protz = -self.pz
        else:
            qq = math.sqrt(qt2+q.pz**2)
            qt = math.sqrt(qt2)
            protx = q.px*q.pz/qq/qt*self.px -q.py/qt*self.py +q.px/qq*self.pz
            proty = q.py*q.pz/qq/qt*self.px +q.px/qt*self.py +q.py/qq*self.pz
            protz = -qt/qq*self.px + q.pz/qq*self.pz

        prot=momentum(protE,protx,proty,protz)
        return prot


class generate_2body_decay:
    """generate momenta for a generic A > B + C decay    """

    def __init__(self,p,mA,mB,mC, costh_val=None, sinth_val=None, cosphi_val=None, sinphi_val=None):
        """ Generate the momentum of B and C in the decay A -> B+C
                If the angles are given, use them to reconstruct the momenta of B, C
                in the rest frame of A.
                If the routine is called without (costh_val, ...), then generate 
                cos(theta) and phi randomly (flat distr.) in the rest frame of A
                Finally, boost the momenta of B and C in the frame where A has 
                momentum p
        """        

        self.mA=mA
        self.mB=mB
        self.mC=mC

        pmod=self.lambda_fct()/(2.0 * self.mA)
        if not costh_val:
            costh=2.0*random.random()-1.0
            sinth=math.sqrt(1-costh**2)
        else:
            costh=costh_val
            sinth=sinth_val

        if not cosphi_val:
            phi=random.random()*2.0*math.pi
            sinphi=math.sin(phi)
            cosphi=math.cos(phi)
        else:
            sinphi=sinphi_val
            cosphi=cosphi_val

        energyB=math.sqrt(pmod**2+mB**2)
        energyC=math.sqrt(pmod**2+mC**2)
        pBrest=momentum(energyB, pmod*cosphi*sinth,pmod*sinphi*sinth, pmod*costh)
        pCrest=momentum(energyC,-pmod*cosphi*sinth,-pmod*sinphi*sinth, -pmod*costh)
        self.momd1=pBrest.boost(p)
        self.momd2=pCrest.boost(p)

#     record costh and phi for later use
        self.costh=costh
        self.sinth=sinth
        self.cosphi=cosphi
        self.sinphi=sinphi

    def lambda_fct(self):
        """ The usual lambda function involved in 2-body decay """
        lam=self.mA**4+self.mB**4+self.mC**4
        lam=lam-2.0*self.mA**2*self.mB**2-2.0*self.mA**2*self.mC**2\
                    -2.0*self.mC**2*self.mB**2
#        if lam<0:
            #print self.mA
            #print self.mB
            #print self.mC
        return math.sqrt(lam)



class production_topo(dict):
    """ A dictionary to record information about a given topology of a production event

                self["branchings"] is a list of the branchings defining the topology (see class branching)
                self["get_mass2"] is a dictionary {index -> mass**2 of the corresponding particle}
                self["get_momentum"] is a dictionary {index -> momentum of the corresponding particle}
                self["get_id"] is a dictionary {index -> pid the corresponding particle}

            Note: index= "madgraph-like" numerotation of the particles
    """

    def __init__(self, production, options):
        """ Initialise the dictionaries+list used later on to record the information
                about the topology of a production event.
                Note that self["branchings"] is a list, 
                as it makes it easier to scan the topology in the ascendent order
        """
        self["branchings"]=[]
        self["get_mass2"]={}
        self["get_momentum"]={}
        self["get_id"]={}
        self.production = production
        self.options = options

    def add_one_branching(self,index_propa, index_d1,index_d2,type_propa):
        """ add the information of one splitting in the topology """
        branch=branching(index_propa, index_d1,index_d2,type_propa)
        self["branchings"].append(branch)


    def print_topo(self):
        """Print the structure of the topology    """
        for branch in self["branchings"]:
            d1=branch["index_d1"]
            d2=branch["index_d2"]
            propa=branch["index_propa"]
            line=str(propa)+" > "
            line+=str(d1)+" + "
            line+=str(d2)+" ,    type="
            line+=branch["type"]
            print(line)

class AllMatrixElement(dict):
    """Object containing all the production topologies required for event to decay.
       This contains the routine to add a production topologies if needed.
    """
    
    def __init__(self, banner, options, decay_ids, model):
        
        dict.__init__(self)
        self.banner = banner
        self.options = options
        self.decay_ids = set([abs(id) for id in decay_ids])
        self.has_particles_ambiguity = False
        self.model = model


    def add(self, topologies, keys):
        """Adding one element to the list of production_topo"""
        
        for key in keys:
            self[key] = topologies

    def get_br(self, proc):
        # get the branching ratio associated to a process
       
        def branching_ratio_for_pdg(pid, lhaid, proc):
            if any(abs(fid) in proc.get('model').get('merged_particles') for fid in lhaid):
                pids = [l.get('id') for l in proc.get('legs')]
                for i,fid in enumerate(pids):
                    if abs(fid) in proc.get('model').get('merged_particles'):
                        l = proc.get('legs')[i]
                        if l.get('flavor'):
                            pids[i] = l.get('flavor')
                        elif fid in proc.get('model').get('merged_particles'):
                            pids[i] = proc.get('model').get('merged_particles')[abs(fid)] 
                        else:
                            pids[i] = [-x for x in proc.get('model').get('merged_particles')[abs(fid)]]
                    else:
                        pids[i] = [fid]

                all_combinations = list(itertools.product(*pids))
                br = 0
                for lhaid in itertools.product(*pids[1:]):
                    lhaid = tuple([len(lhaid)] + sorted(lhaid))
                    if pid in self.banner.param_card['decay'].decay_table:
                        try:
                            br += self.banner.param_card['decay'].decay_table[pid].get(lhaid).value
                        except (KeyError, TypeError):
                            pass
                    elif -pid in self.banner.param_card['decay'].decay_table:
                        lhaid=[x if self.model.get_particle(x)['self_antipart'] else -x for x in lhaid[1:]]
                        lhaid.sort()
                        lhaid = tuple([len(lhaid)] + lhaid)
                        try:
                            br += self.banner.param_card['decay'].decay_table[-pid].get(lhaid).value
                        except (KeyError, TypeError):
                            pass
                if not br:
                    misc.sprint('no valid decay for %s > %s' % (pid, lhaid[1:]))
                    misc.sprint(self.banner.param_card['decay'].decay_table[pid])
                return br

            elif pid in self.banner.param_card['decay'].decay_table:
                return self.banner.param_card['decay'].decay_table[pid].get(lhaid).value
            elif -pid in self.banner.param_card['decay'].decay_table:
                pid = -pid
                lhaid=[x if self.model.get_particle(x)['self_antipart'] else -x
                       for x in lhaid[1:]]
                lhaid.sort()
                lhaid = tuple([len(lhaid)] + lhaid)
                return self.banner.param_card['decay'].decay_table[pid].get(lhaid).value
            else:
                return 0
        br = 1
        ids = collections.defaultdict(list) #check for identical decay
        for decay in proc.get('decay_chains'):
            init, final = decay.get_initial_final_ids()
            lhaid = tuple([len(final)] + [x for x in final])
            ids[init[0]].append(decay)
            br *= branching_ratio_for_pdg(init[0], lhaid, decay)
            if br == 0:
                raise MadGraph5Error("No valid decay for %s. No 2 body decay for that particle. (three body are not supported by MadSpin)" % init[0])
            br *= self.get_br(decay)

        for decays in ids.values():
            if len(decays) == 1:
                continue
            br *= math.factorial(len(decays))
            while decays:
                nb=1
                curr = decays.pop()
                while 1:
                    try:
                        decays.remove(curr)
                        nb+=1
                    except ValueError:
                        break
                br /= math.factorial(nb)
                
        return br

            
    def add_decay(self, proc_list, me_path):
        """ adding a decay to the possibility
            me_path is the path of the fortran directory
            br is the associate branching ratio
            finals is the list of final states equivalent to this ME
            matrix_element is the MG5 matrix element
        """
        
        # Useful debug code tell the status of the various imported decay
        text = ''
        data = []
        for key, prod in self.items():
            if prod in data:
                continue
            data.append(prod)
            br = prod['total_br']
            if br:
                text += '%s %s %s\n' %(key, os.path.basename(prod['path']), br)

        
        
        if  not isinstance(proc_list, list):
            proc_list = proc_list.get('processes')
            
        tag = proc_list[0].get_initial_final_ids()        
        # process with decay not compatible with tag [process under consideration]
        # or with process splitting different for process and decay.
        to_postpose = [proc for proc in proc_list 
                     if id(self[tag]) != id(self[proc.get_initial_final_ids()])]
                         
        finals = []
        for proc in proc_list:
            succeed = True # check if the decay is compatible with the process
                           #under consideration.
            tmp = []
            for dproc in proc.get('decay_chains'):
                pid = dproc.get('legs')[0].get('id')
                # check that the pid correspond -> if not postpone the process
                # to be added in a second step (happen due to symmetry)
                if pid not in tag[1]:
                    to_postpose.append(proc)
                    succeed= False
                    break
                tmp.append((pid,dproc.get_final_ids_after_decay()))
            if succeed and tmp not in finals:
                finals.append(tmp)
        
        # Treat Not compatible decay.        
        if to_postpose:
            self.add_decay(to_postpose, me_path)
        
        # 
        # Now that the various final states are computed, we can add the 
        # associated decay. First computing the branching ratio and then
        # decaying topology
        me = proc_list[0] # all the other are symmetric -> no need to keep those        
        decay_tags = [d.shell_string(pdg_order=True) for d in me['decay_chains']]
        
        #avoid duplicate
        if  any(tuple(decay_tags)==t['decay_tag'] for t in self[tag]['decays']):  
            return   
        
        # the decay:
        out = {'path': me_path, 
               'matrix_element': me, 
               'br': len(finals) * self.get_br(proc),
               'finals': finals, 
               'base_order':[l.get('id') for l in me.get_legs_with_decays()] ,
               'decay_struct':self.get_full_process_structure(proc_list),
               'decay_tag': tuple(decay_tags)}

        # adding it to the current object
        self[tag]['decays'].append(out)
        self[tag]['total_br'] += out['br']
        # update the particle decaying in the process
        decaying = [m.get('legs')[0].get('id') for m in me.get('decay_chains')]
        decaying.sort()
        self[tag]['decaying'] = tuple(decaying)
                
        # sanity check
        assert self[tag]['total_br'] <= 1.01, "wrong BR for %s: %s " % (tag,self[tag]['total_br'])


        
             
    
    def get_full_process_structure(self, me_list):
        """ return a string with the definition of the process fully decayed
                and also a list of dc_branch objects with all information about the topology
                of each decay branch
        """

        me = me_list[0]
        
        decay_struct = {}
        to_decay = collections.defaultdict(list)
        orig_decay = collections.defaultdict(list)
        for i, proc in enumerate(me.get('decay_chains')):
            pid =  proc.get('legs')[0].get('id')
            to_decay[pid].append((i,proc))
            orig_decay[pid].append((i,proc))

        for leg in me.get('legs'):
            if not leg.get('state'): # initial state particle does not decay ...
                continue
            pid =  leg.get('id')
            nb = leg.get('number')
            if pid in to_decay and leg.get('state'):
                # FIFO: pair the n-th leg of a given pid with the n-th decay
                # branch written for that pid. pop() (LIFO) reverses that
                # pairing whenever two or more final-state particles share a
                # pid and carry *different* branches (p p > z z with
                # 'decay z > e+ e-' / 'decay z > u u~'), so the branch used to
                # build the spin-correlated weight is not the one whose decay
                # products get attached to that leg. Single-branch pids (t/t~,
                # w+/w-) are unaffected: the list holds one entry either way.
                i, proc = to_decay[pid].pop(0)
                decay_struct[nb] = dc_branch_from_me(proc)
                identical = [me.get('decay_chains')[i] for me in me_list[1:]]
                decay_struct[nb].add_decay_ids(identical)
            
        return decay_struct

    def get_topologies(self, matrix_element):
        """Extraction of the phase-space self.topologies from mg5 matrix elements 
             This is used for the production matrix element only.

             the routine is essentially equivalent to    write_configs_file_from_diagrams
             except that I don't write the topology in a file, 
             I record it in an object production_topo (the class is defined above in this file)
        """

        # Extract number of external particles
        ( nexternal, ninitial) = matrix_element.get_nexternal_ninitial()

        del nexternal
        preconfigs = [(i+1, d) for i,d in enumerate(matrix_element.get('diagrams'))]
        mapconfigs = [c[0] for c in preconfigs]
        configs=[[c[1]] for c in preconfigs]
        model = matrix_element.get('processes')[0].get('model')


        topologies ={}    # dictionary {mapconfig number -> production_topology}
                                    # this is the object to be returned at the end of this routine

        s_and_t_channels = []

        vert_list = [max([d for d in config if d][0].get_vertex_leg_numbers()) \
          for config in configs if [d for d in config if d][0].\
                                             get_vertex_leg_numbers()!=[]]
        minvert = min(vert_list) if vert_list!=[] else 0
    
        # Number of subprocesses
        #    nsubprocs = len(configs[0])

        nconfigs = 0

        new_pdg = model.get_first_non_pdg()

        for iconfig, helas_diags in enumerate(configs):
            if any([vert > minvert for vert in
                    [d for d in helas_diags if d][0].get_vertex_leg_numbers()]):
                    # Only 3-vertices allowed in configs.inc
                    continue
            nconfigs += 1

            # Need s- and t-channels for all subprocesses, including
            # those that don't contribute to this config
            empty_verts = []
            stchannels = []
            for h in helas_diags:
                    if h:
                            # get_s_and_t_channels gives vertices starting from
                            # final state external particles and working inwards
                            stchannels.append(h.get('amplitudes')[0].\
                                              get_s_and_t_channels(ninitial, model, new_pdg))
                    else:
                            stchannels.append((empty_verts, None))

            # For t-channels, just need the first non-empty one
            tchannels = [t for s,t in stchannels if t != None][0]

            # For s_and_t_channels (to be used later) use only first config
            s_and_t_channels.append([[s for s,t in stchannels if t != None][0],
                                                             tchannels])



            # Make sure empty_verts is same length as real vertices
            if any([s for s,t in stchannels]):
                    empty_verts[:] = [None]*max([len(s) for s,t in stchannels])

                    # Reorganize s-channel vertices to get a list of all
                    # subprocesses for each vertex
                    schannels = list(zip(*[s for s,t in stchannels]))
            else:
                    schannels = []

            allchannels = schannels
            if len(tchannels) > 1:
                    # Write out tchannels only if there are any non-trivial ones
                    allchannels = schannels + tchannels

# Write out propagators for s-channel and t-channel vertices

#         use the AMP2 index to label the self.topologies
            tag_topo=mapconfigs[iconfig]
            topologies[tag_topo]=production_topo(topologies, self.options)

            for verts in allchannels:
                    if verts in schannels:
                            vert = [v for v in verts if v][0]
                    else:
                            vert = verts
                    daughters = [leg.get('number') for leg in vert.get('legs')[:-1]]
                    last_leg = vert.get('legs')[-1]


                    if verts in schannels:
                            type_propa="s"
                    elif verts in tchannels[:-1]:
                            type_propa="t"


                    if (type_propa):
                        topologies[tag_topo].add_one_branching(last_leg.get('number'),\
                         daughters[0],daughters[1],type_propa)

        return topologies
   
    def get_decay_from_tag(self, production_tag, decay_tag):
        for decay in self[production_tag]['decays']:
            if decay['decay_tag']==decay_tag: return decay

        msg = 'Unable to retrieve decay from decay_tag\n%s\n%s' %(production_tag, decay_tag)
        raise Exception(msg)
 
    def get_random_decay(self, production_tag,first=[]):
        """select randomly a decay channel"""
        
        a = random.random() * self[production_tag]['total_br']
        #print 'total', self[production_tag]['total_br']
        if __debug__:
            if not first:
                sum = 0
                for decay in self[production_tag]['decays']:
                    sum += decay['br']
                assert sum == self[production_tag]['total_br']
                first.append(1)
                
        sum = 0
        for decay in self[production_tag]['decays']:
            sum += decay['br']
            if a < sum:
                return decay

            
    def adding_me(self, matrix_elements, path):
        """Adding one element to the list based on the matrix element"""
        
        for me in matrix_elements:
            skip = [] # due to particles/anti-particles some me need to be add
                      # as a separate matrix element in the instance.
            topo = self.get_topologies(me)
            # get the original order:
            initial = []
            final = [l.get('id') for l in me.get('processes')[0].get('legs')\
                      if l.get('state') or initial.append(l.get('id'))]
            decaying_base = [id for id in final if abs(id) in self.decay_ids]
            decaying_base.sort()
            topo['base_order'] = (initial , final)
#            topo['matrix_element'] = me
            tags = []
            topo['tag2order'] = {}
             
            for proc in me.get('processes'): # set of processes accounted by the me
                initial = []
                final = [l.get('id') for l in proc.get('legs')\
                      if l.get('state') or initial.append(l.get('id'))]
                decaying = [id for id in final if abs(id) in self.decay_ids]
                decaying.sort()
                if decaying != decaying_base:
                    skip.append(proc)
                    continue
                topo['decaying'] = ()
                tags.append(proc.get_initial_final_ids())
                topo['tag2order'][tags[-1]] = (initial , final)
            
            if tags[0] not in self:
                self.add(topo, tags)  # mens self[tag]=topo for each tag in tags
            topo['path'] = pjoin(path, 'SubProcesses', 
                                  'P%s' % me.get('processes')[0].shell_string())
            topo['decays'] = []
            topo['total_br'] = 0 
            topo['Pid'] = proc.get('id')
        
            if skip:
                self.add_me_symmetric(skip, topo)
    
            
    def add_me_symmetric(self, process_list, topo):
        """ """
        self.has_particles_ambiguity = True
        skip = [] # due to particles/anti-particles some may need to be add
                  # as a separate matrix element in the instance.
        
        old_topo = topo
        topo = dict(topo) #change the main pointer
        topo['decays'] = []   # unlink information which need to be different.
        topo['total_br'] = 0  #
        topo['tag2order'] = {}
        topo['decaying'] = ()
        for key in topo.keys():
            if isinstance(key, int):
                topo[key] = copy.copy(topo[key])
        
        assert id(old_topo) != id(topo)
        assert id(topo['decays']) != id(old_topo['decays'])
        tags = []
        for i, proc in enumerate(process_list):
            initial = []
            final = [l.get('id') for l in proc.get('legs')\
                      if l.get('state') or initial.append(l.get('id'))]
            decaying = [pid for pid in final if abs(pid) in self.decay_ids]
            decaying.sort()
            if i == 0:
                decaying_base = decaying
            if decaying != decaying_base:
                skip.append(proc)
                continue
            
            tags.append(proc.get_initial_final_ids())
            topo['tag2order'][tags[-1]] = (initial , final)
            
            
        if tags[0] not in self:
            self.add(topo, tags)
            for key in topo.keys():
                if isinstance(key, int):     
                    topo[key].production = self[tags[0]]   
        if skip:
            self.add_me_symmetric(skip, topo)
        
                

class branching(dict):
    """ A dictionary to record information about a given branching in a production event
            self["type"] is the type of the branching , either "s" for s-channel or "t" for t-channel
            self["invariant"] is a real number with the value of p^2 associated with the branching
            self["index_d1"] is the mg index of the first daughter
            self["index_d2"] is the mg index of the second daughter
            self["index_propa"] is the mg index of the propagator
    """

    def __init__(self, index_propa, index_d1,index_d2, s_or_t):
        self["index_d1"]=index_d1
        self["index_d2"]=index_d2
        self["index_propa"]=index_propa
        self["type"]=s_or_t


class width_estimate(object):
    """All methods used to calculate branching fractions"""

    def __init__(self,resonances,path_me, banner, model, pid2label):

        self.resonances=resonances
        self.path_me=path_me
        self.pid2label = pid2label
        self.label2pid = self.pid2label 
        self.model = model
        #print self.model
        self.banner = banner
        #self.model= 

    def update_branch(self,branches,to_add):
        """ complete the definition of the branch by appending each element of to_add"""
        newbranches={}

        for item1 in branches.keys():
            for item2 in to_add.keys():
                tag=item1+item2
                newbranches[tag]={}
                newbranches[tag]['config']=branches[item1]['config']+to_add[item2]['config']
                newbranches[tag]['br']=branches[item1]['br']*to_add[item2]['br']

        return newbranches

    def extract_br(self, decay_processes, mgcmd):
        """Find a way to get the branching ratio. (depending of the model/cards)"""

        # calculate which br are interesting to compute. 
        to_decay = set(decay_processes.keys())
        for decays in decay_processes.values():
            for decay in decays:
                if ',' in decay:
                    to_decay.update(set([l.split('>')[0].strip()
                                                    for l in decay.replace('(','').replace(')','').split(',')]))

        # Maybe the branching fractions are already given in the banner:
        self.extract_br_from_banner(self.banner)
        to_decay = list(to_decay)
        for part in to_decay[:]:
            if part in mgcmd._multiparticles:
                to_decay += [self.pid2label[id] for id in mgcmd._multiparticles[part]]
                to_decay.remove(part)
        to_decay = list(set([p for p in to_decay if not p in self.br]))
        print('to_decay=',to_decay)
        
        if to_decay:
            logger.info('We need to recalculate the branching fractions for %s' % ','.join(to_decay))
            if hasattr(self.model.get('particles')[0], 'partial_widths'):
                logger.info('using the FeynRules formula present in the model (arXiv:1402.1178)')
            else:
                logger.info('Using MadWidth (arXiv:1402.1178)')
                #self.extract_br_from_width_evaluation(to_decay)
            self.launch_width_evaluation(to_decay, mgcmd) 

       
        return self.br

    def get_BR_for_each_decay(self, decay_processes, multiparticles):
        """ get the list for possible decays & the associated branching fraction  """
        
        model = self.model
        base_model = self.model
        pid2label = self.pid2label

        ponctuation=[',','>',')','(']
        new_decay_processes={}       

        for part in decay_processes.keys():
            pos_symbol=-1
            branch_list=decay_processes[part].split()
            new_decay_processes[part]={}
            new_decay_processes[part]['']={}
            new_decay_processes[part]['']['config']=""
            new_decay_processes[part]['']['br']=1.0

            initial=""
            final=[]
            for index, item in enumerate(branch_list):
                # First get the symbol at the next position
                if index<len(branch_list)-1:
                    next_symbol=branch_list[index+1]
                else:
                    next_symbol=''
                # Then handle the symbol item case by case 
                if next_symbol=='>':              # case1: we have a particle initiating a branching
                    initial=item
                    if item not in [ particle['name'] for particle in base_model['particles'] ] \
                        and item not in [ particle['antiname'] for particle in base_model['particles'] ]:
                        raise Exception("No particle "+item+ " in the model "+model)
                    continue
                elif item=='>': continue       # case 2: we have the > symbol
                elif item not in ponctuation : # case 3: we have a particle originating from a branching
                    final.append(item)
                    if next_symbol=='' or next_symbol in ponctuation:
                        #end of a splitting, verify that it exists
                        if initial not in list(self.br.keys()):
                            logger.debug('Branching fractions of particle '+initial+' are unknown')
                            return 0
                        if len(final)>2:
                            raise Exception('splittings different from A > B +C are currently not implemented ')

                        if final[0] in list(multiparticles.keys()):
                            set_B=[pid2label[pid] for pid in multiparticles[final[0]]]
                        else:
                            if final[0] not in [ particle['name'] for particle in base_model['particles'] ] \
                               and final[0] not in [ particle['antiname'] for particle in base_model['particles'] ]:
                                raise Exception("No particle "+item+ " in the model ")
                            set_B=[final[0]]
                        if final[1] in list(multiparticles.keys()):
                            set_C=[pid2label[pid] for pid in multiparticles[final[1]]]
                        else:
                            if final[1] not in [ particle['name'] for particle in base_model['particles'] ] \
                               and final[1] not in [ particle['antiname'] for particle in base_model['particles'] ]:
                                raise Exception("No particle "+item+ " in the model "+model)
                            set_C=[final[1]]

                        splittings={}
                        counter=0
                        for chan in range(len(self.br[initial])): # loop over all channels
                            got_it=0
                            for d1 in set_B: 
                                for d2 in set_C:
                                    if (d1==self.br[initial][chan]['daughters'][0] and \
                                                 d2==self.br[initial][chan]['daughters'][1]) or \
                                                  (d2==self.br[initial][chan]['daughters'][0] and \
                                                 d1==self.br[initial][chan]['daughters'][1]):
                                        split=" "+initial+" > "+d1+" "+d2+" "
                                        # For the tag we need to order d1 d2, so that equivalent tags can be correctly identified
                                        list_daughters=sorted([d1,d2])
                                        tag_split="|"+initial+">"+list_daughters[0]+list_daughters[1]
                                        counter+=1
                                        splittings[tag_split]={}
                                        splittings[tag_split]['config']=split
                                        splittings[tag_split]['br']=self.br[initial][chan]['br']
                                        got_it=1
                                        break # to avoid double counting in cases such as w+ > j j 
                                if got_it: break                   
                
                        if len(splittings)==0:
                            logger.info('Branching '+initial+' > '+final[0]+' '+final[1])
                            logger.info('is currently unknown')
                            return 0
                        else:
                            new_decay_processes[part]=self.update_branch(new_decay_processes[part],splittings)
                    
                        inital=""
                        final=[]

                else: # case 4: punctuation symbol outside a splitting
                      # just append it to all the current branches
                    fake_splitting={}
                    fake_splitting['']={}
                    fake_splitting['']['br']=1.0
                    fake_splitting['']['config']=item
                    new_decay_processes[part]=self.update_branch(new_decay_processes[part],fake_splitting)

        return new_decay_processes        







    def print_branching_fractions(self):
        """ print a list of all known branching fractions"""

        for res in self.br.keys():
            logger.info('  ')
            logger.info('decay channels for '+res+' : ( width = ' 
                        +str(self.width_value[res])+' GeV )')
            logger.info('       BR                 d1  d2' )
            for decay in self.br[res]:
                bran = decay['br']
                d1 = decay['daughters'][0]
                d2 = decay['daughters'][1]
                logger.info('   %e            %s  %s ' % (bran, d1, d2) )
            logger.info('  ')

    def print_partial_widths(self):
        """ print a list of all known partial widths"""

        for res in self.br.keys():
            logger.info('  ')
            logger.info('decay channels for '+res+' :')
            logger.info('       width                     d1  d2' )

            for chan, decay in enumerate(self.br[res]):
                width=self.br[res][chan]['width']
                d1=self.br[res][chan]['daughters'][0]
                d2=self.br[res][chan]['daughters'][1]
                logger.info('   %e            %s  %s ' % (width, d1, d2) )
            logger.info('  ')


    def extract_br_from_width_evaluation(self, to_decay):
        """ use MadGraph7 to generate me's for res > all all  
        """
        raise DeprecationWarning

        if os.path.isdir(pjoin(self.path_me,"width_calculator")):
            shutil.rmtree(pjoin(self.path_me,"width_calculator"))
        
        assert not os.path.exists(pjoin(self.path_me, "width_calculator"))
        
        path_me = self.path_me 
        label2pid = self.label2pid
        # first build a set resonances with pid>0

        #particle_set= list(to_decay)
        pids = set([abs(label2pid[name]) for name in to_decay])
        particle_set = [label2pid[pid] for pid in pids]
    

        modelpath = self.model.get('modelpath')
        if os.path.basename(modelpath) != self.model['name']:
            name, restrict = self.model['name'].rsplit('-',1)
            if os.path.exists(pjoin(os.path.dirname(modelpath),name, 'restrict_%s.dat' % restrict)):
                modelpath = pjoin(os.path.dirname(modelpath), self.model['name'])
    
        commandline="import model %s\n" % modelpath
        commandline+="generate %s > all all \n" % particle_set[0]
        commandline+= "set automatic_html_opening False --no_save\n"
        if len(particle_set)>1:
            for index in range(1,len(particle_set)):
                commandline+="add process %s > all all \n" % particle_set[index]

        # Force the madevent structure regardless of MG5's default output mode
        # (now 'mg7', whose launcher requires lhapdf and does not give the
        # standard madevent layout this width computation drives).
        commandline += "output madevent %s/width_calculator -f \n" % path_me


        aloha.loop_mode = False
        aloha.unitary_gauge = False
        cmd = Cmd.MasterCmd()        
        for line in commandline.split('\n'):
            cmd.run_cmd(line)
        
        # WRONG Needs to takes the param_card from the input files.
        ff = open(pjoin(path_me, 'width_calculator', 'Cards', 'param_card.dat'),'w')
        ff.write(self.banner['slha'])
        ff.close()
        
        lhapdf = False
        if 'lhapdf' in os.environ:
            lhapdf = os.environ['lhapdf']
            del os.environ['lhapdf']
        
        # run but remove the pdf dependencies
        cmd.import_command_file(['launch',
                                 'set lpp1 0', 
                                 'set lpp2 0', 
                                 'done'])

        if lhapdf:
            os.environ['lhapdf'] = lhapdf
                
        #me_cmd = me_interface.MadEventCmd(pjoin(path_me,'width_calculator'))
        #me_cmd.exec_cmd('set automatic_html_opening False --no_save')

        filename=pjoin(path_me,'width_calculator','Events','run_01','param_card.dat')
        self.extract_br_from_card(filename)

    def extract_br_for_antiparticle(self):
        '''  
            for each channel with a specific br value, 
            set the branching fraction of the complex conjugated channel 
            to the same br value 
        '''
        
        label2pid = self.label2pid
        pid2label = self.label2pid
        for res in list(self.br.keys()):
            particle=self.model.get_particle(label2pid[res])
            if particle['self_antipart']: 
                continue
            anti_res=pid2label[-label2pid[res]]
            self.br[anti_res] = []
            if res in self.width_value: 
                self.width_value[anti_res]=self.width_value[res]
            elif anti_res in self.width_value:
                self.width_value[res]=self.width_value[anti_res]
                res, anti_res = anti_res, res
            for chan, decay in enumerate(self.br[res]):
                self.br[anti_res].append({})
                bran=decay['br']
                d1=decay['daughters'][0]
                d2=decay['daughters'][1]
                d1bar=pid2label[-label2pid[d1]]
                d2bar=pid2label[-label2pid[d2]]
                self.br[anti_res][chan]['br']=bran
                self.br[anti_res][chan]['daughters']=[]
                self.br[anti_res][chan]['daughters'].append(d1bar)
                self.br[anti_res][chan]['daughters'].append(d2bar)
                if 'width' in decay:
                    self.br[anti_res][chan]['width']=decay['width']                  

    def launch_width_evaluation(self,resonances, mgcmd):
        """ launch the calculation of the partial widths """

        label2pid = self.label2pid
        pid2label = self.label2pid
        model = self.model
        # first build a set resonances with pid>0
        # since compute_width cannot be used for particle with pid<0
        
        particle_set = set()
        for i, part in enumerate(resonances[:]):
            if part in mgcmd._multiparticles:
                for pid in mgcmd._multiparticles[part]:
                    particle_set.add(abs(pid))
                continue
            try:
                pid_part = abs(label2pid[part])
            except KeyError:
                pid_part = abs(label2pid[part.lower()]) 
                resonances[i] = part.lower()
            particle_set.add(abs(pid_part))  

        particle_set = list(particle_set)
        argument = {'particles': particle_set, 
                    'path': pjoin(self.path_me, 'param_card.dat'),
                    'output': pjoin(self.path_me, 'param_card.dat'),
                    'body_decay': 2}
        
        self.compute_widths(model, argument)
        self.extract_br_from_card(pjoin(self.path_me, 'param_card.dat'))
        self.banner['slha'] = open(pjoin(self.path_me, 'param_card.dat')).read()
        if hasattr(self.banner,'param_card'):
            del self.banner.param_card
        self.banner.charge_card('param_card')
        return      
          
    def compute_widths(self, model, opts):
        
        from madgraph.interface.master_interface import MasterCmd
        import madgraph.iolibs.helas_call_writers as helas_call_writers
        cmd = MasterCmd()
        #self.define_child_cmd_interface(cmd, interface=False)
        cmd.exec_cmd('set automatic_html_opening False --no_save')
        if not opts['path']:
            opts['path'] = pjoin(self.me_dir, 'Cards', 'param_card.dat')
            if not opts['force'] :
                self.ask_edit_cards(['param_card'],[])
        
        
        commandline = 'import model %s' % model.get('modelpath+restriction') 
        if not model.mg5_name:
            commandline += ' --modelname'
        cmd.exec_cmd(commandline)

        line = 'compute_widths %s %s' % \
                (' '.join([str(i) for i in opts['particles']]),
                 ' '.join('--%s=%s' % (key,value) for (key,value) in opts.items()
                        if key not in ['model', 'force', 'particles'] and value))

        #pattern for checking complex mass scheme.
        has_cms = re.compile(r'''set\s+complex_mass_scheme\s*(True|T|1|true|$|;)''', re.M)
        force_CMS =  has_cms.search(self.banner['mg5proccard'])
        if force_CMS:
            cmd.exec_cmd('set complex_mass_scheme')
#        cmd._curr_model = model
#        cmd._curr_fortran_model = helas_call_writers.FortranUFOHelasCallWriter(model)
        cmd.exec_cmd(line)
        #self.child = None
        del cmd                                

    def extract_br_from_banner(self, banner):
        """get the branching ratio from the banner object:
           for each resonance with label 'res', and for each channel with index i,
           returns a dictionary branching_fractions[res][i]
           with keys
            'daughters' : label of the daughters (only 2 body)
            'br' : value of the branching fraction"""
        
        self.br = {}
        
        # read the param_card internally to the banner
        if not hasattr(banner, 'param_card'):
            banner.charge_card('param_card')
        param_card = banner.param_card
        return self.extract_br_from_card(param_card)

    def extract_br_from_card(self, param_card):
        """get the branching ratio from the banner object:
           for each resonance with label 'res', and for each channel with index i,
           returns a dictionary branching_fractions[res][i]
           with keys
            'daughters' : label of the daughters (only 2 body)
            'br' : value of the branching fraction"""        
        
        if isinstance(param_card, str):
            import madgraph.models.check_param_card as check_param_card
            param_card = check_param_card.ParamCard(param_card)
        
        if 'decay' not in param_card or not hasattr(param_card['decay'], 'decay_table'):
            return self.br

        self.width_value={}
        for id, data in param_card['decay'].decay_table.items():
#           check is the new width is close to the one originally in the banner
            recalculated_width=param_card['decay'].param_dict[(id,)].value
            width_in_the_banner=self.banner.get('param_card', 'decay', abs(id)).value
            relative_diff=abs(recalculated_width-width_in_the_banner)/recalculated_width
            if (relative_diff > 0.05):
               logger.warning('The LO estimate for the width of particle %s ' % id)
               logger.warning('differs from the one in the banner by %d percent ' % (relative_diff*100))

            label = self.pid2label[id]
            current = [] # tmp name for  self.br[label]
            for parameter in data:
                if parameter.lhacode[0] == 2:
                    d = [self.pid2label[pid] for pid in  parameter.lhacode[1:]]
                    current.append({'daughters':d, 'br': parameter.value})
            self.br[label] = current
            self.width_value[label]=recalculated_width  

        #update the banner:
        self.banner.param_card = param_card
        self.banner.check_pid(self.pid2label, self.model.get('merged_particles'))
        self.banner['slha'] = self.banner.param_card.write(None)
        
        self.extract_br_for_antiparticle()
        return self.br


class decay_misc:
    """class with various methods for the decay"""

    @staticmethod
    def get_all_resonances(banner, mgcmd, allowed):
        """ return a list of labels of each resonance involved in the decay chain """
        allowed = list(allowed)
        found = set()
        alias = {} # if an allowed particle is inside a multiparticle
        
        # look at the content of the multiparticles in order to know which one
        # we need to track.
        multiparticles = mgcmd._multiparticles
        model = mgcmd._curr_model
        for name, content in multiparticles.items():
            curr = [model.get_particle(id).get('name') \
                              for id in content 
                              if model.get_particle(id).get('name') in allowed ]
            if found:
                alias[name] = set(curr)

        # Now look which of the possible decay that we need to look at are indeed
        # present in the final state of one process.
        for line in banner.proc_card:
            line.strip()
            if line.startswith('generate') or line.startswith('add process'):
                final_process = re.split(r'>.*>|>|[\$/,@\[]', line)[1]
                for search in allowed:
                    if search in final_process:
                        found.add(search)
                        allowed.remove(search)
                for search, data in alias.items():
                    if search in final_process:
                        found.update(data)
                        del alias[search]
                        
        # treat multiparticles
        finalfound = set()
        for name in found:
            if name in mgcmd._multiparticles:
                finalfound.update([model.get_particle(id).get('name') 
                                   for id in mgcmd._multiparticles[name]])
                finalfound.discard(name)
            else:
                finalfound.add(name)

        return finalfound
   
        
    def reorder_branch(self,branch):
        """ branch is a string with the definition of a decay chain
                If branch contains " A > B C , B > ... " 
                reorder into             " A > C B , B > ... "

        """
        branch=branch.replace(',', ' , ')
        branch=branch.replace(')', ' ) ')
        branch=branch.replace('(', ' ( ')
        list_branch=branch.split(" ")
        for index in range(len(list_branch)-1,-1,-1):
            if list_branch[index]==' ' or list_branch[index]=='': del list_branch[index]
        #print list_branch
        for index, item in enumerate(list_branch):

            if item[-1] =="," and list_branch[index+1]!="(":
                # search pos of B and C 
                counter=1
                while 1:
                  if list_branch[index-counter].find("=")<0:
                     break
                  counter+=1
                if list_branch[index-counter-1]==list_branch[index+1]:
                    # swap the two particles before the comma:
                    temp=list_branch[index-counter-1]
                    list_branch[index-counter-1]=list_branch[index-counter]
                    list_branch[index-counter]=temp
            if item[-1] =="," and list_branch[index+1]=="(":
                # search pos of B and C 
                counter=1
                while 1:
                  if list_branch[index-counter].find("=")<0:
                     break
                  counter+=1
                if list_branch[index-counter -1]==list_branch[index+2]:
                    # swap the two particles before the comma:
                    temp=list_branch[index-counter-1]
                    list_branch[index-counter-1]=list_branch[index-counter]
                    list_branch[index-counter]=temp

        new_branch=""
        for item in list_branch:
            new_branch+=item+" "

        return new_branch, list_branch[0]

    def set_light_parton_massless(self,topo):
        """ masses of light partons are set to zero for 
            the evaluation of the matrix elements
        """

        light_partons=[21,1,2,3]
        for part in topo["get_id"].keys():
            if abs(topo["get_id"][part]) in light_partons :
                topo["get_mass2"][part]=0.0

#    need to check if last branch is a t-branching. If it is, 
#    we need to update the value of branch["m2"]
#    since this will be used in the reshuffling procedure
        if len(topo["branchings"])>0:  # Exclude 2>1 self.topologies
            if topo["branchings"][-1]["type"]=="t":
                if topo["branchings"][-2]["type"]!="t":
                    logger.info('last branching is t-channel')
                    logger.info('but last-but-one branching is not t-channel')
                else:
                    part=topo["branchings"][-1]["index_d2"] 
                    if part >0: # reset the mass only if "part" is an external particle
                        topo["branchings"][-2]["m2"]=math.sqrt(topo["get_mass2"][part])

    @staticmethod
    def modify_param_card(pid2widths, path_me):
        """Modify the param_card w/r to what is read from the banner:
             if the value of a width is set to zero in the banner, 
             it is automatically set to its default value in this code
        """

        param_card=open(pjoin(path_me,'param_card.dat'), 'r')
        new_param_card=""
        while 1:
            line=param_card.readline()
            if line =="": break
            list_line=line.split()
            if len(list_line)>2:
                if list_line[0]=="DECAY" and int(list_line[1]) in list(pid2widths.keys()):
                    list_line[2]=str(pid2widths[int(list_line[1])]) 
                    line=""
                    for item in list_line:
                        line+=item+ "    "
                    line+="\n"
            new_param_card+=line

        param_card.close()
        param_card=open(pjoin(path_me, 'param_card.dat'), 'w')
        param_card.write(new_param_card) 
        param_card.close()


    def select_one_topo(self,prod_values):
#
#    prod_values[0] is the value of |M_prod|^2
#    prod_values[1], prod_values[2], ... are the values of individual diagrams
#                                                                            (called AMP2 in mg) 
#

# first evaluate the sum of all single diagram values
        total=0.0
        cumul=[0.0]
        for i in range(1,len(prod_values)):
            cumul.append(cumul[i-1]+float(prod_values[i]))
            total+=float(prod_values[i])

        for i in range(len(cumul)): cumul[i]=cumul[i]/total

        #print "Cumulative AMP2 values: "
        #print cumul
        select_topo=random.random()

        for i in range(1,len(cumul)):
            if select_topo>cumul[i-1] and select_topo<cumul[i]: 
                good_topo=i
                break

        #print "Selected topology"
        #print good_topo
        return good_topo, cumul
    
    def get_final_state_compact(self,final_state_full):

        dc_pos=final_state_full.find(",")

        if dc_pos>0:
            branch_list=final_state_full.split(",")
            del branch_list[0]
            list_obj=final_state_full.split()
            final_state_compact=""
            to_be_deleted=[]
            for index, obj in enumerate(list_obj):
                if obj==">":
                    to_be_deleted.append(list_obj[index-1])

            for obj in list_obj:
                if obj!=">" and obj!="," and obj not in to_be_deleted:
                    final_state_compact+=obj+"    "

            branches={}
            for branch in branch_list:
                list_part=branch.split()
                branches[list_part[0]]={"finalstate":list_part[2:]}
                branches[list_part[0]]["branch"], dummy= self.reorder_branch(branch)
        else:
            final_state_compact=final_state_full
            branches={}

        return final_state_compact, branches
                  
    def get_mean_sd(self,list_obj):
        """ return the mean value and the standard deviation of a list of reals """
        sum=0.0
        N=float(len(list_obj))
        for item in list_obj:
            sum+=item
        mean=sum/N
        sd=0.0
        for item in list_obj:
            sd+=(item-mean)**2
        if N > 1:
            sd=math.sqrt(sd/(N-1.0))
        else: 
            sd = mean/5.
        return mean, sd

class decay_all_events(object):

    # The legacy (madspin_v1) path evaluates matrix elements through a Fortran
    # helper communicating over a stdin/stdout pipe, so Fortran output has to be
    # UNbuffered or the ME values never reach the Python side (see __init__).
    # The density/onshell subclasses evaluate MEs in-process via f2py and do NOT
    # need this. Forcing GFORTRAN_UNBUFFERED_ALL there turns every LesHouches
    # event write into an immediate write() syscall; under a many-core decay
    # event (re)generation that storms the filesystem (APFS write-transaction
    # contention -> large "system" CPU). So gate it on the mode.
    _need_unbuffered_fortran_io = True

    def __init__(self, ms_interface, banner, inputfile, options):
        """Store all the component and organize special variable"""
    
        # input
        self.options = options
        #max_weight_arg = options['max_weight']  
        self.path_me = os.path.realpath(options['curr_dir']) 
        if options['ms_dir']:
            self.path_me = os.path.realpath(options['ms_dir'])
            if not os.path.exists(self.path_me):
                os.mkdir(self.path_me) 
        self.mgcmd = ms_interface.mg5cmd
        self.mscmd = ms_interface
        self.model = ms_interface.model
        self.banner = banner
        self.evtfile = inputfile
        # Pass model so that Event.get_tag() can remap actual PDG codes to
        # merged-particle IDs, matching the keys stored in AllMatrixElement.
        self.curr_event = Event(self.evtfile, banner, model=self.model)
        self.inverted_decay_mapping={}
        self.width_estimator = None
        self.curr_dir = os.getcwd()
        # dictionary to fortran evaluator
        self.calculator = {}
        self.calculator_nbcall = {}
        # need to unbuffer all I/O in fortran, otherwise the values of matrix
        # elements are not passed to the Python script (madspin_v1 pipe path).
        # Only the pipe-based modes need this -- see _need_unbuffered_fortran_io.
        if self._need_unbuffered_fortran_io:
            os.environ['GFORTRAN_UNBUFFERED_ALL']='y'
    
        # Remove old stuff from previous runs
        # so that the current run is not confused
        # Don't have to do that for gridpack / or if asked.
        if not (options["ms_dir"] or options["use_old_dir"]):
            if os.path.isdir(pjoin(self.path_me,"production_me")):
                shutil.rmtree(pjoin(self.path_me,"production_me"))
            if os.path.isdir(pjoin(self.path_me,"full_me")):
                shutil.rmtree(pjoin(self.path_me,"full_me"))    
            if os.path.isdir(pjoin(self.path_me,"decay_me")):
                shutil.rmtree(pjoin(self.path_me,"decay_me"))     
    
        # Prepare some dict useful for optimize model information
        # pid -> label and label -> pid
        self.pid2label=pid2label(self.model)
        self.banner.check_pid(self.pid2label, self.model.get('merged_particles'))
        self.pid2label.update(label2pid(self.model))
        self.pid2massvar={}
        self.pid2widthvar={}
        for part in self.model['particles']:
            self.pid2massvar[int(part['pdg_code'])]=part['mass']    
            self.pid2widthvar[int(part['pdg_code'])]=part['width']    

        # load the Monte Carlo masses
        self.MC_masses=self.get_MC_masses()

#        logger.info('Value of the Monte Carlo masses: ')
#        logger.info(self.MC_masses)


        # dictionary pid > color_rep
        self.pid2color = pid2color(self.model)

        # energy of the collider
        self.Ecollider=float(self.banner.get('run_card', 'ebeam1'))\
                       +float(self.banner.get('run_card', 'ebeam2'))


        # write down the seed:
        seedfile=open(pjoin(self.path_me, 'seeds.dat'),'w')
        seedfile.write('  %s \n' % self.options['seed'])
        seedfile.close()       
 
        # width and mass information will be filled up later

        
        if os.path.isfile(pjoin(self.path_me,"param_card.dat")):
            os.remove(pjoin(self.path_me,"param_card.dat"))        

        # now overwrite the param_card.dat in Cards:
        param_card=self.banner['slha']
        #param_card=decay_tools.check_param_card( param_card)

        # now we can write the param_card.dat:
        # Note that the width of each resonance in the    
        # decay chain should be >0 , we will check that later on
        model_name = os.path.basename(self.model.get('name'))
        param=open(pjoin(self.path_me,'param_card.dat'),"w")
        param.write(param_card)
        param.close()   
        if model_name == 'mssm' or model_name.startswith('mssm-'):
            #need to convert to SLHA2 format
            import madgraph.models.check_param_card as check_param_card
            check_param_card.convert_to_mg5card(pjoin(self.path_me,'param_card.dat'))
  
        
        self.list_branches = ms_interface.list_branches
        decay_ids = [self.pid2label[key] for key in self.list_branches \
                                                       if key in self.pid2label]
        for multi in self.mgcmd._multiparticles:
            if multi in self.list_branches:
                decay_ids += self.mgcmd._multiparticles[multi]
        self.all_ME = AllMatrixElement(banner, self.options, decay_ids, self.model)
        self.all_decay = {}


        # generate BR and all the square matrix element based on the banner.
        pickle_info = pjoin(self.path_me,"production_me", "all_ME.pkl")
        if not options["use_old_dir"] or not os.path.exists(pickle_info):
           
            self.generate_all_matrix_element()
            self.save_status_to_pickle(pickle_info)
        else:
            try:
                data = save_load_object.load_from_file(pjoin(self.path_me,"production_me", "all_ME.pkl"))
                data.restore_pickled_status(self.model, self.path_me)
                # run() needs these from all_decay (get_identical_decay); a
                # file written before they were stored cannot be reused
                if any('final_ids' not in d or 'tags' not in d
                       for d in data.all_decay.values()):
                    raise MadSpinError('%s predates the plain-data all_decay'
                                       % pickle_info)
                self.all_ME, self.all_decay,self.width_estimator = data.all_ME, data.all_decay, data.width_estimator
                # as get_branching_ratio does: the widths MadSpin computed are
                # what the branching ratio and the Breit-Wigner cut use
                if self.width_estimator:
                    self.banner.param_card = self.width_estimator.banner.param_card
                # the Fortran reads a ranmar_state.dat left by the previous run
                # in preference to seeds.dat: drop it, as run_from_pickle does,
                # so that this run follows its own seed
                for name in misc.glob(pjoin('*', 'SubProcesses', '*', 'ranmar_state.dat'),
                                      self.path_me):
                    os.remove(name)
                logger.info('use_old_dir: reusing the matrix elements in %s'
                            % self.path_me)
            except Exception as error:
                logger.debug(str(error))
                self.generate_all_matrix_element()
                # the same format as above: the live objects reach the UFO
                # model and do not pickle (save_to_file would swallow that and
                # leave a truncated file)
                self.save_status_to_pickle(pickle_info)
        
        if not self.options["onlyhelicity"] and \
            self.options['spinmode'] in  ['madspin_v1']:
            
            resonances = self.width_estimator.resonances
            logger.debug('List of resonances: %s' % resonances)
            self.extract_resonances_mass_width(resonances) 

        self.compile()


    def resolve_merged_pid_with_flavor(self, pid, flavor_tuple, me_index):
        """Resolve a merged-particle PDG to the selected concrete flavor."""
        if not flavor_tuple or me_index is None:
            return pid
        merged_particles = self.model.get('merged_particles') if self.model else {}
        merged_pid = abs(pid)
        if not self.model or merged_pid not in merged_particles:
            return pid
        if me_index < 1 or me_index > len(flavor_tuple):
            return pid
        selected = int(flavor_tuple[me_index - 1])
        members = merged_particles[merged_pid]
        if abs(selected) in members:
            resolved_abs = abs(selected)
        elif 1 <= abs(selected) <= len(members):
            resolved_abs = abs(members[abs(selected) - 1])
        else:
            return pid
        return resolved_abs if pid > 0 else -resolved_abs

    def pid2width(self, pid):
        try:
            return self.banner.get('param_card', 'decay', abs(pid)).value
        except Exception:
            if self.model and abs(pid) in self.model['merged_particles']:
                return self.banner.get('param_card', 'decay', abs(self.model['merged_particles'][abs(pid)][0])).value
            elif hasattr(self, 'merged_particles') and abs(pid) in self.merged_particles:
                # this can happens when gridpack mode is used
                return self.banner.get('param_card', 'decay', abs(self.merged_particles[abs(pid)][0])).value
            misc.sprint(pid)
            raise Exception('No width information for particle with pid %s' % pid)
            
    def pid2mass(self, pid):
        try:
            return self.banner.get('param_card', 'mass', abs(pid)).value
        except Exception:
            if self.model and abs(pid) in self.model['merged_particles']:
                return self.banner.get('param_card', 'mass', abs(self.model['merged_particles'][abs(pid)][0])).value
            elif hasattr(self, 'merged_particles') and abs(pid) in self.merged_particles:
                # this can happens when gridpack mode is used
                return self.banner.get('param_card', 'mass', abs(self.merged_particles[abs(pid)][0])).value
            misc.sprint(pid)
            raise Exception('No mass information for particle with pid %s' % pid)

    def save_to_file(self, *args):
        return save_load_object.save_to_file(*args)
    

    def get_MC_masses(self):
        
        MC_masses={}
        pid_heavyquarks=[4,5]
        if 'montecarlomasses' in self.banner:
            
            MC_masses_lines=self.banner['montecarlomasses'].split('\n')
            for line in MC_masses_lines:
                pidvalue=line.split()
                if len(pidvalue)<2: continue # skip blank lines
                pid=abs(int(pidvalue[0]))
                value=float(pidvalue[1])
                MC_masses[pid]=value
                if pid in pid_heavyquarks:
                    value_ME=self.banner.get('param_card','mass', pid).value
                    if value_ME>1E-10:
                        if pid==5:
                            logger.warning('set the mass of the b-quark to its value in the param_card.dat: %s GeV ' % value_ME)
                        if pid==4:
                            logger.warning('set the mass of the c-quark to its value in the param_card.dat: %s GeV ' % value_ME)
                        MC_masses[pid]=value_ME
            
        return MC_masses 

        
    def run(self):
        """Running the full code""" 
    
        max_weight_arg = self.options['max_weight']  
        decay_tools=decay_misc()
        
        #Next step: we need to determine which matrix elements are really necessary
        #==========================================================================
        decay_mapping = self.get_identical_decay()

        # also compute the inverted map, which will be used in the decay procedure       
        for tag in decay_mapping:
            for equiv_decay in decay_mapping[tag]:
                self.inverted_decay_mapping[equiv_decay[0]]=tag
 
        self.mscmd.update_status('MadSpin: Estimate the maximum weight')
        # Estimation of the maximum weight
        #=================================
        if max_weight_arg>0:
            for key in self.all_ME:
                for mode in self.all_ME['decays']:
                    mode['max_weight'] = max_weight_arg
        elif self.options["onlyhelicity"]:
            logger.info("not needed in helicity mode")
        else:
            #self.get_max_weight_from_1toN()
            self.get_max_weight_from_event(decay_mapping)  
        
        # add probability of not writing events (for multi production with
        # different decay
        self.add_loose_decay()
        # Store this object with all the associate number for gridpack:
        if self.options['ms_dir']:
            self.save_status_to_pickle()
    
        self.ending_run()
        
    # Name of the intermediate LHE file the legacy (madspin_v1) decay writes and
    # that MadSpinInterface then gzips into <events>_decayed.lhe.gz.
    DECAYED_EVENTS_NAME = 'decayed_events.lhe'

    @property
    def decayed_events_path(self):
        """The one place that decides where the decayed events are written.

        Both ends of the write/read pair must go through this property --
        ``decaying_events`` opens it, ``MadSpinInterface.do_launch`` and
        ``run_from_pickle`` gzip it -- because they used to compute it
        separately and disagreed (see tests/unit_tests/madspin, class
        TestDecayedEventsPath).

        It is ``curr_dir``, the run's output directory, and deliberately *not*
        ``path_me``:

        * ``path_me`` means "where the matrix-element directories live"
          everywhere else it is used (production_me/full_me/decay_me,
          decay_<pdg>_<i>, ms_wstatus_*, param_card.dat). Under ``ms_dir`` it is
          a directory that is built once and reused -- and possibly shared --
          by later runs, so per-run event output has no business there.
        * without ``ms_dir`` the two coincide (``path_me`` is *defined* as
          ``realpath(curr_dir)``), which is why the mismatch stayed hidden: it
          only bites when ``ms_dir`` is set *and* ``curr_dir`` is not the
          ms_dir, i.e. whenever the event file is imported after ``set ms_dir``
          (``post_set_ms_dir`` points ``curr_dir`` at the ms_dir, and
          ``do_import`` points it back at the event file's directory).

        The value is read off the *live* interface rather than ``self.options``
        on purpose: under ``ms_dir`` this object is restored from
        ``madspin.pkl``, so its own ``options`` -- pickled with the gridpack --
        still describe the run that *built* it, ``curr_dir`` included.
        """
        return pjoin(self.mscmd.options['curr_dir'], self.DECAYED_EVENTS_NAME)

    def ending_run(self):
        """launch the unweighting and deal with final information"""    
        # launch the decay and reweighting
        self.mscmd.update_status('MadSpin: Decaying Events')
        efficiency = self.decaying_events(self.inverted_decay_mapping)
        self.efficiency = efficiency
        if  efficiency != 1 and any(v==-1 for v in self.br_per_id.values()):
            # need to change the banner information [nb_event/cross section]
            files.cp(self.outputfile.name, '%s_tmp' % self.outputfile.name)
            self.outputfile = open(self.outputfile.name, 'w')
            self.write_banner_information(efficiency)
            pos = self.outputfile.tell()
            header = True
            for line in open('%s_tmp' % self.outputfile.name):
                if header:
                    if '</init>' in line:
                        header = False
                    continue
                self.outputfile.write(line)
            files.rm('%s_tmp' % self.outputfile.name)
            
        # Closing all run
        self.terminate_fortran_executables()
        # use_old_dir is the request to reuse them (production_me/all_ME.pkl)
        if not (self.options['ms_dir'] or self.options['use_old_dir']):
            shutil.rmtree(pjoin(self.path_me,'production_me'))
            shutil.rmtree(pjoin(self.path_me,'full_me'))
            if not self.options["onlyhelicity"]:
                shutil.rmtree(pjoin(self.path_me,'decay_me'))
        # set the environment variable GFORTRAN_UNBUFFERED_ALL 
        # to its original value
        #os.environ['GFORTRAN_UNBUFFERED_ALL']='n'

    def save_status_to_pickle(self, path=None):
        import madgraph.iolibs.save_load_object as save_load_object
        #don't store the event file in the pkl
        evt_file, self.evtfile = self.evtfile, None
        curr_event, self.curr_event = self.curr_event , None
        mgcmd, self.mgcmd = self.mgcmd, None
        mscmd, self.mscmd = self.mscmd , None
        #pid2mass, self.pid2mass = self.pid2mass, None
        #pid2width, self.pid2width = self.pid2width, None
        model=  self.model
        #
        if model:
            self.merged_particles = model['merged_particles']


        self.switch_all_model_instance(None)

        self.all_decay, bkp = str(self.all_decay), self.all_decay
        #self.all_ME, bkp2 = None , self.all_ME    
        #self.width_estimator, bkp3 = self.width_estimator, self.width_estimator  
        modelpath = model.get('modelpath')
        for me in self.all_ME:
            for d in self.all_ME[me]['decays']:
                d['decay_struct'] = str(d['decay_struct'])
        self.modelpath = modelpath

                

        if not path:
            name = pjoin(self.options['ms_dir'], 'madspin.pkl')
        else:
            name = path

        save_load_object.save_to_file(name, self)


        #restore the event file
        self.evtfile = evt_file
        self.curr_event = curr_event
        self.mgcmd = mgcmd
        self.mscmd = mscmd 
        #self.pid2mass = pid2mass
        #self.pid2width = pid2width
        

        self.all_decay = bkp 
        #self.all_ME = bkp2 
        #self.width_estimator = bkp3
        for me in self.all_ME:
            for d in self.all_ME[me]['decays']:
                if d['decay_struct'] and isinstance(d['decay_struct'] , str):
                    d['decay_struct'] = eval(d['decay_struct'])
        self.switch_all_model_instance(model)

    def restore_pickled_status(self, model, directory):
        """Undo save_status_to_pickle on an object loaded back from its file:
        madspin.pkl (run_from_pickle) or production_me/all_ME.pkl (use_old_dir).

        The file holds all_decay and every decay_struct as their repr and no
        model: the model is detached and only its merged_particles is kept.
        Both are put back here. all_ME is keyed by flavour-grouped tags, e.g.
        ((-81, 81), (-6, 6)), and the event only produces those through the
        model: without one, Event.get_tag returns the physical
        ((-2, 2), (-6, 6)) and load_event dies with a KeyError on the first
        quark-initiated event. The flavour indices handed to the compiled
        matrix elements are positions within a merged group, so a model that
        groups differently cannot stand in for the one ``directory`` was built
        with.
        """
        if isinstance(self.all_decay, str):
            self.all_decay = eval(self.all_decay)
        # the repr kept only the dict content: get_identical_decay needs the
        # methods back (use_old_dir reruns it; run_from_pickle does not)
        for decay in self.all_decay.values():
            if not isinstance(decay['dc_branch'], dc_branch_from_me):
                decay['dc_branch'] = dc_branch_from_me.from_dict(decay['dc_branch'])
        for production in self.all_ME.values():
            for decay in production['decays']:
                if isinstance(decay['decay_struct'], str):
                    decay['decay_struct'] = eval(decay['decay_struct'])
        pickled = getattr(self, 'merged_particles', None) or {}
        live = (model.get('merged_particles') if model else None) or {}
        if pickled != live:
            raise MadSpinError(
                "The directory %s was built with the flavour grouping %s, but "
                "the model of this event file groups %s. Its matrix elements "
                "cannot be reused for these events." % (directory, pickled, live))
        self.switch_all_model_instance(model)



    def switch_all_model_instance(self, model=None):
        """ For pickling/un-pickling, one need to remove/restore all model instance 
            also remove all 'matrix-element' info since those are not needed
        """
        
        self.model = model
        self.all_ME.model = model
        # Keep curr_event.model in sync so get_tag() uses the right merged_particles
        # (setting it drops the event's cached reverse map).
        if self.curr_event is not None:
            self.curr_event.model = model
        for proc in self.all_ME:
            if  'decays' in self.all_ME[proc]:
                for me in self.all_ME[proc]['decays']:
                    if 'matrix_element' not in me or not me['matrix_element']:
                        continue
                    me['matrix_element']['model'] = model
                    
                    to_clean = list(me['matrix_element']['decay_chains'])
                    while to_clean:
                        p = to_clean.pop()
                        p['model'] = model
                        try:
                            to_clean += p['decay_chains']
                        except KeyError:
                            continue
                    me['matrix_element'] = None
                #self.all_ME[proc]['decays'] = None

            if 'processes' in self.all_ME[proc]:
                for me in self.all_ME[proc]['processes'] or not me['matrix_element']:
                    if 'matrix_element' not in me:
                        continue
                    me['matrix_element']['model'] = model
                    to_clean = list(me['decay_chains'])
                    while to_clean:
                        p = to_clean.pop()
                        p['model'] = model
                        try:
                            to_clean += p['decay_chains']
                        except KeyError:
                            continue
                me['matrix_element'] = None

        for proc in self.all_ME:
            for me in self.all_ME[proc]['decays']:
                # the null decays of add_loose_decay have no decay_struct
                for d in me['decay_struct'] or ():
                    me['decay_struct'][d]['model'] = model

        for proc in self.all_decay:
            for me in self.all_decay[proc]['processes']:
                me['model'] = model
                to_clean = list(me['decay_chains'])
                while to_clean:
                        p = to_clean.pop()
                        p['model'] = model
                        try:
                            to_clean += p['decay_chains']
                        except KeyError:
                            continue

        if self.width_estimator:
            self.width_estimator.model = None
        
    def decaying_events(self,inverted_decay_mapping):
        """perform the decay of each events"""
        time_dec = time.time()
        decay_tools = decay_misc()
        # tools for checking if max_weight is too often broken.
        report = collections.defaultdict(int,{'over_weight': 0}) 


        logger.info(' ' )
        logger.info('Decaying the events... ')
        self.outputfile = open(self.decayed_events_path, 'w')
        self.write_banner_information()

        # Same reasoning as the run_onshell guard (see
        # MadSpinInterface._check_branching_ratio): this number multiplies every
        # weight written below, so a zero one would produce a complete LHE file
        # of +/-0.0 and report success. Skipped in 'onlyhelicity' mode, which
        # writes the events back without applying any branching ratio.
        if not self.options['onlyhelicity']:
            self.mscmd._check_branching_ratio(self.branching_ratio)


        event_nb, fail_nb = 0, 0
        nb_skip = 0 
        trial_nb_all_events=0
        starttime = time.time()
        nb_fail_mc_mass=0
        while 1: # loop on event file
            production_tag, event_map = self.load_event()
            if production_tag == 0 == event_map: #end of file
                break

            if  event_nb and \
                (event_nb % max(int(10**int(math.log10(float(event_nb)))),1000)==0): 
                running_time = misc.format_timer(time.time()-starttime)
                logger.info('Event nb %s %s' % (event_nb, running_time))
                self.mscmd.update_status(('$events',1,event_nb, 'decaying events'), 
                                         force=False, print_log=False)
            if (event_nb==10001): logger.info('reducing number of print status. Next status update in 10000 events')


            if self.options["onlyhelicity"]:
                trial_nb, fail = self.adding_only_helicity(event_map, production_tag)
                trial_nb_all_events+=trial_nb
                fail_nb += fail
                event_nb += 1
                continue

            # Here we need to select a decay configuration on a random basis:
            decay = self.all_ME.get_random_decay(production_tag)
            if not decay['decay_tag']:
                #Not writing events due to global reweighting
                nb_skip +=1
                continue 
            else:
                #  for the matrix element, identify the master decay channel to which 'decay' is equivalent:
                decay_tag_me=inverted_decay_mapping[decay['decay_tag']]
                try:
                    decay_me=self.all_ME.get_decay_from_tag(production_tag, decay_tag_me)
                except Exception:
                    #if the master didn't exist try the original one.
                    decay_me=self.all_ME.get_decay_from_tag(production_tag, decay['decay_tag'])
                    
                event_nb+=1
                report[decay['decay_tag']] += 1 

            indices_for_mc_masses, values_for_mc_masses=self.get_montecarlo_masses_from_event(decay['decay_struct'], event_map, decay['prod2full'])
            nb_mc_masses=len(indices_for_mc_masses)

            p, p_str=self.curr_event.give_momenta(event_map)
            # Compute the two flavor indices for the full ME driver:
            #   flavor_index_prod: which specific initial-state quarks are in this event
            #   flavor_index_full: same, but matching against the full-event flavor groups
            flavor_index_prod = self.curr_event.get_flavor_index(
                self.all_ME[production_tag].get('flavor_groups_prod', []), event_map)
            flavor_index_full = self.choose_full_flavor_index(
                production_tag, decay, decay_me, event_map)
            full_flavor_tuple = self.curr_event.get_selected_flavor_tuple(
                decay.get('flavor_combos_full'),
                flavor_index_full)
            if full_flavor_tuple is None:
                full_flavor_tuple = self.curr_event.get_selected_flavor_tuple(
                    decay_me.get('flavor_combos_full'),
                    flavor_index_full)
            # Use the per-flavor maxweight when available; fall back to the
            # global value for flavors not seen during the maxweight probing.
            mw_for_event = decay_me.get('max_weight_per_flavor', {}).get(
                flavor_index_full, decay_me['max_weight'])
            stdin_text=' %s %s %s %s %s %s %s %s %s\n' % ('2', self.options['BW_cut'], self.Ecollider, mw_for_event, self.options['frame_id'], self.options.beampol_me()[0], self.options.beampol_me()[1], flavor_index_prod, flavor_index_full)
            stdin_text+=p_str
            # here I also need to specify the Monte Carlo Masses
            stdin_text+=" %s \n" % nb_mc_masses
            if  nb_mc_masses>0:
                stdin_text+='%s  \n' % str(indices_for_mc_masses).strip('[]').replace(',', ' ')
                stdin_text+='%s  \n' % str(values_for_mc_masses).strip('[]').replace(',', ' ')
            
#            here apply the reweighting procedure in fortran
            output = self.loadfortran( 'unweighting', decay_me['path'], stdin_text)
            if not output:
                fail_nb +=1
                continue
            trial_nb, BWvalue, weight, momenta, failed, use_mc_masses, helicities = output 
            
            # next: need to fill all intermediate momenta
            if nb_mc_masses>0 and use_mc_masses==0:nb_fail_mc_mass+=1
            
            ext_mom=self.get_mom(momenta)
            # fill all momenta in the decay branches
            momenta_in_decay=self.get_int_mom_in_decay(decay['decay_struct'],ext_mom)
            # reset external momenta in the production event
            self.reset_mom_in_prod_event(decay['decay_struct'],decay['prod2full'],\
                                         event_map,momenta_in_decay,ext_mom, use_mc_masses, helicities)
            # reset intermediate momenta in prod event
            self.curr_event.reset_resonances()
            
            #
            decayed_event = self.decay_one_event_new(self.curr_event,decay['decay_struct'],\
                                                      event_map, momenta_in_decay,use_mc_masses, helicities,
                                                      full_flavor_tuple=full_flavor_tuple)
            
            
            # Treat the case we get too many failures for the PS generation.
            if failed > 500 :
                logger.debug('Got a production event with %s failures for the phase-space generation generation ' % failed)

            # Treat the case that we ge too many overweight.
            # Use the per-flavor maxweight consistent with what was passed to Fortran.
            # decay_me is the canonical ME entry used for the Fortran call; it may differ
            # from decay when inverted_decay_mapping redirects an equivalent channel (e.g.
            # z > l+ l- mapped to z > q q~).  The threshold must match mw_for_event above.
            decay_mw_for_event = decay_me.get('max_weight_per_flavor', {}).get(
                flavor_index_full, decay_me['max_weight'])
            # ``carry``: the overweight safety net (section 14 of
            # doc/madspin_sequential_plan.md). The Fortran
            # accept/reject (MadSpin/src/driver.f, "weight.gt.x*maxweight")
            # stops on a trial with probability min(1, weight/decay_mw_for_event), so a
            # weight above the bound is accepted with probability 1 and the
            # excess used to be dropped. Writing that event with weight
            # max(1, weight/decay_mw_for_event) restores the sampled density exactly,
            # since min(1,x)*max(1,x) = x. Left as the literal 1.0 when nothing
            # overflowed, so the written weights are bit-identical to before.
            # ``weight`` is the matrix-element weight the Fortran tested, not
            # the event's LHE weight, so ``carry`` is always > 1 and unsigned: a
            # negative production weight (an MC@NLO counter-event) keeps its
            # sign and only grows in magnitude.
            carry = 1.0
            if weight > decay_mw_for_event:
                carry = weight / decay_mw_for_event
                report['over_weight'] += 1
                # the accounting is on the WEIGHT, not on a count: a
                # counter-event whose trial overflowed makes the cross-section
                # more negative, so its excess subtracts. w_nom is what this
                # event would have been written with under clipping.
                w_nom = decayed_event.wgt * self.branching_ratio
                report['over_weight_dw'] += w_nom * (carry - 1.0)
                report['over_weight_dabs'] += abs(w_nom) * (carry - 1.0)
                report['%s_f' % (decay['decay_tag'],)] +=1
                if __debug__:               
                    misc.sprint('''over_weight: %s %s, occurrence: %s%%, occurence_channel: %s%%
                    production_tag:%s [%s], decay:%s [%s], BW_cut: %1g\n
                    ''' %\
                    (weight/decay_mw_for_event, decay['decay_tag'], 
                    100 * report['over_weight']/event_nb,
                    100 * report['%s_f' % (decay['decay_tag'],)] / report[decay['decay_tag']],
                    os.path.basename(self.all_ME[production_tag]['path']),
                    production_tag,
                    os.path.basename(decay['path']),
                    decay['decay_tag'],BWvalue))
                        
                
                if weight > 10.0 * decay_mw_for_event:
                    error = """Found a weight MUCH larger than the computed max_weight (ratio: %s). 
    This usually means that the Narrow width approximation reaches it's limit on part of the Phase-Space.
    Do not trust too much the tale of the distribution and/or relaunch the code with smaller BW_cut.
    This is for channel %s with current BW_value at : %g'""" \
                    % (weight/decay_mw_for_event, decay['decay_tag'], BWvalue)  
                    logger.error(error)
                elif report['over_weight'] > max(0.005*event_nb,3):
                    error = """Found too many weight larger than the computed max_weight (%s/%s = %s%%). 
    Please relaunch MS with more events/PS point by event in the
    computation of the maximum_weight.
                    """ % (report['over_weight'], event_nb, 100 * report['over_weight']/event_nb )  
                    raise MadSpinError(error)
                elif report['%s_f' % (decay['decay_tag'],)] > max(0.01*report[decay['decay_tag']],3):
                    error = """Found too many weight larger than the computed max_weight (%s/%s = %s%%),
    for channel %s. Please relaunch MS with more events/PS point by event in the
    computation of the maximum_weight.
                    """ % (report['%s_f' % (decay['decay_tag'],)],\
                            report['%s' % (decay['decay_tag'],)],\
                            100 * report['%s_f' % (decay['decay_tag'],)] / report[ decay['decay_tag']] ,\
                            decay['decay_tag'])  
                    raise MadSpinError(error)
                    
             
            # the carried overweight rides the branching ratio, so it reaches
            # both the event weight and every <rwgt> entry through the single
            # multiplication change_wgt already does
            decayed_event.change_wgt(factor= self.branching_ratio if carry == 1.0
                                     else self.branching_ratio * carry)
            #decayed_event.wgt = decayed_event.wgt * self.branching_ratio
            # the file as clipping would have written it: needed as the
            # denominator of the overweight report, and as the scale that says
            # whether that denominator is distinguishable from zero at all
            w_nom = decayed_event.wgt if carry == 1.0 else decayed_event.wgt / carry
            report['sum_nom'] += w_nom
            report['sum_abs_nom'] += abs(w_nom)
            report['sum_sq_nom'] += w_nom * w_nom

            self.outputfile.write(decayed_event.string_event())
                #print "number of trials: "+str(trial_nb)
            trial_nb_all_events+=trial_nb
            
             
                    
 
        self.outputfile.write('</LesHouchesEvents>\n')
        self.evtfile.close()
        self.outputfile.close()

        if report['over_weight'] > max(0.15*math.sqrt(event_nb),1):
            error = """Found many weight larger than the computed max_weight (%s/%s = %s%%). 
            """ % (report['over_weight'], event_nb, 100 * report['over_weight']/event_nb )  
            logger.warning(error)
        for decay_tag in self.all_decay.keys():
            if report['%s_f' % (decay_tag,)] > max(0.2*report[decay_tag],1):
                error = """Found many weight larger than the computed max_weight (%s/%s = %s%%),
    for channel %s.""" % (report['%s_f' % (decay_tag,)],\
                               report['%s' % (decay_tag,)],\
                               100 * report['%s_f' % (decay_tag,)] / report[decay_tag] ,\
                               decay_tag)
                logger.warning(error)  
        
        
        logger.info(f"Time for decay: {time.time() - time_dec:.2f} sec")
        logger.info('Total number of events written: %s/%s ' % (event_nb, event_nb+nb_skip))
        logger.info('Average number of trial points per production event: '\
            +str(float(trial_nb_all_events)/float(event_nb)))
        logger.info('Branching ratio to allowed decays: %g' % self.branching_ratio)
        logger.info('Number of events with weights larger than max_weight: %s' % report['over_weight'])
        # The overweight safety net's measurement, the same convention as the
        # density path's _report_overweight: how many events carry a non-unit
        # weight, and what the carried excess is worth as a fraction of the
        # sample's cross-section (IDWTUP = -4: sigma is the MEAN of the
        # weights, and carrying changes no event count, so d(sum w)/sum w is
        # the relative shift). The excess is summed WEIGHTED, so a
        # counter-event's overflow subtracts instead of adding; and sum w is
        # only used as a denominator when it is not itself ~0.
        if event_nb:
            if report['over_weight']:
                d_w = report['over_weight_dw']
                d_abs = report['over_weight_dabs']
                sum_w = report['sum_nom']
                sum_abs = report['sum_abs_nom']
                delta = math.sqrt(report['sum_sq_nom'])
                z = (abs(sum_w) / delta) if delta else 0.0
                # built with % here, not handed to the logger as a format
                # string: the head already contains literal per-cent signs
                msg = ("MadSpin overweight safety net: %d/%d written events "
                       "(%.3g%%) carried a non-unit weight because a trial "
                       "weight exceeded max_weight. "
                       % (report['over_weight'], event_nb,
                          100.0 * report['over_weight'] / event_nb))
                # sum w is only a denominator when it is distinguishable
                # from zero -- 5 of its own Monte Carlo errors, the same test
                # the density path uses (_OVERWEIGHT_MIN_Z)
                if z >= 5.0:
                    msg += ("Carrying it added %+.6g to the summed event "
                            "weight, i.e. %+.3g%% of the sample's "
                            "cross-section. " % (d_w, 100.0 * d_w / sum_w))
                else:
                    msg += ("Carrying it added %+.6g to the summed event "
                            "weight and %+.6g to the summed |weight|; the "
                            "summed weight is %+.4g against a Monte Carlo "
                            "error of %.4g (z = %.2f), i.e. consistent with "
                            "zero, so it is not a usable denominator and the "
                            "shift is quoted against sum|w| = %.4g instead: "
                            "%+.3g%%. "
                            % (d_w, d_abs, sum_w, delta, z, sum_abs,
                               100.0 * d_abs / sum_abs if sum_abs
                               else float('nan')))
                msg += ("Clipping it -- what MadSpin did before -- would have "
                        "discarded that silently.")
                logger.warning(msg)
            else:
                logger.info(
                    "MadSpin overweight safety net: 0/%d written events "
                    "carried a non-unit weight -- max_weight was never "
                    "exceeded, so nothing was clipped and nothing is biased "
                    "by it.", event_nb)
        logger.info('Number of subprocesses '+str(len(self.calculator)))
        logger.info('Number of failures when restoring the Monte Carlo masses: %s ' % nb_fail_mc_mass)
        if fail_nb:
            logger.info('Number of failures in reshuffling (event skipped): %s ' % fail_nb)
        
        return  event_nb/(event_nb+nb_skip)       


    def adding_only_helicity(self, event_map, production_tag):
        """no decays for this production mode, run in passthrough mode,
           only adding the helicities to the events """

        #no decays for this production mode, run in passthrough mode, only adding the helicities to the events
        nb_mc_masses=0
        p, p_str=self.curr_event.give_momenta(event_map)
        try: 
            frameid = self.options['frame_id']
        except KeyError:
            frameid = 6
        try:
            beampol = self.options.beampol_me()
        except KeyError:
            beampol = (1.0, 1.0)
        mepath = self.all_ME[production_tag]['path']
        decay = self.all_ME[production_tag]['decays'][0]
        decay_me=self.all_ME.get_decay_from_tag(production_tag, decay['decay_tag'])
        mepath = decay_me['path']
        # Compute both flavor indices for the two-index header format of driver.f
        flavor_index_prod = self.curr_event.get_flavor_index(
            self.all_ME[production_tag].get('flavor_groups_prod', []), event_map)
        flavor_index_full = self.get_full_flavor_index(
            production_tag, decay_me, event_map)
        stdin_text=' %s %s %s %s %s %s %s %s %s\n' % ('2', self.options['BW_cut'], self.Ecollider, 1.0, frameid, beampol[0], beampol[1], flavor_index_prod, flavor_index_full)
        stdin_text+=p_str
        # here I also need to specify the Monte Carlo Masses
        stdin_text+=" %s \n" % nb_mc_masses
                        
        output = self.loadfortran( 'unweighting', mepath, stdin_text)
        if not output:
            # Event fail
            return 0, 1
        trial_nb, BWvalue, weight, momenta, failed, use_mc_masses, helicities = output                
        self.reset_helicityonly_in_prod_event(event_map, helicities)

        decayed_event = self.curr_event
        self.outputfile.write(decayed_event.string_event())
        #print "number of trials: "+str(trial_nb)
        
        return trial_nb, 0


    def get_int_mom_in_decay(self,decay_struct,ext_mom):
        """  fill  """
        momenta_in_decay={}
        for part in decay_struct.keys():
            branch=decay_struct[part]['mg_tree']
            nb_splitting=len(branch)
            for split in range(nb_splitting-1,-1,-1): 
                mother=branch[split][0]
                d1=branch[split][1]
                d2=branch[split][2]
                if d1>0:
                    momenta_in_decay[d1]=ext_mom[d1-1]  # list_momenta is ordered according to ME
                if d2>0:
                    momenta_in_decay[d2]=ext_mom[d2-1]  # list_momenta is ordered according to ME
                momenta_in_decay[mother]=momenta_in_decay[d1].add(momenta_in_decay[d2])
                
        return momenta_in_decay
    
    def reset_mom_in_prod_event(self, decay_struct,prod2full, event_map, momenta_in_decay,ext_mom,use_mc_masses,helicities):

        """ Reset the external momenta in the production event, since
            the virtuality of decaying particles has slightly changed the kinematics
        """
       
        for index in self.curr_event.event2mg.keys():
            if self.curr_event.event2mg[index]>0:
                part=self.curr_event.event2mg[index]       # index for production ME
                part_for_curr_evt=event_map[part-1]+1 # index for curr event
                pid=self.curr_event.particle[part_for_curr_evt]['pid']
                if part in decay_struct:
                    id_res=decay_struct[part]['mg_tree'][0][0]
                    self.curr_event.particle[part_for_curr_evt]['momentum']=momenta_in_decay[id_res].copy()
                    self.curr_event.particle[part_for_curr_evt]['mass']=self.curr_event.particle[part_for_curr_evt]['momentum'].m
                else:
                    self.curr_event.particle[part_for_curr_evt]['momentum']=ext_mom[prod2full[part-1]-1]
                    self.curr_event.particle[part_for_curr_evt]['helicity']=helicities[prod2full[part-1]-1]
                    if not use_mc_masses or abs(pid) not in self.MC_masses:
                        try:
                            self.curr_event.particle[part_for_curr_evt]['mass']=self.banner.get('param_card','mass', abs(pid)).value
                        except KeyError:
                            # pid may be a merged-particle ID (e.g. 81) not present in
                            # param_card; resolve to a real member first, then ask the
                            # model whether the particle is massless.
                            actual_pid = abs(pid)
                            particle = self.model.get_particle(actual_pid)
                            if particle is None:
                                merged_map = self.model.get('merged_particles')
                                if actual_pid in merged_map:
                                    particle = self.model.get_particle(abs(merged_map[actual_pid][0]))
                            if particle is not None and particle.get('mass', '').lower() == 'zero':
                                self.curr_event.particle[part_for_curr_evt]['mass'] = 0
                            else:
                                raise
                    else:
                        self.curr_event.particle[part_for_curr_evt]['mass']=self.MC_masses[abs(pid)]

 
    def reset_helicityonly_in_prod_event(self, event_map, helicities):

        """ Reset the external momenta in the production event, since
            the virtuality of decaying particles has slightly changed the kinematics
        """
       
        for index in self.curr_event.event2mg.keys():
            if self.curr_event.event2mg[index]>0:
                part=self.curr_event.event2mg[index]       # index for production ME
                part_for_curr_evt=event_map[part-1]+1 # index for curr event
                pid=self.curr_event.particle[part_for_curr_evt]['pid']
                self.curr_event.particle[part_for_curr_evt]['helicity']=helicities[part-1]
        for index in self.curr_event.resonance:
            #part=self.curr_event.event2mg[index]       # index for production ME
            #part_for_curr_evt=event_map[part-1]+1 # index for curr event
            self.curr_event.resonance[index]['helicity']=9 
            #part['helicity'] = 9    


    def get_mom(self,momenta):
        """ input: list of momenta in a string format 
            output: list of momenta in a 'momentum' format
        """
        output=[]
        for item in momenta:
            comps=item.split()
            mom=momentum(float(comps[0]),float(comps[1]),float(comps[2]),float(comps[3]))
            output.append(mom)
        return output
        
    def get_identical_decay(self):
        """identify the various decay which are identical to each other"""
        
        logger.info('detect independent decays')
        start = time.time()
        # Possbilitiy to Bypass this step 
        if len(self.all_decay) == 1:
            relation = {}
            base_tag = None
            for prod in self.all_ME.values():
                for decay in prod['decays']:
                    tags = decay['decay_tag']
                    for tag in tags:
                        if not base_tag:
                            relation[tag] = (tag, 1)
                            base_tag = tag
                        elif (tag,1) not in relation[base_tag]:
                            relation[tag] = (base_tag,1)
            decay_mapping = self.get_process_identical_ratio(relation)
            return decay_mapping
        
        BW_cut = self.options['BW_cut']       
        #class the decay by class (nbody/pid)
        nbody_to_decay = collections.defaultdict(list)
        for decay in self.all_decay.values():
            id = decay['dc_branch']['tree'][-1]['label']
            id_final = decay['final_ids']
            cut = 0.0 
            mass_final = tuple([m if m> cut else 0 for m in map(self.pid2mass, id_final)])
            
            nbody_to_decay[(decay['nbody'], abs(id), mass_final)].append(decay)
        
        relation = {} # {tag: {(tag2, ratio)}}
        # Loop over the class and create the relation information about the 1     
        for ((nbody, pid, finals),decays) in nbody_to_decay.items():
            if len(decays) == 1:
                continue  
            mom_init = momentum(self.pid2mass(pid), 0, 0, 0)
            
            # create an object for the validation, keeping the ratio between
            # MEM i and MEM j. this is set at zero when the ratio is not found
            #constant
            valid = dict([ ((i, j), True) for j in range(len(decays)) 
                                          for i in range(len(decays)) 
                                          if i != j])
                
            for nb in range(125):
                tree, jac, nb_sol = decays[0]['dc_branch'].generate_momenta(mom_init,\
                                        True, self.pid2width, self.pid2mass, BW_cut,self.Ecollider)
                if not tree:
                    continue
                p_str = '%s\n%s\n'% (tree[-1]['momentum'],
                    '\n'.join(str(tree[i]['momentum']) for i in range(1, len(tree))
                                                                  if i in tree))
                
                values = {}                
                for i in range(len(decays)):
                    if any([valid[(i,j)] for j in range(len(decays)) if i !=j]):
                        # TODO(flavor): pass the actual flavor_index for this
                        #   decay instead of the default 1. The flavor_index
                        #   should be obtained from the event (not available
                        #   here); adapt once Event.get_flavor_index() is
                        #   wired into this code path.
                        values[i] = self.calculate_matrix_element('decay', 
                                                       decays[i]['path'], p_str)
                    else:
                        #skip computation if all possibility are ruled out.
                        values[i] = 0
                              
                #check if the ratio is constant for all possibilities
                for i in range(len(decays)):
                    for j in range(i+1, len(decays)):
                        if values[i] == 0 or values[j] == 0 or valid[(i,j)] == 0:
                            continue # already not valid
                        elif valid[(i,j)] is True:
                            valid[(i,j)] = values[j]/values[i]
                            valid[(j,i)] = valid[(i,j)]
                        elif (valid[(i,j)] - values[j]/values[i]) < 1e-6 * (valid[(i,j)] + values[j]/values[i]):
                            pass
                        else:
                            valid[(i, j)] = 0
                            valid[(j, i)] = 0
                
            if __debug__: 
                for i in range(len(decays)):
                    comment= "| "
                    for j in range(len(decays)):
                        if i == j:
                            comment+= "%4e " % 1
                            continue
                        comment+=  "%4e " % valid[(i,j)]
                    comment+= "|"+ os.path.basename(decays[i]['path'])                     
                    logger.debug(comment)
            # store the result in the relation object. (using tag as key)
            for i in range(len(decays)):
                tag_i = decays[i]['tag'][2:]
                for j in range(i+1, len(decays)): 
                    tag_j = decays[j]['tag'][2:]     
                    if valid[(i,j)] and tag_j not in relation:
                        relation[tag_j] = (tag_i, valid[(i,j)])
                        
        # fill the object with the already identify to one decay.
        #and add those who doesn't have any relations.
        for decay in self.all_decay.values():
            tags = [tag[2:] for tag in decay['tags']]
            init_tag = tags[0]
            if init_tag not in relation:
                out = (init_tag, 1)
            else:
                out = relation[init_tag]
            for tag in tags[1:]:
                relation[tag] = out

        decay_mapping = self.get_process_identical_ratio(relation)
        
        logger.info('Done in %ss' % (time.time()-start))
        return decay_mapping


    def get_process_identical_ratio(self, relation):
        # Now that we have ratio relation between each tag, we need to say 
        #what is the relation between the decay of the production process.
        #This is not only the product since some decay can be equivalent.
        
        decay_mapping = {} # final output: {first_process: [(equiv_proc, ratio), ...]
        tag2real = {}    # basic tag [the one related via relation] -> first process
        # basic tag ratio doesn't have any identical factor (this simplify calculation)
        nb=0
        for prod in self.all_ME.values():
            for decay in prod['decays']:
                tag = decay['decay_tag']
                nb+=1
                # build the basic tag (all equiv process are related to this tag)
                basic_tag = []
                ratio = 1
                for t in tag:
                    if  t in relation:
                        basic_tag.append(relation[t][0])
                        ratio *= relation[t][1]
                    else:
                        basic_tag.append(t)
                basic_tag = tuple(basic_tag)
                
                # compute identical factor ratio compare to a fully different decay
                #that we have assume for the basic tag
                if len(set(tag)) != len(tag):
                    for t in set(tag):
                        ratio /= math.factorial(tag.count(t))
                
                # Now build the output
                if basic_tag not in tag2real:
                    tag2real[basic_tag] = (tag, ratio)
                    decay_mapping[tag] = set([(tag, 1)])
                    ratio2=1
                else:
                    real_tag, ratio2 = tag2real[basic_tag]
                    if real_tag != tag:
                        decay_mapping[real_tag].add((tag, ratio/ratio2))


        return decay_mapping
    

    @misc.mute_logger()
    @misc.set_global()
    def generate_all_matrix_element(self):
        """generate the full series of matrix element needed by Madspin.
        i.e. the undecayed and the decay one. And associate those to the 
        madspin production_topo object"""

        # 1. compute the partial width        
        # 2. compute the production matrix element
        # 3. create the all_topology object 
        # 4. compute the full matrix element (use the partial to throw away 
        #     pointless decay.
        # 5. add the decay information to the all_topology object (with branching
        #     ratio)  
        
        
        # 0. clean previous run ------------------------------------------------
        path_me = self.path_me
        try:
            shutil.rmtree(pjoin(path_me,'full_me'))
        except Exception: 
            pass
        try:
            shutil.rmtree(pjoin(path_me,'production_me'))
        except Exception as error:
            pass
        path_me = self.path_me        
        
        # 1. compute the partial width------------------------------------------
        if not self.options["onlyhelicity"]:
            self.get_branching_ratio()
        
        # 2. compute the production matrix element -----------------------------
        processes = [line[9:].strip() for line in self.banner.proc_card
                     if line.startswith('generate')]
        processes += [' '.join(line.split()[2:]) for line in self.banner.proc_card
                      if re.search(r'^\s*add\s+process', line)]
        
        mgcmd = self.mgcmd
        modelpath = self.model.get('modelpath+restriction')

        # NLO contexts (loop_interface) force apply_flavor_grouping=False, which
        # collapses get_external_flavors() to a single trivial entry and breaks
        # merged-particle handling in MadSpin.  Re-enable it before reloading
        # the model so the production MEs share the LO multi-flavor treatment.
        mgcmd.exec_cmd('set apply_flavor_grouping True')

        commandline="import model %s" % modelpath
        if not self.model.mg5_name:
            commandline += ' --modelname'

        mgcmd.exec_cmd(commandline)
        # Handle the multiparticle of the banner        
        #for name, definition in self.mscmd.multiparticles:
        if hasattr(self.mscmd, 'multiparticles_ms'):
            for name, pdgs in  self.mscmd.multiparticles_ms.items():
                if name == 'all':
                    continue
                #self.banner.get('proc_card').get('multiparticles'):
                try:
                    mgcmd.do_define("%s = %s" % (name, ' '.join(repr(i) for i in pdgs)))
                except Exception as e:
                    pass

        mgcmd.exec_cmd("set group_subprocesses False")
        logger.info('generating the production square matrix element')
        start = time.time()
        commandline=''
        for proc in processes:
            if '[' in proc:
                commandline += reweight_interface.ReweightInterface.get_LO_definition_from_NLO(proc, mgcmd._curr_model)
            else:
                commandline += 'add process %s; ' % proc
                               
        commandline = commandline.replace('add process', 'generate',1)
        logger.info(commandline)
        
        mgcmd.exec_cmd(commandline, precmd=True)
        commandline = 'output standalone_msP %s %s' % \
        (pjoin(path_me,'production_me'), ' '.join(list(self.list_branches.keys())))        
        mgcmd.exec_cmd(commandline, precmd=True)        
        logger.info('Done %.4g' % (time.time()-start))

        # 3. Create all_ME + topology objects ----------------------------------
        
        matrix_elements = mgcmd._curr_matrix_elements.get_matrix_elements()
        
        self.all_ME.adding_me(matrix_elements, pjoin(path_me,'production_me'))

        # Store production ME flavor data in all_ME for use at compile time (point 2)
        for me in matrix_elements:
            tag = me.get('processes')[0].get_initial_final_ids()
            if tag in self.all_ME:
                nexternal, flavor_combos, pdg_to_group_pos, flavor_groups = \
                    self.get_flavor_data_from_me(me)
                self.all_ME[tag]['flavor_combos_prod'] = (
                    nexternal, flavor_combos, pdg_to_group_pos)
                self.all_ME[tag]['flavor_groups_prod'] = flavor_groups
        
        # 3b. simplify list_branches -------------------------------------------
        # remove decay which are not present in any production ME.
        final_states = set()        
        for me in matrix_elements:
            for leg in me.get('base_amplitude').get('process').get('legs'):
                if not leg.get('state'):
                    continue
                label = self.model.get_particle(leg.get('id')).get_name()
                if self.all_ME.has_particles_ambiguity:
                    final_states.add(self.pid2label[-1*self.pid2label[label]])
                final_states.add(label)
        for key in list(self.list_branches.keys()):
            if key not in final_states and key not in self.mgcmd._multiparticles:
                if (len(self.list_branches)>1):
                    del self.list_branches[key]
                elif not self.options["onlyhelicity"]:
                    raise Exception(" No decay define for process.")
                    logger.info('keeping dummy decay for passthrough mode')

        # 4. compute the full matrix element -----------------------------------
        if not self.options["onlyhelicity"]:
            logger.info('generating the full matrix element squared (with decay)')
            start = time.time()
            to_decay = list(self.mscmd.list_branches.keys())
            decay_text_correlated = {'':[]}
            for decays in self.mscmd.list_branches.values():
                for decay in  decays:
                    correlated = ''
                    if '@' in decay:
                        decay, correlated = decay.split('@')
                        correlated = correlated.strip()
                        if correlated not in decay_text_correlated:
                            decay_text_correlated[correlated] = []
                    curr = decay_text_correlated[correlated]
                    if '=' not in decay:
                        decay += ' QCD=99'
                    if ',' in decay:
                        curr.append('(%s)' % decay)
                    else:
                        curr.append(decay)
            decay_text = ', '.join(decay_text_correlated[''])
            del decay_text_correlated['']
            commandline = ''
            if not decay_text_correlated:
                for proc in processes:
                    if not proc.strip().startswith(('add','generate')):
                        proc = 'add process %s' % proc
                    commandline += self.get_proc_with_decay(proc, decay_text, mgcmd._curr_model, self.options)
                commandline = commandline.replace('add process', 'generate',1)
            else:
                for key in decay_text_correlated:
                    for proc in processes:
                        if not proc.strip().startswith(('add','generate')):
                            proc = 'add process %s' % proc
                        if decay_text:
                            one_decay = decay_text + ',' + ', '.join(decay_text_correlated[key])
                        else:
                            one_decay = ', '.join(decay_text_correlated[key])
                        commandline += self.get_proc_with_decay(proc, one_decay, mgcmd._curr_model, self.options)
                commandline = commandline.replace('add process', 'generate',1)
            logger.info(commandline)
            mgcmd.exec_cmd(commandline, precmd=True)
            # remove decay with 0 branching ratio.
            mgcmd.remove_pointless_decay(self.banner.param_card)
            commandline = 'output standalone_msF %s %s' % (pjoin(path_me,'full_me'),
                                                          ' '.join(list(self.list_branches.keys())))
            mgcmd.exec_cmd(commandline, precmd=True)
            logger.info('Done %.4g' % (time.time()-start))
        elif self.options["onlyhelicity"]:
            logger.info("Helicity Matrix-Element")      
            commandline = 'output standalone_msF %s %s' % \
            (pjoin(path_me,'full_me'), ' '.join(list(self.list_branches.keys())))        
            mgcmd.exec_cmd(commandline, precmd=True)        
            logger.info('Done %.4g' % (time.time()-start))                    



        # 5. add the decay information to the all_topology object --------------                        
        for matrix_element in mgcmd._curr_matrix_elements.get_matrix_elements():
            me_path = pjoin(path_me,'full_me', 'SubProcesses', \
                       "P%s" % matrix_element.get('processes')[0].shell_string())
            self.all_ME.add_decay(matrix_element, me_path)
            # Store full ME flavor data for this decay path (point 2)
            nexternal, flavor_combos, pdg_to_group_pos, flavor_groups = \
                self.get_flavor_data_from_me(matrix_element)
            tag = matrix_element.get('processes')[0].get_initial_final_ids()
            for dico in self.all_ME[tag]['decays']:
                if dico['path'] == me_path and 'flavor_combos_full' not in dico:
                    dico['flavor_combos_full'] = (nexternal, flavor_combos,
                                                  pdg_to_group_pos)
                    dico['flavor_groups_full'] = flavor_groups
                    break

        # 5.b import production matrix elements (+ related info) in the full process directory
        list_prodfiles=['matrix_prod.f','configs_production.inc','props_production.inc','nexternal_prod.inc']
        for tag in self.all_ME:
            prod_path=self.all_ME[tag]['path']
            nfinal=len(self.all_ME[tag]['base_order'][1])
            for dico in self.all_ME[tag]['decays']:
                full_path=dico['path']
                #print prod_path
                #print full_path
                #print ' '
                for item in list_prodfiles:
                     #print full_path
                     prodfile=pjoin(prod_path,item)
                     destination=pjoin(full_path,item)
                     shutil.copyfile(prodfile, destination)  
                # we need to write the file config_decays.inc
                self.generate_configs_file(nfinal,dico,full_path)
                

        if self.options["onlyhelicity"]:
            return

        # 6. generate decay only part ------------------------------------------
        logger.info('generate matrix element for decay only (1 - > N).')
        start = time.time()
        commandline = ''
        i=0
        for processes in self.list_branches.values():
            for proc in processes:
                if "@" in proc:
                    proc = proc.split("@",1)[0]
                commandline+="add process %s @%i --no_warning=duplicate;" % (proc,i)
                i+=1        
        commandline = commandline.replace('add process', 'generate',1)
        mgcmd.exec_cmd(commandline, precmd=True)
        # remove decay with 0 branching ratio.
        mgcmd.remove_pointless_decay(self.banner.param_card)
        #
        commandline = 'output standalone_msF %s' % pjoin(path_me,'decay_me')
        logger.info(commandline)
        mgcmd.exec_cmd(commandline, precmd=True)
        logger.info('Done %.4g' % (time.time()-start))        
        #
        self.all_decay = {}
        for matrix_element in mgcmd._curr_matrix_elements.get_matrix_elements():
            me = matrix_element.get('processes')[0]
            me_string = me.shell_string()
            dirpath = pjoin(path_me,'decay_me', 'SubProcesses', "P%s" % me_string)
            # Store decay ME flavor data for compile time (point 2)
            nexternal, flavor_combos, pdg_to_group_pos, flavor_groups = \
                self.get_flavor_data_from_me(matrix_element)
            # final_ids and tags are what get_identical_decay needs from the
            # processes, kept as plain data: all_decay is pickled as its repr
            # (the processes reach the UFO model, which does not pickle), and
            # what comes back is dicts, not Process objects.
            self.all_decay[me_string] = {'path': dirpath, 
                                         'dc_branch':dc_branch_from_me(me),
                                         'nbody': len(me.get_final_ids_after_decay()),
                                         'processes': matrix_element.get('processes'),
                                         'final_ids': me.get_final_ids_after_decay(),
                                         'tags': [p.shell_string(pdg_order=True)
                                                  for p in matrix_element.get('processes')],
                                         'tag': me.shell_string(pdg_order=True),
                                         'flavor_combos_decay': (nexternal,
                                                                  flavor_combos,
                                                                  pdg_to_group_pos),
                                         'flavor_groups_decay': flavor_groups}
        # Rebuild full-ME flavor data from the production flavor tuples and the
        # decay-only flavor tuples.  This preserves the full cross product of
        # compatible decay channels (e.g. 4 x 4 = 16 entries for WW -> 4j)
        # instead of the canonical subset returned directly by the grouped full
        # matrix element.
        for production_tag, prod_data in self.all_ME.items():
            for decay_dico in prod_data['decays']:
                full_fdata = self.build_full_flavor_data(
                    production_tag, decay_dico['matrix_element'])
                if full_fdata is None:
                    continue
                nexternal, flavor_combos, pdg_to_group_pos, flavor_groups = \
                    full_fdata
                decay_dico['flavor_combos_full'] = (nexternal, flavor_combos,
                                                    pdg_to_group_pos)
                decay_dico['flavor_groups_full'] = flavor_groups
        #
#        if __debug__:
#            #check that all decay matrix element correspond to a decay only
#            for prod in self.all_ME.values():
#                for decay in prod['matrix_element']['base_amplitude']['process']['decay_chains']:
#                    assert decay.shell_string() in self.all_decay
            
    @staticmethod
    def get_proc_with_decay(proc, decay_text, model, msoptions=None):
        
        commands = []
        if '[' in proc:
            new_command = reweight_interface.ReweightInterface.get_LO_definition_from_NLO(proc, model)
            new_procs = new_command.split(';')
        else:
            new_procs = [proc]
        for new_proc in new_procs:
            new_proc= new_proc.strip()
            if new_proc.endswith(';'):
                new_proc = new_proc[:-1]
            #catch line like "define" where no decay need to be added
            if not new_proc.strip():
                continue
            if new_proc.startswith('p '):
                new_proc = 'add process %s' % new_proc
                logger.critical("wrongly formatted input for MadSpin. Please report this!")
            elif not new_proc.startswith(('add', 'generate')):
                commands.append(new_proc)
                continue
            
            # check options
            tmp, options = [], set(["--no_warning=duplicate"])
            for arg in new_proc.split():
                if arg.startswith('--'):
                    options.add(arg)
                else:
                    tmp.append(arg)
            new_proc = ' '.join(tmp)
            options = list(options)
            options.sort()
            options = ' '.join(options)
        
            # deal with @ syntax need to move it after the decay specification
            if '@' in new_proc:
                baseproc, proc_nb = new_proc.split('@')
                try:
                    proc_nb = int(proc_nb)
                except ValueError:
                    raise MadSpinError('MadSpin didn\'t allow order restriction after the @ comment: \"%s\" not valid' % proc_nb)
                proc_nb = '@%i' % proc_nb 
            else:
                baseproc = new_proc
                proc_nb = ''      

            if msoptions and msoptions['global_order_coupling']:
                if '@' in proc_nb:
                    proc_nb += " %s" % msoptions['global_order_coupling']
                else:
                    proc_nb += " @0 %s" %  msoptions['global_order_coupling']                

            nb_comma = baseproc.count(',')
            if nb_comma == 0:
                commands.append("%s, %s %s %s" % (baseproc, decay_text, proc_nb, options))
            elif nb_comma == 1:
                before, after = baseproc.split(',')
                commands.append("%s, %s, (%s, %s) %s  %s" % (before, decay_text, after, decay_text, proc_nb, options))
            else:
                part = baseproc.split(',')
                if any('(' in p for p in part):
                    raise Exception('too much decay at MG level. this can not be done for the moment)')            
                else:
                    decay_part = []
                    for p in part[1:]:
                        decay_part.append("(%s, %s)" % (p, decay_text))
                    commands.append("%s, %s, %s %s %s" % (part[0], decay_text, ', '.join(decay_part), proc_nb, options))
        commands.append('') #to have a ; at the end of the command
        return ';'.join(commands)
        
    
    def get_branching_ratio(self):
        """compute the branching ratio of all the decaying particles"""
    
        # Compute the width branching ratio. Doing this at this point allows
        #to remove potential pointless decay in the diagram generation.
        resonances = decay_misc.get_all_resonances(self.banner, 
                         self.mgcmd, list(self.mscmd.list_branches.keys()))

        logger.debug('List of resonances:%s' % resonances)
        path_me = os.path.realpath(self.path_me) 
        width = width_estimate(resonances, path_me, self.banner, self.model,
                                self.pid2label)
        width.extract_br(self.list_branches, self.mgcmd)
        width.print_branching_fractions()
        #self.channel_br = width.get_BR_for_each_decay(self.decay_processes, 
        #                                    self.mgcmd._multiparticles)
        self.width_estimator = width
        self.banner.param_card = width.banner.param_card
        return width    


    @staticmethod
    def write_flavor_ms_inc(path, flavor_data):
        """Write flavor_ms.inc containing GET_FLAVOR_MS_* subroutines.

        flavor_data is a dict with keys among 'full', 'prod', 'decay', mapping
        to (nexternal, flavor_combo_list, pdg_to_group_pos) tuples, where
        flavor_combo_list is a list of PDG-code sequences (one per flavor_index)
        and pdg_to_group_pos maps PDG code -> position in its merged group.

        For each key, a Fortran subroutine is generated:
          - GET_FLAVOR_MS_FULL(IFLAV, FLAVOR_OUT)  for key 'full'
          - GET_FLAVOR_MS_PROD(IFLAV, FLAVOR_OUT)  for key 'prod'
          - GET_FLAVOR_MS(IFLAV, FLAVOR_OUT)        for key 'decay'
        When no merged particles exist the single entry is all ones (group pos 1).
        """
        name_map = {'full': 'GET_FLAVOR_MS_FULL',
                    'prod': 'GET_FLAVOR_MS_PROD',
                    'decay': 'GET_FLAVOR_MS'}
        lines = []
        for key, (nexternal, flavor_combos, pdg_to_group_pos) in flavor_data.items():
            sub_name = name_map[key]
            # If no flavor data (no merged particles), create a single all-ones entry
            if not flavor_combos:
                flavor_combos = [[1] * nexternal]
            nflavs = len(flavor_combos)
            lines.append('      SUBROUTINE %s(IFLAV, FLAVOR_OUT)' % sub_name)
            lines.append('C     Returns the flavor array for flavor index IFLAV')
            lines.append('C     Generated by MadSpin at output time')
            lines.append('      IMPLICIT NONE')
            lines.append('      INTEGER, PARAMETER :: NEXTERNAL_MS = %d' % nexternal)
            lines.append('      INTEGER, PARAMETER :: NFLAVS_MS = %d' % nflavs)
            lines.append('      INTEGER  I')
            lines.append('      INTEGER IFLAV')
            lines.append('      INTEGER FLAVOR_OUT(NEXTERNAL_MS)')
            lines.append('      INTEGER FLAVOR_DATA(NEXTERNAL_MS, NFLAVS_MS)')
            for i, flav in enumerate(flavor_combos):
                positions = [str(pdg_to_group_pos.get(abs(f), 1)) for f in flav]
                lines.append('      DATA (FLAVOR_DATA(I, %d), I=1,NEXTERNAL_MS) / %s /'
                             % (i+1, ', '.join(positions)))
            lines.append('      FLAVOR_OUT = FLAVOR_DATA(:, IFLAV)')
            lines.append('      RETURN')
            lines.append('      END')
            lines.append('')
        content = '\n'.join(lines)
        with open(pjoin(path, 'flavor_ms.inc'), 'w') as f:
            f.write(content)

    @staticmethod
    def get_flavor_data_from_me(matrix_element):
        """Extract flavor data from a HelasMatrixElement.

        Returns a tuple (nexternal, flavor_combos, pdg_to_group_pos, flavor_groups)
        where:
          - nexternal: number of external particles
          - flavor_combos: list of PDG-code tuples, one per flavor_index, written
            into the Fortran DATA statement for GET_FLAVOR_MS_FULL.
          - pdg_to_group_pos: dict mapping positive PDG code -> position within its
            merged-particle group (used to convert PDG codes to group positions).
          - flavor_groups: list of single-element lists; flavor_groups[i] contains
            the one PDG-code tuple for flavor_index i+1, enabling Python-side
            matching of a real event to its flavor_index.

        Each valid external flavor tuple is given its own flavor_index so that
        distinct decay-product combinations (e.g. W+ -> u d~ vs W+ -> c s~) are
        accessible as separate Fortran indices. This is what allows
        get_compatible_flavor_data to return multiple compatible entries (one per
        decay combination) for a given production-level event.
        """
        (nexternal, _) = matrix_element.get_nexternal_ninitial()
        model = matrix_element.get('processes')[0].get('model')
        pdg_to_group_pos = {}
        for members in model.get('merged_particles').values():
            for pos, pdg in enumerate(members, 1):
                pdg_to_group_pos[pdg] = pos
        # get_external_flavors returns one tuple per valid flavor combination.
        # Using individual tuples (rather than coupling-based groups) ensures
        # that different decay-product flavor combinations each get a distinct
        # Fortran flavor index, which is required for correct BR-weighted
        # maxweight computation across all compatible channels.
        all_flav_flat = matrix_element.get_external_flavors()
        # flavor_combos[i]: raw PDG tuple for Fortran flavor index i+1.
        # The Fortran writer applies pdg_to_group_pos at DATA-statement time.
        flavor_combos = [list(flv) for flv in all_flav_flat]
        # flavor_groups[i] is compared against the group-position tuple
        # produced by Event.get_flavor_index, so it must already be in that
        # space (1-based position within the merged group, 1 for unmerged
        # particles).  get_external_flavors returns raw PDGs, so convert.
        flavor_groups = [[[pdg_to_group_pos.get(abs(f), 1) for f in flv]]
                         for flv in all_flav_flat]
        return nexternal, flavor_combos, pdg_to_group_pos, flavor_groups

    @staticmethod
    def _strip_process_number(shell_string):
        """Remove the leading process-number prefix from a shell string."""
        if '_' in shell_string:
            prefix, suffix = shell_string.split('_', 1)
            if prefix.isdigit():
                return suffix
        return shell_string

    def _get_decay_flavor_entry(self, decay_process):
        """Return the decay-only flavor-data entry matching ``decay_process``."""
        shell_string = decay_process.shell_string()
        shell_string_pdg = decay_process.shell_string(pdg_order=True)
        stripped_shell = self._strip_process_number(shell_string)
        stripped_shell_pdg = self._strip_process_number(shell_string_pdg)

        for key, decay_info in self.all_decay.items():
            stripped_key = self._strip_process_number(key)
            stripped_tag = self._strip_process_number(decay_info.get('tag', ''))
            if (stripped_key == stripped_shell or stripped_key == stripped_shell_pdg or
                    stripped_tag == stripped_shell or stripped_tag == stripped_shell_pdg):
                return decay_info
        return None

    def build_full_flavor_data(self, production_tag, decay_process):
        """Build full-ME flavor data from production and decay flavor blocks.

        The full subprocess generated for a decay-chain process such as
        ``p p > W+ W-, W+ > j j, W- > j j`` is a *single* matrix element whose
        external legs still carry merged-particle IDs.  Relying on
        ``matrix_element.get_external_flavors()`` only returns the canonical
        flavor assignments kept by the grouped ME, which misses the cross
        product of all compatible decay-flavor combinations.  For WW -> 4j
        this collapses the expected 16 full entries down to 4.

        To recover the full list we combine:
          - the production flavor tuples already stored for ``production_tag``,
          - the decay-only flavor tuples of each decay chain stored in
            ``self.all_decay``.

        For each production tuple we replace every decaying production leg by
        the child flavor positions coming from the matching decay-only tuples,
        keeping the production leg order used by ``process.get_legs()``.  The
        resulting full tuples follow the external-leg order of
        ``process.get_legs_with_decays()``.

        Returns a tuple ``(nexternal, flavor_combos, pdg_to_group_pos,
        flavor_groups)`` in the same format as :meth:`get_flavor_data_from_me`.
        """
        prod_data = self.all_ME[production_tag].get('flavor_combos_prod')
        if prod_data is None:
            return None

        proc = decay_process
        prod_nexternal, prod_combos, pdg_to_group_pos = prod_data
        if not prod_combos:
            prod_combos = [[1] * prod_nexternal]

        decay_combo_blocks = []
        combined_pdg_to_group_pos = dict(pdg_to_group_pos)
        for dproc in proc.get('decay_chains'):
            decay_info = self._get_decay_flavor_entry(dproc)
            if decay_info is None:
                return None
            decay_nexternal, decay_combos, decay_pdg_to_group_pos = \
                decay_info['flavor_combos_decay']
            if not decay_combos:
                decay_combos = [[1] * decay_nexternal]
            decay_combo_blocks.append((dproc, decay_combos))
            combined_pdg_to_group_pos.update(decay_pdg_to_group_pos)

        if not decay_combo_blocks:
            flavor_combos = [list(flv) for flv in prod_combos]
            flavor_groups = [[list(flv)] for flv in flavor_combos]
            return (prod_nexternal, flavor_combos,
                    combined_pdg_to_group_pos, flavor_groups)

        full_combos = []
        for prod_combo in prod_combos:
            decay_choices = [combos for _, combos in decay_combo_blocks]
            for selected_decays in itertools.product(*decay_choices):
                decay_by_pid = collections.defaultdict(list)
                for (dproc, _), decay_combo in zip(decay_combo_blocks,
                                                  selected_decays):
                    decay_by_pid[dproc.get('legs')[0].get('id')].append(decay_combo)

                full_combo = []
                prod_index = 0
                for leg in proc.get('legs'):
                    if leg.get('state') and decay_by_pid[leg.get('id')]:
                        decay_combo = decay_by_pid[leg.get('id')].pop(0)
                        full_combo.extend(decay_combo[1:])
                    else:
                        full_combo.append(prod_combo[prod_index])
                    prod_index += 1
                full_combos.append(full_combo)

        nexternal = len(proc.get_legs_with_decays())
        flavor_groups = [[list(flv)] for flv in full_combos]
        return nexternal, full_combos, combined_pdg_to_group_pos, flavor_groups

    def get_full_flavor_index(self, production_tag, decay_me, event_map):
        """Determine the 1-based flavor_index_full for the full (production+decay) ME.

        The method matches the actual particle PDGs from the production event against
        the positions in ``decay_me['flavor_groups_full']`` that correspond to
        production particles (using the ``prod2full`` mapping pre-computed during
        Fortran output generation).

        For each production particle ``i`` (0-based):
          - ``prod2full[i] > 0``: the particle is external in the full ME at
            1-based position ``prod2full[i]``.  We retrieve its actual PID from
            the event via ``event_map[i]`` and compare (by absolute value) with
            the corresponding position in each flavor tuple.
          - ``prod2full[i] <= 0``: the particle decays; its leaf products are not
            compared here because they are specific particles (no merged group),
            so they are the same across all flavor tuples.

        Returns the 1-based index of the matching group, or 1 if no match is
        found (safe fallback for processes without merged particles or when
        ``flavor_groups_full`` or ``prod2full`` are not stored).
        """
        flavor_groups_full = decay_me.get('flavor_groups_full', [])
        if not flavor_groups_full:
            return 1

        prod2full = decay_me.get('prod2full', [])
        if not prod2full:
            return 1

        # Retrieve the PDG->group-position map stored alongside the full combos.
        # The flavor tuples store group positions (1-based within each merged
        # group, defaulting to 1 for unmerged particles like the gluon).  We
        # must therefore compare *group positions*, not raw PDG codes.
        flavor_combos_full = decay_me.get('flavor_combos_full')
        pdg_to_group_pos = flavor_combos_full[2] if flavor_combos_full else {}

        # Build a dict: 0-based full-ME position -> group position of event particle
        pos_to_gpos = {}
        for prod_pos, full_pos in enumerate(prod2full):
            if full_pos > 0:  # external in full ME (not a resonance / decaying particle)
                evt_pos = event_map.get(prod_pos, prod_pos)  # 0-based event position
                pid = self.curr_event.particle[evt_pos + 1]['pid']
                gpos = pdg_to_group_pos.get(abs(pid), 1)
                pos_to_gpos[full_pos - 1] = gpos  # convert to 0-based index

        if not pos_to_gpos:
            return 1

        for group_idx, group_tuples in enumerate(flavor_groups_full):
            for flav_tuple in group_tuples:
                if all(abs(flav_tuple[pos]) == gpos
                       for pos, gpos in pos_to_gpos.items()
                       if pos < len(flav_tuple)):
                    return group_idx + 1  # 1-based

        # No exact match – fall back to index 1
        return 1

    def get_compatible_flavor_indices(self, decay_me, event_map,
                                       production_tag=None):
        """Return 1-based flavor-group indices compatible with the current event.

        This is the pure *flavor-mapping* step: it checks which entries in
        ``decay_me['flavor_groups_full']`` match the production-particle PDGs
        seen in the current event.  No branching-ratio information is touched.

        A flavor group is *compatible* when every production-leg position
        (those entries in ``prod2full`` that are positive, i.e. that appear
        as external particles in the full ME) has an absolute PDG code equal
        to the corresponding particle in the event.

        Design note on full flavor files
        --------------------------------
        For a process such as ``p p > W+ W-, W+ > j j, W- > j j`` the full
        flavor file now contains the full production x decay cross product:
        4 production entries times 4 compatible decay combinations gives
        16 full entries.  For a fixed production event (for example u d~)
        this method therefore returns 4 compatible indices: one per allowed
        decay-product combination.

        Args:
            decay_me       : the decay channel dico (keys: 'flavor_groups_full',
                             'prod2full', ...).
            event_map      : mapping from 0-based production position to
                             0-based event particle index.
            production_tag : optional; used only as fallback when
                             ``flavor_groups_full`` is absent, forwarded to
                             ``get_full_flavor_index``.

        Returns:
            List of 1-based integer flavor-group indices that are compatible
            with the current event.  Never empty: falls back to [1] when no
            flavor-group data is available.
        """
        flavor_groups_full = decay_me.get('flavor_groups_full', [])
        if not flavor_groups_full:
            # No merged-particle flavor data – single group; use legacy helper
            flavor_index_full = self.get_full_flavor_index(
                production_tag, decay_me, event_map)
            return [flavor_index_full]

        prod2full = decay_me.get('prod2full', [])

        # Retrieve the PDG->group-position map.  The flavor tuples store group
        # positions (1-based within merged groups, 1 for unmerged particles such
        # as the gluon).  We must compare group positions, not raw PDG codes.
        flavor_combos_full = decay_me.get('flavor_combos_full')
        pdg_to_group_pos = flavor_combos_full[2] if flavor_combos_full else {}

        # Build mapping: 0-based full-ME position -> group position from event
        pos_to_gpos = {}
        if prod2full:
            for prod_pos, full_pos in enumerate(prod2full):
                if full_pos > 0:  # positive entry = external particle
                    evt_pos = event_map.get(prod_pos, prod_pos)
                    pid = self.curr_event.particle[evt_pos + 1]['pid']
                    gpos = pdg_to_group_pos.get(abs(pid), 1)
                    pos_to_gpos[full_pos - 1] = gpos  # 0-based

        # Find all groups whose production-position PDGs match the event
        compatible = []
        for group_idx, group_tuples in enumerate(flavor_groups_full):
            for flav_tuple in group_tuples:
                if (not pos_to_gpos or
                        all(abs(flav_tuple[pos]) == gpos
                            for pos, gpos in pos_to_gpos.items()
                            if pos < len(flav_tuple))):
                    compatible.append(group_idx + 1)  # 1-based
                    break  # one match per group is sufficient

        if not compatible:
            # No match – fall back to the legacy single best-match index
            flavor_index_full = self.get_full_flavor_index(
                production_tag, decay_me, event_map)
            return [flavor_index_full]

        return compatible

    def get_compatible_flavor_data(self, production_tag, decay_me, event_map):
        """Return (compatible_indices, rel_brs) for full-ME flavor groups
        compatible with the current event's production particles.

        This is a thin wrapper around :meth:`get_compatible_flavor_indices`
        that attaches the per-channel branching ratio.  The two concerns are
        kept separate so that the pure flavor-matching logic can be unit-tested
        independently.

        The BR factor is the already-computed value stored on the decay channel
        (``decay_me['br']``).  It is *not* normalised within the compatible set
        so that each maxweight entry can be correctly scaled.

        Returns:
            compatible_indices : list of 1-based group indices
            rel_brs            : list of BR factors, one per compatible group
        """
        decay_br = decay_me.get('br', 1.0)
        compatible = self.get_compatible_flavor_indices(
            decay_me, event_map, production_tag=production_tag)
        return compatible, [decay_br] * len(compatible)

    def choose_full_flavor_index(self, production_tag, decay, decay_me, event_map):
        """Choose a compatible full-event flavor index for this selected decay."""

        selected_compatible = self.get_compatible_flavor_indices(
            decay, event_map, production_tag=production_tag)

        if decay_me is decay:
            compatible = selected_compatible
        else:
            canonical_compatible = self.get_compatible_flavor_indices(
                decay_me, event_map, production_tag=production_tag)
            compatible = [idx for idx in selected_compatible
                          if idx in canonical_compatible]
            if not compatible:
                compatible = selected_compatible or canonical_compatible

        if compatible:
            return random.choice(compatible)

        return self.get_full_flavor_index(production_tag, decay_me, event_map)

    def nb_decaying_in_production(self):
        """The largest number of final-state particles of a production process
        that MadSpin decays (the decays of their decay products do not count).
        The production processes are in all_ME for madspin_v1 and in all_me
        (type 'production') for the onshell/density modes."""
        decay_ids = self.all_ME.decay_ids
        finals = [topo['base_order'][1] for topo in self.all_ME.values()]
        finals += [tag[1] for tag, info in getattr(self, 'all_me', {}).items()
                   if info.get('type') == 'production']
        return max([sum(abs(pid) in decay_ids for pid in final)
                    for final in finals] or [0])

    def use_global_flag(self, tree):
        """Compile ``tree`` with MS_GLOBAL_FLAG if the production has enough
        particles to decay for it to pay off (see MS_GLOBAL_FLAG_MIN_DECAYS)."""
        if self.nb_decaying_in_production() >= MS_GLOBAL_FLAG_MIN_DECAYS:
            set_global_flag(tree)

    def compile(self):
        logger.info('Compiling code')
        self.compile_fortran(self.path_me, mode="full_me")
        if not self.options["onlyhelicity"]:
            self.compile_fortran(self.path_me, mode="production_me")
            self.compile_fortran(self.path_me, mode="decay_me")

    def compile_fortran(self, path_me, mode='production_me'):
        """ Compile the fortran executables associated with the evaluation of the
                matrix elements (production process)
                Returns the path to the fortran executable
        """

        base_dir = pjoin(path_me, mode,"SubProcesses")
        list_prod=os.listdir(base_dir)
        logger.debug("""Finalizing %s's """% mode)

        # COMPILATION OF LIBRARY
        self.use_global_flag(pjoin(path_me, mode))
        misc.compile( cwd=pjoin(path_me, mode,"Source","DHELAS"), mode='fortran')
        file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'lha_read_ms.f')
        shutil.copyfile(file_madspin, pjoin(path_me, mode,"Source","MODEL","lha_read.f" ))
        if not self.options["use_old_dir"]: 
            misc.compile(arg=['clean'], cwd=pjoin(path_me, mode,"Source","MODEL"), mode='fortran')
        misc.compile( cwd=pjoin(path_me, mode,"Source","MODEL"), mode='fortran')     

        file=pjoin(path_me, 'param_card.dat')
        shutil.copyfile(file,pjoin(path_me,mode,"Cards","param_card.dat")) 

#       get all paths to matrix elements
        list_prod=[]
        # path_to_flavor_data maps me_path -> flavor_data dict for write_flavor_ms_inc
        path_to_flavor_data = {}
        if mode == 'full_me':
            for tag in self.all_ME:    
                prod_tag_data = self.all_ME[tag]
                for dico in prod_tag_data['decays']:
                    full_path=dico['path']
                    if full_path not in list_prod: list_prod.append(full_path)
                    # Build flavor_data for this full_me path
                    if full_path not in path_to_flavor_data:
                        full_fdata = dico.get('flavor_combos_full', None)
                        prod_fdata = prod_tag_data.get('flavor_combos_prod', None)
                        path_to_flavor_data[full_path] = {}
                        if full_fdata is not None:
                            path_to_flavor_data[full_path]['full'] = full_fdata
                        if prod_fdata is not None:
                            path_to_flavor_data[full_path]['prod'] = prod_fdata
        elif mode == 'production_me':
            for tag in self.all_ME:    
                prod_path=self.all_ME[tag]['path']
                if prod_path not in list_prod: list_prod.append(prod_path)
                if prod_path not in path_to_flavor_data:
                    prod_fdata = self.all_ME[tag].get('flavor_combos_prod', None)
                    path_to_flavor_data[prod_path] = {}
                    if prod_fdata is not None:
                        path_to_flavor_data[prod_path]['prod'] = prod_fdata
        elif mode == 'decay_me':
                for dir in os.listdir(base_dir):
                    if dir[0] == 'P':
                        dpath = pjoin(base_dir, dir)
                        list_prod.append(dpath)
                        # look up decay me flavor data by basename
                        dirname = os.path.basename(dpath)[1:]  # strip leading 'P'
                        decay_fdata = None
                        for key, dinfo in self.all_decay.items():
                            if os.path.basename(dinfo['path'])[1:] == dirname:
                                decay_fdata = dinfo.get('flavor_combos_decay', None)
                                break
                        path_to_flavor_data[dpath] = {}
                        if decay_fdata is not None:
                            path_to_flavor_data[dpath]['decay'] = decay_fdata

        for i,me_path in enumerate(list_prod):
#            if direc[0] == "P" and os.path.isdir(pjoin(base_dir, direc)):
#                new_path = pjoin(base_dir, direc)
                new_path = me_path

                if mode == 'full_me':
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'driver.f')
                    shutil.copyfile(file_madspin, pjoin(new_path,"driver.f")) 
                elif mode == 'production_me':
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'driver_prod.f')
                    shutil.copyfile(file_madspin, pjoin(new_path,"check_sa.f")) 
                else:
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'driver_decay.f')
                    shutil.copyfile(file_madspin, pjoin(new_path,"check_sa.f")) 

                # Generate flavor_ms.inc with GET_FLAVOR_MS_* subroutines
                flavor_data = path_to_flavor_data.get(new_path, {})
                self.write_flavor_ms_inc(new_path, flavor_data)
                     
                
                if mode=='full_me':
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'ranmar.f')
                    shutil.copyfile(file_madspin, pjoin(new_path,"ranmar.f"))
                    # driver.f's boost_to_frame/boost_to_frame_prod call
                    # impose_frame_rest, which is shared with the LO and NLO
                    # templates rather than inlined a third and fourth time.
                    # Only full_me builds driver.o, so only it needs the file.
                    file_madspin=pjoin(MG5DIR, 'Template', 'Common', 'Source',
                                       'impose_frame_rest.f')
                    shutil.copyfile(file_madspin,
                                    pjoin(new_path, "impose_frame_rest.f"))
                    file_madspin=pjoin(path_me, 'seeds.dat')  
                    files.ln(file_madspin, new_path)
                    file_madspin=pjoin(new_path, 'offset.dat')
                    open(file_madspin,'w').write('%i\n' % i)
                    
                    
                      
                    

                
                
                if mode == 'full_me':
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'makefile_full')
                elif mode == 'production_me':
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'makefile_prod')
                else:
                    file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'makefile_decay')
                    
                shutil.copyfile(file_madspin, pjoin(new_path,"makefile") )

                # files to produce the parameters:
                file_madspin=pjoin(MG5DIR, 'MadSpin', 'src', 'initialize.f')
                shutil.copyfile(file_madspin,pjoin(new_path,"initialize.f"))
                    
                shutil.copyfile(pjoin(path_me, mode,'Source','MODEL','input.inc'),
                                pjoin(new_path,'input.inc'))
                if not os.path.exists(pjoin(new_path,os.path.pardir, 'parameters.inc')):
                    if not self.options["use_old_dir"]:
                        misc.compile(arg=['clean'], cwd=new_path, mode='fortran')
                    misc.compile(arg=['init'],cwd=new_path,mode='fortran')
                    misc.call('./init', cwd=new_path)
                    shutil.copyfile(pjoin(new_path,'parameters.inc'), 
                               pjoin(new_path,os.path.pardir, 'parameters.inc'))
                if mode == 'production_me':
                    misc.compile(cwd=new_path, mode='fortran')
                else:
                    misc.compile(cwd=new_path, mode='fortran')
                    misc.compile(arg=['check'], cwd=new_path, mode='fortran')

                if __debug__:
                    if(os.path.getsize(pjoin(path_me, mode,'SubProcesses', 'parameters.inc'))<10):
                        print(pjoin(path_me, mode,'SubProcesses', 'parameters.inc'))
                        raise Exception("Parameters of the model were not written correctly ! %s " %\
                            os.path.getsize(pjoin(path_me, mode,'SubProcesses', 'parameters.inc')))


    def extract_resonances_mass_width(self, resonances):
        """ """

        label2width = {}
        label2mass = {}
        pid2width = {}
        #pid2mass = self.pid2mass
        need_param_card_modif = False
        
        # now extract the width of the resonances:
        for i,particle_label in enumerate(copy.copy(resonances)):
            try:
                try:
                    part=abs(self.pid2label[particle_label])
                except KeyError as error:
                    part=abs(self.pid2label[particle_label.lower()])
                    resonances[i] = particle_label.lower()
                #mass = self.banner.get('param_card','mass', abs(part))
                width = self.banner.get('param_card','decay', abs(part))
            except ValueError as error:
                continue
            else:
                if (width.value > 0.001):  
                    label2width[particle_label]=float(width.value)
                else: # the width is less than 1 MeV, need to use an effective width !!
                      # this is useful to handle cases like tau decays
                    label2width[particle_label]=0.001
                    need_param_card_modif = True
                    logger.warning('ATTENTION')
                    logger.warning('Found a very small width in the param_card for particle '\
                                   +str(particle_label))
                    logger.warning('Use instead an effective width of 1 MeV ' )
                #label2mass[particle_label]=float(mass.value)
                #pid2mass[part]=label2mass[particle_label]
                pid2width[abs(part)]=label2width[particle_label]
                if label2width[particle_label]==0.0:
                    need_param_card_modif = True
                    for param in self.model["parameters"][('external',)]:
                        if param.lhablock=="DECAY" and param.lhacode==[abs(part)]:
                            label2width[particle_label]=max(param.value,0.001)
                            pid2width[abs(part)]=label2width[particle_label]
                    logger.warning('ATTENTION')
                    logger.warning('Found a zero width in the param_card for particle '\
                                   +str(particle_label))
                    logger.warning('Use instead the default/effective value '\
                                   +str(label2width[particle_label]))
               
        # now we need to modify the values of the width
        # in param_card.dat, since this is where the input 
        # parameters will be read when evaluating matrix elements
        if need_param_card_modif:
            decay_misc.modify_param_card(pid2width, self.path_me)            
            
    def get_max_weight_from_event(self, decay_mapping):
        """ """

        decay_tools = decay_misc()
        
        # check all set of decay that need to be done:
        decay_set = set()
        for production in self.all_ME.values():
            decay_set.add(production['decaying'])

        numberev = self.options['Nevents_for_max_weight'] # number of events
        numberps = self.options['max_weight_ps_point'] # number of phase pace points per event
        
        logger.info('  ')
        logger.info('   Estimating the maximum weight    ')
        logger.info('   *****************************    ')
        logger.info('     Probing the first '+str(numberev)+' events')
        logger.info('     with '+str(numberps)+' phase space points')
        if len(decay_set) > 1: 
            logger.info('     For %s decaying particle type in the final states' % len(decay_set))
        logger.info('  ')

        
        probe_weight = []
       

        starttime = time.time()
        ev = -1
        nb_decay = dict( (key,0) for key in decay_set)
        probe_weight = dict( (key,[]) for key in decay_set)
        while ev+1 < len(decay_set) * numberev: 
            production_tag, event_map = self.load_event()
            if production_tag == 0 == event_map: #end of file
                logger.info('Not enough events for at least one production mode.')
                logger.info('This is ok as long as you don\'t reuse the max weight for other generations.')
                break
            
            #check if this event is useful or not
            decaying = self.all_ME[production_tag]['decaying']
            if nb_decay[decaying] >=  numberev:
                continue 
            ev += 1
            nb_decay[decaying] += 1 

#            mg5_me_prod, prod_values = self.evaluate_me_production(production_tag, event_map)   

   
            logger.debug('Event %s/%s: ' % (ev+1, len(decay_set)*numberev))
            if (len(decay_set)*numberev -(ev+2)) >0:
                self.mscmd.update_status((len(decay_set)*numberev -(ev+2),1,ev+1, 
                                          'MadSpin: Maximum weight'), 
                                         force=False, print_log=False)
            #logger.debug('Selected topology               : '+str(tag_topo))

            max_decay = {}
            mean_decay= {}
            std_decay = {}

            atleastonedecay=False
            for decay in self.all_ME[production_tag]['decays']:
                tag = decay['decay_tag']

                if decay_mapping and not tag in decay_mapping:
                    continue
                if not tag:
                    continue # No decay for this process
                atleastonedecay = True
                weight_dict = self.get_max_weight_from_fortran(
                    decay['path'], event_map, numberps, self.options['BW_cut'],
                    production_tag=production_tag, decay_me=decay)
                    #weight=mg5_me_full*BW_weight_prod*BW_weight_decay/mg5_me_prod
                if tag in max_decay:
                    for j, w in weight_dict.items():
                        if j in max_decay[tag]:
                            max_decay[tag][j] = max(max_decay[tag][j], w)
                        else:
                            max_decay[tag][j] = w
                else:
                    max_decay[tag] = dict(weight_dict)
                      
            if not atleastonedecay:
                # NO decay [one possibility is all decay are identical to their particle]
                logger.info('No independent decay for one type of final states -> skip those events for the maximum weight computation')
                nb_decay[decaying] = numberev
                ev += numberev -1
                continue
            probe_weight[decaying].append(max_decay)

            self.terminate_fortran_executables()
            self.calculator = {}
            self.calculator_nbcall = {}
            if ev % 5 == 0:
                running_time = misc.format_timer(time.time()-starttime)
                info_text = 'Event %s/%s : %s \n' % (ev + 1, len(decay_set)*numberev, running_time) 
                #for  index,tag_decay in enumerate(max_decay):
                #    info_text += '            decay_config %s [%s] : %s\n' % \
                #       (index+1, ','.join(tag_decay), probe_weight[decaying][nb_decay[decaying]-1][tag_decay])
                logger.info(info_text[:-1])
        
        
        
        # Computation of the maximum weight used in the unweighting procedure
        for decaying in probe_weight:
            if not probe_weight[decaying]:
                continue
            #me_linked = [me for me in self.all_ME.values() if me['decaying'] == decaying]
            for decay_tag in probe_weight[decaying][0].keys():
                # Collect all flavor indices observed across events
                all_flavor_j = set()
                for ev_data in probe_weight[decaying]:
                    if decay_tag in ev_data:
                        all_flavor_j.update(ev_data[decay_tag].keys())

                if not all_flavor_j:
                    logger.warning('no events for %s' % str(decay_tag))
                    continue

                # 3.x-style sharing: for a given decay channel, build one common
                # base maxweight from the per-event envelope across compatible
                # flavors, then reuse it across production modes.
                shared_weights = []
                for ev_data in probe_weight[decaying]:
                    try:
                        weights_by_flavor = ev_data[decay_tag]
                    except Exception:
                        continue
                    if not weights_by_flavor:
                        continue
                    w = max(weights_by_flavor.values())
                    if w > 0:
                        shared_weights.append(w)

                if not shared_weights:
                    logger.warning('no events for %s' % str(decay_tag))
                    continue

                shared_weights.sort(reverse=True)
                ave_weight, std_weight = decay_tools.get_mean_sd(shared_weights)
                base_max_weight = 1.05 * (ave_weight + self.options['nb_sigma'] * std_weight)
                for i in [20, 30, 40, 50]:
                    if len(shared_weights) < i:
                        break
                    ave_weight, std_weight = decay_tools.get_mean_sd(shared_weights[:i])
                    base_max_weight = max(base_max_weight,
                                          1.05 * (ave_weight + self.options['nb_sigma'] * std_weight))
                if shared_weights[0] > base_max_weight:
                    base_max_weight = 1.05 * shared_weights[0]

                for associated_decay, ratio in decay_mapping[decay_tag]:
                    max_weight = ratio * base_max_weight
                    if ratio != 1:
                        max_weight *= 1.1  # security
                    # Keep per-flavor lookup compatibility while sharing one
                    # common value across production/flavor configurations.
                    mw_per_flavor = dict((j, max_weight) for j in all_flavor_j)

                    br = 0
                    #assign the value to the associated decays
                    for k, m in self.all_ME.items():
                        for mi in m['decays']:
                            if mi['decay_tag'] == associated_decay:
                                mi['max_weight'] = max_weight
                                mi['max_weight_per_flavor'] = dict(mw_per_flavor)
                                br = mi['br']
                                nb_finals = len(mi['finals'])

                    if decay_tag == associated_decay:
                        logger.debug('Decay channel %s :Using maximum weight %s [%s] (BR: %s)' % \
                               (','.join(decay_tag), base_max_weight,
                                shared_weights[0] if shared_weights else 0, br/nb_finals))
                    else:
                        logger.debug('Decay channel %s :Using maximum weight %s (BR: %s)' % \
                                    (','.join(associated_decay), max_weight, br/nb_finals))

#        if __debug__: 
        # check that all decay have a max_weight and fix it if not the case.
        for prod in self.all_ME.values():
            for dec in prod['decays']:
                if dec['decay_tag'] and not 'max_weight' in dec:
                    dec['max_weight'] = 0. 

#                        assert 'max_weight' in dec and dec['max_weight'] ,\
#                                  'fail for %s (%s)' % (str(dec['decay_tag']), \
#                                                  os.path.basename(prod['path']))
        self.evtfile.seek(0)
        return

    def load_event(self):
        """Load the next event and ensure that the ME is define"""

        #decay_tools = decay_misc()
        if self.curr_event.get_next_event() == 'no_event':
            return 0, 0
        production_tag, order = self.curr_event.get_tag()
        P_order = self.all_ME[production_tag]['tag2order'][production_tag]

        event_map = {}
        evt_order = list(order[0])+list(order[1])
        for i, id in enumerate(P_order[0] + P_order[1]):
            in_event = [pos for pos, label in enumerate(evt_order) \
                               if label == id]
            if i < len(order[0]):
                in_event = [pos for pos in in_event if pos < len(order[0])]
            else:
                in_event = [pos for pos in in_event if pos >= len(order[0])]
                
            if len(in_event) == 1:
                in_event = in_event[0]
            else:
                config = random.randint(0, len(in_event)-1)
                in_event = in_event[config]            
            evt_order[in_event] = 0
            event_map[i] = in_event
        
        if __debug__ and len(order[0]) == 2:   
            assert event_map[0] in [0,1], 'wrong event mapping %s' % event_map
            assert event_map[1] in [0,1], 'wrong event mapping %s' % event_map
        assert production_tag in self.all_ME
        
        return production_tag, event_map
    
    def get_max_weight_from_fortran(self, path, event_map, nbpoints, BWcut,
                                    production_tag=None, decay_me=None):
        """Return per-flavor max weights as dict {flavor_index_full: maxweight}.

        Passes to Fortran (mode=1) the list of full-ME flavor groups that are
        compatible with the current production event together with their
        relative BRs.  Fortran computes:
            G = max_{j in compatible, PS points} M_full(j)*jac/M_prod / rel_br(j)
        and returns G.  Python then reconstructs per-flavor maxweights:
            maxweight_j = G * rel_br(j)
        ensuring maxweight_j >= max_PS[M_full(j)*jac/M_prod] for every j.
        """
        p, p_str = self.curr_event.give_momenta(event_map)
        if production_tag and decay_me:
            flavor_index_prod = self.curr_event.get_flavor_index(
                self.all_ME[production_tag].get('flavor_groups_prod', []), event_map)
            compatible_indices, rel_brs = self.get_compatible_flavor_data(
                production_tag, decay_me, event_map)
            # Use the first compatible index as the header field (Fortran ignores
            # it in mode=1 when it reads the explicit compatible-flavor list).
            flavor_index_full = compatible_indices[0]
        else:
            flavor_index_prod = 1
            flavor_index_full = 1
            compatible_indices = [1]
            rel_brs = [1.0]

        try:
            beampol = self.options.beampol_me()
        except KeyError:
            beampol = (1.0, 1.0)
        std_in = " %s  %s %s %s %s %s %s %s %s\n" % ("1", BWcut, self.Ecollider, nbpoints,
                                                 self.options['frame_id'],
                                                 beampol[0], beampol[1],
                                                 flavor_index_prod, flavor_index_full)
        std_in += p_str
        # Pass the number of compatible flavor groups and their (index, BR-factor) pairs.
        # Must not exceed MAX_COMPAT_FLAVS defined in driver.f.
        if len(compatible_indices) > MAX_COMPAT_FLAVS:
            logger.warning('Number of compatible flavor groups (%d) exceeds the '
                           'Fortran limit of %d; truncating.'
                           % (len(compatible_indices), MAX_COMPAT_FLAVS))
            compatible_indices = compatible_indices[:MAX_COMPAT_FLAVS]
            rel_brs = rel_brs[:MAX_COMPAT_FLAVS]
        std_in += "%d\n" % len(compatible_indices)
        for idx, br in zip(compatible_indices, rel_brs):
            std_in += "%d %.15e\n" % (idx, br)

        # G = max_{j,PS} M_full(j)*jac/M_prod / br_factor(j)
        G = self.loadfortran('maxweight', path, std_in)

        # Remap: per-flavor maxweight_j = G * br_factor(j)
        return {j: G * br for j, br in zip(compatible_indices, rel_brs)}
    
    nb_load = 0
    def loadfortran(self, mode, path, stdin_text, first=True):
        """ call the fortran executable """

        self.nb_load +=1
        tmpdir = ''
        if ('full',path) in self.calculator:
            external = self.calculator[('full',path)]
            self.calculator_nbcall[('full',path)] += 1
        else:
            logger.debug('we have %s calculator ready' % len(self.calculator))
            tmpdir = path

            executable_prod="./check"
            my_env = os.environ.copy()
            my_env["GFORTRAN_UNBUFFERED_ALL"] = "y"
            external = Popen(executable_prod, stdout=PIPE, stdin=PIPE, 
                                          stderr=STDOUT, cwd=tmpdir, env=my_env)
            self.calculator[('full',path,)] = external 
            self.calculator_nbcall[('full',path)] = 1 
            
        try:
            external.stdin.write(stdin_text.encode())
            external.stdin.flush()
        except IOError as error:
            if not first:
                raise
            #misc.sprint(error)
            try:
                external.stdin.close()
            except Exception as  error:
                misc.sprint(error, cond=self.nb_load<=250)
            try:
                external.stdout.close()
            except Exception as error:
                misc.sprint(error, cond=self.nb_load<=250)
            try:
                external.stderr.close()
            except Exception as error:
                misc.sprint(error, cond=self.nb_load<=250)
            try:
                external.terminate()
            except Exception as error:
                misc.sprint(error, cond=self.nb_load<=250)

            del self.calculator[('full',path,)]
            return self.loadfortran(mode, path, stdin_text, first=False)

        if mode == 'maxweight':
            maxweight=float(external.stdout.readline())
            output = maxweight
        elif mode == 'full_me':
            me_value=float(external.stdout.readline())
            output = me_value
        elif mode == 'unweighting':
            firstline=external.stdout.readline().split()
            try:
                nexternal=int(firstline[0])
                trials= int(firstline[1])
                BWvalue= float(firstline[2])
                weight= float(firstline[3])
                failed= float(firstline[4])
                use_mc_masses=int(firstline[5])
            except ValueError:
                logger.debug(firstline)
                return
            momenta=[external.stdout.readline() for i in range(nexternal)]
            lastline=external.stdout.readline().split()
            helicities=[lastline[i] for i in range(len(lastline))]
            output = trials, BWvalue, weight, momenta, failed, use_mc_masses, helicities

        if len(self.calculator) > self.options['max_running_process']:
            logger.debug('more than %s calculators. Perform cleaning' % self.options['max_running_process'])
            nb_calls = list(self.calculator_nbcall.values())
            nb_calls.sort()
            cut = max([nb_calls[len(nb_calls)//2], 0.001 * nb_calls[-1]])
            for key, external in list(self.calculator.items()):
                nb = self.calculator_nbcall[key]
                if nb < cut:
                    if key[0]=='full':
                        path=key[1]
                        # 9 fields to match driver.f's read(*,*) of
                        # mode, BWcut, Ecollider, temp, frame_id, beampol(1), beampol(2),
                        # flavor_index_prod, flavor_index_full.
                        # Sending fewer numbers leaves the Fortran process blocked
                        # in stdin read while Python blocks in stdout readline below,
                        # deadlocking any cleanup that fires (only triggered when
                        # len(self.calculator) > max_running_process, which happens
                        # on processes with many decay subprocess variants -- ttbar).
                        end_signal="5 0 0 0 0 0 0 0 0\n"  # before closing, write down the seed
                        external.stdin.write(end_signal.encode())
                        external.stdin.flush()
                        external.stdout.flush()
                        ranmar_state=external.stdout.readline().decode(errors='ignore')
                        ranmar_file=pjoin(path,'ranmar_state.dat')
                        ranmar=open(ranmar_file, 'w')
                        ranmar.write(ranmar_state)
                        ranmar.close()
                    external.stdin.close()
                    external.stdout.close()
                    external.terminate()
                    del self.calculator[key]
                    del self.calculator_nbcall[key]
                else:
                    self.calculator_nbcall[key] = self.calculator_nbcall[key] //10
                    
        return output
    
    def calculate_matrix_element(self, mode, production, stdin_text, flavor_index=1):
        """routine to return the matrix element

        Uses driver_decay.f (mode='decay') or driver_prod.f (mode='prod'), both
        of which take a single leading ``flavor_index`` line before the momenta.
        This is distinct from driver.f (the full-event ME, used via loadfortran)
        which takes two separate indices (flavor_index_prod, flavor_index_full).

        NOTE(flavor): the flavor_index parameter is left at its default value of
        1 for all callers in get_process_identical_ratio.  In that context the
        code computes ratios of equivalent decay channels using random phase-space
        points (no event PIDs available), so flavor_index=1 is a reasonable
        fallback for now.
        """

        if mode != "decay":
            raise Exception("This function is only secure in mode decay.")

        tmpdir = ''
        if (mode, production) in self.calculator:
            external = self.calculator[(mode, production)]
            self.calculator_nbcall[(mode, production)] += 1
        else:
            logger.debug('we have %s calculator ready' % len(self.calculator))
            if mode == 'prod':
                tmpdir = pjoin(self.path_me,'production_me', 'SubProcesses',
                           production)
            elif mode in ['full','decay']:
                tmpdir = pjoin(self.path_me,'%s_me' % mode, 'SubProcesses',
                           production)
            executable_prod="./check"
            my_env = os.environ.copy()
            my_env["GFORTRAN_UNBUFFERED_ALL"] = "y"
            external = Popen(executable_prod, stdout=PIPE, stdin=PIPE,
                                                      stderr=STDOUT, cwd=tmpdir,
                                                      env=my_env,
                                                      bufsize=0)
            assert (mode, production) not in self.calculator
            self.calculator[(mode, production)] = external 
            self.calculator_nbcall[(mode, production)] = 1       

        # prepend flavor_index before momenta for the decay driver
        full_stdin = '%s\n%s' % (flavor_index, stdin_text)
        external.stdin.write(full_stdin.encode())
        if mode == 'prod':
            info = int(external.stdout.readline().decode(errors='ignore'))
            nb_output = abs(info)+1
        else:
            info = 1
            nb_output = 1
        std = []
        for i in range(nb_output):
            external.stdout.flush()
            line = external.stdout.readline().decode(errors='ignore')
            std.append(line)
        prod_values = ' '.join(std)
        #prod_values = ' '.join([external.stdout.readline().decode(errors='ignore') for i in range(nb_output)])
        if info < 0:
            print('ZERO DETECTED')
            print(prod_values)
            print(stdin_text)
            os.system('lsof -p %s' % external.pid)
            return ' '.join(prod_values.split()[-1*(nb_output-1):])
        if len(self.calculator) > self.options['max_running_process']:
            logger.debug('more than 100 calculator. Perform cleaning')
            nb_calls = list(self.calculator_nbcall.values())
            nb_calls.sort()
            cut = max([nb_calls[len(nb_calls)//2], 0.001 * nb_calls[-1]])
            for key, external in list(self.calculator.items()):
                nb = self.calculator_nbcall[key]
                if nb < cut:
                    external.stdin.close()
                    external.stdout.close()
                    external.terminate()
                    del self.calculator[key]
                    del self.calculator_nbcall[key]
                else:
                    self.calculator_nbcall[key] = self.calculator_nbcall[key] //10
        if mode == 'prod':
            return prod_values
        else:
            return float(prod_values)
              
    def generate_configs_file(self,nfinal,decay, path):
        """ write the file configs_decay.inc
            also record the itree information in a python variable, 
            this will be needed to write down the event
            
            decay_struct['mg_tree'] = [(d1,d2, mother), (d1,d2,mother), ...]
                with - BACKWARD ORDER, 
                     - me indices
        """
   
        decay_struct=decay['decay_struct'] 
        me_index=2 # should match the particle index in the full matrix element 
        count_res=0 # count number of resonances
        iforest=[] 
        pmasswidth=[]
        
#              data (map_external2res(i), i=1,4)/1,2,-2,-4/
 
        decay['prod2full']=[1,2]
        map_external='      data (map_external2res(i), i=1,%s)/1,2,' %(nfinal+2)    
        for part in range(3,nfinal+3):
            if part in decay_struct:  # particle in the prod. event to be decayed
                #print part
                decay_struct[part]['mg_tree']=[]

                nb_res=len(list(decay_struct[part]["tree"].keys()))
                for res in range(-1,-nb_res-1,-1):
                    label=abs(decay_struct[part]["tree"][res]['label'])
                    mass=self.pid2massvar[label]
                    width=self.pid2widthvar[label] 
                    me_res=-nb_res-res-count_res-1
                    indexd1=decay_struct[part]["tree"][res]["d1"]["index"]
                    if indexd1>0:
                        me_index+=1
                        me_d1=me_index
                    else: 
                        # need to label resonances backward
                        me_d1 = -nb_res-indexd1-count_res-1
                    indexd2=decay_struct[part]["tree"][res]["d2"]["index"]
                    if indexd2>0:
                        me_index+=1
                        me_d2=me_index
                    else: 
                        # need to label resonances backward
                        me_d2 = -nb_res-indexd2-count_res-1
                    iforest.append("      DATA (IDECAY(I, %s ),I=1,2)/  %s ,  %s / \n" % (me_res, me_d1, me_d2))
                    decay_struct[part]['mg_tree'].append((me_res,me_d1,me_d2))
                    pmasswidth.append("      PRMASS(%s)=%s \n" %(me_res,mass) )
                    pmasswidth.append("      PRWIDTH(%s)=%s \n" %(me_res,width) )

                count_res=count_res+nb_res
                map_external+='%s ,' % (-count_res)
                decay['prod2full'].append(-count_res)
            else:
                me_index+=1
                map_external+='%s ,' % me_index
                decay['prod2full'].append(me_index)
   
        map_external=map_external[:-1]+'/ \n'
        
        trappe=open(pjoin(path,'configs_decay.inc'),'w')
        trappe.write(map_external)
        for item in iforest:
            trappe.write(item)
        trappe.write('      ns_channel_decay= %s \n' % count_res)
        for item in pmasswidth:
            trappe.write(item)
        trappe.close()

    def get_montecarlo_masses_from_event(self,decay_struct, event_map, map_prod2full):
        """
            from the production event curr_event and from the decay channel 'decay_struct'
            (which has just been selected randomly), get the MonteCarlo masses
        """
        
        # in order to preserve the natural order in lhe file,
        # we need the inverse of the dico event_map
        inv_event_map={}
        for i in event_map.keys():
            inv_event_map[event_map[i]]=i
        
        indices_for_mc_masses=[]
        values_for_mc_masses=[]
        
        for index in self.curr_event.event2mg.keys():
            if self.curr_event.event2mg[index]>0: # no need to consider resonances in the production event file
                part=inv_event_map[self.curr_event.event2mg[index]-1]+1 # index for prod. matrix element
                part_for_curr_evt=self.curr_event.event2mg[index]       # index for event file
                
                if part not in decay_struct:
                    # get the pid
                    curr_pid=abs(self.curr_event.particle[part_for_curr_evt]['pid'])
                    if curr_pid in self.MC_masses:
                        #print part
                        #print map_prod2full
                        indices_for_mc_masses.append(map_prod2full[part-1])
                        values_for_mc_masses.append(self.MC_masses[curr_pid])
                    
                else:
                    # now we need to write the decay products in the event
                    # follow the decay chain order, so that we can easily keep track of the mother index                                           
                    for res in range(-1,-len(list(decay_struct[part]["tree"].keys()))-1,-1):
                        index_d1=decay_struct[part]['mg_tree'][-res-1][1]
                        index_d2=decay_struct[part]['mg_tree'][-res-1][2]
                        
                        pid_d1=abs(decay_struct[part]\
                                    ["tree"][res]["d1"]["label"])
                        pid_d2=abs(decay_struct[part]\
                                    ["tree"][res]["d2"]["label"])
                        if index_d1 >0 and pid_d1 in self.MC_masses:
                            indices_for_mc_masses.append(index_d1)
                            values_for_mc_masses.append(self.MC_masses[pid_d1])

                        if index_d2 >0 and pid_d2 in self.MC_masses:
                            indices_for_mc_masses.append(index_d2)
                            values_for_mc_masses.append(self.MC_masses[pid_d2])

        return indices_for_mc_masses,values_for_mc_masses

    def decay_one_event_new(self,curr_event,decay_struct, event_map, momenta_in_decay,
                            use_mc_masses, helicities, full_flavor_tuple=None):
        """Write down the event 
           momenta is the list of momenta ordered according to the productin ME
        """

        pid2color = self.pid2color
        decayed_event=Event()
        decayed_event.event2mg={}

        decayed_event.ievent=curr_event.ievent
        decayed_event.wgt=curr_event.wgt
        decayed_event.scale=curr_event.scale
        decayed_event.aqed=curr_event.aqed
        decayed_event.aqcd=curr_event.aqcd
        decayed_event.diese=curr_event.diese
        decayed_event.rwgt=curr_event.rwgt
        decayed_event.event_init_line=curr_event.event_init_line

        part_number=0
        external=0
        maxcol=curr_event.max_col

        # in order to preserve the natural order in lhe file,
        # we need the inverse of the dico event_map
        inv_event_map={}
        for i in event_map.keys():
            inv_event_map[event_map[i]]=i
        sol_nb = None
        
        for index in curr_event.event2mg.keys():
            if curr_event.event2mg[index]>0:
                part=inv_event_map[curr_event.event2mg[index]-1]+1 # index for prod. matrix element
                part_for_curr_evt=curr_event.event2mg[index]       # index for event file
                
                if part not in decay_struct:
                    external+=1 
                    part_number+=1
                    decayed_event.particle[part_number]=curr_event.particle[part_for_curr_evt]
                    decayed_event.event2mg[part_number]=part_number
                
                else:
                    # now we need to write the decay products in the event
                    # follow the decay chain order, so that we can easily keep track of the mother index
                    map_to_part_number={}
                    for res in range(-1,-len(list(decay_struct[part]["tree"].keys()))-1,-1):
                        index_res_for_mom=decay_struct[part]['mg_tree'][-res-1][0]
                        if (res==-1):
                            part_number+=1
                            mom=momenta_in_decay[index_res_for_mom].copy()
                            pid=decay_struct[part]["tree"][res]['label'] 
                            istup=2
                            mothup1=curr_event.particle[part_for_curr_evt]["mothup1"]
                            mothup2=curr_event.particle[part_for_curr_evt]["mothup2"]
                            colup1=curr_event.particle[part_for_curr_evt]["colup1"]
                            colup2=curr_event.particle[part_for_curr_evt]["colup2"]
                            decay_struct[part]["tree"][res]["colup1"]=colup1
                            decay_struct[part]["tree"][res]["colup2"]=colup2
                            mass=mom.m
                            helicity=9.
                            decayed_event.particle[part_number]={"pid":pid,\
                                "istup":istup,"mothup1":mothup1,"mothup2":mothup2,\
                                "colup1":colup1,"colup2":colup2,"momentum":mom,\
                                "mass":mass,"helicity":helicity}
                            decayed_event.event2mg[part_number]=part_number

                            map_to_part_number[res]=part_number
   
#
#             Extract color information so that we can write the color flow
#
                        colormother=pid2color[decay_struct[part]["tree"][res]["label"]]
                        colord1=pid2color[decay_struct[part]\
                                            ["tree"][res]["d1"]["label"]]
                        colord2=pid2color[decay_struct[part]\
                                            ["tree"][res]["d2"]["label"]]
                
                        colup1=decay_struct[part]["tree"][res]["colup1"]
                        colup2=decay_struct[part]["tree"][res]["colup2"]

#            now figure out what is the correct color flow information
#            Only consider 1,3, 3-bar and 8 color rep.
#            Normally, the color flow needs to be determined only
#            during the reshuffling phase, but it is currently assigned
#            for each "trial event"
                        if abs(colord1)==1:
                            d2colup1=colup1
                            d2colup2=colup2
                            d1colup1=0
                            d1colup2=0
                        elif abs(colord2)==1:
                            d1colup1=colup1
                            d1colup2=colup2
                            d2colup1=0
                            d2colup2=0
                        elif colord1==3 and colord2==-3 and colormother ==1:
                            maxcol+=1
                            d1colup1=maxcol
                            d1colup2=0
                            d2colup1=0
                            d2colup2=maxcol
                     
                        elif colord1==3 and colord2==-3 and colormother ==8:
                            d1colup1=colup1
                            d1colup2=0
                            d2colup1=0
                            d2colup2=colup2
                        elif colord1==-3 and colord2==3 and colormother ==8:
                            d1colup1=0
                            d1colup2=colup2
                            d2colup1=colup1
                            d2colup2=0
                        elif colord1==-3 and colord2==3 and colormother ==1:
                            maxcol+=1
                            d1colup1=0
                            d1colup2=maxcol
                            d2colup1=maxcol
                            d2colup2=0
                        elif colord1==3 and colord2==8 and colormother ==3:
                            maxcol+=1
                            d2colup1=colup1
                            d2colup2=maxcol
                            d1colup1=maxcol
                            d1colup2=0

                        elif colord2==3 and colord1==8 and colormother ==3:
                            maxcol+=1
                            d1colup1=colup1
                            d1colup2=maxcol
                            d2colup1=maxcol
                            d2colup2=0

                        elif colord1==-3 and colord2==8 and colormother ==-3:
                            maxcol+=1
                            d2colup2=colup2
                            d2colup1=maxcol
                            d1colup2=maxcol
                            d1colup1=0

                        elif colord2==-3 and colord1==8 and colormother ==-3:
                            maxcol+=1
                            d1colup2=colup2
                            d1colup1=maxcol
                            d2colup2=maxcol
                            d2colup1=0
                        elif colord1==-3 and colord2==-3 and colormother == 3:
                            maxcol+=2
                            d1colup1=0
                            d1colup2=maxcol
                            d2colup1=0
                            d2colup2=maxcol-1
                        elif (colord1==-3 and colord2==3 and colormother == 3) or\
                             (colord1==-3 and colord2==3 and colormother == -3):
                            maxcol+=2
                            d1colup1 = 0
                            d1colup2 = maxcol
                            d2colup1 = maxcol-1
                            d2colup2 = 0
                        elif (colord1==3 and colord2==-3 and colormother == 3) or\
                            (colord1==3 and colord2==-3 and colormother == -3):
                            maxcol+=2
                            d1colup1=maxcol
                            d1colup2=0
                            d2colup1=0
                            d2colup2=maxcol-1
                        elif colord1==3 and colord2==3 and colormother == -3:
                            maxcol+=2
                            d1colup1=maxcol
                            d1colup2=0
                            d2colup1=maxcol-1
                            d2colup2=0    
                        elif colord2==8 and colord1==8 and colormother ==8:
                            maxcol+=1
                            ran = random.random()
                            if ran> 0.5:
                                d1colup2=colup2
                                d1colup1=maxcol
                                d2colup2=maxcol
                                d2colup1=colup1
                            else:                            
                                d1colup2=maxcol
                                d1colup1=colup1
                                d2colup2=colup2
                                d2colup1=maxcol                        
                        else:
                            raise Exception('color combination not treated by MadSpin (yet). (%s,%s,%s)' \
                                % (colord1,colord2,colormother))
                        part_number+=1
                        index_d1_for_mom=decay_struct[part]['mg_tree'][-res-1][1]
                        mom=momenta_in_decay[index_d1_for_mom].copy()
                        #mom=decay_products[decay_struct[part]\
                        #            ["tree"][res]["d1"]["index"]]["momentum"]
                        pid=decay_struct[part]\
                                    ["tree"][res]["d1"]["label"]
                        pid=self.resolve_merged_pid_with_flavor(
                            pid, full_flavor_tuple, index_d1_for_mom)


                        indexd1=decay_struct[part]["tree"][res]["d1"]["index"]
                        if ( indexd1>0):
                            hel=helicities[index_d1_for_mom-1]
                            istup=1
                            external+=1
                            if not use_mc_masses or abs(pid) not in self.MC_masses:
                                mass = self.pid2mass(abs(pid))
                                #mass=self.banner.get('param_card','mass', abs(pid)).value
                            else:
                                mass=self.MC_masses[abs(pid)]
                        else:
                            hel=0.
                            decay_struct[part]["tree"][indexd1]["colup1"]=d1colup1
                            decay_struct[part]["tree"][indexd1]["colup2"]=d1colup2
                            istup=2                    
                            mass=mom.m
                            map_to_part_number[indexd1]=part_number 
 
                        mothup1=map_to_part_number[res]
                        mothup2=map_to_part_number[res]
                        decayed_event.particle[part_number]={"pid":pid,\
                                "istup":istup,"mothup1":mothup1,"mothup2":mothup2,\
                                "colup1":d1colup1,"colup2":d1colup2,"momentum":mom,\
                                "mass":mass,"helicity":hel}
                        decayed_event.event2mg[part_number]=part_number

                        part_number+=1
                        index_d2_for_mom=decay_struct[part]['mg_tree'][-res-1][2]
                        mom=momenta_in_decay[index_d2_for_mom].copy()

                        #mom=decay_products[decay_struct[part]["tree"][res]["d2"]\
                        #                   ["index"]]["momentum"]
                        pid=decay_struct[part]["tree"][res]["d2"]\
                                           ["label"]
                        pid=self.resolve_merged_pid_with_flavor(
                            pid, full_flavor_tuple, index_d2_for_mom)

                        indexd2=decay_struct[part]["tree"][res]["d2"]["index"]
                        if ( indexd2>0):
                            hel=helicities[index_d2_for_mom-1]
                            istup=1
                            external+=1
                            if not use_mc_masses or abs(pid) not in self.MC_masses:
                                mass = self.pid2mass(abs(pid))
                            else:
                                mass=self.MC_masses[abs(pid)]
                        else:
                            hel=0.
                            istup=2
                            decay_struct[part]["tree"][indexd2]["colup1"]=d2colup1
                            decay_struct[part]["tree"][indexd2]["colup2"]=d2colup2
                            mass=mom.m
                            map_to_part_number[indexd2]=part_number

                        mothup1=map_to_part_number[res]
                        mothup2=map_to_part_number[res]
                        decayed_event.particle[part_number]={"pid":pid,"istup":istup,\
                           "mothup1":mothup1,"mothup2":mothup2,"colup1":d2colup1,\
                           "colup2":d2colup2,\
                           "momentum":mom,"mass":mass,"helicity":hel}

                        decayed_event.event2mg[part_number]=part_number

                
            
            else: # resonance in the production event
                part=curr_event.event2mg[index]
                part_number+=1
                decayed_event.particle[part_number]=curr_event.resonance[part]
                decayed_event.event2mg[part_number]=part_number
#        Here I need to check that the daughters still have the correct mothup1 and mothup2
                for part in curr_event.resonance.keys():
                    mothup1=curr_event.resonance[part]["mothup1"]         
                    mothup2=curr_event.resonance[part]["mothup2"] 
                    if mothup1==index:
                        if mothup2!=index: print("Warning: mothup1!=mothup2")
                        curr_event.resonance[part]["mothup1"]=part_number
                        curr_event.resonance[part]["mothup2"]=part_number
                for part in curr_event.particle.keys():
                    mothup1=curr_event.particle[part]["mothup1"]         
                    mothup2=curr_event.particle[part]["mothup2"] 
                    if mothup1==index:
                        if mothup2!=index: print("Warning: mothup1!=mothup2")
                        curr_event.particle[part]["mothup1"]=part_number
                        curr_event.particle[part]["mothup2"]=part_number

        decayed_event.nexternal=part_number        
        return decayed_event       


    def add_loose_decay(self):
        """ in presence of multiprocess with multiple decay options all the 
        BR might not be identical. In such case, the total number of events should
        drop such that the events file is still a unweighted physical events sample.
        This routines add null decay (=> not written events) if appropriate."""
        
        first = True
        max_br = max([m['total_br'] for m in self.all_ME.values()])
        if max_br >= 1:
            if max_br > 1.0001:
                raise MadSpinError('BR is larger than one.')
            max_br = 1
        for production in self.all_ME.values():
            if production['total_br'] < max_br:
                if production['total_br'] > 0.9999:
                    continue
                if first:
                    first = False
                    min_br = min([m['total_br'] for m in self.all_ME.values()])
                    logger.info('''All production process does not have the same total Branching Ratio.
                    Therefore the total number of events after decay will be lower than the original file.
                    [max_br = %s, min_br = %s]''' % (max_br, min_br),'$MG:BOLD')
                fake_decay = {'br': max_br - production['total_br'], 
                              'path': None, 'matrix_element': None, 
                              'finals': None, 'base_order': None,
                              'decay_struct':None, 'decay_tag': None}
                production['decays'].append(fake_decay)
                production['total_br'] = max_br




    def bw_truncation_factor(self, decay):
        """The Breit-Wigner truncation of one decay channel of the v1 path.

        Unlike the density path, the v1 driver regenerates the *whole* decay
        chain's phase space: ``merge_itree`` marks every decay-side s-channel
        invariant free (``keep_inv(i) = .FALSE.``, only the production ones are
        frozen) and ``generate_inv_mass_sch`` then draws each of them inside
        ``+- BW_cut`` widths. So the product runs over every resonance of the
        chain -- the decaying particle itself *and* every nested one, the W of
        ``t > w+ b, w+ > l+ vl`` included.

        Correcting all of them is right here and would be double-counting on the
        density side, because the two paths normalise differently: v1 uses the
        param-card branching ratio of the full chain (``AllMatrixElement.get_br``,
        recursive, untruncated), while the density path divides MG5-measured
        partial widths that already carry the nested resonance's truncation.
        """
        bw_cut = self.options['BW_cut']
        if bw_cut is None or bw_cut < 0:
            bw_cut = 15
        factor = 1.0
        for branch in (decay.get('decay_struct') or {}).values():
            for res in branch['tree'].values():
                pdg = abs(res['label'])
                factor *= bw_retained_fraction(self.pid2mass(pdg),
                                               self.pid2width(pdg), bw_cut)
        return factor

    def write_banner_information(self, eff=1):

        ms_banner = ""
        cross_section = True # tell if possible to write the cross-section in advance
        total_br = []
        self.br_per_id = {}
        # Breit-Wigner truncation, averaged over the decay channels weighted by
        # their own branching ratio -- exact whenever the channels share a
        # resonance content (they normally do: only the final states differ).
        # The "loose" channels of add_loose_decay are not in the average: they
        # stand for an event that is dropped, and the drop is already in ``eff``.
        bw_trunc_num, bw_trunc_den = 0.0, 0.0
        for production in self.all_ME.values():
            one_br = 0
            partial_br = 0
            for decay in production['decays']:
                if not decay['decay_tag']:
                    cross_section = False
                    one_br += decay['br']
                    continue
                partial_br += decay['br']
                bw_trunc_num += decay['br'] * self.bw_truncation_factor(decay)
                bw_trunc_den += decay['br']
                ms_banner += "# %s\n" % ','.join(decay['decay_tag']).replace('\n',' ')
                ms_banner += "# BR: %s\n# max_weight: %s\n" % (decay['br'], decay['max_weight'])
                one_br += decay['br']

            if production['Pid'] not in self.br_per_id:
                self.br_per_id[production['Pid']] = partial_br
            elif self.br_per_id[production['Pid']] != partial_br:
                self.br_per_id[production['Pid']] = -1
            total_br.append(one_br)

        if __debug__:
            for production in self.all_ME.values():
                assert production['total_br'] - min(total_br) < 1e-4

        # MadSpin samples each virtuality only inside the BW_cut window but
        # normalises with the full width, so without this the reported cross
        # section is the same number whatever BW_cut is. Applied to
        # ``branching_ratio`` and to ``br_per_id``, i.e. to both users of the
        # rate: the per-subprocess <init> rows below and every event weight
        # (``change_wgt(factor=self.branching_ratio ...)``), which is what keeps
        # sigma = mean(w) true under IDWTUP = -4.
        #
        # 'onlyhelicity' writes the production events back undecayed -- nothing
        # is sampled from a truncated window, so nothing is corrected.
        bw_trunc = 1.0
        if bw_trunc_den and not self.options['onlyhelicity']:
            bw_trunc = bw_trunc_num / bw_trunc_den
        if bw_trunc != 1.0:
            logger.info(
                "Breit-Wigner truncation at BW_cut = %g keeps %.5g of the "
                "cross-section; the reported sigma is scaled by it.",
                self.options['BW_cut'], bw_trunc)
            for pid in self.br_per_id:
                if self.br_per_id[pid] != -1:
                    self.br_per_id[pid] *= bw_trunc
            total_br = [br * bw_trunc for br in total_br]

        self.branching_ratio = max(total_br) * eff
        #self.banner['madspin'] += ms_banner
        # Update cross-section in the banner
        if 'mggenerationinfo' in self.banner:
            mg_info = self.banner['mggenerationinfo'].split('\n')
            for i,line in enumerate(mg_info):
                if 'Events' in line:
                    if eff == 1:
                        self.err_branching_ratio = 0
                        continue
                    initial_event = int(mg_info[i].split()[-1])
                    nb_event =  int(initial_event * eff) 
                    mg_info[i] = '#  Number of Events        :       %i' % nb_event
                    if eff >0.5:
                        self.err_branching_ratio = max(total_br) * math.sqrt(initial_event - eff * initial_event)/initial_event
                    else:
                        self.err_branching_ratio = max(total_br) * math.sqrt(eff * initial_event)/initial_event
                    continue
                if ':' not in line:
                    continue
                info, value = line.rsplit(':',1)
                try:
                    value = float(value)
                except:
                    continue
                if cross_section:
                    mg_info[i] = '%s : %s' % (info, value * self.branching_ratio)            
                else:
                    mg_info[i] = '%s : %s' % (info, value * self.branching_ratio)
                self.banner['mggenerationinfo'] = '\n'.join(mg_info)
                
        self.cross = 0
        self.error = 0
        if 'init' in self.banner and (eff!=1 or not any(v==-1 for v in self.br_per_id.values())) \
                                 and not self.options['onlyhelicity']:
            new_init =''
            curr_proc = 0
            has_missing=False
            for line in self.banner['init'].split('\n'):
                if len(line.split()) != 4:
                    new_init += '%s\n' % line
                else:
                    curr_proc += 1 
                    data = [float(nb) for nb in line.split()]
                    id = int(data[-1])
                    if id in self.br_per_id and not any(v==-1 for v in self.br_per_id.values()):
                        data[:3] = [data[i] * self.br_per_id[id] for i  in range(3)]
                    else:
                        data[:3] = [ data[i] * self.branching_ratio for i  in range(3)]
                        has_missing=True
                    new_init += ' %.12E %.12E %.12E %i\n' % tuple(data)
                    cross, error = [float(d) for d in data[:2]]
                    self.cross += cross
                    self.error += error**2
                    
                    
            self.banner['init'] = new_init
            self.error = math.sqrt(self.error)
            if has_missing and curr_proc not in [0,1]:
                logger.warning('''The partial cross section for each subprocess can not be determine. due
    Reason: multiple final state in the same subprocess (and the presence of multiple BR)
    Consequence: the <init> information of the lhe will therefore be incorrect. Please correct it if needed.''')
        self.banner.write(self.outputfile, close_tag=False)        
        
    def terminate_fortran_executables(self, path_to_decay=0 ):
        """routine to terminate all fortran executables"""

        if not path_to_decay:
            for (mode, path) in self.calculator:
                if mode=='decay':
                    external = self.calculator[(mode, path)]
                    try:
                        external.stdin.close()
                    except Exception as  error:
                        misc.sprint(error)
                        continue
                    try:
                        external.stdout.close()
                    except Exception as error:
                        misc.sprint(error)
                        continue
                    external.terminate()
                    del external
                elif mode=='full':
                    stdin_text="5 0 0 0 0 0 0 0 0\n".encode()  # before closing, write down the seed
                    external = self.calculator[('full',path)]
                    try:
                        external.stdin.write(stdin_text)
                        external.stdin.flush() 
                    except Exception as error:
                        misc.sprint(error)
                        raise
                        continue
                    ranmar_state=external.stdout.readline().decode(errors='ignore')
                    ranmar_file=pjoin(path,'ranmar_state.dat')
                    ranmar=open(ranmar_file, 'w')
                    ranmar.write(ranmar_state)
                    ranmar.close()
                    try:
                        external.stdin.close()
                    except Exception as  error:
                        misc.sprint(error)
                    try:
                        external.stdout.close()
                    except Exception as error:
                        misc.sprint(error)
                    external.terminate()
                    del external
                else:
                    misc.sprint('not closed', mode, type(mode))
        else:
            try:
                external = self.calculator[('full', path_to_decay)]
            except Exception:
                pass
            else:
                # 9 fields to match driver.f's read(*,*) protocol
                # (see comment on the analogous end_signal in loadfortran).
                stdin_text="5 0 0 0 0 0 0 0 0\n"
                try:
                    external.stdin.write(stdin_text)
                except Exception:
                    pass
                try:
                    external.stdin.close()
                except Exception:
                    pass
                try:
                    external.stdout.close()
                except Exception:
                    pass
                external.terminate()       
                del external
            
        self.calculator = {}




class decay_all_events_onshell(decay_all_events):
    """special mode for onshell production"""

    mode = "onshell"
    # density/onshell evaluate MEs in-process via f2py, not through the Fortran
    # stdin/stdout pipe, so they must NOT force unbuffered Fortran I/O (which
    # would flush every event write and storm the filesystem during the
    # many-core decay-event generation/refill). Inherited by decay_all_events_density.
    _need_unbuffered_fortran_io = False
 
    
    @misc.mute_logger()
    @misc.set_global()
    
    def generate_all_matrix_element(self):
        """generate the full series of matrix element needed by Madspin.
        i.e. the undecayed and the decay one. And associate those to the 
        madspin production_topo object"""

        # 1. compute the partial width        
        # 2. compute the production matrix element
        # 3. create the all_topology object 
        # 4. compute the full matrix element (use the partial to throw away 
        #     pointless decay.
        # 5. add the decay information to the all_topology object (with branching
        #     ratio)  
        
        
        # 0. clean previous run ------------------------------------------------
        path_me = self.path_me
        # Each MadSpinInterface instance owns its own ME output subdirectory
        # (so dlopen cannot return a cached library handle across runs in
        # the same process — see MadSpinInterface._ms_run_counter).
        ms_me_subdir = getattr(self.mscmd, 'ms_me_subdir', 'madspin_me')
        ms_me_decay_subdir = getattr(self.mscmd, 'ms_me_decay_subdir', 'madspin_decay')
        try:
            shutil.rmtree(pjoin(path_me, ms_me_subdir))
        except Exception:
            pass
        try:
            shutil.rmtree(pjoin(path_me, ms_me_decay_subdir))
        except Exception:
            pass
        
        # 1. compute the partial width------------------------------------------
        #self.get_branching_ratio()
        start = time.time()
        # 2. compute the production matrix element -----------------------------
        self.handle_model()
        processes = [line[9:].strip() for line in self.banner.proc_card
                     if line.startswith('generate')]
        processes += [' '.join(line.split()[2:]) for line in self.banner.proc_card
                      if re.search(r'^\s*add\s+process', line)]


        commandline = self.get_production_command(processes)
        #misc.sprint(commandline)
        # 3. Create all_ME + topology objects ----------------------------------
#        matrix_elements = mgcmd._curr_matrix_elements.get_matrix_elements()
#        self.all_ME.adding_me(matrix_elements, pjoin(path_me,'production_me'))
        

        # 4. compute the full matrix element -----------------------------------
        if self.mode == "onshell" or (self.mode == "density" and self.options['density_debug']):
            commandline += self.get_full_matrix_command(processes)
            #misc.sprint(commandline)
            logger.debug("Full ME calculation") 
        else:
            logger.debug("Skipping full ME calculation")        

        # 5. add the decay information to the all_topology object --------------                        
#        for matrix_element in mgcmd._curr_matrix_elements.get_matrix_elements():
#            me_path = pjoin(path_me,'full_me', 'SubProcesses', \
#                       "P%s" % matrix_element.get('processes')[0].shell_string())
#            self.all_ME.add_decay(matrix_element, me_path)

        # 5.b import production matrix elements (+ related info) in the full process directory
#        list_prodfiles=['matrix_prod.f','configs_production.inc','props_production.inc','nexternal_prod.inc']
#        for tag in self.all_ME:
#            prod_path=self.all_ME[tag]['path']
#            nfinal=len(self.all_ME[tag]['base_order'][1])
#            for dico in self.all_ME[tag]['decays']:
#                full_path=dico['path']
                #print prod_path
                #print full_path
                #print ' '
#                for item in list_prodfiles:
                     #print full_path
#                     prodfile=pjoin(prod_path,item)
#                     destination=pjoin(full_path,item)
#                     shutil.copyfile(prodfile, destination)  
                # we need to write the file config_decays.inc
#                self.generate_configs_file(nfinal,dico,full_path)
                

#        if self.options["onlyhelicity"]:
#            return

        # 6. generate decay only part ------------------------------------------
        def fill_all_me(self, prod_or_decay):
            # store information about matrix element
            if prod_or_decay not in ["production", "decay"]:
                raise ValueError("The input prod_or_decay of fill_all_me only accepts values in 'production' or 'decay'.")
            for matrix_element in mgcmd._curr_matrix_elements.get_matrix_elements():
                me_string = matrix_element.get('processes')[0].shell_string()
                for me in matrix_element.get('processes'):
                    # get the original order:
                    initial = []
                    final = [l.get('id') for l in me.get_legs_with_decays()\
                                if l.get('state') or initial.append(l.get('id'))]
                    order = (tuple(initial), tuple(final))
                    initial.sort(), final.sort()
                    tag = (tuple(initial), tuple(final))
                    self.all_me[tag] = {'pdir': "P%s" % me_string, 'order': order, 'type': prod_or_decay}


        mgcmd = self.mgcmd
        self.all_me = {}

        # legacy options 'onshell_v1' and 'madspin_v1' store both the production and the decay in a single folder
        if self.options['spinmode'] in ['onshell_v1', 'madspin_v1']:
            commandline += self.get_decay_command()
            commandline = commandline.replace('add process', 'generate',1)
            mgcmd.exec_cmd(commandline, precmd=True)

            # same t-channel widths as madevent (zerowidth_tchannel)
            commandline = 'output standalone_fortran %s --prefix=int --zerowidth_tchannel=True' % pjoin(path_me, ms_me_subdir)
            logger.info(commandline)
            mgcmd.exec_cmd(commandline, precmd=True)
            fill_all_me(self, "production")
        else:
            # auto_zero_width_PA: the decayed particles in the production
            # (pdg list), the decaying particle in each decay (True/False)
            zero_width = self.zerowidth_decay_pdgs()
            commandline_production = commandline.replace('add process', 'generate',1)
            backend = self.density_backend(commandline_production, zero_width)
            logger.info(commandline_production)
            mgcmd.exec_cmd(commandline_production, precmd=True)
            # same t-channel widths as madevent (zerowidth_tchannel)
            self.output_density_me(pjoin(path_me, ms_me_subdir), backend, 'p',
                                   '--zerowidth_tchannel=True --zerowidth_decay=%s'
                                   % zero_width)

            # store information about the production matrix elements
            fill_all_me(self, "production")

            commandline_decay = self.get_decay_command()
            commandline_decay = commandline_decay.replace('add process', 'generate',1)

            logger.info(commandline_decay)
            mgcmd.exec_cmd(commandline_decay, precmd=True)
            self.output_density_me(pjoin(path_me, ms_me_decay_subdir),
                                   self.density_backend(commandline_decay, zero_width),
                                   'd', '--zerowidth_decay=%s' % bool(zero_width))

            # store information about the decay matrix elements
            fill_all_me(self, "decay")

        logger.info('Done %.4g' % (time.time()-start))

        return self.all_me

    def density_backend(self, commandline, zero_width=''):
        """'madmatrix' or 'fortran': what evaluates the density matrices and
        |M|^2 of the processes commandline generates (option density_backend).
        zero_width is the --zerowidth_decay of the production
        (zerowidth_decay_pdgs)."""
        try:
            backend = self.options['density_backend']
        except Exception:
            backend = 'madmatrix'
        if backend == 'fortran':
            return 'fortran'
        if '[' in commandline:
            # a loop-induced production (get_LO_definition_from_NLO leaves its
            # [sqrvirt=...]/[virt=...] in place): MadLoop, only in the Fortran
            return 'fortran'
        mgcmd = getattr(self, 'mgcmd', None)
        if mgcmd is not None and mgcmd.options.get('complex_mass_scheme'):
            # the complex-mass scheme (set from the banner's proc card): the
            # parameters madmatrix writes for it do not compile, and its
            # output only fails at the build, which output_density_me cannot
            # catch
            logger.info('MadSpin: complex-mass scheme, the density matrices '
                        'come from the Fortran matrix elements')
            return 'fortran'
        if zero_width:
            # auto_zero_width_PA: only the Fortran output writes propagators
            # with a zero width (output standalone_fortran --zerowidth_decay)
            logger.info('MadSpin: auto_zero_width_PA, the density matrices '
                        'come from the Fortran matrix elements')
            return 'fortran'
        return 'madmatrix'

    def density_libtag(self, side):
        """The LIBTAG of the madmatrix libraries of one density tree (side 'p'
        production, 'd' decay) for this MadSpin run (density_libtag)."""
        return density_libtag(getattr(self.mscmd, '_ms_run_id', 1), side)

    def output_density_me(self, path, backend, side, fortran_options=''):
        """Write the matrix elements just generated to path, for the density
        modes (side 'p' production, 'd' decay). A madmatrix output is built
        right away, while these processes are still the current ones: one that
        cannot be written or does not compile is replaced by the Fortran one.
        Returns the backend written; MadSpinInterface.create_f2py_module tells
        the two apart from what it finds in path."""
        if backend == 'madmatrix':
            commandline = 'output standalone %s -f --noeps=True' % path
            logger.info(commandline)
            try:
                self.mgcmd.exec_cmd(commandline, precmd=True)
                dependent = madmatrix_density.scale_dependence(path)
                if dependent:
                    # couplings depending on MU_R: the Fortran output sets it
                    # from each event's scale, madmatrix keeps the card value
                    raise madmatrix_density.MadDensityError(
                        'MU_R-dependent couplings (%s)' % '; '.join(
                            '%s: %s' % (p, ', '.join(r))
                            for p, r in sorted(dependent.items())))
                misc.compile(madmatrix_density.make_variables(
                                 libtag=self.density_libtag(side)),
                             cwd=pjoin(path, 'SubProcesses'), mode='cpp',
                             nb_core=self.mgcmd.options['nb_core'])
                return backend
            except Exception as error:
                logger.warning('MadSpin could not write or build its density matrix '
                               'elements with madmatrix (%s): falling back to the '
                               'Fortran standalone output.',
                               str(error).strip().split('\n')[0])
                logger.debug('madmatrix failure: %s', error)
                if os.path.exists(path):
                    shutil.rmtree(path)
        commandline = 'output standalone_fortran %s --prefix=int --density=1 %s -f' % (
                                                        path, fortran_options)
        logger.info(commandline)
        self.mgcmd.exec_cmd(commandline, precmd=True)
        return 'fortran'

    @misc.mute_logger()
    def handle_model(self):
        mgcmd = self.mgcmd
        modelpath = self.model.get('modelpath+restriction')

        # NLO contexts (loop_interface) force apply_flavor_grouping=False, which
        # collapses get_external_flavors() to a single trivial entry and breaks
        # merged-particle handling in MadSpin.  Re-enable it before reloading
        # the model so the production MEs share the LO multi-flavor treatment.
        mgcmd.exec_cmd('set apply_flavor_grouping True')

        commandline="import model %s" % modelpath
        if not self.model.mg5_name:
            commandline += ' --modelname'

        mgcmd.exec_cmd(commandline)
        # Handle the multiparticle of the banner        
        #for name, definition in self.mscmd.multiparticles:
        if hasattr(self.mscmd, 'multiparticles_ms'):
            for name, pdgs in  self.mscmd.multiparticles_ms.items():
                if name == 'all':
                    continue
                #self.banner.get('proc_card').get('multiparticles'):
                mgcmd.do_define("%s = %s" % (name, ' '.join(repr(i) for i in pdgs)))
        mgcmd.exec_cmd("set group_subprocesses False")


    def get_production_command(self, processes):

            
        logger.info('generating the production square matrix element for %s' % self.mode)
        commandline=''
        for proc in processes:
            if '[' in proc:
                new_proc = reweight_interface.ReweightInterface.get_LO_definition_from_NLO(proc, self.mgcmd._curr_model)
            else:
                new_proc = 'add process %s ;' % proc               
            commandline += self.adapt_production(new_proc)
#        commandline = commandline.replace('add process', 'generate',1)
#        logger.info(commandline)
#        
#        mgcmd.exec_cmd(commandline, precmd=True)
#        commandline = 'output standalone_msP %s %s' % \
#        (pjoin(path_me,'production_me'), ' '.join(self.list_branches.keys()))        
#        mgcmd.exec_cmd(commandline, precmd=True)        
#        logger.info('Done %.4g' % (time.time()-start))

        return commandline

    def get_full_matrix_command(self, processes):
        """generate full matrix-element squared with decay"""
        logger.info('generating the full matrix element squared (with decay)')

        
#        start = time.time()
        commandline = ''
        to_decay = list(self.mscmd.list_branches.keys())
        decay_text = []
        for decays in self.mscmd.list_branches.values():
            for decay in  decays:
                # MadSpin's own '@' grouping tag, not something MG5 should see
                decay = self.mscmd._split_group_tag(decay)[0]
                if '=' not in decay:
                    decay += ' QCD=99'
                if ',' in decay:
                    decay_text.append('(%s)' % decay)
                else:
                    decay_text.append(decay)
        decay_text = ', '.join(decay_text)
#        commandline = ''
        
        for proc in processes:
            if not proc.strip().startswith(('add','generate')):
                proc = 'add process %s' % proc
            commandline += self.get_proc_with_decay(proc, decay_text, self.mgcmd._curr_model)

#        start = time.time()
        to_decay = list(self.mscmd.list_branches.keys())
        decay_text = []
        for decays in self.mscmd.list_branches.values():
            for decay in  decays:
                # MadSpin's own '@' grouping tag, not something MG5 should see
                decay = self.mscmd._split_group_tag(decay)[0]
                if '=' not in decay:
                    decay += ' QCD=99'
                if ',' in decay:
                    decay_text.append('(%s)' % decay)
                else:
                    decay_text.append(decay)
        decay_text = ', '.join(decay_text)
#        commandline = ''

        for proc in processes:
            if not proc.strip().startswith(('add','generate')):
                proc = 'add process %s' % proc
            commandline += self.get_proc_with_decay(proc, decay_text, self.mgcmd._curr_model)

        return commandline
    
    def get_decay_command(self):
        logger.info('generate matrix element for decay only (1 - > N).')
#        start = time.time()
        commandline = ''
        i=0
        for processes in self.list_branches.values():
            for proc in processes:
                # Drop MadSpin's own '@' grouping tag first: this line appends a
                # process number of its own, MG5 binds that at the top level and
                # would absorb the user's as the process number of the
                # *sub-decay*. Nothing would fail -- the amplitude is the same --
                # but the tag is MadSpin bookkeeping and has no business
                # reaching MG5. (madspin_v1 strips it the same way, decay.py
                # get_all_ME step 6.)
                proc = self.mscmd._split_group_tag(proc)[0]
                newproc = "add process %s @%i --no_warning=duplicate --standalone;" % (proc,i)
                commandline += self.adapt_decay(newproc)
                #commandline+="add process %s @%i --no_warning=duplicate --standalone;" % (proc,i)
                i+=1
        return commandline

    def zerowidth_decay_pdgs(self):
        """The value of ``output standalone_fortran --zerowidth_decay=`` of the
        production for auto_zero_width_PA: comma-separated |pdg|, empty for
        none. The decay output gets True when this is not empty.

        With spinmode=PA, the propagators of the particles MadSpin decays are
        written with a zero width -- in the production, and in each particle's
        own decay only (ProcessExporterFortranSA.get_zerowidth_pdgs). The
        param_card, and so every width MadSpin reads (Breit-Wigner,
        reshuffling, branching ratios), is untouched.
        """
        pdgs = []
        if hasattr(getattr(self, 'mscmd', None), '_zero_width_pdgs'):
            pdgs = self.mscmd._zero_width_pdgs()
        return ','.join(str(pid) for pid in pdgs)

    def refresh_me_param_cards(self):
        """Put MadSpin's parameters inside every matrix-element directory.

        ``output standalone`` writes ``Cards/param_card.dat`` from the *model*,
        i.e. from the model's default/restriction values -- it knows nothing
        about the event file. But ``initialise_f2py_module`` hands exactly that
        file to the compiled matrix element, so without this the production and
        decay density matrices are evaluated with the model defaults and every
        parameter the user actually generated the events with (a mass, a width,
        a Wilson coefficient) is silently ignored.

        ``path_me/param_card.dat`` is the single source of truth: it is written
        from ``banner['slha']`` on every run (decay_all_events.__init__), so it
        already carries the parameters of the input events, including the
        ``import model <MODEL> <CARD>`` override -- the one supported way to
        ask MadSpin for different parameters, which rewrites ``banner['slha']``
        after checking it against the banner.

        A *copy*, not a symlink: these trees are compiled in place, tarred into
        gridpacks and (under ``ms_dir``) moved to other machines, none of which
        survives a link pointing outside the tree; and the copy left behind is
        the record of what the run used, which a link -- repointed by the next
        run -- would destroy. Freshness costs nothing here because this runs on
        every run, reuse included. Same idiom as the legacy
        ``compile_fortran`` (production_me/full_me/decay_me).
        """
        source = pjoin(self.path_me, 'param_card.dat')
        if not os.path.exists(source):
            return
        ms_me_subdir = getattr(self.mscmd, 'ms_me_subdir', 'madspin_me')
        ms_me_decay_subdir = getattr(self.mscmd, 'ms_me_decay_subdir', 'madspin_decay')
        for subdir in (ms_me_subdir, ms_me_decay_subdir):
            cards = pjoin(self.path_me, subdir, 'Cards')
            if not os.path.isdir(cards):
                continue
            shutil.copyfile(source, pjoin(cards, 'param_card.dat'))

    def compile(self):
        logger.info('Compiling code')
        # Before anything is compiled or loaded: the matrix elements read their
        # parameters from these cards at initialise() time, and what
        # ``output standalone`` left there is the model default.
        self.refresh_me_param_cards()
        ms_me_subdir = getattr(self.mscmd, 'ms_me_subdir', 'madspin_me')
        ms_me_decay_subdir = getattr(self.mscmd, 'ms_me_decay_subdir', 'madspin_decay')
        # Per-instance suffix for the f2py-linked shared library: with the
        # makefile's former (always empty) default ``PROCNAME=`` it produced
        # ``liball_2me.{so,dylib}`` whichever madspin_me_<N> subdir we are in
        # (the default is now the output directory name), and the
        # dynamic loader on both Linux (SONAME) and macOS (LC_ID_DYLIB)
        # caches that library by its baked-in name. So a second MadSpin
        # call in the same process — even loading a wrapper from a fresh
        # subdir — would still resolve to the first call's already-loaded
        # library and report ``undefined symbol`` for any newly-added
        # matrix element. We override PROCNAME at make time for the 2nd+
        # call so the resulting library gets a unique SONAME /
        # install_name and the loader keeps both copies live.
        ms_run_id = getattr(self.mscmd, '_ms_run_id', 1)
        # The production (madspin_me) and decay (madspin_decay) matrix elements
        # are compiled into two separate standalone trees but are loaded into
        # the *same* Python process to build the density matrix. They must NOT
        # share the f2py extension-module name (all_matrix<MENUM>py) nor the
        # dependent Fortran shared library name (liball<PROCNAME>_<MENUM>me):
        # with the former empty default PROCNAME both sides produced
        # ``all_matrix2py`` + ``@rpath/liball_2me.dylib``, and two identically
        # named f2py modules (sharing the same Fortran COMMON blocks / global
        # symbols) co-existing in one process corrupt memory and segfault
        # during the density evaluation. Build the decay side with a distinct
        # MENUM so both the module and the dependent library get unique names.
        # (see MadSpinInterface._load_f2py_matrix_module / create_f2py_module,
        # which load madspin_me with MENUM=2 and madspin_decay with MENUM=1).
        prod_args = ['MENUM=2', 'all_matrix2py.so']
        decay_args = ['MENUM=1', 'all_matrix1py.so']
        if ms_run_id > 1:
            prod_args.insert(0, 'PROCNAME=_ms%d' % ms_run_id)
            decay_args.insert(0, 'PROCNAME=_ms%d' % ms_run_id)
        #my_env = os.environ.copy()
        #os.environ["GFORTRAN_UNBUFFERED_ALL"] = "y"
        trees = [(ms_me_subdir, prod_args, 'p')]
        #Valentin: not sure the decay_folder exists in all cases, so I check
        if os.path.exists(pjoin(self.path_me, ms_me_decay_subdir)):
            trees.append((ms_me_decay_subdir, decay_args, 'd'))
        for subdir, fortran_args, side in trees:
            tree = pjoin(self.path_me, subdir)
            if madmatrix_density.is_output(tree):
                # The C++ libraries madmatrix.density loads, which
                # output_density_me already built (make has nothing left to do
                # then); named per tree for the same reason the Fortran side
                # changes MENUM and PROCNAME above (density_libtag).
                misc.compile(madmatrix_density.make_variables(
                                 libtag=self.density_libtag(side)),
                             cwd=pjoin(tree, 'SubProcesses'), mode='cpp',
                             nb_core=self.mgcmd.options['nb_core'])
                continue
            self.use_global_flag(tree)
            misc.compile(cwd=pjoin(tree, 'Source'),
                         nb_core=self.mgcmd.options['nb_core'])
            misc.compile(fortran_args,
                         cwd=pjoin(tree, 'SubProcesses'),
                         nb_core=self.mgcmd.options['nb_core'])

    def save_to_file(self, *args):
        import sys
        with misc.stdchannel_redirected(sys.stdout, os.devnull):
            return super(decay_all_events_onshell,self).save_to_file(*args) 

    

    def adapt_production(self, line):
        return line
    
    def adapt_decay(self, line):
        return line
   
    
class decay_all_events_density(decay_all_events_onshell):    
    
    mode = 'density'

    def __init__(self, *args, **opts):
        self.density_matrix = True
        return super().__init__(*args, **opts)


    #def get_full_matrix_command(self, processes): 
    #    "No need of full matrix-element in this mode"
    #    return ""
    
    def adapt_production(self, line):
        """If allowing offshell matrix element add * to the decaying particle.

        Only particles that the user actually asked MadSpin to decay (i.e. keys
        of ``self.mscmd.list_branches``) get marked off-shell. Spectator final-
        state particles -- in particular multiparticle aliases like ``j`` --
        must be left as-is, otherwise MG5 receives an invalid process string
        of the form ``... > t* j* ;`` and "Skipping full ME calculation"."""

        if self.options['spinmode'] in ['PA', 'onshell']:
             return line

        to_decay = set()
        if hasattr(self, 'mscmd') and hasattr(self.mscmd, 'list_branches'):
            to_decay = set(self.mscmd.list_branches.keys())

        out = []
        input = line.split(';')
        for oneline in input:
            if not oneline.strip():
                continue
            if '>' not in oneline:
                # Non-process command (e.g. the NLO 'define pert_QCD = ...' line):
                # nothing to mark off-shell, keep it verbatim.
                out.append("%s;" % oneline.strip())
                continue
            init, final = oneline.rsplit('>',maxsplit=1)
            end = len(final)
            if "[" in final:
                end = min(end, final.index('['))
            if "$" in final:
                end = min(end, final.index('$'))
            if "/" in final:
                end = min(end, final.index('/'))
            particle, final = final[:end], final[end:]
            new_particle = []
            for p in particle.split():
                # a polarised leg is written "t{L}"; the label MadSpin decays is
                # the part before the brace, and MG5 parses the off-shell star
                # after it ("t{L}*"), so strip the brace for the lookup only.
                name = p.split('{', 1)[0]
                if name in to_decay:
                    new_particle.append('%s*' % p)
                else:
                    new_particle.append(p)
            out.append("%s > %s %s;" % (init, ' '.join(new_particle), final))
        return ' '.join(out)

    
    def adapt_decay(self, line):
        '''If allowing offshell matrix element add * to the decaying particle.'''
        if self.options['spinmode'] in ['PA', 'onshell']:
             return line
        
        out = []
        input = line.split(';')
        for oneline in input:
            if not oneline.strip():
                continue
            if '>' not in oneline:
                # Non-process command (e.g. the NLO 'define pert_QCD = ...' line):
                # nothing to mark off-shell, keep it verbatim.
                out.append("%s;" % oneline.strip())
                continue
            init, final = oneline.split('>',maxsplit=1)
            end = len(init)
            out.append("%s* > %s;" % (init.strip(), final))

        return ' '.join(out)

    def save_to_file(self, *args):

        import sys
        with misc.stdchannel_redirected(sys.stdout, os.devnull):
            return super(decay_all_events_onshell,self).save_to_file(*args) 



class DensityMatrix:
    """
    DensityMatrix is a numpy container holding
      - helicities: int32 array of shape (N, L)
      - values:     complex64 array of shape (N,)
    It corresponds to INTER = Sum_colors JAMP(h1)*JAMP(h2)
    (eq 45 in Quentin's thesis)

    PERFORMANCE NOTES 
    -----------------
    - Keep helicity labels, but store them as plain NumPy arrays
    - Cache the helicity-index map (allowed_hel, n_changing) -> map dict
    - Avoid Python dict/tuple joins during contractions
    - cache ONE lexsort permutation per basis_id
    - Cache diagonal masks per basis_id (trace becomes cheap)
    - Cache tensor-product helicity tables per tensor-product basis_id, so tensor_product
       only recomputes VALUES per event (outer product / kron), not helicity labels.

    Invariants
    ----------
    - helicities[k] and values[k] always refer to the same matrix element.
    - for map-built instances, row order is deterministic from get_map_density_matrix().
    - scalar_multiplication fast-path is valid only when map_density_matrix_ind is
      the same cached object.
    """

    # Cache for the helicity-index map.
    # Key: (tuple(allowed_hel), n_changing)
    _map_cache = {}

    # Cache for map-built basis templates.
    # Key: (tuple(allowed_hel), n_changing)
    # Value: (helicities[int32], source_idx[int64], needs_conjugation[bool])
    _map_template_cache = {}

    # Cache for sort permutations by basis_id.
    # basis_id is stable across events for the same helicity basis.
    _sort_cache = {}

    # Cache diagonal masks by basis_id (depends only on helicities)
    _diag_cache = {}

    # Same, as integer positions, for trace()
    _diag_pos_cache = {}

    # Cache tensor-product helicity tables by basis_id
    _tp_hel_cache = {}

    # Cache helicity-restriction row selections.
    # Key: (basis_id, normalised restriction key)
    # Value: (mask[bool], rows[int64], diag_rows[int64]) -- see _restriction_rows
    _restriction_cache = {}

    # Same, but for the sorted-alignment path: the surviving positions *within*
    # the cached sort permutation. Filled lazily, since the map-built fast path
    # never needs a sort order at all.
    # Key: (basis_id, normalised restriction key)
    # Value: (keep[int64], sorted_rows[int64])
    _restriction_sort_cache = {}

    def __init__(self, array, nchanging, all_helicity_combinations, dimension):
        """
        Parameters
        ----------
        array : np.ndarray or array-like
            Either:
              - a 1D complex array containing the independent INTER entries in the
                MadGraph/MadSpin triangular storage convention (as produced by Fortran),
                OR
              - a dict-like object {"helicities": <int32 (N,L)>, "values": <complex64 (N,)>}
                (used internally by from_components / tensor_product).
        nchanging : int
            Number of helicities that are changing in the decay chain segment.
        all_helicity_combinations : list[int] or np.ndarray
            Flat list of allowed helicities (Fortran-style ordering) used to build the map.
        dimension : int
            Dimension used for packed-triangular diagonal indexing.
        """
        self.nchanging = int(nchanging)
        self.all_helicity_combinations = all_helicity_combinations
        self.dimension = int(dimension)

        # Indices of diagonal elements in the packed upper-triangular storage
        self.diag_elements = [
            i * (2 * self.dimension - i + 1) // 2 for i in range(self.dimension)
        ]

        # Map is cached and reused across instances with same (allowed_hel, n_changing)
        self.map_density_matrix_ind = DensityMatrix.get_map_density_matrix(
            all_helicity_combinations, self.nchanging
        )

        # Basis identifier (stable across events) for caching sort permutations and diag masks.
        # For "map-built" matrices, this is fully determined by (allowed_hel, n_changing).
        self._basis_id = ("map", tuple(all_helicity_combinations), self.nchanging)

        # Per-particle helicity restriction (see set_hel_restriction). None = full sum.
        self.hel_restriction = None
        # Restriction used by trace()/normalized() when hel_restriction is a
        # *cross* one (see set_hel_restriction_trace). None = untraced.
        self.hel_restriction_trace = None

        # Lazy per-instance cache
        self._sort_order = None

        # If array already comes in as our internal representation (from_components)
        if isinstance(array, dict) and "helicities" in array and "values" in array:
            self.helicities = array["helicities"].astype(np.int32, copy=False)
            self.values = array["values"].astype(np.complex64, copy=False)
        else:
            hel_template, src_idx, conj_mask = DensityMatrix.get_map_template(
                all_helicity_combinations, self.nchanging
            )
            values = np.asarray(array)[src_idx]
            if conj_mask.any():
                values = values.copy()
                values[conj_mask] = np.conjugate(values[conj_mask])
            self.helicities = hel_template
            self.values = values.astype(np.complex64, copy=False)

        # Diagonal mask is cached per basis_id
        self._diag_mask = self._get_diag_mask_cached()

    # -------------------------------------------------------------------------
    # Map caching 
    # -------------------------------------------------------------------------

    @classmethod
    def get_map_density_matrix(cls, allowed_hel, n_changing):
        """Build/cache mapping: helicity label tuple -> (is_direct, inter_index).

        allowed_hel is the flat Fortran ALLOW_HEL buffer of length
        n_comb*n_changing. Direct entries are filled for I<=J; conjugate labels
        reuse the same INTER index.
        """
        # allowed_hel can be list/np array: make it hashable
        cache_key = (tuple(allowed_hel), int(n_changing))
        cached = cls._map_cache.get(cache_key)
        if cached is not None:
            return cached

        map_density = {}
        #c  FORTRAN CODE
        #c 576       DO I = 1, N_COMB
        #c 577         DO N = 1, N_CHANGING
        #c 578           NHEL(POS(N)) = ALLOW_HEL((I-1)*N_CHANGING+N)
        #c 579           CALL GET_AMP(P,NHEL,IC,AMP)
        #c 580           CALL GET_JAMP(AMP,JAMP(1,I))
        #c 581         ENDDO
        #c 582       ENDDO
        #c 584       SOL = 0
        #c 585       DO I = 1, N_COMB
        #c 586         DO J= I, N_COMB
        #c 587           SOL = SOL +1
        #c 588           CALL GET_INTER(JAMP(1,I), JAMP(1,J), INTER(SOL))
        #c 589         ENDDO
        #c 590       ENDDO

        n_comb = len(allowed_hel) // n_changing

        # Direct entries (i <= j)
        nb_sol = 0
        for i in range(n_comb):
            for j in range(i, n_comb):
                curr_index = []
                for n in range(n_changing):
                    curr_index.append(allowed_hel[i * n_changing + n])
                    curr_index.append(allowed_hel[j * n_changing + n])
                map_density[tuple(curr_index)] = (True, nb_sol)
                nb_sol += 1

        # Complex-conjugate entries (swap each (h1,h2) pair)
        def conjugate_index(orig_index):
            flip_index = []
            for k in range(0, len(orig_index), 2):
                flip_index += [orig_index[k + 1], orig_index[k]]
            return tuple(flip_index)

        for key in list(map_density.keys()):
            conj = conjugate_index(key)
            if conj != key:
                map_density[conj] = (False, map_density[key][1])

        cls._map_cache[cache_key] = map_density
        return map_density

    @classmethod
    def get_map_template(cls, allowed_hel, n_changing):
        """Return cached (helicities, src_idx, conj_mask) for vectorized reconstruction.

        helicities is shared cached data and should not be mutated in place.
        src_idx selects packed INTER entries; conj_mask marks entries that need
        complex conjugation.
        """
        cache_key = (tuple(allowed_hel), int(n_changing))
        cached = cls._map_template_cache.get(cache_key)
        if cached is not None:
            return cached

        map_density = cls.get_map_density_matrix(allowed_hel, n_changing)
        keys = list(map_density.keys())
        helicities = np.asarray(keys, dtype=np.int32)
        src_idx = np.fromiter(
            (map_density[key][1] for key in keys), dtype=np.int64, count=len(keys)
        )
        conj_mask = np.fromiter(
            (not map_density[key][0] for key in keys), dtype=np.bool_, count=len(keys)
        )
        out = (helicities, src_idx, conj_mask)
        cls._map_template_cache[cache_key] = out
        return out

    # -------------------------------------------------------------------------
    # Construction helper for tensor products
    # -------------------------------------------------------------------------

    @staticmethod
    def from_components(helicities, values, nchanging, all_helicity_combinations, dimension, basis_id):
        """
        Construct from prebuilt arrays (typically tensor products).

        No map is attached (map_density_matrix_ind=None), so scalar contraction
        uses the sorted-alignment path.
        """
        obj = object.__new__(DensityMatrix)
        obj.nchanging = int(nchanging)
        obj.all_helicity_combinations = all_helicity_combinations
        obj.dimension = int(dimension)
        obj.diag_elements = [
            i * (2 * obj.dimension - i + 1) // 2 for i in range(obj.dimension)
        ]

        # Tensor-product objects typically don't have a useful map
        obj.map_density_matrix_ind = None

        obj.helicities = helicities.astype(np.int32, copy=False)
        obj.values = values.astype(np.complex64, copy=False)

        obj._basis_id = basis_id
        obj.hel_restriction = None
        obj.hel_restriction_trace = None
        obj._sort_order = None

        # Diagonal mask is cached per basis_id
        obj._diag_mask = obj._get_diag_mask_cached()
        return obj

    # -------------------------------------------------------------------------
    # Cached diagonal mask
    # -------------------------------------------------------------------------

    def _get_diag_mask_cached(self):
        """
        Diagonal entries satisfy, for label [h1_1,h2_1,h1_2,h2_2,...]:
            h1_k == h2_k  for all k
        This is independent of entry ordering and depends only on helicities,
        so we cache it per basis_id.
        """
        cached = DensityMatrix._diag_cache.get(self._basis_id)
        if cached is not None:
            return cached

        h = self.helicities
        mask = np.all(h[:, 0::2] == h[:, 1::2], axis=1)
        DensityMatrix._diag_cache[self._basis_id] = mask
        return mask

    def _get_diag_positions_cached(self):
        """Positions of the diagonal entries, as a plain tuple of ints.

        trace() sums a handful of entries -- two, for a single decaying
        fermion -- and numpy costs about 0.9 us to do that however few there
        are, nearly all of it dispatch. Indexing the cached positions directly
        is 8x faster at that size. Cached per basis_id alongside the mask.
        """
        cached = DensityMatrix._diag_pos_cache.get(self._basis_id)
        if cached is not None:
            return cached
        positions = tuple(int(i) for i in np.flatnonzero(self._diag_mask))
        DensityMatrix._diag_pos_cache[self._basis_id] = positions
        return positions

    # -------------------------------------------------------------------------
    # Helicity restriction (production polarisation)
    # -------------------------------------------------------------------------

    @staticmethod
    def _is_cross_restriction(entry):
        """Whether a *normalised* per-particle entry is a cross (interference)
        one, i.e. a ``(bra_allowed, ket_allowed)`` pair rather than a flat
        tuple of helicity values."""
        return (isinstance(entry, tuple) and len(entry) == 2
                and isinstance(entry[0], tuple))

    @staticmethod
    def normalize_hel_restriction(restriction):
        """Canonical, hashable form of a per-particle helicity restriction.

        ``restriction`` is a sequence with one entry per *changing* helicity
        (i.e. per decaying particle, in the order the density matrix' helicity
        columns are laid out). Each entry is either

          - ``None`` (or an empty container): that index is summed over its
            whole basis -- the historical behaviour,

          - a container of the helicity values that index is allowed to take
            (the *symmetric* form: both the bra and the ket index of that
            particle must lie in the set), or

          - a pair ``(bra_allowed, ket_allowed)`` of two such containers (the
            *cross*, or pure-interference, form: see ``set_hel_restriction``).
            ``(S, S)`` normalises back to the symmetric ``S``.

        Returns ``None`` when nothing is restricted, so that the unrestricted
        code paths stay bit-for-bit identical.
        """
        if restriction is None:
            return None

        def _flat(values):
            return tuple(sorted(set(int(h) for h in values)))

        key = []
        for allowed in restriction:
            if allowed is None:
                key.append(None)
                continue
            allowed = list(allowed)
            if allowed and all(isinstance(x, (list, tuple, set, frozenset))
                               for x in allowed):
                if len(allowed) != 2:
                    raise ValueError(
                        "A cross helicity restriction must be a "
                        "(bra_allowed, ket_allowed) pair, got %s" % (allowed,))
                bra, ket = _flat(allowed[0]), _flat(allowed[1])
                if not bra or not ket:
                    # an empty side would kill the whole contraction; treat it
                    # like the unrestricted historical spelling instead
                    key.append(None)
                elif bra == ket:
                    key.append(bra)
                else:
                    key.append((bra, ket))
                continue
            allowed = _flat(allowed)
            key.append(allowed if allowed else None)
        if all(a is None for a in key):
            return None
        return tuple(key)

    def set_hel_restriction(self, restriction):
        """Attach a per-particle helicity restriction to this matrix.

        The restriction travels with the matrix rather than with the call, so
        that ``scalar_multiplication`` / ``trace`` pick it up wherever the
        production density matrix is contracted -- including the sequential
        accept/reject, which contracts it against partially filled decay
        tensors. Returns self so it can be chained onto ``get_density``.

        A restricted index is one whose production process carries a
        polarisation brace: ``{0}``/``{+}``/``{-}`` select a single helicity X
        and so keep only the diagonal ``rho_prod(X,X) rho_dec(X,X)`` term,
        ``{T}`` keeps the whole ``-1/+1`` block and drops the ``0`` row and
        column. The rule is uniform: a matrix element (i,j) of particle k
        survives iff *both* i and j are allowed for k.

        A per-particle entry may instead be a *cross* pair ``(P, D)``, which
        keeps the (i,j) entries with ``i in P and j in D`` **together with**
        their transposes ``i in D and j in P``. With ``P`` and ``D`` disjoint
        this is the pure-interference block between the two polarisations: it
        has no diagonal entry, so the restricted ``trace()`` is exactly zero
        (the interference term carries no cross-section), and it is closed
        under (i,j) -> (j,i). That closure is what makes the contraction real:
        rho_prod and rho_dec are both hermitian, so the (j,i) term is the
        complex conjugate of the (i,j) one and the pair adds up to
        ``2 Re[rho_prod(i,j) rho_dec(i,j)]``. Summing ``P x D`` *alone* would
        give a complex number and is not a physical weight -- see
        doc/madspin_sequential_plan.md section 13.
        """
        self.hel_restriction = DensityMatrix.normalize_hel_restriction(restriction)
        return self

    def set_hel_restriction_trace(self, restriction):
        """Attach the restriction ``trace()`` / ``normalized()`` must use when
        ``hel_restriction`` is a *cross* (pure-interference) one.

        For a symmetric restriction the two are the same object and this is
        never consulted: the polarised cross-section is normalised by the
        polarised trace, which is exactly the restriction the contraction uses,
        and that is what keeps the accept/reject weight averaging to 1/n.

        A cross restriction has no diagonal entry, so its restricted trace is
        identically zero -- it is the statement that the interference term
        carries no cross-section. Using it to normalise would divide the weight
        by zero, so the two restrictions have to part company here: the
        contraction stays on the interference block while the normalisation
        keeps using the *production* trace, i.e. the symmetric restriction the
        production process' own braces impose (``None``, the full trace, for the
        unpolarised production this mode requires). See
        doc/madspin_sequential_plan.md section 13.4.
        """
        self.hel_restriction_trace = \
            DensityMatrix.normalize_hel_restriction(restriction)
        return self

    def _trace_restriction(self):
        """The restriction in force for ``trace()``.

        Symmetric restrictions are returned untouched, so nothing that existed
        before the interference mode can move; only a cross restriction defers
        to ``hel_restriction_trace``.
        """
        restriction = self.hel_restriction
        if restriction is None:
            return None
        if any(DensityMatrix._is_cross_restriction(entry)
               for entry in restriction):
            return self.hel_restriction_trace
        return restriction

    def _restriction_rows(self, restriction):
        """(mask, rows, diag_rows) implementing ``restriction`` on this matrix.

        ``mask`` is the boolean row mask, ``rows`` the indices of the surviving
        rows and ``diag_rows`` the indices surviving *and* diagonal (what the
        restricted trace sums). All three depend only on the helicity labels, so
        they are cached per (basis_id, restriction) and never recomputed per
        event.

        The contractions use ``rows``/``diag_rows`` rather than ``mask``: a
        restriction typically keeps a handful of rows out of hundreds, and
        gathering with a short index array is markedly cheaper than boolean
        indexing, which has to scan (and count) the full-length array. The rows
        come out in increasing index order, i.e. exactly the order boolean
        indexing would have produced, so the sums are bit-for-bit identical.
        """
        if restriction is None:
            return None, None, None
        cache_key = (self._basis_id, restriction)
        cached = DensityMatrix._restriction_cache.get(cache_key)
        if cached is not None:
            return cached

        h = self.helicities
        mask = np.ones(h.shape[0], dtype=np.bool_)
        for k, allowed in enumerate(restriction):
            if allowed is None:
                continue
            # column 2k is the row (bra) helicity of particle k, 2k+1 the column
            # (ket) one -- see get_map_density_matrix
            bra, ket = h[:, 2 * k], h[:, 2 * k + 1]
            if DensityMatrix._is_cross_restriction(allowed):
                # pure interference: (bra in P and ket in D) or its transpose.
                # Keeping both orderings is not optional -- it is what makes the
                # contraction real (see set_hel_restriction).
                left = np.asarray(allowed[0], dtype=np.int32)
                right = np.asarray(allowed[1], dtype=np.int32)
                mask &= ((np.isin(bra, left) & np.isin(ket, right)) |
                         (np.isin(bra, right) & np.isin(ket, left)))
                continue
            allowed = np.asarray(allowed, dtype=np.int32)
            mask &= np.isin(bra, allowed)
            mask &= np.isin(ket, allowed)

        out = (mask, np.flatnonzero(mask), np.flatnonzero(self._diag_mask & mask))
        DensityMatrix._restriction_cache[cache_key] = out
        return out

    def _restriction_row_mask(self, restriction):
        """Boolean row mask implementing ``restriction`` on this matrix' labels."""
        return self._restriction_rows(restriction)[0]

    def _restriction_sorted_rows(self, restriction):
        """(keep, sorted_rows) for the sorted-alignment path.

        ``keep`` are the positions inside the cached sort permutation whose row
        survives, and ``sorted_rows`` the rows themselves (``sort_order[keep]``).
        Contracting ``self.values[sorted_rows]`` against
        ``other.values[other_sort_order[keep]]`` visits exactly the entries, in
        exactly the order, that masking the two sorted views would have.

        Requires ``_ensure_sorted_view`` to have run.
        """
        cache_key = (self._basis_id, restriction)
        cached = DensityMatrix._restriction_sort_cache.get(cache_key)
        if cached is not None:
            return cached
        order = self._sort_order
        keep = np.flatnonzero(self._restriction_rows(restriction)[0][order])
        out = (keep, order[keep])
        DensityMatrix._restriction_sort_cache[cache_key] = out
        return out

    @staticmethod
    def _combine_restrictions(a, b):
        """The restriction in force for a contraction between two matrices.

        Only one side ever carries one (the production density matrix knows the
        polarisation, the decay side does not), so this is really "whichever is
        set", with a guard against two contradicting ones.
        """
        if a is None:
            return b
        if b is None or a == b:
            return a
        raise ValueError("Contradicting helicity restrictions between the "
                         "production and decay spin-density matrices")

    # -------------------------------------------------------------------------
    # Cached permutation for alignment by helicity labels
    # -------------------------------------------------------------------------

    def _ensure_sorted_view(self):
        """
        Cache the permutation that sorts rows by helicity labels for this basis.
        This is computed ONCE per basis_id and reused across all events, avoiding
        the repeated sort storm.
        """
        if self._sort_order is not None:
            return

        bid = self._basis_id
        cached = DensityMatrix._sort_cache.get(bid)
        if cached is not None:
            self._sort_order = cached
            return

        hel = self.helicities
        # Lexicographic sort by columns: last key is primary -> reverse columns
        keys = [hel[:, i] for i in range(hel.shape[1] - 1, -1, -1)]
        order = np.lexsort(keys)

        DensityMatrix._sort_cache[bid] = order
        self._sort_order = order

    # -------------------------------------------------------------------------
    # Operations
    # -------------------------------------------------------------------------

    def scalar_multiplication(self, other, hel_restriction=None):
        """
        Scalar contraction between two density matrices.

        Fast path:
        - If both matrices are built from the same cached map object, the entry
          order matches by construction -> dot-product of values.

        General path:
        - Align by cached helicity-sort permutations (one per basis_id), then
          dot-product on aligned values.

        ``hel_restriction`` (or, when omitted, the one either operand carries --
        see ``set_hel_restriction``) drops the (i,j) terms the production
        polarisation forbids before summing.
        """
        if len(self.values) != len(other.values):
            raise TypeError("Non-compatible dimensions of production and decay spin-density matrices")

        restriction = DensityMatrix._combine_restrictions(
            self.hel_restriction, other.hel_restriction)
        if hel_restriction is not None:
            restriction = DensityMatrix._combine_restrictions(
                restriction, DensityMatrix.normalize_hel_restriction(hel_restriction))
        # Fastest correct path for map-built matrices
        if (self.map_density_matrix_ind is not None and
                self.map_density_matrix_ind is other.map_density_matrix_ind):
            # np.dot rather than np.sum(a*b): identical for complex (dot does
            # not conjugate) but one call instead of two, and it skips the
            # temporary the multiply would allocate. 0.23 us against 0.90 us
            # on the 16-entry matrices this sees.
            if restriction is None:
                return np.dot(self.values, other.values)
            rows = self._restriction_rows(restriction)[1]
            # np.sum(a*b), not np.dot: the restricted path is asserted
            # bit-identical to the masked reference (see
            # test_restricted_paths_are_bit_identical_to_masking), and np.dot
            # sums pairwise. The fast unrestricted path above is where the
            # trials actually are.
            return np.sum(self.values[rows] * other.values[rows])

        # Align by cached ordering for each basis
        self._ensure_sorted_view()
        other._ensure_sorted_view()

        a = self._sort_order
        b = other._sort_order
        if restriction is None:
            return np.dot(self.values[a], other.values[b])
        # the restriction lives on self's rows; the surviving positions inside
        # the sort permutation are the same on both sides, so one cached gather
        # does the masking and the alignment at once
        keep, rows = self._restriction_sorted_rows(restriction)
        return np.sum(self.values[rows] * other.values[b[keep]])

    def tensor_product(self, other):
        """
        Tensor product of two density matrices (vectorized), with cached helicity labels.

        Values:
          - computed every call (event-dependent)

        Helicities:
          - cached per tensor-product basis_id (basis-dependent, not event-dependent)
        """
        # Cache key is basis-structure dependent and remains bounded per process setup.
        basis_id = ("tp", self._basis_id, other._basis_id)

        # --- helicities: cache per basis_id ---
        hel = DensityMatrix._tp_hel_cache.get(basis_id)
        if hel is None:
            h1 = self.helicities
            h2 = other.helicities
            n1, L1 = h1.shape
            n2, L2 = h2.shape

            L = L1 + L2
            hel = np.empty((n1 * n2, L), dtype=np.int32)
            hel[:, :L1] = np.repeat(h1, n2, axis=0)
            hel[:, L1:] = np.tile(h2, (n1, 1))

            DensityMatrix._tp_hel_cache[basis_id] = hel

        # --- values: compute every call ---
        v1 = self.values
        v2 = other.values

        # Often faster than np.kron
        vals = (v1[:, None] * v2[None, :]).ravel().astype(np.complex64, copy=False)

        out = DensityMatrix.from_components(
            hel,
            vals,
            self.nchanging + other.nchanging,
            self.all_helicity_combinations,
            self.dimension,
            basis_id=basis_id,
        )
        # a restriction is per-index, so the tensor product simply concatenates
        # the two (the decay side normally carries none, and this stays None)
        if self.hel_restriction is not None or other.hel_restriction is not None:
            left = self.hel_restriction or (None,) * self.nchanging
            right = other.hel_restriction or (None,) * other.nchanging
            out.set_hel_restriction(tuple(left) + tuple(right))
            # the trace restriction is per-index too, and concatenates the same
            # way; it only differs from the above for a cross restriction
            if (self.hel_restriction_trace is not None
                    or other.hel_restriction_trace is not None):
                left = self.hel_restriction_trace or (None,) * self.nchanging
                right = other.hel_restriction_trace or (None,) * other.nchanging
                out.set_hel_restriction_trace(tuple(left) + tuple(right))
        return out

    @classmethod
    def identity(cls, nchanging, all_helicity_combinations, dimension):
        """The density matrix a decay averages to over its *full* phase space:
        delta_{hh'} / n.

        Integrating a decay density matrix over the whole solid angle kills the
        off-diagonal (interference) entries by rotational invariance in the
        parent rest frame, and leaves the diagonal flat. So a particle whose
        decay has not been drawn yet contributes exactly this to the production
        contraction -- which is what lets the accept/reject be done one particle
        at a time (see doc/madspin_sequential_plan.md).

        Built through the normal constructor, so it shares the cached helicity
        map with the real density matrices of the same basis and keeps the
        scalar_multiplication fast path available.
        """
        array = np.zeros(dimension * (dimension + 1) // 2, dtype=np.complex64)
        # diagonal entries in the packed upper-triangular storage
        diag = [i * (2 * dimension - i + 1) // 2 for i in range(dimension)]
        array[diag] = 1.0 / dimension
        return cls(array, nchanging, all_helicity_combinations, dimension)

    def normalized(self):
        """Same matrix divided by its trace (Dhat = D / Tr D), i.e. on the same
        footing as ``identity``. Returns self unchanged if the trace vanishes.

        Cached: a density matrix does not change after construction, and the
        sequential accept/reject normalises each accepted slot once per later
        slot -- O(n^2) times for n decaying particles otherwise."""
        cached = getattr(self, '_normalized_cache', None)
        if cached is not None:
            return cached
        tr = self.trace()
        if tr == 0:
            self._normalized_cache = self
            return self
        out = DensityMatrix.from_components(
            self.helicities,
            self.values / tr,
            self.nchanging,
            self.all_helicity_combinations,
            self.dimension,
            basis_id=self._basis_id,
        )
        out.hel_restriction = self.hel_restriction
        out.hel_restriction_trace = self.hel_restriction_trace
        self._normalized_cache = out
        return out

    def trace(self, hel_restriction=None):
        """
        Order-independent trace.

        With a helicity restriction in force (production polarisation) this is
        the *restricted* trace, sum_{h in allowed} rho(h,h): that is the
        normalisation the polarised production cross-section actually uses, and
        keeping it consistent with ``scalar_multiplication`` is what leaves the
        accept/reject weight averaging to 1/n exactly as in the unrestricted
        case.
        """
        restriction = self._trace_restriction()
        if hel_restriction is not None:
            restriction = DensityMatrix._combine_restrictions(
                restriction, DensityMatrix.normalize_hel_restriction(hel_restriction))
        if restriction is not None:
            return np.sum(self.values[self._restriction_rows(restriction)[2]])
        # Unrestricted: sum the diagonal entries by position. See
        # _get_diag_positions_cached: at these sizes numpy's dispatch dwarfs
        # the addition itself.
        values = self.values
        positions = self._get_diag_positions_cached()
        if not positions:
            return np.complex64(0)
        total = values[positions[0]]
        for i in positions[1:]:
            total = total + values[i]
        return total


    def print_full_matrix(self, precision=6):

        n = self.dimension
        M = np.empty((n, n), dtype=np.complex64)

        idx = 0
        for i in range(n):
            for j in range(i, n):
                v = self.values[idx]
                M[i, j] = v
                M[j, i] = np.conjugate(v)
                idx += 1

        fmt = f"{{: .{precision}e}}"

        print("\nFull density matrix:\n")
        for i in range(n):
            print(" ".join(
                f"({fmt.format(M[i,j].real)},{fmt.format(M[i,j].imag)})"
                for j in range(n)
            ))

        return M
