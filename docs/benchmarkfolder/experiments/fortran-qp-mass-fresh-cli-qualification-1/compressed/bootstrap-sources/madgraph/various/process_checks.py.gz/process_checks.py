################################################################################
#
# Copyright (c) 2009 The MadGraph7 Development team and Contributors
#
# This file is a part of the MadGraph7 project, an application which 
# automatically generates Feynman diagrams and matrix elements for arbitrary
# high-energy processes in the Standard Model and beyond.
#
# It is subject to the MadGraph7 license which should accompany this 
# distribution.
#
# For more information, visit madgraph.phys.ucl.ac.be and amcatnlo.web.cern.ch
#
################################################################################
"""Several different checks for processes (and hence models):
permutation tests, gauge invariance tests, lorentz invariance
tests. Also class for evaluation of Python matrix elements,
MatrixElementEvaluator."""

from __future__ import division

from __future__ import absolute_import
import array
import copy
import fractions
import itertools
import logging
import math
import os
import sys
import re
import shutil
import random
import glob
import re
import subprocess
import time
import datetime
import errno
import pickle
# If psutil becomes standard, the RAM check can be performed with it instead
#import psutil

import aloha
import aloha.aloha_writers as aloha_writers
import aloha.create_aloha as create_aloha

import madgraph.iolibs.export_python as export_python
import madgraph.iolibs.helas_call_writers as helas_call_writers
import madgraph.models.import_ufo as import_ufo
import madgraph.iolibs.save_load_object as save_load_object
import madgraph.iolibs.file_writers as writers

import madgraph.core.base_objects as base_objects
import madgraph.core.color_algebra as color
import madgraph.core.color_amp as color_amp
import madgraph.core.helas_objects as helas_objects
import madgraph.core.diagram_generation as diagram_generation

import contextlib
import madgraph.various.rambo as rambo
import madgraph.various.misc as misc
import madgraph.various.ninjars_install as ninjars_install
import madgraph.various.progressbar as pbar
import madgraph.various.banner as bannermod
import madgraph.various.progressbar as pbar

import madgraph.loop.loop_diagram_generation as loop_diagram_generation
import madgraph.loop.loop_helas_objects as loop_helas_objects
import madgraph.loop.loop_base_objects as loop_base_objects
import madgraph.models.check_param_card as check_param_card

from madgraph.interface.madevent_interface import MadLoopInitializer
from madgraph.interface.common_run_interface import AskforEditCard
from madgraph import MG5DIR, InvalidCmd, MadGraph5Error

from madgraph.iolibs.files import cp

import madgraph.models.model_reader as model_reader
import aloha.template_files.wavefunctions as wavefunctions
from aloha.template_files.wavefunctions import \
     ixxxxx, oxxxxx, vxxxxx, sxxxxx, txxxxx, irxxxx, orxxxx, sfdxxx, vfdxxxx
import io
import io as StringIO
file = io.FileIO


ADDED_GLOBAL = []

temp_dir_prefix = "TMP_CHECK"

pjoin = os.path.join

def clean_added_globals(to_clean):
    for value in list(to_clean):
        del globals()[value]
        to_clean.remove(value)

#===============================================================================
# Fake interface to be instancied when using process_checks from tests instead.
#===============================================================================
class FakeInterface(object):
    """ Just an 'option container' to mimic the interface which is passed to the
    tests. We put in only what is now used from interface by the test:
    cmd.options['fortran_compiler']
    cmd.options['cpp_compiler']
    cmd.options['complex_mass_scheme']
    cmd._mgme_dir"""
    def __init__(self, mgme_dir = "", complex_mass_scheme = False,
                 fortran_compiler = 'gfortran', cpp_compiler = 'g++'):
        self._mgme_dir = mgme_dir
        self.options = {}
        self.options['complex_mass_scheme']=complex_mass_scheme
        self.options['fortran_compiler']=fortran_compiler
        self.options['cpp_compiler']=cpp_compiler

#===============================================================================
# Logger for process_checks
#===============================================================================

logger = logging.getLogger('madgraph.various.process_checks')


# Helper function to boost momentum
def boost_momenta(p, boost_direction=1, beta=0.5):
    """boost the set momenta in the 'boost direction' by the 'beta' 
       factor"""
       
    boost_p = []    
    gamma = 1/ math.sqrt(1 - beta**2)
    for imp in p:
        bosst_p = imp[boost_direction]
        E, px, py, pz = imp
        boost_imp = []
        # Energy:
        boost_imp.append(gamma * E - gamma * beta * bosst_p)
        # PX
        if boost_direction == 1:
            boost_imp.append(-gamma * beta * E + gamma * px)
        else: 
            boost_imp.append(px)
        # PY
        if boost_direction == 2:
            boost_imp.append(-gamma * beta * E + gamma * py)
        else: 
            boost_imp.append(py)    
        # PZ
        if boost_direction == 3:
            boost_imp.append(-gamma * beta * E + gamma * pz)
        else: 
            boost_imp.append(pz) 
        #Add the momenta to the list
        boost_p.append(boost_imp)                   
            
    return boost_p

#===============================================================================
# Helper class MatrixElementEvaluator
#===============================================================================
class MatrixElementEvaluator(object):
    """Class taking care of matrix element evaluation, storing
    relevant quantities for speedup."""

    def __init__(self, model , param_card = None,
                    auth_skipping = False, reuse = True, cmd = FakeInterface()):
        """Initialize object with stored_quantities, helas_writer,
        model, etc.
        auth_skipping = True means that any identical matrix element will be
                        evaluated only once
        reuse = True means that the matrix element corresponding to a
                given process can be reused (turn off if you are using
                different models for the same process)"""
 
        self.cmd = cmd
 
        # Writer for the Python matrix elements
        self.helas_writer = helas_call_writers.PythonUFOHelasCallWriter(model)
    
        # Read a param_card and calculate couplings
        self.full_model = model_reader.ModelReader(model)
        try:
            self.full_model.set_parameters_and_couplings(param_card)
        except MadGraph5Error:
            if isinstance(param_card, (str,file)):
                raise
            logger.warning('param_card present in the event file not compatible.'+
                                                ' We will use the default one.')
            self.full_model.set_parameters_and_couplings()
            
        self.auth_skipping = auth_skipping
        self.reuse = reuse
        self.cmass_scheme = cmd.options['complex_mass_scheme']
        self.store_aloha = []
        self.stored_quantities = {}
        
    #===============================================================================
    # Helper function evaluate_matrix_element
    #===============================================================================
    def evaluate_matrix_element(self, matrix_element, p=None, full_model=None, 
                                gauge_check=False, auth_skipping=None, output='m2',
                                options=None):
        """Calculate the matrix element and evaluate it for a phase space point
           output is either m2, amp, jamp
        """

        if full_model:
            self.full_model = full_model
        process = matrix_element.get('processes')[0]
        model = process.get('model')

        # Build the per-leg flavor index array passed to smatrix, using exactly
        # the convention the Fortran/C++ standalone drivers build into their
        # FLAV_TABLE (e.g. `DATA FLAV_TABLE / 1, 3, 1, 1 /`):
        #   * a merged leg carries the 1-based *position* of its flavor inside
        #     the merged group (e.g. vt is position 3 of {12,14,16}), and
        #   * every other leg carries index 1 -- NOT the physical PDG and NOT
        #     -1.  The unmerged partner of a single-merged-leg FLV vertex is
        #     always flavor index 1 (see FLV_Coupling.get_partner_indices), so
        #     PARTNER(1)=<merged pos> resolves the coupling.
        # The leg 'flavor' tag stores the physical PDG, so convert it here.
        # NB: for the light quarks the PDG (1..4) already equals the position,
        # which is why this used to appear correct and only broke for a single
        # merged lepton/neutrino paired with an unmerged partner, e.g.
        # `w+ vt~ > z ta+` (vt is position 3, the tau must be index 1 -- passing
        # -1 short-circuited the flavor check and returned zero).
        merged = model.get('merged_particles') or {}
        def _flavor_group_pos(leg):
            tag = leg.get('flavor')
            if not tag:
                return 1
            pdg = abs(tag[0])
            for sub_ids in merged.values():
                if pdg in sub_ids:
                    return list(sub_ids).index(pdg) + 1
            return 1
        legs = process.get('legs')
        flavor = [_flavor_group_pos(leg) for leg in legs]

        if "matrix_elements" not in self.stored_quantities:
            self.stored_quantities['matrix_elements'] = []
            matrix_methods = {}

        if self.reuse and "Matrix_%s" % process.shell_string() in globals() and p:
            try:
                if matrix_element not in self.stored_quantities['matrix_elements']:
                    self.stored_quantities['matrix_elements'].append(matrix_element)
                # Evaluate the matrix element for the momenta p
                matrix = eval("Matrix_%s()" % process.shell_string(), globals())
                me_value = matrix.smatrix(p, self.full_model, flavor)
                if output == "m2":
                    return matrix.smatrix(p, self.full_model, flavor), matrix.amp2
                else:
                    m2 = matrix.smatrix(p, self.full_model, flavor)
                return {'m2': m2, output:getattr(matrix, output)}
            except NameError:
                pass

        if (auth_skipping or self.auth_skipping) and matrix_element in \
               self.stored_quantities['matrix_elements']:
            # Exactly the same matrix element has been tested
            logger.info("Skipping %s, " % process.nice_string() + \
                        "identical matrix element already tested" \
                        )
            return None


        self.stored_quantities['matrix_elements'].append(matrix_element)
        # Create an empty color basis, and the list of raw
        # colorize objects (before simplification) associated
        # with amplitude
        if "list_colorize" not in self.stored_quantities:
            self.stored_quantities["list_colorize"] = []
        if "list_color_basis" not in self.stored_quantities:
            self.stored_quantities["list_color_basis"] = []
        if "list_color_matrices" not in self.stored_quantities:
            self.stored_quantities["list_color_matrices"] = []        

        col_basis = color_amp.ColorBasis()
        new_amp = matrix_element.get_base_amplitude()
        matrix_element.set('base_amplitude', new_amp)
        colorize_obj = col_basis.create_color_dict_list(new_amp)

        try:
            # If the color configuration of the ME has
            # already been considered before, recycle
            # the information
            col_index = self.stored_quantities["list_colorize"].index(colorize_obj)
        except ValueError:
            # If not, create color basis and color
            # matrix accordingly
            self.stored_quantities['list_colorize'].append(colorize_obj)
            col_basis.build()
            self.stored_quantities['list_color_basis'].append(col_basis)
            col_matrix = color_amp.ColorMatrix(col_basis)
            self.stored_quantities['list_color_matrices'].append(col_matrix)
            col_index = -1

        # Set the color for the matrix element
        matrix_element.set('color_basis',
                           self.stored_quantities['list_color_basis'][col_index])
        matrix_element.set('color_matrix',
                           self.stored_quantities['list_color_matrices'][col_index])

        # Create the needed aloha routines
        if "used_lorentz" not in self.stored_quantities:
            self.stored_quantities["used_lorentz"] = []

        me_used_lorentz = set(matrix_element.get_used_lorentz())
        me_used_lorentz = [lorentz for lorentz in me_used_lorentz \
                               if lorentz not in self.store_aloha]

        aloha_model = create_aloha.AbstractALOHAModel(model.get('modelpath'))
        aloha_model.add_Lorentz_object(model.get('lorentz'))
        aloha_model.compute_subset(me_used_lorentz)

        # Write out the routines in Python
        aloha_routines = []
        for routine in aloha_model.values():
            aloha_routines.append(routine.write(output_dir = None, 
                                                mode='mg5',
                                                language = 'Python'))
        for routine in aloha_model.external_routines:
            for path in aloha_model.locate_external(routine, 'Python'):
                aloha_routines.append(open(path).read())

        # Define the routines to be available globally
        previous_globals = list(globals().keys())
        for routine in aloha_routines:
            exec(routine, globals())
        for key in globals().keys():
            if key not in previous_globals:
                ADDED_GLOBAL.append(key)

        # Add the defined Aloha routines to used_lorentz
        self.store_aloha.extend(me_used_lorentz)
        # Export the matrix element to Python calls
        exporter = export_python.ProcessExporterPython(matrix_element,
                                                       self.helas_writer)
        try:
            matrix_methods = exporter.get_python_matrix_methods(\
                gauge_check=gauge_check)
#            print "I got matrix_methods=",str(matrix_methods.items()[0][1])
        except helas_call_writers.HelasWriterError as error:
            logger.info(error)
            return None
        # If one wants to output the python code generated for the computation
        # of these matrix elements, it is possible to run the following cmd
        if False:
            fsock = open('output%s.py' % process.shell_string(), 'w')
            text = """
import madgraph
import madgraph.models.model_reader as model_reader
import aloha.template_files.wavefunctions as wavefunctions
from aloha.template_files.wavefunctions import \
     ixxxxx, oxxxxx, vxxxxx, sxxxxx
import cmath


import madgraph.interface.master_interface as Cmd
"""
            fsock.write(text)
            for routine in aloha_routines:
                fsock.write(routine)
            fsock.write(matrix_methods[process.shell_string()])
            if not p:
                p, w_rambo = self.get_momenta(process, options)
            text= """
if __name__ == '__main__':
    
     interface = Cmd.MasterCmd()
     interface.exec_cmd('import model sm')  # or whatever model you need
    
     model = interface._curr_model
     runner = Matrix_%s()
     p =  %s
     flavor = %s
     print(flavor, runner.smatrix(p, model, flavor))
    """ % (process.shell_string(), str(p), str(flavor))
            fsock.write(text)
            fsock.close()
        if self.reuse:
            # Define the routines globally so they can be reused in future calls
            exec(matrix_methods[process.shell_string()], globals())	    
            ADDED_GLOBAL.append('Matrix_%s'  % process.shell_string())
            exec_ns = globals()
        else:
            # Define the routines in a local namespace to avoid overwriting
            # globally cached matrices (e.g. from the reuse evaluator) that
            # share the same shell_string but were generated for a different
            # model (merged vs unmerged).
            exec_ns = dict(globals())
            exec(matrix_methods[process.shell_string()], exec_ns)
        # Generate phase space point to use
        if not p:
            p, w_rambo = self.get_momenta(process, options)
        # Evaluate the matrix element for the momenta p
        data = exec_ns['Matrix_%s' % process.shell_string()]()
        if output == "m2":
            return data.smatrix(p, self.full_model, flavor), data.amp2
        else:
            m2 = data.smatrix(p, self.full_model, flavor)
            return {'m2': m2, output:getattr(data, output)}
    
    @staticmethod
    def pass_isolation_cuts(pmoms, ptcut=50.0, drcut=0.5):
        """ Check whether the specified kinematic point passes isolation cuts
        """

        def Pt(pmom):
            """ Computes the pt of a 4-momentum"""
            return math.sqrt(pmom[1]**2+pmom[2]**2)

        def DeltaR(p1,p2):
            """ Computes the DeltaR between two 4-momenta"""
            # First compute pseudo-rapidities
            p1_vec=math.sqrt(p1[1]**2+p1[2]**2+p1[3]**2)
            p2_vec=math.sqrt(p2[1]**2+p2[2]**2+p2[3]**2)    
            eta1=0.5*math.log((p1_vec+p1[3])/(p1_vec-p1[3]))
            eta2=0.5*math.log((p2_vec+p2[3])/(p2_vec-p2[3]))
            # Then azimutal angle phi
            phi1=math.atan2(p1[2],p1[1])
            phi2=math.atan2(p2[2],p2[1])
            dphi=abs(phi2-phi1)
            # Take the wraparound factor into account
            dphi=abs(abs(dphi-math.pi)-math.pi)
            # Now return deltaR
            return math.sqrt(dphi**2+(eta2-eta1)**2)

        for i, pmom in enumerate(pmoms[2:]):
            # Pt > 50 GeV
            if Pt(pmom)<ptcut:
                return False
            # Delta_R ij > 0.5
            for pmom2 in pmoms[3+i:]:
                if DeltaR(pmom,pmom2)<drcut:
                    return False
        return True
    
    #===============================================================================
    # Helper function get_momenta
    #===============================================================================
    def get_momenta(self, process, options=None, special_mass=None):
        """Get a point in phase space for the external states in the given
        process, with the CM energy given. The incoming particles are
        assumed to be oriented along the z axis, with particle 1 along the
        positive z axis.
        For the CMS check, one must be able to chose the mass of the special
        resonance particle with id = -1, and the special_mass option allows
        to specify it."""

        if not options:
            energy=1000
            events=None
        else:
            energy = options['energy']
            events = options['events']
            to_skip = options['skip_evt']
            
        if not (isinstance(process, base_objects.Process) and \
                isinstance(energy, (float,int))):
            raise rambo.RAMBOError("Not correct type for arguments to get_momenta")


        sorted_legs = sorted(process.get('legs'), key=lambda l: l.get('number')) 

        # If an events file is given use it for getting the momentum
        if events:
            ids = [l.get('id') for l in sorted_legs]
            import MadSpin.decay as madspin
            if not hasattr(self, 'event_file') or self.event_file.inputfile.closed:
                print( "reset")
                fsock = open(events)
                self.event_file = madspin.Event(fsock)

            skip = 0
            while self.event_file.get_next_event() != 'no_event':
                event = self.event_file.particle
                #check if the event is compatible
                event_ids = [p['pid'] for p in event.values()]
                if event_ids == ids:
                    skip += 1
                    if skip > to_skip:
                        break
            else:
                raise MadGraph5Error('No compatible events for %s' % ids)
            p = []
            for part in event.values():
                m = part['momentum']
                p.append([m.E, m.px, m.py, m.pz])
            fsock.close()
            return p, 1

        nincoming = len([leg for leg in sorted_legs if leg.get('state') == False])
        nfinal = len(sorted_legs) - nincoming

        # Find masses of particles
        mass = []
        for l in sorted_legs:
            pdg = l.get('id')
            if pdg != 0 and pdg:
                if pdg in self.full_model.merged_particles:
                    pdg =  self.full_model.merged_particles[pdg][0] 
                mass_string = self.full_model.get_particle(pdg).get('mass')        
                mass.append(self.full_model.get('parameter_dict')[mass_string].real)
            else:
                if isinstance(special_mass, float):
                    mass.append(special_mass)
                else:
                    raise Exception("A 'special_mass' option must be specified"+\
                 " in get_momenta when a leg with id=-10 is present (for CMS check)")
        #mass = [math.sqrt(m.real) for m in mass]



        # Make sure energy is large enough for incoming and outgoing particles,
#        # Keep the special_mass case separate to be sure that nothing interferes
#        # with the regular usage of get_momenta.
#        if not (any(l.get('id')==0 for l in sorted_legs) and \
#                                               isinstance(special_mass, float)):
        energy = max(energy, sum(mass[:nincoming])*1.2,sum(mass[nincoming:])*1.2)
#        else:
#            incoming_mass = sum([mass[i] for i, leg in enumerate(sorted_legs) \
#                             if leg.get('state') == False and leg.get('id')!=0])
#            outcoming_mass = sum([mass[i] for i, leg in enumerate(sorted_legs) \
#                             if leg.get('state') == True and leg.get('id')!=0])
#            energy = max(energy, incoming_mass*1.2, outcoming_mass*1.2)

        if nfinal == 1:
            p = []
            energy = mass[-1]
            p.append([energy/2,0,0,energy/2])
            p.append([energy/2,0,0,-energy/2])
            p.append([mass[-1],0,0,0])
            return p, 1.0

        e2 = energy**2
        m1 = mass[0]
        p = []

        masses = rambo.FortranList(nfinal)
        for i in range(nfinal):
            masses[i+1] = mass[nincoming + i]

        if nincoming == 1:
            # Momenta for the incoming particle
            p.append([abs(m1), 0., 0., 0.])
            p_rambo, w_rambo = rambo.RAMBO(nfinal, abs(m1), masses)
            # Reorder momenta from px,py,pz,E to E,px,py,pz scheme
            for i in range(1, nfinal+1):
                momi = [p_rambo[(4,i)], p_rambo[(1,i)],
                        p_rambo[(2,i)], p_rambo[(3,i)]]
                p.append(momi)

            return p, w_rambo

        if nincoming != 2:
            raise rambo.RAMBOError('Need 1 or 2 incoming particles')

        if nfinal == 1:
            energy = masses[1]
            if masses[1] == 0.0:
                raise rambo.RAMBOError('The kinematic 2 > 1 with the final'+\
                                          ' state particle massless is invalid')

        e2 = energy**2
        m2 = mass[1]

        mom = math.sqrt((e2**2 - 2*e2*m1**2 + m1**4 - 2*e2*m2**2 - \
                  2*m1**2*m2**2 + m2**4) / (4*e2))
        e1 = math.sqrt(mom**2+m1**2)
        e2 = math.sqrt(mom**2+m2**2)
        # Set momenta for incoming particles
        p.append([e1, 0., 0., mom])
        p.append([e2, 0., 0., -mom])

        if nfinal == 1:
            p.append([energy, 0., 0., 0.])
            return p, 1.

        p_rambo, w_rambo = rambo.RAMBO(nfinal, energy, masses)

        # Reorder momenta from px,py,pz,E to E,px,py,pz scheme
        for i in range(1, nfinal+1):
            momi = [p_rambo[(4,i)], p_rambo[(1,i)],
                    p_rambo[(2,i)], p_rambo[(3,i)]]
            p.append(momi)

        return p, w_rambo

#===============================================================================
# Helper class LoopMatrixElementEvaluator
#===============================================================================

class LoopMatrixElementEvaluator(MatrixElementEvaluator):
    """Class taking care of matrix element evaluation for loop processes."""

    def __init__(self,cuttools_dir=None, output_path=None, tir_dir={}, 
                                            cmd=FakeInterface(),*args,**kwargs):
        """Allow for initializing the MG5 root where the temporary fortran
        output for checks is placed."""
        
        super(LoopMatrixElementEvaluator,self).__init__(*args,cmd=cmd,**kwargs)

        self.mg_root=self.cmd._mgme_dir
        # If no specific output path is specified, then write in MG5 root directory
        if output_path is None:
            self.output_path = self.cmd._mgme_dir
        else:
            self.output_path = output_path
            
        self.cuttools_dir=cuttools_dir
        self.tir_dir=tir_dir
        self.loop_optimized_output = cmd.options['loop_optimized_output']
        # Set proliferate to true if you want to keep the produced directories
        # and eventually reuse them if possible
        self.proliferate=True
        
    #===============================================================================
    # Helper function evaluate_matrix_element for loops
    #===============================================================================
    def evaluate_matrix_element(self, matrix_element, p=None, options=None,
                             gauge_check=False, auth_skipping=None, output='m2', 
                                                  PS_name = None, MLOptions={}):
        """Calculate the matrix element and evaluate it for a phase space point
           Output can only be 'm2. The 'jamp' and 'amp' returned values are just
           empty lists at this point.
           If PS_name is not none the written out PS.input will be saved in 
           the file PS.input_<PS_name> as well."""

        process = matrix_element.get('processes')[0]
        model = process.get('model')
        
        if options and 'split_orders' in list(options.keys()):
            split_orders = options['split_orders']
        else:
            split_orders = -1
        
        if "loop_matrix_elements" not in self.stored_quantities:
            self.stored_quantities['loop_matrix_elements'] = []

        if (auth_skipping or self.auth_skipping) and matrix_element in \
                [el[0] for el in self.stored_quantities['loop_matrix_elements']]:
            # Exactly the same matrix element has been tested
            logger.info("Skipping %s, " % process.nice_string() + \
                        "identical matrix element already tested" )
            return None

        # Generate phase space point to use
        if not p:
            p, w_rambo = self.get_momenta(process, options=options)
        
        if matrix_element in [el[0] for el in \
                                self.stored_quantities['loop_matrix_elements']]:  
            export_dir=self.stored_quantities['loop_matrix_elements'][\
                [el[0] for el in self.stored_quantities['loop_matrix_elements']\
                 ].index(matrix_element)][1]
            logger.debug("Reusing generated output %s"%str(export_dir))
        else:        
            export_dir=pjoin(self.output_path,temp_dir_prefix)
            if os.path.isdir(export_dir):
                if not self.proliferate:
                    raise InvalidCmd("The directory %s already exist. Please remove it."%str(export_dir))
                else:
                    id=1
                    while os.path.isdir(pjoin(self.output_path,\
                                        '%s_%i'%(temp_dir_prefix,id))):
                        id+=1
                    export_dir=pjoin(self.output_path,'%s_%i'%(temp_dir_prefix,id))
            
            if self.proliferate:
                self.stored_quantities['loop_matrix_elements'].append(\
                                                    (matrix_element,export_dir))

            # I do the import here because there is some cyclic import of export_v4
            # otherwise
            import madgraph.loop.loop_exporters as loop_exporters
            if self.loop_optimized_output:
                exporter_class=loop_exporters.LoopProcessOptimizedExporterFortranSA
            else:
                exporter_class=loop_exporters.LoopProcessExporterFortranSA
            
            MLoptions = {'clean': True, 
                       'complex_mass': self.cmass_scheme,
                       'export_format':'madloop', 
                       'mp':True,
                       'SubProc_prefix':'P',
                       'compute_color_flows': not process.get('has_born'),
              'loop_dir': pjoin(self.mg_root,'Template','loop_material'),
                       'cuttools_dir': self.cuttools_dir,
                       'fortran_compiler': self.cmd.options['fortran_compiler'],
                       'output_dependencies': self.cmd.options['output_dependencies']}

            MLoptions.update(self.tir_dir)
            
            FortranExporter = exporter_class(export_dir, MLoptions)
            FortranModel = helas_call_writers.FortranUFOHelasCallWriter(model)
            FortranExporter.copy_template(model)
            FortranExporter.generate_subprocess_directory(matrix_element, FortranModel)
            wanted_lorentz = misc.make_unique(matrix_element.get_used_lorentz())
            wanted_couplings = misc.make_unique([c for l in matrix_element.get_used_couplings() \
                                                                    for c in l])
            FortranExporter.convert_model(model,wanted_lorentz,wanted_couplings)
            FortranExporter.finalize(matrix_element,"",self.cmd.options, ['nojpeg'])

        MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                                                      split_orders=split_orders)

        self.fix_MadLoopParamCard(pjoin(export_dir,'Cards'),
           mp = gauge_check and self.loop_optimized_output, MLOptions=MLOptions)
        
        if gauge_check:
            file_path, orig_file_content, new_file_content = \
              self.setup_ward_check(pjoin(export_dir,'SubProcesses'), 
                                       ['helas_calls_ampb_1.f','loop_matrix.f'])
            file = open(file_path,'w')
            file.write(new_file_content)
            file.close()
            if self.loop_optimized_output:
                mp_file_path, mp_orig_file_content, mp_new_file_content = \
                  self.setup_ward_check(pjoin(export_dir,'SubProcesses'), 
                  ['mp_helas_calls_ampb_1.f','mp_compute_loop_coefs.f'],mp=True)
                mp_file = open(mp_file_path,'w')
                mp_file.write(mp_new_file_content)
                mp_file.close()
    
        # Evaluate the matrix element for the momenta p
        finite_m2 = self.get_me_value(process.shell_string_v4(), 0,\
                          export_dir, p, PS_name = PS_name, verbose=False)[0][0]

        # Restore the original loop_matrix.f code so that it could be reused
        if gauge_check:
            file = open(file_path,'w')
            file.write(orig_file_content)
            file.close()
            if self.loop_optimized_output:
                mp_file = open(mp_file_path,'w')
                mp_file.write(mp_orig_file_content)
                mp_file.close()
        
        # Now erase the output directory
        if not self.proliferate:
            shutil.rmtree(export_dir)
        
        if output == "m2": 
            # We do not provide details (i.e. amps and Jamps) of the computed 
            # amplitudes, hence the []
            return finite_m2, []
        else:
            return {'m2': finite_m2, output:[]}

    def fix_MadLoopParamCard(self,dir_name, mp=False, loop_filter=False,
                                 DoubleCheckHelicityFilter=False, MLOptions={}):
        """ Set parameters in MadLoopParams.dat suited for these checks.MP
            stands for multiple precision and can either be a bool or an integer
            to specify the mode."""

        # Instantiate a MadLoopParam card
        file = open(pjoin(dir_name,'MadLoopParams.dat'), 'r')
        MLCard = bannermod.MadLoopParam(file)

        if isinstance(mp,bool):
            mode = 4 if mp else 1
        else:
            mode = mp

        for key, value in MLOptions.items():
            if key == "MLReductionLib":
                if isinstance(value, int):
                    ml_reds = str(value)
                if isinstance(value,list):
                    if len(value)==0:
                        ml_reds = '1'
                    else:
                        ml_reds="|".join([str(vl) for vl in value])
                elif isinstance(value, str):
                    ml_reds = value
                elif isinstance(value, int):
                    ml_reds = str(value)
                else:
                    raise MadGraph5Error('The argument %s '%str(value)+\
                      ' in fix_MadLoopParamCard must be a string, integer'+\
                      ' or a list.')
                MLCard.set("MLReductionLib",ml_reds)      
            elif key == 'ImprovePS':
                MLCard.set('ImprovePSPoint',2 if value else -1)
            elif key == 'ForceMP':
                mode = 4
            elif key in MLCard:
                MLCard.set(key,value)
            else:
                raise Exception('The MadLoop options %s specified in function'%key+\
                  ' fix_MadLoopParamCard does not correspond to an option defined'+\
                  ' MadLoop nor is it specially handled in this function.')
        if not mode is None:
            MLCard.set('CTModeRun',mode)
            MLCard.set('CTModeInit',mode)
        MLCard.set('UseLoopFilter',loop_filter)
        MLCard.set('DoubleCheckHelicityFilter',DoubleCheckHelicityFilter)
        
        MLCard.write(pjoin(dir_name,os.pardir,'SubProcesses','MadLoopParams.dat'))

    @classmethod
    def get_me_value(cls, proc, proc_id, working_dir, PSpoint=[], PS_name = None,
                          verbose=True, format='tuple', skip_compilation=False):
        """Compile and run ./check, then parse the output and return the result
        for process with id = proc_id and PSpoint if specified.
        If PS_name is not none the written out PS.input will be saved in 
        the file PS.input_<PS_name> as well"""  
        if verbose:
            sys.stdout.write('.')
            sys.stdout.flush()
         
        shell_name = None
        directories = misc.glob('P%i_*' % proc_id, pjoin(working_dir, 'SubProcesses'))
        if directories and os.path.isdir(directories[0]):
            shell_name = os.path.basename(directories[0])

        # If directory doesn't exist, skip and return 0
        if not shell_name:
            logging.info("Directory hasn't been created for process %s: %s", proc, directories)
            return ((0.0, 0.0, 0.0, 0.0, 0), [])

        if verbose: logging.debug("Working on process %s in dir %s" % (proc, shell_name))
        
        dir_name = pjoin(working_dir, 'SubProcesses', shell_name)
        if not skip_compilation:
            # Make sure to recreate the executable and modified sources
            if os.path.isfile(pjoin(dir_name,'check')):
                os.remove(pjoin(dir_name,'check'))
                try:
                    os.remove(pjoin(dir_name,'check_sa.o'))
                    os.remove(pjoin(dir_name,'loop_matrix.o'))
                except OSError:
                    pass
            # Now run make
            devnull = open(os.devnull, 'w')
            retcode = subprocess.call(['make','check'],
                                       cwd=dir_name, stdout=devnull, stderr=devnull)
            devnull.close()
                         
            if retcode != 0:
                logging.info("Error while executing make in %s" % shell_name)
                return ((0.0, 0.0, 0.0, 0.0, 0), [])

        # If a PS point is specified, write out the corresponding PS.input
        if PSpoint:
            misc.write_PS_input(pjoin(dir_name, 'PS.input'),PSpoint)
            # Also save the PS point used in PS.input_<PS_name> if the user
            # wanted so. It is used for the lorentz check. 
            if not PS_name is None:
                misc.write_PS_input(pjoin(dir_name, \
                                                 'PS.input_%s'%PS_name),PSpoint)        
        # Run ./check
        try:
            result_path = pjoin(dir_name, 'result.dat')
            if os.path.exists(result_path):
                os.remove(result_path)
            check = subprocess.Popen('./check',
                        cwd=dir_name,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output, _ = check.communicate()
            if check.returncode != 0:
                raise MadGraph5Error("./check failed in %s (exit %s): %s" %
                    (dir_name, check.returncode, output.decode(errors='replace')[-2000:]))
            if not os.path.isfile(result_path):
                raise MadGraph5Error("./check did not produce a fresh result.dat in %s" % dir_name)
            with open(result_path) as result:
                return cls.parse_check_output(result, format=format)
        except OSError as error:
            raise MadGraph5Error("Could not execute ./check in %s: %s" %
                                 (dir_name, error)) from error

    @classmethod
    def parse_check_output(cls,output,format='tuple'):
        """Parse the output string and return a pair where first four values are 
        the finite, born, single and double pole of the ME and the fourth is the
        GeV exponent and the second value is a list of 4 momenta for all particles 
        involved. Return the answer in two possible formats, 'tuple' or 'dict'."""

        res_dict = {'res_p':[],
                    'born':0.0,
                    'finite':0.0,
                    '1eps':0.0,
                    '2eps':0.0,
                    'gev_pow':0,
                    'export_format':'Default',
                    'accuracy':0.0,
                    'return_code':0,
                    'Split_Orders_Names':[],
                    'Loop_SO_Results':[],
                    'Born_SO_Results':[],
                    'Born_kept':[],
                    'Loop_kept':[],
                    'RMatrix': []
                    }
        res_p = []
        
        # output is supposed to be a file, if it is its content directly then
        # I change it to be the list of line.
        if isinstance(output,(file,io.TextIOWrapper)) or isinstance(output,list):
            text=output
        elif isinstance(output,(str)):
            text=output.split('\n')
        elif isinstance(output, bytes):
            text=output.decode(errors='ignore').split('\n')
        else:
            raise MadGraph5Error('Type for argument output not supported in'+\
                                                          ' parse_check_output: %s' % type(output))
        for line in text:
            splitline=line.split()
            if len(splitline)==0:
                continue
            elif splitline[0]=='PS':
                res_p.append([float(s) for s in splitline[1:]])
            elif splitline[0]=='ASO2PI':
                res_dict['alphaS_over_2pi']=float(splitline[1])
            elif splitline[0]=='BORN':
                res_dict['born']=float(splitline[1])
            elif splitline[0]=='FIN':
                res_dict['finite']=float(splitline[1])
            elif splitline[0]=='1EPS':
                res_dict['1eps']=float(splitline[1])
            elif splitline[0]=='2EPS':
                res_dict['2eps']=float(splitline[1])
            elif splitline[0]=='EXP':
                res_dict['gev_pow']=int(splitline[1])
            elif splitline[0]=='Export_Format':
                res_dict['export_format']=splitline[1]
            elif splitline[0]=='ACC':
                res_dict['accuracy']=float(splitline[1])
            elif splitline[0]=='RETCODE':
                res_dict['return_code']=int(splitline[1])
            elif splitline[0]=='Split_Orders_Names':
                res_dict['Split_Orders_Names']=splitline[1:]
            elif splitline[0] in ['Born_kept', 'Loop_kept']:
                res_dict[splitline[0]] = [kept=='T' for kept in splitline[1:]]
            elif splitline[0] in ['Loop_SO_Results', 'Born_SO_Results']:
                # The value for this key of this dictionary is a list of elements
                # with format ([],{}) where the first list specifies the split
                # orders to which the dictionary in the second position corresponds 
                # to.
                res_dict[splitline[0]].append(\
                                         ([int(el) for el in splitline[1:]],{}))
            elif splitline[0]=='SO_Loop':
                res_dict['Loop_SO_Results'][-1][1][splitline[1]]=\
                                                             float(splitline[2])
            elif splitline[0]=='SO_Born':
                res_dict['Born_SO_Results'][-1][1][splitline[1]]=\
                                                             float(splitline[2])
            elif splitline[0]=='RHO':
                res_dict['RMatrix'] = []
                for elem in splitline[1:]:
                    aux = elem.strip('()').split(',')
                    res_dict['RMatrix'].append(float(aux[0]) + float(aux[1])*1j)
        
        res_dict['res_p'] = res_p

        if format=='tuple':
            return ((res_dict['finite'],res_dict['born'],res_dict['1eps'],
                       res_dict['2eps'],res_dict['gev_pow']), res_dict['res_p'])
        else:
            return res_dict
    
    @staticmethod
    def apply_log_tweak(proc_path, mode):
        """ Changes the file model_functions.f in the SOURCE of the process output
        so as to change how logarithms are analytically continued and see how
        it impacts the CMS check."""
        valid_modes = ['default','recompile']
        if not (mode in valid_modes or (isinstance(mode, list) and
                len(mode)==2 and all(m in ['logp','logm','log'] for m in mode))):
            raise MadGraph5Error("Mode '%s' not reckonized"%mode+
                                                " in function apply_log_tweak.")
        
        model_path = pjoin(proc_path,'Source','MODEL')
        directories = misc.glob('P0_*', pjoin(proc_path,'SubProcesses'))
        if directories and os.path.isdir(directories[0]):
            exe_path = directories[0]
        else:
            raise MadGraph5Error('Could not find a process executable '+\
                                                      'directory in %s'%proc_dir)
        bu_path = pjoin(model_path, 'model_functions.f__backUp__')
        
        if mode=='default':
            # Restore the default source file model_function.f
            if not os.path.isfile(bu_path):
                raise MadGraph5Error('Back up file %s could not be found.'%bu_path)
            shutil.move(bu_path, pjoin(model_path, 'model_functions.f'))
            return

        if mode=='recompile':
            try:
                os.remove(pjoin(model_path,'model_functions.o'))
                os.remove(pjoin(proc_path,'lib','libmodel.a'))
            except:
                pass    
            misc.compile(cwd=model_path)
            # Remove the executable to insure proper recompilation
            try:
                os.remove(pjoin(exe_path,'check'))
            except:
                pass
            misc.compile(arg=['check'], cwd=exe_path)
            return
        
        if mode[0]==mode[1]:
            return
        
        # Now change the logs
        mp_prefix = 'MP_'
        target_line = 'FUNCTION %%sREG%s(ARG)'%mode[0].lower()

        # Make sure to create a backup
        if not os.path.isfile(bu_path):
            shutil.copy(pjoin(model_path, 'model_functions.f'), bu_path)            
        model_functions = open(pjoin(model_path,'model_functions.f'),'r')
        
        new_model_functions = []
        has_replaced        = False
        just_replaced       = False
        find_one_replacement= False
        mp_mode             = None
        suffix = {'log':'','logp':r'\s*\+\s*TWOPII','logm':r'\s*\-\s*TWOPII'}
        replace_regex=r'^\s*%%sREG%s\s*=\s*LOG\(ARG\)%s'%(mode[0],suffix[mode[0]])
        for line in model_functions:
            # Make sure to skip split lines after the replacement
            if just_replaced:
                if not re.match(r'\s{6}', line):
                    continue
                else:
                    just_replaced = False
            if mp_mode is None:
                # We are looking for the start of the function
                new_model_functions.append(line)
                if (target_line%mp_prefix).lower() in line.lower():
                    mp_mode       = mp_prefix
                elif (target_line%'').lower() in line.lower():
                    mp_mode       = ''
            else:
                # Now apply the substitution
                if not has_replaced and re.match(replace_regex%mp_mode,line,
                                                                 re.IGNORECASE):
                    # Apply the replacement
                    if mode[0]=='log':
                        if mp_mode=='':
                            new_line =\
"""      if(dble(arg).lt.0.0d0.and.dimag(arg).gt.0.0d0)then
        reg%s=log(arg) %s TWOPII
      else
        reg%s=log(arg)
      endif\n"""%(mode[0],'+' if mode[1]=='logp' else '-',mode[0])
                        else:
                            new_line =\
"""      if(real(arg,kind=16).lt.0.0e0_16.and.imagpart(arg).lt.0.0e0_16)then
        mp_reg%s=log(arg) %s TWOPII
      else
        mp_reg%s=log(arg)
      endif\n"""%(mode[0],'+' if mode[1]=='logp' else '-',mode[0])
                    else:
                        new_line = ' '*6+"%sreg%s=log(arg) %s\n"%(mp_mode,mode[0],
      ('' if mode[1]=='log' else ('+TWOPII' if mode[1]=='logp' else '-TWOPII')))
                    new_model_functions.append(new_line)
                    just_replaced = True
                    has_replaced  = True
                    find_one_replacement = True
                else:
                    new_model_functions.append(line)
                    if re.match(r'^\s*END\s*$',line,re.IGNORECASE):
                        mp_mode      = None
                        has_replaced = False
        
        if not find_one_replacement:
            logger.warning('No replacement was found/performed for token '+
                                                  "'%s->%s'."%(mode[0],mode[1]))
        else:
            open(pjoin(model_path,'model_functions.f'),'w').\
                                             write(''.join(new_model_functions))
        return          
                
    def setup_ward_check(self, working_dir, file_names, mp = False):
        """ Modify loop_matrix.f so to have one external massless gauge boson
        polarization vector turned into its momentum. It is not a pretty and 
        flexible solution but it works for this particular case."""
        
        shell_name = None
        directories = misc.glob('P0_*', working_dir)
        if directories and os.path.isdir(directories[0]):
            shell_name = os.path.basename(directories[0])
        
        dir_name = pjoin(working_dir, shell_name)
        
        # Look, in order, for all the possible file names provided.
        ind=0
        while ind<len(file_names) and not os.path.isfile(pjoin(dir_name,
                                                              file_names[ind])):
            ind += 1
        if ind==len(file_names):
            raise Exception("No helas calls output file found.")
        
        helas_file_name=pjoin(dir_name,file_names[ind])
        file = open(pjoin(dir_name,helas_file_name), 'r')
        
        helas_calls_out=""
        original_file=""
        gaugeVectorRegExp=re.compile(\
         r"CALL (MP\_)?VXXXXX\(P\(0,(?P<p_id>\d+)\),((D)?CMPLX\()?ZERO((,KIND\=16)?\))?,"+
         r"NHEL\(\d+\),[\+\-]1\,W\((?P<wf_id>\d+(,H)?)\)\)")
        foundGauge=False
        # Now we modify the first massless gauge vector wavefunction
        for line in file:
            helas_calls_out+=line
            original_file+=line
            if line.find("INCLUDE 'coupl.inc'") != -1 or \
                             line.find("INCLUDE 'mp_coupl_same_name.inc'") !=-1:
                helas_calls_out+="      INTEGER WARDINT\n"
            if not foundGauge:
                res=gaugeVectorRegExp.search(line)
                if res!=None:
                    foundGauge=True
                    helas_calls_out+="      DO WARDINT=1,4\n"
                    helas_calls_out+="        W(WARDINT+4,"+res.group('wf_id')+")="
                    if not mp:
                        helas_calls_out+=\
                            "DCMPLX(P(WARDINT-1,"+res.group('p_id')+"),0.0D0)\n"
                    else:
                        helas_calls_out+="CMPLX(P(WARDINT-1,"+\
                                       res.group('p_id')+"),0.0E0_16,KIND=16)\n"
                    helas_calls_out+="      ENDDO\n"
        file.close()
        
        return pjoin(dir_name,helas_file_name), original_file, helas_calls_out

#===============================================================================
# Helper class LoopMatrixElementEvaluator
#===============================================================================
class LoopMatrixElementTimer(LoopMatrixElementEvaluator):
    """Class taking care of matrix element evaluation and running timing for 
       loop processes."""

    def __init__(self, *args, **kwargs):
        """ Same as the mother for now """
        LoopMatrixElementEvaluator.__init__(self,*args, **kwargs)
    
    @classmethod
    def get_MadLoop_Params(cls,MLCardPath):
        """ Return a dictionary of the parameter of the MadLoopParamCard.
        The key is the name of the parameter and the value is the corresponding
        string read from the card."""
        
        return bannermod.MadLoopParam(MLCardPath)


    @classmethod
    def set_MadLoop_Params(cls,MLCardPath,params):
        """ Set the parameters in MadLoopParamCard to the values specified in
        the dictionary params.
        The key is the name of the parameter and the value is the corresponding
        string to write in the card."""
        
        MLcard = bannermod.MadLoopParam(MLCardPath)
        for key,value in params.items():
            MLcard.set(key, value, changeifuserset=False)
        MLcard.write(MLCardPath, commentdefault=True)

    def skip_loop_evaluation_setup(self, dir_name, skip=True):
        """ Edit loop_matrix.f in order to skip the loop evaluation phase.
        Notice this only affects the double precision evaluation which is
        normally fine as we do not make the timing check on mp."""

        file = open(pjoin(dir_name,'loop_matrix.f'), 'r')
        loop_matrix = file.read()
        file.close()
        
        file = open(pjoin(dir_name,'loop_matrix.f'), 'w')
        loop_matrix = re.sub(r"SKIPLOOPEVAL=\S+\)","SKIPLOOPEVAL=%s)"%('.TRUE.' 
                                           if skip else '.FALSE.'), loop_matrix)
        file.write(loop_matrix)
        file.close()

    def boot_time_setup(self, dir_name, bootandstop=True):
        """ Edit loop_matrix.f in order to set the flag which stops the
        execution after booting the program (i.e. reading the color data)."""

        file = open(pjoin(dir_name,'loop_matrix.f'), 'r')
        loop_matrix = file.read()
        file.close()
        
        file = open(pjoin(dir_name,'loop_matrix.f'), 'w')        
        loop_matrix = re.sub(r"BOOTANDSTOP=\S+\)","BOOTANDSTOP=%s)"%('.TRUE.' 
                                    if bootandstop else '.FALSE.'), loop_matrix)
        file.write(loop_matrix)
        file.close()

    def setup_process(self, matrix_element, export_dir, reusing = False,
                                      param_card = None, MLOptions={},clean=True):
        """ Output the matrix_element in argument and perform the initialization
        while providing some details about the output in the dictionary returned. 
        Returns None if anything fails"""
                
        infos={'Process_output': None,
               'HELAS_MODEL_compilation' : None,
               'dir_path' : None,
               'Initialization' : None,
               'Process_compilation' : None}

        if not reusing and clean:
            if os.path.isdir(export_dir):
                clean_up(self.output_path)
                if os.path.isdir(export_dir):
                    raise InvalidCmd(\
                            "The directory %s already exist. Please remove it."\
                                                            %str(export_dir))
        else:
            if not os.path.isdir(export_dir):
                raise InvalidCmd(\
                    "Could not find the directory %s to reuse."%str(export_dir))                           
        

        if not reusing and clean:
            model = matrix_element['processes'][0].get('model')
            # I do the import here because there is some cyclic import of export_v4
            # otherwise
            import madgraph.loop.loop_exporters as loop_exporters
            if self.loop_optimized_output:
                exporter_class=loop_exporters.LoopProcessOptimizedExporterFortranSA
            else:
                exporter_class=loop_exporters.LoopProcessExporterFortranSA
    
            MLoptions = {'clean': True, 
                       'complex_mass': self.cmass_scheme,
                       'export_format':'madloop', 
                       'mp':True,
                       'SubProc_prefix':'P',
        'compute_color_flows':not matrix_element['processes'][0].get('has_born'),
          'loop_dir': pjoin(self.mg_root,'Template','loop_material'),
                       'cuttools_dir': self.cuttools_dir,
                       'fortran_compiler':self.cmd.options['fortran_compiler'],
                       'output_dependencies':self.cmd.options['output_dependencies']}
    
            MLoptions.update(self.tir_dir)

            start=time.time()
            FortranExporter = exporter_class(export_dir, MLoptions)
            FortranModel = helas_call_writers.FortranUFOHelasCallWriter(model)
            FortranExporter.copy_template(model)
            FortranExporter.generate_subprocess_directory(matrix_element, FortranModel)
            wanted_lorentz = misc.make_unique(matrix_element.get_used_lorentz())
            wanted_couplings = misc.make_unique([c for l in matrix_element.get_used_couplings() \
                                                                for c in l])
            FortranExporter.convert_model(self.full_model,wanted_lorentz,wanted_couplings)
            infos['Process_output'] = time.time()-start
            start=time.time()
            FortranExporter.finalize(matrix_element,"",self.cmd.options, ['nojpeg'])
            infos['HELAS_MODEL_compilation'] = time.time()-start
        
        # Copy the parameter card if provided
        if param_card != None:
            if isinstance(param_card, str):
                cp(pjoin(param_card),\
                              pjoin(export_dir,'Cards','param_card.dat'))
            else:
                param_card.write(pjoin(export_dir,'Cards','param_card.dat'))
                
        # First Initialize filters (in later versions where this will hopefully
        # be done at generation time, then it will be able to skip it)
        MadLoopInitializer.fix_PSPoint_in_check(
                 pjoin(export_dir,'SubProcesses'), read_ps = False, npoints = 4)

        self.fix_MadLoopParamCard(pjoin(export_dir,'Cards'),
                            mp = False, loop_filter = True,MLOptions=MLOptions)
        
        shell_name = None
        directories = misc.glob('P0_*', pjoin(export_dir, 'SubProcesses'))
        if directories and os.path.isdir(directories[0]):
            shell_name = os.path.basename(directories[0])
        dir_name = pjoin(export_dir, 'SubProcesses', shell_name)
        infos['dir_path']=dir_name

        # Do not refresh the filter automatically as this is very often a waste
        # of time
        if not MadLoopInitializer.need_MadLoopInit(
                                                export_dir, subproc_prefix='P'):
            return infos

        attempts = [3,15]
        # remove check and check_sa.o for running initialization again
        try:
            os.remove(pjoin(dir_name,'check'))
            os.remove(pjoin(dir_name,'check_sa.o'))
        except OSError:
            pass

        nPS_necessary = MadLoopInitializer.run_initialization(dir_name,
                                pjoin(export_dir,'SubProcesses'),infos,\
                                req_files = ['HelFilter.dat','LoopFilter.dat'],
                                attempts = attempts)
        if attempts is None:
            logger.error("Could not compile the process %s,"%shell_name+\
                              " try to generate it via the 'generate' command.")
            return None
        if nPS_necessary is None:
            logger.error("Could not initialize the process %s"%shell_name+\
                                            " with %s PS points."%max(attempts))
            return None
        elif nPS_necessary > min(attempts):
            logger.warning("Could not initialize the process %s"%shell_name+\
              " with %d PS points. It needed %d."%(min(attempts),nPS_necessary))

        return infos

    def time_matrix_element(self, matrix_element, reusing = False,
                       param_card = None, keep_folder = False, options=None,
                       MLOptions = {}):
        """ Output the matrix_element in argument and give detail information
        about the timing for its output and running"""

        # If True, then force three PS points only and skip the test on
        # unpolarized PS point 
        make_it_quick=False

        if options and 'split_orders' in list(options.keys()):
            split_orders = options['split_orders']
        else:
            split_orders = -1

        assert ((not reusing and isinstance(matrix_element, \
                 helas_objects.HelasMatrixElement)) or (reusing and 
                              isinstance(matrix_element, base_objects.Process)))
        if not reusing:
            proc_name = matrix_element['processes'][0].shell_string()[2:]
        else:
            proc_name = matrix_element.shell_string()[2:]
        
        export_dir=pjoin(self.output_path,('SAVED' if keep_folder else '')+\
                                                temp_dir_prefix+"_%s"%proc_name)

        res_timings = self.setup_process(matrix_element,export_dir, \
            reusing, param_card,MLOptions = MLOptions,clean=True)
        
        if res_timings == None:
            return None
        dir_name=res_timings['dir_path']

        # Preserve exact timing inputs/results before profile's stability pass
        # rewrites the driver, filters and result.dat. All capture is outside
        # make_and_run's existing timers and does not change its calls/settings.
        import hashlib
        import json

        timing_metadata = {
            'schema': 'madloop-profile-timing-metadata-v1',
            'process': proc_name,
            'export_dir': os.path.abspath(export_dir),
            'subprocess_dir': os.path.abspath(dir_name),
            'requested_split_orders': split_orders,
            'stages': [],
            'selected_timing_helicity': None,
            'per_evaluation_statuses_available': False,
            'limitations': [
                'Stock CLI timing retains result.dat rather than a complete point/status stream.',
                'Its Fortran point generator has its own state; a Python seed alone does not identify that stream.',
                'Stage point counts can differ between backends because stock timing estimates its run length.',
                'Raw output file freshness is not guaranteed, especially for boot-and-stop; identities are observations only.'
            ]}
        metadata_dir = pjoin(export_dir, 'SavedRunInfos')
        metadata_path = pjoin(metadata_dir, 'profile_timing_metadata.json')

        def timing_file(path, include_text=False):
            record = {'path': os.path.abspath(path)}
            if os.path.isfile(path):
                with open(path, 'rb') as stream:
                    contents = stream.read()
                record.update(sha256=hashlib.sha256(contents).hexdigest(),
                              bytes=len(contents), realpath=os.path.realpath(path),
                              mtime_ns=os.stat(path).st_mtime_ns)
                if include_text:
                    record['text'] = contents.decode('utf-8')
            else:
                record['available'] = False
            return record

        def timing_runtime():
            records = {}
            seen = set()
            library_dir = pjoin(export_dir, 'lib')
            for directory, directories, names in os.walk(library_dir, followlinks=True):
                real = os.path.realpath(directory)
                if real in seen:
                    directories[:] = []
                    continue
                seen.add(real)
                for name in sorted(names):
                    if (name.endswith(('.a', '.dylib', '.mod')) or
                            re.search(r'\.so(?:\.[0-9]+)*$', name) or
                            name in ('ninjars-config.json', 'ninjars-native-libs.txt',
                                     'ninjars-link-before.txt', 'tirust-config.json',
                                     'tirust-native-libs.txt', 'tirust-link-before.txt')):
                        path = pjoin(directory, name)
                        records[os.path.relpath(path, export_dir)] = timing_file(path)
            for name in ('Source/make_opts', 'SubProcesses/MadLoop_makefile_definitions'):
                records[name] = timing_file(pjoin(export_dir, name))
            return records

        def verify_timing_runtime():
            # Runtime archives are static during the stock timing stages.
            # Reuse their once-hashed context; do not stream large archives
            # through the cache after every timed invocation.
            for record in timing_metadata['runtime_files'].values():
                path = record['path']
                if record.get('available') is False:
                    unchanged = not os.path.isfile(path)
                elif os.path.isfile(path):
                    current = os.stat(path)
                    unchanged = (current.st_size == record['bytes'] and
                                 current.st_mtime_ns == record['mtime_ns'] and
                                 os.path.realpath(path) == record['realpath'])
                else:
                    unchanged = False
                if not unchanged:
                    raise MadGraph5Error('Timing runtime changed during measurement: %s'%path)

        def save_timing_metadata():
            if not os.path.isdir(metadata_dir):
                os.makedirs(metadata_dir)
            with open(metadata_path, 'w') as stream:
                json.dump(timing_metadata, stream, indent=2, allow_nan=False)
                stream.write('\n')

        def capture_timing_stage(name, compile_seconds, wall_seconds, ram_usage):
            verify_timing_runtime()
            driver_path = pjoin(dir_name, 'check_sa.f')
            loop_path = pjoin(dir_name, 'loop_matrix.f')
            with open(driver_path) as stream:
                driver = stream.read()
            with open(loop_path) as stream:
                loop = stream.read()
            # Fixed-form continuation markers are irrelevant to these literals.
            flat = re.sub(r'\n     [^ 0] ?', '', driver)
            npoints = re.search(r'NPSPOINTS\s*=\s*([0-9]+)', flat, re.I)
            readps = re.search(r'READPS\s*=\s*(\.TRUE\.|\.FALSE\.)', flat, re.I)
            helicity = re.search(r'SLOOPMATRIXHEL_THRES\s*\(\s*P\s*,\s*([+-]?[0-9]+)', flat, re.I)
            target = re.search(r'SET_COUPLINGORDERS_TARGET\s*\(\s*([+-]?[0-9]+)', flat, re.I)
            flags = {}
            for flag in ('SKIPLOOPEVAL', 'BOOTANDSTOP'):
                values = re.findall(flag+r'\s*=\s*(\.TRUE\.|\.FALSE\.)', loop, re.I)
                flags[flag] = (values[0].upper() == '.TRUE.' if values and
                               len(set(value.upper() for value in values)) == 1 else None)
            effective = dict(self.get_MadLoop_Params(pjoin(export_dir, 'Cards', 'MadLoopParams.dat')))
            source_dir = pjoin(metadata_dir, '%02d_%s'%(len(timing_metadata['stages']), name))
            if not os.path.isdir(source_dir):
                os.makedirs(source_dir)
            source_snapshots = {}
            for filename, source_path in (('check_sa.f', driver_path), ('loop_matrix.f', loop_path)):
                target_path = pjoin(source_dir, filename)
                shutil.copyfile(source_path, target_path)
                source_snapshots[filename] = timing_file(target_path)
            # Match LHA_loadcard: direct file, then Cards in cwd and 5 parents.
            physical_card_paths = [pjoin(dir_name,'param_card.dat')]
            physical_card_paths.extend(pjoin(dir_name,*([os.pardir]*depth),
                'Cards','param_card.dat') for depth in range(6))
            physical_card_path = next((path for path in physical_card_paths
                if os.path.isfile(path)),physical_card_paths[0])
            stage = {
                'name': name,
                'actual_npoints': int(npoints.group(1)) if npoints else None,
                'read_ps': readps.group(1).upper() == '.TRUE.' if readps else None,
                'helicity_one_based_index': int(helicity.group(1)) if helicity else -1,
                'split_orders_target': int(target.group(1)) if target else None,
                'energy_assignment_lines': [line.strip() for line in driver.splitlines()
                                            if re.search(r'\bSQRTS\s*=', line, re.I)],
                'flags': flags,
                'check_sa': timing_file(driver_path),
                'loop_matrix': timing_file(loop_path),
                'executable': timing_file(pjoin(dir_name, 'check')),
                'source_snapshots': source_snapshots,
                'parameter_card': timing_file(pjoin(export_dir, 'Cards', 'param_card.dat'), True),
                'subprocess_parameter_card': timing_file(physical_card_path, True),
                'effective_madloop_card': timing_file(pjoin(export_dir, 'Cards', 'MadLoopParams.dat'), True),
                'madloop_card_aliases': [timing_file(path, True) for path in sorted(glob.glob(
                    pjoin(export_dir, 'SubProcesses', '**', 'MadLoopParams.dat'), recursive=True))],
                'effective_madloop_parameters': effective,
                'runtime_files_reference': 'runtime_files',
                'runtime_stat_unchanged': True,
                'raw_outputs': {'result.dat': timing_file(pjoin(dir_name, 'result.dat'), True)},
                'raw_output_freshness_verified': False,
                'compile_seconds': compile_seconds,
                'wall_seconds': wall_seconds,
                'ram_usage': ram_usage,
                'boot_wall_seconds': (wall_seconds if name == 'boot' else res_timings.get('Booting_time')),
                'derived_seconds_per_point': None,
                'per_evaluation_statuses_available': False}
            if name in ('polarized_full', 'unpolarized_full', 'unpolarized_skip', 'polarized_skip'):
                denominator = stage['actual_npoints']
                if denominator and stage['boot_wall_seconds'] is not None and wall_seconds is not None:
                    stage['derived_seconds_per_point'] = (wall_seconds-stage['boot_wall_seconds'])/denominator
            timing_metadata['stages'].append(stage)
            save_timing_metadata()

        def finish_timing_metadata():
            verify_timing_runtime()
            # Copy before adding the metadata reference to the return dictionary.
            timing_metadata['timing_result'] = copy.deepcopy(res_timings)
            save_timing_metadata()
            res_timings['timing_metadata'] = {'schema': timing_metadata['schema'],
                                             'path': os.path.abspath(metadata_path)}

        timing_metadata['runtime_files'] = timing_runtime()

        def check_disk_usage(path):
            return subprocess.check_output(
                [f"du -shc {path}"], shell=True, encoding="utf8"
            ).split()[-2]

        res_timings['du_source']=check_disk_usage(pjoin(\
                                                 export_dir,'Source','*','*.f'))
        res_timings['du_process']=check_disk_usage(pjoin(dir_name,'*.f'))
        res_timings['du_color']=check_disk_usage(pjoin(dir_name,
                                                  'MadLoop5_resources','*.dat'))
        res_timings['du_exe']=check_disk_usage(pjoin(dir_name,'check'))

        if not res_timings['Initialization']==None:
            time_per_ps_estimate = (res_timings['Initialization']/4.0)/2.0
        elif make_it_quick:
            time_per_ps_estimate = -1.0            
        else:
            # We cannot estimate from the initialization, so we run just a 3
            # PS point run to evaluate it.
            MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                                  read_ps = False, npoints = 3, hel_config = -1, 
                                                      split_orders=split_orders)
            compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name)
            capture_timing_stage('estimate', compile_time, run_time, ram_usage)
            time_per_ps_estimate = run_time/3.0
        
        self.boot_time_setup(dir_name,bootandstop=True)
        compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name)
        capture_timing_stage('boot', compile_time, run_time, ram_usage)
        res_timings['Booting_time'] = run_time
        self.boot_time_setup(dir_name,bootandstop=False)

        # Detect one contributing helicity
        contributing_hel=0
        n_contrib_hel=0
        proc_prefix_file = open(pjoin(dir_name,'proc_prefix.txt'),'r')
        proc_prefix = proc_prefix_file.read()
        proc_prefix_file.close()
        helicities = open(pjoin(dir_name,'MadLoop5_resources',
                                  '%sHelFilter.dat'%proc_prefix)).read().split()
        for i, hel in enumerate(helicities):
            if (self.loop_optimized_output and int(hel)>-10000) or hel=='T':
                if contributing_hel==0:
                    contributing_hel=i+1
                n_contrib_hel += 1
                    
        if contributing_hel==0:
            logger.error("Could not find a contributing helicity "+\
                                     "configuration for process %s."%proc_name)
            return None
        
        res_timings['n_contrib_hel']=n_contrib_hel
        res_timings['n_tot_hel']=len(helicities)
        helicity_path = pjoin(dir_name, 'MadLoop5_resources', '%sHelConfigs.dat'%proc_prefix)
        physical_tuple = None
        if os.path.isfile(helicity_path):
            with open(helicity_path) as stream:
                configurations = [line.split() for line in stream if line.strip()]
            if 0 < contributing_hel <= len(configurations):
                physical_tuple = [int(value) for value in configurations[contributing_hel-1]]
        timing_metadata['selected_timing_helicity'] = {
            'one_based_index': contributing_hel,
            'physical_tuple': physical_tuple,
            'helicity_configurations': timing_file(helicity_path, True),
            'filter': timing_file(pjoin(dir_name, 'MadLoop5_resources', '%sHelFilter.dat'%proc_prefix), True),
            'filter_tokens': list(helicities),
            'contributing_count': n_contrib_hel,
            'total_count': len(helicities)}
        raw_backends = self.get_MadLoop_Params(
            pjoin(export_dir, 'Cards', 'MadLoopParams.dat'))['MLReductionLib']
        timing_metadata['reduction_backends'] = ([int(tool.strip()) for tool in raw_backends.split('|')
            if tool.strip()] if isinstance(raw_backends, str) else [int(tool) for tool in raw_backends])
        timing_metadata['backend_labels'] = [bannermod.MadLoopParam._ID_reduction_tool_map.get(
            tool, str(tool)) for tool in timing_metadata['reduction_backends']]
        save_timing_metadata()
        
        # We aim at a 30 sec run
        if not make_it_quick:
            target_pspoints_number = max(int(30.0/time_per_ps_estimate)+1,50)
        else:
            target_pspoints_number = 10
        
        logger.info("Checking timing for process %s "%proc_name+\
                                    "with %d PS points."%target_pspoints_number)
        
        MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                          read_ps = False, npoints = target_pspoints_number*2, \
                       hel_config = contributing_hel, split_orders=split_orders)
        compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name)
        capture_timing_stage('polarized_full', compile_time, run_time, ram_usage)
        
        if compile_time == None: return None
        
        res_timings['run_polarized_total']=\
               (run_time-res_timings['Booting_time'])/(target_pspoints_number*2)

        if make_it_quick:
            res_timings['run_unpolarized_total'] = 1.0
            res_timings['ram_usage'] = 0.0
        else:
            MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                 read_ps = False, npoints = target_pspoints_number, hel_config = -1,
                                                          split_orders=split_orders)
            compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name, 
                                                                      checkRam=True)
            capture_timing_stage('unpolarized_full', compile_time, run_time, ram_usage)

            if compile_time == None: return None
            res_timings['run_unpolarized_total']=\
                       (run_time-res_timings['Booting_time'])/target_pspoints_number
            res_timings['ram_usage'] = ram_usage       
        
        if not self.loop_optimized_output:
            finish_timing_metadata()
            return res_timings
        
        # For the loop optimized output, we also check the time spent in
        # computing the coefficients of the loop numerator polynomials.
        
        # So we modify loop_matrix.f in order to skip the loop evaluation phase.
        self.skip_loop_evaluation_setup(dir_name,skip=True)

        if make_it_quick:
            res_timings['run_unpolarized_coefs'] = 1.0
        else:
            MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                 read_ps = False, npoints = target_pspoints_number, hel_config = -1,
                                                          split_orders=split_orders)
            compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name)
            capture_timing_stage('unpolarized_skip', compile_time, run_time, ram_usage)
            if compile_time == None: return None
            res_timings['run_unpolarized_coefs']=\
                       (run_time-res_timings['Booting_time'])/target_pspoints_number
        
        MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
                          read_ps = False, npoints = target_pspoints_number*2, \
                       hel_config = contributing_hel, split_orders=split_orders)
        compile_time, run_time, ram_usage = MadLoopInitializer.make_and_run(dir_name)
        capture_timing_stage('polarized_skip', compile_time, run_time, ram_usage)
        if compile_time == None: return None
        res_timings['run_polarized_coefs']=\
               (run_time-res_timings['Booting_time'])/(target_pspoints_number*2)    

        # Restitute the original file.
        self.skip_loop_evaluation_setup(dir_name,skip=False)
        
        finish_timing_metadata()
        return res_timings

#===============================================================================
# Global helper function run_multiprocs
#===============================================================================

    def check_matrix_element_stability(self, matrix_element,options=None,
                          infos_IN = None, param_card = None, keep_folder = False,
                          MLOptions = {}):
        """ Output the matrix_element in argument, run in for nPoints and return
        a dictionary containing the stability information on each of these points.
        If infos are provided, then the matrix element output is skipped and 
        reused from a previous run and the content of infos.
        """
        
        if not options:
            reusing = False
            nPoints = 100
            split_orders = -1
        else:
            reusing = options['reuse']
            nPoints = options['npoints']
            split_orders = options['split_orders']
        
        assert ((not reusing and isinstance(matrix_element, \
                 helas_objects.HelasMatrixElement)) or (reusing and 
                              isinstance(matrix_element, base_objects.Process)))            

        # Helper functions
        def relative_spread(values):
            """Keep exact zeros and zero-mean disagreements distinguishable."""
            spread = max(values) - min(values)
            average = abs(sum(values) / len(values))
            if not (math.isfinite(spread) and math.isfinite(average)):
                # Preserve the original arithmetic unless finite inputs overflow.
                scale = max(abs(value) for value in values)
                normalized = [value / scale for value in values]
                spread = max(normalized) - min(normalized)
                average = abs(sum(normalized) / len(normalized))
            if average == 0.0:
                return 0.0 if spread == 0.0 else float('inf')
            return spread / average

        def stop_stability_checker(checker):
            # Invalid results abort this run; do not leave its checker alive.
            try:
                checker.kill()
            except OSError:
                pass
            checker.wait()

        def format_PS_point(ps, rotation=0):
            """ Write out the specified PS point to the file dir_path/PS.input
            while rotating it if rotation!=0. We consider only rotations of 90
            but one could think of having rotation of arbitrary angle too.
            The first two possibilities, 1 and 2 are a rotation and boost 
            along the z-axis so that improve_ps can still work.
            rotation=0  => No rotation
            rotation=1  => Z-axis pi/2 rotation
            rotation=2  => Z-axis pi/4 rotation
            rotation=3  => Z-axis boost            
            rotation=4 => (x'=z,y'=-x,z'=-y)
            rotation=5 => (x'=-z,y'=y,z'=x)"""
            if rotation==0:
                p_out=copy.copy(ps)
            elif rotation==1:
                p_out = [[pm[0],-pm[2],pm[1],pm[3]] for pm in ps]
            elif rotation==2:
                sq2 = math.sqrt(2.0)
                p_out = [[pm[0],(pm[1]-pm[2])/sq2,(pm[1]+pm[2])/sq2,pm[3]] for pm in ps]
            elif rotation==3:
                p_out = boost_momenta(ps, 3)     
            # From this point the transformations will prevent the
            # improve_ps script of MadLoop to work.      
            elif rotation==4:
                p_out=[[pm[0],pm[3],-pm[1],-pm[2]] for pm in ps]
            elif rotation==5:
                p_out=[[pm[0],-pm[3],pm[2],pm[1]] for pm in ps]
            else:
                raise MadGraph5Error("Rotation id %i not implemented"%rotation)
            
            return '\n'.join([' '.join(['%.16E'%pi for pi in p]) for p in p_out])
            
        def pick_PS_point(proc, options):
            """ Randomly generate a PS point and make sure it is eligible. Then
            return it. Users can edit the cuts here if they want."""

            p, w_rambo = self.get_momenta(proc, options)
            if options['events']:
                return p
            # For 2>1 process, we don't check the cuts of course
            while (not MatrixElementEvaluator.pass_isolation_cuts(p) and  len(p)>3):
                p, w_rambo = self.get_momenta(proc, options)
             
            # For a 2>1 process, it would always be the same PS point,
            # so here we bring in so boost along the z-axis, just for the sake
            # of it.
            if len(p)==3:
                p = boost_momenta(p,3,random.uniform(0.0,0.99))
            return p
        
        # Start loop on loop libraries        
        # Accuracy threshold of double precision evaluations above which the
        # PS points is also evaluated in quadruple precision
        accuracy_threshold=1.0e-1
        
        # Number of lorentz transformations to consider for the stability test
        # (along with the loop direction test which is performed by default)
        num_rotations = 1
        
        if "MLReductionLib" not in MLOptions:
            tools=[1]
        else:
            tools=MLOptions["MLReductionLib"]
            tools=misc.make_unique(tools) # remove the duplication ones
            
        # not self-contained tir libraries
        tool_var={'pjfry':2,'golem':4,'samurai':5,'ninja':6,'collier':7,'ninjars':8,'tirust':9}
        for tool in ['pjfry','golem','samurai','ninja','collier','ninjars','tirust']:
            tool_dir='%s_dir'%tool
            if not tool_dir in self.tir_dir:
                if tool in ('ninjars', 'tirust') and tool_var[tool] in tools:
                    raise MadGraph5Error("Requested %s library is unavailable. Run 'install %s'." %
                                         (bannermod.MadLoopParam._ID_reduction_tool_map[tool_var[tool]], tool))
                continue
            tool_libpath=self.tir_dir[tool_dir]
            tool_libname="lib%s.a"%tool
            if (not isinstance(tool_libpath,str)) or (not os.path.exists(tool_libpath)) \
                or (not os.path.isfile(pjoin(tool_libpath,tool_libname))):
                if tool_var[tool] in tools:
                    if tool in ('ninjars', 'tirust'):
                        raise MadGraph5Error("Requested %s library is unavailable. Run 'install %s'." %
                                             (bannermod.MadLoopParam._ID_reduction_tool_map[tool_var[tool]], tool))
                    tools.remove(tool_var[tool])
        if not tools:
            return None
        
        # Normally, this should work for loop-induced processes as well
        if not reusing:
            process = matrix_element['processes'][0]
        else:
            process = matrix_element
        proc_name = process.shell_string()[2:]
        export_dir=pjoin(self.output_path,("SAVED" if keep_folder else "")+\
                                                temp_dir_prefix+"_%s"%proc_name)
        
        tools_name=bannermod.MadLoopParam._ID_reduction_tool_map
        
        return_dict={}
        return_dict['Stability']={}
        infos_save={'Process_output': None,
               'HELAS_MODEL_compilation' : None,
               'dir_path' : None,
               'Initialization' : None,
               'Process_compilation' : None} 
       
        for tool in tools:
            tool_name=tools_name[tool]
            # Each evaluations is performed in different ways to assess its stability.
            # There are two dictionaries, one for the double precision evaluation
            # and the second one for quadruple precision (if it was needed).
            # The keys are the name of the evaluation method and the value is the 
            # float returned.
            DP_stability = []
            QP_stability = []
            # The unstable point encountered are stored in this list
            Unstable_PS_points = []
            # The exceptional PS points are those which stay unstable in quad prec.
            Exceptional_PS_points = []
        
            MLoptions=copy.deepcopy(MLOptions)
            MLoptions["MLReductionLib"]=tool
            clean = (tool==tools[0]) and not nPoints==0
            if infos_IN==None or (tool_name not in infos_IN):
                infos=infos_IN
            else:
                infos=infos_IN[tool_name]

            if not infos:
                infos = self.setup_process(matrix_element,export_dir, \
                                            reusing, param_card,MLoptions,clean)
                if not infos:
                    return None
            
            if clean:
                infos_save['Process_output']=infos['Process_output']
                infos_save['HELAS_MODEL_compilation']=infos['HELAS_MODEL_compilation']
                infos_save['dir_path']=infos['dir_path']
                infos_save['Process_compilation']=infos['Process_compilation']
            else:
                if not infos['Process_output']:
                    infos['Process_output']=infos_save['Process_output']
                if not infos['HELAS_MODEL_compilation']:
                    infos['HELAS_MODEL_compilation']=infos_save['HELAS_MODEL_compilation']
                if not infos['dir_path']:
                    infos['dir_path']=infos_save['dir_path']
                if not infos['Process_compilation']:
                    infos['Process_compilation']=infos_save['Process_compilation']
                    
            dir_path=infos['dir_path']

            # Reuse old stability runs if present
            savefile='SavedStabilityRun_%s%%s.pkl'%tools_name[tool]
            data_i = 0
            
            if reusing:
                # Possibly add additional data than the main one in 0
                data_i=0
                while os.path.isfile(pjoin(dir_path,savefile%('_%d'%data_i))):
                    pickle_path = pjoin(dir_path,savefile%('_%d'%data_i))
                    saved_run = save_load_object.load_from_file(pickle_path)
                    if data_i>0:
                        logger.info("Loading additional data stored in %s."%
                                                               str(pickle_path))
                        logger.info("Loaded data moved to %s."%str(pjoin(
                                   dir_path,'LOADED_'+savefile%('_%d'%data_i))))
                        shutil.move(pickle_path,
                               pjoin(dir_path,'LOADED_'+savefile%('%d'%data_i)))
                    DP_stability.extend(saved_run['DP_stability'])
                    QP_stability.extend(saved_run['QP_stability'])
                    Unstable_PS_points.extend(saved_run['Unstable_PS_points'])
                    Exceptional_PS_points.extend(saved_run['Exceptional_PS_points'])
                    data_i += 1
                                        
            return_dict['Stability'][tool_name] = {'DP_stability':DP_stability,
                              'QP_stability':QP_stability,
                              'Unstable_PS_points':Unstable_PS_points,
                              'Exceptional_PS_points':Exceptional_PS_points}

            if nPoints==0:
                if len(return_dict['Stability'][tool_name]['DP_stability'])!=0:
                    # In case some data was combined, overwrite the pickle
                    if data_i>1:
                        save_load_object.save_to_file(pjoin(dir_path,
                             savefile%'_0'),return_dict['Stability'][tool_name])
                    continue
                else:
                    logger.info("ERROR: Not reusing a directory or any pickled"+
                                " result for tool %s and the number"%tool_name+\
                                             " of point for the check is zero.")
                    return None

            logger.info("Checking stability of process %s "%proc_name+\
                "with %d PS points by %s."%(nPoints,tool_name))
            if infos['Initialization'] != None:
                time_per_ps_estimate = (infos['Initialization']/4.0)/2.0
                sec_needed = int(time_per_ps_estimate*nPoints*4)
            else:
                sec_needed = 0
            
            progress_bar = None
            time_info = False
            if sec_needed>5:
                time_info = True
                logger.info("This check should take about "+\
                            "%s to run. Started on %s."%(\
                            str(datetime.timedelta(seconds=sec_needed)),\
                            datetime.datetime.now().strftime("%d-%m-%Y %H:%M")))
            if logger.getEffectiveLevel()<logging.WARNING and \
                              (sec_needed>5 or infos['Initialization'] == None):
                widgets = ['Stability check:', pbar.Percentage(), ' ', 
                                            pbar.Bar(),' ', pbar.ETA(), ' ']
                progress_bar = pbar.ProgressBar(widgets=widgets, maxval=nPoints, 
                                                              fd=sys.stdout)
            MadLoopInitializer.fix_PSPoint_in_check(pjoin(export_dir,'SubProcesses'),
            read_ps = True, npoints = 1, hel_config = -1, split_orders=split_orders)
            # Recompile (Notice that the recompilation is only necessary once) for
            # the change above to take effect.
            # Make sure to recreate the executable and modified sources
            try:
                os.remove(pjoin(dir_path,'check'))
                os.remove(pjoin(dir_path,'check_sa.o'))
            except OSError:
                pass
            # Now run make
            devnull = open(os.devnull, 'w')
            retcode = subprocess.call(['make','check'],
                                   cwd=dir_path, stdout=devnull, stderr=devnull)
            devnull.close()    
            if retcode != 0:
                logging.info("Error while executing make in %s" % dir_path)
                return None
                

            # First create the stability check fortran driver executable if not 
            # already present.
            if not os.path.isfile(pjoin(dir_path,'StabilityCheckDriver.f')):
                # Use the presence of the file born_matrix.f to check if this output
                # is a loop_induced one or not.
                if os.path.isfile(pjoin(dir_path,'born_matrix.f')):
                    checkerName = 'StabilityCheckDriver.f'
                else:
                    checkerName = 'StabilityCheckDriver_loop_induced.f'

                with open(pjoin(self.mg_root,'Template','loop_material','Checks',
                                                checkerName),'r') as checkerFile:
                    with open(pjoin(dir_path,'proc_prefix.txt')) as proc_prefix:
                        checkerToWrite = checkerFile.read()%{'proc_prefix':
                                                                 proc_prefix.read()}
                checkerFile = open(pjoin(dir_path,'StabilityCheckDriver.f'),'w')
                checkerFile.write(checkerToWrite)
                checkerFile.close()                
                #cp(pjoin(self.mg_root,'Template','loop_material','Checks',\
                #    checkerName),pjoin(dir_path,'StabilityCheckDriver.f'))
        
            # Make sure to recompile the possibly modified files (time stamps can be
            # off).
            if os.path.isfile(pjoin(dir_path,'StabilityCheckDriver')):
                os.remove(pjoin(dir_path,'StabilityCheckDriver'))
            if os.path.isfile(pjoin(dir_path,'loop_matrix.o')):
                os.remove(pjoin(dir_path,'loop_matrix.o'))
            misc.compile(arg=['StabilityCheckDriver'], cwd=dir_path, \
                                              mode='fortran', job_specs = False)

            # Now for 2>1 processes, because the HelFilter was setup in for always
            # identical PS points with vec(p_1)=-vec(p_2), it is best not to remove
            # the helicityFilter double check
            if len(process['legs'])==3:
                self.fix_MadLoopParamCard(pjoin(export_dir,'Cards'), mp=False,
                              loop_filter=False, DoubleCheckHelicityFilter=True)

            StabChecker = subprocess.Popen([pjoin(dir_path,'StabilityCheckDriver')], 
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, 
                                                                   cwd=dir_path, bufsize=0)
            start_index = len(DP_stability)
            if progress_bar!=None:
                    progress_bar.start()

            # Flag to know if the run was interrupted or not
            interrupted = False
            # Flag to know whether the run for one specific PS point got an IOError
            # and must be retried
            retry = 0
            # We do not use a for loop because we want to manipulate the updater.
            i=start_index
            if options and 'events' in options and options['events']:
                # it is necessary to reuse the events from lhe file
                import MadSpin.decay as madspin
                fsock = open(options['events'])
                self.event_file = madspin.Event(fsock)
            while i<(start_index+nPoints):
                # To be added to the returned statistics  
                qp_dict={}
                dp_dict={}
                UPS = None
                EPS = None
                # Pick an eligible PS point with rambo, if not already done
                if retry==0:
                    p = pick_PS_point(process, options)
#               print "I use P_%i="%i,p
                try:
                    if progress_bar!=None:
                        progress_bar.update(i+1-start_index)
                    # Write it in the input file
                    PSPoint = format_PS_point(p,0)
                    dp_res=[]
                    dp_res.append(self.get_me_value(StabChecker,PSPoint,1,
                                                     split_orders=split_orders))
                    dp_dict['CTModeA']=dp_res[-1]
                    dp_res.append(self.get_me_value(StabChecker,PSPoint,2,
                                                     split_orders=split_orders))
                    dp_dict['CTModeB']=dp_res[-1]
                    for rotation in range(1,num_rotations+1):
                        PSPoint = format_PS_point(p,rotation)
                        dp_res.append(self.get_me_value(StabChecker,PSPoint,1,
                                                     split_orders=split_orders))
                        dp_dict['Rotation%i'%rotation]=dp_res[-1]
                        # Make sure all results make sense
                    if any(res is None or not math.isfinite(res) for res in dp_res):
                        stop_stability_checker(StabChecker)
                        return None
                    dp_accuracy = relative_spread(dp_res)
                    dp_dict['Accuracy'] = dp_accuracy
                    if dp_accuracy>accuracy_threshold:
                        if tool in [1,6,8,9]:
                            # CutTools, Ninja, NinjaRS and TIRust can use QP
                            UPS = [i,p]
                            qp_res=[]
                            PSPoint = format_PS_point(p,0)
                            qp_res.append(self.get_me_value(StabChecker,PSPoint,4,
                                                         split_orders=split_orders))
                            qp_dict['CTModeA']=qp_res[-1]
                            qp_res.append(self.get_me_value(StabChecker,PSPoint,5,
                                                         split_orders=split_orders))
                            qp_dict['CTModeB']=qp_res[-1]
                            for rotation in range(1,num_rotations+1):
                                PSPoint = format_PS_point(p,rotation)
                                qp_res.append(self.get_me_value(StabChecker,PSPoint,4,
                                                         split_orders=split_orders))
                                qp_dict['Rotation%i'%rotation]=qp_res[-1]
                            # Make sure all results make sense
                            if any(res is None or not math.isfinite(res) for res in qp_res):
                                stop_stability_checker(StabChecker)
                                return None
                        
                            qp_accuracy = relative_spread(qp_res)
                            qp_dict['Accuracy']=qp_accuracy
                            if qp_accuracy>accuracy_threshold:
                                EPS = [i,p]
                        else:
                            # Keep a UPS without an external QP evaluation for
                            # reduction libraries that do not support this path.
                            UPS = [i,p]

                except KeyboardInterrupt:
                    interrupted = True
                    break
                except IOError as e:
                    if e.errno == errno.EINTR:
                        if retry==100:
                            logger.error("Failed hundred times consecutively because"+
                                               " of system call interruptions.")
                            raise
                        else:
                            logger.debug("Recovered from a system call interruption."+\
                                        "PSpoint #%i, Attempt #%i."%(i,retry+1))
                            # Sleep for half a second. Safety measure.
                            time.sleep(0.5)                        
                        # We will retry this PS point
                        retry = retry+1
                        # Make sure the MadLoop process is properly killed
                        try:
                            StabChecker.kill()
                        except Exception: 
                            pass
                        StabChecker = subprocess.Popen(\
                               [pjoin(dir_path,'StabilityCheckDriver')], 
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, 
                                           stderr=subprocess.PIPE, cwd=dir_path, bufsize=0)
                        continue
                    else:
                        raise
                
                # Successfully processed a PS point so,
                #  > reset retry
                retry = 0
                #  > Update the while loop counter variable
                i=i+1
            
                # Update the returned statistics
                DP_stability.append(dp_dict)
                QP_stability.append(qp_dict)
                if not EPS is None:
                    Exceptional_PS_points.append(EPS)
                if not UPS is None:
                    Unstable_PS_points.append(UPS)

            if progress_bar!=None:
                progress_bar.finish()
            if time_info:
                logger.info('Finished check on %s.'%datetime.datetime.now().strftime(\
                                                              "%d-%m-%Y %H:%M"))

            # Close the StabChecker process.
            if not interrupted:
                StabChecker.stdin.write('y\n'.encode())
            else:
                StabChecker.kill()
        
            #return_dict = {'DP_stability':DP_stability,
            #           'QP_stability':QP_stability,
            #           'Unstable_PS_points':Unstable_PS_points,
            #           'Exceptional_PS_points':Exceptional_PS_points}
        
            # Save the run for possible future use
            save_load_object.save_to_file(pjoin(dir_path,savefile%'_0'),\
                                          return_dict['Stability'][tool_name])

            if interrupted:
                break
        
        return_dict['Process'] =  matrix_element.get('processes')[0] if not \
                                                     reusing else matrix_element
        return return_dict

    @classmethod
    def get_me_value(cls, StabChecker, PSpoint, mode, hel=-1, mu_r=-1.0,
                                                               split_orders=-1):
        """ This version of get_me_value is simplified for the purpose of this
        class. No compilation is necessary. The CT mode can be specified."""

        # Reset the stdin with EOF character without closing it.
        StabChecker.stdin.write('\x1a'.encode())
        StabChecker.stdin.write('1\n'.encode())
        StabChecker.stdin.write(('%d\n'%mode).encode())   
        StabChecker.stdin.write(('%s\n'%PSpoint).encode())
        StabChecker.stdin.write(('%.16E\n'%mu_r).encode()) 
        StabChecker.stdin.write(('%d\n'%hel).encode())
        StabChecker.stdin.write(('%d\n'%split_orders).encode())
        

        try:
            #fsock = open('/tmp/log', 'w')
            while True:
                output = StabChecker.stdout.readline().decode(errors='ignore')
                #fsock.write(output)
                if output != '':
                    last_non_empty = output
                if output==' ##TAG#RESULT_START#TAG##\n':
                    break
                # Break if the checker has crashed for some reason.
                ret_code = StabChecker.poll()
                if not ret_code is None:
                    output = StabChecker.stdout.readline().decode(errors='ignore')
                    if output != '':
                        last_non_empty = output
                    error = StabChecker.stderr.readline().decode(errors='ignore')
                    raise MadGraph5Error("The MadLoop stability checker crashed with return code = %d, and last output:\n\nstdout: %s\nstderr: %s\n"%\
                                               (ret_code, last_non_empty, error))
                    
            res = ""
            while True:
                output = StabChecker.stdout.readline().decode(errors='ignore')
                if output != '':
                    last_non_empty = output
                if str(output)==' ##TAG#RESULT_STOP#TAG##\n':
                    break
                else:
                    res += output
                ret_code = StabChecker.poll()               
                if not ret_code is None:
                    output = StabChecker.stdout.readline().decode(errors='ignore')
                    if output != '':
                        last_non_empty = output
                    error = StabChecker.stderr.readline().decode(errors='ignore')
                    raise MadGraph5Error("The MadLoop stability checker crashed with return code = %d, and last output:\n\nstdout: %s\nstderr: %s\n"%\
                                               (ret_code, last_non_empty, error))

            # A missing finite record must not inherit the general parser's
            # zero default: an explicitly printed FIN 0 is a valid result.
            finite_rows = [line.split() for line in res.splitlines()
                           if line.split()[:1] == ['FIN']]
            if len(finite_rows) != 1 or len(finite_rows[0]) != 2:
                return None
            try:
                finite_value = float(finite_rows[0][1])
            except ValueError:
                return None
            if not math.isfinite(finite_value):
                return None
            return cls.parse_check_output(res,format='tuple')[0][0]
        except IOError as e:
            logging.warning("Error while running MadLoop. Exception = %s"%str(e))
            raise e 

def evaluate_helicities(process, param_card = None, mg_root="", 
                                                          cmass_scheme = False):
    """ Perform a python evaluation of the matrix element independently for
    all possible helicity configurations for a fixed number of points N and 
    returns the average for each in the format [[hel_config, eval],...].
    This is used to determine what are the vanishing and dependent helicity 
    configurations at generation time and accordingly setup the output.
    This is not yet implemented at LO."""
    
    # Make sure this function is employed with a single process at LO
    assert isinstance(process,base_objects.Process)
    assert process.get('perturbation_couplings')==[]
    
    N_eval=50
    
    evaluator = MatrixElementEvaluator(process.get('model'), param_card,
                                            auth_skipping = False, reuse = True)
    
    amplitude = diagram_generation.Amplitude(process)
    matrix_element = helas_objects.HelasMatrixElement(amplitude,gen_color=False)
    
    cumulative_helEvals = []
    # Fill cumulative hel progressively with several evaluations of the ME.
    for i in range(N_eval):
        p, w_rambo = evaluator.get_momenta(process) 
        helEvals = evaluator.evaluate_matrix_element(\
                matrix_element, p = p, output = 'helEvals')['helEvals']
        if cumulative_helEvals==[]:
            cumulative_helEvals=copy.copy(helEvals)
        else:
            cumulative_helEvals = [[h[0],h[1]+helEvals[i][1]] for i, h in \
                                                 enumerate(cumulative_helEvals)]
            
    # Now normalize with the total number of evaluations
    cumulative_helEvals = [[h[0],h[1]/N_eval] for h in cumulative_helEvals]
    
    # As we are not in the context of a check command, so we clean the added
    # globals right away
    clean_added_globals(ADDED_GLOBAL)
    
    return cumulative_helEvals
    
def run_multiprocs_no_crossings(function, multiprocess, stored_quantities,
                                opt=None, options=None):
    """A wrapper function for running an iteration of a function over
    a multiprocess, without having to first create a process list
    (which makes a big difference for very large multiprocesses.
    stored_quantities is a dictionary for any quantities that we want
    to reuse between runs."""
    
    model = multiprocess.get('model')
    isids = [leg.get('ids') for leg in multiprocess.get('legs') \
              if not leg.get('state')]
    fsids = [leg.get('ids') for leg in multiprocess.get('legs') \
             if leg.get('state')]
    # Create dictionary between isids and antiids, to speed up lookup
    id_anti_id_dict = {}
    for id in set(tuple(sum(isids+fsids, []))):
        id_anti_id_dict[id] = model.get_particle(id).get_anti_pdg_code()
        id_anti_id_dict[model.get_particle(id).get_anti_pdg_code()] = id        
    sorted_ids = []
    results = []
    for is_prod in itertools.product(*isids):
        for fs_prod in itertools.product(*fsids):

            # Check if we have already checked the process
            if check_already_checked(is_prod, fs_prod, sorted_ids,
                                     multiprocess, model, id_anti_id_dict):
                continue
            # Generate process based on the selected ids
            # (get_process carries over the polarization of the multi-legs)
            process = multiprocess.get_process(is_prod, fs_prod)

            if opt is not None:
                if isinstance(opt, dict):
                    try:
                        value = opt[process.base_string()]
                    except Exception:
                        continue
                    result = function(process, stored_quantities, value, options=options)
                else:
                    result = function(process, stored_quantities, opt, options=options)
            else:
                result = function(process, stored_quantities, options=options)
                      
            if result:
                results.append(result)

    return results

#===============================================================================
# Helper function check_already_checked
#===============================================================================

def check_already_checked(is_ids, fs_ids, sorted_ids, process, model,
                          id_anti_id_dict = {}):
    """Check if process already checked, if so return True, otherwise add
    process and antiprocess to sorted_ids."""

    # Check if process is already checked
    if id_anti_id_dict:
        is_ids = [id_anti_id_dict[id] for id in \
                  is_ids]
    else:
        is_ids = [model.get_particle(id).get_anti_pdg_code() for id in \
                  is_ids]        

    ids = array.array('i', sorted(is_ids + list(fs_ids)) + \
                      [process.get('id')])

    if ids in sorted_ids:
        # We have already checked (a crossing of) this process
        return True

    # Add this process to tested_processes
    sorted_ids.append(ids)

    # Skip adding antiprocess below, since might be relevant too
    return False

#===============================================================================
# Generate a loop matrix element
#===============================================================================
def generate_loop_matrix_element(process_definition, reuse, output_path=None,
                        cmd = FakeInterface(), proc_name=None, loop_filter=None):
    """ Generate a loop matrix element from the process definition, and returns
    it along with the timing information dictionary.
    If reuse is True, it reuses the already output directory if found.
    There is the possibility of specifying the proc_name."""

    assert isinstance(process_definition,
                          (base_objects.ProcessDefinition,base_objects.Process))
    assert process_definition.get('perturbation_couplings')!=[]

    if isinstance(process_definition,base_objects.ProcessDefinition):
        if any(len(l.get('ids'))>1 for l in process_definition.get('legs')):
            raise InvalidCmd("This check can only be performed on single "+
                             " processes. (i.e. without multiparticle labels).")
    
        isids = [leg.get('ids')[0] for leg in process_definition.get('legs') \
                  if not leg.get('state')]
        fsids = [leg.get('ids')[0] for leg in process_definition.get('legs') \
                 if leg.get('state')]
    
        # Now generate a process based on the ProcessDefinition given in argument.
        process = process_definition.get_process(isids,fsids)
    else:
        process = process_definition
    
    if not output_path is None:
        root_path = output_path
    else:
        root_path = cmd._mgme_dir
    # By default, set all entries to None
    timing = {'Diagrams_generation': None,
              'n_loops': None,
              'HelasDiagrams_generation': None,
              'n_loop_groups': None,
              'n_loop_wfs': None,
              'loop_wfs_ranks': None}

    if proc_name:
        proc_dir = pjoin(root_path,proc_name)
    else:
        proc_dir = pjoin(root_path,"SAVED"+temp_dir_prefix+"_%s"%(
                               '_'.join(process.shell_string().split('_')[1:])))
    if reuse and os.path.isdir(proc_dir):
        logger.info("Reusing directory %s"%str(proc_dir))
        # If reusing, return process instead of matrix element
        return timing, process
    
    logger.info("Generating p%s"%process_definition.nice_string()[1:])

    start=time.time()
    try:
        amplitude = loop_diagram_generation.LoopAmplitude(process,
                                                        loop_filter=loop_filter)
    except InvalidCmd:
        # An error about the sanity of the process can be thrown, in which case
        # we return nothing
        return time.time()-start, None        
    if not amplitude.get('diagrams'):
        # Not matrix element for this process
        return time.time()-start, None

    # Make sure to disable loop_optimized_output when considering loop induced 
    # processes
    loop_optimized_output = cmd.options['loop_optimized_output']
    timing['Diagrams_generation']=time.time()-start
    timing['n_loops']=len(amplitude.get('loop_diagrams'))
    start=time.time()
    
    matrix_element = loop_helas_objects.LoopHelasMatrixElement(amplitude,
                        optimized_output = loop_optimized_output,gen_color=True)
    # Here, the alohaModel used for analytica computations and for the aloha
    # subroutine output will be different, so that some optimization is lost.
    # But that is ok for the check functionality.
    matrix_element.compute_all_analytic_information()
    timing['HelasDiagrams_generation']=time.time()-start
    
    if loop_optimized_output:
        timing['n_loop_groups']=len(matrix_element.get('loop_groups'))
        lwfs=[l for ldiag in matrix_element.get_loop_diagrams() for l in \
                                                ldiag.get('loop_wavefunctions')]
        timing['n_loop_wfs']=len(lwfs)
        timing['loop_wfs_ranks']=[]
        for rank in range(0,max([l.get_analytic_info('wavefunction_rank') \
                                                             for l in lwfs])+1):
            timing['loop_wfs_ranks'].append(\
                len([1 for l in lwfs if \
                               l.get_analytic_info('wavefunction_rank')==rank]))

    return timing, matrix_element

#===============================================================================
# check profile for loop process (timings + stability in one go)
#===============================================================================
def check_profile(process_definition, param_card = None,cuttools="",tir={},
             options = {}, cmd = FakeInterface(),output_path=None,MLOptions={}):
    """For a single loop process, check both its timings and then its stability
    in one go without regenerating it."""

    if 'reuse' not in options:
        keep_folder=False
    else:
        keep_folder = options['reuse']

    model=process_definition.get('model')

    timing1, matrix_element = generate_loop_matrix_element(process_definition,
                                    keep_folder,output_path=output_path,cmd=cmd)
    reusing = isinstance(matrix_element, base_objects.Process)
    options['reuse'] = reusing
    myProfiler = LoopMatrixElementTimer(cuttools_dir=cuttools,tir_dir=tir,
                                  model=model, output_path=output_path, cmd=cmd)

    if not myProfiler.loop_optimized_output:
        MLoptions={}
    else:
        MLoptions=copy.deepcopy(MLOptions)
        # Prefer an installed NinjaRS backend for Born-process profiles unless
        # the caller explicitly selected a reduction list.
        has_born = (matrix_element.get('has_born') if reusing else
                        matrix_element.get('processes')[0].get('has_born'))
        if 'MLReductionLib' not in MLoptions or not MLoptions['MLReductionLib']:
            MLoptions['MLReductionLib'] = ninjars_install.default_reduction_library(
                has_born, tir.get('ninjars_dir'))

    timing2 = myProfiler.time_matrix_element(matrix_element, reusing, 
                            param_card, keep_folder=keep_folder,options=options,
                            MLOptions = MLoptions) 
    
    if timing2 == None:
        return None, None

    timing2['reduction_tool'] = MLoptions.get('MLReductionLib', [1])[0]

    # The timing info is made of the merged two dictionaries
    timing = dict(list(timing1.items())+list(timing2.items()))
    if 'timing_metadata' in timing:
        import json
        metadata_path = timing['timing_metadata']['path']
        with open(metadata_path) as stream:
            metadata = json.load(stream)
        metadata['profile_timing_result'] = copy.deepcopy(timing)
        with open(metadata_path, 'w') as stream:
            json.dump(metadata, stream, indent=2, allow_nan=False)
            stream.write('\n')
    stability = myProfiler.check_matrix_element_stability(matrix_element,                                            
                            options=options, infos_IN=timing,param_card=param_card,
                                                      keep_folder = keep_folder,
                                                      MLOptions = MLoptions)
    if stability == None:
        return None, None
    else:
        timing['loop_optimized_output']=myProfiler.loop_optimized_output
        stability['loop_optimized_output']=myProfiler.loop_optimized_output
        return timing, stability

#===============================================================================
# check_timing for loop processes
#===============================================================================
def check_stability(process_definition, param_card = None,cuttools="",tir={}, 
                               options=None,nPoints=100, output_path=None,
                               cmd = FakeInterface(), MLOptions = {}):
    """For a single loop process, give a detailed summary of the generation and
    execution timing."""

    if "reuse" in options:
        reuse=options['reuse']
    else:
        reuse=False

    reuse=options['reuse']
    keep_folder = reuse
    model=process_definition.get('model')

    timing, matrix_element = generate_loop_matrix_element(process_definition,
                                        reuse, output_path=output_path, cmd=cmd)
    reusing = isinstance(matrix_element, base_objects.Process)
    options['reuse'] = reusing
    myStabilityChecker = LoopMatrixElementTimer(cuttools_dir=cuttools,tir_dir=tir,
                                    output_path=output_path,model=model,cmd=cmd)

    if not myStabilityChecker.loop_optimized_output:
        MLoptions = {}
    else:
        MLoptions = copy.deepcopy(MLOptions)
        # Make sure that the poles computation is disabled for COLLIER
        if 'COLLIERComputeUVpoles' not in MLoptions:
            MLoptions['COLLIERComputeUVpoles']=False
        if 'COLLIERComputeIRpoles' not in MLoptions:
            MLoptions['COLLIERComputeIRpoles']=False
        # Use high required accuracy in COLLIER's requirement if not specified
        if 'COLLIERRequiredAccuracy' not in MLoptions:
            MLoptions['COLLIERRequiredAccuracy']=1e-13
        # Use loop-direction switching as stability test if not specified (more reliable)
        if 'COLLIERUseInternalStabilityTest' not in MLoptions:
            MLoptions['COLLIERUseInternalStabilityTest']=False
        # Finally we *must* forbid the use of COLLIER global cache here, because it
        # does not work with the way we call independently CTMODERun 1 and 2
        # with the StabilityChecker.
        MLoptions['COLLIERGlobalCache'] = 0
        # Independent direction/rotation probes must not reuse the original point's cache.
        MLoptions['TIRustGlobalCache'] = 0

        if "MLReductionLib" not in MLOptions:
            MLoptions["MLReductionLib"] = []
            if cuttools:
                MLoptions["MLReductionLib"].extend([1])
            if "iregi_dir" in tir:
                MLoptions["MLReductionLib"].extend([3])
            if "pjfry_dir" in tir:
                MLoptions["MLReductionLib"].extend([2])
            if "golem_dir" in tir:
                MLoptions["MLReductionLib"].extend([4])
            if "samurai_dir" in tir:
                MLoptions["MLReductionLib"].extend([5])
            if "ninja_dir" in tir:
                MLoptions["MLReductionLib"].extend([6])
            if "collier_dir" in tir:
                MLoptions["MLReductionLib"].extend([7])
            if "ninjars_dir" in tir:
                MLoptions["MLReductionLib"].extend([8])

    stability = myStabilityChecker.check_matrix_element_stability(matrix_element, 
                        options=options,param_card=param_card, 
                                                        keep_folder=keep_folder,
                                                        MLOptions=MLoptions)
    
    if stability == None:
        return None
    else:
        stability['loop_optimized_output']=myStabilityChecker.loop_optimized_output
        return stability

#===============================================================================
# check_timing for loop processes
#===============================================================================
def check_timing(process_definition, param_card= None, cuttools="",tir={},
                           output_path=None, options={}, cmd = FakeInterface(),
                                                                MLOptions = {}):                 
    """For a single loop process, give a detailed summary of the generation and
    execution timing."""

    if 'reuse' not in options:
        keep_folder = False
    else:
        keep_folder = options['reuse']
    model=process_definition.get('model')
    timing1, matrix_element = generate_loop_matrix_element(process_definition,
                                  keep_folder, output_path=output_path, cmd=cmd)
    reusing = isinstance(matrix_element, base_objects.Process)
    options['reuse'] = reusing
    myTimer = LoopMatrixElementTimer(cuttools_dir=cuttools,model=model,tir_dir=tir,
                                               output_path=output_path, cmd=cmd)

    if not myTimer.loop_optimized_output:
        MLoptions = {}
    else:
        MLoptions = copy.deepcopy(MLOptions)
        # Make sure that the poles computation is disabled for COLLIER
        if 'COLLIERComputeUVpoles' not in MLoptions:
            MLoptions['COLLIERComputeUVpoles']=False
        if 'COLLIERComputeIRpoles' not in MLoptions:
            MLoptions['COLLIERComputeIRpoles']=False
        # And the COLLIER global cache is active, if not specified
        if 'COLLIERGlobalCache' not in MLoptions:
            MLoptions['COLLIERGlobalCache']=-1
        # Prefer installed NinjaRS for Born processes when not specified.
        if 'MLReductionLib' not in MLoptions or \
                                            len(MLoptions['MLReductionLib'])==0:
            has_born = (matrix_element.get('has_born') if reusing else
                        matrix_element.get('processes')[0].get('has_born'))
            MLoptions['MLReductionLib'] = ninjars_install.default_reduction_library(
                has_born, tir.get('ninjars_dir'))
            
    timing2 = myTimer.time_matrix_element(matrix_element, reusing, param_card,
                                     keep_folder = keep_folder, options=options,
                                     MLOptions = MLoptions)
    
    if timing2 == None:
        return None
    else:    
        # Return the merged two dictionaries
        res = dict(list(timing1.items())+list(timing2.items()))
        res['loop_optimized_output']=myTimer.loop_optimized_output
        res['reduction_tool'] = MLoptions.get('MLReductionLib', [1])[0]
        return res

#===============================================================================
# check_processes
#===============================================================================
def check_processes(processes, param_card = None, quick = [],cuttools="",tir={},
          options=None, reuse = False, output_path=None, cmd = FakeInterface()):
    """Check processes by generating them with all possible orderings
    of particles (which means different diagram building and Helas
    calls), and comparing the resulting matrix element values."""

    cmass_scheme = cmd.options['complex_mass_scheme']
    if isinstance(processes, base_objects.ProcessDefinition):
        # Generate a list of unique processes
        # Extract IS and FS ids
        multiprocess = processes
        model = multiprocess.get('model')

        # Initialize matrix element evaluation
        if multiprocess.get('perturbation_couplings')==[]:
            evaluator = MatrixElementEvaluator(model,
               auth_skipping = True, reuse = False, cmd = cmd)
        else:
            evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir, 
                            model=model, auth_skipping = True,
                            reuse = False, output_path=output_path, cmd = cmd)
       
        results = run_multiprocs_no_crossings(check_process,
                                              multiprocess,
                                              evaluator,
                                              quick,
                                              options)

        if "used_lorentz" not in evaluator.stored_quantities:
            evaluator.stored_quantities["used_lorentz"] = []
            
        if multiprocess.get('perturbation_couplings')!=[] and not reuse:
            # Clean temporary folders created for the running of the loop processes
            clean_up(output_path)
            
        return results, evaluator.stored_quantities["used_lorentz"]

    elif isinstance(processes, base_objects.Process):
        processes = base_objects.ProcessList([processes])
    elif isinstance(processes, base_objects.ProcessList):
        pass
    else:
        raise InvalidCmd("processes is of non-supported format")

    if not processes:
        raise InvalidCmd("No processes given")

    model = processes[0].get('model')

    # Initialize matrix element evaluation
    if processes[0].get('perturbation_couplings')==[]:
        evaluator = MatrixElementEvaluator(model, param_card,
               auth_skipping = True, reuse = False, cmd = cmd)
    else:
        evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools, tir_dir=tir,
                                               model=model,param_card=param_card,
                                           auth_skipping = True, reuse = False,
                                           output_path=output_path, cmd = cmd)

    # Keep track of tested processes, matrix elements, color and already
    # initiated Lorentz routines, to reuse as much as possible
    sorted_ids = []
    comparison_results = []

    # Check process by process
    for process in processes:
        
        # Check if we already checked process        
        if check_already_checked([l.get('id') for l in process.get('legs') if \
                                  not l.get('state')],
                                 [l.get('id') for l in process.get('legs') if \
                                  l.get('state')],
                                 sorted_ids, process, model):
            continue
        # Get process result
        res = check_process(process, evaluator, quick, options)
        if res:
            comparison_results.append(res)

    if "used_lorentz" not in evaluator.stored_quantities:
        evaluator.stored_quantities["used_lorentz"] = []
    
    if processes[0].get('perturbation_couplings')!=[] and not reuse:
        # Clean temporary folders created for the running of the loop processes
        clean_up(output_path)    
    
    return comparison_results, evaluator.stored_quantities["used_lorentz"]

def check_process(process, evaluator, quick, options):
    """Check the helas calls for a process by generating the process
    using all different permutations of the process legs (or, if
    quick, use a subset of permutations), and check that the matrix
    element is invariant under this."""

    model = process.get('model')

    # Ensure that leg numbers are set
    for i, leg in enumerate(process.get('legs')):
        leg.set('number', i+1)

    logger.info("Checking crossings of %s" % \
                process.nice_string().replace('Process:', 'process'))

    process_matrix_elements = []

    # For quick checks, only test twp permutations with leg "1" in
    # each position
    if quick:
        leg_positions = [[] for leg in process.get('legs')]
        quick = list(range(1,len(process.get('legs')) + 1))

    values = []

    # Now, generate all possible permutations of the legs
    number_checked=0
    for legs in itertools.permutations(process.get('legs')):
        
        order = [l.get('number') for l in legs]
        if quick:
            found_leg = True
            for num in quick:
                # Only test one permutation for each position of the
                # specified legs
                leg_position = legs.index([l for l in legs if \
                                           l.get('number') == num][0])

                if not leg_position in leg_positions[num-1]:
                    found_leg = False
                    leg_positions[num-1].append(leg_position)

            if found_leg:
                continue
        
        # Further limit the total number of permutations checked to 3 for
        # loop processes.
        if quick and process.get('perturbation_couplings') and number_checked >3:
            continue

        legs = base_objects.LegList(legs)

        if order != list(range(1,len(legs) + 1)):
            logger.info("Testing permutation: %s" % \
                        order)
        
        newproc = copy.copy(process)
        newproc.set('legs',legs)

        # Generate the amplitude for this process
        try:
            if newproc.get('perturbation_couplings')==[]:
                amplitude = diagram_generation.Amplitude(newproc)
            else:
                # Change the cutting method every two times.
                loop_base_objects.cutting_method = 'optimal' if \
                                            number_checked%2 == 0 else 'default'
                amplitude = loop_diagram_generation.LoopAmplitude(newproc)
        except InvalidCmd:
            result=False
        else:
            result = amplitude.get('diagrams')
        # Make sure to re-initialize the cutting method to the original one.
        loop_base_objects.cutting_method = 'optimal'
        
        if not result:
            # This process has no diagrams; go to next process
            logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
            break

        if order == list(range(1,len(legs) + 1)):
            # Generate phase space point to use
            p, w_rambo = evaluator.get_momenta(process, options)

        # Generate the HelasMatrixElement for the process
        if not isinstance(amplitude,loop_diagram_generation.LoopAmplitude):
            matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                          gen_color=False)
        else:
            matrix_element = loop_helas_objects.LoopHelasMatrixElement(amplitude,
                               optimized_output=evaluator.loop_optimized_output)

        # The loop diagrams are always the same in the basis, so that the
        # LoopHelasMatrixElement always look alike. One needs to consider
        # the crossing no matter what then.
        if amplitude.get('process').get('has_born'):
            # But the born diagrams will change depending on the order of the
            # particles in the process definition
            if matrix_element in process_matrix_elements:
                # Exactly the same matrix element has been tested
                # for other permutation of same process
                continue

        process_matrix_elements.append(matrix_element)

        res = evaluator.evaluate_matrix_element(matrix_element, p = p, 
                                                                options=options)
        if res == None:
            break

        values.append(res[0])
        number_checked += 1

        # Check if we failed badly (1% is already bad) - in that
        # case done for this process
        if abs(max(values)) + abs(min(values)) > 0 and \
               2 * abs(max(values) - min(values)) / \
               (abs(max(values)) + abs(min(values))) > 0.01:
            break
    
    # Check if process was interrupted
    if not values:
        return None

    # Done with this process. Collect values, and store
    # process and momenta
    diff = 0
    if abs(max(values)) + abs(min(values)) > 0:
        diff = 2* abs(max(values) - min(values)) / \
               (abs(max(values)) + abs(min(values)))

    # be more tolerant with loop processes
    if process.get('perturbation_couplings'):
        passed = diff < 1.e-5
    else:
        passed = diff < 1.e-8        

    return {"process": process,
            "momenta": p,
            "values": values,
            "difference": diff,
            "passed": passed}

def clean_up(mg_root):
    """Clean-up the possible left-over outputs from 'evaluate_matrix element' of
    the LoopMatrixEvaluator (when its argument proliferate is set to true). """
    
    if mg_root is None:
        pass
    
    directories = misc.glob('%s*' % temp_dir_prefix, mg_root)
    if directories != []:
        logger.debug("Cleaning temporary %s* check runs."%temp_dir_prefix)
    for dir in directories:
        # For safety make sure that the directory contains a folder SubProcesses
        if os.path.isdir(pjoin(dir,'SubProcesses')):
            shutil.rmtree(dir)

def format_output(output,format):
    """ Return a string for 'output' with the specified format. If output is 
    None, it returns 'NA'."""
    
    if output!=None:
        return format%output
    else:
        return 'NA'

def output_profile(myprocdef, stability, timing, output_path, reusing=False):
    """Present the results from a timing and stability consecutive check"""
    

    opt = timing['loop_optimized_output']

    text = 'Timing result for the '+('optimized' if opt else 'default')+\
                                                                    ' output:\n'
    text += output_timings(myprocdef,timing)

    text += '\nStability result for the '+('optimized' if opt else 'default')+\
                                                                    ' output:\n'
    text += output_stability(stability,output_path, reusing=reusing)

    mode = 'optimized' if opt else 'default'
    logFilePath =  pjoin(output_path, 'profile_%s_%s.log'\
                                    %(mode,stability['Process'].shell_string()))        
    logFile = open(logFilePath, 'w')
    logFile.write(text)
    logFile.close()
    logger.info('Log of this profile check was output to file %s'\
                                                              %str(logFilePath))
    return text

def output_stability(stability, output_path, reusing=False):
    """Present the result of a stability check in a nice format.
    The full info is printed out in 'Stability_result_<proc_shell_string>.dat'
    under the MadGraph7 root folder (output_path)"""
    
    def accuracy(eval_list):
        """ Compute the accuracy from different evaluations."""
        largest, smallest = max(eval_list), min(eval_list)
        spread = largest-smallest
        denominator = abs(largest+smallest)
        if not (math.isfinite(2.0*spread) and math.isfinite(denominator)):
            scale = max(abs(largest),abs(smallest))
            largest, smallest = largest/scale, smallest/scale
            spread = largest-smallest
            denominator = abs(largest+smallest)
        if denominator == 0.0:
            return 0.0 if spread == 0.0 else float('inf')
        return 2.0*spread/denominator
    
    def best_estimate(eval_list):
        """ Returns the best estimate from different evaluations."""
        largest, smallest = max(eval_list), min(eval_list)
        total = largest+smallest
        return total/2.0 if math.isfinite(total) else largest/2.0+smallest/2.0

    def log_accuracy(value):
        # A zero diagnostic ratio has logarithm -inf; do not alter raw samples.
        return float('-inf') if value == 0.0 else math.log(value)/math.log(10)
    
    def loop_direction_test_power(eval_list):
        """ Computes the loop direction test power P is computed as follow:
          P = accuracy(loop_dir_test) / accuracy(all_test)
        So that P is large if the loop direction test is effective.
        The tuple returned is (log(median(P)),log(min(P)),frac)
        where frac is the fraction of events with powers smaller than -3
        which means events for which the reading direction test shows an
        accuracy three digits higher than it really is according to the other
        tests."""
        powers=[]
        for eval in eval_list:
            loop_dir_evals = [eval['CTModeA'],eval['CTModeB']]
            # CTModeA is the reference so we keep it in too
            other_evals = [eval[key] for key in eval.keys() if key not in \
                                                         ['CTModeB','Accuracy']]
            if accuracy(other_evals)!=0.0 and accuracy(loop_dir_evals)!=0.0:
                power=accuracy(loop_dir_evals)/accuracy(other_evals)
                if not math.isnan(power):
                    powers.append(power)
        
        n_fail=0
        for p in powers:
            if log_accuracy(p)<-3:
                n_fail+=1
                
        if len(powers)==0:
            return (None,None,None)

        return (log_accuracy(median(powers)),
                log_accuracy(min(powers)),
                n_fail/len(powers))
        
    def test_consistency(dp_eval_list, qp_eval_list):
        """ Computes the consistency test C from the DP and QP evaluations.
          C = accuracy(all_DP_test) / abs(best_QP_eval-best_DP_eval)
        So a consistent test would have C as close to one as possible.
        The tuple returned is (log(median(C)),log(min(C)),log(max(C)))"""
        consistencies = []
        for dp_eval, qp_eval in zip(dp_eval_list,qp_eval_list):
            dp_evals = [dp_eval[key] for key in dp_eval.keys() \
                                                             if key!='Accuracy']
            qp_evals = [qp_eval[key] for key in qp_eval.keys() \
                                                             if key!='Accuracy']
            if (abs(best_estimate(qp_evals)-best_estimate(dp_evals)))!=0.0 and \
               accuracy(dp_evals)!=0.0:
                consistency=accuracy(dp_evals)/(abs(\
                              best_estimate(qp_evals)-best_estimate(dp_evals)))
                if not math.isnan(consistency):
                    consistencies.append(consistency)

        if len(consistencies)==0:
            return (None,None,None)

        return (log_accuracy(median(consistencies)),
                log_accuracy(min(consistencies)),
                log_accuracy(max(consistencies)))
    
    def median(orig_list):
        """ Find the median of a sorted float list. """
        tmp=copy.copy(orig_list)
        tmp.sort()
        if len(tmp)%2==0:
            return (tmp[int((len(tmp)/2)-1)]+tmp[int(len(tmp)/2)])/2.0
        else:
            return tmp[int((len(tmp)-1)/2)]

    # Define shortcut
    f = format_output   
    opt = stability['loop_optimized_output']
    for toolname, tool_data in stability['Stability'].items():
        for precision in ['DP_stability','QP_stability']:
            for evaluation in tool_data[precision]:
                if precision == 'QP_stability' and evaluation == {}:
                    continue
                try:
                    invalid = (math.isnan(evaluation['Accuracy']) or
                               evaluation['Accuracy'] < 0.0 or
                               any(not math.isfinite(value) for key,value in
                                   evaluation.items() if key != 'Accuracy'))
                except (KeyError,TypeError,ValueError):
                    invalid = True
                if invalid:
                    raise MadGraph5Error('Invalid stability data for %s (%s). '
                        'Remove stale saved stability data and rerun without -reuse.'
                        % (toolname,precision))

    mode = 'optimized' if opt else 'default'
    process = stability['Process']
    res_str = "Stability checking for %s (%s mode)\n"\
                                           %(process.nice_string()[9:],mode)

    logFile = open(pjoin(output_path, 'stability_%s_%s.log'\
                                           %(mode,process.shell_string())), 'w')

    logFile.write('Stability check results\n\n')
    logFile.write(res_str)
    data_plot_dict={}
    accuracy_dict={}
    nPSmax=0
    max_acc=0.0
    min_acc=1.0
    if stability['Stability']:
        toolnames= list(stability['Stability'].keys())
        toolnamestr="     |     ".join(tn+
                                ''.join([' ']*(10-len(tn))) for tn in toolnames)
        DP_stability = [[eval['Accuracy'] for eval in stab['DP_stability']] \
                        for key,stab in stability['Stability'].items()]
        med_dp_stab_str="     |     ".join([f(median(dp_stab),'%.2e  ') for dp_stab in  DP_stability])
        min_dp_stab_str="     |     ".join([f(min(dp_stab),'%.2e  ') for dp_stab in  DP_stability])
        max_dp_stab_str="     |     ".join([f(max(dp_stab),'%.2e  ') for dp_stab in  DP_stability])
        UPS = [stab['Unstable_PS_points'] for key,stab in stability['Stability'].items()]
        res_str_i  = "\n= Tool (DoublePrec for CT).......   %s\n"%toolnamestr
        len_PS=["%i"%len(evals)+\
             ''.join([' ']*(10-len("%i"%len(evals)))) for evals in DP_stability]
        len_PS_str="     |     ".join(len_PS)
        res_str_i += "|= Number of PS points considered   %s\n"%len_PS_str        
        res_str_i += "|= Median accuracy...............   %s\n"%med_dp_stab_str
        res_str_i += "|= Max accuracy..................   %s\n"%min_dp_stab_str
        res_str_i += "|= Min accuracy..................   %s\n"%max_dp_stab_str
        pmedminlist=[]
        pfraclist=[]
        for key,stab in stability['Stability'].items():
            (pmed,pmin,pfrac)=loop_direction_test_power(stab['DP_stability'])
            ldtest_str = "%s,%s"%(f(pmed,'%.1f'),f(pmin,'%.1f'))
            pfrac_str = f(pfrac,'%.2e')
            pmedminlist.append(ldtest_str+''.join([' ']*(10-len(ldtest_str))))
            pfraclist.append(pfrac_str+''.join([' ']*(10-len(pfrac_str))))
        pmedminlist_str="     |     ".join(pmedminlist)
        pfraclist_str="     |     ".join(pfraclist)
        res_str_i += "|= Overall DP loop_dir test power   %s\n"%pmedminlist_str
        res_str_i += "|= Fraction of evts with power<-3   %s\n"%pfraclist_str
        len_UPS=["%i"%len(upup)+\
                        ''.join([' ']*(10-len("%i"%len(upup)))) for upup in UPS]
        len_UPS_str="     |     ".join(len_UPS)
        res_str_i += "|= Number of Unstable PS points     %s\n"%len_UPS_str
        res_str_i += \
            """
= Legend for the statistics of the stability tests. (all log below ar log_10)
The loop direction test power P is computed as follow:
    P = accuracy(loop_dir_test) / accuracy(all_other_test)
    So that log(P) is positive if the loop direction test is effective.
  The tuple printed out is (log(median(P)),log(min(P)))
  The consistency test C is computed when QP evaluations are available:
     C = accuracy(all_DP_test) / abs(best_QP_eval-best_DP_eval)
  So a consistent test would have log(C) as close to zero as possible.
  The tuple printed out is (log(median(C)),log(min(C)),log(max(C)))\n"""
        res_str+=res_str_i
    for key in stability['Stability'].keys():
        toolname=key
        stab=stability['Stability'][key]
        DP_stability = [eval['Accuracy'] for eval in stab['DP_stability']]
        # Remember that an evaluation which did not require QP has an empty dictionary
        QP_stability = [eval['Accuracy'] if eval!={} else -1.0 for eval in \
                                                      stab['QP_stability']]
        nPS = len(DP_stability)
        if nPS>nPSmax:nPSmax=nPS
        UPS = stab['Unstable_PS_points']
        UPS_stability_DP = [DP_stability[U[0]] for U in UPS]
        UPS_stability_QP = [QP_stability[U[0]] for U in UPS]
        EPS = stab['Exceptional_PS_points']
        EPS_stability_DP = [DP_stability[E[0]] for E in EPS]
        EPS_stability_QP = [QP_stability[E[0]] for E in EPS]
        res_str_i = ""
        # Use nicer name for the XML tag in the log file
        xml_toolname = {'GOLEM95':'GOLEM','IREGI':'IREGI',
                        'CUTTOOLS':'CUTTOOLS','PJFRY++':'PJFRY',
                        'NINJA':'NINJA','NINJARS':'NINJARS','TIRUST':'TIRUST','SAMURAI':'SAMURAI',
                        'COLLIER':'COLLIER'}[toolname.upper()]
        if len(UPS)>0:
            res_str_i = "\nDetails of the %d/%d UPS encountered by %s\n"\
                                                        %(len(UPS),nPS,toolname)
            prefix = 'DP' if toolname in ['CutTools','Ninja','NinjaRS','TIRust'] else ''
            res_str_i += "|= %s Median inaccuracy.......... %s\n"\
                                    %(prefix,f(median(UPS_stability_DP),'%.2e'))
            res_str_i += "|= %s Max accuracy............... %s\n"\
                                       %(prefix,f(min(UPS_stability_DP),'%.2e'))
            res_str_i += "|= %s Min accuracy............... %s\n"\
                                       %(prefix,f(max(UPS_stability_DP),'%.2e'))
            (pmed,pmin,pfrac)=loop_direction_test_power(\
                                 [stab['DP_stability'][U[0]] for U in UPS])
            if toolname in ['CutTools','Ninja','NinjaRS','TIRust']:
                res_str_i += "|= UPS DP loop_dir test power.... %s,%s\n"\
                                                %(f(pmed,'%.1f'),f(pmin,'%.1f'))
                res_str_i += "|= UPS DP fraction with power<-3. %s\n"\
                                                                %f(pfrac,'%.2e')
                res_str_i += "|= QP Median accuracy............ %s\n"\
                                             %f(median(UPS_stability_QP),'%.2e')
                res_str_i += "|= QP Max accuracy............... %s\n"\
                                                %f(min(UPS_stability_QP),'%.2e')
                res_str_i += "|= QP Min accuracy............... %s\n"\
                                                %f(max(UPS_stability_QP),'%.2e')
                (pmed,pmin,pfrac)=loop_direction_test_power(\
                                     [stab['QP_stability'][U[0]] for U in UPS])
                res_str_i += "|= UPS QP loop_dir test power.... %s,%s\n"\
                                                %(f(pmed,'%.1f'),f(pmin,'%.1f'))
                res_str_i += "|= UPS QP fraction with power<-3. %s\n"%f(pfrac,'%.2e')
                (pmed,pmin,pmax)=test_consistency(\
                                     [stab['DP_stability'][U[0]] for U in UPS],
                                     [stab['QP_stability'][U[0]] for U in UPS])
                res_str_i += "|= DP vs QP stab test consistency %s,%s,%s\n"\
                                     %(f(pmed,'%.1f'),f(pmin,'%.1f'),f(pmax,'%.1f'))
            if len(EPS)==0:    
                res_str_i += "= Number of Exceptional PS points : 0\n"
        if len(EPS)>0:
            res_str_i = "\nDetails of the %d/%d EPS encountered by %s\n"\
                                                        %(len(EPS),nPS,toolname)
            res_str_i += "|= DP Median accuracy............ %s\n"\
                                             %f(median(EPS_stability_DP),'%.2e')
            res_str_i += "|= DP Max accuracy............... %s\n"\
                                                %f(min(EPS_stability_DP),'%.2e')
            res_str_i += "|= DP Min accuracy............... %s\n"\
                                                %f(max(EPS_stability_DP),'%.2e')
            pmed,pmin,pfrac=loop_direction_test_power(\
                                 [stab['DP_stability'][E[0]] for E in EPS])
            res_str_i += "|= EPS DP loop_dir test power.... %s,%s\n"\
                                                %(f(pmed,'%.1f'),f(pmin,'%.1f'))
            res_str_i += "|= EPS DP fraction with power<-3. %s\n"\
                                                                %f(pfrac,'%.2e')
            res_str_i += "|= QP Median accuracy............ %s\n"\
                                             %f(median(EPS_stability_QP),'%.2e')
            res_str_i += "|= QP Max accuracy............... %s\n"\
                                                %f(min(EPS_stability_QP),'%.2e')
            res_str_i += "|= QP Min accuracy............... %s\n"\
                                                %f(max(EPS_stability_QP),'%.2e')
            pmed,pmin,pfrac=loop_direction_test_power(\
                                 [stab['QP_stability'][E[0]] for E in EPS])
            res_str_i += "|= EPS QP loop_dir test power.... %s,%s\n"\
                                                %(f(pmed,'%.1f'),f(pmin,'%.1f'))
            res_str_i += "|= EPS QP fraction with power<-3. %s\n"%f(pfrac,'%.2e')

        logFile.write(res_str_i)

        if len(EPS)>0:
            logFile.write('\nFull details of the %i EPS encountered by %s.\n'\
                                                           %(len(EPS),toolname))
            logFile.write('<EPS_data reduction=%s>\n'%xml_toolname.upper())
            for i, eps in enumerate(EPS):
                logFile.write('\nEPS #%i\n'%(i+1))
                logFile.write('\n'.join(['  '+' '.join(['%.16E'%pi for pi in p]) \
                                                              for p in eps[1]]))
                logFile.write('\n  DP accuracy :  %.4e\n'%DP_stability[eps[0]])
                logFile.write('  QP accuracy :  %.4e\n'%QP_stability[eps[0]])
            logFile.write('</EPS_data>\n')
        if len(UPS)>0:
            logFile.write('\nFull details of the %i UPS encountered by %s.\n'\
                                                           %(len(UPS),toolname))
            logFile.write('<UPS_data reduction=%s>\n'%xml_toolname.upper())
            for i, ups in enumerate(UPS):
                logFile.write('\nUPS #%i\n'%(i+1))
                logFile.write('\n'.join(['  '+' '.join(['%.16E'%pi for pi in p]) \
                                                              for p in ups[1]]))
                logFile.write('\n  DP accuracy :  %.4e\n'%DP_stability[ups[0]])
                logFile.write('  QP accuracy :  %.4e\n'%QP_stability[ups[0]])
            logFile.write('</UPS_data>\n')

        logFile.write('\nData entries for the stability plot.\n')
        logFile.write('First row is a maximal accuracy delta, second is the '+\
                  'fraction of events with DP accuracy worse than delta.\n')
        logFile.write('<plot_data reduction=%s>\n'%xml_toolname.upper())
    # Set the x-range so that it spans [10**-17,10**(min_digit_accuracy)]
        if max(DP_stability)>0.0:
            largest_accuracy=max(DP_stability)
            min_digit_acc=(int(math.log(largest_accuracy)/math.log(10))
                           if math.isfinite(largest_accuracy) else 0)
            if min_digit_acc>=0:
                min_digit_acc = min_digit_acc+1
            min_digit_acc=max(-16,min(308,min_digit_acc))
            accuracies=[10**(-17+(i/5.0)) for i in range(5*(17+min_digit_acc)+1)]
        else:
            accuracies=[10**(-17+(i/5.0)) for i in range(5*17+1)]
            res_str_i += '\nPerfect accuracy over all the trial PS points.'

        accuracy_dict[toolname]=accuracies
        if max(accuracies) > max_acc: max_acc=max(accuracies)
        if min(accuracies) < min_acc: min_acc=min(accuracies)
        data_plot=[]
        for acc in accuracies:
            data_plot.append(float(len([d for d in DP_stability if d>acc]))\
                                                      /float(len(DP_stability)))
        data_plot_dict[toolname]=data_plot
        
        logFile.writelines('%.4e  %.4e\n'%(accuracies[i], data_plot[i]) for i in \
                                                         range(len(accuracies)))
        logFile.write('</plot_data>\n')
        logFile.write('\nList of accuracies recorded for the %i evaluations with %s\n'\
                                                                %(nPS,toolname))
        logFile.write('First row is DP, second is QP (if available).\n\n')
        logFile.write('<accuracies reduction=%s>\n'%xml_toolname.upper())
        logFile.writelines('%.4e  '%DP_stability[i]+('NA\n' if QP_stability[i]==-1.0 \
                             else '%.4e\n'%QP_stability[i]) for i in range(nPS))
        logFile.write('</accuracies>\n')
        res_str+=res_str_i
    logFile.close()
    res_str += "\n= Stability details of the run are output to the file"+\
                          " stability_%s_%s.log\n"%(mode,process.shell_string())
                          
    # Bypass the plotting if the madgraph logger has a FileHandler (like it is
    # done in the check command acceptance test) because in this case it makes
    # no sense to plot anything.
    if any(isinstance(handler,logging.FileHandler) for handler in \
                                        logging.getLogger('madgraph').handlers):
        return res_str

    try:
        import matplotlib.pyplot as plt
        colorlist=['b','r','g','y','m','c','k']
        for i,key in enumerate(data_plot_dict.keys()):
            color=colorlist[i]
            data_plot=data_plot_dict[key]
            accuracies=accuracy_dict[key]
            plt.plot(accuracies, data_plot, color=color, marker='', linestyle='-',\
                     label=key)
        plt.axis([min_acc,max_acc,\
                               10**(-int(math.log(nPSmax-0.5)/math.log(10))-1), 1])
        plt.yscale('log')
        plt.xscale('log')
        plt.title('Stability plot for %s (%s mode, %d points)'%\
                                           (process.nice_string()[9:],mode,nPSmax))
        plt.ylabel('Fraction of events')
        plt.xlabel('Maximal precision')
        plt.legend()
        if not reusing:
            logger.info('Some stability statistics will be displayed once you '+\
                                                        'close the plot window')
            plt.show()
        else:
            fig_output_file = str(pjoin(output_path, 
                     'stability_plot_%s_%s.png'%(mode,process.shell_string())))
            logger.info('Stability plot output to file %s. '%fig_output_file)
            plt.savefig(fig_output_file)
        return res_str
    except Exception as e:
        if isinstance(e, ImportError):
            res_str += "\n= Install matplotlib to get a "+\
                               "graphical display of the results of this check."
        else:
            res_str += "\n= Could not produce the stability plot because of "+\
                                                "the following error: %s"%str(e)
        return res_str
  
def output_timings(process, timings):
    """Present the result of a timings check in a nice format """
    
    # Define shortcut
    f = format_output
    loop_optimized_output = timings['loop_optimized_output']
    reduction_tool        = bannermod.MadLoopParam._ID_reduction_tool_map[
                                                      timings['reduction_tool']]
    
    res_str = "%s \n"%process.nice_string()
    try:
        gen_total = timings['HELAS_MODEL_compilation']+\
                    timings['HelasDiagrams_generation']+\
                    timings['Process_output']+\
                    timings['Diagrams_generation']+\
                    timings['Process_compilation']+\
                    timings['Initialization']
    except TypeError:
        gen_total = None
    res_str += "\n= Generation time total...... ========== %s\n"%f(gen_total,'%.3gs')
    res_str += "|= Diagrams generation....... %s\n"\
                                       %f(timings['Diagrams_generation'],'%.3gs')
    res_str += "|= Helas Diagrams generation. %s\n"\
                                  %f(timings['HelasDiagrams_generation'],'%.3gs')
    res_str += "|= Process output............ %s\n"\
                                            %f(timings['Process_output'],'%.3gs')
    res_str += "|= HELAS+model compilation... %s\n"\
                                   %f(timings['HELAS_MODEL_compilation'],'%.3gs')
    res_str += "|= Process compilation....... %s\n"\
                                       %f(timings['Process_compilation'],'%.3gs')
    res_str += "|= Initialization............ %s\n"\
                                            %f(timings['Initialization'],'%.3gs')

    res_str += "\n= Reduction tool tested...... %s\n"%reduction_tool
    res_str += "\n= Helicity sum time / PSpoint ========== %.3gms\n"\
                                    %(timings['run_unpolarized_total']*1000.0)
    if loop_optimized_output:
        coef_time=timings['run_unpolarized_coefs']*1000.0
        loop_time=(timings['run_unpolarized_total']-\
                                        timings['run_unpolarized_coefs'])*1000.0
        total=coef_time+loop_time
        res_str += "|= Coefs. computation time... %.3gms (%d%%)\n"\
                                  %(coef_time,int(round(100.0*coef_time/total)))
        res_str += "|= Loop evaluation time...... %.3gms (%d%%)\n"\
                                  %(loop_time,int(round(100.0*loop_time/total)))
    res_str += "\n= One helicity time / PSpoint ========== %.3gms\n"\
                                    %(timings['run_polarized_total']*1000.0)
    if loop_optimized_output:
        coef_time=timings['run_polarized_coefs']*1000.0
        loop_time=(timings['run_polarized_total']-\
                                        timings['run_polarized_coefs'])*1000.0
        total=coef_time+loop_time        
        res_str += "|= Coefs. computation time... %.3gms (%d%%)\n"\
                                  %(coef_time,int(round(100.0*coef_time/total)))
        res_str += "|= Loop evaluation time...... %.3gms (%d%%)\n"\
                                  %(loop_time,int(round(100.0*loop_time/total)))
    res_str += "\n= Miscellaneous ========================\n"
    res_str += "|= Number of hel. computed... %s/%s\n"\
                %(f(timings['n_contrib_hel'],'%d'),f(timings['n_tot_hel'],'%d'))
    res_str += "|= Number of loop diagrams... %s\n"%f(timings['n_loops'],'%d')
    if loop_optimized_output:
        res_str += "|= Number of loop groups..... %s\n"\
                                               %f(timings['n_loop_groups'],'%d')
        res_str += "|= Number of loop wfs........ %s\n"\
                                                  %f(timings['n_loop_wfs'],'%d')
        if timings['loop_wfs_ranks']!=None:
            for i, r in enumerate(timings['loop_wfs_ranks']):
                res_str += "||= # of loop wfs of rank %d.. %d\n"%(i,r)
    res_str += "|= Loading time (Color data). ~%.3gms\n"\
                                               %(timings['Booting_time']*1000.0)
    res_str += "|= Maximum RAM usage (rss)... %s\n"\
                                  %f(float(timings['ram_usage']/1000.0),'%.3gMb')                                            
    res_str += "\n= Output disk size =====================\n"
    res_str += "|= Source directory sources.. %s\n"%f(timings['du_source'],'%sb')
    res_str += "|= Process sources........... %s\n"%f(timings['du_process'],'%sb')    
    res_str += "|= Color and helicity data... %s\n"%f(timings['du_color'],'%sb')
    res_str += "|= Executable size........... %s\n"%f(timings['du_exe'],'%sb')
    
    return res_str

def output_comparisons(comparison_results):
    """Present the results of a comparison in a nice list format
       mode short: return the number of fail process
    """    
    proc_col_size = 17
    pert_coupl = comparison_results[0]['process']['perturbation_couplings']
    if pert_coupl:
        process_header = "Process [virt="+" ".join(pert_coupl)+"]"
    else:
        process_header = "Process"

    if len(process_header) + 1 > proc_col_size:
        proc_col_size = len(process_header) + 1

    for proc in comparison_results:
        if len(proc['process'].base_string()) + 1 > proc_col_size:
            proc_col_size = len(proc['process'].base_string()) + 1

    col_size = 18

    pass_proc = 0
    fail_proc = 0
    no_check_proc = 0

    failed_proc_list = []
    no_check_proc_list = []

    res_str = fixed_string_length(process_header, proc_col_size) + \
              fixed_string_length("Min element", col_size) + \
              fixed_string_length("Max element", col_size) + \
              fixed_string_length("Relative diff.", col_size) + \
              "Result"

    for result in comparison_results:
        proc = result['process'].base_string()
        values = result['values']
        
        if len(values) <= 1:
            res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                   "    * No permutations, process not checked *" 
            no_check_proc += 1
            no_check_proc_list.append(result['process'].nice_string())
            continue

        passed = result['passed']

        res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                   fixed_string_length("%1.10e" % min(values), col_size) + \
                   fixed_string_length("%1.10e" % max(values), col_size) + \
                   fixed_string_length("%1.10e" % result['difference'],
                                       col_size)
        if passed:
            pass_proc += 1
            res_str += "Passed"
        else:
            fail_proc += 1
            failed_proc_list.append(result['process'].nice_string())
            res_str += "Failed"

    res_str += "\nSummary: %i/%i passed, %i/%i failed" % \
                (pass_proc, pass_proc + fail_proc,
                 fail_proc, pass_proc + fail_proc)

    if fail_proc != 0:
        res_str += "\nFailed processes: %s" % ', '.join(failed_proc_list)
    if no_check_proc != 0:
        res_str += "\nNot checked processes: %s" % ', '.join(no_check_proc_list)

    return res_str

def fixed_string_length(mystr, length):
    """Helper function to fix the length of a string by cutting it 
    or adding extra space."""
    
    if len(mystr) > length:
        return mystr[0:length]
    else:
        return mystr + " " * (length - len(mystr))
    

#===============================================================================
# check_gauge
#===============================================================================
def check_gauge(processes, param_card = None,cuttools="", tir={}, reuse = False, 
                         options=None, output_path=None, cmd = FakeInterface()):
    """Check gauge invariance of the processes by using the BRS check.
    For one of the massless external bosons (e.g. gluon or photon), 
    replace the polarization vector (epsilon_mu) with its momentum (p_mu)
    """
    cmass_scheme = cmd.options['complex_mass_scheme']
    if isinstance(processes, base_objects.ProcessDefinition):
        # Generate a list of unique processes
        # Extract IS and FS ids
        multiprocess = processes

        model = multiprocess.get('model')        
        # Initialize matrix element evaluation
        if multiprocess.get('perturbation_couplings')==[]:
            evaluator = MatrixElementEvaluator(model, param_card,cmd= cmd,
                                           auth_skipping = True, reuse = False)
        else:
            evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                           cmd=cmd,model=model, param_card=param_card,
                                           auth_skipping = False, reuse = False,
                                           output_path=output_path)

        if not cmass_scheme and multiprocess.get('perturbation_couplings')==[]:
            # Set all widths to zero for gauge check
            logger.info('Set All width to zero for non complex mass scheme checks')
            for particle in evaluator.full_model.get('particles'):
                if particle.get('width') != 'ZERO':
                    evaluator.full_model.get('parameter_dict')[particle.get('width')] = 0.
        results = run_multiprocs_no_crossings(check_gauge_process,
                                           multiprocess,
                                           evaluator,
                                           options=options
                                           )
        
        if multiprocess.get('perturbation_couplings')!=[] and not reuse:
            # Clean temporary folders created for the running of the loop processes
            clean_up(output_path)
        
        return results

    elif isinstance(processes, base_objects.Process):
        processes = base_objects.ProcessList([processes])
    elif isinstance(processes, base_objects.ProcessList):
        pass
    else:
        raise InvalidCmd("processes is of non-supported format")

    assert processes, "No processes given"

    model = processes[0].get('model')

    # Initialize matrix element evaluation
    if processes[0].get('perturbation_couplings')==[]:
        evaluator = MatrixElementEvaluator(model, param_card,
                                       auth_skipping = True, reuse = False, 
                                       cmd = cmd)
    else:
        evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                           model=model, param_card=param_card,
                                           auth_skipping = False, reuse = False,
                                           output_path=output_path, cmd = cmd)
    comparison_results = []
    comparison_explicit_flip = []

    # For each process, make sure we have set up leg numbers:
    for process in processes:
        # Check if we already checked process
        #if check_already_checked([l.get('id') for l in process.get('legs') if \
        #                          not l.get('state')],
        ##                         [l.get('id') for l in process.get('legs') if \
        #                          l.get('state')],
        #                         sorted_ids, process, model):
        #    continue
        
        # Get process result
        result = check_gauge_process(process, evaluator,options=options)
        if result:
            comparison_results.append(result)

    if processes[0].get('perturbation_couplings')!=[] and not reuse:
        # Clean temporary folders created for the running of the loop processes
        clean_up(output_path)
            
    return comparison_results


def check_gauge_process(process, evaluator, options=None):
    """Check gauge invariance for the process, unless it is already done."""

    model = process.get('model')

    # Check that there are massless vector bosons in the process
    found_gauge = False
    for i, leg in enumerate(process.get('legs')):
        part = model.get_particle(leg.get('id'))
        if part.get('spin') == 3 and part.get('mass').lower() == 'zero':
            found_gauge = True
            break
    if not found_gauge:
        logger.info("No ward identity for %s" % \
                process.nice_string().replace('Process', 'process'))
        # This process can't be checked
        return None

    for i, leg in enumerate(process.get('legs')):
        leg.set('number', i+1)

    logger.info("Checking ward identities for %s" % \
                process.nice_string().replace('Process', 'process'))

    legs = process.get('legs')
    # Generate a process with these legs
    # Generate the amplitude for this process
    try:
        if process.get('perturbation_couplings')==[]:
            amplitude = diagram_generation.Amplitude(process)
        else:
            amplitude = loop_diagram_generation.LoopAmplitude(process)
    except InvalidCmd:
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None    
    if not amplitude.get('diagrams'):
        # This process has no diagrams; go to next process
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None
    # Generate the HelasMatrixElement for the process
    if not isinstance(amplitude,loop_diagram_generation.LoopAmplitude):
        matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                      gen_color = False)
    else:
        matrix_element = loop_helas_objects.LoopHelasMatrixElement(amplitude,
                               optimized_output=evaluator.loop_optimized_output)

    #p, w_rambo = evaluator.get_momenta(process)

#    MLOptions = {'ImprovePS':True,'ForceMP':True}

#    brsvalue = evaluator.evaluate_matrix_element(matrix_element, gauge_check = True,
#                                  output='jamp',MLOptions=MLOptions, options=options)

    brsvalue = evaluator.evaluate_matrix_element(matrix_element, gauge_check = True,
                                                 output='jamp', options=options)

    if not isinstance(amplitude,loop_diagram_generation.LoopAmplitude):
        matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                      gen_color = False)
          
    mvalue = evaluator.evaluate_matrix_element(matrix_element, gauge_check = False,
                                               output='jamp', options=options)
    
    if mvalue and mvalue['m2']:
        return {'process':process,'value':mvalue,'brs':brsvalue}

def output_gauge(comparison_results, output='text'):
    """Present the results of a comparison in a nice list format"""

    proc_col_size = 17
    
    pert_coupl = comparison_results[0]['process']['perturbation_couplings']
    
    # Of course, be more tolerant for loop processes
    if pert_coupl:
        threshold=1e-5
    else:
        threshold=1e-10
        
    if pert_coupl:
        process_header = "Process [virt="+" ".join(pert_coupl)+"]"
    else:
        process_header = "Process"

    if len(process_header) + 1 > proc_col_size:
        proc_col_size = len(process_header) + 1

    for one_comp in comparison_results:
        proc = one_comp['process'].base_string()
        mvalue = one_comp['value']
        brsvalue = one_comp['brs']
        if len(proc) + 1 > proc_col_size:
            proc_col_size = len(proc) + 1

    col_size = 18

    pass_proc = 0
    fail_proc = 0

    failed_proc_list = []
    no_check_proc_list = []

    res_str = fixed_string_length(process_header, proc_col_size) + \
              fixed_string_length("matrix", col_size) + \
              fixed_string_length("BRS", col_size) + \
              fixed_string_length("ratio", col_size) + \
              "Result"

    for  one_comp in comparison_results:
        proc = one_comp['process'].base_string()
        mvalue = one_comp['value']
        brsvalue = one_comp['brs']
        ratio = (abs(brsvalue['m2'])/abs(mvalue['m2']))
        res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                    fixed_string_length("%1.10e" % mvalue['m2'], col_size)+ \
                    fixed_string_length("%1.10e" % brsvalue['m2'], col_size)+ \
                    fixed_string_length("%1.10e" % ratio, col_size)
         
        if ratio > threshold:
            fail_proc += 1
            proc_succeed = False
            failed_proc_list.append(proc)
            res_str += "Failed"
        else:
            pass_proc += 1
            proc_succeed = True
            res_str += "Passed"

        #check all the JAMP
        # loop over jamp
        # This is not available for loop processes where the jamp list returned
        # is empty.
        if len(mvalue['jamp'])!=0:
            for k in range(len(mvalue['jamp'][0])):
                m_sum = 0
                brs_sum = 0
                # loop over helicity
                for j in range(len(mvalue['jamp'])):
                    #values for the different lorentz boost
                    m_sum += abs(mvalue['jamp'][j][k])**2
                    brs_sum += abs(brsvalue['jamp'][j][k])**2                                            
                        
                # Compare the different helicity  
                if not m_sum:
                    continue
                ratio = abs(brs_sum) / abs(m_sum)
    
                tmp_str = '\n' + fixed_string_length('   JAMP %s'%k , proc_col_size) + \
                       fixed_string_length("%1.10e" % m_sum, col_size) + \
                       fixed_string_length("%1.10e" % brs_sum, col_size) + \
                       fixed_string_length("%1.10e" % ratio, col_size)        
                       
                if ratio > 1e-15:
                    if not len(failed_proc_list) or failed_proc_list[-1] != proc:
                        fail_proc += 1
                        pass_proc -= 1
                        failed_proc_list.append(proc)
                    res_str += tmp_str + "Failed"
                elif not proc_succeed:
                     res_str += tmp_str + "Passed"


    res_str += "\nSummary: %i/%i passed, %i/%i failed" % \
                (pass_proc, pass_proc + fail_proc,
                 fail_proc, pass_proc + fail_proc)

    if fail_proc != 0:
        res_str += "\nFailed processes: %s" % ', '.join(failed_proc_list)

    if output=='text':
        return res_str
    else:
        return fail_proc
#===============================================================================
# check_lorentz
#===============================================================================
def check_lorentz(processes, param_card = None,cuttools="", tir={}, options=None, \
                 reuse = False, output_path=None, cmd = FakeInterface()):
    """ Check if the square matrix element (sum over helicity) is lorentz 
        invariant by boosting the momenta with different value."""

    cmass_scheme = cmd.options['complex_mass_scheme']
    if isinstance(processes, base_objects.ProcessDefinition):
        # Generate a list of unique processes
        # Extract IS and FS ids
        multiprocess = processes
        model = multiprocess.get('model')
        # Initialize matrix element evaluation
        if multiprocess.get('perturbation_couplings')==[]:
            evaluator = MatrixElementEvaluator(model,
                                cmd= cmd, auth_skipping = False, reuse = True)
        else:
            evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                     model=model, auth_skipping = False, reuse = True,
                                             output_path=output_path, cmd = cmd)

        if not cmass_scheme and processes.get('perturbation_couplings')==[]:
            # Set all widths to zero for lorentz check
            logger.info('Set All width to zero for non complex mass scheme checks')
            for particle in evaluator.full_model.get('particles'):
                if particle.get('width') != 'ZERO':
                    evaluator.full_model.get('parameter_dict')[\
                                                     particle.get('width')] = 0.

        results = run_multiprocs_no_crossings(check_lorentz_process,
                                           multiprocess,
                                           evaluator,
                                           options=options)

        if multiprocess.get('perturbation_couplings')!=[] and not reuse:
            # Clean temporary folders created for the running of the loop processes
            clean_up(output_path)
        
        return results
        
    elif isinstance(processes, base_objects.Process):
        processes = base_objects.ProcessList([processes])
    elif isinstance(processes, base_objects.ProcessList):
        pass
    else:
        raise InvalidCmd("processes is of non-supported format")

    assert processes, "No processes given"

    model = processes[0].get('model')

    # Initialize matrix element evaluation
    if processes[0].get('perturbation_couplings')==[]:
        evaluator = MatrixElementEvaluator(model, param_card,
                                       auth_skipping = False, reuse = True, 
                                       cmd=cmd)
    else:
        evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools, tir_dir=tir,
                                               model=model,param_card=param_card,
                                           auth_skipping = False, reuse = True,
                                           output_path=output_path, cmd = cmd)

    comparison_results = []

    # For each process, make sure we have set up leg numbers:
    for process in processes:
        # Check if we already checked process
        #if check_already_checked([l.get('id') for l in process.get('legs') if \
        #                          not l.get('state')],
        #                         [l.get('id') for l in process.get('legs') if \
        #                          l.get('state')],
        #                         sorted_ids, process, model):
        #    continue
        
        # Get process result
        result = check_lorentz_process(process, evaluator,options=options)
        if result:
            comparison_results.append(result)

    if processes[0].get('perturbation_couplings')!=[] and not reuse:
        # Clean temporary folders created for the running of the loop processes
        clean_up(output_path)

    return comparison_results


def check_lorentz_process(process, evaluator,options=None):
    """Check gauge invariance for the process, unless it is already done."""

    amp_results = []
    model = process.get('model')

    for i, leg in enumerate(process.get('legs')):
        leg.set('number', i+1)

    logger.info("Checking lorentz transformations for %s" % \
                process.nice_string().replace('Process:', 'process'))

    legs = process.get('legs')
    # Generate a process with these legs
    # Generate the amplitude for this process
    try:
        if process.get('perturbation_couplings')==[]:
            amplitude = diagram_generation.Amplitude(process)
        else:
            amplitude = loop_diagram_generation.LoopAmplitude(process)
    except InvalidCmd:
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None
    
    if not amplitude.get('diagrams'):
        # This process has no diagrams; go to next process
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None

     # Generate the HelasMatrixElement for the process
    p, w_rambo = evaluator.get_momenta(process, options)

    # Generate the HelasMatrixElement for the process
    if not isinstance(amplitude, loop_diagram_generation.LoopAmplitude):
        matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                               gen_color = True)
    else:
        matrix_element = loop_helas_objects.LoopHelasMatrixElement(amplitude,
                                       optimized_output = evaluator.loop_optimized_output)

    MLOptions = {'ImprovePS':True,'ForceMP':True}
    if not isinstance(amplitude, loop_diagram_generation.LoopAmplitude):
        data = evaluator.evaluate_matrix_element(matrix_element, p=p, output='jamp',
                                                 auth_skipping = True, options=options)
    else:
        data = evaluator.evaluate_matrix_element(matrix_element, p=p, output='jamp',
                auth_skipping = True, PS_name = 'original', MLOptions=MLOptions,
                                                              options = options)

    if data and data['m2']:
        if not isinstance(amplitude, loop_diagram_generation.LoopAmplitude):
            results = [data]
        else:
            results = [('Original evaluation',data)]
    else:
        return  {'process':process, 'results':'pass'}

    # The boosts are not precise enough for the loop evaluations and one need the
    # fortran improve_ps function of MadLoop to work. So we only consider the
    # boosts along the z directions for loops or simple rotations.
    if not isinstance(amplitude, loop_diagram_generation.LoopAmplitude):
        for boost in range(1,4):
            boost_p = boost_momenta(p, boost)
            results.append(evaluator.evaluate_matrix_element(matrix_element,
                                                    p=boost_p,output='jamp'))
    else:
        # We only consider the rotations around the z axis so to have the
        boost_p = boost_momenta(p, 3)
        results.append(('Z-axis boost',
            evaluator.evaluate_matrix_element(matrix_element, options=options,
            p=boost_p, PS_name='zBoost', output='jamp',MLOptions = MLOptions)))
        # We add here also the boost along x and y for reference. In the output
        # of the check, it is now clearly stated that MadLoop improve_ps script
        # will not work for them. The momenta read from event file are not
        # precise enough so these x/yBoost checks are omitted.
        if not options['events']:
            boost_p = boost_momenta(p, 1)
            results.append(('X-axis boost',
                evaluator.evaluate_matrix_element(matrix_element, options=options,
                p=boost_p, PS_name='xBoost', output='jamp',MLOptions = MLOptions)))
            boost_p = boost_momenta(p, 2)
            results.append(('Y-axis boost',
                evaluator.evaluate_matrix_element(matrix_element,options=options,
                p=boost_p, PS_name='yBoost', output='jamp',MLOptions = MLOptions)))
        # We only consider the rotations around the z axis so to have the 
        # improve_ps fortran routine work.
        rot_p = [[pm[0],-pm[2],pm[1],pm[3]] for pm in p]
        results.append(('Z-axis pi/2 rotation',
            evaluator.evaluate_matrix_element(matrix_element,options=options,
            p=rot_p, PS_name='Rotation1', output='jamp',MLOptions = MLOptions)))
        # Now a pi/4 rotation around the z-axis
        sq2 = math.sqrt(2.0)
        rot_p = [[pm[0],(pm[1]-pm[2])/sq2,(pm[1]+pm[2])/sq2,pm[3]] for pm in p]
        results.append(('Z-axis pi/4 rotation',
            evaluator.evaluate_matrix_element(matrix_element,options=options,
            p=rot_p, PS_name='Rotation2', output='jamp',MLOptions = MLOptions)))
            
        
    return {'process': process, 'results': results}

#===============================================================================
# check_flavor
#===============================================================================
def check_flavor(process_definition, param_card=None, options=None,
                 cmd=FakeInterface()):
    """Check that the merged-flavor matrix element agrees with the individual-
    flavor matrix elements for each subprocess.

    For each individual-flavor subprocess (e.g. ``u u~ > t t~``, ``d d~ > t t~``,
    etc.) the function evaluates:

    1. The matrix element using the *merged* model with explicit flavor tags on
       the external legs (so the merged coupling selects the correct flavor).
    2. The matrix element for the same individual subprocess using the *unmerged*
       model at the *same* phase-space point.

    The two results are compared.  A successful check means both evaluations
    agree to within a relative tolerance.

    Parameters
    ----------
    process_definition : base_objects.ProcessDefinition
        The process definition (may contain merged-flavor multi-legs such as
        ``p``, ``_quark``, etc.).
    param_card : str or None
        Path to a param_card file.  If *None* the model defaults are used.
    options : dict or None
        Optional dict with keys understood by ``MatrixElementEvaluator`` (e.g.
        ``'energy'``).
    cmd : interface object
        Interface object providing ``cmd.options`` etc.

    Returns
    -------
    list of dict
        Each dict has the keys:
        ``'process'``       – the *individual-flavor* process string,
        ``'value_merged'``  – ``{'m2': float, 'jamp': ...}`` from merged model
                              (or ``None`` if no diagrams / evaluation failed),
        ``'value_unmerged'``– same dict from the unmerged model.
    """
    if not isinstance(process_definition, base_objects.ProcessDefinition):
        raise InvalidCmd(
            "check_flavor requires a ProcessDefinition (multiprocess) object")

    if options is None:
        options = {}

    multiprocess = process_definition
    merged_model = multiprocess.get('model')
    cmass_scheme = cmd.options['complex_mass_scheme']

    # Determine the set of merged particle PDG codes and their constituents.
    merged_particles = merged_model.get('merged_particles')  # {merged_pdg: [individual_pdgs]}

    def expand_ids(pdg_code):
        """Return list of individual pdg codes for a potentially merged one."""
        apg = abs(pdg_code)
        if apg in merged_particles:
            sub_ids = merged_particles[apg]
            if pdg_code > 0:
                return [i for i in sub_ids if i > 0]
            else:
                return [-i for i in sub_ids if i > 0]
        return [pdg_code]

    # ── 1. Set up the merged-model evaluator ─────────────────────────────────
    # Use reuse=True: all individual-flavor processes for the same merged
    # process share the same matrix class (the merged PDG codes give the same
    # shell_string), and flavor is a runtime argument passed to smatrix, so
    # the class can safely be reused across different flavor evaluations.
    # Keep reuse disabled here: Matrix_* classes are module globals keyed only
    # by process shell string, so reusing across the merged/unmerged evaluators
    # can pick up a class generated with the other model.
    evaluator_merged = MatrixElementEvaluator(merged_model, param_card,
                                              cmd=cmd,
                                              auth_skipping=False, reuse=False)
    if not cmass_scheme and multiprocess.get('perturbation_couplings') == []:
        logger.info('Setting all widths to zero for flavor check')
        for particle in evaluator_merged.full_model.get('particles'):
            if particle.get('width') != 'ZERO':
                evaluator_merged.full_model.get('parameter_dict')[
                    particle.get('width')] = 0.

    # ── 2. Import the same model *without* flavor grouping ───────────────────
    # Using unmerge_flavors() on a deep-copy can leave color-algebra objects in
    # an array form that the color module cannot handle.  Importing the model
    # fresh with apply_flavor_grouping=False gives clean color objects.
    model_path = merged_model.get('modelpath')
    unmerged_model = import_ufo.import_model(model_path,
                                             options={'apply_flavor_grouping': False})

    evaluator_unmerged = MatrixElementEvaluator(unmerged_model, param_card,
                                                cmd=cmd,
                                                auth_skipping=False, reuse=False)
    if not cmass_scheme:
        for particle in evaluator_unmerged.full_model.get('particles'):
            if particle.get('width') != 'ZERO':
                evaluator_unmerged.full_model.get('parameter_dict')[
                    particle.get('width')] = 0.

    # ── 3. Build the list of individual-flavor processes to check ────────────
    # For each multileg combination in the process definition, expand every
    # merged-particle id into its constituent individual ids.
    is_id_options_merged  = [leg.get('ids') for leg in multiprocess.get('legs')
                             if not leg.get('state')]
    fs_id_options_merged  = [leg.get('ids') for leg in multiprocess.get('legs')
                             if leg.get('state')]
    is_id_options_indiv   = [sum([expand_ids(i) for i in ids], [])
                             for ids in is_id_options_merged]
    fs_id_options_indiv   = [sum([expand_ids(i) for i in ids], [])
                             for ids in fs_id_options_merged]

    results = []
    checked = set()   # avoid duplicate (is_ids, fs_ids) combinations

    for is_flavor_ids in itertools.product(*is_id_options_indiv):
        for fs_flavor_ids in itertools.product(*fs_id_options_indiv):
            key = (is_flavor_ids, fs_flavor_ids)
            if key in checked:
                continue
            checked.add(key)

            # ── 3a. Unmerged evaluation ──────────────────────────────────────
            unmerged_legs = base_objects.LegList(
                [base_objects.Leg({'id': id, 'state': False})
                 for id in is_flavor_ids] +
                [base_objects.Leg({'id': id, 'state': True})
                 for id in fs_flavor_ids])
            unmerged_proc = base_objects.Process({
                'legs': unmerged_legs,
                'model': unmerged_model,
                'orders': multiprocess.get('orders'),
                'forbidden_particles': multiprocess.get('forbidden_particles'),
                'forbidden_onsh_s_channels': multiprocess.get('forbidden_onsh_s_channels'),
                'forbidden_s_channels': multiprocess.get('forbidden_s_channels'),
                'perturbation_couplings': multiprocess.get('perturbation_couplings'),
            })
            for i, leg in enumerate(unmerged_proc.get('legs')):
                leg.set('number', i + 1)

            logger.info("Flavor check (unmerged): %s" %
                        unmerged_proc.nice_string().replace('Process:', 'process'))

            try:
                amplitude_u = diagram_generation.Amplitude(unmerged_proc)
            except InvalidCmd:
                continue
            if not amplitude_u.get('diagrams'):
                continue

            p, _ = evaluator_unmerged.get_momenta(unmerged_proc, options)
            me_u = helas_objects.HelasMatrixElement(amplitude_u, gen_color=True)
            val_unmerged = evaluator_unmerged.evaluate_matrix_element(
                me_u, p=p, output='jamp', options=options)

            # ── 3b. Merged evaluation with explicit flavor tags on legs ──────
            # Map each individual-flavor id back to the merged-particle id (if
            # it belongs to a merged group) and set the flavor attribute on the
            # leg so the ALOHA routine selects the correct coupling entry.
            # The FLV_Coupling convention always uses the POSITIVE (particle)
            # PDG code as the flavor key, even for antiparticle legs.
            merged_legs_list = []
            for is_id_individual in is_flavor_ids:
                merged_id = is_id_individual
                flav_tag = []
                for mpdg, sub_ids in merged_particles.items():
                    if abs(is_id_individual) in sub_ids:
                        # Use the merged-particle id (preserving sign for
                        # particle/anti-particle), and the POSITIVE individual
                        # pdg as the flavor tag.
                        merged_id = mpdg if is_id_individual > 0 else -mpdg
                        flav_tag = [abs(is_id_individual)]
                        break
                merged_legs_list.append(
                    base_objects.Leg({'id': merged_id, 'state': False,
                                      'flavor': flav_tag}))
            for fs_id_individual in fs_flavor_ids:
                merged_id = fs_id_individual
                flav_tag = []
                for mpdg, sub_ids in merged_particles.items():
                    if abs(fs_id_individual) in sub_ids:
                        merged_id = mpdg if fs_id_individual > 0 else -mpdg
                        flav_tag = [abs(fs_id_individual)]
                        break
                merged_legs_list.append(
                    base_objects.Leg({'id': merged_id, 'state': True,
                                      'flavor': flav_tag}))

            merged_proc = base_objects.Process({
                'legs': base_objects.LegList(merged_legs_list),
                'model': merged_model,
                'orders': multiprocess.get('orders'),
                'forbidden_particles': multiprocess.get('forbidden_particles'),
                'forbidden_onsh_s_channels': multiprocess.get('forbidden_onsh_s_channels'),
                'forbidden_s_channels': multiprocess.get('forbidden_s_channels'),
                'perturbation_couplings': multiprocess.get('perturbation_couplings'),
            })
            for i, leg in enumerate(merged_proc.get('legs')):
                leg.set('number', i + 1)

            logger.info("Flavor check (merged):   %s" %
                        merged_proc.nice_string().replace('Process:', 'process'))

            val_merged = None
            try:
                amplitude_m = diagram_generation.Amplitude(merged_proc)
            except InvalidCmd:
                amplitude_m = None
            if amplitude_m and amplitude_m.get('diagrams'):
                me_m = helas_objects.HelasMatrixElement(amplitude_m, gen_color=True)
                val_merged = evaluator_merged.evaluate_matrix_element(
                    me_m, p=p, output='jamp', options=options)

            results.append({
                'process': unmerged_proc,
                'value_merged': val_merged,
                'value_unmerged': val_unmerged,
            })

    clean_added_globals(ADDED_GLOBAL)
    return results



def output_flavor(comparison_results, output='text'):
    """Present the results of a flavor check in a nice table.

    Compares the matrix element from the *merged* model against the same
    matrix element computed with the *unmerged* model for each individual
    flavor subprocess.

    Parameters
    ----------
    comparison_results : list of dict
        As returned by :func:`check_flavor`.
    output : {'text', 'fail'}
        If ``'fail'``, return the number of failed processes instead of the
        formatted string.

    Returns
    -------
    str or int
        Formatted results table (``output='text'``) or number of failures.
    """
    proc_col_size = 17
    process_header = "Process"

    for data in comparison_results:
        proc = data['process'].base_string()
        if len(proc) + 1 > proc_col_size:
            proc_col_size = len(proc) + 1

    col_size = 18

    pass_proc = 0
    fail_proc = 0
    no_check_proc = 0
    failed_proc_list = []
    no_check_proc_list = []

    res_str = fixed_string_length(process_header, proc_col_size) + \
              fixed_string_length("Merged", col_size) + \
              fixed_string_length("Unmerged", col_size) + \
              fixed_string_length("Relative diff.", col_size) + \
              "Result"

    for one_comp in comparison_results:
        proc = one_comp['process'].base_string()
        val_m = one_comp['value_merged']
        val_u = one_comp['value_unmerged']

        if val_m is None or val_u is None:
            no_check_proc += 1
            no_check_proc_list.append(proc)
            res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                       "    * No matrix element, process not checked *"
            continue

        m2_merged   = val_m['m2']
        m2_unmerged = val_u['m2']

        if m2_merged == 0 and m2_unmerged == 0:
            no_check_proc += 1
            no_check_proc_list.append(proc)
            res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                       "    * Both matrix elements are zero, process not checked *"
            continue

        ref = abs(m2_merged) if m2_merged != 0 else abs(m2_unmerged)
        diff = abs(m2_merged - m2_unmerged) / ref

        res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                   fixed_string_length("%1.10e" % m2_merged, col_size) + \
                   fixed_string_length("%1.10e" % m2_unmerged, col_size) + \
                   fixed_string_length("%1.10e" % diff, col_size)

        if diff < 1e-6:
            pass_proc += 1
            res_str += "Passed"
        else:
            fail_proc += 1
            failed_proc_list.append(proc)
            res_str += "Failed"

    res_str += "\nSummary: %i/%i passed, %i/%i failed" % (
        pass_proc, pass_proc + fail_proc,
        fail_proc, pass_proc + fail_proc)

    if fail_proc:
        res_str += "\nFailed processes: %s" % ', '.join(failed_proc_list)
    if no_check_proc:
        res_str += "\nNot checked processes: %s" % ', '.join(no_check_proc_list)

    if output == 'text':
        return res_str
    else:
        return fail_proc


#===============================================================================
# Marsaglia-Zaman RNG matching the check_sa Fortran/C++ template seed
#===============================================================================
class _Ranmar(object):
    """Marsaglia-Zaman RNG used in the check_sa Fortran/C++ templates.

    Initialising with the same seeds as the templates (``ij=1802, kl=9373``)
    and drawing numbers in the same sequence gives identical RAMBO phase-space
    points, allowing the Python backend in ``check_language`` to compare
    against Fortran/C++ results without relying on printed momenta.
    """

    def __init__(self, ij=1802, kl=9373):
        self.ranu = [0.0] * 98
        self.rmarin(ij, kl)

    def rmarin(self, ij, kl):
        i = (ij // 177) % 177 + 2
        j = ij % 177 + 2
        k = (kl // 169) % 178 + 1
        l = kl % 169
        for ii in range(1, 98):
            s = 0.0
            t = 0.5
            for _ in range(24):
                m = ((i * j) % 179 * k) % 179
                i, j, k = j, k, m
                l = (53 * l + 1) % 169
                if (l * m) % 64 >= 32:
                    s += t
                t *= 0.5
            self.ranu[ii] = s
        self.ranc = 362436.0 / 16777216.0
        self.rancd = 7654321.0 / 16777216.0
        self.rancm = 16777213.0 / 16777216.0
        self.iranmr = 97
        self.jranmr = 33

    def ranmar(self):
        uni = self.ranu[self.iranmr] - self.ranu[self.jranmr]
        if uni < 0.0:
            uni += 1.0
        self.ranu[self.iranmr] = uni
        self.iranmr -= 1
        self.jranmr -= 1
        if self.iranmr == 0:
            self.iranmr = 97
        if self.jranmr == 0:
            self.jranmr = 97
        self.ranc -= self.rancd
        if self.ranc < 0.0:
            self.ranc += self.rancm
        uni -= self.ranc
        if uni < 0.0:
            uni += 1.0
        return uni

    def rn(self):
        out = self.ranmar()
        while out < 1e-16:
            out = self.ranmar()
        return out


@contextlib.contextmanager
def _seeded_rambo_rng(ij=1802, kl=9373):
    """Context manager that temporarily replaces ``rambo.random_nb`` with a
    fresh Marsaglia-Zaman RNG seeded with *(ij, kl)*.

    This gives a deterministic RAMBO phase-space point that matches the one
    produced by the check_sa Fortran/C++ binaries, which use the same seed
    convention.

    .. warning::
        This patches a module-level function and is therefore **not
        thread-safe**.  It should only be used in single-threaded context such
        as the interactive check command.
    """
    rng = _Ranmar(ij, kl)
    old_random_nb = rambo.random_nb
    rambo.random_nb = lambda _dummy: rng.rn()
    try:
        yield rng
    finally:
        rambo.random_nb = old_random_nb


def _get_seeded_python_momenta(proc, evaluator_obj, energy_value):
    """Generate Python momenta with the same RAMBO RNG seed as check_sa.

    Uses :func:`_seeded_rambo_rng` to temporarily replace ``rambo.random_nb``
    with a fresh Marsaglia-Zaman RNG (seeds ``1802, 9373``) identical to those
    hard-coded in the Fortran/C++ check_sa templates, so that all three
    backends in ``check_language`` share the same phase-space point without
    relying on parsed printed output.

    Returns ``None`` on any error.
    """
    if evaluator_obj is None:
        return None
    try:
        with _seeded_rambo_rng(1802, 9373):
            seeded_options = {'energy': float(energy_value),
                              'events': None,
                              'skip_evt': 0}
            p_seeded, _ = evaluator_obj.get_momenta(proc, seeded_options)
        return p_seeded
    except Exception:
        return None


#===============================================================================
# check_language
#===============================================================================
def check_language(process_definition, param_card=None, options=None,
                   cmd=FakeInterface()):
    """Compare Fortran SA, C++ SA and Python matrix elements for each process
    in *process_definition*.

    For each process the function:

    1. Generates a Fortran standalone (SA) directory, compiles it, and runs
       ``./check <energy>`` where *energy* is fixed so that both backends use
       the same RAMBO seed → identical phase-space points.
    2. Does the same with the C++ SA back-end.
    3. Evaluates the matrix element in pure Python using the phase-space
       point printed by the SA binaries (so all three backends see the same
       momenta).
    4. Parses the outputs, extracts the per-flavor |M|² values, and compares
       all three backends.

    The centre-of-mass energy defaults to 1000 GeV and can be overridden via
    ``options['energy']``.

    Parameters
    ----------
    process_definition : base_objects.ProcessDefinition or base_objects.Process
        The process to check.
    param_card : str or None
        Path to a ``param_card.dat`` file.  *None* uses model defaults.
    options : dict or None
        Optional dict.  Recognised key: ``'energy'`` (float, GeV).
    cmd : interface object
        Interface object providing ``cmd.options`` and ``cmd._mgme_dir``.

    Returns
    -------
    list of dict
        One entry per process.  Each dict has the keys:

        ``'process'``       – :class:`base_objects.Process`,
        ``'value_fortran'`` – ``{'m2': float}`` or ``None``,
        ``'value_cpp'``     – ``{'m2': float}`` or ``None``,
        ``'value_mg7'``     – ``{'m2': float}`` or ``None``,
        ``'value_python'``  – ``{'m2': float}`` or ``None``,
        ``'momenta'``       – phase-space point (list of 4-vectors) or ``None``.
    """
    import madgraph.iolibs.export_v4 as export_v4
    import madgraph.iolibs.export_cpp as export_cpp
    import tempfile

    if options is None:
        options = {}

    energy = float(options.get('energy', 1000.0))

    # Compiler availability
    has_fortran = bool(misc.which('gfortran') or
                       (hasattr(cmd, 'options') and
                        cmd.options.get('fortran_compiler')))
    has_cpp     = bool(misc.which('g++') or
                       (hasattr(cmd, 'options') and
                        cmd.options.get('cpp_compiler')))
    fortran_compiler = (hasattr(cmd, 'options') and
                        cmd.options.get('fortran_compiler')) or 'gfortran'
    cpp_compiler     = (hasattr(cmd, 'options') and
                        cmd.options.get('cpp_compiler'))     or 'g++'

    # MG7 (standalone / madmatrix) availability: needs the madmatrix
    # package, a C++ compiler and make.  Its check_sa.exe "matrix" mode
    # evaluates the same phase-space point as the Fortran/C++ drivers and
    # prints the per-flavor PDG / matrix-element lines in the same format.
    try:
        from madmatrix import output as madmatrix_output
        from madmatrix import model_handling as madmatrix_model_handling
        has_mg7 = has_cpp and bool(misc.which('make'))
    except ImportError:
        has_mg7 = False

    # Ensure Template/LO/Source/make_opts exists (written on first MG5 run).
    make_opts     = pjoin(MG5DIR, 'Template', 'LO', 'Source', 'make_opts')
    make_opts_src = pjoin(MG5DIR, 'Template', 'LO', 'Source', '.make_opts')
    if not os.path.exists(make_opts) and os.path.exists(make_opts_src):
        shutil.copy(make_opts_src, make_opts)

    # ── helpers ──────────────────────────────────────────────────────────────
    _me_re  = re.compile(
        r"\sMatrix\selement\s=\s*(?P<val>-?\d*\.\d*(E[+-]?\d*)?)"
        r"\s*GeV\^\s*(?P<pow>-?\d+)", re.IGNORECASE | re.VERBOSE)
    _mom_re = re.compile(
        r"""\s*\d+\s+(?P<p0>-?\d*\.\d*E[+-]?\d*)\s+
             (?P<p1>-?\d*\.\d*E[+-]?\d*)\s+
             (?P<p2>-?\d*\.\d*E[+-]?\d*)\s+
             (?P<p3>-?\d*\.\d*E[+-]?\d*)""",
        re.IGNORECASE | re.VERBOSE)
    # Matches the "PDG  2  -2  6  -6" lines written by the flavor loop.
    _pdg_re = re.compile(r'^\s*PDG\s+(.+)$', re.IGNORECASE)

    def _parse_all_flavors_dict(text):
        """Parse ALL PDG blocks in SA output.

        Returns an OrderedDict mapping ``pdg_tuple → me_value``.
        Each PDG line like ``PDG 2 -2 23 21`` followed by a
        ``Matrix element = ...`` line produces one entry.
        """
        from collections import OrderedDict
        result = OrderedDict()
        current_pdgs = None
        for line in text.split('\n'):
            mp = _pdg_re.match(line)
            if mp:
                try:
                    current_pdgs = tuple(int(x) for x in mp.group(1).split())
                except ValueError:
                    current_pdgs = None
            m = _me_re.match(line)
            if m:
                val = float(m.group('val'))
                key = current_pdgs  # None when no PDG line precedes this ME
                if key not in result:  # keep first occurrence per combination
                    result[key] = val
                current_pdgs = None
        return result

    def _parse_momenta(text):
        """Parse the phase-space point printed once per SA run.

        Returns the first contiguous block of momentum lines (stopping at the
        first non-matching line), so the per-flavor matrix element values that
        follow do not leak into the list.
        """
        momenta = []
        started = False
        for line in text.split('\n'):
            m = _mom_re.match(line)
            if m:
                momenta.append([float(x) for x in m.groups()[:4]])
                started = True
            elif started:
                break
        return momenta

    def _pdg_tuple_to_label(pdg_tuple, m, proc):
        """Convert a tuple of PDG codes to a human-readable process label.

        E.g. ``(2, -2, 23, 21)`` → ``'u u~ > z g'``.
        Falls back to a numeric string on any error.
        """
        try:
            ninitial = sum(1 for l in proc.get('legs') if not l.get('state'))
            names = []
            for pdg in pdg_tuple:
                part = m.get_particle(pdg)
                names.append(part.get_name() if part else str(pdg))
            return (' '.join(names[:ninitial]) + ' > ' +
                    ' '.join(names[ninitial:]))
        except Exception:
            return str(pdg_tuple)

    def _parse_sa_output(text, target_pdgs=None):
        """Parse stdout of a SA check binary; return (me_value, momenta).

        Matches the per-flavor PDG block to *target_pdgs* when provided.
        Falls back to the last seen ME value when no match is found.
        """
        me_val, momenta = None, []
        last_val = None
        current_pdgs = None
        for line in text.split('\n'):
            mp = _pdg_re.match(line)
            if mp:
                try:
                    current_pdgs = [int(x) for x in mp.group(1).split()]
                except ValueError:
                    current_pdgs = None
            m = _me_re.match(line)
            if m:
                val = float(m.group('val'))
                last_val = val
                if target_pdgs is not None and current_pdgs is not None:
                    if current_pdgs == list(target_pdgs):
                        me_val = val
                else:
                    me_val = val
                current_pdgs = None
            m2 = _mom_re.match(line)
            if m2:
                momenta.append([float(x) for x in m2.groups()[:4]])
        if target_pdgs is not None and me_val is None:
            me_val = last_val
        return me_val, momenta

    # ── resolve process list ──────────────────────────────────────────────────
    if isinstance(process_definition, base_objects.ProcessDefinition):
        model = process_definition.get('model')
        is_id_options = [leg.get('ids') for leg in process_definition.get('legs')
                         if not leg.get('state')]
        fs_id_options = [leg.get('ids') for leg in process_definition.get('legs')
                         if leg.get('state')]
        proc_list = []
        checked   = set()
        for is_ids in itertools.product(*is_id_options):
            for fs_ids in itertools.product(*fs_id_options):
                key = (is_ids, fs_ids)
                if key in checked:
                    continue
                checked.add(key)
                legs = base_objects.LegList(
                    [base_objects.Leg({'id': i, 'state': False}) for i in is_ids] +
                    [base_objects.Leg({'id': i, 'state': True})  for i in fs_ids])
                proc = base_objects.Process({
                    'legs': legs,
                    'model': model,
                    'orders': process_definition.get('orders'),
                    'forbidden_particles':
                        process_definition.get('forbidden_particles'),
                    'forbidden_onsh_s_channels':
                        process_definition.get('forbidden_onsh_s_channels'),
                    'forbidden_s_channels':
                        process_definition.get('forbidden_s_channels'),
                    'perturbation_couplings':
                        process_definition.get('perturbation_couplings'),
                })
                for idx, leg in enumerate(proc.get('legs')):
                    leg.set('number', idx + 1)
                proc_list.append(proc)
    else:
        model     = process_definition.get('model')
        proc_list = [process_definition]

    mg5opt = {
        'fortran_compiler': fortran_compiler,
        'cpp_compiler':     cpp_compiler,
        'f2py_compiler':    'f2py',
        'output_dependencies': 'external',
    }

    # ── Python evaluator (always available – pure-Python back-end) ────────────
    has_python = True
    evaluator = None
    try:
        # Keep reuse disabled to avoid reusing Matrix_* globals generated in a
        # previous check command with a different model.
        evaluator = MatrixElementEvaluator(model, param_card, cmd=cmd,
                                           auth_skipping=False, reuse=False)
    except Exception as err:
        logger.info("Language check: Python evaluator setup failed: %s" % err)
        has_python = False

    # Merged-particle map used to set per-leg flavor tags when the SA output
    # iterates over individual flavors of a merged multi-leg.
    try:
        merged_particles = model.get('merged_particles') or {}
    except Exception:
        merged_particles = {}

    results = []
    # Cache SA output text (stdout of ./check <energy>) keyed by the leg-id
    # tuple.  All individual-flavor procs share the same matrix element code.
    sa_f_output_cache   = {}
    sa_cpp_output_cache = {}
    # Cache of MG7 (standalone / madmatrix) check_sa.exe matrix-mode output text.
    sa_mg7_output_cache = {}

    energy_str = str(energy)

    for proc in proc_list:
        try:
            amplitude = diagram_generation.Amplitude(proc)
        except InvalidCmd:
            continue
        if not amplitude.get('diagrams'):
            continue

        logger.info("Language check: %s" %
                    proc.nice_string().replace('Process:', 'process'))

        me = helas_objects.HelasMatrixElement(amplitude, gen_color=True)
        wl = misc.make_unique(me.get_used_lorentz())
        _seen_wc = set()
        wc = []
        for l in me.get_used_couplings():
            for c in l:
                key_c = c if isinstance(c, str) else c.get('name')
                if key_c not in _seen_wc:
                    _seen_wc.add(key_c)
                    wc.append(c)

        sa_key = tuple(leg.get('id') for leg in proc.get('legs'))

        # ── Fortran SA ───────────────────────────────────────────────────────
        out_f_text = None
        if has_fortran:
            if sa_key not in sa_f_output_cache:
                sa_f_output_cache[sa_key] = None
                parent_f  = tempfile.mkdtemp(prefix='mg5_langcheck_f_')
                sa_dir_f  = pjoin(parent_f, 'sa_f')
                try:
                    opt_f = {'sa_symmetry': False, 'export_format': 'standalone_fortran',
                             'mp': False, 'v5_model': True,
                             'output_options': {'noeps': 'True'}}
                    exporter_f = export_v4.ProcessExporterFortranSA(sa_dir_f, opt_f)
                    fmodel = helas_call_writers.FortranUFOHelasCallWriter(model)
                    exporter_f.copy_template(model)
                    me_f = copy.deepcopy(me)
                    exporter_f.generate_subprocess_directory(me_f, fmodel, 0)
                    exporter_f.convert_model(model, wl, wc)
                    exporter_f.finalize({'matrix_elements': [me_f]}, '',
                                        mg5opt, ['nojpeg'])
                    p_dirs_f = sorted([
                        d for d in os.listdir(pjoin(sa_dir_f, 'SubProcesses'))
                        if d.startswith('P') and
                        os.path.isdir(pjoin(sa_dir_f, 'SubProcesses', d))])
                    if p_dirs_f:
                        check_dir_f = pjoin(sa_dir_f, 'SubProcesses', p_dirs_f[0])
                        with open(os.devnull, 'w') as devnull:
                            ret = subprocess.call(['make', 'check'],
                                                  cwd=check_dir_f,
                                                  stdout=devnull, stderr=devnull)
                        if ret == 0:
                            try:
                                out_f = subprocess.check_output(
                                    ['./check', energy_str],
                                    cwd=check_dir_f,
                                    stderr=subprocess.STDOUT).decode()
                                sa_f_output_cache[sa_key] = out_f
                            except Exception:
                                pass
                except Exception as err:
                    logger.info("Language check: Fortran SA failed for %s: %s"
                                % (proc.nice_string(), err))
                finally:
                    shutil.rmtree(parent_f, ignore_errors=True)

            out_f_text = sa_f_output_cache.get(sa_key)

        # ── C++ SA ───────────────────────────────────────────────────────────
        out_cpp_text = None
        if has_cpp:
            if sa_key not in sa_cpp_output_cache:
                sa_cpp_output_cache[sa_key] = None
                parent_cpp = tempfile.mkdtemp(prefix='mg5_langcheck_cpp_')
                sa_dir_cpp = pjoin(parent_cpp, 'sa_cpp')
                try:
                    opt_cpp = {'sa_symmetry': False,
                               'export_format': 'standalone_cpp',
                               'mp': False, 'v5_model': True,
                               'cpp_compiler': cpp_compiler}
                    exporter_cpp = export_cpp.ProcessExporterCPP(sa_dir_cpp,
                                                                  opt_cpp)
                    cpp_model = helas_call_writers.CPPUFOHelasCallWriter(model)
                    exporter_cpp.copy_template(model)
                    me_cpp_sa = copy.deepcopy(me)
                    exporter_cpp.generate_subprocess_directory(me_cpp_sa,
                                                               cpp_model, 0)
                    exporter_cpp.convert_model(model, wl, wc)
                    exporter_cpp.finalize({'matrix_elements': [me_cpp_sa]},
                                          '', mg5opt, ['nojpeg'])
                    p_dirs_cpp = sorted([
                        d for d in os.listdir(pjoin(sa_dir_cpp, 'SubProcesses'))
                        if d.startswith('P') and
                        os.path.isdir(pjoin(sa_dir_cpp, 'SubProcesses', d))])
                    if p_dirs_cpp:
                        check_dir_cpp = pjoin(sa_dir_cpp, 'SubProcesses',
                                              p_dirs_cpp[0])
                        with open(os.devnull, 'w') as devnull:
                            ret = subprocess.call(['make', 'check'],
                                                  cwd=check_dir_cpp,
                                                  stdout=devnull, stderr=devnull)
                        if ret == 0:
                            try:
                                out_cpp = subprocess.check_output(
                                    ['./check', energy_str],
                                    cwd=check_dir_cpp,
                                    stderr=subprocess.STDOUT).decode()
                                sa_cpp_output_cache[sa_key] = out_cpp
                            except Exception:
                                pass
                except Exception as err:
                    logger.info("Language check: C++ SA failed for %s: %s"
                                % (proc.nice_string(), err))
                finally:
                    shutil.rmtree(parent_cpp, ignore_errors=True)

            out_cpp_text = sa_cpp_output_cache.get(sa_key)

        # ── MG7 SA (standalone / madmatrix) ─────────────────────────────────
        out_mg7_text = None
        if has_mg7:
            if sa_key not in sa_mg7_output_cache:
                sa_mg7_output_cache[sa_key] = {}
                parent_mg7 = tempfile.mkdtemp(prefix='mg5_langcheck_mg7_')
                sa_dir_mg7 = pjoin(parent_mg7, 'sa_mg7')
                try:
                    opt_mg7 = {'export_format': 'standalone',
                               'mp': False, 'v5_model': True,
                               'cpp_compiler': cpp_compiler,
                               'output_options': {}}
                    exporter_mg7 = madmatrix_output.\
                        ProcessExporterMadMatrixStandalone(sa_dir_mg7, opt_mg7)
                    mg7_writer = madmatrix_model_handling.\
                        MadMatrixUFOHelasCallWriter(model)
                    exporter_mg7.copy_template(model)
                    me_mg7 = copy.deepcopy(me)
                    exporter_mg7.generate_subprocess_directory(me_mg7,
                                                               mg7_writer, 0)
                    exporter_mg7.convert_model(model, wl, wc)
                    exporter_mg7.finalize({'matrix_elements': [me_mg7]}, '',
                                          mg5opt, ['nojpeg'])
                    p_dirs_mg7 = sorted([
                        d for d in os.listdir(pjoin(sa_dir_mg7, 'SubProcesses'))
                        if d.startswith('P') and
                        os.path.isdir(pjoin(sa_dir_mg7, 'SubProcesses', d))])
                    if p_dirs_mg7:
                        check_dir_mg7 = pjoin(sa_dir_mg7, 'SubProcesses',
                                              p_dirs_mg7[0])
                        backends = ["scalar", "simd_128", "simd_256", "simd_512", "cuda", "hip"]
                        for backend in backends:
                            with open(os.devnull, 'w') as devnull:
                                ret = subprocess.call(f'make clean && make BACKEND={backend} USEBUILDDIR=1', shell=True, cwd=check_dir_mg7,
                                                      stdout=devnull,
                                                      stderr=devnull)
                            if ret == 0:
                                try:
                                    out_mg7 = subprocess.check_output(
                                        ['./check_sa.exe', 'matrix', energy_str],
                                        cwd=check_dir_mg7,
                                        stderr=subprocess.STDOUT).decode()
                                    sa_mg7_output_cache[sa_key][backend] = out_mg7
                                except Exception:
                                    pass
                except Exception as err:
                    logger.info("Language check: MG7 SA failed for %s: %s"
                                % (proc.nice_string(), err))
                finally:
                    shutil.rmtree(parent_mg7, ignore_errors=True)

            out_mg7_text = sa_mg7_output_cache.get(sa_key)

        # ── per-flavor comparison ─────────────────────────────────────────────
        # Parse ALL PDG blocks from the SA outputs and match by PDG tuple so
        # that merged-particle processes (e.g. _quark _anti_quark > z g) are
        # compared flavor-by-flavor: u u~ > z g, d d~ > z g, etc.
        from collections import OrderedDict as _OD
        flavors_f   = _parse_all_flavors_dict(out_f_text)   if out_f_text   else _OD()
        flavors_cpp = _parse_all_flavors_dict(out_cpp_text) if out_cpp_text else _OD()
        flavors_mg7 = { b: _parse_all_flavors_dict(mg7_text) if mg7_text else _OD() for b, mg7_text in out_mg7_text.items() }

        # Build the Python phase-space point using the same RAMBO RNG seed as
        # check_sa (Fortran/C++), so all backends compare on the same point.
        sa_momenta = _get_seeded_python_momenta(proc, evaluator, energy)
        if not sa_momenta:
            # Fallback to parsing the point printed by SA when seeded generation
            # is unavailable.
            if out_f_text:
                sa_momenta = _parse_momenta(out_f_text)
            if not sa_momenta and out_cpp_text:
                sa_momenta = _parse_momenta(out_cpp_text)
            if not sa_momenta:
                sa_momenta = None

        # Union of PDG keys in order: Fortran first, then any keys seen only
        # by the C++ or MG7 backends.
        mg7_keys = []
        for _, flavors in flavors_mg7.items():
            mg7_keys.extend(list(flavors.keys()))
        all_keys = list(dict.fromkeys(
            list(flavors_f.keys()) + list(flavors_cpp.keys()) + mg7_keys
        ))

        # ── Python evaluation per PDG tuple ───────────────────────────────────
        # Run the Python back-end with the same phase-space point as Fortran/
        # C++.  For merged-particle processes the leg flavor tags are set to
        # the individual PDG codes before each call so that smatrix selects
        # the matching FLV-coupling component.  We rebuild the Process from
        # scratch (rather than deep-copying) because the SA exporters mutate
        # internal color-algebra objects on the legs in a way that breaks
        # color_amp.create_color_dict_list when re-evaluated.
        py_values = {}
        if has_python and sa_momenta and all_keys:
            keys_for_python = all_keys if all_keys != [None] else [None]
            orig_legs = list(proc.get('legs'))
            for key in keys_for_python:
                new_legs = base_objects.LegList()
                for idx, src_leg in enumerate(orig_legs):
                    leg_data = {
                        'id':     src_leg.get('id'),
                        'state':  src_leg.get('state'),
                        'number': idx + 1,
                    }
                    if (key is not None and
                            abs(src_leg.get('id')) in merged_particles):
                        leg_data['flavor'] = [abs(key[idx])]
                    new_legs.append(base_objects.Leg(leg_data))
                proc_py = base_objects.Process({
                    'legs':  new_legs,
                    'model': model,
                    'orders': proc.get('orders'),
                    'forbidden_particles': proc.get('forbidden_particles'),
                    'forbidden_onsh_s_channels':
                        proc.get('forbidden_onsh_s_channels'),
                    'forbidden_s_channels': proc.get('forbidden_s_channels'),
                    'perturbation_couplings':
                        proc.get('perturbation_couplings'),
                })
                try:
                    amp_py = diagram_generation.Amplitude(proc_py)
                    if not amp_py.get('diagrams'):
                        continue
                    me_py_obj = helas_objects.HelasMatrixElement(amp_py,
                                                                 gen_color=True)
                    result = evaluator.evaluate_matrix_element(
                        me_py_obj, p=sa_momenta, options=options)
                    if result is None:
                        continue
                    if isinstance(result, tuple):
                        m2_py = result[0]
                    elif isinstance(result, dict):
                        m2_py = result.get('m2')
                    else:
                        m2_py = result
                    py_values[key] = m2_py
                except Exception as err:
                    logger.info(
                        "Language check: Python eval failed for %s: %s"
                        % (proc.nice_string(), err))

        if not all_keys:
            # Neither backend ran → one placeholder entry so the process still
            # appears in the output table.
            mg7_results = { f"value_mg7_{b}": None for b in flavors_mg7.keys() }
            results.append({
                'process':        proc,
                'process_label':  proc.base_string(),
                'value_fortran':  None,
                'value_cpp':      None,
                **mg7_results,
                'value_python':   None,
                'momenta':        sa_momenta,
            })
        else:
            for key in all_keys:
                me_f_val   = flavors_f.get(key)
                me_cpp_val = flavors_cpp.get(key)
                me_mg7_val = { f"value_mg7_{b}": flv.get(key) for b, flv in flavors_mg7.items() }
                me_py_val  = py_values.get(key)

                if key is None:
                    label = proc.base_string()
                else:
                    label = _pdg_tuple_to_label(key, model, proc)

                results.append({
                    'process':        proc,
                    'process_label':  label,
                    'value_fortran':  {'m2': me_f_val}   if me_f_val   is not None else None,
                    'value_cpp':      {'m2': me_cpp_val} if me_cpp_val is not None else None,
                    **{ k: {'m2': val} if val is not None else None for k, val in me_mg7_val.items() },
                    'value_mg7':      {'m2': me_mg7_val} if me_mg7_val is not None else None,
                    'value_python':   {'m2': me_py_val}  if me_py_val  is not None else None,
                    'momenta':        sa_momenta,
                })

    clean_added_globals(ADDED_GLOBAL)
    return results


#===============================================================================
# check_precision
#===============================================================================
# The floating point modes of the madmatrix build (madmatrix.mk FPTYPE letters)
# that 'check precision' compares against FPTYPE=d.
PRECISION_MODES = {
    'm': 'color32: double precision amplitudes, single precision colour algebra',
    'f': 'all32: single precision everywhere',
    'v': 'denom64: single precision amplitudes, double precision momenta and denominators',
}

# madmatrix.mk BACKEND values; 'auto' is the widest SIMD flavour of the host.
PRECISION_BACKENDS = ['auto', 'scalar', 'simd_128', 'simd_256', 'avx512y',
                      'simd_512', 'cuda', 'hip']

# An event whose relative error exceeds this counts in the reported rate.
PRECISION_THRESHOLD = 0.01

# Events per check_sa.exe perf batch (a power of two, so any SIMD width fits).
PRECISION_BATCH = 1024


class PrecisionProgress(object):
    """Progress bar over the steps of check_precision (builds and runs), drawn
    with tqdm when it is installed and silently absent otherwise."""

    def __init__(self, total, desc='check precision', stream=None):
        try:
            from tqdm import tqdm
        except ImportError:
            self.bar = None
        else:
            # stream None is tqdm's default (stderr)
            self.bar = tqdm(total=total, desc=desc, unit='step', leave=True,
                            dynamic_ncols=True, file=stream)

    def add(self, nb_step):
        """More steps than first announced (only known once the flavours are)."""
        if self.bar is not None and nb_step:
            self.bar.total += nb_step
            self.bar.refresh()

    @contextlib.contextmanager
    def step(self, description):
        """Show *description* while the step runs, count it once it is done."""
        if self.bar is not None:
            self.bar.set_postfix_str(description)
        yield
        if self.bar is not None:
            self.bar.update(1)

    def close(self):
        if self.bar is not None:
            self.bar.close()


def precision_statistics(me_double, me_mode, threshold=PRECISION_THRESHOLD):
    """Relative error of the matrix elements of a reduced precision build with
    respect to the double precision ones, event by event.

    The relative error is |me_mode - me_double| / |me_double|. An event with a
    zero double precision matrix element has no relative error: it is 0 when
    the other build also gives exactly zero and infinite otherwise, as is a
    non-finite value from either build. Infinite errors enter the rate above
    threshold and the maximum, but not the mean (which they would otherwise
    make meaningless); their number is reported on its own.

    Returns a dict with the keys 'nb_event', 'errors' (list of floats),
    'mean', 'max', 'nb_above', 'rate' and 'nb_invalid'.
    """
    if len(me_double) != len(me_mode):
        raise MadGraph5Error('The two builds returned %d and %d matrix elements'
                             % (len(me_double), len(me_mode)))
    errors = []
    total = 0.
    nb_finite = 0
    nb_above = 0
    nb_invalid = 0
    for ref, val in zip(me_double, me_mode):
        if not (math.isfinite(ref) and math.isfinite(val)):
            err = float('inf')
        elif ref == 0.:
            err = 0. if val == 0. else float('inf')
        else:
            err = abs(val - ref) / abs(ref)
        errors.append(err)
        if math.isinf(err):
            nb_invalid += 1
        else:
            total += err
            nb_finite += 1
        if err > threshold:
            nb_above += 1
    nb_event = len(errors)
    return {'nb_event': nb_event,
            'errors': errors,
            'mean': total / nb_finite if nb_finite else float('nan'),
            'max': max(errors) if errors else float('nan'),
            'nb_above': nb_above,
            'rate': nb_above / nb_event if nb_event else float('nan'),
            'nb_invalid': nb_invalid}


def check_precision(process_definition, modes, param_card=None, options=None,
                    cmd=FakeInterface(), output_path=None):
    """Compare the matrix elements of the madmatrix standalone output built in
    each of the floating point *modes* ('m', 'f' and/or 'v', a single letter or
    a list of them) with the ones of its double precision build (FPTYPE=d), on
    the same RAMBO phase-space points.

    The points are generated once, in double precision, by the FPTYPE=d build
    and written to disk, then read back by every build: the comparison sees the
    precision of the matrix element alone, not the one of the momenta, and
    each build narrows the points exactly as it would when called from an
    integrator. The double precision reference is computed only once, however
    many modes are compared to it.

    Recognised *options*: 'nb_event' (default 10^6), 'energy' (GeV, default
    1000) and 'backend' (madmatrix.mk BACKEND, default 'auto'). The difference
    plot, one per subprocess with every mode on it, is written in *output_path*
    (default: the current directory).

    Returns a list with one dict per subprocess, mode and flavour combination,
    with the keys 'process_label', 'subprocess', 'flavor', 'mode', 'backend',
    the ones of :func:`precision_statistics`, 'time_double', 'time_mode' and
    'plot'.
    """
    import tempfile
    import multiprocessing
    from madmatrix import output as madmatrix_output
    from madmatrix import model_handling as madmatrix_model_handling

    if isinstance(modes, str):
        modes = [modes]
    modes = misc.make_unique(list(modes))
    if not modes:
        raise InvalidCmd('check precision needs at least one precision mode (%s)'
                         % '|'.join(PRECISION_MODES))
    for mode in modes:
        if mode not in PRECISION_MODES:
            raise InvalidCmd('Precision mode must be one of %s, not %s'
                             % ('|'.join(PRECISION_MODES), mode))
    if options is None:
        options = {}
    nb_event = int(options.get('nb_event', 1000000))
    if nb_event < 1:
        raise InvalidCmd('--nb_event must be a positive number of events')
    energy = float(options.get('energy', 1000.0))
    backend = options.get('backend', 'auto')
    if backend not in PRECISION_BACKENDS:
        raise InvalidCmd('--backend must be one of %s, not %s'
                         % ('|'.join(PRECISION_BACKENDS), backend))
    if output_path is None:
        output_path = os.getcwd()
    if process_definition.get('perturbation_couplings'):
        raise InvalidCmd('check precision is only available for tree-level processes')
    for tool in ('make',):
        if not misc.which(tool):
            raise InvalidCmd('check precision needs %s' % tool)

    model = process_definition.get('model')
    nb_core = (cmd.options.get('nb_core') if hasattr(cmd, 'options') else None) \
              or multiprocessing.cpu_count()

    work_dir = tempfile.mkdtemp(prefix='mg5_precisioncheck_')
    sa_dir = pjoin(work_dir, 'standalone')
    logger.info('check precision: writing the standalone output in %s' % sa_dir)

    # Same helas objects as 'generate' + 'output standalone' (not grouped)
    opt = {'export_format': 'standalone', 'mp': False, 'v5_model': True,
           'cpp_compiler': cmd.options.get('cpp_compiler') if hasattr(cmd, 'options') else None,
           'output_options': {}}
    exporter = madmatrix_output.ProcessExporterMadMatrixStandalone(sa_dir, opt)
    old_enumerate = helas_objects.HelasMatrixElement.enumerate_all_flavors
    helas_objects.HelasMatrixElement.enumerate_all_flavors = \
        not getattr(exporter, 'use_flavor_mask', True)
    try:
        ignore_six_quark = cmd.options.get('ignore_six_quark_processes', []) \
                           if hasattr(cmd, 'options') else []
        amplitudes = diagram_generation.MultiProcess(process_definition,
                        ignore_six_quark_processes=ignore_six_quark or []).get('amplitudes')
        if not amplitudes:
            raise InvalidCmd('No amplitude generated for %s'
                             % process_definition.nice_string())
        multi_me = helas_objects.HelasMultiProcess(amplitudes)
        matrix_elements = multi_me.get_matrix_elements()
        for uid, me in enumerate(matrix_elements):
            me.get('processes')[0].set('uid', uid + 1)
        writer = madmatrix_model_handling.MadMatrixUFOHelasCallWriter(model)
        exporter.copy_template(model)
        for me_number, me in enumerate(matrix_elements):
            exporter.generate_subprocess_directory(me, writer, me_number)
        exporter.convert_model(model, multi_me.get_used_lorentz(),
                               multi_me.get_used_couplings())
        exporter.finalize({'matrix_elements': matrix_elements}, '', {}, ['nojpeg'])
    finally:
        helas_objects.HelasMatrixElement.enumerate_all_flavors = old_enumerate
    if param_card:
        cp(param_card, pjoin(sa_dir, 'Cards', 'param_card.dat'))

    proc_root = pjoin(sa_dir, 'SubProcesses')
    p_dirs = sorted(d for d in os.listdir(proc_root)
                    if d.startswith('P') and os.path.isdir(pjoin(proc_root, d)))
    if not p_dirs:
        raise MadGraph5Error('check precision: no subprocess directory in %s' % proc_root)

    def build(p_dir, fptype):
        log = pjoin(work_dir, 'build_%s_%s.log' % (os.path.basename(p_dir), fptype))
        with open(log, 'w') as out:
            subprocess.call(['make', 'cleanall'], cwd=p_dir, stdout=out,
                            stderr=subprocess.STDOUT)
            status = subprocess.call(['make', '-j%s' % nb_core, 'FPTYPE=%s' % fptype,
                                      'BACKEND=%s' % backend],
                                     cwd=p_dir, stdout=out, stderr=subprocess.STDOUT)
        if status:
            raise MadGraph5Error('check precision: FPTYPE=%s BACKEND=%s build failed, see %s'
                                 % (fptype, backend, log))

    def run(p_dir, args, tag):
        log = pjoin(work_dir, 'run_%s_%s.log' % (os.path.basename(p_dir), tag))
        with open(log, 'w') as out:
            status = subprocess.call(['./check_sa.exe'] + [str(a) for a in args],
                                     cwd=p_dir, stdout=out, stderr=subprocess.STDOUT)
        if status:
            raise MadGraph5Error('check precision: check_sa.exe failed, see %s' % log)
        return log

    def read_doubles(path):
        values = array.array('d')
        with open(path, 'rb') as stream:
            values.frombytes(stream.read())
        return values

    def flavor_labels(log):
        labels = []
        for line in open(log):
            if line.strip().startswith('PDG'):
                pdgs = [int(x) for x in line.split()[1:]]
                ninitial = process_definition.get_ninitial()
                names = [model.get_particle(p).get_name() if model.get_particle(p)
                         else str(p) for p in pdgs]
                labels.append(' '.join(names[:ninitial]) + ' > ' +
                              ' '.join(names[ninitial:]))
        return labels

    niter = (nb_event + PRECISION_BATCH - 1) // PRECISION_BATCH
    batch = ['1', PRECISION_BATCH]
    results = []
    # Steps per subprocess: build d, flavour list, RAMBO, one run per flavour in
    # d, a build and one run per flavour for each mode, and the analysis. The
    # number of flavours is only known after the flavour list: count one until then.
    steps_per_flavor = 1 + len(modes)
    progress = PrecisionProgress(len(p_dirs) * (4 + len(modes) + steps_per_flavor))
    try:
        for p_name in p_dirs:
            p_dir = pjoin(proc_root, p_name)
            logger.info('check precision: %s, %d events, FPTYPE=d vs FPTYPE=%s, BACKEND=%s'
                        % (p_name, nb_event, ','.join(modes), backend))
            # Double precision: the points, the flavours and the reference values
            with progress.step('%s: build FPTYPE=d' % p_name):
                build(p_dir, 'd')
            with progress.step('%s: flavours' % p_name):
                labels = flavor_labels(run(p_dir, ['matrix', energy], 'matrix'))
            if not labels:
                raise MadGraph5Error('check precision: no flavour found for %s' % p_name)
            progress.add((len(labels) - 1) * steps_per_flavor)
            momenta = pjoin(work_dir, '%s_momenta.bin' % p_name)
            with progress.step('%s: RAMBO %d events' % (p_name, nb_event)):
                run(p_dir, ['perf', '--energy', energy, '--dump-momenta', momenta]
                           + batch + [niter], 'rambo')
            size = os.path.getsize(momenta)
            event_size = size // (niter * PRECISION_BATCH)
            with open(momenta, 'r+b') as stream:
                stream.truncate(event_size * nb_event)

            def evaluate(fptype):
                values = []
                times = []
                for iflav in range(len(labels)):
                    dump = pjoin(work_dir, '%s_me_%s_%d.bin' % (p_name, fptype, iflav))
                    with progress.step('%s: FPTYPE=%s, flavour %d/%d'
                                       % (p_name, fptype, iflav + 1, len(labels))):
                        log = run(p_dir, ['perf', '-f', iflav, '--momenta', momenta,
                                          '--dump-me', dump] + batch + [1],
                                  '%s_%d' % (fptype, iflav))
                    values.append(read_doubles(dump))
                    times.append(matrix_element_time(open(log).read()))
                return values, times

            me_double, time_double = evaluate('d')

            entries = []
            for mode in modes:
                with progress.step('%s: build FPTYPE=%s' % (p_name, mode)):
                    build(p_dir, mode)
                me_mode, time_mode = evaluate(mode)
                for iflav, label in enumerate(labels):
                    entry = precision_statistics(me_double[iflav], me_mode[iflav])
                    entry.update({'process_label': label, 'subprocess': p_name,
                                  'flavor': iflav, 'mode': mode, 'backend': backend,
                                  'time_double': time_double[iflav],
                                  'time_mode': time_mode[iflav]})
                    entries.append(entry)
            with progress.step('%s: plot' % p_name):
                plot = plot_precision(entries, pjoin(output_path,
                                      'check_precision_%s_%s' % ('_'.join(modes), p_name)))
            for entry in entries:
                entry['plot'] = plot
            results.extend(entries)
    finally:
        progress.close()

    shutil.rmtree(work_dir, ignore_errors=True)
    return results


def matrix_element_time(perf_output):
    """Time spent in the matrix element evaluation, in seconds, as printed by
    `check_sa.exe perf` (TotalTime[MatrixElems]): the momenta reading and the
    RAMBO generation are not included. None if the line is missing."""
    match = re.search(r'TotalTime\[MatrixElems\]\s*\(3\)\s*=\s*\(\s*([-+0-9.eE]+)\s*\)',
                      perf_output)
    return float(match.group(1)) if match else None


def plot_precision(entries, basename):
    """Histogram of log10 of the relative error of every event, one curve per
    precision mode and flavour, written to basename.pdf. Without matplotlib the
    relative errors are written to basename.dat instead. Returns the path
    written."""
    modes = misc.make_unique([entry['mode'] for entry in entries])
    nb_flavor = len(set(entry['flavor'] for entry in entries))
    floor = 1e-18
    # MG5 runs with DEBUG logging, which matplotlib would otherwise flood with
    # one line per font it considers
    logging.getLogger('matplotlib').setLevel(logging.WARNING)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        path = basename + '.dat'
        logger.warning('matplotlib is not available: no plot, the relative '
                       'errors are written to %s instead' % path)
        with open(path, 'w') as out:
            out.write('# mode  flavor  relative_error  (FPTYPE=%s vs FPTYPE=d)\n'
                      % ','.join(modes))
            for entry in entries:
                if entry['mode'] == modes[0]:
                    out.write('# flavor %d: %s\n' % (entry['flavor'], entry['process_label']))
            for entry in entries:
                for err in entry['errors']:
                    out.write('%s %d %.6e\n' % (entry['mode'], entry['flavor'], err))
        return path

    from matplotlib.lines import Line2D
    path = basename + '.pdf'
    fig, ax = plt.subplots(figsize=(7, 4.5))
    # The line style tells the precision mode, the colour the process (flavour)
    mode_style = dict(zip(modes, ['-', '--', ':', '-.']))
    flavor_color = {}
    colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
    all_logs = [[math.log10(max(e, floor)) if math.isfinite(e) else 1.
                 for e in entry['errors']] for entry in entries]
    # common bins, so that the curves can be compared bin by bin
    low = min(min(logs) for logs in all_logs if logs)
    high = max(max(logs) for logs in all_logs if logs)
    if high <= low:
        high = low + 1.
    bins = [low + (high - low) * i / 100. for i in range(101)]
    for entry, logs in zip(entries, all_logs):
        color = flavor_color.setdefault(entry['flavor'],
                                        colors[len(flavor_color) % len(colors)])
        ax.hist(logs, bins=bins, histtype='step', log=True, color=color,
                linestyle=mode_style[entry['mode']])
    threshold = math.log10(PRECISION_THRESHOLD)
    ax.axvline(threshold, color='red', linestyle='-.', linewidth=1)
    handles = [Line2D([], [], color='black', linestyle=mode_style[mode],
                      label='FPTYPE=%s' % mode) for mode in modes]
    handles.append(Line2D([], [], color='red', linestyle='-.', linewidth=1,
                          label='1% relative error'))
    ax.set_xlabel(r'$\log_{10}\,|M^2_{\mathrm{mode}} - M^2_{d}|\,/\,|M^2_{d}|$')
    ax.set_ylabel('events')
    title = '%s: FPTYPE=%s vs FPTYPE=d (%d events)' % (
        entries[0]['process_label'] if nb_flavor == 1 else entries[0]['subprocess'],
        ','.join(modes), entries[0]['nb_event'])
    ax.set_title(title, fontsize='medium')
    ax.legend(handles=handles, fontsize='small')
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)
    return path


def output_precision(results, output='text'):
    """Present the results of :func:`check_precision`."""
    if not results:
        return 'No result'
    modes = misc.make_unique([r['mode'] for r in results])
    proc_col = max([len('Process')] + [len(r['process_label']) for r in results]) + 2
    col = 16
    text = 'FPTYPE=%s vs FPTYPE=d, BACKEND=%s, %d events per flavour\n' % (
        ','.join(modes), results[0].get('backend', 'auto'), results[0]['nb_event'])
    for mode in modes:
        text += '  %s = %s\n' % (mode, PRECISION_MODES.get(mode, 'unknown mode'))

    def _time(value):
        return '%.3e' % value if value is not None else 'N/A'

    def _speedup(r):
        if not r.get('time_double') or not r.get('time_mode'):
            return 'N/A'
        return '%.2f' % (r['time_double'] / r['time_mode'])

    text += (fixed_string_length('Process', proc_col) +
             fixed_string_length('mode', 6) +
             fixed_string_length('mean error', col) +
             fixed_string_length('max error', col) +
             fixed_string_length('rate > 1%', col) +
             fixed_string_length('non-finite', 12) +
             fixed_string_length('time d [s]', col) +
             fixed_string_length('time mode [s]', col) + 'speed-up')
    for r in results:
        text += ('\n' + fixed_string_length(r['process_label'], proc_col) +
                 fixed_string_length(r['mode'], 6) +
                 fixed_string_length('%.3e' % r['mean'], col) +
                 fixed_string_length('%.3e' % r['max'], col) +
                 fixed_string_length('%.3e' % r['rate'], col) +
                 fixed_string_length('%d' % r['nb_invalid'], 12) +
                 fixed_string_length(_time(r.get('time_double')), col) +
                 fixed_string_length(_time(r.get('time_mode')), col) +
                 _speedup(r))
    text += ('\n(time: matrix element evaluation only, for the %d events)'
             % results[0]['nb_event'])
    for plot in misc.make_unique([r['plot'] for r in results]):
        if plot.endswith('.dat'):
            text += '\nRelative errors (no matplotlib, no plot): %s' % plot
        else:
            text += '\nPlot of the difference: %s' % plot
    return text


def output_language(comparison_results, output='text'):
    """Present the results of a Fortran SA / C++ SA / MG7 SA / Python cross-check.

    Parameters
    ----------
    comparison_results : list of dict
        As returned by :func:`check_language`.
    output : {'text', 'fail'}
        If ``'fail'``, return the number of failed processes.

    Returns
    -------
    str or int
    """
    proc_col_size = 17
    for data in comparison_results:
        proc = data.get('process_label', data['process'].base_string())
        if len(proc) + 1 > proc_col_size:
            proc_col_size = len(proc) + 1

    col_size = 16
    process_header = "Process"

    pass_proc = 0
    fail_proc = 0
    no_check_proc = 0
    no_check_list = []
    failed_list = []

    # in case something broke within MG7, we just write a single N/A column
    try:
        mg7_columns = [fixed_string_length(f"MG7 SA ({k.rsplit('_',1)[-1]})", col_size) for k in comparison_results[0]["value_mg7"]["m2"].keys()]
    except KeyError:
        mg7_columns = [fixed_string_length("MG7 SA", col_size)]
    res_str = (fixed_string_length(process_header, proc_col_size) +
               fixed_string_length("Fortran SA", col_size) +
               fixed_string_length("C++ SA", col_size) +
               "".join(mg7_columns) + 
               fixed_string_length("Python", col_size) +
               fixed_string_length("max rel.diff.", col_size) +
               "Result")

    def _fmt(v):
        return "%1.6e" % v if v is not None else "N/A"

    def _reldiff(a, b):
        if a is None or b is None:
            return None
        ref = abs(a) if a != 0 else abs(b) if b != 0 else 0.
        if ref == 0:
            return 0.
        return abs(a - b) / ref

    def _fmt_diff(d):
        return "%1.6e" % d if d is not None else "N/A"

    for entry in comparison_results:
        proc    = entry.get('process_label', entry['process'].base_string())
        val_f   = entry['value_fortran']
        val_cpp = entry['value_cpp']
        val_mg7 = entry.get('value_mg7')
        val_py  = entry.get('value_python')

        me_f   = val_f['m2']   if val_f   is not None else None
        me_cpp = val_cpp['m2'] if val_cpp is not None else None
        me_mg7 = val_mg7['m2'] if val_mg7 is not None else None
        me_py  = val_py['m2']  if val_py  is not None else None

        # Pairwise relative differences across the available backends.
        # for MG7 separate results from various backends, if something broke
        # we display a single None
        mg7_fortran_diffs = [ _reldiff(me_f, me_mg7_backend) for me_mg7_backend in me_mg7.values() ] if me_mg7 is not None else [None]
        mg7_cpp_diffs = [ _reldiff(me_cpp, me_mg7_backend) for me_mg7_backend in me_mg7.values() ] if me_mg7 is not None else [None]
        mg7_python_diffs = [ _reldiff(me_py, me_mg7_backend) for me_mg7_backend in me_mg7.values() ] if me_mg7 is not None else [None]
        diffs = [d for d in (
            _reldiff(me_f, me_cpp),
            *mg7_fortran_diffs,
            _reldiff(me_f, me_py),
            *mg7_cpp_diffs,
            _reldiff(me_cpp, me_py),
            *mg7_python_diffs,
        ) if d is not None]
        max_diff = max(diffs) if diffs else None

        mg7_strings = [
            fixed_string_length(_fmt(me_mg7_backend), col_size)
            for me_mg7_backend in me_mg7.values()
        ] if me_mg7 is not None else [fixed_string_length(_fmt(None), col_size)]
        row = ('\n' + fixed_string_length(proc, proc_col_size) +
               fixed_string_length(_fmt(me_f),   col_size) +
               fixed_string_length(_fmt(me_cpp), col_size) +
               "".join(mg7_strings) +
               fixed_string_length(_fmt(me_py),  col_size) +
               fixed_string_length(_fmt_diff(max_diff), col_size))

        mg7_available = me_mg7.values() if me_mg7 is not None else [None]
        n_available = sum(v is not None for v in (me_f, me_cpp, *mg7_available, me_py))

        if n_available == 0:
            no_check_proc += 1
            no_check_list.append(proc)
            res_str += row + "No backend available"
        elif n_available == 1:
            no_check_proc += 1
            no_check_list.append(proc)
            res_str += row + "Only one backend available"
        elif max_diff is not None and max_diff < 1e-4:
            pass_proc += 1
            res_str += row + "Passed"
        else:
            fail_proc += 1
            failed_list.append(proc)
            res_str += row + "Failed"

    res_str += "\nSummary: %i/%i passed, %i/%i failed" % (
        pass_proc, pass_proc + fail_proc,
        fail_proc, pass_proc + fail_proc)
    if fail_proc:
        res_str += "\nFailed processes: %s" % ', '.join(failed_list)
    if no_check_proc:
        res_str += "\nNot checked: %s" % ', '.join(no_check_list)

    if output == 'text':
        return res_str
    return fail_proc


#===============================================================================
# check_gauge
#===============================================================================
def check_unitary_feynman(processes_unit, processes_feynm, processes_axial=None, processes_fd=None, param_card=None, 
                               options=None, tir={}, output_path=None,
                               cuttools="", reuse=False, cmd = FakeInterface()):
    """Check gauge invariance of the processes by flipping
       the gauge of the model
    """
    
    mg_root = cmd._mgme_dir
    
    cmass_scheme = cmd.options['complex_mass_scheme']
    
    if isinstance(processes_unit, base_objects.ProcessDefinition):
        # Generate a list of unique processes
        # Extract IS and FS ids
        multiprocess_unit = processes_unit
        model = multiprocess_unit.get('model')

        # Initialize matrix element evaluation
        # For the unitary gauge, open loops should not be used
        loop_optimized_bu = cmd.options['loop_optimized_output']
        if processes_unit.get('squared_orders'):
            if processes_unit.get('perturbation_couplings') in [[],['QCD']]:
                cmd.options['loop_optimized_output'] = True
            else:
                raise InvalidCmd("The gauge test cannot be performed for "+
                  " a process with more than QCD corrections and which"+
                  " specifies squared order constraints.")
        else:
            cmd.options['loop_optimized_output'] = False
            
        aloha.unitary_gauge = True
        if processes_unit.get('perturbation_couplings')==[]:
            evaluator = MatrixElementEvaluator(model, param_card,
                                       cmd=cmd,auth_skipping = False, reuse = True)
        else:
            evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                           cmd=cmd, model=model,
                                           param_card=param_card,
                                           auth_skipping = False, 
                                           output_path=output_path,
                                           reuse = False)
        if not cmass_scheme and multiprocess_unit.get('perturbation_couplings')==[]:
            logger.info('Set All width to zero for non complex mass scheme checks')
            for particle in evaluator.full_model.get('particles'):
                if particle.get('width') != 'ZERO':
                    evaluator.full_model.get('parameter_dict')[particle.get('width')] = 0.

        output_u = run_multiprocs_no_crossings(get_value,
                                           multiprocess_unit,
                                           evaluator,
                                           options=options)
        
        clean_added_globals(ADDED_GLOBAL)
       # Clear up previous run if checking loop output
        if processes_unit.get('perturbation_couplings')!=[]:
            clean_up(output_path)

        momentum = {}
        for data in output_u:
            momentum[data['process']] = data['p']
        
        multiprocess_feynm = processes_feynm
        model = multiprocess_feynm.get('model')

        # Initialize matrix element evaluation
        aloha.unitary_gauge = False
        # We could use the default output as well for Feynman, but it provides
        # an additional check
        cmd.options['loop_optimized_output'] = True
        if processes_feynm.get('perturbation_couplings')==[]:
            evaluator = MatrixElementEvaluator(model, param_card,
                                       cmd= cmd, auth_skipping = False, reuse = False)
        else:
            evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                           cmd= cmd, model=model,
                                           param_card=param_card,
                                           auth_skipping = False, 
                                           output_path=output_path,
                                           reuse = False)

        if not cmass_scheme and multiprocess_feynm.get('perturbation_couplings')==[]:
            # Set all widths to zero for gauge check
            for particle in evaluator.full_model.get('particles'):
                if particle.get('width') != 'ZERO':
                    evaluator.full_model.get('parameter_dict')[particle.get('width')] = 0.

        output_f = run_multiprocs_no_crossings(get_value, multiprocess_feynm,
                                                            evaluator, momentum,
                                                            options=options)
        output_axial = None
        if processes_axial is not None:
            multiprocess_axial = processes_axial
            model = multiprocess_axial.get('model')
            with misc.TMP_variable(aloha, 'unitary_gauge', 2):
                cmd.options['loop_optimized_output'] = True
                if multiprocess_axial.get('perturbation_couplings')==[]:
                    evaluator = MatrixElementEvaluator(model, param_card,
                                            cmd= cmd, auth_skipping = False, reuse = False)
                else:
                    evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                                cmd= cmd, model=model,
                                                param_card=param_card,
                                                auth_skipping = False,
                                                output_path=output_path,
                                                reuse = False)

                if not cmass_scheme and multiprocess_axial.get('perturbation_couplings')==[]:
                    for particle in evaluator.full_model.get('particles'):
                        if particle.get('width') != 'ZERO':
                            evaluator.full_model.get('parameter_dict')[particle.get('width')] = 0.

                output_axial = run_multiprocs_no_crossings(get_value, multiprocess_axial,
                                                                   evaluator, momentum,
                                                                   options=options)
        output_fd = None
        if processes_fd is not None:
            multiprocess_fd = processes_fd
            model = multiprocess_fd.get('model')
            with misc.TMP_variable(aloha, 'unitary_gauge', 3):
                cmd.options['loop_optimized_output'] = True
                if multiprocess_fd.get('perturbation_couplings')==[]:
                    evaluator = MatrixElementEvaluator(model, param_card,
                                            cmd= cmd, auth_skipping = False, reuse = False)
                else:
                    evaluator = LoopMatrixElementEvaluator(cuttools_dir=cuttools,tir_dir=tir,
                                                cmd= cmd, model=model,
                                                param_card=param_card,
                                                auth_skipping = False,
                                                output_path=output_path,
                                                reuse = False)

                if not cmass_scheme and multiprocess_fd.get('perturbation_couplings')==[]:
                    for particle in evaluator.full_model.get('particles'):
                        if particle.get('width') != 'ZERO':
                            evaluator.full_model.get('parameter_dict')[particle.get('width')] = 0.

                output_fd = run_multiprocs_no_crossings(get_value, multiprocess_fd,
                                                                    evaluator, momentum,
                                                                    options=options)
        output = [processes_unit]        
        for data in output_f:
            local_dico = {}
            local_dico['process'] = data['process']
            local_dico['value_feynm'] = data['value']
            local_dico['value_unit'] = [d['value'] for d in output_u 
                                      if d['process'] == data['process']][0]
            if output_axial is not None:
                local_dico['value_axial'] = [d['value'] for d in output_axial
                                             if d['process'] == data['process']][0]
            if output_fd is not None:
                local_dico['value_fd'] = [d['value'] for d in output_fd
                                          if d['process'] == data['process']][0]
            output.append(local_dico)
        
        if processes_feynm.get('perturbation_couplings')!=[] and not reuse:
            # Clean temporary folders created for the running of the loop processes
            clean_up(output_path)

        # Avoid leaking generated Python matrix-element classes/wavefunctions
        # across subsequent checks (e.g. lorentz/permutation) with different gauges.
        clean_added_globals(ADDED_GLOBAL)

        # Reset the original global variable loop_optimized_output.
        cmd.options['loop_optimized_output'] = loop_optimized_bu

        return output
#    elif isinstance(processes, base_objects.Process):
#        processes = base_objects.ProcessList([processes])
#    elif isinstance(processes, base_objects.ProcessList):
#        pass
    else:
        raise InvalidCmd("processes is of non-supported format")

#===============================================================================
# check_cms
#===============================================================================
def check_complex_mass_scheme(process_line, param_card=None, cuttools="",tir={}, 
         cmd = FakeInterface(), output_path=None, MLOptions = {}, options={}):
    """Check complex mass scheme consistency in the offshell region of s-channels
    detected for this process, by varying the expansion parameter consistently
    with the corresponding width and making sure that the difference between
    the complex mass-scheme and the narrow-width approximation is higher order.
    """

    if not isinstance(process_line, str):
        raise InvalidCmd("Process definition must be given as a string for this check")

    # Generate a list of unique processes in the NWA scheme
    cmd.do_set('complex_mass_scheme False', log=False)
    #cmd.do_import('model loop_qcd_qed_sm-NWA')
    multiprocess_nwa = cmd.extract_process(process_line)

    # Change the option 'recompute_width' to the optimal value if set to 'auto'.
    has_FRdecay = os.path.isfile(pjoin(cmd._curr_model.get('modelpath'),
                                                                   'decays.py'))

    # Proceed with some warning
    missing_perturbations = cmd._curr_model.get_coupling_orders()-\
                             set(multiprocess_nwa.get('perturbation_couplings'))

    if len(multiprocess_nwa.get('perturbation_couplings'))>0 and \
                                                   len(missing_perturbations)>0:
        logger.warning("------------------------------------------------------")
        logger.warning("The process considered does not specify the following "+
           "type of loops to be included : %s"%str(list(missing_perturbations)))
        logger.warning("Consequently, the CMS check will be unsuccessful if the"+
         " process involves any resonating particle whose LO decay is "+
         "mediated by one of these orders.")
        logger.warning("You can use the syntax '[virt=all]' to automatically"+
                                 " include all loops supported by the model.")
        logger.warning("------------------------------------------------------")

    if len(multiprocess_nwa.get('perturbation_couplings'))>0 and \
                                            len(multiprocess_nwa.get('legs'))<=4:
        logger.warning("------------------------------------------------------")
        logger.warning("Processes with four or less external states are typically not"+\
          " sensitive to incorrect Complex Mass Scheme implementations.")
        logger.warning("You can test this sensitivity by making sure that the"+
          " same check on the leading-order counterpart of this process *fails*"+
          " when using the option '--diff_lambda_power=2'.")
        logger.warning("If it does not, then consider adding a massless "+
                                         "gauge vector to the external states.")
        logger.warning("------------------------------------------------------")

    if options['recompute_width']=='auto':
        if multiprocess_nwa.get('perturbation_couplings')!=[]:
            # NLO, so it is necessary to have the correct LO width for the check
            options['recompute_width'] = 'first_time'
        else:
            options['recompute_width'] = 'never'

    # Some warnings
    if options['recompute_width'] in ['first_time', 'always'] and \
                             not has_FRdecay and not 'cached_widths' in options:
        logger.info('The LO widths will need to be recomputed but the '+
         'model considered does not appear to have a decay module.\nThe widths'+
         ' will need to be computed numerically and it will slow down the test.\n'+
         'Consider using a param_card already specifying correct LO widths and'+
         " adding the option --recompute_width=never when doing this check.")

    if options['recompute_width']=='never' and \
        any(order in multiprocess_nwa.get('perturbation_couplings') for order in
                                                   options['expansion_orders']):
        logger.warning('You chose not to recompute the widths while including'+
          ' loop corrections. The check will be successful only if the width'+\
          ' specified in the default param_card is LO accurate (Remember that'+\
          ' the default values of alpha_s and awem1 are set to 0.1 and 10.0'+\
          ' respectively by default).')

    # Reload the model including the decay.py to have efficient MadWidth if
    # possible (this model will be directly given to MadWidth. Notice that 
    # this will not be needed for the CMS run because MadWidth is not supposed
    # to be used there (the widths should be recycled from those of the NWA run).
    if options['recompute_width'] in ['first_time', 'always'] and has_FRdecay:
        modelname = cmd._curr_model.get('modelpath+restriction')
        # Preserve apply_flavor_grouping only when explicitly configured by
        # the caller. Otherwise let import_model use its own default behavior.
        import_model_kwargs = {'decay': True, 'complex_mass_scheme': False}
        if hasattr(cmd, 'options') and isinstance(cmd.options, dict) and \
                                 'apply_flavor_grouping' in cmd.options:
            import_model_kwargs['options'] = {
                'apply_flavor_grouping': cmd.options['apply_flavor_grouping']}
        with misc.MuteLogger(['madgraph'], ['INFO']):
            model = import_ufo.import_model(modelname, **import_model_kwargs)
        multiprocess_nwa.set('model', model)

    run_options = copy.deepcopy(options)

    # Set the seed if chosen by user
    if options['seed'] > 0:
        random.seed(options['seed'])
    
    # Add useful entries
    run_options['param_card'] = param_card
    if isinstance(cmd, FakeInterface):
        raise MadGraph5Error("Check CMS cannot be run with a FakeInterface.")
    run_options['cmd']        = cmd
    run_options['MLOptions']  = MLOptions
    if output_path:
        run_options['output_path'] = output_path
    else:
        run_options['output_path'] = cmd._mgme_dir
    
    # Add the information regarding FR decay for optimal log information
    run_options['has_FRdecay']     = has_FRdecay

    # And one for caching the widths computed along the way
    if 'cached_widths' not in run_options:
        run_options['cached_widths'] = {}
    # Cached param_cards, first is param_card instance, second is
    # param_name dictionary
    run_options['cached_param_card'] = {'NWA':[None,None],'CMS':[None,None]}

    if options['tweak']['name']:
        logger.info("Now running the CMS check for tweak '%s'"\
                                                      %options['tweak']['name'])

    model = multiprocess_nwa.get('model')
    # Make sure all masses are defined as external
    for particle in model.get('particles'):
        mass_param = model.get_parameter(particle.get('mass'))
        if particle.get('mass')!='ZERO' and 'external' not in mass_param.depend:
            if model.get('name') not in ['sm','loop_sm']:
                logger.warning("The mass '%s' of particle '%s' is not an external"%\
              (model.get_parameter(particle.get('mass')).name,particle.get('name'))+\
              " parameter as required by this check. \nMG5_aMC will try to"+\
              " modify the model to remedy the situation. No guarantee.")
            status = model.change_electroweak_mode(set(['mz','mw','alpha']), bypass_check=True)
            if not status:
                raise InvalidCmd('The EW scheme could apparently not be changed'+\
                  ' so as to have the W-boson mass external. The check cannot'+\
                  ' proceed.')
            break

    veto_orders = [order for order in model.get('coupling_orders') if \
                                       order not in options['expansion_orders']]
    if len(veto_orders)>0:
        logger.warning('You did not define any parameter scaling rule for the'+\
          " coupling orders %s. They will be "%','.join(veto_orders)+\
          "forced to zero in the tests. Consider adding the scaling rule to"+\
          "avoid this. (see option '--cms' in 'help check')")
        for order in veto_orders:
            multiprocess_nwa.get('orders')[order]==0
        multiprocess_nwa.set('perturbation_couplings', [order for order in
        multiprocess_nwa['perturbation_couplings'] if order not in veto_orders])

    if multiprocess_nwa.get('perturbation_couplings')==[]:
        evaluator = MatrixElementEvaluator(model, param_card,
                                   cmd=cmd,auth_skipping = False, reuse = True)
    else:
        evaluator = LoopMatrixElementTimer(cuttools_dir=cuttools,tir_dir=tir,
                                           cmd=cmd, model=model,
                                           param_card=param_card,
                                           auth_skipping = False, 
                                           output_path=output_path,
                                           reuse = False)

    cached_information = []
    output_nwa = run_multiprocs_no_crossings(check_complex_mass_scheme_process,
                                           multiprocess_nwa,
                                           evaluator,
    # This empty list 'opt' will be passed to the check_complex_mass_scheme_process
    # function which will fill it with the specification of the particle for which
    # the complex mass scheme must be checked. The fact that it is a list
    # at this stage tells the function check_complex_mass_scheme_process that
    # we are doing nwa. It will then be converted to a dictionary when doing cms.
                                           opt = cached_information,
                                           options=run_options)

    # Make sure to start from fresh for LO runs
    clean_added_globals(ADDED_GLOBAL)

    # Generate a list of unique processes in the CMS scheme
    cmd.do_set('complex_mass_scheme True --allow_qed', log=False)
    #cmd.do_import('model loop_qcd_qed_sm__CMS__-CMS')

    multiprocess_cms = cmd.extract_process(process_line)    
    model = multiprocess_cms.get('model')
    # Apply veto
    if len(veto_orders)>0:
        for order in veto_orders:
            multiprocess_cms.get('orders')[order]==0
        multiprocess_cms.set('perturbation_couplings', [order for order in
        multiprocess_cms['perturbation_couplings'] if order not in veto_orders])
        
    if multiprocess_cms.get('perturbation_couplings')==[]:
        evaluator = MatrixElementEvaluator(model, param_card,
                                    cmd=cmd,auth_skipping = False, reuse = True)
    else:
        evaluator = LoopMatrixElementTimer(cuttools_dir=cuttools,tir_dir=tir,
                                           cmd=cmd, model=model,
                                           param_card=param_card,
                                           auth_skipping = False, 
                                           output_path=output_path,
                                           reuse = False)

    output_cms = run_multiprocs_no_crossings(check_complex_mass_scheme_process,
                                   multiprocess_cms,
                                   evaluator,
                                   # We now substituted the cached information
                                   opt = dict(cached_information),
                                   options=run_options)

    if multiprocess_cms.get('perturbation_couplings')!=[] and not options['reuse']:
        # Clean temporary folders created for the running of the loop processes
        clean_up(output_path)

    # Now reformat a bit the output by putting the CMS and NWA results together
    # as values of a dictionary with the process name as key. 
    # Also a 'processes_order' to list all processes in their order of appearance
    result = {'ordered_processes':[],'lambdaCMS':options['lambdaCMS']}
    # Recall what perturbation orders were used
    result['perturbation_orders']=multiprocess_nwa.get('perturbation_couplings')
    for i, proc_res in enumerate(output_nwa):
        result['ordered_processes'].append(proc_res[0])
        result[proc_res[0]] = {
                'NWA':proc_res[1]['resonances_result'],
                'CMS':output_cms[i][1]['resonances_result'],
                'born_order':proc_res[1]['born_order'],
                'loop_order':proc_res[1]['loop_order']}
    
    # As an optimization we propagate the widths as they could be reused when
    # using several tweaks
    options['cached_widths'] = run_options['cached_widths']
    
    # Add widths information to the result
    result['recompute_width'] = options['recompute_width']
    result['has_FRdecay']     = has_FRdecay
    result['widths_computed'] = []
    cached_widths = sorted(list(options['cached_widths'].items()), key=lambda el: \
                                                                  abs(el[0][0]))
    for (pdg, lambda_value), width in cached_widths:
        if lambda_value != 1.0:
            continue
        result['widths_computed'].append((model.get_particle(pdg).get_name(),
                                                                         width))
        
    # Make sure to clear the python ME definitions generated in LO runs
    clean_added_globals(ADDED_GLOBAL)
    
    return result


# Check CMS for a given process
def check_complex_mass_scheme_process(process, evaluator, opt = [], 
                                                                  options=None):
    """Check CMS for the process in argument. The options 'opt' is quite important.
    When opt is a list, it means that we are doing NWA and we are filling the
    list with the following tuple 
                       ('proc_name',({'ParticlePDG':ParticlePDG,
                                      'FinalStateMothersNumbers':set([]), 
                                      'PS_point_used':[]},...))
    When opt is a dictionary, we are in the CMS mode and it will be reused then.
    """

    # a useful logical to check if we are in LO (python on the flight) or 
    # NLO (output and compilation) mode
    NLO = process.get('perturbation_couplings') != []
    
    def glue_momenta(production, decay):
        """ Merge together the kinematics for the production of particle 
        positioned last in the 'production' array with the 1>N 'decay' kinematic' 
        provided where the decay particle is first."""
        
        from MadSpin.decay import momentum
        
        full = production[:-1]
        
        # Consistency check:
        # target  =  production[decay_number-1]
        # boosted = momentum(decay[0][0],decay[0][1],decay[0][2],decay[0][3])
        # print 'Consistency check ',target==boosted
        for p in decay[1:]:
            bp = momentum(*p).boost(momentum(*production[-1]))
            full.append([bp.E,bp.px,bp.py,bp.pz])
        
        return full
    
    def find_resonances(diagrams):
        """ Find all the resonances in the matrix element in argument """
        
        model = process['model']
        resonances_found = []

        for ll, diag in enumerate(diagrams):
            for amp in diag.get('amplitudes'):
                # 0 specifies the PDG given to the fake s-channels from 
                # vertices with more than four legs
                s_channels, t_channels = amp.\
                 get_s_and_t_channels(process.get_ninitial(), model, 0)
                # The s-channel are given from the outmost ones going inward as
                # vertices, so we must replace parent legs with the outermost ones
                replacement_dict = {}
                for s_channel in s_channels:
                    new_resonance = {
                        'ParticlePDG':s_channel.get('legs')[-1].get('id'),
                        'FSMothersNumbers':[],
                        'PS_point_used':[]}
                    for leg in s_channel.get('legs')[:-1]:
                        if leg.get('number')>0:
                            new_resonance['FSMothersNumbers'].append(
                                                            leg.get('number'))
                        else:
                            try:
                                new_resonance['FSMothersNumbers'].extend(
                                            replacement_dict[leg.get('number')])
                            except KeyError:
                                raise Exception('The following diagram '+\
                                              'is malformed:'+diag.nice_string())
                                               
                    replacement_dict[s_channel.get('legs')[-1].get('number')] = \
                                               new_resonance['FSMothersNumbers']
                    new_resonance['FSMothersNumbers'] = set(
                                              new_resonance['FSMothersNumbers'])
                    if new_resonance not in resonances_found:
                        resonances_found.append(new_resonance)

        # Now we setup the phase-space point for each resonance found
        kept_resonances = []
        for resonance in resonances_found:
            # Discard fake s-channels
            if resonance['ParticlePDG'] == 0:
                continue

            # Discard if the particle appears in the final state
            if abs(resonance['ParticlePDG']) in \
                                [abs(l.get('id')) for l in process.get('legs')]:
                continue

            mass_string = evaluator.full_model.get_particle(
                                           resonance['ParticlePDG']).get('mass')
            mass  = evaluator.full_model.get('parameter_dict')[mass_string].real
            # Discard massless s-channels
            if mass==0.0:
                continue
            
            width_string = evaluator.full_model.get_particle(
                                           resonance['ParticlePDG']).get('width')
            width  = evaluator.full_model.get('parameter_dict')[width_string].real

            # Discard stable s-channels
            if width==0.0:
                continue

            final_state_energy = sum(
                evaluator.full_model.get('parameter_dict')[
                evaluator.full_model.get_particle(l.get('id')).get('mass')].real
                for l in process.get('legs') if l.get('number') in 
                                                  resonance['FSMothersNumbers'])
            
            # Choose the offshellness
            special_mass = (1.0 + options['offshellness'])*mass
            
            # Discard impossible kinematics
            if special_mass<final_state_energy:
                raise InvalidCmd('The offshellness specified (%s) is such'\
                  %options['offshellness']+' that the resulting kinematic is '+\
                  'impossible for resonance %s %s.'%(evaluator.full_model.
                           get_particle(resonance['ParticlePDG']).get_name(),
                                      str(list(resonance['FSMothersNumbers']))))
                continue
            
            # Add it to the list of accepted resonances
            kept_resonances.append(resonance)
            
        for resonance in kept_resonances:
            # Chose the PS point for the resonance
            set_PSpoint(resonance, force_other_res_offshell=kept_resonances)

        return tuple(kept_resonances)

    def set_PSpoint(resonance, force_other_res_offshell=[], 
                                allow_energy_increase=1.5, isolation_cuts=True):
        """ Starting from the specified resonance, construct a phase space point
        for it and possibly also enforce other resonances to be onshell. Possibly
        allow to progressively increase enregy by steps of the integer specified
        (negative float to forbid it) and possible enforce default isolation cuts
        as well."""
        
        def invmass(momenta):
            """ Computes the invariant mass of a list of momenta."""
            ptot = [sum(p[i] for p in momenta) for i in range(4)]
            return math.sqrt(ptot[0]**2-ptot[1]**2-ptot[2]**2-ptot[3]**2)
        
        model = evaluator.full_model
        def getmass(pdg):
            """ Returns the mass of a particle given the current model and its
            pdg given in argument."""
            return model.get('parameter_dict')[
                                       model.get_particle(pdg).get('mass')].real

        N_trials                  = 0
        max_trial                 = 1e4
        nstep_for_energy_increase = 1e3
        PS_point_found            = None
        if options['offshellness'] > 0.0:
            offshellness              = options['offshellness']
        else:
            # We must undershoot the offshellness since one needs more 
            # energy than the target mass to have a valid PS point. So we
            # start with an offshellness 4 times larger, and progressively reduce
            # it later
            offshellness = (0.25*(options['offshellness']+1.0))-1.0
        
        # When offshellness is negative, it is progressively decreased every
        # nstep_for_energy_increase attempts (not increased!), so it is more
        # dangerous, and we therefore want the steps to be smaller
        if options['offshellness'] < 0.0:
            energy_increase = math.sqrt(allow_energy_increase)
        else:
            energy_increase = allow_energy_increase
        # Make sure to remove the resonance itself from force_other_res_offshell
        other_res_offshell = [res for res in force_other_res_offshell if 
                                                                 res!=resonance]

        # Now play it smart on finding starting energy and offshellness and 
        # register all resonance masses
        all_other_res_masses = [getmass(res['ParticlePDG'])
                                                  for res in other_res_offshell]
        resonance_mass = getmass(resonance['ParticlePDG'])

        str_res = '%s %s'%(model.get_particle(
                            resonance['ParticlePDG']).get_name(),
                                       str(list(resonance['FSMothersNumbers'])))
        leg_number_to_leg = dict((l.get('number'),l) for l in process.get('legs'))
        # Find what is the minimum possible offshellness given
        # the mass of the daughters of this resonance.
        # This will only be relevant when options['offshellness'] is negative
        daughter_masses = sum(getmass(leg_number_to_leg[\
                 number].get('id')) for number in resonance['FSMothersNumbers'])
        min_offshellnes = 4.0*((daughter_masses*1.2)/resonance_mass)-1.0

        # Compute the minimal energy given the external states, add 20% to leave
        # enough phase-space
        min_energy = max(sum(getmass(l.get('id')) for l in \
                                  process.get('legs') if l.get('state')==True),
                         sum(getmass(l.get('id')) for l in \
                                  process.get('legs') if l.get('state')==False))
        
        # List all other offshellnesses of the potential daughters of this 
        # resonance
        daughter_offshellnesses = [(1.0+options['offshellness'])*mass 
              for i, mass in enumerate(all_other_res_masses) if 
                      other_res_offshell[i]['FSMothersNumbers'].issubset(
                                                 resonance['FSMothersNumbers'])]
        
        if options['offshellness'] >= 0.0:
            
            if len(daughter_offshellnesses)>0:
                max_mass = max(daughter_offshellnesses)
                # A factor two to have enough phase-space
                offshellness = max(2.0*(max_mass/resonance_mass)-1.0,
                                                        options['offshellness'])
            
            max_mass = max([(1.0+options['offshellness'])*mass for mass in \
                  all_other_res_masses]+[(1.0+offshellness)*resonance_mass])
            
            # Account for external_masses too
            # A factor two to have enough phase-space open
            target = max(min_energy*1.2,max_mass*2.0)
            if target > options['energy']:
                logger.warning("The user-defined energy %f seems "%options['energy']+
              " insufficient to reach the minimum propagator invariant mass "+
              "%f required for the chosen offshellness %f."%(max_mass,
               options['offshellness']) + " Energy reset to %f."%target)
                options['energy'] = target
                
        else:
            if len(daughter_offshellnesses) > 0:
                min_mass = min(daughter_offshellnesses)
                # A factor one half to have enough phase-space
                offshellness = min(0.25*(min_mass/resonance_mass)-1.0,
                                                        options['offshellness'])
            
            # Make sure the chosen offshellness leaves enough energy to produce
            # the daughter masses
            if (1.0+offshellness)*resonance_mass < daughter_masses*1.2:
                msg = 'The resonance %s cannot accomodate'%str_res+\
              ' an offshellness of %f because the daughter'%options['offshellness']+\
              ' masses are %f.'%daughter_masses
                if options['offshellness']<min_offshellnes:
                    msg += ' Try again with an offshellness'+\
                  ' smaller (in absolute value) of at least %f.'%min_offshellnes
                else:
                  msg += ' Try again with a smalled offshellness (in absolute value).'
                raise InvalidCmd(msg)
            
            min_mass = min([(1.0+options['offshellness'])*mass for mass in \
                      all_other_res_masses]+[(1.0+offshellness)*resonance_mass])
            # Account for external_masses too
            # A factor two to have enough phase-space open
            if 2.0*min_mass < options['energy']:
                new_energy = max(min_energy*1.2, 2.0*min_mass)
                logger.warning("The user-defined energy %f seems "%options['energy']+
                  " too large to not overshoot the maximum propagator invariant mass "+
                  "%f required for the chosen offshellness %f."%(min_mass,
                   options['offshellness']) + " Energy reset to %f."%new_energy)
                options['energy'] = new_energy  
        
        if options['offshellness'] < 0.0 and options['energy'] >= min_mass:
            logger.debug("The target energy is not compatible with the mass"+
              " of the external states for this process (%f). It is "%min_mass+
                 "unlikely that a valid kinematic configuration will be found.")
        
        if options['offshellness']<0.0 and offshellness<options['offshellness'] or \
           options['offshellness']>0.0 and offshellness>options['offshellness']:
            logger.debug("Offshellness increased to %f"%offshellness+
                " so as to try to find a kinematical configuration with"+
                " offshellness at least equal to %f"%options['offshellness']+
                                                         " for all resonances.")

        start_energy = options['energy']        
        while N_trials<max_trial:
            N_trials += 1
            if N_trials%nstep_for_energy_increase==0:
                if allow_energy_increase > 0.0:
                    old_offshellness = offshellness
                    if offshellness > 0.0:
                        options['energy'] *= energy_increase
                        offshellness      *= energy_increase
                    else:
                        options['energy'] = max(options['energy']/energy_increase, 
                                                                 min_energy*1.2)
                        offshellness = max(min_offshellnes,
                                       ((offshellness+1.0)/energy_increase)-1.0)
                    if old_offshellness!=offshellness:
                        logger.debug('Trying to find a valid kinematic'+\
                           " configuration for resonance '%s'"%str_res+\
                             ' with increased offshellness %f'%offshellness)

            candidate = get_PSpoint_for_resonance(resonance, offshellness)
            pass_offshell_test = True
            for i, res in enumerate(other_res_offshell):
                # Make sure other resonances are sufficiently offshell too
                if offshellness > 0.0:
                    if invmass([candidate[j-1] for j in res['FSMothersNumbers']]) <\
                        ((1.0+options['offshellness'])*all_other_res_masses[i]):
                        pass_offshell_test = False
                        break
                else:
                    if invmass([candidate[j-1] for j in res['FSMothersNumbers']]) >\
                        ((1.0+options['offshellness'])*all_other_res_masses[i]):
                        pass_offshell_test = False
                        break
            if not pass_offshell_test:
                continue
            # Make sure it is isolated
            if isolation_cuts:
                # Set ptcut to 5% of total energy
                if not evaluator.pass_isolation_cuts(candidate,
                      ptcut=0.05*invmass([candidate[0],candidate[1]]), drcut=0.4):
                    continue
            PS_point_found = candidate
            break
        
        # Restore the initial energy setup
        options['energy'] = start_energy

        if PS_point_found is None:
            err_msg = 'Could not find a valid PS point in %d'%max_trial+\
                ' trials. Try increasing the energy, modify the offshellness '+\
                'or relax some constraints.'
            if options['offshellness']<0.0:
                err_msg +='Try with a positive offshellness instead (or a '+\
                                       'negative one of smaller absolute value)'
            raise InvalidCmd(err_msg)
        else:
#            misc.sprint('PS point found in %s trials.'%N_trials)
#            misc.sprint(PS_point_found)
            resonance['offshellnesses'] = []
            all_other_res_masses = [resonance_mass] + all_other_res_masses
            other_res_offshell   = [resonance] + other_res_offshell
            for i, res in enumerate(other_res_offshell):
                if i==0:
                    res_str = 'self'
                else:
                    res_str = '%s %s'%(model.get_particle(
                                         res['ParticlePDG']).get_name(),
                                             str(list(res['FSMothersNumbers'])))
                resonance['offshellnesses'].append((res_str,(
                    (invmass([PS_point_found[j-1] for j in 
                       res['FSMothersNumbers']])/all_other_res_masses[i])-1.0)))

            resonance['PS_point_used'] = PS_point_found
        
    def get_PSpoint_for_resonance(resonance, offshellness = options['offshellness']):
        """ Assigns a kinematic configuration to the resonance dictionary 
        given in argument."""            

        # Get the particle mass
        mass_string = evaluator.full_model.get_particle(
                                       resonance['ParticlePDG']).get('mass')
        mass  = evaluator.full_model.get('parameter_dict')[mass_string].real
        
        # Choose the offshellness
        special_mass = (1.0 + offshellness)*mass
        
        # Create a fake production and decay process
        prod_proc = base_objects.Process({'legs':base_objects.LegList(
             copy.copy(leg) for leg in process.get('legs') if 
                   leg.get('number') not in resonance['FSMothersNumbers'])})
        # Add the resonant particle as a final state
        # ID set to 0 since its mass will be forced
        # Number set so as to be first in the list in get_momenta
        prod_proc.get('legs').append(base_objects.Leg({
                'number':max(l.get('number') for l in process.get('legs'))+1,
                'state':True,
                'id':0}))
        # now the decay process
        decay_proc = base_objects.Process({'legs':base_objects.LegList(
           copy.copy(leg) for leg in process.get('legs') if leg.get('number') 
             in resonance['FSMothersNumbers'] and not leg.get('state')==False)})
        # Add the resonant particle as an initial state
        # ID set to 0 since its mass will be forced
        # Number set to -1 as well so as to be sure it appears first in 
        # get_momenta
        decay_proc.get('legs').insert(0,base_objects.Leg({
                'number':-1,
                'state':False,
                'id':0}))
        prod_kinematic = evaluator.get_momenta(prod_proc, options=options,
                                               special_mass=special_mass)[0]
        decay_kinematic = evaluator.get_momenta(decay_proc, options=options, 
                                               special_mass=special_mass)[0]
        momenta = glue_momenta(prod_kinematic,decay_kinematic)
        # Reshuffle the momentum so as to put it back in the order specified
        # in the process definition.
        # First the production momenta, without the special decayed particle
        ordered_momenta = [(prod_proc.get('legs')[i].get('number'),momenta[i])
                for i in range(len(prod_proc.get('legs'))-1)]
        # And then the decay ones.
        ordered_momenta += [(decay_proc.get('legs')[-i].get('number'),
                 momenta[-i]) for i in range(1,len(decay_proc.get('legs')))]

        # Return the PSpoint found in the right order
        return [m[1] for m in sorted(ordered_momenta, key = lambda el: el[0])]
        
        # misc.sprint(resonance['PS_point_used'])        
    
    @misc.mute_logger()
    def get_width(PDG, lambdaCMS, param_card):
        """ Returns the width to use for particle with absolute PDG 'PDG' and
        for the lambdaCMS value 'lambdaCMS' using the cache if possible."""

        # If an unstable particle is in the external state, then set its width
        # to zero and don't cache the result of course.
        if abs(PDG) in [abs(leg.get('id')) for leg in process.get('legs')]:
            return 0.0

        particle = evaluator.full_model.get_particle(PDG)
        
        # If it is a goldstone or a ghost, return zero as its width should anyway
        # not be independent.
        if particle.get('ghost') or particle.get('goldstone'):
            return 0.0

        # If its width is analytically set to zero, then return zero right away
        if particle.get('width')=='ZERO':
            return 0.0
    
        if (PDG,lambdaCMS) in options['cached_widths']:
            return options['cached_widths'][(PDG,lambdaCMS)]

        if options['recompute_width'] == 'never':
            width = evaluator.full_model.\
                               get('parameter_dict')[particle.get('width')].real
        else:
            # Crash if we are doing CMS and the width was not found and recycled above
            if aloha.complex_mass:
                raise MadGraph5Error("The width for particle with PDG %d and"%PDG+\
                  " lambdaCMS=%f should have already been "%lambdaCMS+\
                  "computed during the NWA run.")

        # Use MadWith
        if options['recompute_width'] in ['always','first_time']:
            particle_name = particle.get_name()
            with misc.TMP_directory(dir=options['output_path']) as path:
                param_card.write(pjoin(path,'tmp.dat'))
                # 2-body decay is the maximum that should be considered for NLO check.
                # The default 1% accuracy is not enough when pushing to small
                # lambdaCMS values, we need 1 per mil at least.
                # MadEvent integrates it: the check works on the model of its
                # evaluator, which madspace has not been validated on.
                command = '%s --output=%s'%(particle_name,pjoin(path,'tmp.dat'))+\
                    ' --path=%s --body_decay=2'%pjoin(path,'tmp.dat')+\
                    ' --precision_channel=0.001 --engine=madevent'
#                misc.sprint(command)
                param_card.write(pjoin(options['output_path'],'tmp.dat'))
                # The MG5 command get_width will change the cmd._curr_model
                # and the cmd._curr_fortran_model which what we specified, so 
                # we must make sure to restore them after it finishes
                orig_model = options['cmd']._curr_model
                orig_helas_model = options['cmd']._curr_helas_model
                options['cmd'].do_compute_widths(command, evaluator.full_model)
                # Restore the models
                options['cmd']._curr_model = orig_model
                options['cmd']._curr_helas_model = orig_helas_model
                # Restore the width of the model passed in argument since
                # MadWidth will automatically update the width
                evaluator.full_model.set_parameters_and_couplings(
                                                          param_card=param_card)
                try:
                    tmp_param_card = check_param_card.ParamCard(pjoin(path,'tmp.dat'))
                except:
                    raise MadGraph5Error('Error occurred during width '+\
                       'computation with command:\n   compute_widths %s'%command)                   
                width = tmp_param_card['decay'].get(PDG).value
#                misc.sprint('lambdaCMS checked is', lambdaCMS,
#                                                   'for particle',particle_name)
#                misc.sprint('Width obtained :', width)
#                if lambdaCMS != 1.0:
#                    misc.sprint('Naively expected (lin. scaling) :',
#                                  options['cached_widths'][(PDG,1.0)]*lambdaCMS)
                
        if options['recompute_width'] in ['never','first_time']:
            # Assume linear scaling of the width
            for lam in options['lambdaCMS']:
                options['cached_widths'][(PDG,lam)]=width*(lam/lambdaCMS)
        else:
            options['cached_widths'][(PDG,lambdaCMS)] = width
        
        return options['cached_widths'][(PDG,lambdaCMS)]
            
    def get_order(diagrams, diagsName):
        """Compute the common summed of coupling orders used for this cms check
         in the diagrams specified. When inconsistency occurs, use orderName
         in the warning message if throwm."""
         
        orders = set([])
        for diag in diagrams:
            diag_orders = diag.calculate_orders()
            orders.add(sum((diag_orders[order] if order in diag_orders else 0)
                                      for order in options['expansion_orders']))
            if len(orders)>1:
                logger.warning(msg%('%s '%diagsName,str(orders)))
                return min(list(orders))
            else:
                return list(orders)[0]
         
    MLoptions = copy.copy(options['MLOptions'])
    # Make sure double-check helicities is set to False
    MLoptions['DoubleCheckHelicityFilter'] = False
    
    # Apply the seed tweak if present
    for tweak in options['tweak']['custom']:
        if tweak.startswith('seed'):
            try:
                new_seed = int(tweak[4:])
            except ValueError:
                raise MadGraph5Error("Seed '%s' is not of the right format 'seed<int>'."%tweak)
            random.seed(new_seed)
                
    mode = 'CMS' if aloha.complex_mass else 'NWA'
    for i, leg in enumerate(process.get('legs')):
        leg.set('number', i+1)

    logger.info("Running CMS check for process %s  (now doing %s scheme)" % \
                  ( process.nice_string().replace('Process:', 'process'), mode))
    
    proc_dir = None
    resonances = None
    warning_msg = "All %sdiagrams do not share the same sum of orders "+\
            "%s; found %%s."%(','.join(options['expansion_orders']))+\
            " This potentially problematic for the CMS check."
    if NLO:
        # We must first create the matrix element, export it and set it up.
        # If the reuse option is specified, it will be recycled.
        
        if options['name']=='auto':
            proc_name = "%s%s_%s%s__%s__"%(('SAVED' if options['reuse'] else ''),
         temp_dir_prefix, '_'.join(process.shell_string().split('_')[1:]), 
         ('_' if process.get('perturbation_couplings') else '')+
         '_'.join(process.get('perturbation_couplings')),mode)
        else:
            proc_name = "%s%s_%s__%s__"%(('SAVED' if options['reuse'] else ''),
                                          temp_dir_prefix,options['name'], mode)
        # Generate the ME
        timing, matrix_element = generate_loop_matrix_element(process, 
                options['reuse'], output_path=options['output_path'], 
                           cmd = options['cmd'], proc_name=proc_name, 
                                             loop_filter=options['loop_filter'])
        if matrix_element is None:
            # No diagrams for this process
            return None

        reusing = isinstance(matrix_element, base_objects.Process)
        proc_dir = pjoin(options['output_path'],proc_name)

        # Export the ME
        infos = evaluator.setup_process(matrix_element, proc_dir, 
                        reusing = reusing, param_card = options['param_card'], 
                                                            MLOptions=MLoptions)
        # Make sure the right MLoptions are set
        evaluator.fix_MadLoopParamCard(pjoin(proc_dir,'Cards'),
                              mp = None, loop_filter = True,MLOptions=MLoptions)
        
        # Make sure to start from fresh if previous run was stopped
        tmp_card_backup = pjoin(proc_dir,'Cards','param_card.dat__TemporaryBackup__')
        if os.path.isfile(tmp_card_backup):
            # Run was stopped mid-way, we must then restore the original card
            logger.info("Last run in process '%s' apparently aborted."%proc_dir+\
                           " Now reverting 'param_card.dat' to its original value.")
            shutil.copy(tmp_card_backup, pjoin(proc_dir, 'Cards','param_card.dat'))
        else:
            # Create a temporary backup which will be cleaned if the run ends properly
            shutil.copy(pjoin(proc_dir,'Cards','param_card.dat'), tmp_card_backup)
        # Now do the same with model_functions.f
        tmp_modelfunc_backup = pjoin(proc_dir,'Source','MODEL',
                                         'model_functions.f__TemporaryBackup__')
        if os.path.isfile(tmp_modelfunc_backup):
            # Run was stopped mid-way, we must then restore the model functions
            logger.info("Last run in process '%s' apparently aborted."%proc_dir+\
                    " Now reverting 'model_functions.f' to its original value.")
            shutil.copy(tmp_modelfunc_backup, pjoin(proc_dir,'Source','MODEL',
                                                           'model_functions.f'))
            evaluator.apply_log_tweak(proc_dir, 'recompile')
        else:
            # Create a temporary backup which will be cleaned if the run ends properly
            shutil.copy(pjoin(proc_dir,'Source','MODEL','model_functions.f'),
                                                           tmp_modelfunc_backup)

        # Make sure to setup correctly the helicity
        MadLoopInitializer.fix_PSPoint_in_check(pjoin(proc_dir,'SubProcesses'),
              read_ps = True, npoints = 1, hel_config = options['helicity'], 
                                           split_orders=options['split_orders'])
   
        # And recompile while making sure to recreate the executable and 
        # modified sources
        for dir in misc.glob('P*_*', pjoin(proc_dir,'SubProcesses')):
            if not (re.search(r'.*P\d+_\w*$', dir) or not os.path.isdir(dir)):
                continue
            try:
                os.remove(pjoin(dir,'check'))
                os.remove(pjoin(dir,'check_sa.o'))
            except OSError:
                pass
            # Now run make
            with open(os.devnull, 'w') as devnull:
                retcode = subprocess.call(['make','check'],
                                   cwd=dir, stdout=devnull, stderr=devnull)                     
            if retcode != 0:
                raise MadGraph5Error("Compilation error with "+\
                                                        "'make check' in %s"%dir)

        # Now find all the resonances of the ME, if not saved from a previous run
        pkl_path = pjoin(proc_dir,'resonance_specs.pkl')
        if reusing:
            # We recover the information from the pickle dumped during the
            # original run
            if not os.path.isfile(pkl_path):
                raise InvalidCmd('The folder %s could'%proc_dir+\
                 " not be reused because the resonance specification file "+
                                            "'resonance_specs.pkl' is missing.")
            else:
                proc_name, born_order, loop_order, resonances = \
                                       save_load_object.load_from_file(pkl_path)
                # Make sure to rederive the phase-space point since parameters
                # such as masses, seed, offshellness could have affected it
                for res in resonances:
                    set_PSpoint(res, force_other_res_offshell=resonances)

            # Second run (CMS), we can reuse the information if it is a dictionary
            if isinstance(opt, list):
                opt.append((proc_name, resonances))
            else:
                resonances = opt
        else:
            helas_born_diagrams = matrix_element.get_born_diagrams()
            if len(helas_born_diagrams)==0:
                logger.warning('The CMS check for loop-induced process is '+\
                                  'not yet available (nor is it very interesting).')
                return None
            born_order = get_order(helas_born_diagrams,'Born')
            loop_order = get_order(matrix_element.get_loop_diagrams(),'loop')

            # Second run (CMS), we can reuse the information if it is a dictionary
            if isinstance(opt, list):
                opt.append((process.base_string(),find_resonances(helas_born_diagrams)))
                resonances = opt[-1][1]
            else:
                resonances = opt
            # Save the resonances to a pickle file in the output directory so that
            # it can potentially be reused.
            save_load_object.save_to_file(pkl_path, (process.base_string(),
                                             born_order, loop_order,resonances))

    else:
        # The LO equivalent
        try:
            amplitude = diagram_generation.Amplitude(process)
        except InvalidCmd:
            logging.info("No diagrams for %s" % \
                            process.nice_string().replace('Process', 'process'))
            return None
        if not amplitude.get('diagrams'):
            # This process has no diagrams; go to next process
            logging.info("No diagrams for %s" % \
                             process.nice_string().replace('Process', 'process'))
            return None

        matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                                 gen_color=True)
        diagrams = matrix_element.get('diagrams')
        born_order = get_order(diagrams,'Born')
        # Loop order set to -1 indicates an LO result
        loop_order = -1
        # Find all the resonances of the ME, if not already given in opt
        if isinstance(opt, list):
            opt.append((process.base_string(),find_resonances(diagrams)))
            resonances = opt[-1][1]
        else:
            resonances= opt
    
    if len(resonances)==0:
        logger.info("No resonance found for process %s."\
                                                         %process.base_string())
        return None
    
    # Cache the default param_card for NLO
    if not options['cached_param_card'][mode][0]:
        if NLO:
            param_card = check_param_card.ParamCard(
                                       pjoin(proc_dir,'Cards','param_card.dat'))
        else:
            param_card = check_param_card.ParamCard(
                     StringIO.StringIO(evaluator.full_model.write_param_card()))
        options['cached_param_card'][mode][0] = param_card
        name2block, _ = param_card.analyze_param_card()
        options['cached_param_card'][mode][1] = name2block
        
    else:
        param_card = options['cached_param_card'][mode][0]
        name2block = options['cached_param_card'][mode][1]

    # Already add the coupling order for this squared ME.
    if loop_order != -1 and (loop_order+born_order)%2 != 0:
        raise MadGraph5Error('The summed squared matrix element '+\
                              " order '%d' is not even."%(loop_order+born_order))
    result = {'born_order':born_order, 
              'loop_order': (-1 if loop_order==-1 else (loop_order+born_order)/2),
              'resonances_result':[]}

    # Create a physical backup of the param_card
    if NLO:
        try:
            shutil.copy(pjoin(proc_dir,'Cards','param_card.dat'),
                             pjoin(proc_dir,'Cards','param_card.dat__backUp__'))
        except:
            pass

    # Apply custom tweaks
    had_log_tweaks=False
    if NLO:
        for tweak in options['tweak']['custom']:
            if tweak.startswith('seed'):
                continue
            try:
                logstart, logend = tweak.split('->')
            except:
                raise Madgraph5Error("Tweak '%s' not reckognized."%tweak)
            if logstart in ['logp','logm', 'log'] and \
               logend in ['logp','logm', 'log']:
                if NLO:
                    evaluator.apply_log_tweak(proc_dir, [logstart, logend])
                    had_log_tweaks = True
            else:
                raise Madgraph5Error("Tweak '%s' not reckognized."%tweak)
        if had_log_tweaks:
            evaluator.apply_log_tweak(proc_dir, 'recompile')

    # Select what resonances should be run
    if options['resonances']=='all':
        resonances_to_run = resonances
    elif isinstance(options['resonances'],int):
        resonances_to_run = resonances[:options['resonances']]    
    elif isinstance(options['resonances'],list):
        resonances_to_run = []
        for res in resonances:
            for res_selection in options['resonances']:
                if abs(res['ParticlePDG'])==res_selection[0] and \
                                 res['FSMothersNumbers']==set(res_selection[1]):
                    resonances_to_run.append(res)
                    break
    else:
        raise InvalidCmd("Resonance selection '%s' not reckognized"%\
                                                     str(options['resonances']))

    # Display progressbar both for LO and NLO for now but not when not showing
    # the plots
    if NLO and options['show_plot']:
        widgets = ['ME evaluations:', pbar.Percentage(), ' ', 
                                                pbar.Bar(),' ', pbar.ETA(), ' ']
        progress_bar = pbar.ProgressBar(widgets=widgets, 
                maxval=len(options['lambdaCMS'])*len(resonances_to_run), fd=sys.stdout)
        progress_bar.update(0)
        # Flush stdout to force the progress_bar to appear
        sys.stdout.flush()
    else:
        progress_bar = None

    for resNumber, res in enumerate(resonances_to_run):
        # First add a dictionary for this resonance to the result with already
        # one key specifying the resonance
        result['resonances_result'].append({'resonance':res,'born':[]})
        if NLO:
            result['resonances_result'][-1]['finite'] = []
        # Now scan the different lambdaCMS values
        for lambdaNumber, lambdaCMS in enumerate(options['lambdaCMS']):
            # Setup the model for that value of lambdaCMS
            # The copy constructor below creates a deep copy
            new_param_card = check_param_card.ParamCard(param_card)
            # Change all specified parameters
            for param, replacement in options['expansion_parameters'].items():
                # Replace the temporary prefix used for evaluation of the 
                # substitution expression 
                orig_param = param.replace('__tmpprefix__','')
                if orig_param not in name2block:
                    # It can be that some parameter ar in the NWA model but not
                    # in the CMS, such as the Yukawas for example.
                    # logger.warning("Unknown parameter '%s' in mode '%s'."%(param,mode))
                    continue
                for block, lhaid in name2block[orig_param]:
                    orig_value = float(param_card[block].get(lhaid).value)
                    new_value  = eval(replacement,
                                       {param:orig_value,'lambdacms':lambdaCMS})
                    new_param_card[block].get(lhaid).value=new_value

            # Apply these changes already (for the purpose of Width computation.
            # although it is optional since we now provide the new_param_card to
            # the width computation function.). Also in principle this matters
            # only in the CMS and there the widths would be reused from their 
            # prior computation within NWA with zero widths. So, all in all,
            # the line below is really not crucial, but semantically, it ought
            # to be there.
            evaluator.full_model.set_parameters_and_couplings(
                                                      param_card=new_param_card)
            # Now compute or recycle all widths
            for decay in new_param_card['decay'].keys():
                if mode=='CMS':
                    new_width = get_width(abs(decay[0]), lambdaCMS, 
                                                                 new_param_card)
                else:
                    new_width = 0.0
                new_param_card['decay'].get(decay).value= new_width

            # Apply these changes for the purpose of the final computation
            evaluator.full_model.set_parameters_and_couplings(
                                                      param_card=new_param_card)
            if NLO:
                new_param_card.write(pjoin(proc_dir,'Cards','param_card.dat'))
                # Write the recomputed widths so that it can potentially be
                # used for future runs (here for the model in the CMS format)
                if lambdaCMS==1.0 and mode=='CMS' and \
                          options['recompute_width'] in ['always','first_time']:
                    new_param_card.write(pjoin(proc_dir,
                                    'Cards','param_card.dat_recomputed_widths'))
                    
            # If recomputing widths with MadWidths, we want to do it within
            # the NWA models with zero widths.
            if mode=='NWA' and (options['recompute_width']=='always' or (
                  options['recompute_width']=='first_time' and lambdaCMS==1.0)):
                # The copy constructor below creates a deep copy
                tmp_param_card = check_param_card.ParamCard(new_param_card)
                # We don't use the result here, it is just so that it is put
                # in the cache and reused in the CMS run that follows.
                for decay in new_param_card['decay'].keys():
                    particle_name = evaluator.full_model.get_particle(\
                                                       abs(decay[0])).get_name()
                    new_width = get_width(abs(decay[0]),lambdaCMS,new_param_card)
                    tmp_param_card['decay'].get(decay).value = new_width
                    if not options['has_FRdecay'] and new_width != 0.0 and \
                      (abs(decay[0]),lambdaCMS) not in options['cached_widths']:
                        logger.info('Numerically computed width of particle'+\
                                        ' %s for lambda=%.4g : %-9.6gGeV'%
                                            (particle_name,lambdaCMS,new_width))

                # Write the recomputed widths so that it can potentially be
                # used for future runs (here the model in the NWA format)
                if lambdaCMS==1.0 and NLO:
                    tmp_param_card.write(pjoin(proc_dir,
                                    'Cards','param_card.dat_recomputed_widths'))
            
            # Apply the params tweaks
            for param, replacement in options['tweak']['params'].items():
               # Replace the temporary prefix used for evaluation of the 
               # substitution expression 
               orig_param = param.replace('__tmpprefix__','')
               # Treat the special keyword 'allwidths'
               if orig_param.lower() == 'allwidths':
                    # Apply the rule to all widhts
                    for decay in new_param_card['decay'].keys():
                        orig_value = float(new_param_card['decay'].get(decay).value)
                        new_value = eval(replacement,
                                       {param:orig_value,'lambdacms':lambdaCMS})
                        new_param_card['decay'].get(decay).value = new_value
                    continue
               if orig_param not in name2block:
                   # It can be that some parameter are in the NWA model but not
                   # in the CMS, such as the Yukawas for example.
                   continue
               for block, lhaid in name2block[orig_param]:
                   orig_value = float(new_param_card[block].get(lhaid).value)
                   new_value  = eval(replacement,
                                       {param:orig_value,'lambdacms':lambdaCMS})
                   new_param_card[block].get(lhaid).value=new_value
            
            if options['tweak']['params']:
                # Apply the tweaked param_card one last time
                evaluator.full_model.set_parameters_and_couplings(
                                                      param_card=new_param_card)
                if NLO:
                    new_param_card.write(pjoin(proc_dir,'Cards','param_card.dat'))

            # Finally ready to compute the matrix element
            if NLO:
                ME_res = LoopMatrixElementEvaluator.get_me_value(process, 0, 
                       proc_dir, PSpoint=res['PS_point_used'], verbose=False, 
                                           format='dict', skip_compilation=True)
                # Notice that there is much more information in ME_res. It can
                # be forwarded to check_complex_mass_scheme in this result
                # dictionary if necessary for the analysis. (or even the full 
                # dictionary ME_res can be added).
                result['resonances_result'][-1]['born'].append(ME_res['born'])
                result['resonances_result'][-1]['finite'].append(
                      ME_res['finite']*ME_res['born']*ME_res['alphaS_over_2pi'])
            else:
                ME_res = evaluator.evaluate_matrix_element(matrix_element,
                    p=res['PS_point_used'], auth_skipping=False, output='m2')[0]
                result['resonances_result'][-1]['born'].append(ME_res)
            if not progress_bar is None:
                progress_bar.update(resNumber*len(options['lambdaCMS'])+\
                                                               (lambdaNumber+1))
                # Flush to force the printout of the progress_bar to be updated
                sys.stdout.flush()

    # Restore the original continued log definition if necessary
    log_reversed = False
    for tweak in options['tweak']['custom']:
        if tweak.startswith('log') and had_log_tweaks:
            if log_reversed:
                continue
            if NLO:
                evaluator.apply_log_tweak(proc_dir, 'default')
                evaluator.apply_log_tweak(proc_dir, 'recompile')                
                log_reversed = True

    # Restore the original model parameters
    evaluator.full_model.set_parameters_and_couplings(param_card=param_card)
    if NLO:
        try:
            shutil.copy(pjoin(proc_dir,'Cards','param_card.dat__backUp__'),
                                      pjoin(proc_dir,'Cards','param_card.dat'))
        except:
            param_card.write(pjoin(proc_dir,'Cards','param_card.dat'))
    
    # All should have been restored properly, so we can now clean the temporary
    # backups
    try:
        os.remove(pjoin(proc_dir,'Cards','param_card.dat__TemporaryBackup__'))
        os.remove(pjoin(proc_dir,'Source','MODEL',
                                        'model_functions.f__TemporaryBackup__'))
    except:
        pass

    return (process.nice_string().replace('Process:', '').strip(),result)

def get_value(process, evaluator, p=None, options=None):
    """Return the value/momentum for a phase space point"""
    
    for i, leg in enumerate(process.get('legs')):
        leg.set('number', i+1)

    name = {0:'Feynman', 1:'unitary', 2:'axial', 3:'FD'}[int(aloha.unitary_gauge)]

    logger.info("Checking %s in %s gauge" % \
        ( process.nice_string().replace('Process:', 'process'), name))

    legs = process.get('legs')
    # Generate a process with these legs
    # Generate the amplitude for this process
    try:
        if process.get('perturbation_couplings')==[]:
            amplitude = diagram_generation.Amplitude(process)
        else:
            amplitude = loop_diagram_generation.LoopAmplitude(process)
    except InvalidCmd:
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None
    logger.debug("number of diagrams %d" % len(amplitude.get('diagrams')))
    if not amplitude.get('diagrams'):
        # This process has no diagrams; go to next process
        logging.info("No diagrams for %s" % \
                         process.nice_string().replace('Process', 'process'))
        return None
    
    if not p:
        # Generate phase space point to use
        p, w_rambo = evaluator.get_momenta(process, options)
        
    # Generate the HelasMatrixElement for the process
    if not isinstance(amplitude, loop_diagram_generation.LoopAmplitude):
        matrix_element = helas_objects.HelasMatrixElement(amplitude,
                                                      gen_color = True)
    else:
        matrix_element = loop_helas_objects.LoopHelasMatrixElement(amplitude, 
           gen_color = True, optimized_output = evaluator.loop_optimized_output)

    mvalue = evaluator.evaluate_matrix_element(matrix_element, p=p,
                                                  output='jamp',options=options)
    
    if mvalue and mvalue['m2']:
        return {'process':process.base_string(),'value':mvalue,'p':p}

def output_lorentz_inv_loop(comparison_results, output='text'):
    """Present the results of a comparison in a nice list format for loop 
    processes. It detail the results from each lorentz transformation performed.
    """

    process = comparison_results[0]['process']
    results = comparison_results[0]['results']
    # Rotations do not change the reference vector for helicity projection,
    # the loop ME are invarariant under them with a relatively good accuracy.
    threshold_rotations = 1e-6
    # This is typically not the case for the boosts when one cannot really 
    # expect better than 1e-5. It turns out that this is even true in 
    # quadruple precision, for an unknown reason so far.
    threshold_boosts =  1e-3
    res_str = "%s" % process.base_string()
    
    transfo_col_size = 17
    col_size = 18
    transfo_name_header = 'Transformation name'

    if len(transfo_name_header) + 1 > transfo_col_size:
        transfo_col_size = len(transfo_name_header) + 1
    
    for transfo_name, value in results:
        if len(transfo_name) + 1 > transfo_col_size:
            transfo_col_size = len(transfo_name) + 1
        
    res_str += '\n' + fixed_string_length(transfo_name_header, transfo_col_size) + \
      fixed_string_length("Value", col_size) + \
      fixed_string_length("Relative diff.", col_size) + "Result"
    
    ref_value = results[0]
    res_str += '\n' + fixed_string_length(ref_value[0], transfo_col_size) + \
                   fixed_string_length("%1.10e" % ref_value[1]['m2'], col_size)
    # Now that the reference value has been recuperated, we can span all the 
    # other evaluations
    all_pass = True
    for res in results[1:]:
        threshold = threshold_boosts if 'BOOST' in res[0].upper() else \
                                                             threshold_rotations
        rel_diff = abs((ref_value[1]['m2']-res[1]['m2'])\
                                       /((ref_value[1]['m2']+res[1]['m2'])/2.0))
        this_pass = rel_diff <= threshold
        if not this_pass: 
            all_pass = False
        res_str += '\n' + fixed_string_length(res[0], transfo_col_size) + \
                   fixed_string_length("%1.10e" % res[1]['m2'], col_size) + \
                   fixed_string_length("%1.10e" % rel_diff, col_size) + \
                   ("Passed" if this_pass else "Failed")
    if all_pass:
        res_str += '\n' + 'Summary: passed'
    else:
        res_str += '\n' + 'Summary: failed'
    
    return res_str

def output_lorentz_inv(comparison_results, output='text'):
    """Present the results of a comparison in a nice list format
        if output='fail' return the number of failed process -- for test-- 
    """

    # Special output for loop processes
    if comparison_results[0]['process']['perturbation_couplings']!=[]:
        return output_lorentz_inv_loop(comparison_results, output)

    proc_col_size = 17

    threshold=1e-10
    process_header = "Process"

    if len(process_header) + 1 > proc_col_size:
        proc_col_size = len(process_header) + 1
    
    for proc, values in comparison_results:
        if len(proc) + 1 > proc_col_size:
            proc_col_size = len(proc) + 1

    col_size = 18

    pass_proc = 0
    fail_proc = 0
    no_check_proc = 0

    failed_proc_list = []
    no_check_proc_list = []

    res_str = fixed_string_length(process_header, proc_col_size) + \
              fixed_string_length("Min element", col_size) + \
              fixed_string_length("Max element", col_size) + \
              fixed_string_length("Relative diff.", col_size) + \
              "Result"

    for one_comp in comparison_results:
        proc = one_comp['process'].base_string()
        data = one_comp['results']
        
        if data == 'pass':
            no_check_proc += 1
            no_check_proc_list.append(proc)
            continue

        values = [data[i]['m2'] for i in range(len(data))]
        
        min_val = min(values)
        max_val = max(values)
        diff = (max_val - min_val) / abs(max_val) 
        
        res_str += '\n' + fixed_string_length(proc, proc_col_size) + \
                   fixed_string_length("%1.10e" % min_val, col_size) + \
                   fixed_string_length("%1.10e" % max_val, col_size) + \
                   fixed_string_length("%1.10e" % diff, col_size)
                   
        if diff < threshold:
            pass_proc += 1
            proc_succeed = True
            res_str += "Passed"
        else:
            fail_proc += 1
            proc_succeed = False
            failed_proc_list.append(proc)
            res_str += "Failed"

        #check all the JAMP
        # loop over jamp
        # Keep in mind that this is not available for loop processes where the
        # jamp list is empty
        if len(data[0]['jamp'])!=0:
            for k in range(len(data[0]['jamp'][0])):
                sum = [0] * len(data)
                # loop over helicity
                for j in range(len(data[0]['jamp'])):
                    #values for the different lorentz boost
                    values = [abs(data[i]['jamp'][j][k])**2 for i in range(len(data))]
                    sum = [sum[i] + values[i] for i in range(len(values))]
    
                # Compare the different lorentz boost  
                min_val = min(sum)
                max_val = max(sum)
                if not max_val:
                    continue
                diff = (max_val - min_val) / max_val 
            
                tmp_str = '\n' + fixed_string_length('   JAMP %s'%k , proc_col_size) + \
                           fixed_string_length("%1.10e" % min_val, col_size) + \
                           fixed_string_length("%1.10e" % max_val, col_size) + \
                           fixed_string_length("%1.10e" % diff, col_size)
                       
                if diff > 1e-10:
                    if not len(failed_proc_list) or failed_proc_list[-1] != proc:
                        fail_proc += 1
                        pass_proc -= 1
                        failed_proc_list.append(proc)
                    res_str += tmp_str + "Failed"
                elif not proc_succeed:
                 res_str += tmp_str + "Passed" 
            
            
        
    res_str += "\nSummary: %i/%i passed, %i/%i failed" % \
                (pass_proc, pass_proc + fail_proc,
                 fail_proc, pass_proc + fail_proc)

    if fail_proc != 0:
        res_str += "\nFailed processes: %s" % ', '.join(failed_proc_list)
    if no_check_proc:
        res_str += "\nNot checked processes: %s" % ', '.join(no_check_proc_list)
    
    if output == 'text':
        return res_str        
    else: 
        return fail_proc

def output_unitary_feynman(comparison_results, output='text'):
    """Present the results of a comparison in a nice list format
        if output='fail' return the number of failed process -- for test-- 
    """
    
    proc_col_size = 17
    
    # We use the first element of the comparison_result list to store the
    # process definition object
    pert_coupl = comparison_results[0]['perturbation_couplings']
    comparison_results = comparison_results[1:]
    
    if pert_coupl:
        process_header = "Process [virt="+" ".join(pert_coupl)+"]"
    else:
        process_header = "Process"
    
    if len(process_header) + 1 > proc_col_size:
        proc_col_size = len(process_header) + 1
    
    for data in comparison_results:
        proc = data['process']
        if len(proc) + 1 > proc_col_size:
            proc_col_size = len(proc) + 1

    pass_proc = 0
    fail_proc = 0
    no_check_proc = 0

    failed_proc_list = []
    no_check_proc_list = []

    col_size = 18
    use_axial = any('value_axial' in comp for comp in comparison_results)
    use_fd = any('value_fd' in comp for comp in comparison_results)
    gauge_columns = [("Unitary", 'value_unit'), ("Feynman", 'value_feynm')]
    if use_axial:
        gauge_columns.append(("Axial", 'value_axial'))
    if use_fd:
        gauge_columns.append(("FD", 'value_fd'))

    res_str = fixed_string_length(process_header, proc_col_size)
    for label, _ in gauge_columns:
        res_str += fixed_string_length(label, col_size)
    res_str += fixed_string_length("Relative diff.", col_size) + "Result"

    for one_comp in comparison_results:
        proc = one_comp['process']
        data = [one_comp[key] for _, key in gauge_columns]
        
        
        if data[0] == 'pass':
            no_check_proc += 1
            no_check_proc_list.append(proc)
            continue
        
        values = [data[i]['m2'] for i in range(len(data))]
        
        min_val = min(values)
        max_val = max(values)
        # when max_val is also negative
        # diff will be negative if there is no abs
        diff = (max_val - min_val) / abs(max_val) 
        
        res_str += '\n' + fixed_string_length(proc, proc_col_size)
        for value in values:
            res_str += fixed_string_length("%1.10e" % value, col_size)
        res_str += fixed_string_length("%1.10e" % diff, col_size)
                   
        if diff < 1e-8:
            pass_proc += 1
            proc_succeed = True
            res_str += "Passed"
        else:
            fail_proc += 1
            proc_succeed = False
            failed_proc_list.append(proc)
            res_str += "Failed"

        #check all the JAMP
        # loop over jamp
        # This is not available for loop processes where the jamp list returned
        # is empty.
        if len(data[0]['jamp'])>0:
            for k in range(len(data[0]['jamp'][0])):
                sum = [0] * len(data)
                # loop over helicity
                for j in range(len(data[0]['jamp'])):
                    #values for the different lorentz boost
                    values = [abs(data[i]['jamp'][j][k])**2 for i in range(len(data))]
                    sum = [sum[i] + values[i] for i in range(len(values))]
    
                # Compare the different lorentz boost  
                min_val = min(sum)
                max_val = max(sum)
                if not max_val:
                    continue
                diff = (max_val - min_val) / max_val 
            
                tmp_str = '\n' + fixed_string_length('   JAMP %s'%k , col_size)
                for value in sum:
                    tmp_str += fixed_string_length("%1.10e" % value, col_size)
                tmp_str += fixed_string_length("%1.10e" % diff, col_size)
                       
                if diff > 1e-10:
                    if not len(failed_proc_list) or failed_proc_list[-1] != proc:
                        fail_proc += 1
                        pass_proc -= 1
                        failed_proc_list.append(proc)
                    res_str += tmp_str + "Failed"
                elif not proc_succeed:
                     res_str += tmp_str + "Passed" 
                
            
        
    res_str += "\nSummary: %i/%i passed, %i/%i failed" % \
                (pass_proc, pass_proc + fail_proc,
                 fail_proc, pass_proc + fail_proc)

    if fail_proc != 0:
        res_str += "\nFailed processes: %s" % ', '.join(failed_proc_list)
    if no_check_proc:
        res_str += "\nNot checked processes: %s" % ', '.join(no_check_proc_list)
    
    
    if output == 'text':
        return res_str        
    else: 
        return fail_proc

def CMS_save_path(extension, cms_res, used_model, opts, output_path=None):
    """Creates a suitable filename for saving these results."""
    
    if opts['name']=='auto' and opts['analyze']!='None':
        # Reuse the same name then
        return '%s.%s'%(os.path.splitext(opts['analyze'].split(',')[0])\
                                                                  [0],extension)
    # if a name is specified, use it
    if opts['name']!='auto':
        basename = opts['name']
    else:
        prefix = 'cms_check_'
        # Use process name if there is only one process            
        if len(cms_res['ordered_processes'])==1:
            proc = cms_res['ordered_processes'][0]
            replacements = [('=>','gt'),('<=','lt'),('/','_no_'),
                            (' ',''),('+','p'),('-','m'),
                            ('~','x'), ('>','_'),('=','eq'),('^2','squared')]
            # Remove the perturbation couplings:
            try:
                proc=proc[:proc.index('[')]
            except ValueError:
                pass
    
            for key, value in replacements:
                proc = proc.replace(key,value)
    
            basename =prefix+proc+'_%s_'%used_model.get('name')+\
                      ( ('_'+'_'.join(cms_res['perturbation_orders'])) if \
                                      cms_res['perturbation_orders']!=[] else '')
        # Use timestamp otherwise
        else:
            basename = prefix+datetime.datetime.now().strftime("%Y_%m_%d_%Hh%Mm%Ss")
            
    suffix = '_%s'%opts['tweak']['name'] if opts['tweak']['name']!='' else '' 
    if output_path:     
        return pjoin(output_path,'%s%s.%s'%(basename,suffix,extension))
    else:
        return '%s%s.%s'%(basename,suffix,extension)

def output_complex_mass_scheme(result,output_path, options, model, output='text'):
    """ Outputs nicely the outcome of the complex mass scheme check performed
    by varying the width in the offshell region of resonances found for each process.
    Output just specifies whether text should be returned or a list of failed
    processes. Use 'concise_text' for a consise report of the results."""
    
    pert_orders=result['perturbation_orders']
    
    ######## CHECK PARAMETERS #########
    #
    # diff_lambda_power choses the power by which one should divide the difference
    # curve. The test should only work with 1, but it is useful for the LO
    # check to see the difference has O(\lambda) contribution by setting this
    # parameter to 2. If the Born does not have O(\lambda) contributions
    # (i.e. if the test still pas with diff_lambda_power=2) then the NLO test
    # will not be sensitive to the CMS implementation details.
    diff_lambda_power = options['diff_lambda_power']
    # DISCLAIMER:
    # The CMS check is non trivial to automate and it is actually best done
    # manually by looking at plots for various implementation of the CMS.
    # The automatic check performed here with the default parameters below
    # should typically capture the main features of the CMS implementation.
    # There will always be exceptions however.
    #
    if 'has_FRdecay' in result:
        has_FRdecay = result['has_FRdecay']
    else:
        has_FRdecay = False
    # be tighter at LO
    if not pert_orders:
        CMS_test_threshold = 1e-3
    else:
        # AT NLO, a correct cancellation is typically of the order of 2% with
        # a lowest lambda value of 10^-4. It is clear that the threshold should
        # scale with the minimum lambda value because any little offset in the
        # LO width value for example (acceptable when less than one 1% if the
        # widths were computed numerically) will lead to an inaccuracy of the 
        # cancellation scaling with lambda. 
        if not has_FRdecay and ('recomputed_with' not in result or \
                          result['recompute_width'] in ['always','first_time']):
            CMS_test_threshold = 2e-2*(1.0e-4/min(result['lambdaCMS']))
        else:
            # If the widths were not computed numerically, then the accuracy of
            # the cancellation should be better.
            CMS_test_threshold = 2e-2*(1.0e-5/min(result['lambdaCMS']))
            
    # This threshold sets how flat the diff line must be when approaching it from
    # the right to start considering its value. Notice that it cannot be larger
    # than the CMS_test_threshold
    consideration_threshold = min(CMS_test_threshold/10.0, 0.05)
    # Number of values grouped with the median technique to avoid being
    # sensitive to unstabilities
    group_val = 3
    # Starting from which value, relative to the averaged diff, should one consider
    # the asymptotic diff median to be exactly 0.0 in which case one would use this
    # average instead of this asymptotic median. u d~ > e+ ve LO exhibit a \
    # difference at zero for example.
    diff_zero_threshold = 1e-3
    # Plotting parameters. Specify the lambda range to plot. 
    # lambda_range = [-1,-1] returns the default automatic setup
    lambda_range = options['lambda_plot_range']
    ##################################
    
#   One can print out the raw results by uncommenting the line below
#    misc.sprint(result)
#    for i, res in enumerate(result['a e- > e- ve ve~ [ virt = QCD QED ]']['CMS']):
#    for i, res in enumerate(result['u d~ > e+ ve a [ virt = QCD QED ]']['CMS']):
#        if res['resonance']['FSMothersNumbers'] == set([3, 4]):
#            misc.sprint(res['resonance']['PS_point_used'])
#    stop
    
    res_str           = ''
    # Variables for the concise report
    concise_str       = ''
    concise_data      = '%%(process)-%ds%%(asymptot)-15s%%(cms_check)-25s%%(status)-25s\n'
    concise_repl_dict = {'Header':{'process':'Process',
                                   'asymptot':'Asymptot',
                                   'cms_check':'Deviation to asymptot',
                                   'status':'Result'}}
    
    ####### BEGIN helper functions

    # Chose here whether to use Latex particle names or not
    # Possible values are 'none', 'model' or 'built-in'
    useLatexParticleName = 'built-in'
    name2tex = {'e+':r'e^+','w+':r'W^+','a':r'\gamma','g':'g',
                'e-':r'e^-','w-':r'W^-','z':'Z','h':'H',
                'mu+':r'\mu^+',
                'mu-':r'\mu^-',
                'ta+':r'\tau^+',
                'ta-':r'\tau^-'}
    for p in ['e','m','t']:
        d = {'e':'e','m':r'\mu','t':r'\tau'}
        name2tex['v%s'%p]=r'\nu_{%s}'%d[p]
        name2tex['v%s~'%p]=r'\bar{\nu_{%s}}'%d[p]
        
    for p in ['u','d','c','s','b','t']:
        name2tex[p]=p
        name2tex['%s~'%p]=r'\bar{%s}'%p
      
    def format_particle_name(particle, latex=useLatexParticleName):
        p_name = particle
        if latex=='model':
            try:
                texname = model.get_particle(particle).get('texname')
                if texname and texname!='none':
                    p_name = r'$\displaystyle %s$'%texname
            except:
                pass
        elif latex=='built-in':
            try:
                p_name = r'$\displaystyle %s$'%name2tex[particle]
            except:
                pass
        return p_name

    def resonance_str(resonance, latex=useLatexParticleName):
        """ Provides a concise string to characterize the resonance """
        particle_name = model.get_particle(resonance['ParticlePDG']).get_name()
        mothersID=['%d'%n for n in sorted(resonance['FSMothersNumbers'])]
        return r"%s [%s]"%(format_particle_name(particle_name,latex=latex),
                                                            ','.join(mothersID))

    def format_title(process, resonance):
        """ Format the plot title given the process and resonance """
        
        process_string = []
        for particle in process.split():
            if '<=' in particle:
                particle = particle.replace('<=',r'$\displaystyle <=$')
            if '^2' in particle:
                particle = particle.replace('^2',r'$\displaystyle ^2$')
            if particle=='$$':
                process_string.append(r'\$\$')
                continue
            if particle=='>':
                process_string.append(r'$\displaystyle \rightarrow$')
                continue
            if particle=='/':
                process_string.append(r'$\displaystyle /$')
                continue
            process_string.append(format_particle_name(particle))              

        if resonance=='':
            return r'CMS check for %s' %(' '.join(process_string))
        else:
            return r'CMS check for %s ( resonance %s )'\
                                           %(' '.join(process_string),resonance)

    def guess_lambdaorder(ME_values_list, lambda_values, expected=None,
                                                           proc=None, res=None):
        """ Guess the lambda scaling from a list of ME values and return it.
        Also compare with the expected result if specified and trigger a 
        warning if not in agreement."""
        # guess the lambdaCMS power in the amplitude squared
        bpowers = []
        for i, lambdaCMS in enumerate(lambda_values[1:]):
            bpowers.append(round(math.log(ME_values_list[0]/ME_values_list[i+1],\
                                                   lambda_values[0]/lambdaCMS)))

        # Pick the most representative power
        bpower = sorted([(el, bpowers.count(el)) for el in set(bpowers)],
                                 key = lambda elem: elem[1], reverse=True)[0][0]
        if not expected:
            return bpower
        if bpower != expected:
            logger.warning('The apparent scaling of the squared amplitude'+
             'seems inconsistent w.r.t to detected value '+
             '(%i vs %i). %i will be used.'%(expected,bpower,bpower)+
             ' This happened for process %s and resonance %s'%(proc, res))
        return bpower    

    def check_stability(ME_values, lambda_values, lambda_scaling, values_name):
        """ Checks if the values passed in argument are stable and return the 
        stability check outcome warning if it is not precise enough. """

        values = sorted([
            abs(val*(lambda_values[0]/lambda_values[i])**lambda_scaling) for \
                                                i, val in enumerate(ME_values)])
        median = values[len(values)//2]
        max_diff = max(abs(values[0]-median),abs(values[-1]-median))
        stability = max_diff/median
        stab_threshold = 1e-2
        if stability >= stab_threshold:
            return "== WARNING: Stability check failed for '%s' with stability %.2e.\n"\
                                                       %(values_name, stability)
        else:
            return None
    ####### END helper functions
    if options['analyze']=='None':
        if options['reuse']:
            save_path = CMS_save_path('pkl', result, model, options, 
                                                        output_path=output_path)
            buff = "\nThe results of this check have been stored on disk and its "+\
              "analysis can be rerun at anytime with the MadGraph7 command:\n   "+\
            "      check cms --analyze=%s\n"%save_path
            res_str += buff
            concise_str += buff
            save_load_object.save_to_file(save_path, result)
        elif len(result['ordered_processes'])>0:
            buff = "\nUse the following synthax if you want to store "+\
                    "the raw results on disk.\n"+\
                    "    check cms -reuse <proc_def> <options>\n"
            res_str += buff
            concise_str += buff            
    
    ############################
    # Numerical check first    #
    ############################
    
    checks = []
    for process in result['ordered_processes']:
        checks.extend([(process,resID) for resID in \
                                            range(len(result[process]['CMS']))])
        
    if options['reuse']:
        logFile = open(CMS_save_path(
                    'log', result, model, options, output_path=output_path),'w')
    
    lambdaCMS_list=result['lambdaCMS']
    
    # List of failed processes
    failed_procs = []

    # A bar printing function helper. Change the length here for esthetics
    bar = lambda char: char*47

    # Write out the widths used if information is present:
    if 'widths_computed' in result:
        res_str += '\n%s%s%s\n'%(bar('='),' Widths ',bar('='))
        if result['recompute_width'] == 'never':
            res_str += '| Widths extracted from the param_card.dat'
        else:
            res_str += '| Widths computed %s'%('analytically' if has_FRdecay 
                                                             else 'numerically')
            if result['recompute_width'] == 'first_time':
                res_str += r' for \lambda = 1'
            elif result['recompute_width'] == 'always':
                res_str += r' for all \lambda values'
        res_str += " using mode '--recompute_width=%s'.\n"%result['recompute_width']
        for particle_name, width in result['widths_computed']:
            res_str += '| %-10s = %-11.6gGeV\n'%('Width(%s)'%particle_name,width)
        res_str += '%s%s%s\n'%(bar('='),'='*8,bar('='))

    # Doing the analysis to printout to the MG5 interface and determine whether
    # the test is passed or not
    # Number of last points to consider for the stability test
    nstab_points=group_val
    # Store here the asymptot detected for each difference curve
    differences_target = {}
    for process, resID in checks:
        # Reinitialize the concise result replacement dictionary 
        # (only one resonance is indicated in this one, no matter what.)
        concise_repl_dict[process] = {'process':process,
                                      'asymptot':'N/A',
                                      'cms_check':'N/A',
                                      'status':'N/A'}
        proc_res = result[process]
        cms_res = proc_res['CMS'][resID]
        nwa_res = proc_res['NWA'][resID]
        resonance = resonance_str(cms_res['resonance'], latex='none')
        cms_born=cms_res['born']
        nwa_born=nwa_res['born']
        # Starting top thick bar
        res_str += '\n%s%s%s\n'%(bar('='),'='*8,bar('='))
        # Centered process and resonance title
        proc_title = "%s (resonance %s)"%(process,resonance)
        centering = (bar(2)+8-len(proc_title))//2
        res_str += "%s%s\n"%(' '*centering,proc_title)
        # Starting bottom thin bar
        res_str += '%s%s%s\n'%(bar('-'),'-'*8,bar('-'))
        # Reminder if diff_lambda_power is not 1
        
        if diff_lambda_power!=1:
            res_str += "== WARNING diff_lambda_power is not 1 but    = %g\n"%diff_lambda_power
            res_str += '%s%s%s\n'%(bar('-'),'-'*8,bar('-'))

        born_power = guess_lambdaorder(nwa_born,lambdaCMS_list,
               expected=proc_res['born_order'], proc=process, res=resonance)
        stab_cms_born = check_stability(cms_born[-nstab_points:], 
                         lambdaCMS_list[-nstab_points:], born_power, 'CMS Born')
        if stab_cms_born:
            res_str += stab_cms_born
        stab_nwa_born = check_stability(nwa_born[-nstab_points:], 
                         lambdaCMS_list[-nstab_points:], born_power, 'NWA Born')
        if stab_nwa_born:
            res_str += stab_nwa_born
        # Write out the phase-space point
        res_str += "== Kinematic configuration in GeV (E,px,pypz)\n"
        for i, p in enumerate(cms_res['resonance']['PS_point_used']):
            res_str += "  | p%-2.d = "%(i+1)
            for pi in p:
                res_str += '%-24.17g'%pi if pi<0.0 else ' %-23.17g'%pi 
            res_str += "\n"
        # Write out the offshellnesses specification
        res_str += "== Offshellnesses of all detected resonances\n"
        for res_name, offshellness in cms_res['resonance']['offshellnesses']:
            res_str += "  | %-15s = %f\n"%(res_name, offshellness)
        res_str += '%s%s%s\n'%(bar('-'),'-'*8,bar('-'))

        if not pert_orders:
            res_str += "== Born scaling lambda^n_born. nborn         = %d\n"%born_power
        else:
            cms_finite=cms_res['finite']
            nwa_finite=nwa_res['finite']
            loop_power = guess_lambdaorder(nwa_finite,lambdaCMS_list,
                   expected=proc_res['loop_order'], proc=process, res=resonance)  
            res_str += "== Scaling lambda^n. nborn, nloop            = %d, %d\n"\
                                                        %(born_power,loop_power)
            stab_cms_finite = check_stability(cms_finite[-nstab_points:], 
                                  lambdaCMS_list[-nstab_points:], loop_power, 'CMS finite')
            if stab_cms_finite:
                res_str += stab_cms_finite
            stab_nwa_finite = check_stability(nwa_finite[-nstab_points:], 
                      lambdaCMS_list[-nstab_points:], loop_power, 'NWA finite')
            if stab_nwa_finite:
                res_str += stab_nwa_finite
        # Now organize data
        CMSData     = []
        NWAData     = []
        DiffData    = []
        for idata, lam in enumerate(lambdaCMS_list):
            if not pert_orders:
                new_cms=cms_born[idata]/(lam**born_power)
                new_nwa=nwa_born[idata]/(lam**born_power)
            else:
                new_cms=(cms_finite[idata]+cms_born[idata]-nwa_born[idata])/(lam*nwa_born[idata])
                new_nwa=nwa_finite[idata]/(lam*nwa_born[idata])
            new_diff=(new_cms-new_nwa)/(lam**diff_lambda_power)
            CMSData.append(new_cms)
            NWAData.append(new_nwa)
            DiffData.append(new_diff)

                    
        # NWA Born median

        # Find which values to start the test at by looking at the CMSdata scaling
        # First compute the median of the middle 60% of entries in the plot
        trim_range=int(((1.0-0.6)/2.0)*len(DiffData))
        low_diff_median = sorted(DiffData[trim_range:-trim_range])\
                                               [(len(DiffData)-2*trim_range)//2]
        
        # Now walk the values from the right of the diff plot until we reaches
        # values stable with respect to the CMS_tale_median. This value will
        # be limit of the range considered for the CMS test. Do it in a way which
        # is insensitive to instabilities, by considering medians of group_val 
        # consecutive points.
        current_median = 0
        # We really want to select only the very stable region
        scan_index = 0
        reference = abs(sorted(NWAData)[len(NWAData)//2])
        if low_diff_median!= 0.0:
            if abs(reference/low_diff_median)<diff_zero_threshold:
                reference = abs(low_diff_median)
        while True:
            scanner = DiffData[scan_index:group_val+scan_index]
            current_median = sorted(scanner)[len(scanner)//2]
            # Useful for debugging
            #misc.sprint(scanner,current_median,abs(current_median-low_diff_median)/reference,reference,consideration_threshold)
            if abs(current_median-low_diff_median)/reference<\
                                                        consideration_threshold:
                break;
            scan_index += 1
            if (group_val+scan_index)>=len(DiffData):
                # this should not happen, but in this case we arbitrarily take
                # half of the data
                logger.warning('The median scanning failed during the CMS check '+
                  'for process %s'%proc_title+\
                  'This is means that the difference plot has not stable'+\
                  'intermediate region and MadGraph7 will arbitrarily consider the'+\
                                                     'left half of the values.')
                scan_index = -1
                break;
        
        if scan_index == -1:
            cms_check_data_range = len(DiffData)//2
        else:
            cms_check_data_range = scan_index + group_val

        res_str += "== Data range considered (min, max, n_val)   = (%.1e, %.1e, %d)\n"\
                  %(lambdaCMS_list[-1],lambdaCMS_list[scan_index],
                                                 len(lambdaCMS_list)-scan_index)
        # Now setup the list of values affecting the CMScheck
        CMScheck_values = DiffData[cms_check_data_range:]

        # For the purpose of checking the stability of the tale, we now do
        # the consideration_threshold scan from the *left* and if we finish
        # before the end, it means that there is an unstable region.
        if scan_index >= 0:            
            # try to find the numerical instability region
            scan_index = len(CMScheck_values)
            used_group_val = max(3,group_val)
            unstability_found = True
            while True:
                scanner = CMScheck_values[scan_index-used_group_val:scan_index]
                maxdiff =  max(abs(scan-low_diff_median) for scan in scanner)
                if maxdiff/reference<consideration_threshold:
                    break;
                if (scan_index-used_group_val)==0:
                    # this only happens when no stable intermediate region can be found
                    # Set scan_index to -99 so as to prevent warning
                    unstability_found = False
                    break;
                # Proceed to th next block of data
                scan_index -= 1

            # Now report here the instability found
            if unstability_found:
                unstab_check=CMScheck_values[scan_index:]
                relative_array = [val > CMScheck_values[scan_index-1] for 
                                                            val in unstab_check]
                upper = relative_array.count(True)
                lower = relative_array.count(False)
                if not ((lower==0 and upper>=0) or (lower>=0 and upper==0)):
                    logger.warning(
"""For process %s, a numerically unstable region was detected starting from lambda < %.1e.
Look at the plot in this region (and possibly throw more points using the option --lambdaCMS).
If this is indeed a stability issue, then either decrease MLStabThreshold in MadLoop or decrease the
minimum value of lambda to be considered in the CMS check."""\
                %(proc_title, lambdaCMS_list[cms_check_data_range+scan_index-1]))
        
        # Now apply the same same technique, as above but to the difference plot
        # Now we will use low_diff_median instead of diff_tale_median
        #diff_tale_median = sorted(CMScheck_values)[len(CMScheck_values)//2]
        scan_index = 0
        max_diff = 0.0
        res_str += "== Ref. value used in the ratios (Born NWA)  = %s\n"\
                                                             %('%.3g'%reference)
        res_str += "== Asymptotic difference value detected      = %s\n"\
                                                       %('%.3g'%low_diff_median)
        concise_repl_dict[process]['asymptot'] = '%.3e'%low_diff_median

        # Pass information to the plotter for the difference target
        differences_target[(process,resID)]= low_diff_median
#        misc.sprint('Now doing resonance %s.'%res_str)
        while True:
            current_vals = CMScheck_values[scan_index:scan_index+group_val]      
            max_diff = max(max_diff, abs(low_diff_median-
                     sorted(current_vals)[len(current_vals)//2])/reference)
            if (scan_index+group_val)>=len(CMScheck_values):
                break
            scan_index += 1
        
        # Now use the CMS check result
        cms_check = (max_diff*100.0, '>' if max_diff>CMS_test_threshold else '<',
                                                       CMS_test_threshold*100.0) 
        res_str += "== CMS check result (threshold)              = %.3g%% (%s%.3g%%)\n"%cms_check
        concise_repl_dict[process]['cms_check'] = \
            "%-10s (%s%.3g%%)"%('%.3g%%'%cms_check[0],cms_check[1],cms_check[2])

        if max_diff>CMS_test_threshold:
            failed_procs.append((process,resonance))
        res_str += "%s %s %s\n"%(bar('='),
                 'FAILED' if max_diff>CMS_test_threshold else 'PASSED',bar('='))
        concise_repl_dict[process]['status'] = 'Failed' if max_diff>CMS_test_threshold \
                                                                   else 'Passed'

    if output=='concise_text':
        # Find what is the maximum size taken by the process string
        max_proc_size = max(
                 [len(process) for process in result['ordered_processes']]+[10])
        # Re-initialize the res_str so as to contain only the minimal report
        res_str = concise_str
        res_str += '\n'+concise_data%(max_proc_size+4)%concise_repl_dict['Header']
        for process in result['ordered_processes']:
            res_str += (concise_data%(max_proc_size+4)%concise_repl_dict[process])

    if len(checks):
        res_str += "Summary: %i/%i passed"%(len(checks)-len(failed_procs),len(checks))+\
                    ('.\n' if not failed_procs else ', failed checks are for:\n')
    else:
        return "\nNo CMS check to perform, the process either has no diagram or does not "+\
                                  "not feature any massive s-channel resonance."
        
    for process, resonance in failed_procs:
        res_str += ">  %s, %s\n"%(process, resonance)

    if output=='concise_text':
        res_str += '\nMore detailed information on this check available with the command:\n'
        res_str += '  MadGraph7>display checks\n'

    ############################
    # Now we turn to the plots #
    ############################
    if not options['show_plot']:
        if options['reuse']:
            logFile.write(res_str)
            logFile.close()
        if output.endswith('text'):
            return res_str
        else:
            return failed_procs
        
    fig_output_file = CMS_save_path('pdf', result, model, options, 
                                                        output_path=output_path)
    base_fig_name = fig_output_file[:-4]
    suffix = 1
    while os.path.isfile(fig_output_file):
        fig_output_file = '%s__%d__.pdf'%(base_fig_name,suffix)
        suffix+=1

    process_data_plot_dict={}
    
    # load possible additional results. The second element of the tuple is
    # the dataset name.
    all_res = [(result, None)]
    for i, add_res in enumerate(options['analyze'].split(',')[1:]):
        specs =re.match(r'^(?P<filename>.*)\((?P<title>.*)\)$', add_res)
        if specs:
            filename = specs.group('filename')
            title    = specs.group('title')
        else:
            filename = add_res
            title    = '#%d'%(i+1)

        new_result = save_load_object.load_from_file(filename)
        if new_result is None:
            raise InvalidCmd('The complex mass scheme check result'+
                             " file below could not be read.\n     %s"%filename)
        if len(new_result['ordered_processes'])!=len(result['ordered_processes']) \
                      or len(new_result['lambdaCMS'])!=len(result['lambdaCMS']):
            raise self.InvalidCmd('The complex mass scheme check result'+
                      " file below does not seem compatible.\n     %s"%filename)
        all_res.append((new_result,title))
    
    # Prepare the data
    for process, resID in checks:
        data1=[] # for subplot 1,i.e. CMS and NWA
        data2=[] # for subplot 2,i.e. diff
        info ={} # info to be passed to the plotter
        for res in all_res:
            proc_res = res[0][process]
            cms_res = proc_res['CMS'][resID]
            nwa_res = proc_res['NWA'][resID]
            resonance = resonance_str(cms_res['resonance'])
            if options['resonances']!=1:
                info['title'] = format_title(process, resonance)
            else:
                info['title'] = format_title(process, '')
            # Born result
            cms_born=cms_res['born']
            nwa_born=nwa_res['born']
            if len(cms_born) != len(lambdaCMS_list) or\
                 len(nwa_born) != len(lambdaCMS_list):
                raise MadGraph5Error('Inconsistent list of results w.r.t. the'+\
                                ' lambdaCMS values specified for process %s'%process)
            if pert_orders:
                cms_finite=cms_res['finite'] 
                nwa_finite=nwa_res['finite']
                if len(cms_finite) != len(lambdaCMS_list) or\
                    len(nwa_finite) != len(lambdaCMS_list):
                    raise MadGraph5Error('Inconsistent list of results w.r.t. the'+\
                                ' lambdaCMS values specified for process %s'%process)
        
            bpower = guess_lambdaorder(nwa_born,lambdaCMS_list,
                    expected=proc_res['born_order'], proc=process, res=resonance)

            CMSData  = []
            NWAData  = []
            DiffData = []   
            for idata, lam in enumerate(lambdaCMS_list):
                if not pert_orders:
                    new_cms = cms_born[idata]/lam**bpower
                    new_nwa = nwa_born[idata]/lam**bpower
                else:
                    new_cms=cms_finite[idata]+cms_born[idata]-nwa_born[idata]
                    new_nwa=nwa_finite[idata]
                    new_cms /= lam*nwa_born[idata]
                    new_nwa /= lam*nwa_born[idata]
                new_diff=(new_cms-new_nwa)/(lam**diff_lambda_power)
                CMSData.append(new_cms)
                NWAData.append(new_nwa)
                DiffData.append(new_diff)
            if res[1] is None:
                if not pert_orders:
                    data1.append([r'$\displaystyle CMS\;=\;\mathcal{M}_{CMS}^{(0)}/\lambda^%d$'%bpower,CMSData])
                    data1.append([r'$\displaystyle NWA\;=\;\mathcal{M}_{NWA}^{(0)}/\lambda^%d$'%bpower,NWAData])
                else:
                    data1.append([r'$\displaystyle CMS\;=\;(\mathcal{M}^{(1)}_{CMS}+\mathcal{M}_{CMS}^{(0)}-\mathcal{M}^{(0)}_{NWA})/(\lambda\cdot\mathcal{M}^{(0)}_{NWA})$',CMSData])
                    data1.append([r'$\displaystyle NWA\;=\;\mathcal{M}^{(1)}_{NWA}/(\lambda\cdot\mathcal{M}^{(0)}_{NWA})$',NWAData])
                data2.append([r'$\displaystyle\Delta\;=\;(CMS-NWA)/\lambda%s$'\
                    %('' if diff_lambda_power==1 else r'^{%g}'%diff_lambda_power)
                                                                     ,DiffData])
                data2.append([r'Detected asymptot',[differences_target[(process,resID)] 
                                                for i in range(len(lambdaCMS_list))]])
            else:
                data1.append([r'$\displaystyle CMS$  %s'%res[1].replace('_',' ').replace('#',r'\#'), CMSData])
                data1.append([r'$\displaystyle NWA$  %s'%res[1].replace('_',' ').replace('#',r'\#'), NWAData])
                data2.append([r'$\displaystyle\Delta$  %s'%res[1].replace('_',' ').replace('#',r'\#'), DiffData])
                
        process_data_plot_dict[(process,resID)]=(data1,data2, info)

    # Now turn to the actual plotting
    try:
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_pdf import PdfPages
        logger.info('Rendering plots... (this can take some time because of the latex labels)')

        res_str += \
"""\n-----------------------------------------------------------------------------------------------
| In the plots, the Complex Mass Scheme check is successful if the normalized difference      |
| between the CMS and NWA result (lower inset) tends to a constant when \\lambda goes to zero. |
-----------------------------------------------------------------------------------------------\n"""

        # output the figures
        if lambda_range[1]>0:
            min_lambda_index = -1
            for i, lam in enumerate(lambdaCMS_list):
                if lam<=lambda_range[1]:
                    min_lambda_index = i
                    break
        else:
            min_lambda_index = 0
        if lambda_range[0]>0:
            max_lambda_index = -1
            for i, lam in enumerate(lambdaCMS_list):
                if lam<=lambda_range[0]:
                    max_lambda_index=i-1
                    break
        else:
            max_lambda_index=len(lambdaCMS_list)-1
    
        if max_lambda_index==-1 or min_lambda_index==-1 or \
                                             min_lambda_index==max_lambda_index:
            raise InvalidCmd('Invalid lambda plotting range: (%.1e,%.1e)'%\
                                              (lambda_range[0],lambda_range[1]))
        # Trim lambda values
        if lambda_range[0]>0.0 or lambda_range[1]>0.0:
            lambdaCMS_list = lambdaCMS_list[min_lambda_index:max_lambda_index+1]

        plt.rc('text', usetex=True)
        plt.rc('font', family='serif')
        pp=PdfPages(fig_output_file)
        if len(checks)==0 or len(process_data_plot_dict[checks[0]][1])<=7:
            colorlist=['b','r','g','k','c','m','y']
        else:
            import matplotlib.colors as colors
            import matplotlib.cm as mplcm
            import matplotlib.colors as colors
            
            # Nice color maps here are 'gist_rainbow'
            cm = plt.get_cmap('gist_rainbow')
            cNorm  = colors.Normalize(vmin=0, vmax=(len(data2)-1))
            scalarMap = mplcm.ScalarMappable(norm=cNorm, cmap=cm)
            # use vmax=(len(data1)-1)*0.9 to remove pink at the end of the spectrum
            colorlist = [scalarMap.to_rgba(i*0.9) for i in range(len(data2))]
            # Or it is also possible to alternate colors so as to make them 
            # as distant as possible to one another
            # colorlist = sum([
            #    [scalarMap.to_rgba(i),scalarMap.to_rgba(i+len(data2)//2)]
            #                                  for i in range(len(data2)//2)],[])

        legend_size = 10
        for iproc, (process, resID) in enumerate(checks):
            data1,data2, info=process_data_plot_dict[(process,resID)]
            # Trim dataplot if necessary
            if lambda_range[0]>0.0 or lambda_range[1]>0.0:
                for i in range(len(data1)):
                    data1[i][1]=data1[i][1][min_lambda_index:max_lambda_index+1]
                for i in range(len(data2)):
                    data2[i][1]=data2[i][1][min_lambda_index:max_lambda_index+1]
            plt.figure(iproc+1)
            plt.subplot(211)
            minvalue=1e+99
            maxvalue=-1e+99
            for i, d1 in enumerate(data1):
                # Use the same color for NWA and CMS curve but different linestyle
                color=colorlist[i//2]
                data_plot=d1[1]
                minvalue=min(min(data_plot),minvalue)
                maxvalue=max(max(data_plot),maxvalue)           
                plt.plot(lambdaCMS_list, data_plot, color=color, marker='', \
                        linestyle=('-' if i%2==0 else '--'), 
                        label=(d1[0] if (i%2==0 or i==1) else '_nolegend_'))
            ymin = minvalue-(maxvalue-minvalue)/5.
            ymax = maxvalue+(maxvalue-minvalue)/5.

            plt.yscale('linear')
            plt.xscale('log')
            plt.title(info['title'],fontsize=12,y=1.08)
            plt.ylabel(r'$\displaystyle \mathcal{M}$')
            #plt.xlabel('lambdaCMS')
            if ymax*len(data1)-sum(max(d1[1][-len(d1[1])//2:]) \
                                 for d1 in data1) > 0.5*(ymax-ymin)*len(data1):
                plt.legend(prop={'size':legend_size},loc='upper left', frameon=False)
            else:
                plt.legend(prop={'size':legend_size},loc='lower left', frameon=False)
                
            plt.axis([min(lambdaCMS_list),max(lambdaCMS_list), ymin, ymax])
            
            plt.subplot(212)
            minvalue=1e+99
            maxvalue=-1e+99
            
            try:
                asymptot_index = [d2[0] for d2 in data2].index('Detected asymptot')
                plt.plot(lambdaCMS_list, data2[asymptot_index][1], 
                               color='0.75', marker='', linestyle='-', label='')
            except ValueError:
                pass
            
            color_ID = -1
            for d2 in data2:
                # Special setup for the reference asymptot straight line
                if d2[0]=='Detected asymptot':
                    continue
                color_ID += 1
                color=colorlist[color_ID]
                data_plot=d2[1]
                minvalue=min(min(data_plot),minvalue)
                maxvalue=max(max(data_plot),maxvalue)
                plt.plot(lambdaCMS_list, data_plot, color=color, marker='',\
                                                     linestyle='-', label=d2[0])
            ymin = minvalue-(maxvalue-minvalue)/5.
            ymax = maxvalue+(maxvalue-minvalue)/5.

            plt.yscale('linear')
            plt.xscale('log')
            plt.ylabel(r'$\displaystyle \Delta$')
            plt.xlabel(r'$\displaystyle \lambda$')
            # The unreadable stuff below is just to check if the left of the 
            # plot is stable or not
            sd = [sorted(d2[1][-len(d2[1])//2:]) for d2 in data2]
            left_stability = sum(abs(s[0]-s[-1]) for s in sd)
            sd = [sorted(d2[1][:-len(d2[1])//2]) for d2 in data2]
            right_stability = sum(abs(s[0]-s[-1]) for s in sd)
            left_stable =  False if right_stability==0.0 else \
                                            (left_stability/right_stability)<0.1
 
            if left_stable:
                if ymax*len(data2)-sum(max(d2[1][-len(d2[1])//2:]) \
                                 for d2 in data2) > 0.5*(ymax-ymin)*len(data2):
                    plt.legend(prop={'size':legend_size},loc='upper left', frameon=False)
                else:
                    plt.legend(prop={'size':legend_size},loc='lower left', frameon=False)                
            else:
                if ymax*len(data2)-sum(max(d2[1][:-len(d2[1])//2]) \
                                  for d2 in data2) > 0.5*(ymax-ymin)*len(data2):
                    plt.legend(prop={'size':legend_size},loc='upper right', frameon=False)
                else:
                    plt.legend(prop={'size':legend_size},loc='lower right', frameon=False)

            plt.axis([min(lambdaCMS_list),max(lambdaCMS_list),\
              minvalue-(maxvalue-minvalue)/5., maxvalue+(maxvalue-minvalue)/5.])
            
            plt.savefig(pp,format='pdf')

        pp.close()
        
        if len(checks)>0:
            logger.info('Complex Mass Scheme check plot output to file %s. '%fig_output_file)
            
            if sys.platform.startswith('linux'):
                misc.call(["xdg-open", fig_output_file])
            elif sys.platform.startswith('darwin'):
                misc.call(["open", fig_output_file])
        
        plt.close("all")
    
    except Exception as e:
        if isinstance(e, ImportError):
            res_str += "\n= Install matplotlib to get a "+\
                "graphical display of the results of the cms check."
        else:
            general_error = "\n= Could not produce the cms check plot because of "+\
                                                    "the following error: %s"%str(e)
            try:
                import tkinter
                if isinstance(e, tkinter.TclError):
                    res_str += "\n= Plots are not generated because your system"+\
                                          " does not support graphical display."
                else:
                    res_str += general_error
            except:
                res_str += general_error
    
    if options['reuse']:
        logFile.write(res_str)
        logFile.close()

    if output.endswith('text'):
        return res_str
    else:
        return failed_procs
