################################################################################
#
# Copyright (c) 2009 The MadGraph7 Development team and Contributors
#
# This file is a part of the MadGraph7 project, an application which 
# automatically generates Feynman diagrams and matrix elements for arbitrary
# high-energy processes in the Standard Model and beyond.
#
# It is subject to the MadGraph7 license which should accompany this 
# distribution.
#
# For more information, visit madgraph.phys.ucl.ac.be and amcatnlo.web.cern.ch
#
################################################################################


from __future__ import absolute_import
import logging
import math
import os
import pydoc
import re
import subprocess
import time
start=time.time()
import madgraph.iolibs.files as files
import madgraph.interface.madevent_interface as me_cmd
import madgraph.interface.common_run_interface as common_run
import madgraph.various.misc as misc
import madgraph.various.process_checks as process_checks
import madgraph.various.banner as banner_mod
import madgraph.interface.extended_cmd as extended_cmd
import sys

#from madgraph import MG4DIR, MG5DIR, MadGraph5Error
#from madgraph.iolibs.files import cp
pjoin = os.path.join


logger = logging.getLogger('cmdprint.ext_program')



class ExtLauncher(object):
    """ Generic Class for executing external program """
    
    program_dir = ''
    executable = ''  # path from program_dir
    
    force = False
    
    def __init__(self, cmd, running_dir, card_dir='', **options):
        """ initialize an object """
        
        self.running_dir = running_dir
        self.card_dir = os.path.join(self.running_dir, card_dir)
        self.cmd_int = cmd
        if 'force' in options:
            self.force = options['force']
        
        #include/overwrite options
        for key,value in options.items():
            setattr(self, key, value)
            
        self.cards = [] # files can be modified (path from self.card_dir)
            
    def run(self):
        """ execute the main code """

        self.prepare_run()   
        
        import madgraph.interface.common_run_interface as common_run_interface
        
        self.cmd_int.me_dir = self.running_dir
        if self.cards:
            common_run_interface.CommonRunCmd.ask_edit_card_static(self.cards,
                             mode='fixed',
                             timeout=0, ask=self.cmd_int.ask, force=self.force)
             
        #for card in self.cards:
        #    self.treat_input_file(card, default = 'n')

        self.launch_program()

        
    def prepare_run(self):
        """ additional way to prepare the run"""
        pass
    
    def launch_program(self):
        """launch the main program"""
        subprocess.call([self.executable], cwd=self.running_dir)
    
    def edit_file(self, path):
        """edit a file"""

        path = os.path.realpath(path)
        open_file(path)
    

    # Treat Nicely the timeout
    def timeout_fct(self,timeout):
        if timeout:
            # avoid to always wait a given time for the next answer
            self.force = True
   
    def ask(self, question, default, choices=[], path_msg=None):
        """nice handling of question"""
     
        if not self.force:
            return self.cmd_int.ask(question, default, choices=choices, 
                                path_msg=path_msg, fct_timeout=self.timeout_fct)
        else:
            return str(default)
         
        
    def treat_input_file(self, filename, default=None, msg=''):
        """ask to edit a file"""
        
        if msg == '' and filename == 'param_card.dat':
            msg = \
            "WARNING: If you edit this file don\'t forget to consistently "+\
            "modify the different parameters,\n especially the width of all "+\
            "particles."
                                         
        if not self.force:
            if msg:  print(msg)
            question = 'Do you want to edit file: %(card)s?' % {'card':filename}
            choices = ['y', 'n']
            path_info = 'path of the new %(card)s' % {'card':os.path.basename(filename)}
            ans = self.ask(question, default, choices, path_info)
        else:
            ans = default
        
        if ans == 'y':
            path = os.path.join(self.card_dir, filename)
            self.edit_file(path)
        elif ans == 'n':
            return
        else:
            path = os.path.join(self.card_dir, filename)
            files.cp(ans, path)
            
class MadLoopLauncher(ExtLauncher):
    """ A class to launch a simple Standalone test """
    
    def __init__(self, cmd_int, running_dir, **options):
        """ initialize the StandAlone Version """
        
        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **options)
        self.cards = ['param_card.dat','MadLoopParams.dat']

    def prepare_run(self):
        """ Possible preparatory actions to take."""
        pass

    def treat_input_file(self, filename, default=None, msg='', dir_path=None):
        """ask to edit a file"""

        if filename == 'PS.input':
            if not self.force:
                if msg!='':  print(msg)
                question = 'Do you want to specify the Phase-Space point: %(card)s?' % {'card':filename}
                choices = ['y', 'n']
                path_info = 'path of the PS.input file'
                ans = self.ask(question, default, choices, path_info)
            else:
                ans = default
            if ans == 'y':
                if not os.path.isfile(os.path.join(dir_path,'PS.input')):
                    PSfile = open(os.path.join(dir_path,'PS.input'), 'w')
                    if not os.path.isfile(os.path.join(dir_path,'result.dat')):
                        PSfile.write('\n'.join([' '.join(['%.16E'%0.0 for \
                                        pi in range(4)]) for pmom in range(1)]))
                    else:
                        default_ps = process_checks.LoopMatrixElementEvaluator.\
                            parse_check_output(open(os.path.join(dir_path,\
                                          'result.dat')),format='dict')['res_p']
                        PSfile.write('\n'.join([' '.join(['%.16E'%pi for pi \
                                             in pmom]) for pmom in default_ps]))                     
                    PSfile.write("\n\nEach line number 'i' like the above one sets"+\
                            " the momentum of particle number i, \nordered like in"+\
                            " the process definition. The format is (E,px,py,pz).")
                    PSfile.close()       
                self.edit_file(os.path.join(dir_path,'PS.input'))
        else:
            super(MadLoopLauncher,self).treat_input_file(filename,default,msg)

    def uses_density(self):
        """True if the output was written with 'output ... --density=...'.
        The command options are not available here, so they are read back
        from the proc_card (the only place they are recorded), through
        ProcCard which joins the lines older versions wrapped."""

        proc_card = banner_mod.ProcCard(pjoin(self.card_dir, 'proc_card_mg5.dat'))
        return 'density' in proc_card.get_output_options()

    def launch_program(self):
        """launch the main program"""
        evaluator = process_checks.LoopMatrixElementTimer
        sub_path = os.path.join(self.running_dir, 'SubProcesses')
        for path in os.listdir(sub_path):
            if path.startswith('P') and \
                                    os.path.isdir(os.path.join(sub_path, path)):
                shell_name = path.split('_')[1]+' > '+path.split('_')[2]
                curr_path = os.path.join(sub_path, path)
                infos = {}
                logger.info("Initializing process %s."%shell_name)
                nps = me_cmd.MadLoopInitializer.run_initialization(
                                curr_path, sub_path, infos,
                                req_files = ['HelFilter.dat','LoopFilter.dat'])
                if nps == None:
                    raise MadGraph5Error("MadLoop could not initialize the process %s"\
                      %shell_name)
                logger.debug(("MadLoop initialization performed for %s"+\
                        " using %d PS points (%s)")\
                        %(shell_name,abs(nps),\
                    'double precision' if nps>0 else 'quadruple precision'))
                # Ask if the user wants to edit the PS point.
                self.treat_input_file('PS.input', default='n', 
                  msg='Phase-space point for process %s.'%shell_name,\
                                                             dir_path=curr_path)
                # We use mu_r=-1.0 to use the one defined by the user in the
                # param_card.dat
                # Note: we must target the subprocess directory currently being
                # run (curr_path) and not the SubProcesses directory (sub_path).
                # Otherwise fix_PSPoint_in_check edits the first P* directory it
                # finds instead of this one, leaving curr_path's check_sa.f with
                # the NPSPOINTS value left over from the initialization. The
                # phase-space point written would then be the (NPSPOINTS)-th
                # RAMBO point instead of the first, making the kinematics depend
                # on the initialization (and hence on the other subprocesses
                # generated) rather than only on this process.
                me_cmd.MadLoopInitializer.fix_PSPoint_in_check(curr_path,
                  read_ps = os.path.isfile(os.path.join(curr_path, 'PS.input')),
                  npoints = 1, mu_r=-1.0)
                
                # Make sure to temporarily disable the double-check of the helicity filter
                # as this would disable the stability check.
                MadLoopparam = banner_mod.MadLoopParam(
                                          os.path.join(self.card_dir, 'MadLoopParams.dat'))   
                bu_helicity_filter_value = MadLoopparam['DoubleCheckHelicityFilter']
                MadLoopparam.set('DoubleCheckHelicityFilter', False)
                MadLoopparam.write(os.path.join(self.card_dir, 'MadLoopParams.dat'))

                #for the density mode, we use HelicityFilterLevel = 0 because the use of symmetry of HelicityFilterLevel = 2 does not work for JAMP interferences
                if self.uses_density():
                    MadLoopparam.set('HelicityFilterLevel', 0)
                    MadLoopparam.write(os.path.join(self.card_dir, 'MadLoopParams.dat'))
                    logger.warning("WARNING: With the density mode, HelicityFilterLevel must be set to 0. It is currently set to 0.")

                # check
                t1, t2, ram_usage = me_cmd.MadLoopInitializer.make_and_run(curr_path)
                
                # Restore the original value of 'DoubleCheckHelicityFilter'
                MadLoopparam.set('DoubleCheckHelicityFilter', bu_helicity_filter_value)
                MadLoopparam.write(os.path.join(self.card_dir, 'MadLoopParams.dat'))

                if t1==None or t2==None:
                    raise MadGraph5Error("Error while running process %s."\
                                                                     %shell_name)
                try:
                    rFile=open(os.path.join(curr_path,'result.dat'), 'r')
                except IOError:
                    raise MadGraph5Error("Could not find result file %s."%\
                                       str(os.path.join(curr_path,'result.dat')))
                # The result are returned as a dictionary.
                result = evaluator.parse_check_output(rFile,format='dict')
                for line in self.format_res_string(result, shell_name):
                    if isinstance(line, str):
                        logger.info(line)
                    elif isinstance(line,tuple):
                        logger.info(line[0],line[1])

    def format_res_string(self, res, shell_name):
        """ Returns a good-looking string presenting the results.
        The argument the tuple ((fin,born,spole,dpole,me_pow), p_out)."""
        
        main_color='$MG:color:BLUE'
        
        def special_float_format(float):
            return '%s%.16e'%('' if float<0.0 else ' ',float)
        
        so_order_names = res['Split_Orders_Names']
        
        def format_so_orders(so_orders):
            return ' '.join(['%s=%d'%(so_order_names[i],so_orders[i]) for i in
                                                         range(len(so_orders))])

        ASCII_bar = ('|'+''.join(['='*96]),main_color)
        
        ret_code_h = res['return_code']//100
        ret_code_t = (res['return_code']-100*ret_code_h)//10
        ret_code_u = res['return_code']%10
        StabilityOutput=[]
        if ret_code_h==1:
            if ret_code_t==3 or ret_code_t==4:
                StabilityOutput.append('| Unknown numerical stability because '+\
                                      'MadLoop is in the initialization stage.')
            else:
                StabilityOutput.append('| Unknown numerical stability, check '+\
                                        'CTRunMode value in MadLoopParams.dat.')
        elif ret_code_h==2:
            StabilityOutput.append('| Stable kinematic configuration (SPS).')
        elif ret_code_h==3:
            StabilityOutput.append('| Unstable kinematic configuration (UPS).')
            StabilityOutput.append('| Quadruple precision rescue successful.')            
        elif ret_code_h==4:
            StabilityOutput.append('| Exceptional kinematic configuration (EPS).')
            StabilityOutput.append('| Both double and quadruple precision'+\
                                                  ' computations are unstable.')
        
        if ret_code_t==2 or ret_code_t==4:
            StabilityOutput.append('| Quadruple precision was used for this'+\
                                                                 'computation.')
        if ret_code_h!=1:
            if res['accuracy']>0.0:
                StabilityOutput.append('| Estimated relative accuracy = %.1e'\
                                                               %res['accuracy'])
            elif res['accuracy']==0.0:
                StabilityOutput.append('| Estimated relative accuracy = %.1e'\
                             %res['accuracy']+' (i.e. beyond double precision)')
            else:
                StabilityOutput.append('| Estimated accuracy could not be '+\
                                              'computed for an unknown reason.')

        PS_point_spec = ['|| Phase-Space point specification (E,px,py,pz)','|']
        PS_point_spec.append('\n'.join(['| '+' '.join(['%s'%\
           special_float_format(pi) for pi in pmom]) for pmom in res['res_p']]))
        PS_point_spec.append('|')
        
        str_lines=[]
        
        notZeroBorn=True
        if res['export_format']!='LoopInduced' and len(so_order_names) and \
                                     len([1 for k in res['Born_kept'] if k])==0:
            notZeroBorn = False
            str_lines.append(
("|  /!\\ There is no Born contribution for the squared orders specified in "+
                                  "the process definition/!\\",'$MG:color:RED'))
        
        if res['export_format']=='Default' and notZeroBorn:
            str_lines.extend(['\n',ASCII_bar,
  ('|| Results for process %s'%shell_name,main_color),
  ASCII_bar]+PS_point_spec+StabilityOutput+[
  '|',
  ('|| Total(*) Born contribution (GeV^%d):'%res['gev_pow'],main_color),
  ('|    Born        = %s'%special_float_format(res['born']),main_color),
  ('|| Total(*) virtual contribution normalized with born*alpha_S/(2*pi):',main_color),
  ('|    Finite      = %s'%special_float_format(res['finite']),main_color),
  ('|    Single pole = %s'%special_float_format(res['1eps']),main_color),
  ('|    Double pole = %s'%special_float_format(res['2eps']),main_color)])
        elif res['export_format']=='LoopInduced' and notZeroBorn:
            str_lines.extend(['\n',ASCII_bar,
  ('|| Results for process %s (Loop-induced)'%shell_name,main_color),
  ASCII_bar]+PS_point_spec+StabilityOutput+[
  '|',
  ('|| Loop amplitude squared, must be finite:',main_color),
  ('|    Finite      = %s'%special_float_format(res['finite']),main_color),
  '|(| Pole residues, indicated only for checking purposes: )',
  '|(    Single pole = %s )'%special_float_format(res['1eps']),
  '|(    Double pole = %s )'%special_float_format(res['2eps'])])

        if (len(res['Born_SO_Results'])+len(res['Born_SO_Results']))>0:
            if notZeroBorn:
                str_lines.append(
    ("|  (*) The results above sum all starred contributions below",main_color))

        str_lines.append('|')
        if not notZeroBorn:
            str_lines.append(
("|  The Born contributions below are computed but do not match these squared "+
                                               "orders constraints",main_color))

        if len(res['Born_SO_Results'])==1:
            str_lines.append('|| All Born contributions are of split orders *(%s)'\
                                %format_so_orders(res['Born_SO_Results'][0][0]))
        elif len(res['Born_SO_Results'])>1:
            for i, bso_contrib in enumerate(res['Born_SO_Results']):
                str_lines.append('|| Born contribution of split orders %s(%s) = %s'\
                                           %('*' if res['Born_kept'][i] else ' ',
                                               format_so_orders(bso_contrib[0]),
                                  special_float_format(bso_contrib[1]['BORN'])))
        
        if len(so_order_names):
            str_lines.append('|')

        if len(res['Loop_SO_Results'])==1:
            str_lines.append('|| All virtual contributions are of split orders *(%s)'\
                                %format_so_orders(res['Loop_SO_Results'][0][0]))
        elif len(res['Loop_SO_Results'])>1:
            if not notZeroBorn:
                str_lines.append(
    ("|  The coupling order combinations matching the squared order"+
                              " constraints are marked with a star",main_color))
            for i, lso_contrib in enumerate(res['Loop_SO_Results']):
                str_lines.append('|| Virtual contribution of split orders %s(%s):'\
                                        %('*' if res['Loop_kept'][i] else ' ',
                                              format_so_orders(lso_contrib[0])))
                str_lines.append('|    Accuracy    =  %.1e'%\
                                                         lso_contrib[1]['ACC']),
                str_lines.append('|    Finite      = %s'%\
                                   special_float_format(lso_contrib[1]['FIN'])),
                if res['export_format']=='LoopInduced':
                    str_lines.append('|(    Single pole = %s )'%\
                                   special_float_format(lso_contrib[1]['1EPS']))
                    str_lines.append('|(    Double pole = %s )'%\
                                   special_float_format(lso_contrib[1]['2EPS']))
                else:
                    str_lines.append('|    Single pole = %s'%\
                                   special_float_format(lso_contrib[1]['1EPS']))
                    str_lines.append('|    Double pole = %s'%\
                                   special_float_format(lso_contrib[1]['2EPS']))    
        if res['RMatrix']:
            str_lines.append('|')
            str_lines.append(('|| Density matrix (non-normalised):',main_color))

            n = int((-1 + (1 + 8*len(res['RMatrix']))**.5)/2)
            if n%1 != 0:
                    raise ValueError("Problem in the dimension of the density matrix.")
            rho_square = [[0. for o in range(n)] for _ in range(n)]
            for i in range(n):
                    for k in range(n):
                            if k > i:
                                    rho_square[i][k] = res['RMatrix'][i*n + k - i*(i + 1)//2].conjugate()
                            elif k == i:
                                    rho_square[i][k] = res['RMatrix'][i*n + k - i*(i + 1)//2] #this line is just here because the diagonal elements should not be conjugated (they are real anyway)
                            else:
                                    rho_square[i][k] = rho_square[k][i].conjugate()
                    str_lines.append(('|  ' + str(rho_square[i]), main_color))          
        str_lines.extend([ASCII_bar,'\n'])

        return str_lines

class SALauncher(ExtLauncher):
    """ A class to launch a simple Standalone test """
    
    def __init__(self, cmd_int, running_dir, **options):
        """ initialize the StandAlone Version"""
        
        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **options)
        self.cards = ['param_card.dat']
        if os.path.isfile(running_dir+'/Cards/onia_card.dat'):
            self.cards += ['onia_card.dat']

    
    def launch_program(self):
        """launch the main program"""
        sub_path = os.path.join(self.running_dir, 'SubProcesses')
        for path in sorted(os.listdir(sub_path)):
            if path.startswith('P') and \
                                   os.path.isdir(os.path.join(sub_path, path)):
                cur_path =  os.path.join(sub_path, path)
                # make
                misc.compile(cwd=cur_path, mode='unknown')
                # check
                timings = getattr(self, 'timings', 0)
                if timings and int(timings) > 0:
                    nb_run = int(getattr(self, 'nb_run', 1))
                    if nb_run == 0:
                        # --nb_run=0: good-helicity check mode. Evaluate each
                        # flavor `timings` times (so the good-helicity filter is
                        # exercised) and print ./check's matrix-element values
                        # instead of a timing table.
                        self._run_goodhel_check(cur_path, int(timings))
                    else:
                        self._run_with_timings(cur_path, int(timings), nb_run)
                else:
                    subprocess.call(['./check'], cwd=cur_path)

    def _run_goodhel_check(self, cur_path, nb_try):
        """Evaluate every flavor nb_try times and print the resulting
        matrix-element values, with no timing summary.

        Here "every flavor" means every distinct external-flavor assignment the
        merged matrix element serves: when light quarks/leptons are grouped into
        merged particles, a single subprocess covers several physical flavor
        combinations (e.g. u u~ > u u~, d d~ > d d~, ...), enumerated by the
        flavor index. ./check is invoked with unique_flavor=0 so it loops over
        all of them, calling SMATRIX nb_try times each (so the good-helicity
        filter is exercised), and prints the final matrix-element evaluation
        (with its PDG label) for each. A non-merged process simply has one
        flavor.

        Parameters
        ----------
        cur_path : str
            Path to the subprocess directory containing the compiled ./check.
        nb_try : int
            Number of SMATRIX calls per flavor (the --timings value).
        """
        logger.info('Good-helicity check: %d SMATRIX call(s) per flavor '
                    '(printing matrix-element values, no timing table)' % nb_try)
        subprocess.call(['./check', '1000', str(nb_try), '0'], cwd=cur_path)

    def _run_with_timings(self, cur_path, nb_try, nb_run):
        """Run timing analysis for each flavor and print a summary table.

        Parameters
        ----------
        cur_path : str
            Path to the subprocess directory containing the compiled ./check binary.
        nb_try : int
            Number of SMATRIX calls per flavor per run (passed as arg2 to ./check).
        nb_run : int
            Number of independent timing repetitions used to build statistics.
        """
        # Discover the number of flavors and their PDG codes by running once
        # with nb_try=1 and unique_flavor=0 (all flavors).
        try:
            proc = subprocess.Popen(['./check', '1000', '1', '0'],
                                    cwd=cur_path,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
            stdout, _ = proc.communicate()
            if isinstance(stdout, bytes):
                stdout = stdout.decode('utf-8', errors='replace')
        except OSError:
            logger.error('Could not run ./check for flavor discovery')
            return

        # Parse "PDG ..." lines to collect flavor PDG tuples
        pdg_per_flavor = []
        for line in stdout.splitlines():
            stripped = line.strip()
            if stripped.upper().startswith('PDG'):
                pdg_per_flavor.append(stripped[3:].strip())
        nflavors = len(pdg_per_flavor)
        if nflavors == 0:
            logger.warning('No flavors detected in ./check output; skipping timing.')
            return

        logger.info('Timing %d flavor(s), %d SMATRIX calls/run, %d run(s)'
                    % (nflavors, nb_try, nb_run))

        # Time each flavor individually
        results = []
        for flav_idx in range(1, nflavors + 1):
            run_times = []
            for _ in range(nb_run):
                t0 = time.time()
                subprocess.call(['./check', '1000', str(nb_try), str(flav_idx)],
                                cwd=cur_path,
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
                run_times.append(time.time() - t0)
            avg = sum(run_times) / len(run_times)
            if len(run_times) > 1:
                sigma = math.sqrt(
                    sum((t - avg) ** 2 for t in run_times) / (len(run_times) - 1))
            else:
                sigma = 0.0
            pdg_label = pdg_per_flavor[flav_idx - 1] if flav_idx - 1 < len(pdg_per_flavor) else ''
            results.append((flav_idx, pdg_label, avg, sigma))

        # Print summary table
        n_diagrams = self._read_feynman_diagram_count(cur_path)
        sep = '=' * 80
        header_fmt = '%-6s  %-30s  %-18s  %-18s'
        row_fmt    = '%-6d  %-30s  %-18.6f  %-18.6f'
        print('\n' + sep)
        if n_diagrams is not None:
            print('Timing summary: %d Feynman diagram(s), %d SMATRIX calls/flavor/run, %d run(s)' %
                  (n_diagrams, nb_try, nb_run))
        else:
            print('Timing summary: %d SMATRIX calls/flavor/run, %d run(s)' % (nb_try, nb_run))
        print('-' * 80)
        print(header_fmt % ('Flavor', 'PDG codes', 'Avg time (s)', '1-sigma (s)'))
        print('-' * 80)
        for flav_idx, pdg_label, avg, sigma in results:
            print(row_fmt % (flav_idx, pdg_label, avg, sigma))
        print(sep + '\n')

    def _read_feynman_diagram_count(self, cur_path):
        """Return number of Feynman diagrams from ngraphs.inc, if available."""
        ngraphs_path = os.path.join(cur_path, 'ngraphs.inc')
        try:
            with open(ngraphs_path, 'r') as ngraphs_file:
                content = ngraphs_file.read()
        except (IOError, OSError):
            return None

        match = re.search(r'n_max_cg\s*=\s*(\d+)', content, re.IGNORECASE)
        if not match:
            return None

        try:
            return int(match.group(1))
        except (TypeError, ValueError):
            return None


class FKSSALauncher(ExtLauncher):
    """Launch the FKS Born building-block standalone check ('check_fks').

    Produced by 'output standalone_fortran --fks'. ExtLauncher.run() first offers to
    edit the param_card (bypassed with -f); launch_program() then compiles the
    Source libraries, builds 'check_fks' in every born subprocess directory and
    runs it, echoing the Born, spin-correlated Born and color/charge-linked
    Borns for one phase-space point. The --energy / --timings / --nb_run
    options are honoured.

    For an output made with '--limits', it then also builds and runs the
    aMC@NLO soft/collinear limit test (test_soft_col_limits) in every born
    directory and reports whether the real emission approaches its
    counterterms, which are built from these same Born building blocks.
    """

    # same input as the aMC@NLO launch uses for its 'test_ME' check: ME
    # (not MC) counterterms, random energy/angle, 100 soft and 100 collinear
    # points, all FKS configurations, first diagram
    limits_input = "2\n-2 -2\n100 100\n0\n" + "-1\n" * 50

    def __init__(self, cmd_int, running_dir, **options):
        """initialize the FKS standalone version"""
        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **options)
        self.with_limits = os.path.isfile(
            pjoin(running_dir, 'SubProcesses', 'check_sa_fks_limits'))
        self.cards = ['param_card.dat']
        if self.with_limits:
            # the limit test reads the beams/energy from the run_card
            self.cards.append('run_card.dat')

    def launch_program(self):
        """compile and run check_fks in each born subprocess directory."""
        me_dir = self.running_dir
        logger.info(
            'Compiling Source libraries for the FKS standalone check...')
        misc.compile(cwd=pjoin(me_dir, 'Source'))

        sub_path = pjoin(me_dir, 'SubProcesses')
        born_dirs = sorted(pjoin(sub_path, p) for p in os.listdir(sub_path)
                           if p.startswith('P') and os.path.isfile(
                               pjoin(sub_path, p, 'check_sa_fks.f')))
        if not born_dirs:
            logger.error(
                'No FKS standalone born directory found in %s' % sub_path)
            return

        energy = float(getattr(self, 'energy', 0) or 0)
        timings = int(getattr(self, 'timings', 0) or 0)
        nb_run = int(getattr(self, 'nb_run', 1) or 1)

        for born_path in born_dirs:
            pdir = os.path.basename(born_path)
            logger.info('Building check_fks in %s ...' % pdir)
            misc.compile(['check_fks'], cwd=born_path)
            logger.info('==== %s ====' % pdir)
            # print the building-block values once (honouring --energy)
            output = subprocess.Popen(
                ['./check_fks', self._energy_arg(energy)],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=born_path).communicate()[0]
            if isinstance(output, bytes):
                output = output.decode('utf-8', errors='replace')
            logger.info(output)
            if timings > 0:
                self._run_with_timings(born_path, energy, timings, nb_run)

        if self.with_limits:
            failed = [os.path.basename(p) for p in born_dirs
                      if not self._run_limits(p)]
            if failed:
                from madgraph import MadGraph5Error
                raise MadGraph5Error('Soft/collinear limit test FAILED in %s '
                    '(see test_ME.log there)' % ', '.join(failed))

    def _run_limits(self, born_path):
        """build and run test_soft_col_limits; True if no check FAILED."""
        pdir = os.path.basename(born_path)
        logger.info('Building test_soft_col_limits in %s ...' % pdir)
        misc.compile(['test_soft_col_limits'], cwd=born_path)
        log = pjoin(born_path, 'test_ME.log')
        with open(pjoin(born_path, 'test_ME_input.txt'), 'w') as fsock:
            fsock.write(self.limits_input)
        with open(pjoin(born_path, 'test_ME_input.txt')) as stdin, \
                open(log, 'w') as stdout:
            misc.call(['./test_soft_col_limits'], cwd=born_path, stdin=stdin,
                      stdout=stdout, stderr=subprocess.STDOUT)
        content = open(log, errors='replace').read()
        if 'incoming j_fks, but fixed shat' in content:
            # an initial-state FKS parton needs a varying momentum fraction,
            # i.e. PDF beams; for incoming leptons ([QED]) that means lepton
            # densities, which the default run_card does not set up
            logger.warning('%s: soft/collinear limit test NOT RUN: an FKS '
                'parton is in the initial state, which needs PDF beams '
                '(set lpp1/lpp2 in Cards/run_card.dat). See %s' % (pdir, log))
            return True
        npass, nfail = content.count('PASSED'), content.count('FAILED')
        if nfail or not npass:
            logger.error('%s: soft/collinear limit test FAILED '
                         '(%d passed, %d failed), see %s'
                         % (pdir, npass, nfail, log))
            return False
        logger.info('%s: soft/collinear limit test passed (%d checks)'
                    % (pdir, npass))
        return True

    @staticmethod
    def _energy_arg(energy):
        """command-line sqrt(s) for check_fks; '0' means built-in default."""
        return ('%.16g' % energy) if energy and energy > 0 else '0'

    def _run_with_timings(self, born_path, energy, nb_try, nb_run):
        """time nb_try Born re-evaluations, averaged over nb_run repetitions."""
        run_times = []
        for _ in range(nb_run):
            t0 = time.time()
            subprocess.call(
                ['./check_fks', self._energy_arg(energy), str(nb_try)],
                cwd=born_path, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL)
            run_times.append(time.time() - t0)
        avg = sum(run_times) / len(run_times)
        if len(run_times) > 1:
            sigma = math.sqrt(sum((t - avg) ** 2 for t in run_times)
                              / (len(run_times) - 1))
        else:
            sigma = 0.0
        sep = '=' * 60
        print('\n' + sep)
        print('Timing summary (%s): %d Born evaluation(s)/run, %d run(s)'
              % (os.path.basename(born_path), nb_try, nb_run))
        print('  wall time per run: %.6f +/- %.6f s' % (avg, sigma))
        print(sep + '\n')


class AskMadMatrixBuild(extended_cmd.ControlSwitch):
    """Switches for building/running the `output standalone` (madmatrix)
    check_sa.exe: the backend, the P* subfolder and the number of make jobs."""

    to_control = [('backend', 'Backend to compile check_sa.exe with'),
                  ('subprocess', 'P* subfolder to build and run'),
                  ('nb_core', 'Number of parallel make jobs')]

    # same list (and order) as bin/generate_events
    backends = ['auto', 'scalar', 'simd_128', 'simd_256', 'avx512y',
                'simd_512', 'cuda', 'hip']

    def __init__(self, question, line_args=[], mode=None, force=False,
                                                                  *args, **opt):
        self.me_dir = opt['mother_interface'].me_dir
        self.subproc_dir = pjoin(self.me_dir, 'SubProcesses')
        self.p_dirs = sorted(d for d in os.listdir(self.subproc_dir)
                             if d.startswith('P') and
                             os.path.isdir(pjoin(self.subproc_dir, d)))
        super(AskMadMatrixBuild, self).__init__(self.to_control,
                                    opt['mother_interface'], *args, **opt)

    #
    #   BACKEND
    #
    def get_allowed_backend(self):
        """cuda/hip are only offered when their compiler is in the PATH
        (madmatrix.mk looks for them the same way)"""

        if hasattr(self, 'allowed_backend'):
            return self.allowed_backend
        self.allowed_backend = [b for b in self.backends
                                if b not in ('cuda', 'hip')]
        if misc.which('nvcc'):
            self.allowed_backend.append('cuda')
        if misc.which('hipcc'):
            self.allowed_backend.append('hip')
        return self.allowed_backend

    def set_default_backend(self):
        """reuse the backend of the last build (recorded by the makefile in
        .check_sa_backend) so that a relaunch does not recompile"""

        self.switch['backend'] = 'auto'
        for d in self.p_dirs:
            marker = pjoin(self.subproc_dir, d, '.check_sa_backend')
            if os.path.exists(marker):
                with open(marker) as fsock:
                    last = fsock.read().strip()
                if last in self.get_allowed_backend():
                    self.switch['backend'] = last
                return

    #
    #   SUBPROCESS
    #
    def get_allowed_subprocess(self):
        return ['all'] + self.p_dirs

    def set_default_subprocess(self):
        self.switch['subprocess'] = 'all'

    def print_options_subprocess(self):
        others = [v for v in self.get_allowed_subprocess()
                  if v != self.switch['subprocess']]
        if len(others) > 3:
            others = others[:3] + ['...']
        return '|'.join(others)

    #
    #   NB_CORE
    #
    def get_allowed_nb_core(self):
        ncpu = os.cpu_count() or 1
        return [str(n) for n in sorted(set([1, 2, 4, 8, ncpu])) if n <= ncpu]

    def check_value_nb_core(self, value):
        return str(value).isdigit() and int(value) > 0

    def set_default_nb_core(self):
        nb_core = self.mother_interface.options.get('nb_core')
        if not nb_core:
            nb_core = self.get_allowed_nb_core()[-1]
        self.switch['nb_core'] = str(nb_core)

    def print_options_nb_core(self):
        return 'any positive integer'


class AskMadMatrixEditCard(common_run.AskforEditCardWithSwitch,
                           AskMadMatrixBuild,
                           common_run.AskforEditCard):
    """Single question for `launch` of an `output standalone` directory: the
    build switches and the edition of the param_card (same commands as for
    standalone_fortran: set, path to a card, decay all auto, ...)."""

    switch_class = AskMadMatrixBuild
    always_cards = ['param_card.dat']
    optional_cards = ['onia_card.dat']
    switch_cards = []


class MadMatrixLauncher(ExtLauncher):
    """Launch the `output standalone` (madmatrix) check_sa.exe.

    Everything runs in process (no bin/generate_events subprocess, which
    stays for command-line use only): one question for the build switches
    and the param_card, then make + check_sa.exe in each chosen P* folder."""

    def __init__(self, cmd_int, running_dir, **options):
        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **options)
        self.cards = ['param_card.dat']
        self.switch = {}

    def get_model(self):
        """The model this output was generated with (SubProcesses/model.txt),
        or the current one of the session if the output did not record it."""

        current = getattr(self.cmd_int, '_curr_model', None)
        model_file = pjoin(self.running_dir, 'SubProcesses', 'model.txt')
        if not os.path.exists(model_file):
            return current
        with open(model_file) as fsock:
            ref = fsock.readline().strip()
        if not ref:
            return current
        try:
            if current and current.get('modelpath+restriction') == ref:
                return current
        except Exception:
            pass
        import madgraph.models.import_ufo as import_ufo
        try:
            with misc.MuteLogger(['madgraph.model'], [50]):
                return import_ufo.import_model(ref)
        except Exception as error:
            logger.warning('could not import the model %s of this output: %s',
                           ref, error)
            return current

    def run(self):
        """ask the build/card question, then build and run check_sa.exe"""

        self.cmd_int.me_dir = self.running_dir
        # the card question needs the output's model (auto widths, update
        # dependent), which is not necessarily the one of the session
        with misc.TMP_variable(self.cmd_int, '_curr_model', self.get_model()):
            self.switch, question = self.cmd_int.ask('', '0', [],
                                           path_msg='enter path',
                                           ask_class=AskMadMatrixEditCard,
                                           mode='fixed', timeout=0,
                                           force=self.force,
                                           return_instance=True)
            if self.force:
                # a forced ask returns without closing the question: run its
                # final card check (auto widths, update dependent) ourselves
                question.postcmd(True, '0')
        self.launch_program()

    def launch_program(self):
        """make and run check_sa.exe (same logic as bin/generate_events)"""

        backend = self.switch['backend']
        sub_path = pjoin(self.running_dir, 'SubProcesses')
        p_dirs = sorted(d for d in os.listdir(sub_path)
                        if d.startswith('P') and
                        os.path.isdir(pjoin(sub_path, d)))
        if self.switch['subprocess'] != 'all':
            p_dirs = [self.switch['subprocess']]

        for d in p_dirs:
            cur_path = pjoin(sub_path, d)
            logger.info('[%s] Building %s', backend, d)
            misc.compile(['BACKEND=%s' % backend, 'USEBUILDDIR=1'],
                         cwd=cur_path, mode='cpp',
                         nb_core=int(self.switch['nb_core']))
            logger.info('[%s] Running %s/check_sa.exe matrix', backend, d)
            try:
                misc.call(['./check_sa.exe', 'matrix'], cwd=cur_path)
            except KeyboardInterrupt:
                break


class aMCatNLOLauncher(ExtLauncher):
    """A class to launch MadEvent run"""
    
    def __init__(self, running_dir, cmd_int, run_mode='', unit='pb', **option):
        """ initialize the StandAlone Version"""

        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **option)
        #self.executable = os.path.join('.', 'bin','generate_events')

        self.options = option
        assert hasattr(self, 'cluster')
        assert hasattr(self, 'multicore')
        assert hasattr(self, 'name')
        assert hasattr(self, 'shell')

        self.unit = unit
        self.run_mode = run_mode
        
        if self.cluster or option['cluster']:
            self.cluster = 1
        if self.multicore or option['multicore']:
            self.cluster = 2
        
        self.cards = []

        # Assign a valid run name if not put in options
        if self.name == '':
            self.name = me_cmd.MadEventCmd.find_available_run_name(self.running_dir)
    
    def launch_program(self):
        """launch the main program"""
        
        # Check for number of cores if multicore mode
        mode = str(self.cluster)
        nb_node = 1
        if mode == "2":
            import multiprocessing
            max_node = multiprocessing.cpu_count()
            if max_node == 1:
                logger.warning('Only one core is detected on your computer! Pass in single machine')
                self.cluster = 0
                self.launch_program()
                return
            elif max_node == 2:
                nb_node = 2
            elif not self.force:
                nb_node = self.ask('How many cores do you want to use?', max_node, list(range(2,max_node+1)))
            else:
                nb_node=max_node
                
        import madgraph.interface.amcatnlo_run_interface as run_int
        
        if hasattr(self, 'shell') and self.shell:
            usecmd = run_int.aMCatNLOCmdShell(me_dir=self.running_dir, options = self.cmd_int.options)
        else:
            usecmd = run_int.aMCatNLOCmd(me_dir=self.running_dir, options = self.cmd_int.options)
        
        #Check if some configuration were overwritten by a command. If so use it    
        set_cmd = [l for l in self.cmd_int.history if l.strip().startswith('set')
                   # an answer to an earlier launch's question is not a
                   # setting of this prompt (extended_cmd.QuestionAnswer)
                   and not extended_cmd.is_question_answer(l)]
        all_options = list(usecmd.options_configuration.keys()) +  list(usecmd.options_madgraph.keys()) + list(usecmd.options_madevent.keys())
        for line in set_cmd:
            arg = line.split()
            if arg[1] not in all_options:
                continue
            try:
                usecmd.exec_cmd(line)
            except Exception as error:
                misc.sprint('Command %s fails with msg: %s'%(str(line), \
                                                                    str(error)))
                pass
        launch = self.cmd_int.define_child_cmd_interface(
                     usecmd, interface=False)
        #launch.me_dir = self.running_dir
        option_line = ' '.join([' --%s' % opt for opt in self.options.keys() \
                if self.options[opt] and not opt in ['cluster', 'multicore', 'name', 'appl_start_grid','shell']])
        if self.options['name']:
            option_line += ' --name %s' %  self.options['name']
        if 'appl_start_grid' in self.options and  self.options['appl_start_grid']:
            option_line += ' --appl_start_grid %s' %  self.options['appl_start_grid']
        command = 'launch ' + self.run_mode + ' ' + option_line

        if mode == "1":
            command += " -c"
        elif mode == "2":
            command += " -m" 
            usecmd.nb_core = int(nb_node)
        try:
            os.remove('ME5_debug')
        except:
           pass
        launch.run_cmd(command)
        launch.run_cmd('quit')
        
        

                
        
class MELauncher(ExtLauncher):
    """A class to launch MadEvent run"""
    
    def __init__(self, running_dir, cmd_int , unit='pb', **option):
        """ initialize the StandAlone Version"""

        ExtLauncher.__init__(self, cmd_int, running_dir, './Cards', **option)
        #self.executable = os.path.join('.', 'bin','generate_events')
        self.pythia = cmd_int.options['pythia-pgs_path']
        self.delphes = cmd_int.options['delphes_path'],
        self.options = cmd_int.options

        assert hasattr(self, 'cluster')
        assert hasattr(self, 'multicore')
        assert hasattr(self, 'name')
        assert hasattr(self, 'shell')

        self.unit = unit
        
        if self.cluster:
            self.cluster = 1
        if self.multicore:
            self.cluster = 2
        
        self.cards = []

        # Assign a valid run name if not put in options
        if self.name == '':
            self.name = me_cmd.MadEventCmd.find_available_run_name(self.running_dir)
    
    def launch_program(self):
        """launch the main program"""
        
        # Check for number of cores if multicore mode
        mode = str(self.cluster)
        nb_node = 1
        if mode == "2":
            import multiprocessing
            max_node = multiprocessing.cpu_count()
            if max_node == 1:
                logger.warning('Only one core is detected on your computer! Pass in single machine')
                self.cluster = 0
                self.launch_program()
                return
            elif max_node == 2:
                nb_node = 2
            elif not self.force:
                nb_node = self.ask('How many cores do you want to use?', max_node, list(range(2,max_node+1)))
            else:
                nb_node=max_node
                
        import madgraph.interface.madevent_interface as ME
        
        stdout_level = self.cmd_int.options['stdout_level']
        
        with ME.MadEventCmd.RunWebHandling(self.running_dir):
            if os.path.exists(pjoin(self.running_dir, 'bin','internal', 'launch_plugin.py')):
                with  misc.TMP_variable(sys, 'path', sys.path + [pjoin(self.running_dir, 'bin', 'internal')]):
                    from importlib import reload
                    try:
                        reload('launch_plugin')
                    except Exception as error:
                        misc.sprint(error)
                        import launch_plugin
                usecmd = launch_plugin.MEINTERFACE(me_dir=self.running_dir, options=self.options, force_run=True)
            elif self.shell:
                usecmd = ME.MadEventCmdShell(me_dir=self.running_dir, options=self.options, force_run=True)
            else:
                usecmd = ME.MadEventCmd(me_dir=self.running_dir, options=self.options, force_run=True)
                usecmd.pass_in_web_mode()
            #Check if some configuration were overwritten by a command. If so use it    
            set_cmd = [l for l in self.cmd_int.history if l.strip().startswith('set')
                       # an answer to an earlier launch's question is not a
                       # setting of this prompt (extended_cmd.QuestionAnswer)
                       and not extended_cmd.is_question_answer(l)]
            all_options = list(usecmd.options_configuration.keys()) +  list(usecmd.options_madgraph.keys()) + list(usecmd.options_madevent.keys())
            for line in set_cmd:
                arg = line.split()
                if arg[1] not in all_options:
                    continue
                try:
                    usecmd.do_set(line[3:], log=False)
                except usecmd.InvalidCmd:
                    pass
            usecmd.do_set('stdout_level %s'  % stdout_level,log=False)
            #ensure that the logger level 
            launch = self.cmd_int.define_child_cmd_interface(
                         usecmd, interface=False)
            #launch.me_dir = self.running_dir
            if self.unit == 'pb':
                command = 'generate_events %s' % self.name
            else:
                warning_text = '''\
                Note that since 2.3. The launch for 1>N pass in event generation
                For efficient width computation see arXiv:1402.1178.'''
                logger.warning(warning_text)
                command = 'generate_events %s' % self.name
            if mode == "1":
                command += " --cluster"
            elif mode == "2":
                command += " --nb_core=%s" % nb_node
            
            if self.force:
                command+= " -f"
            
            if self.laststep:
                command += ' --laststep=%s' % self.laststep
            if self.reweight:
                command += ' -R '
            if self.madspin:
                command += ' -M '
            
            
            try:
                os.remove('ME5_debug')
            except:
                pass
    
            launch.run_cmd(command)
            launch.run_cmd('quit')
            
            if os.path.exists('ME5_debug'):
                return True
            
            # Display the cross-section to the screen
            path = os.path.join(self.running_dir, 'SubProcesses', 'results.dat') 
            if not os.path.exists(path):
                logger.error('Generation failed (no results.dat file found)')
                return
            fsock = open(path)
            line = fsock.readline()
            cross, error = line.split()[0:2]
            
            logger.info('more information in %s' 
                                     % os.path.join(self.running_dir, 'index.html'))
                

class Pythia8Launcher(ExtLauncher):
    """A class to launch Pythia8 run"""
    
    def __init__(self, running_dir, cmd_int, **option):
        """ initialize launching Pythia 8"""

        running_dir = os.path.join(running_dir, 'examples')
        ExtLauncher.__init__(self, cmd_int, running_dir, '.', **option)
        self.cards = []
    
    def prepare_run(self):
        """ ask for pythia-pgs/delphes run """

        # Find all main_model_process.cc files
        date_file_list = []
        for file in misc.glob('main_*_*.cc', self.running_dir):
            # retrieves the stats for the current file as a tuple
            # (mode, ino, dev, nlink, uid, gid, size, atime, mtime, ctime)
            # the tuple element mtime at index 8 is the last-modified-date
            stats = os.stat(file)
            # create tuple (year yyyy, month(1-12), day(1-31), hour(0-23), minute(0-59), second(0-59),
            # weekday(0-6, 0 is monday), Julian day(1-366), daylight flag(-1,0 or 1)) from seconds since epoch
            # note:  this tuple can be sorted properly by date and time
            lastmod_date = time.localtime(stats[8])
            date_file_list.append((lastmod_date, os.path.split(file)[-1]))

        if not date_file_list:
            raise MadGraph5Error('No Pythia output found')
        # Sort files according to date with newest first
        date_file_list.sort()
        date_file_list.reverse()
        files = [d[1] for d in date_file_list]
        
        answer = ''
        answer = self.ask('Select a main file to run:', files[0], files)

        self.cards.append(answer)
    
        self.executable = self.cards[-1].replace(".cc","")

        # Assign a valid run name if not put in options
        if self.name == '':
            for i in range(1000):
                path = os.path.join(self.running_dir, '',
                                    '%s_%02i.log' % (self.executable, i))
                if not os.path.exists(path):
                    self.name = '%s_%02i.log' % (self.executable, i)
                    break
        
        if self.name == '':
            raise MadGraph5Error('too many runs in this directory')

        # Find all exported models
        models = misc.glob("Processes_*", pjoin(self.running_dir,os.path.pardir))
        models = [os.path.split(m)[-1].replace("Processes_","") for m in models]
        # Extract model name from executable
        models.sort(key=len)
        models.reverse()
        model_dir = ""
        for model in models:
            if self.executable.replace("main_", "").startswith(model):
                model_dir = "Processes_%s" % model
                break
        if model_dir:
            self.model = model
            self.model_dir = os.path.realpath(os.path.join(self.running_dir,
                                                           os.path.pardir,
                                                           model_dir))
            self.cards.append(os.path.join(self.model_dir,
                                           "param_card_%s.dat" % model))
        
    def launch_program(self):
        """launch the main program"""

        # Make pythia8
        print("Running make for pythia8 directory")
        if self.model_dir:
            print("Running make in %s" % self.model_dir)
            misc.compile(cwd=self.model_dir, mode='cpp')
        # Finally run make for executable
        makefile = self.executable.replace("main_","Makefile_")
        print("Running make with %s" % makefile)
        misc.compile(arg=['-f', makefile], cwd=self.running_dir, mode='cpp')
        
        print("Running " + self.executable)
        
        output = open(os.path.join(self.running_dir, self.name), 'w')
        if not self.executable.startswith('./'):
            self.executable = os.path.join(".", self.executable)
        subprocess.call([self.executable], stdout = output, stderr = output,
                        cwd=self.running_dir)
        
        # Display the cross-section to the screen
        path = os.path.join(self.running_dir, self.name) 
        pydoc.pager(open(path).read())

        print("Output of the run is found at " + \
              os.path.realpath(os.path.join(self.running_dir, self.name)))

# old compatibility shortcut
open_file = misc.open_file
