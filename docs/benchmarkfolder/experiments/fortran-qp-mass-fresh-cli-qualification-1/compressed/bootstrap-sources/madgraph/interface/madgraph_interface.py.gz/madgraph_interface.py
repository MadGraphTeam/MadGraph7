################################################################################
#
# Copyright (c) 2009 The MadGraph7 Development team and Contributors
#
# This file is a part of the MadGraph7 project, an application which
# automatically generates Feynman diagrams and matrix elements for arbitrary
# high-energy processes in the Standard Model and beyond.
#
# It is subject to the MadGraph7 license which should accompany this
# distribution.
#
# For more information, visit madgraph.phys.ucl.ac.be and amcatnlo.web.cern.ch
#
################################################################################
"""A user friendly command line interface to access MadGraph7 features at LO.
   Uses the cmd package for command interpretation and tab completion.
"""
from __future__ import division

from __future__ import absolute_import
import atexit
import collections
import concurrent.futures
import cmath
import math
import glob
import logging
import operator
import optparse
import os
import pydoc
import random
import re
import signal
import subprocess
import copy
import sys
import shutil
import tempfile

import traceback
import time
import inspect
import urllib.request, urllib.parse, urllib.error
import random
import io
import json
#useful shortcut
pjoin = os.path.join

# define a temporary directory for drawing diagrams
tempdir = tempfile.TemporaryDirectory()

try:
    import readline
    GNU_SPLITTING = ('GNU' in readline.__doc__)
except:
    GNU_SPLITTING = True

import aloha
import madgraph
from madgraph import MG4DIR, MG5DIR, MadGraph5Error


import madgraph.core.base_objects as base_objects
import madgraph.core.color_amp as color_amp
import madgraph.core.diagram_generation as diagram_generation
import madgraph.loop.loop_diagram_generation as loop_diagram_generation
import madgraph.loop.loop_base_objects as loop_base_objects
import madgraph.core.drawing as draw_lib
import madgraph.core.helas_objects as helas_objects



import madgraph.iolibs.drawing_eps as draw
import madgraph.iolibs.export_cpp as export_cpp
import madgraph.iolibs.export_v4 as export_v4
import madgraph.iolibs.helas_call_writers as helas_call_writers
import madgraph.iolibs.file_writers as writers
import madgraph.iolibs.files as files
import madgraph.iolibs.group_subprocs as group_subprocs
import madgraph.iolibs.import_v4 as import_v4
import madgraph.iolibs.save_load_object as save_load_object

import madgraph.interface.extended_cmd as cmd
import madgraph.interface.coloring_logging as coloring_logging
import madgraph.interface.tutorials as tutorials
import madgraph.interface.tutorials.mixin as tutorial_mixin
import madgraph.interface.launch_ext_program as launch_ext
import madgraph.interface.madevent_interface as madevent_interface
import madgraph.interface.amcatnlo_run_interface as amcatnlo_run

import madgraph.loop.loop_exporters as loop_exporters
import madgraph.loop.loop_helas_objects as loop_helas_objects

import madgraph.various.process_checks as process_checks
import madgraph.various.banner as banner_module
import madgraph.various.misc as misc
import madgraph.various.cluster as cluster

import madgraph.fks.fks_tag as fks_tag

import madgraph.models as ufomodels
import madgraph.models.import_ufo as import_ufo
import madgraph.models.write_param_card as param_writer
import madgraph.models.check_param_card as check_param_card
import madgraph.models.model_reader as model_reader
import madgraph.models.build_restriction_lib as build_restrict_lib

import aloha.aloha_fct as aloha_fct
import aloha.create_aloha as create_aloha
import aloha.aloha_lib as aloha_lib

import mg5decay.decay_objects as decay_objects


# Special logger for the Cmd Interface
logger = logging.getLogger('cmdprint') # -> stdout
logger_check = logging.getLogger('check') # -> stdout
logger_mg = logging.getLogger('madgraph.interface') # -> stdout
logger_stderr = logging.getLogger('fatalerror') # ->stderr
# Every tutorial writes through this one logger, whatever it teaches: the
# per-tutorial loggers below are kept alive only because external logging
# configurations still name them.
logger_tuto = logging.getLogger('tutorial') # -> stdout include instruction in
                                            #order to learn MG5
logger_tuto_nlo = logging.getLogger('tutorial_aMCatNLO') # deprecated, unused
logger_tuto_madloop = logging.getLogger('tutorial_MadLoop') # deprecated, unused


# The logo's blue (#3B6598). Empty under --plain (MG7_NO_COLOR).
if os.environ.get('MG7_NO_COLOR'):
    MG7_BLUE = ""
elif os.environ.get('COLORTERM', '').lower() in ('truecolor', '24bit'):
    MG7_BLUE = "\033[1;38;2;59;101;152m"
else:
    MG7_BLUE = "\033[1;34m" #fall back to bold blue
MG7_RESET = "\033[0m" if MG7_BLUE else ""

class DuplicateParticle(madgraph.InvalidCmd):
    """A particle name given twice where only one is meaningful.

    Its own class because the caller that asks for it (the required s-channel
    list) turns it into a message about the "> A A >" syntax, and must not
    turn any *other* InvalidCmd -- an unknown particle name, say -- into that
    same misleading message.
    """
    
#===============================================================================
# Interference of two amplitude sets: 'left [LIxtree=QCD] right' and
# 'left [treextree] right'
#===============================================================================
# The bracket of an interference process. Its keyword is matched without
# regard to case, so that [LIxtree=QCD], [lixtree=QCD] and [TreeXTree] are all
# accepted; INTERFERENCE_MODES maps the lower-case spelling on the one stored
# in Process['interference_mode'].
INTERFERENCE_MODES = {'lixtree': 'LIxtree', 'treextree': 'treextree'}
_INTERFERENCE_BRACKET = re.compile(
    r"\[\s*(?:(?P<option>\w+)\s*=)?\s*(?P<orders>[^\]\[]*?)\s*\]")
# One coupling-order constraint at the start of a string: 'QED=0', 'QCD^2<=4',
# 'QED == 2', ... The constraints written between the bracket and the
# right-hand process belong to the left-hand one (the usual place of the
# squared-order constraints of a loop process), those written after the
# right-hand process belong to the right-hand one. An order name is an
# identifier, never a pdg code: '25 > 6 -6' is a process, not 'ORDER > 6'.
_LEADING_ORDER_CONSTRAINT = re.compile(
    r"^\s*[A-Za-z_]\w*(?:\^2)?\s*(?:===|==|<=|>=|!=|=|<|>)\s*-?\d+(?=\s|$)")


def interference_mode_of(option, orders):
    """The interference mode named by a bracket, '' if it names none.
    'option' is the word before '=' (None without '='), 'orders' the list of
    words after it."""

    if option and option.lower() in INTERFERENCE_MODES:
        return INTERFERENCE_MODES[option.lower()]
    # bare keyword: '[treextree]', or '[LIxtree]' (refused later: no orders)
    if not option and len(orders) == 1 and orders[0].lower() in INTERFERENCE_MODES:
        return INTERFERENCE_MODES[orders[0].lower()]
    return ''


def split_interference_line(line):
    """Split a process definition of the form

        left_process [LIxtree=ORDERS] left_constraints right_process
        left_process [treextree] left_constraints right_process

    into (left_line, mode, right_line).

    'left_line' is the left-hand process written in the ordinary syntax: with
    '[noborn=ORDERS]' for LIxtree (the loop-induced amplitude) and without any
    bracket for treextree. 'mode' is 'LIxtree' or 'treextree', and
    'right_line' the right-hand (tree-level) process, None when it is absent.
    A trailing '@N' and what follows it stay with the left-hand line, which
    carries the process number of the whole definition.

    A line without an interference bracket is returned as (line, '', None).
    Raises InvalidCmd for a malformed interference bracket.
    """

    match = _INTERFERENCE_BRACKET.search(line)
    if not match:
        return line, '', None
    option = match.group('option')
    orders = match.group('orders').split()
    mode = interference_mode_of(option, orders)
    if not mode:
        return line, '', None
    if not option:
        # the only word in the bracket is the keyword itself
        orders = []

    head, tail = line[:match.start()], line[match.end():]
    if '[' in tail or ']' in tail:
        raise madgraph.InvalidCmd(
            "Only one '[...]' is allowed in a %s process: the right-hand "
            "process is a tree-level process." % mode)

    if mode == 'LIxtree':
        if not orders:
            raise madgraph.InvalidCmd(
                "The LIxtree mode needs the orders of the loop, as in "
                "'g g > h > t t~ [LIxtree=QCD]'.")
        bracket = ' [noborn= %s ] ' % ' '.join(orders)
    else:
        if option:
            raise madgraph.InvalidCmd(
                "The treextree mode takes no orders: write '[treextree]', "
                "not '[%s=%s]'." % (option, ' '.join(orders)))
        bracket = ' '

    # '@N ...' closes the whole definition: keep it with the left-hand line
    suffix = ''
    at = re.search(r'@\s*\d+', tail)
    if at:
        tail, suffix = tail[:at.start()], ' ' + tail[at.start():]

    left_constraints = []
    tail = tail.strip()
    constraint = _LEADING_ORDER_CONSTRAINT.match(tail)
    while constraint:
        rest = tail[constraint.end():].strip()
        # a constraint is followed by more constraints or by the right-hand
        # process, which has an arrow: in 'h > 5 -5', 'h > 5' is no constraint
        if rest and not re.search(r'>\D', rest):
            break
        left_constraints.append(constraint.group(0).strip())
        tail = rest
        constraint = _LEADING_ORDER_CONSTRAINT.match(tail)

    right = tail if tail else None
    if right is None and mode == 'treextree':
        raise madgraph.InvalidCmd(
            "The treextree mode needs the right-hand process, as in "
            "'p p > z > e+ e- [treextree] p p > a > e+ e-'.")

    left = head.rstrip() + bracket + ' '.join(left_constraints) + suffix
    return ' '.join(left.split()), mode, right


# the same prompt without the colour escapes, for quoting commands inside
# tutorial text and help messages
MG7_PROMPT_TEXT = "MG7> "

# Stock macOS Python just leaks escape bytes into
# the line editor instead of rendering. Keep the prompt plain there.
try:
    _prompt_is_libedit = 'libedit' in readline.__doc__
except Exception:
    _prompt_is_libedit = False

#left open so whole command in blue
if _prompt_is_libedit or not MG7_BLUE:
    MG7_PROMPT = MG7_PROMPT_TEXT
else:
    MG7_PROMPT = "\001%s\002MG7> " % MG7_BLUE

# The banner (and every easter-egg variant of it in madgraph.various.misc) is
# written as a block of BANNER_WIDTH columns: '*', 58 characters of content and
# a closing '*'. On a wider terminal the block is re-centred so that the two
# columns of '*' sit on the edges of the screen. A line built wider than that
# (the GIT line, with a long tag and a long branch name) is re-centred the same
# way, from its own length, and is left alone when it does not fit the screen.
BANNER_WIDTH = 60
# Width assumed when the output is not a terminal (a log file, a pipe, ...).
BANNER_FILE_WIDTH = 80
# Escape sequences (the development-version warning is printed in red) do not
# take any place on screen and must not be counted in the width of a line.
BANNER_ANSI = re.compile('\\033\\[[0-9;]*m')

def get_banner_width():
    """Number of columns available for the banner: the width of the terminal,
    or BANNER_FILE_WIDTH when the output is redirected to a file/pipe."""

    try:
        if not sys.stdout.isatty():
            return BANNER_FILE_WIDTH
        width = shutil.get_terminal_size((BANNER_FILE_WIDTH, 24)).columns
    except Exception:
        return BANNER_FILE_WIDTH
    return max(width, BANNER_WIDTH)

def fit_banner_width(text, width=None):
    """Re-centre a BANNER_WIDTH columns banner on a screen of *width* columns.

    Each line of at least BANNER_WIDTH visible characters delimited by '*' is
    padded symmetrically (with '*' for the horizontal rules, with spaces
    otherwise); any other line, and any line already wider than the screen, is
    returned untouched."""

    if width is None:
        width = get_banner_width()
    if width <= BANNER_WIDTH:
        return text

    out = []
    for line in text.split('\n'):
        plain = BANNER_ANSI.sub('', line)
        if len(plain) < BANNER_WIDTH or not plain.startswith('*') \
                                     or not plain.endswith('*'):
            out.append(line)
            continue
        extra = width - len(plain)
        if extra <= 0:
            out.append(line)
            continue
        left = extra // 2
        right = extra - left
        start = line.index('*')
        end = line.rindex('*')
        inside = line[start+1:end]
        fill = '*' if set(BANNER_ANSI.sub('', inside)) == set('*') else ' '
        out.append(line[:start+1] + fill*left + inside + fill*right + line[end:])
    return '\n'.join(out)

# Human readable name of the internal polarization codes, used when refusing a
# polarization restriction that names the same state twice.
_POLARIZATION_STATE_NAMES = {0: '0 (longitudinal)',
                             1: '+1 (right)',
                             -1: '-1 (left)',
                             4: '4 (metric, "G")',
                             5: '5 (Theta, "H")',
                             6: '6 (longitudinal - Theta, "Q")',
                             7: '7 (Ward-protected, "W")',
                             9: '9 (scalar, "S")',
                             99: '99 (auxiliary, "A")'}

def polarization_state_name(value):
    """Name one internal polarization code the way a user typed/reads it."""
    return _POLARIZATION_STATE_NAMES.get(value, '%+d' % value)

#===============================================================================
# CmdExtended
#===============================================================================
class CmdExtended(cmd.Cmd):
    """Particularisation of the cmd command for MG5"""

    #suggested list of command
    next_possibility = {
        'start': ['import model ModelName', 'import command PATH',
                      'import proc_v4 PATH', 'tutorial'],
        'import model' : ['generate PROCESS','define MULTIPART PART1 PART2 ...',
                                   'display particles', 'display interactions'],
        'define': ['define MULTIPART PART1 PART2 ...', 'generate PROCESS',
                                                    'display multiparticles'],
        'generate': ['add process PROCESS','output [OUTPUT_TYPE] [PATH]','display diagrams'],
        'add process':['output [OUTPUT_TYPE] [PATH]', 'display processes'],
        'output':['launch','open index.html','history PATH', 'exit'],
        'display': ['generate PROCESS', 'add process PROCESS', 'output [OUTPUT_TYPE] [PATH]'],
        'import proc_v4' : ['launch','exit'],
        'launch': ['open index.html','exit'],
        'tutorial': ['generate PROCESS', 'import model MODEL', 'help TOPIC']
    }

    debug_output = 'MG5_debug'
    error_debug = 'Please report this bug on https://bugs.launchpad.net/mg5amcnlo\n'
    error_debug += 'More information is found in \'%(debug)s\'.\n'
    error_debug += 'Please attach this file to your report.'

    config_debug = 'If you need help with this issue please contact us on https://answers.launchpad.net/mg5amcnlo\n'

    keyboard_stop_msg = """stopping all operation
            in order to quit mg5 please enter exit"""

    # Define the Error Class # Define how error are handle
    InvalidCmd = madgraph.InvalidCmd
    ConfigurationError = MadGraph5Error
    
    intro_banner = "************************************************************\n" + \
        "*                                                          *\n" + \
        "*                     W E L C O M E to                     *\n" + \
        "*                    M A D G R A P H " + MG7_BLUE + "7" + MG7_RESET + "                     *\n" + \
        "*                                                          *\n" + \
        "*                                                          *\n" + \
        "*                        ..........                        *\n" + \
        "*                      @          ....                     *\n" + \
        "*                    @               ...                   *\n" + \
        "*                  @    M         M    .                   *\n" + \
        "*                 @     MM       MM    ..                  *\n" + \
        "*                 .     M  M   M  M  ..                    *\n" + \
        "*                 ..    M   M M   M ..                     *\n" + \
        "*                  .    M    M    M.                       *\n" + \
        "*                  ...               " + MG7_BLUE + "7777777" + MG7_RESET + "               *\n" + \
        "*                    ....                 " + MG7_BLUE + "7" + MG7_RESET + "                *\n" + \
        "*                       ................ " + MG7_BLUE + "7" + MG7_RESET + "                 *\n" + \
        "*                                       " + MG7_BLUE + "7" + MG7_RESET + "                  *\n" + \
        "*                                      " + MG7_BLUE + "7" + MG7_RESET + "                   *\n" + \
        "*                                                          *\n" + \
        "%s" + \
        "*                                                          *\n" + \
        "*       The MadGraph7 Development Team - Find us at        *\n" + \
        "*              http://madgraph.phys.ucl.ac.be/             *\n" + \
        "*                            and                           *\n" + \
        "*            http://amcatnlo.web.cern.ch/amcatnlo/         *\n" + \
        "*                                                          *\n" + \
        "*               Type 'help' for in-line help.              *\n" + \
        "*       Type 'tutorial' to learn how MadGraph7 works       *\n" + \
        "*                                                          *\n" + \
        "************************************************************"
    

    def __init__(self, *arg, **opt):
        """Init history and line continuation"""

        # If possible, build an info line with current version number
        # and date, from the VERSION text file
        info = misc.get_pkg_info()
        info_line = ""

        if 'version' in info and  'date' in info:
            len_version = len(info['version'])
            len_date = len(info['date'])
            if len_version + len_date < 30:
                info_line = "#*         VERSION %s %s %s         *\n" % \
                            (info['version'],
                            (30 - len_version - len_date) * ' ',
                            info['date'])

        if os.path.exists(pjoin(MG5DIR, '.git')):
            try: 
                proc = subprocess.Popen(['git', 'tag', '--points-at', 'HEAD'], stdout=subprocess.PIPE,cwd=MG5DIR)
            except OSError:
                # user does not have git installed
                logger_stderr.critical("Note that this is a development version.\nThis version is intended for development/beta testing and NOT for production.\nThis version has not been fully tested (if at all) and might have limited user support (if at all)")
                info_line += "#*     UNKNOWN DEVELOPMENT VERSION. NOT FOR PRODUCTION      *\n"
            else:
                # check if the version corresponds to a tag
                #
                alltag,_ = proc.communicate() 
                alltag = alltag.decode(errors='ignore').strip().split()
              
                if not alltag:
                    proc = subprocess.Popen(['git', 'describe', '--tags'], stdout=subprocess.PIPE,cwd=MG5DIR)
                    tag,_ = proc.communicate()
                    tag = tag.decode(errors='ignore').strip()
                    
                elif len(alltag) == 1:
                    tag = alltag[0]
                else:
                    tag = [name for name in alltag if name.startswith('v')][0]
                branch,_ = subprocess.Popen(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], stdout=subprocess.PIPE,cwd=MG5DIR).communicate()
                branch = branch.decode(errors='ignore').strip()
                

                info_line += "#*         GIT %s %s %s         *\n" % \
                                (tag,
                                (34 - len(tag) - len(branch)) * ' ',
                                branch)
        elif os.path.exists(pjoin(MG5DIR, 'bin', 'create_release.py')):
            logger_stderr.critical("Note that this is a development version.\nThis version is intended for development/beta testing and NOT for production.\nThis version has not been fully tested (if at all) and might have limited user support (if at all)")
            info_line += "\033[1;31m#*%s*\033[1;0m\n" % (' '*58)
            info_line += "\033[1;31m#*          WARNING: UNKNOWN DEVELOPMENT VERSION.           *\033[1;0m\n"
            info_line += "\033[1;31m#*            WARNING: DO NOT USE FOR PRODUCTION            *\033[1;0m\n"
            info_line += "\033[1;31m#*%s*\033[1;0m\n" % (' '*58)

        # Create a header for the history file.
        # Remember to fill in time at writeout time!
        self.history_header = banner_module.ProcCard.history_header % {'info_line': info_line}
        banner_module.ProcCard.history_header = self.history_header

        if info_line:
            info_line = info_line.replace("#*","*")
            

        logger.info(fit_banner_width(self.intro_banner % info_line))

        cmd.Cmd.__init__(self, *arg, **opt)

        self.history = banner_module.ProcCard()


    def default(self, line):
        """Default action if line is not recognized"""

        # Faulty command
        log=True
        if line.startswith('p') or line.startswith('e'):
            logger.warning("Command %s not recognized. Did you mean \'generate %s\'?. Please try again" %
                           (line.split()[0], line))
            log=False
        return super(CmdExtended,self).default(line, log=log)

    def postcmd(self,stop, line):
        """ finishing a command
        This looks if the command add a special post part.
        This looks if we have to write an additional text for the tutorial."""

        stop = super(CmdExtended, self).postcmd(stop, line)
        # Print additional information in case of routines fails
        if stop == False:
            return False

        # The tutorial hook used to live here as three hard-coded
        # command-name -> text lookups.  It now lives in
        # madgraph.interface.tutorials.mixin.TutorialMixin.postcmd, which is
        # only in the MRO while a tutorial is actually running -- so outside
        # tutorial mode this costs nothing at all.
        return stop


    def get_history_header(self):
        """return the history header"""
        return self.history_header % misc.get_time_info()

#===============================================================================
# HelpToCmd
#===============================================================================
class HelpToCmd(cmd.HelpCmd):
    """ The Series of help routine for the MadGraphCmd"""

    def help_save(self):
        logger.info("syntax: save %s FILENAME [OPTIONS]" % "|".join(self._save_opts),'$MG:color:BLUE')
        logger.info("-- save information as file FILENAME",'$MG:BOLD')
        logger.info("   FILENAME is optional for saving 'options'.")
        logger.info('   By default it uses ./input/mg7_configuration.txt')
        logger.info('   If you put "global" for FILENAME it will use the global configuration')
        logger.info('   If this files exists, it is uses by all MG5 on the system but continues')
        logger.info('   to read the local options files.')
        logger.info('   if additional argument are defined for save options, only those arguments will be saved to the configuration file.')

    def help_load(self):
        logger.info("syntax: load %s FILENAME" % "|".join(self._save_opts),'$MG:color:BLUE')
        logger.info("-- load information from file FILENAME",'$MG:BOLD')

    def help_import(self):
        logger.info("syntax: import " + "|".join(self._import_formats) + \
              " FILENAME",'$MG:color:BLUE')
        logger.info("-- imports file(s) in various formats",'$MG:color:GREEN')
        logger.info("")
        logger.info("   import model MODEL[-RESTRICTION] [OPTIONS]:",'$MG:BOLD')
        logger.info("      Import a UFO model.")
        logger.info("      MODEL should be a valid UFO model name")
        logger.info("      Model restrictions are specified by MODEL-RESTRICTION")
        logger.info("        with the file restrict_RESTRICTION.dat in the model dir.")
        logger.info("        By default, restrict_default.dat is used.")
        logger.info("        Specify model_name-full to get unrestricted model.")
        logger.info("      '--modelname' keeps the original particle names for the model")
        logger.info("")
        logger.info("      Type 'display modellist' to have the list of all model available.",'$MG:color:GREEN')
        logger.info("")
        logger.info("   import model_v4 MODEL --debug [--modelname] :",'$MG:BOLD')
        logger.info("      Import an MG4 model in debug mode only.")
        logger.info("      Model should be the name of the model")
        logger.info("      or the path to theMG4 model directory")
        logger.info("      This deprecated command is no longer supported in normal user mode.")
        logger.info("      '--modelname' keeps the original particle names for the model")
        logger.info("")
        logger.info("   import proc_v4 [PATH] :",'$MG:BOLD')
        logger.info("      Execute MG5 based on a proc_card.dat in MG4 format.")
        logger.info("      Path to the proc_card is optional if you are in a")
        logger.info("      madevent directory")
        logger.info("")
        logger.info("   import command PATH :",'$MG:BOLD')
        logger.info("      Execute the list of command in the file at PATH")
        logger.info("")
        logger.info("   import banner PATH  [--no_launch]:",'$MG:BOLD')
        logger.info("      Rerun the exact same run define in the valid banner.")

    def help_install(self):
        logger.info("syntax: install " + "|".join(self._install_opts),'$MG:color:BLUE')
        logger.info("-- Download the last version of the program and install it")
        logger.info("   locally in the current MadGraph7 version. In order to have")
        logger.info("   a successful installation, you will need to have an up-to-date")
        logger.info("   F77 and/or C and Root compiler.")
        logger.info(" ")
        logger.info("   When installing any of the following programs:")
        logger.info("     %s"%(', '.join(self._advanced_install_opts)))
        logger.info("   The following options are available:")
        logger.info("     --force        Overwrite without asking any existing installation.")
        logger.info("     --keep_source  Keep a local copy of the sources of the tools MadGraph7 installed from.")
        logger.info("     --hepmc2       (pythia8) Build Pythia8 against HepMC2 instead of HepMC3.")
        logger.info("                    Either way, main164 is also compiled for the other HepMC version.")
        logger.info(" ")
        logger.info("   \"install cuttools_iregi\"",'$MG:BOLD')
        logger.info("   recompile the CutTools and IREGI libraries shipped with MadGraph7")
        logger.info("   (in vendor/) with the current fortran compiler (option fortran_compiler).")
        logger.info("   Needed after a change (or an update) of the fortran compiler.")
        logger.info(" ")
        logger.info("   \"install update\"",'$MG:BOLD')
        logger.info("   check if your MG5 installation is the latest one.")
        logger.info("   If not it load the difference between your current version and the latest one,")
        logger.info("   and apply it to the code. Two options are available for this command:")
        logger.info("     -f: didn't ask for confirmation if it founds an update.")
        logger.info("     --timeout=: Change the maximum time allowed to reach the server.")
        logger.info(" ")
        logger.info("   \"install madspace [options]\"",'$MG:BOLD')
        logger.info("   Install the madspace phase-space library used by the MG7 integrator.")
        logger.info("   Without options an interactive installer is launched. Available options:")
        logger.info("     -y/--yes       Re-install non-interactively using saved settings.")
        logger.info("     --bin          Install pre-compiled package from PyPI (non-interactive;")
        logger.info("                    only guaranteed to match this checkout in a release tarball).")
        logger.info("     --source       Build from source (non-interactive).")
        logger.info("     -j N/--jobs=N  Parallel compilation jobs (source build;")
        logger.info("                    defaults to the 'nb_core' option).")
        logger.info("     --cuda         Enable CUDA GPU backend (source build).")
        logger.info("     --hip          Enable HIP/ROCm GPU backend (source build).")
        logger.info("     --openblas     Build OpenBLAS from source (default on Linux/Windows, source build).")
        logger.info("     --no-openblas  Use system BLAS library (default on Apple, source build).")
        logger.info("     --simd         Enable SIMD backend (source build, experimental).")
        logger.info("     --debug        Optimized build with debug symbols, RelWithDebInfo (source build).")
        logger.info("     --full-debug   Debug build without optimization, Debug mode (source build).")
        logger.info("     --no-debug     Optimized build, no debug symbols, Release (source build, default).")
        logger.info("     --cuda-arch=ARCHS  Semicolon-separated CUDA compute capabilities, e.g. 75;80;86.")
        logger.info("     --hip-arch=ARCHS   Semicolon-separated HIP architectures, e.g. gfx900;gfx906.")
        logger.info(" ")
        logger.info("   \"install ninjars [options]\"",'$MG:BOLD')
        logger.info("   Build the pinned NinjaRS/oneloopmaster Fortran interface (MLReductionLib=8).")
        logger.info("   Requires Cargo/Rust >= 1.96, GNU make and a Fortran compiler with REAL(16).")
        logger.info("     --source=DIR          Use a local NinjaRS checkout (copied before building).")
        logger.info("     --oneloop-source=DIR  Use a local oneloopmaster checkout.")
        logger.info("     --prefix=DIR          Override the HEPTools installation prefix.")
        logger.info("     -j N/--jobs=N         Parallel compilation jobs (default: nb_core).")
        logger.info("     --update              Rebuild with this checkout's committed dependency pins (after git pull).")
        logger.info("                           Replace the installation after DP and QP smoke tests pass.")
        logger.info("     --force               Equivalent backward-compatible alias for --update.")
        logger.info("   \"install tirust [options]\"",'$MG:BOLD')
        logger.info("   Build the pinned TIRust/oneloopmaster Fortran interface (MLReductionLib=9).")
        logger.info("   Requires Cargo/Rust >= 1.96, GNU make and a Fortran compiler with REAL(16).")
        logger.info("     --source=DIR          Use a local TIRust checkout (copied before building).")
        logger.info("     --oneloop-source=DIR  Use a local oneloopmaster checkout.")
        logger.info("     --prefix=DIR          Override the HEPTools installation prefix.")
        logger.info("     -j N/--jobs=N         Parallel compilation jobs (default: nb_core).")
        logger.info("     --update              Rebuild with this checkout's committed dependency pins (after git pull).")
        logger.info("                           Replace the installation after DP and QP smoke tests pass.")
        logger.info("     --force               Equivalent backward-compatible alias for --update.")

    def help_display(self):
        logger.info("syntax: display " + "|".join(self._display_opts),'$MG:color:BLUE')
        logger.info("-- display a the status of various internal state variables")
        logger.info("   for particles/interactions you can specify the name or id of the")
        logger.info("   particles/interactions to receive more details information.")
        logger.info("   Example: display particles e+.",'$MG:color:GREEN')
        logger.info(" > For \"checks\", can specify only to see failed checks.")
        logger.info(" > For \"diagrams\", you can specify where the file will be written.")
        logger.info("   Add --no_open to save without opening the files (directory required).")
        logger.info("   Add --merge to merge all .eps files into a single PDF via ghostscript (directory required).")
        logger.info("   Example: display diagrams ./",'$MG:color:GREEN')
        logger.info("   Example: display diagrams ./ --merge --no_open",'$MG:color:GREEN')
        logger.info(" > For \"diagrams_text\", you can also specify a directory, --no_open, and --merge.")
        logger.info("   Add --merge to merge all .txt files into all_diagrams_text.txt (directory required).")
        logger.info("   Example: display diagrams_text ./ --merge --no_open",'$MG:color:GREEN')


    def help_launch(self):
        """help for launch command"""
        # Using the built-in parser help is not convenient when one wants to use
        # color schemes.
        #_launch_parser.print_help()
        logger.info("syntax: launch <dir_path> <options>",'$MG:color:BLUE')
        logger.info("-- execute the aMC@NLO/madevent/standalone/pythia8 output present in dir_path",'$MG:BOLD')
        logger.info("By default, dir_path points to the last created directory.")
        logger.info("(for pythia8, it should be the Pythia 8 main directory)")
        logger.info("")
        logger.info("Launch on madevent/pythia8/standalone outputs:",'$MG:BOLD')
        logger.info(" o Example: launch PROC_sm_1 --name=run2",'$MG:color:GREEN')
        logger.info(" o Example: launch ../pythia8",'$MG:color:GREEN')
        logger.info(" > Options:")
        logger.info("     -h, --help            show this help message and exit")
        logger.info("     -f, --force           Use the card present in the directory in order")
        logger.info("                           to launch the different program")
        logger.info("     -n NAME, --name=NAME  Provide a name to the run (for madevent run)")
        logger.info("     -c, --cluster         submit the job on the cluster")
        logger.info("     -m, --multicore       submit the job on multicore core")
        logger.info("     -i, --interactive     Use Interactive Console [if available]")
        logger.info("     -s LASTSTEP, --laststep=LASTSTEP")
        logger.info("                           last program run in MadEvent run.")
        logger.info("                           [auto|parton|pythia|pgs|delphes]")
        logger.info("")
        logger.info("Launch on MadLoop standalone output:",'$MG:BOLD')
        logger.info(" o Example: launch PROC_loop_sm_1 -f",'$MG:color:GREEN')
        logger.info(" > Simple check of a single Phase-space points.")
        logger.info(" > You will be asked whether you want to edit the MadLoop ")
        logger.info("   and model param card as well as the PS point, unless ")
        logger.info("   the -f option is specified. All other options are ")
        logger.info("   irrelevant for this kind of launch.")
        logger.info("")
        logger.info("Launch on standalone output with timing analysis:",'$MG:BOLD')
        logger.info(" o Example: launch PROC_sm_1 --timings=1000 --nb_run=5",'$MG:color:GREEN')
        logger.info(" > --timings=N   Number of SMATRIX calls per flavor per run (enables timing mode)")
        logger.info(" > --nb_run=Y    Number of timing repetitions (default: 1)")
        logger.info(" > Prints a table with flavor index, average time and 1-sigma uncertainty.")
        logger.info(" o Example: launch PROC_sm_1 --timings=100 --nb_run=0",'$MG:color:GREEN')
        logger.info(" > --nb_run=0  Masking check: skip the timing table and instead")
        logger.info("                print the matrix-element value per flavor after N SMATRIX calls.")
        logger.info("")
        logger.info("Launch on FKS Born building-block standalone output (output standalone_fortran --fks):",'$MG:BOLD')
        logger.info(" o Example: launch PROC_FKS_sm_0 --energy=500",'$MG:color:GREEN')
        logger.info(" > Builds and runs 'check_fks', printing the Born, spin-correlated Born")
        logger.info("   and color/charge-linked Borns for one phase-space point.")
        logger.info(" > You will be asked whether you want to edit the param_card, unless")
        logger.info("   the -f option is specified.")
        logger.info(" > --energy=E   sqrt(s) of the phase-space point (default: built-in)")
        logger.info(" > --timings=N --nb_run=Y   time N Born re-evaluations over Y runs")
        logger.info(" > If the output was made with --limits, also builds and runs the")
        logger.info("   soft/collinear limit test (test_soft_col_limits) and reports whether")
        logger.info("   it passed; the beams/energy are read from the run_card.")
        logger.info("")
        logger.info("Launch on aMC@NLO output:",'$MG:BOLD')
        logger.info(" > launch <dir_path> <mode> <options>",'$MG:color:BLUE')
        logger.info(" o Example: launch MyProc aMC@NLO -f -p",'$MG:color:GREEN')

    def help_tutorial(self):
        logger.info("syntax: tutorial [NAME|list|status|stop]",'$MG:color:BLUE')
        logger.info("-- with no argument, choose a tutorial from a menu")
        for tutorial in tutorials.all_tutorials():
            logger.info("-- %-11s %s" % (tutorial.name, tutorial.description))
        logger.info("-- list        show the tutorials without starting one")
        logger.info("-- status      show how far you are in the running tutorial")
        logger.info("-- stop        leave tutorial mode")
        logger.info("-- help        the commands a running tutorial understands")
        logger.info("   (while one runs: hint, solution, next, repeat, back, skip)")

    def help_open(self):
        logger.info("syntax: open FILE  ",'$MG:color:BLUE')
        logger.info("-- open a file with the appropriate editor.",'$MG:BOLD')
        logger.info('   If FILE belongs to index.html, param_card.dat, run_card.dat')
        logger.info('   the path to the last created/used directory is used')
        logger.info('   The program used to open those files can be chosen in the')
        logger.info('   configuration file ./input/mg7_configuration.txt')

    def help_explain_restriction(self):
        logger.info("syntax: explain_restriction [PATH|MODEL-RESTRICTION]",'$MG:color:BLUE')
        logger.info("--  Report what a restriction card removes from a model.",'$MG:BOLD')
        logger.info("    Without argument the card the current model was loaded with,")
        logger.info("    otherwise the path of a card or a name such as 'sm-ckm'.")
        logger.info("    Every parameter the card sets to zero/one, and every family of")
        logger.info("    parameters it sets to a common value, is applied alone to say")
        logger.info("    which couplings it -and it only- is responsible for.")
        logger.info("    --all lists every coupling instead of the first few of them.")

    def help_customize_model(self):
        logger.info("syntax: customize_model --save=NAME",'$MG:color:BLUE')
        logger.info("--  Open an invite where you options to tweak the model.",'$MG:BOLD')
        logger.info("    On top of the options specific to the model, you can choose the")
        logger.info("    flavour scheme (3F/4F/5F), the number of massive leptons, and set")
        logger.info("    a parameter to zero/one/to the value of another parameter.")
        logger.info("    If you specify the option --save=NAME, this tweak will be")
        logger.info("    available for future import with the command 'import model XXXX-NAME'")
        logger.info("    Changing the formula of a parameter/coupling is also possible but")
        logger.info("    requires to write a new UFO model (and is not compatible with --save)")
        logger.info("    --explain=life (the default) reports what each command you")
        logger.info("    enter changes in the model, --explain=final reports which of your")
        logger.info("    choices is responsible for each coupling removed from it,")
        logger.info("    --explain=off asks for no report at all.")
        logger.info("    --all lists every coupling instead of the first few of them.")

    def help_output(self):
        logger.info("syntax: output [" + "|".join(self._export_formats) + \
                    "] [path|.|auto] [options]",'$MG:color:BLUE')
        logger.info("-- Output any generated process(es) to file.",'$MG:BOLD')
        logger.info("   Default mode is madevent. Default path is \'.\' or auto.")
        logger.info("   mode:",'$MG:BOLD')
        logger.info("   - For MadLoop and aMC@NLO runs, there is only one mode and")
        logger.info("     it is set by default.")
        logger.info("   - For an NLO process, 'standalone_fortran --fks' writes the FKS Born")
        logger.info("     building blocks (Born, spin-correlated and color/charge-linked Borns)")
        logger.info("     with a light 'check_fks' driver; adding '--limits' also keeps the")
        logger.info("     real-emission code so that 'launch' runs the soft/collinear limit test.")
        logger.info("   - If mode is madevent, create a MadEvent process directory.")
        logger.info("   - If mode is standalone, create a Standalone directory")
        logger.info("     using the MadMatrix (C++/CUDA) matrix elements.")
        logger.info("   - If mode is standalone_fortran, create a Fortran Standalone directory")
        logger.info("   - If mode is matrix, output the matrix.f files for all")
        logger.info("     generated processes in directory \"path\".")
        logger.info("   - If mode is pythia8, output all files needed to generate")
        logger.info("     the processes using Pythia 8. The files are written in")
        logger.info("     the Pythia 8 directory (default).")
        logger.info("     NOTE: The Pythia 8 directory is set in the ./input/mg7_configuration.txt")
        logger.info("   - If mode is aloha: Special syntax output:")
        logger.info("     syntax: aloha [ROUTINE] [--options]" )
        logger.info("     valid options for aloha output are:")
        logger.info("      --format=Fortran|Python|Cpp : defining the output language")
        logger.info("      --output= : defining output directory")
        logger.info("   path: The path of the process directory.",'$MG:BOLD')
        logger.info("     If you put '.' as path, your pwd will be used.")
        logger.info("     If you put 'auto', an automatic directory PROC_XX_n will be created.")
        logger.info("   options:",'$MG:BOLD')
        logger.info("      -f: force cleaning of the directory if it already exists")
        logger.info("      -d: specify other MG/ME directory")
        logger.info("      -noclean: no cleaning performed in \"path\".")
        logger.info("      -nojpeg: no jpeg diagrams will be generated.")
        logger.info("      --noeps=True: no jpeg and eps diagrams will be generated.")
        logger.info("      -name: the postfix of the main file in pythia8 mode.")
        logger.info("      --jamp_optim=[True|False]: [madevent(default:True)|standalone_fortran(default:False)] allows a more efficient code computing the color-factor.")
        logger.info("      --jamp_orbit=[True|False]: [madevent|standalone_fortran|mg7] look for the shared color-factor sub-expressions by whole orbits of the color basis symmetry.")
        logger.info("      --t_strategy: [madevent] allows to change ordering strategy for t-channel.")
        logger.info("      --hel_recycling=False: [madevent] forbids helicity recycling optimization")
        logger.info("      --axial_gauge=True: [madevent|standalone_fortran] build the polarisation of massless vectors in the axial gauge of another external (lightlike) leg, so that whole diagrams vanish (default:False).")
        logger.info("      --mask=False: [madevent|standalone_fortran] disable flavor-mask optimization for grouped/merged flavors (default:True).")
        logger.info("      --prefix=int|proc: [standalone_fortran] prefix matrix-element routine names (int: M<n>_, proc: process name); generates f2py python-linkable routines.")
        logger.info("      --zerowidth_tchannel=[True|False]: [standalone_fortran(default:False)|standalone_rw/msP/msF(default:True)] set the t-channel widths to zero as madevent (see option zerowidth_tchannel)")
        logger.info("      --zerowidth_decay=True|False|<pdg>,<pdg>: [standalone_fortran] write the propagators of the final-state particles (of the decaying particle in a 1>N decay) with a zero width; a pdg list restricts to those.")
        logger.info("   Examples:",'$MG:color:GREEN')
        logger.info("       output",'$MG:color:GREEN')
        logger.info("       output standalone_fortran MYRUN -f",'$MG:color:GREEN')
        logger.info("       output pythia8 ../pythia8/ -name qcdprocs",'$MG:color:GREEN')

    def help_check(self):
        logger.info("syntax: check [" + "|".join(self._check_opts) + "] [param_card] process_definition [--energy=] [--split_orders=] [--reduction=]",'$MG:color:BLUE')
        logger.info("-- check a process or set of processes.",'$MG:BOLD')
        logger.info("General options:",'$MG:BOLD')
        logger.info("o full:",'$MG:color:GREEN')
        logger.info("   Perform all four checks described below:")
        logger.info("   permutation, brs, gauge and lorentz_invariance.")
        logger.info("   If the model uses flavor grouping (merged particles),")
        logger.info("   the flavor check is also performed automatically.")
        logger.info("o permutation:",'$MG:color:GREEN')
        logger.info("   Check that the model and MG5 are working properly")
        logger.info("   by generating permutations of the process and checking")
        logger.info("   that the resulting matrix elements give the same value.")
        logger.info("o gauge:",'$MG:color:GREEN')
        logger.info("   Check that processes are gauge invariant by ")
        logger.info("   comparing Feynman and unitary gauges.")
        logger.info("   This check is, for now, not available for loop processes.")
        logger.info("o brs:",'$MG:color:GREEN')
        logger.info("   Check that the Ward identities are satisfied if the ")
        logger.info("   process has at least one massless gauge boson as an")
        logger.info("   external particle.")
        logger.info("o lorentz_invariance:",'$MG:color:GREEN')
        logger.info("   Check that the amplitude is lorentz invariant by")
        logger.info("   comparing the amplitiude in different frames")
        logger.info("o flavor:",'$MG:color:GREEN')
        logger.info("   Check that the flavor-merged matrix element agrees with")
        logger.info("   the individual-flavor matrix elements computed without")
        logger.info("   flavor grouping at the same phase-space point.")
        logger.info("   This is useful to validate the merged-flavor method.")
        logger.info("o language:",'$MG:color:GREEN')
        logger.info("   Cross-check the matrix element by comparing the Python,")
        logger.info("   Fortran standalone (SA), and C++ standalone (SA) back-ends")
        logger.info("   at the same phase-space point.  Requires gfortran / g++.")
        logger.info("   Example: check language p p > e+ e-",'$MG:color:GREEN')
        logger.info("o precision:",'$MG:color:GREEN')
        logger.info("   syntax: check precision m|f|v [m|f|v ...] process_definition [--nb_event=X] [--energy=] [--backend=]")
        logger.info("   Evaluate the madmatrix standalone output built in each of the given")
        logger.info("   floating point modes (m: colour algebra in single precision,")
        logger.info("   f: single precision everywhere, v: single precision amplitudes")
        logger.info("   with double precision momenta and denominators) against its")
        logger.info("   double precision build, on the same X RAMBO phase-space points")
        logger.info("   (default 10^6). Reports the mean and maximum relative error and")
        logger.info("   the rate of events with an error above 1%, the time spent in the")
        logger.info("   matrix element by each of the two builds (and the speed-up), and")
        logger.info("   writes a plot of the difference. Requires g++ and make.")
        logger.info("   Several modes share one double precision reference and one plot.")
        logger.info("   --backend selects the madmatrix BACKEND of every build (default auto:")
        logger.info("   the widest SIMD flavour of the host): %s." % '|'.join(process_checks.PRECISION_BACKENDS))
        logger.info("   Example: check precision f m v g g > t t~ g --nb_event=100000",'$MG:color:GREEN')
        logger.info("o cms:",'$MG:color:GREEN')
        logger.info("   Check the complex mass scheme consistency by comparing")
        logger.info("   it to the narrow width approximation in the off-shell")
        logger.info("   region of detected resonances and by progressively")
        logger.info("   decreasing the width. Additional options for this check are:")
        logger.info("    --offshellness=f : f is a positive or negative float specifying ")
        logger.info("      the distance from the pole as f*particle_mass. Default is 10.0")
        logger.info("    --seed=i : to force a specific RNG integer seed i (default is fixed to 0)")
        logger.info("    --cms=order1&order2;...,p1->f(p,lambdaCMS)&p2->f2(p,lambdaCMS);...")
        logger.info("      'order_i' specifies the expansion orders considered for the test.")
        logger.info("      The substitution lists specifies how internal parameter must be modified")
        logger.info("      with the width scaling 'lambdaCMS'. The default value for this option is:")
        logger.info("        --cms=QED&QCD,aewm1->10.0/lambdaCMS&as->0.1*lambdaCMS ")
        logger.info("      The number of order and parameters don't have to be the same.")
        logger.info("      The scaling must be specified so that one occurrence of the coupling order.")
        logger.info("      brings in exactly one power of lambdaCMS.")
        logger.info("    --recompute_width= never|first_time|always|auto")
        logger.info("      Decides when to use MadWidth to automatically recompute the width")
        logger.info("      'auto' (default) let MG5 chose the most appropriate behavior.")
        logger.info("      'never' uses the default width value for lambdaCMS=1.0.")
        logger.info("      'first_time' uses MadWidth to compute the width for lambdaCMS=1.0.")
        logger.info("      'first_time' and 'never' assume linear scaling of the widths with lambdaCMS")
        logger.info("      'always' uses MadWidth to compute the widths for all values of lambdaCMS")
        logger.info("               the test relies on linear scaling of the width, so 'always' is ")
        logger.info("               only for double-checks")
        logger.info("    --lambdaCMS = <python_list> : specifies the list of lambdaCMS values to ")
        logger.info(r"      use for the test. For example: '[(1/2.0)**exp\ for\ exp\ in\ range(0,20)]'")
        logger.info("      In the list expression, you must escape spaces. Also, this option")
        logger.info("      *must* appear last in the option list. Finally, the default value is '1.0e-6'")
        logger.info("      for which an optimal list of progressive values is picked up to 1.0e-6")
        logger.info("    --show_plot = True or False: Whether to show plot during analysis (default is True)")
        logger.info("    --report = concise or full: Whether return a concise or full report.")
        logger.info("Comments",'$MG:color:GREEN')
        logger.info(" > If param_card is given, that param_card is used ")
        logger.info("   instead of the default values for the model.")
        logger.info("   If that file is an (LHE) event file. The param_card of the banner")
        logger.info("   is used and the first event compatible with the requested process")
        logger.info("   is used for the computation of the square matrix elements")
        logger.info(" > \"--energy=\" allows to change the default value of sqrt(S).")
        logger.info(" > Except for the 'gauge' test, all checks above are also")
        logger.info("   available for loop processes with ML5 ('virt=' mode)")
        logger.info("Example: check full p p > j j",'$MG:color:GREEN')
        logger.info("Using leshouches file as input",'$MG:color:GREEN')
        logger.info("    use the option --events=PATH")
        logger.info("      zipped file are not supported")
        logger.info("      to loop over the file use the option --skip_evt=X")
        logger.info("")
        logger.info("Options for loop processes only:",'$MG:BOLD')
        logger.info("o timing:",'$MG:color:GREEN')
        logger.info("   Generate and output a process and returns detailed")
        logger.info("   information about the code and a timing benchmark.")
        logger.info("o stability:",'$MG:color:GREEN')
        logger.info("   Generate and output a process and returns detailed")
        logger.info("   statistics about the numerical stability of the code.")
        logger.info("o profile:",'$MG:color:GREEN')
        logger.info("   Performs both the timing and stability analysis at once")
        logger.info("   and outputs the result in a log file without prompting")
        logger.info("   it to the user.")
        logger.info("Comments",'$MG:color:GREEN')
        logger.info(" > These checks are only available for ML5 ('virt=' mode)")
        logger.info(" > For the 'profile' and 'stability' checks, you can chose")
        logger.info("   how many PS points should be used for the statistic by")
        logger.info("   specifying it as an integer just before the [param_card]")
        logger.info("   optional argument.")
        logger.info(" > Notice multiparticle labels cannot be used with these checks.")
        logger.info(" > \"--reduction=\" allows to change what reduction methods should be used.")
        logger.info(" > TIRust: --reduction=9, --tirust_cache=-1, --tirust_cache_max_bytes=268435456.")
        logger.info(" > --loop_pole_mode=-1|0|1|2|3 selects legacy/both/UV/IR/no poles.")
        logger.info(" > --tirust_finite=false is reserved for tensor diagnostics; amplitude checks require finite results.")
        logger.info(" > \"--split_orders=\" allows to change what specific combination of coupling orders to consider.")
        logger.info(" > For process syntax, please see help generate.")
        logger.info(" > In order to save the directory generated or the reuse an existing one")
        logger.info("   previously generated with the check command, one can add the '-reuse' ")
        logger.info("   keyword just after the specification of the type of check desired.")
        logger.info("Example: check profile g g > t t~ [virt=QCD]",'$MG:color:GREEN')


    def help_generate(self):

        logger.info("-- generate diagrams for a given process",'$MG:color:BLUE')
        logger.info("General leading-order syntax:",'$MG:BOLD')
        logger.info(" o generate INITIAL STATE > REQ S-CHANNEL > FINAL STATE $ EXCL S-CHANNEL / FORBIDDEN PARTICLES COUP1=ORDER1 COUP2^2=ORDER2 @N")
        logger.info(" o Example: generate l+ vl > w+ > l+ vl a $ z / a h QED<=3 QCD=0 @1",'$MG:color:GREEN')
        logger.info(" > Alternative required s-channels can be separated by \"|\":")
        logger.info("   b b~ > W+ W- | H+ H- > ta+ vt ta- vt~")
        logger.info(" > If no coupling orders are given, MG5 will try to determine")
        logger.info("   orders to ensure maximum number of QCD vertices.")
        logger.info(" > Desired coupling orders combination can be specified directly for")
        logger.info("   the squared matrix element by appending '^2' to the coupling name.")
        logger.info("   For example, 'p p > j j QED^2==2 QCD^2==2' selects the QED-QCD")
        logger.info("   interference terms only. The other two operators '<=' and '>' are")
        logger.info("   supported. Finally, a negative value COUP^2==-I refers to the")
        logger.info("   N^(-I+1)LO term in the expansion of the COUP order.")
        logger.info(" > allowed coupling operator are: \"==\", \"=\", \"<=\" and \">\".")
        logger.info("    \"==\" request exactly that number of coupling while \"=\" is interpreted as \"<=\".")
        logger.info(" > To generate a second process use the \"add process\" command")
        logger.info("Decay chain syntax:",'$MG:BOLD')
        logger.info(" o core process, decay1, (decay2, (decay2', ...)), ...  etc")
        logger.info(" o Example: generate p p > t~ t QED=0, (t~ > W- b~, W- > l- vl~), t > j j b @2",'$MG:color:GREEN')
        logger.info(" > Note that identical particles will all be decayed.")
        logger.info("Polarized process syntax:",'$MG:BOLD')
        logger.info(" > Fix the helicity polarizations of external particles (massless or massive) or massive internal particles")
        logger.info("   before decay chain by adding '{X}' to (multi)particles in process definitions.")
        logger.info(" > Example: generate t{L} > w+{T} b{R}, w+ > ta+ vt",'$MG:color:GREEN')
        logger.info(" > For further help, see 'help polarization'")
        logger.info("Loop processes syntax:",'$MG:BOLD')
        logger.info(" o core process [ <NLO_mode=> LoopOrder1 LoopOrder2 ... ] SQUAREDCOUPi=ORDERi")
        logger.info(" o Example: generate p p > t~ t QED=0 QCD=2 [ all= QCD ] QCD=6",'$MG:color:GREEN')
        logger.info(" > Notice that in this format, decay chains are not allowed.")
        logger.info(" > The LoopOrder(s) defined specify the kind of loops to consider (only QCD for now).")
        logger.info(" > The coupling restrictions before '[' restrict the orders of born *amplitudes*.")
        logger.info("   So that in the example above QCD=2 restricts the born amplitude to have at")
        logger.info("   most QCD=2 and loop amplitudes at most QCD=2+2 (because QCD loops are considered)")
        logger.info(" > The coupling restrictions after ']' restrict the orders of the matrix element, ")
        logger.info("   namely the squared amplitudes. In the example above QCD=6 correspond to born")
        logger.info("   amplitudes with QCD=2 squared against loop amplitudes with QCD=4, adding up to 6.")
        logger.info(" > The optional <NLO_mode=> can be any of the following ('all=' by default if absent):")
        logger.info("     all=   : Generate all the real-emission and loop diagrams, ready for aMC@NLO runs.")
        logger.info("     virt=  : Generate only the loop diagrams, read for MadLoop standalone checks/runs.")
        logger.info("     real=  : Generate only the real-emission diagrams, for use with alternative OLP. ")
        logger.info(" > For processes without born amplitudes (i.e. loop-induced like g g > z), please use ")
        logger.info("   the 'virt=' NLO mode. aMC@NLO cannot integrate these processes, but standalone MadLoop5")
        logger.info("   can still handle these.")
        self._log_interference_syntax()
        self._log_diagram_filter_syntax()

    def _log_diagram_filter_syntax(self):
        """The diagram filter options, for 'help generate' and 'help add'."""
        logger.info("Diagram filter syntax:",'$MG:BOLD')
        logger.info(" o process --diagram_filter=PLUGINNAME")
        logger.info(" o NLO process [QCD] --tree_diagram_filter=PLUGINNAME --loop_diagram_filter=PLUGINNAME")
        logger.info(" o Example: generate u u~ > d d~ QED=2 --diagram_filter=no_photon",'$MG:color:GREEN')
        logger.info(" > Removes the diagrams for which the function new_diagram_filter of the plugin")
        logger.info("   PLUGINNAME (in its __init__.py) returns True. It is called as")
        logger.info("   new_diagram_filter(diagram, model).")
        logger.info(" > --diagram_filter applies to tree-level and MadLoop ([virt=], [noborn=])")
        logger.info("   processes, to the Born and the loop diagrams. For NLO processes with FKS")
        logger.info("   subtraction, --tree_diagram_filter filters the Born and real-emission")
        logger.info("   diagrams and --loop_diagram_filter the loop diagrams of the virtual.")
        logger.info(" > Without =PLUGINNAME, the function remove_diag of PLUGIN/user_filter.py is used.")
        logger.info(" > Removing diagrams usually breaks gauge invariance.")
        logger.info(" > See the 'Diagram filters' page of the documentation.")

    def _log_interference_syntax(self):
        """The interference syntax, for 'help generate' and 'help add'."""
        logger.info("Interference syntax:",'$MG:BOLD')
        logger.info(" o left process [LIxtree=LoopOrders] SQUAREDCOUPi=ORDERi right process")
        logger.info(" o left process [treextree] SQUAREDCOUPi=ORDERi right process")
        logger.info(" o Example: generate g g > h > t t~ [LIxtree=QCD] g g > t t~",'$MG:color:GREEN')
        logger.info(" o Example: generate p p > z > e+ e- [treextree] p p > a > e+ e-",'$MG:color:GREEN')
        logger.info(" > Only the interference 2 Re(A_left A_right^*) is computed. The left process is")
        logger.info("   a loop-induced process for LIxtree, a tree-level one for treextree; the right")
        logger.info("   process is always tree level. The keywords are case-insensitive.")
        logger.info(" > Each side takes its own s-channel requirements, exclusions and amplitude orders.")
        logger.info("   Squared-order constraints apply to the interference: give them right after ']'.")
        logger.info(" > Both sides must have the same external legs, in the same order (the right-hand")
        logger.info("   legs may be wider multiparticles). For LIxtree the right process is optional:")
        logger.info("   by default it is the tree-level process with the same legs.")
        logger.info(" > 'output' (mg7) and 'output madevent' integrate the interference (events with")
        logger.info("   signed weights); 'output standalone' and 'output standalone_fortran' evaluate")
        logger.info("   it at a phase-space point. LIxtree needs a loop backend: 'output madevent' or")
        logger.info("   'output standalone_fortran' only.")

    def help_add(self):
        logger.info("-- generate diagrams for a process and add to existing processes",'$MG:color:BLUE')
        logger.info("   OR merge two model",'$MG:color:BLUE')
        logger.info('')
        logger.info("-- generate diagrams for a process and add to existing processes",'$MG:color:BLUE')
        logger.info("General leading-order syntax:",'$MG:BOLD')
        logger.info(" o add process INITIAL STATE > REQ S-CHANNEL > FINAL STATE $ EXCL S-CHANNEL / FORBIDDEN PARTICLES COUP1=ORDER1 COUP2=ORDER2 @N")
        logger.info(" o Example: add process l+ vl > w+ > l+ vl a $ z / a h QED=3 QCD=0 @1",'$MG:color:GREEN')
        logger.info(" > Alternative required s-channels can be separated by \"|\":")
        logger.info("   b b~ > W+ W- | H+ H- > ta+ vt ta- vt~")
        logger.info(" > If no coupling orders are given, MG5 will try to determine")
        logger.info("   orders to ensure maximum number of QCD vertices.")
        logger.info(" > Note that if there are more than one non-QCD coupling type,")
        logger.info("   coupling orders need to be specified by hand.")
        logger.info("Decay chain syntax:",'$MG:BOLD')
        logger.info(" o core process, decay1, (decay2, (decay2', ...)), ...  etc")
        logger.info(" o Example: add process p p > t~ t QED=0, (t~ > W- b~, W- > l- vl~), t > j j b @2",'$MG:color:GREEN')
        logger.info(" > Note that identical particles will all be decayed.")
        logger.info("Polarized process syntax:",'$MG:BOLD')
        logger.info(" > Fix the helicity polarizations of external particles (massless or massive) or massive internal particles")
        logger.info("   before decay chain by adding '{X}' to (multi)particles in process definitions.")
        logger.info(" > Example: add process t{L} > w+{T} b{R}, w+ > ta+ vt",'$MG:color:GREEN')
        logger.info(" > For further help, see 'help polarization'")
        logger.info("Loop processes syntax:",'$MG:BOLD')
        logger.info(" o core process [ <NLO_mode=> LoopOrder1 LoopOrder2 ... ] SQUAREDCOUPi=ORDERi")
        logger.info(" o Example: add process p p > t~ t QED=0 QCD=2 [ all= QCD ] QCD=6",'$MG:color:GREEN')
        logger.info(" > Notice that in this format, decay chains are not allowed.")
        logger.info(" > The LoopOrder(s) defined specify the kind of loops to consider (only QCD for now).")
        logger.info(" > The coupling restrictions before '[' restrict the orders of born *amplitudes*.")
        logger.info("   So that in the example above QCD=2 restricts the born amplitude to have at")
        logger.info("   most QCD=2 and loop amplitudes at most QCD=2+2 (because QCD loops are considered)")
        logger.info(" > The coupling restrictions after ']' restrict the orders of the matrix element, ")
        logger.info("   namely the squared amplitudes. In the example above QCD=6 correspond to born")
        logger.info("   amplitudes with QCD=2 squared against loop amplitudes with QCD=4, adding up to 6.")
        logger.info(" > The optional <NLO_mode=> can be any of the following ('all=' by default if absent):")
        logger.info("     all=   : Generate all the real-emission and loop diagrams, ready for aMC@NLO runs.")
        logger.info("     virt=  : Generate only the loop diagrams, read for MadLoop standalone checks/runs.")
        logger.info("     real=  : Generate only the real-emission diagrams, for use with alternative OLP. ")
        logger.info(" > For processes without born amplitudes (i.e. loop-induced like g g > z), please use ")
        logger.info("   the 'virt=' NLO mode. aMC@NLO cannot integrate these processes, but standalone MadLoop5")
        logger.info("   can still handle these.")
        self._log_interference_syntax()
        self._log_diagram_filter_syntax()

        logger.info("--  merge two model to create a new one", '$MG:color:BLUE')
        logger.info("syntax:",'$MG:BOLD')
        logger.info(" o add model MODELNAME [OPTIONS]")
        logger.info(" o Example: add model taudecay",'$MG:color:GREEN')
        logger.info(" > Merge the two model in a single one. If that same merge was done before.")
        logger.info(" > Just reload the previous merge. (WARNING: This doesn't check if those model are modified)")
        logger.info(" > Options:")
        logger.info("   --output=  : Specify the name of the directory where the merge is done.")
        logger.info("                This allow to do \"import NAME\" to load that merge.")
        logger.info("   --recreate : Force to recreated the merge model even if the merge model directory already exists.")
        logger.info("   --fock_states_only : only add the Fock states (bound states) of MODELNAME to the current model,")
        logger.info("                        e.g. 'import model heft' then 'add model sm_onia --fock_states_only'.")
        
    def help_convert(self):
        logger.info("syntax: convert model FULLPATH")
        logger.info("modify (in place) the UFO model to make it compatible with both python2 and python3")
        
    def help_compute_widths(self):
        logger.info("syntax: calculate_width PART [other particles] [OPTIONS]")
        logger.info("  Computes the width and partial width for a set of particles")
        logger.info("  Returns a valid param_card with this information.")
        logger.info(" ")
        logger.info("  PART: name of the particle you want to calculate width")
        logger.info("        you can enter either the name or pdg code.\n")
        logger.info("  Various options:\n")
        logger.info("  --body_decay=X: Parameter to control the precision of the computation")
        logger.info("        if X is an integer, we compute all channels up to X-body decay.")
        logger.info("        if X <1, then we stop when the estimated error is lower than X.")
        logger.info("        if X >1 BUT not an integer, then we X = N + M, with M <1 and N an integer")
        logger.info("              We then either stop at the N-body decay or when the estimated error is lower than M.")
        logger.info("        default: 4.0025")
        logger.info("  --min_br=X: All channel which are estimated below this value will not be integrated numerically.")
        logger.info("        default: precision (decimal part of the body_decay options) divided by four")
        logger.info("  --precision_channel=X: requested numerical precision for each channel")
        logger.info("        default: 0.01")
        logger.info("  --path=X: path for param_card")
        logger.info("        default: take value from the model")
        logger.info("  --output=X: path where to write the resulting card. ")
        logger.info("        default: overwrite input file. If no input file, write it in the model directory")
        logger.info("  --nlo: Compute the NLO width. With the dedicated code of the model")
        logger.info("        (SMWidth, for the SM: QCD and EW) when it has one. Otherwise the two-body")
        logger.info("        decays that have a colour charge are run at NLO in QCD with MC@NLO (it")
        logger.info("        needs a model with loop information; sm uses loop_sm) and the decays into")
        logger.info("        three bodies or more stay at LO: --nlo --body_decay=3 is the two-body")
        logger.info("        decays at NLO and the three-body ones at LO, --body_decay=2 the two-body")
        logger.info("        decays only. --nlo=smwidth or --nlo=mcatnlo chooses the code.")
        logger.info("  --corrections=X: corrections of the MC@NLO runs: QCD (default), QED (the")
        logger.info("        electroweak corrections, EW is accepted) or QCD+QED. The electroweak ones")
        logger.info("        are for every two-body decay, not only the coloured ones, and need a")
        logger.info("        model with loop information (loop_qcd_qed_sm).")
        logger.info("  --engine=X: integrator of the N-body decays (N>2): madspace or madevent")
        logger.info("        default: madspace (the phase-space library of the mg7 output, with madevent")
        logger.info("        as fallback when it is unusable). madevent is the Fortran integration of the")
        logger.info("        former releases; it is the only one for the complex mass scheme.")
        logger.info("")
        logger.info("  In a param_card, a width set to auto takes the same options:")
        logger.info("        DECAY 6 auto --nlo --body_decay=3   (DECAY 6 auto@NLO is 'auto --nlo')")
        logger.info("")
        logger.info(" example: calculate_width h --body_decay=2 --output=./param_card")

    def help_decay_diagram(self):
        logger.info("syntax: decay_diagram PART [other particles] [OPTIONS]")
        logger.info("  Returns the amplitude required for the computation of the widths")
        logger.info(" ")
        logger.info("  PART: name of the particle you want to calculate width")
        logger.info("        you can enter either the name or pdg code.\n")
        logger.info("  Various options:\n")
        logger.info("  --body_decay=X: Parameter to control the precision of the computation")
        logger.info("        if X is an integer, we compute all channels up to X-body decay.")
        logger.info("        if X <1, then we stop when the estimated error is lower than X.")
        logger.info("        if X >1 BUT not an integer, then we X = N + M, with M <1 and N an integer")
        logger.info("              We then either stop at the N-body decay or when the estimated error is lower than M.")
        logger.info("        default: 4.0025")
        logger.info("  --min_br=X: All channel which are estimated below this value will not be integrated numerically.")
        logger.info("        default: precision (decimal part of the body_decay options) divided by four")
        logger.info("  --precision_channel=X: requested numerical precision for each channel")
        logger.info("        default: 0.01")
        logger.info("  --path=X: path for param_card")
        logger.info("        default: take value from the model")
        logger.info("  --output=X: path where to write the resulting card. ")
        logger.info("        default: overwrite input file. If no input file, write it in the model directory")
        logger.info("")
        logger.info(" example: calculate_width h --body_decay=2 --output=./param_card")

    def help_define(self):
        logger.info("-- define a multiparticle",'$MG:color:BLUE')
        logger.info("Syntax:  define multipart_name [=] part_name_list")
        logger.info("Example: define p = g u u~ c c~ d d~ s s~ b b~",'$MG:color:GREEN')
        logger.info("Special syntax: Use | for OR (used for required s-channels)")
        logger.info("Special syntax: Use / to remove particles. Example: define q = p / g")

    def help_polarization(self):
        logger.info("Polarized process syntax:",'$MG:BOLD')
        logger.info(" > Fix the helicity polarizations of external particles (massless or massive) or massive internal particles")
        logger.info("   before decay chain by adding '{X}' to (multi)particles in process definitions.")
        logger.info(" > Example: generate t{L} > w+{T} b{R}, w+ > ta+ vt",'$MG:color:GREEN')
        logger.info(" > Example: generate p p > z{T} z{A}, z > e+ e-",'$MG:color:GREEN')
        logger.info(" > Example: generate p p > z{0} z{T}, z > e+ e-, z > mu+ mu-",'$MG:color:GREEN')
        logger.info(" > '{X}' is a *set* of helicities, so each helicity may be named at most once.")
        logger.info("   '{++}' is refused, and so is '{+T}' -- 'T' already covers +1 and -1.")
        logger.info(" > '{G}','{H}','{Q}','{W}','{S}' select a piece of the *propagator* of a massive vector")
        logger.info("   and are only valid on a particle that is decayed further (an internal line).")
        logger.info(" > At LO, users need to set 'group_subprocesses False' and 'me_frame' (run_card).")
        logger.info("   'nhel=1' is only a variance choice, not a requirement: it selects Monte-Carlo")
        logger.info("   over helicities, which is an unbiased estimator of the same cross-section.")
        logger.info(" > For the process 'p p > w+ z j j, w+ > l+ vl, z > l+ l-', the WZ rest frame is given by me_frame = [3,4,5,6]")
        logger.info("Polarization at NLO:",'$MG:BOLD')
        logger.info(" > A polarized massive particle needs a frame, so it is allowed for the NLO modes")
        logger.info("   that have one:")
        logger.info("     - [QCD], [real=QCD] and [LOonly=QCD] take 'me_frame' from the run_card.")
        logger.info("       QCD is the only perturbation order supported here so far: the boost")
        logger.info("       machinery is order-agnostic, but nothing in the QED sector has been")
        logger.info("       validated, so [QED] and mixed orders are still refused.")
        logger.info("     - [virt=QCD] and standalone MadLoop take the frame from the momenta the")
        logger.info("       caller supplies, so any perturbation order is allowed.")
        logger.info("   A polarized massless particle needs no frame and was always allowed.")
        logger.info(" > Colour, in [QCD]/[real=QCD]/[LOonly=QCD] only: a polarized coloured")
        logger.info("   particle must be in the FINAL state and must be massive.")
        logger.info("     - final state, massive: allowed. p p > t{+} t~{-} [QCD] -- the closure")
        logger.info("       and the FKS soft limit off the polarized top were measured.")
        logger.info("     - final state, massless: untested and refused, so a polarized gluon or")
        logger.info("       massless quark, and 'p'/'j', which contain one. Note this depends on")
        logger.info("       the model: b is massive in a 4-flavour scheme and massless in a")
        logger.info("       5-flavour one. The check reads the symbolic mass at generation time,")
        logger.info("       so setting a mass to zero in the param card afterwards is NOT")
        logger.info("       re-checked.")
        logger.info("     - INITIAL state: refused whatever the mass, so b{+} b~ > h [QCD] and")
        logger.info("       t{+} t~ > z [QCD] are both rejected. The initial-state splitting runs")
        logger.info("       backwards, g -> q(-> Born) q~, so the polarized parton is an internal")
        logger.info("       line of the real emission and no external leg can carry the")
        logger.info("       projection. A 1 -> N decay is exempt: its initial leg is never split,")
        logger.info("       so t{+} > w+ b [QCD] and h > b{+} b~ [QCD] are fine.")
        logger.info(" > Caveat, coloured polarized particle + single-leg 'me_frame': what was")
        logger.info("   measured is a two-leg frame, me_frame = [3,4]. A frame made of ONE leg")
        logger.info("   puts that leg exactly at rest, which is where HELAS picks the spin")
        logger.info("   quantisation axis by convention rather than from the momentum. That")
        logger.info("   combination is accepted but untested; prefer a frame of two or more legs.")
        logger.info(" > Example: generate p p > z{0} z{0} j [QCD]  with me_frame = [3,4]",'$MG:color:GREEN')
        logger.info(" > Example: generate p p > t{+} t~{-} [QCD]  with me_frame = [3,4]",'$MG:color:GREEN')
        logger.info(" > Both fixed-order (calculate_xsect) and NLO+PS event generation")
        logger.info("   (generate_events, i.e. MC@NLO matching) are supported: the MC")
        logger.info("   counterterms and the weights written to the LHE use the same frame as")
        logger.info("   the cross-section. The shower itself knows nothing about the frame, so")
        logger.info("   the polarised sample is defined by the hard process, as at LO.")
        logger.info(" > Define the frame from final-state particles only. A frame built from the")
        logger.info("   initial state is not infrared safe at NLO -- the real emission and the reduced")
        logger.info("   Born carry different momentum fractions even in the collinear limit -- and is")
        logger.info("   refused. me_frame = [1,2] names the partonic c.m. and is simply skipped.")
        logger.info(" > For further details, see appendices of [arXiv:1912.01725] and [arXiv:2512.10015],")
        logger.info("   and for possibilities with loop-induced processes, see [2401.17365].")
    
    def help_polarisation(self):
        logger.info("Polarized process syntax:",'$MG:BOLD')
        logger.info(" > See 'help polarization'")

    def help_set(self):
        logger.info("-- set options for generation or output.",'$MG:color:BLUE')
        logger.info("syntax: set <option_name> <option_value>",'$MG:BOLD')
        logger.info("Documented options are: \n", '$MG:BOLD')
        #options = [self._set_options[i*3:(i+1)*3] for i in \
        #                                  range((len(self._set_options)//4)+1)]
        doc_options = [name[5:] for name in dir(self) if name.startswith('set2_')]
        doc_options.sort()
        doc_options = [doc_options[i*3:(i+1)*3] for i in \
                                          range((len(doc_options)//3)+1)]
        for opts in doc_options:
            if len(opts)<3:
                    opts += ['']*(3-len(opts))
            mystr="%-35s\t%-35s\t%-25s" % (tuple(opts))
            logger.info(mystr)

            #logger.info("%30s"%('\t'.join(opts)))
        doc_options = sum(doc_options, [])
            
        logger.info("\nFor details for each option: please type: help set <option_name>\n ",'$MG:color:GREEN')
        
        logger.info("Undocumented options are: \n", '$MG:BOLD')

        options = self._set_options
        options += self.options_configuration.keys()
        options += self.options_madgraph.keys()
        options += self.options_madevent.keys()
        options = [opt for opt in options if not opt in doc_options]
        options = list(set(options))
        options.sort()
        options = [options[i*3:(i+1)*3] for i in \
                                          range((len(options)//3)+1)]
        for opts in options:
            if len(opts)<3:
                    opts += ['']*(3-len(opts))
            mystr="%-25s\t%-25s\t%-25s" % (tuple(opts))
            logger.info(mystr)

        #lo
        return
        logger.info("group_subprocesses True/False/Auto/gpu: ",'$MG:color:GREEN')
        logger.info(" > (default Auto) Smart grouping of subprocesses into ")
        logger.info("   directories, mirroring of initial states, and ")
        logger.info("   combination of integration channels.")
        logger.info(" > Example: p p > j j j w+ gives 5 directories and 184 channels",'$MG:BOLD')
        logger.info("   (cf. 65 directories and 1048 channels for regular output)",'$MG:BOLD')
        logger.info(" > Auto means False for decay computation and True for collisions.")
        logger.info("ignore_six_quark_processes multi_part_label",'$MG:color:GREEN')
        logger.info(" > (default none) ignore processes with at least 6 of any")
        logger.info("   of the quarks given in multi_part_label.")
        logger.info(" > These processes give negligible contribution to the")
        logger.info("   cross section but have subprocesses/channels.")
        logger.info("stdout_level DEBUG|INFO|WARNING|ERROR|CRITICAL",'$MG:color:GREEN')
        logger.info(" > change the default level for printed information")
        logger.info("fortran_compiler NAME",'$MG:color:GREEN')
        logger.info(" > (default None) Force a specific fortran compiler.")
        logger.info("   If None, it tries first g77 and if not present gfortran")
        logger.info("   but loop output use gfortran.")
        logger.info("loop_optimized_output True|False",'$MG:color:GREEN')
        logger.info(" > Exploits the open loop thechnique for considerable")
        logger.info("   improvement.")
        logger.info(" > CP relations among helicites are detected and the helicity")
        logger.info("   filter has more potential.")
        logger.info("loop_color_flows True|False",'$MG:color:GREEN')
        logger.info(" > Only relevant for the loop optimized output.")
        logger.info(" > Reduces the loop diagrams at the amplitude level")
        logger.info("   rendering possible the computation of the loop amplitude")
        logger.info("   for a fixed color flow or color configuration.")
        logger.info(" > This option can considerably slow down the loop ME")
        logger.info("   computation time, especially when summing over all color")
        logger.info("   and helicity configuration, hence turned off by default.")        
        logger.info("gauge unitary|Feynman|axial|FD",'$MG:color:GREEN')
        logger.info(" > (default unitary) choose the gauge of the non QCD part.")
        logger.info(" > FD is for Feynman Diagram gauge:     2203.10440 ")
        logger.info(" > For loop processes, only Feynman gauge is employable.")
        logger.info("complex_mass_scheme True|False",'$MG:color:GREEN')
        logger.info(" > (default False) Set complex mass scheme.")
        logger.info(" > Complex mass scheme is not yet supported for loop processes.")
        logger.info("include_lepton_initiated_processes True|False",'$MG:color:GREEN')
        logger.info(" > (default False) Do not include processes with leptons in the initial state (nlo gen. only).")
        logger.info("timeout VALUE",'$MG:color:GREEN')
        logger.info(" > (default 20) Seconds allowed to answer questions.")
        logger.info(" > Note that pressing tab always stops the timer.")
        logger.info("cluster_temp_path PATH",'$MG:color:GREEN')
        logger.info(" > (default None) [Used in Madevent Output]")
        logger.info(" > Allow to perform the run in PATH directory")
        logger.info(" > This allow to not run on the central disk. ")
        logger.info(" > This is not used by condor cluster (since condor has")
        logger.info("   its own way to prevent it).")
        logger.info("OLP ProgramName",'$MG:color:GREEN')
        logger.info(" > (default 'MadLoop') [Used for virtual generation]")
        logger.info(" > Chooses what One-Loop Program to use for the virtual")
        logger.info(" > matrix element generation via the BLAH accord.")
        logger.info("output_dependencies <mode>",'$MG:color:GREEN')
        logger.info(" > (default 'external') [Use for NLO outputs]")
        logger.info(" > Choses how the external dependences (such as CutTools)")
        logger.info(" > of NLO outputs are handled. Possible values are:")
        logger.info("     o external: Some of the libraries the output depends")
        logger.info("       on are links to their installation in MG5 root dir.")
        logger.info("     o internal: All libraries the output depends on are")
        logger.info("       copied and compiled locally in the output directory.")
        logger.info("     o environment_paths: The location of all libraries the ")
        logger.info("       output depends on should be found in your env. paths.")        
        logger.info("max_npoint_for_channel <value>",'$MG:color:GREEN')
        logger.info(" > (default '0') [Used ONLY for loop-induced outputs with madevent]")
        logger.info(" > Sets the maximum 'n' of n-points loops to be used for")
        logger.info(" > setting up the integration multichannels.") 
        logger.info(" > The default value of zero automatically picks the apparent")
        logger.info(" > appropriate choice which is to sometimes pick box loops")
        logger.info(" > but never higher n-points ones.")
        logger.info("max_t_for_channel <value>",'$MG:color:GREEN')
        logger.info(" > (default '0') [Used ONLY for tree-level output with madevent]")
        logger.info(" > Forbids the inclusion of channel of integration with more than X")
        logger.info(" > T channel propagators. Such channel can sometimes be quite slow to integrate")
        logger.info("zerowidth_tchannel <value>",'$MG:color:GREEN')
        logger.info(" > (default: True) [Used ONLY for tree-level output with madevent]")
        logger.info(" > set the width to zero for all T-channel propagator --no impact on complex-mass scheme mode")
        logger.info("auto_convert_model <value>",'$MG:color:GREEN')   
        logger.info(" > (default: False) If set on True any python2 UFO model will be automatically converted to pyton3 format")   
        logger.info("nlo_mixed_expansion <value>",'$MG:color:GREEN') 
        logger.info("deactivates mixed expansion support at NLO, goes back to MG5aMCv2 behavior")
        logger.info("acknowledged_v3.1_syntax <value>",'$MG:color:GREEN') 
        logger.info("if set to True allows to use syntax which have change meaning between 3.0 and 3.1 version")
          
#===============================================================================
# CheckValidForCmd
#===============================================================================
#===============================================================================
# customize_model --explain
#===============================================================================
# 'life' reports what each command does while the question is answered,
# 'final' reports which choice is responsible for what once it is closed,
# 'off' asks for no report at all. 'life' is what one gets without asking.
CUSTOMIZE_EXPLAIN_MODES = ['life', 'final', 'off']
CUSTOMIZE_EXPLAIN_DEFAULT = 'life'
CUSTOMIZE_EXPLAIN_ALIAS = {'live': 'life', # 'live' is the spelling one expects
                           'none': 'off', 'false': 'off', 'no': 'off'}


def natural_key(name):
    """sort GC_9 before GC_10"""

    return [int(part) if part.isdigit() else part
            for part in re.split(r'(\d+)', str(name))]


def parse_explain_mode(arg):
    """the mode of a --explain/--explain=MODE argument (None if arg is neither)"""

    if arg == '--explain':
        return 'life'
    if not arg.startswith('--explain='):
        return None
    mode = arg.split('=', 1)[1].lower()
    return CUSTOMIZE_EXPLAIN_ALIAS.get(mode, mode)


def resolve_explain_mode(args):
    """the --explain mode a customize_model command line asks for: the last
    --explain wins, the live report is what one gets without the option, and
    None (no report at all) is what --explain=off asks for."""

    mode = ([CUSTOMIZE_EXPLAIN_DEFAULT] + [parse_explain_mode(a) for a in args
                                           if parse_explain_mode(a)])[-1]
    return None if mode == 'off' else mode


class CheckValidForCmd(cmd.CheckCmd):
    """ The Series of help routine for the MadGraphCmd"""

    class RWError(MadGraph5Error):
        """a class for read/write errors"""

    def check_add(self, args):
        """check the validity of line
        syntax: add process PROCESS | add model MODELNAME
        """

        if len(args) < 2:
            self.help_add()
            raise self.InvalidCmd('\"add\" requires at least two arguments')
        
        if args[0] not in  ['model', 'process']:
            raise self.InvalidCmd('\"add\" requires the argument \"process\" or \"model\"')    
    
        if args[0] == 'process':
            return self.check_generate(args)
    
        if args[0] == 'model':
            pass
            

    def check_define(self, args):
        """check the validity of line
        syntax: define multipart_name [ part_name_list ]
        """

        if len(args) < 2:
            self.help_define()
            raise self.InvalidCmd('\"define\" command requires at least two arguments')

        if args[1] == '=':
            del args[1]
            if len(args) < 2:
                self.help_define()
                raise self.InvalidCmd('\"define\" command requires at least one particles name after \"=\"')

        if '=' in args:
            self.help_define()
            raise self.InvalidCmd('\"define\" command requires symbols \"=\" at the second position')

        if not self._curr_model:
            logger.info('No model currently active. Try with the Standard Model')
            self.do_import('model sm')

        if self._curr_model['particles'].find_name(args[0]):
            raise self.InvalidCmd("label %s is a particle name in this model\n\
            Please retry with another name." % args[0])

    def check_display(self, args):
        """check the validity of line
        syntax: display XXXXX
        """

        if len(args) < 1:
            self.help_display()
            raise self.InvalidCmd('display requires an argument specifying what to display')
        if args[0] not in self._display_opts + ['model_list']:
            self.help_display()
            raise self.InvalidCmd('Invalid arguments for display command: %s' % args[0])

        # the model list is what you read *before* importing one -- the banner
        # suggests it at startup -- and it lists model directories and the
        # online database, never the loaded model
        if not self._curr_model and args[0] not in ('modellist', 'model_list'):
            raise self.InvalidCmd("No model currently active, please import a model!")

        # check that either _curr_amps or _fks_multi_proc exists.
        # _fks_multi_proc is only created when an NLO process is generated, so
        # it is read with getattr: without it 'display processes' before any
        # process died with an AttributeError instead of saying so.
        if args[0] in ['processes', 'diagrams', 'diagrams_text'] and \
                not self._curr_amps and not getattr(self, '_fks_multi_proc', None):
            raise self.InvalidCmd("No process generated, please generate a process!")
        if args[0] == 'checks' and not self._comparisons and not self._cms_checks:
            raise self.InvalidCmd("No check results to display.")

        if args[0] == 'variable' and len(args) !=2:
            raise self.InvalidCmd('variable need a variable name')


    def check_draw(self, args):
        """check the validity of line
        syntax: draw DIRPATH
        the options have already been removed from args by _draw_parser
        """

        if len(args) < 1:
            args.append(tempdir.name)
        elif not os.path.isdir(args[0]):
            raise self.InvalidCmd( "%s is not a valid directory for export file" % args[0])

        if not self._curr_amps:
            raise self.InvalidCmd("No process generated, please generate a process!")

    def check_check(self, args):
        """check the validity of args"""

        if  not self._curr_model:
            raise self.InvalidCmd("No model currently active, please import a model!")

        if self._model_v4_path:
            raise self.InvalidCmd(\
                "\"check\" not possible for v4 models")

        if len(args) < 2 and not args[0].lower().endswith('options'):
            self.help_check()
            raise self.InvalidCmd("\"check\" requires a process.")

        if args[0] not in self._check_opts and \
                                        not args[0].lower().endswith('options'):
            args.insert(0, 'full')

        # check precision takes one or more floating point modes first
        precision_mode = None
        if args[0] == 'precision':
            modes = []
            while len(args) > 1 and args[1] in process_checks.PRECISION_MODES:
                modes.append(args.pop(1))
            if not modes or len(args) < 2:
                self.help_check()
                raise self.InvalidCmd("\"check precision\" requires at least one precision "
                        "mode (%s) and a process." % '|'.join(process_checks.PRECISION_MODES))
            # one token, and no ',' which would read as a decay chain below
            precision_mode = ':'.join(misc.make_unique(modes))

        param_card = None
        if args[0] not in ['stability','profile','timing'] and \
                                        len(args)>1 and os.path.isfile(args[1]):
            param_card = args.pop(1)

        if len(args)>1:
            if args[1] != "-reuse":
                args.insert(1, '-no_reuse')
        else:
            args.append('-no_reuse')

        if precision_mode:
            args.insert(2, precision_mode)

        if args[0] in ['timing'] and len(args)>2 and os.path.isfile(args[2]):
            param_card = args.pop(2)
        if args[0] in ['stability', 'profile'] and len(args)>1:
            # If the first argument after 'stability' is not the integer
            # specifying the desired statistics (i.e. number of points), then
            # we insert the default value 100
            try:
                int(args[2])
            except ValueError:
                args.insert(2, '100')

        if args[0] in ['stability', 'profile'] and os.path.isfile(args[3]):
            param_card = args.pop(3)
        if any([',' in elem for elem in args if not elem.startswith('--')]):
            raise self.InvalidCmd('Decay chains not allowed in check')
        
        user_options = {'--energy':'1000','--split_orders':'-1',
                   '--reduction':'1|3|5|6','--CTModeRun':'-1',
                   '--helicity':'-1','--seed':'-1','--collier_cache':'-1',
                   '--collier_req_acc':'auto',
                   '--collier_internal_stability_test':'False',
                   '--collier_mode':'1',
                   '--loop_pole_mode':'-1', '--tirust_finite':'true',
                   '--tirust_cache':'-1', '--tirust_cache_max_bytes':'268435456',
                   '--tirust_qp_integrand':'true',
                   '--events': None,
                   '--skip_evt':0}

        if args[0] == 'precision':
            user_options['--nb_event'] = '1000000'
            user_options['--backend'] = 'auto'

        if args[0] in ['cms'] or args[0].lower()=='cmsoptions':
            # increase the default energy to 5000
            user_options['--energy']='5000'
            # The first argument gives the name of the coupling order in which
            # the cms expansion is carried, and the expression following the 
            # comma gives the relation of an external parameter with the
            # CMS expansions parameter called 'lambdaCMS'.
            parameters = ['aewm1->10.0/lambdaCMS','as->0.1*lambdaCMS']
            user_options['--cms']='QED&QCD,'+'&'.join(parameters)
            # Widths are assumed to scale linearly with lambdaCMS unless
            # --force_recompute_width='always' or 'first_time' is used.
            user_options['--recompute_width']='auto'
            # It can be negative so as to be offshell below the resonant mass
            user_options['--offshellness']='10.0'
            # Pick the lambdaCMS values for the test. Instead of a python list
            # we specify here (low,N) which means that do_check will automatically
            # pick lambda values up to the value low and with N values uniformly
            # spread in each interval [1.0e-i,1.0e-(i+1)].
            # Some points close to each other will be added at the end for the
            # stability test.
            user_options['--lambdaCMS']='(1.0e-6,5)'
            # Set the RNG seed, -1 is default (random).
            user_options['--seed']=666
            # The option below can help the user re-analyze existing pickled check
            user_options['--analyze']='None'
            # Decides whether to show plot or not during the analysis
            user_options['--show_plot']='True'
            # Decides what kind of report 
            user_options['--report']='concise'
            # 'secret' option to chose by which lambda power one should divide
            # the nwa-cms difference. Useful to set to 2 when doing the Born check
            # to see whether the NLO check will have sensitivity to the CMS
            # implementation
            user_options['--diff_lambda_power']='1'
            # Sets the range of lambda values to plot
            user_options['--lambda_plot_range']='[-1.0,-1.0]'
            # Sets a filter to apply at generation. See name of available 
            # filters in loop_diagram_generations.py, function user_filter 
            user_options['--loop_filter']='None'
            # Apply tweaks to the check like multiplying a certain width by a
            # certain parameters or changing the analytical continuation of the 
            # logarithms of the UV counterterms
            user_options['--tweak']='default()'
            # Give a name to the run for the files to be saved
            user_options['--name']='auto'
            # Select what resonances must be run
            user_options['--resonances']='1'
        
        for arg in args[:]:
            if arg.startswith('--') and '=' in arg:
                parsed = arg.split('=')
                key, value = parsed[0],'='.join(parsed[1:])
                if key not in user_options:
                    raise self.InvalidCmd("unknown option %s" % key)
                user_options[key] = value
                args.remove(arg)

        # If we are just re-analyzing saved data or displaying options then we 
        # shouldn't check the process format.
        if not (args[0]=='cms' and '--analyze' in user_options and \
                              user_options['--analyze']!='None') and not \
                                            args[0].lower().endswith('options'):
            
            self.check_process_format(" ".join(args[1:]))

        for option, value in user_options.items():
            args.append('%s=%s'%(option,value))

        return param_card

    def check_generate(self, args):
        """check the validity of args"""

        if not self._curr_model:
            logger.info("No model currently active, so we import the Standard Model")
            self.do_import('model sm')
        
        argproc_noopt = [a for a in args[1:] if not (a.startswith('--') and "=" in a)]

        if args[-1].startswith('--optimize'):
            if args[2] != '>':
                raise self.InvalidCmd('optimize mode valid only for 1->N processes. (See model restriction for 2->N)')
            if '=' in args[-1]:
                path = args[-1].split('=',1)[1]
                if not os.path.exists(path) or \
                                self.detect_file_type(path) != 'param_card':
                    raise self.InvalidCmd('%s is not a valid param_card')
            else:
                path=None
            # Update the default value of the model here.
            if not isinstance(self._curr_model, model_reader.ModelReader):
                self._curr_model = model_reader.ModelReader(self._curr_model)
            self._curr_model.set_parameters_and_couplings(path)
        
        self.check_process_format(' '.join(argproc_noopt))            
        
    

    def check_process_format(self, process):
        """ check the validity of the string given to describe a format """

        left, mode, right = split_interference_line(process)
        if mode:
            self.check_process_format(left)
            if right is not None:
                self.check_process_format(right)
            return

        #check balance of parenthesis
        if process.count('(') != process.count(')'):
            raise self.InvalidCmd('Invalid Format, no balance between open and close parenthesis')
        #remove parenthesis for fututre introspection
        process = process.replace('(',' ').replace(')',' ')

        # split following , (for decay chains)
        subprocesses = process.split(',')
        if len(subprocesses) > 1:
            for subprocess in subprocesses:
                self.check_process_format(subprocess)
            return

        # request that we have one or two > in the process
        nbsep = len(re.findall(r'>\D', process)) # not use process.count because of QCD^2>2
        if nbsep not in [1,2]:
            raise self.InvalidCmd(
               'wrong format for \"%s\" this part requires one or two symbols \'>\', %s found'
               % (process, nbsep))

        # we need at least one particles in each pieces
        particles_parts = re.split(r'>\D', process)
        for particles in particles_parts:
            if re.match(r'^\s*$', particles):
                raise self.InvalidCmd(
                '\"%s\" is a wrong process format. Please try again' % process)

        # '/' and '$' should be used only after the process definition
        for particles in particles_parts[:-1]:
            if re.search(r'\D/', particles):
                raise self.InvalidCmd(
                'wrong process format: restriction should be place after the final states')
            if re.search(r'\D\$', particles):
                raise self.InvalidCmd(
                'wrong process format: restriction should be place after the final states')
                
        # '{}' should only be used for onshell particle (including initial/final state)
        # check first that polarization are not include between > >
        if nbsep == 2:
            if '{' in particles_parts[1]:
                raise self.InvalidCmd('Polarization restriction can not be used as required s-channel')
        split = re.split(r'\D[$|/]',particles_parts[-1],1)
        if len(split)==2:
            if '{' in split[1]:
                raise self.InvalidCmd('Polarization restriction can not be used in forbidding particles')
            
        if '[' in process and '{' in process:
            # Which NLO mode was asked for, taken from inside the brackets so
            # that a stray 'real' elsewhere in the process cannot match.
            bracket = process.split('[')[1].split(']')[0]
            if '=' in bracket:
                nlo_mode, pert_orders = bracket.split('=', 1)
                nlo_mode = nlo_mode.strip().lower()
            else:
                # no keyword, e.g. '[QCD]': the parser calls that mode 'all'
                nlo_mode, pert_orders = 'all', bracket

            # A polarised massive particle needs a frame to be defined in,
            # but the three NLO regimes get there in completely different ways
            # and so need different checks -- not one shared flag.
            #
            # 1. 'virt' outputs standalone MadLoop. The user supplies the
            #    phase-space point themselves and so chooses the frame. There
            #    is no run_card, no me_frame and nothing for the code to get
            #    wrong, whatever the perturbation orders.
            standalone_olp = nlo_mode == 'virt'

            # 2. Loop-induced. There is no Born to subtract against and no
            #    counterterm that has to be evaluated in the same frame as
            #    anything else: 'noborn' is exported through the LO madevent
            #    template and boosted by the very same
            #    Template/LO/SubProcesses/genps.f boost_to_frame as a tree
            #    process, and 'sqrvirt' squares one amplitude standalone. So
            #    nothing here is an NLO-specific hazard, and no NLO-specific
            #    restriction applies -- massive or not, whatever the orders.
            #    Verified at runtime on g g > z{0} z{0} [noborn=QCD]: see
            #    docs/nlo_polarisation_boost_plan.md, M6.
            loop_induced = nlo_mode in ('noborn', 'sqrvirt')

            # 3. The subtracted modes. Here the frame comes from me_frame in
            #    the run_card and every piece has to be boosted into it by
            #    hand: the Born (M1), the real emission and the full set of FKS
            #    counterterms (M2), the virtual through binothlha_frame (M3),
            #    and the MC counterterms' azimuth for NLO+PS (M5). That
            #    threading is what can be got wrong, so this is the only
            #    regime worth restricting, and the restriction is exactly the
            #    reach of the boost: validated for QCD, since the QED
            #    counterterms go through the same wrappers but nothing in the
            #    QED sector has been validated.
            subtracted_boost_ok = (nlo_mode in ('loonly', 'real', 'all')
                                   and pert_orders.strip().lower() == 'qcd')

            if not (standalone_olp or loop_induced or subtracted_boost_ok):
                raise self.InvalidCmd('Polarization restriction can not be '
                                      'used for NLO processes')

            # Colour, in the subtracted regime only: a coloured polarised
            # particle is an FKS emitter. Two rules, two messages.
            # (a) INITIAL state coloured: refused whatever the mass -- the
            #     splitting reads backwards, so the polarised parton is an
            #     internal line of the real. A 1 -> N decay is exempt, its
            #     initial leg being a spectator find_reals never splits.
            # (b) FINAL state coloured: refused if MASSLESS (untested, and no
            #     daughter carries the mother's identity); massive is measured.
            # Evidence and caveats: docs/nlo_polarisation_massive_colour.md.
            if subtracted_boost_ok:
                # A 1 -> N decay: the single particle before the '>' is the
                # decaying one, never an FKS initial-state splitter.
                is_decay = len(particles_parts[0].split()) == 1

                def check(p, initial):
                    # get_particle returns None for a name the model does not
                    # know; leave the real diagnostic to the process parser
                    if p is None:
                        return
                    if p.get('color') == 1:
                        return
                    if initial and not is_decay:
                        raise self.InvalidCmd(
                            'Polarization restriction can not be used for '
                            'color charged particles (%s) in the INITIAL '
                            'state of a subtracted NLO computation, whatever '
                            'their mass: the initial-state splitting makes '
                            'the polarized particle an internal line of the '
                            'real emission, so no external leg can carry the '
                            'polarization. Only final-state coloured '
                            'particles may be polarized.' % p.get('name'))
                    if p.get('mass').lower() == 'zero':
                        raise self.InvalidCmd(
                            'Polarization restriction can not be used for '
                            'massless color charged particles (%s) in a '
                            'subtracted NLO computation. Only massive '
                            'coloured particles may be polarized here.'
                            % p.get('name'))

                def walk(particles, initial):
                    # no model loaded -> nothing to look a colour up in, so
                    # the whole check is skipped rather than passing per token
                    if not self._curr_model:
                        return
                    for p in particles.split():
                        if '{' not in p:
                            continue
                        part = p.split('{')[0]
                        particle = self._curr_model.get_particle(part)
                        if particle:
                            check(particle, initial)
                        elif part.lower() in self._multiparticles:
                            # do_define lowercases the label it stores
                            for part2 in self._multiparticles[part.lower()]:
                                check(self._curr_model.get_particle(part2),
                                      initial)
                        else:
                            check(self._curr_model.get_particle(part.lower()),
                                  initial)

                walk(particles_parts[0], True)
                walk(particles_parts[-1], False)


    def check_tutorial(self, args):
        """check the validity of the line"""
        if len(args) == 0:
            # a bare 'tutorial' opens the menu -- or, with no terminal to ask
            # on, keeps its historical meaning of "start the first tutorial"
            args.append(self.ask_tutorial())
        if len(args) == 2 and args[0] == 'skip':
            # `tutorial skip N` goes to step N
            if not args[1].isdigit():
                raise self.InvalidCmd('tutorial skip takes a step number -- '
                                      '`tutorial index` lists them')
        elif len(args) != 1:
            self.help_tutorial()
            raise self.InvalidCmd('Too many arguments for tutorial')
        if args[0] not in self._tutorial_opts:
            self.help_tutorial()
            raise self.InvalidCmd('Invalid argument for tutorial: %s' % args[0])
        # normalise an alias ('MadGraph5') to the primary name ('lo')
        tutorial = tutorials.get(args[0])
        if tutorial is not None:
            args[0] = tutorial.name



    def check_import(self, args):
        """check the validity of line"""
        
        modelname = False
        prefix = True
        debug = False
        if '-modelname' in args:
            args.remove('-modelname')
            modelname = True
        elif '--modelname' in args:
            args.remove('--modelname')
            modelname = True

        if '--debug' in args:
            args.remove('--debug')
            debug = True
            
        if '--noprefix' in args:
            args.remove('--noprefix')
            prefix = False  

        if args and args[0] == 'model' and '--last' in args:
            # finding last created directory
            args.remove('--last')
            last_change =  0
            to_search = [pjoin(MG5DIR,'models')]
            if 'PYTHONPATH' in os.environ:
                to_search += os.environ['PYTHONPATH'].split(':')
                to_search = [d for d in to_search if os.path.exists(d)]
            
            models = []
            for d in to_search:
                for p in misc.glob('*/particles.py', path=d ):
                    if p.endswith(('__REAL/particles.py','__COMPLEX/particles.py')):
                        continue
                    models.append(os.path.dirname(p))
                
            lastmodel = max(models, key=os.path.getmtime)
            logger.info('last model found is %s', lastmodel)
            args.insert(1, lastmodel)
            self.history.info['model'] = lastmodel

        if not args:
            self.help_import()
            raise self.InvalidCmd('wrong \"import\" format')

        if len(args) >= 2 and args[0] not in self._import_formats:
            self.help_import()
            raise self.InvalidCmd('wrong \"import\" format')
        elif len(args) == 1:
            if args[0] in self._import_formats:
                if args[0] != "proc_v4":
                    self.help_import()
                    raise self.InvalidCmd('wrong \"import\" format')
                elif not self._export_dir:
                    self.help_import()
                    raise self.InvalidCmd('PATH is mandatory in the current context\n' + \
                                  'Did you forget to run the \"output\" command')
            # The type of the import is not given -> guess it
            format = self.find_import_type(args[0])
            logger.info('The import format was not given, so we guess it as %s' % format)
            args.insert(0, format)
            if self.history[-1].startswith('import'):
                self.history[-1] = 'import %s %s' % \
                                (format, ' '.join(self.history[-1].split()[1:]))

        if not prefix:
            args.append('--noprefix')

        if modelname:
            args.append('-modelname')

        if args[0] == 'model_v4' and not debug:
            raise self.InvalidCmd(
                'The "import model_v4" command is deprecated and no longer '
                'available in normal user mode. If you really need it for '
                'debugging, use "import model_v4 MODEL --debug".')



    def check_install(self, args):
        """check that the install command is valid"""
        

        install_options = {'options_for_HEPToolsInstaller':[],
                   'update_options':[]}
        hidden_prog = ['Delphes2', 'pythia-pgs','SysCalc']

        if len(args) < 1:
            self.help_install()
            raise self.InvalidCmd('install command require at least one argument')
        
        if len(args) > 1:
            for arg in args[1:]:
                try:
                    option, value = arg.split('=')
                except ValueError:
                    option = arg
                    value = None
                # Options related to the MadGraph installer can be treated here, i.e
                if args[0]=='update':
                    if value is None:
                        install_options['update_options'].append(option)
                    else:
                        install_options['update_options'].append('='.join([option,value]))                        
                else:
                    # Other options will be directly added to the call to HEPToolsInstallers
                    # in the advanced_install function
                    install_options['options_for_HEPToolsInstaller'].append(arg)
            # Now that the options have been treated keep only the target tool
            # to install as argument.   
            args = args[:1]

        if args[0] == 'mg5amc_py8_interface':
            raise self.InvalidCmd("The MG5aMC_PY8_interface is not supported by "+
                "MadGraph7: the Pythia8 shower runs Pythia8's main164, which is "+
                "installed (and compiled if needed) with 'install pythia8'.")

        if args[0] not in self._install_opts + hidden_prog + self._advanced_install_opts: 
            self.help_install()
            raise self.InvalidCmd('Not recognize program %s ' % args[0])

        if args[0] in ["ExRootAnalysis", "Delphes", "Delphes2"]:
            if not misc.which('root'):
                raise self.InvalidCmd(
'''In order to install ExRootAnalysis, you need to install Root on your computer first.
please follow information on http://root.cern.ch/drupal/content/downloading-root''')
            if 'ROOTSYS' not in os.environ:
                raise self.InvalidCmd(
'''The environment variable ROOTSYS is not configured.
You can set it by adding the following lines in your .bashrc [.bash_profile for mac]:
export ROOTSYS=%s
export PATH=$PATH:$ROOTSYS/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ROOTSYS/lib
export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$ROOTSYS/lib
This will take effect only in a NEW terminal
''' % os.path.realpath(pjoin(misc.which('root'), \
                                               os.path.pardir, os.path.pardir)))

        return install_options

    def check_launch(self, args, options):
        """check the validity of the line"""
        # modify args in order to be MODE DIR
        # mode being either standalone or madevent
        if not( 0 <= int(options.cluster) <= 2):
            return self.InvalidCmd( 'cluster mode should be between 0 and 2')

        if not args:
            if self._done_export:
                mode = self.find_output_type(self._done_export[0])
                if (self._done_export[1] == 'plugin' and mode in self._export_formats):
                    args.append(mode)
                    args.append(self._done_export[0])
                elif self._done_export[1].startswith(mode):
                    args.append(self._done_export[1])
                    args.append(self._done_export[0])
                elif mode == 'standalone_fortran' and self._done_export[1] in \
                        ('standalone_msP', 'standalone_msF', 'standalone_rw'):
                    # find_output_type cannot tell the Fortran standalone
                    # variants apart on disk: they all report
                    # 'standalone_fortran'. Accept the recorded format.
                    args.append(self._done_export[1])
                    args.append(self._done_export[0])
                else:
                    raise self.InvalidCmd('%s not valid directory for launch' % self._done_export[0])
                return
            else:
                logger.warning('output command missing, run it automatically (with default argument)')
                self.do_output('')
                logger.warning('output done: running launch')
                return self.check_launch(args, options)

        if len(args) != 1:
            self.help_launch()
            return self.InvalidCmd( 'Invalid Syntax: Too many argument')

        # search for a valid path
        if os.path.isdir(args[0]):
            path = os.path.realpath(args[0])
        elif os.path.isdir(pjoin(MG5DIR,args[0])):
            path = pjoin(MG5DIR,args[0])
        elif  MG4DIR and os.path.isdir(pjoin(MG4DIR,args[0])):
            path = pjoin(MG4DIR,args[0])
        else:
            raise self.InvalidCmd('%s is not a valid directory' % args[0])

        mode = self.find_output_type(path)
        if mode == 'madweight':
            raise self.InvalidCmd('launch on a madweight directory is no longer supported; '
                                  'MadWeight has been removed')

        args[0] = mode
        args.append(path)
        # inform where we are for future command
        self._done_export = [path, mode]


    def find_import_type(self, path):
        """ identify the import type of a given path
        valid output: model/model_v4/proc_v4/command"""

        possibility = [pjoin(MG5DIR,'models',path), \
                     pjoin(MG5DIR,'models',path+'_v4'), path]
        if '-' in path:
            name = path.rsplit('-',1)[0]
            possibility = [pjoin(MG5DIR,'models',name), name] + possibility
        # Check if they are a valid directory
        for name in possibility:
            if os.path.isdir(name):
                if os.path.exists(pjoin(name,'particles.py')):
                    return 'model'
                elif os.path.exists(pjoin(name,'particles.dat')):
                    return 'model_v4'

        # Not valid directory so maybe a file
        if os.path.isfile(path):
            text = open(path).read()
            pat = re.compile('(Begin process|<MGVERSION>)', re.I)
            matches = pat.findall(text)
            if not matches:
                return 'command'
            elif len(matches) > 1:
                return 'banner'
            elif matches[0].lower() == 'begin process':
                return 'proc_v4'
            else:
                return 'banner'
        else:
            return 'proc_v4'




    def find_output_type(self, path):
        """ identify the type of output of a given directory:
        valid output: madevent/standalone/standalone_fortran/mg7/..."""

        card_path = pjoin(path,'Cards')
        bin_path = pjoin(path,'bin')
        src_path = pjoin(path,'src')
        include_path = pjoin(path,'include')
        subproc_path = pjoin(path,'SubProcesses')
        mw_path = pjoin(path,'Source','MadWeight')

        if os.path.isfile(pjoin(include_path, 'Pythia.h')) or \
            os.path.isfile(pjoin(include_path, 'Pythia8', 'Pythia.h')):
            return 'pythia8'
        elif not os.path.isdir(os.path.join(path, 'SubProcesses')):
            raise self.InvalidCmd('%s : Not a valid directory' % path)
        if os.path.isfile(pjoin(subproc_path, 'check_sa_fks_mode')):
            return 'amcatnlo_fks_sa'
        if os.path.isfile(pjoin(bin_path,'madevent')):
            return 'madevent'
        elif os.path.isfile(pjoin(subproc_path, 'madmatrix_standalone.mk')):
            # the `standalone` (madmatrix) export writes
            # SubProcesses/madmatrix_standalone.mk (the regular mg7 export only
            # writes madmatrix.mk, so testing for that would match it too).
            return 'standalone'
        elif os.path.isfile(pjoin(card_path, 'run_card.toml')):
            return 'mg7'
        elif os.path.isdir(src_path):
            # Catch-all for the C++-family standalone trees, i.e. anything
            # written by a ProcessExporterCPP descendant that ships a src/
            # directory and is not one of the more specific cases above --
            # today that is `matchbox_cpp` and `mg7_v5`.  This is not a
            # user-facing `output` format name; it only has to start with
            # 'standalone' so that do_launch routes it to the SALauncher.
            return 'standalone_cpp_family'
        elif os.path.isdir(mw_path):
            return 'madweight'
        elif os.path.isfile(pjoin(bin_path,'aMCatNLO')):
            return 'aMC@NLO'
        elif os.path.isdir(card_path):
            return 'standalone_fortran'

        raise self.InvalidCmd('%s : Not a valid directory' % path)

    def check_load(self, args):
        """ check the validity of the line"""

        if len(args) != 2 or args[0] not in self._save_opts:
            self.help_load()
            raise self.InvalidCmd('wrong \"load\" format')

    def check_explain_restriction(self, args):
        """check the validity of the line"""

        args = [arg for arg in args if arg != '--all']
        if len(args) > 1:
            self.help_explain_restriction()
            raise self.InvalidCmd('explain_restriction takes at most one argument')
        if not args and not self._curr_model:
            raise self.InvalidCmd('No model loaded: give a restriction card or '
                                  'a model name to explain.')
        if self._model_v4_path:
            raise self.InvalidCmd('Restriction of Model is not supported by v4 model.')

    def check_customize_model(self, args):
        """check the validity of the line"""

        # Check argument validity
        for arg in args:
            if arg == '--all':
                continue
            if arg == '--explain' or arg.startswith('--explain='):
                mode = parse_explain_mode(arg)
                if mode not in CUSTOMIZE_EXPLAIN_MODES:
                    raise self.InvalidCmd('Valid values for --explain are: %s '
                        '(--explain alone means --explain=%s, which is also '
                        'what you get without the option; --explain=off turns '
                        'the report off).'
                        % (', '.join(CUSTOMIZE_EXPLAIN_MODES),
                           CUSTOMIZE_EXPLAIN_DEFAULT))
                continue
            if arg.startswith('--save='):
                if '-' in arg.split('=', 1)[1]:
                    raise self.InvalidCmd('The name given in save options can\'t contain \'-\' symbol.')
                continue
            self.help_customize_model()
            raise self.InvalidCmd('Wrong argument for this command')

        if self._model_v4_path:
            raise self.InvalidCmd('Restriction of Model is not supported by v4 model.')


    def check_save(self, args):
        """ check the validity of the line"""

        if len(args) == 0:
            args.append('options')

        if args[0] not in self._save_opts and args[0] != 'global':
            self.help_save()
            raise self.InvalidCmd('wrong \"save\" format')
        elif args[0] == 'global':
            args.insert(0, 'options')

        if args[0] != 'options' and len(args) != 2:
            self.help_save()
            raise self.InvalidCmd('wrong \"save\" format')
        elif args[0] != 'options' and len(args) == 2:
            basename = os.path.dirname(args[1])
            if not os.path.exists(basename):
                raise self.InvalidCmd('%s is not a valid path, please retry' % \
                                                                        args[1])

        if args[0] == 'options':
            has_path = None
            for arg in args[1:]:
                if arg in ['--auto', '--all'] or arg in self.options:
                    continue
                elif arg.startswith('--'):
                    raise self.InvalidCmd('unknow command for \'save options\'')
                elif arg == 'global':
                    config_file = misc.user_config_file(create=True)
                    if not config_file:
                        raise self.InvalidCmd('no home directory to save the '
                                              'global configuration into')
                    args.remove('global')
                    args.insert(1, config_file)

                    has_path = True
                else:
                    basename = os.path.dirname(arg)
                    if not os.path.exists(basename):
                        raise self.InvalidCmd('%s is not a valid path, please retry' % \
                                                                        arg)
                    elif has_path:
                        raise self.InvalidCmd('only one path is allowed')
                    else:
                        args.remove(arg)
                        args.insert(1, arg)
                        has_path = True
            if not has_path:
                args.insert(1, misc.install_config_file(MG5DIR))


    def check_set(self, args, log=True):
        """ check the validity of the line"""

        if len(args) == 1 and args[0] in ['complex_mass_scheme',\
                                          'loop_optimized_output',\
                                          'loop_color_flows',\
                                          'include_lepton_initiated_processes',\
                                          'low_mem_multicore_nlo_generation',\
                                          'merge_same_topologies']:
            args.append('True')

        if len(args) > 2 and '=' == args[1]:
            args.pop(1)

        if len(args) < 2:
            self.help_set()
            raise self.InvalidCmd('set needs an option and an argument')

        if args[1] == 'default':
            if args[0] in self.options_configuration:
                default = self.options_configuration[args[0]]
            elif args[0] in self.options_madgraph:
                default = self.options_madgraph[args[0]]
            elif args[0] in self.options_madevent:
                default = self.options_madevent[args[0]]
            else:
                raise self.InvalidCmd('%s doesn\'t have a valid default value' % args[0])
            if log:
                logger.info('Pass parameter %s to it\'s default value: %s' %
                                                             (args[0], default))
            args[1] = str(default)

        if cmd.is_removed_option(args[0]):
            # handled (and reported) by do_set: never an error
            return

        if args[0] not in self._set_options:
            if not args[0] in self.options and not args[0] in self.options:
                self.help_set()
                raise self.InvalidCmd('Possible options for set are %s' % \
                                  self._set_options)

        if args[0] in ['group_subprocesses']:
            if args[1].lower() not in ['false', 'true', 'auto', 'gpu']:
                raise self.InvalidCmd('%s needs argument False, True, gpu or Auto, got %s' % \
                                      (args[0], args[1]))
        if args[0] in ['ignore_six_quark_processes']:
            if args[1] not in list(self._multiparticles.keys()) and args[1].lower() != 'false':
                raise self.InvalidCmd('ignore_six_quark_processes needs ' + \
                                      'a multiparticle name as argument')

        if args[0] in ['stdout_level']:
            if args[1] not in ['DEBUG','INFO','WARNING','ERROR','CRITICAL'] and \
                                                          not args[1].isdigit():
                raise self.InvalidCmd('output_level needs ' + \
                                      'a valid level')

        if args[0] in ['timeout', 'max_npoint_for_channel', 'max_t_for_channel']:
            if not args[1].isdigit():
                raise self.InvalidCmd('%s values should be an integer' % args[0])
            
        if args[0] in ['loop_optimized_output', 'loop_color_flows', 'low_mem_multicore_nlo_generation', 'nlo_mixed_expansion']:
            try:
                args[1] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
            except Exception:
                raise self.InvalidCmd('%s needs argument True or False'%args[0])

        if args[0] in ['gauge']:
            allow = ['unitary','Feynman', 'axial', 'FD']
            if args[1] not in allow:
                raise self.InvalidCmd('gauge needs argument %s.' % ','.join(allow))

        if args[0] in ['timeout']:
            if not args[1].isdigit():
                raise self.InvalidCmd('timeout values should be an integer')

        if args[0] in ['OLP']:
            if args[1] not in MadGraphCmd._OLP_supported:
                raise self.InvalidCmd('OLP value should be one of %s'\
                                               %str(MadGraphCmd._OLP_supported))

        if args[0].lower() in ['ewscheme']:
            if not self._curr_model:
                raise self.InvalidCmd("ewscheme acts on the current model please load one first.")
            if args[1] not in ['external', 'MZ_MW_alpha']:
                raise self.InvalidCmd('Only valid ewscheme are "external" and "MZ_MW_alpha". To restore default, please re-import the model.')

        if args[0] in ['output_dependencies']:
            if args[1] not in MadGraphCmd._output_dependencies_supported:
                raise self.InvalidCmd('output_dependencies value should be one of %s'\
                               %str(MadGraphCmd._output_dependencies_supported))

    def check_open(self, args):
        """ check the validity of the line """

        if len(args) != 1:
            self.help_open()
            raise self.InvalidCmd('OPEN command requires exactly one argument')

        if args[0].startswith('./'):
            if not os.path.isfile(args[0]):
                raise self.InvalidCmd('%s: not such file' % args[0])
            return True

        # if special : create the path.
        if not self._done_export:
            if not os.path.isfile(args[0]):
                self.help_open()
                raise self.InvalidCmd('No command \"output\" or \"launch\" used. Impossible to associate this name to a file')
            else:
                return True

        path = self._done_export[0]
        if os.path.isfile(pjoin(path,args[0])):
            args[0] = pjoin(path,args[0])
        elif os.path.isfile(pjoin(path,'Cards',args[0])):
            args[0] = pjoin(path,'Cards',args[0])
        elif os.path.isfile(pjoin(path,'HTML',args[0])):
            args[0] = pjoin(path,'HTML',args[0])
        # special for card with _default define: copy the default and open it
        elif '_card.dat' in args[0]:
            name = args[0].replace('_card.dat','_card_default.dat')
            if os.path.isfile(pjoin(path,'Cards', name)):
                files.cp(path + '/Cards/' + name, path + '/Cards/'+ args[0])
                args[0] = pjoin(path,'Cards', args[0])
            else:
                raise self.InvalidCmd('No default path for this file')
        elif not os.path.isfile(args[0]):
            raise self.InvalidCmd('No default path for this file')


    def check_output(self, args, default='mg7'):
        """ check the validity of the line"""

        if args and args[0] == 'madweight':
            raise self.InvalidCmd('output madweight is no longer supported; please use a different output mode')

        if args and args[0] == 'pythia8':
            raise self.InvalidCmd('output pythia8 is no longer supported; please use a different output mode')

        if args and args[0] == 'standalone_cpp':
            raise self.InvalidCmd('output standalone_cpp is no longer supported; '
                                  'use \'standalone\' for the MadMatrix (C++/CUDA) '
                                  'standalone or \'standalone_fortran\' for the '
                                  'Fortran one')

        if args and args[0] in self._export_formats:
            self._export_format = args.pop(0)
        elif args:
            # check for PLUGIN format
            output_cls = misc.from_plugin_import(self.plugin_path, 'new_output',
                                                 args[0], warning=True, 
                                                 info='Output will be done with PLUGIN: %(plug)s')
            if output_cls:
                self._export_format = 'plugin'
                self._export_plugin = output_cls
                args.pop(0)
                if hasattr(output_cls, 'change_output_args'):
                    args[:] = output_cls.change_output_args(args, self) 
            else:
                self._export_format = default
        else:
            self._export_format = default

        if not self._curr_model:
            text = 'No model found. Please import a model first and then retry.'
            raise self.InvalidCmd(text)

        if self._model_v4_path and \
               (self._export_format not in self._v4_export_formats):
            text = " The Model imported (MG4 format) does not contain enough\n "
            text += " information for this type of output. In order to create\n"
            text += " output for " + args[0] + ", you have to use a UFO model.\n"
            text += " Those model can be imported with MG5> import model NAME."
            logger.warning(text)
            raise self.InvalidCmd('')

        if self._export_format == 'aloha':
            return


        if not self._curr_amps:
            text = 'No processes generated. Please generate a process first.'
            raise self.InvalidCmd(text)

        if args and args[0][0] != '-':
            # This is a path
            path = args.pop(0)
            forbiden_chars = ['>','<',';','&']
            for char in forbiden_chars:
                if char in path:
                    raise self.InvalidCmd('%s is not allowed in the output path' % char)
            # Check for special directory treatment
            if path == 'auto' and self._export_format in \
                     ['madevent', 'standalone_fortran', 'matchbox_cpp',
                      'matchbox', 'plugin', 'me7', 'mg7', 'mg7_v5', 'standalone']:
                self.get_default_path()
                if '-noclean' not in args and os.path.exists(self._export_dir):
                    args.append('-noclean')
            elif path != 'auto':
                if path in ['HELAS', 'tests', 'MadSpin', 'madgraph', 'mg5decay', 'vendor','madevent_gpu', 'madevent_simd']:
                    if os.getcwd() == MG5DIR:
                        raise self.InvalidCmd("This name correspond to a builtin MG5 directory. Please choose another name")
                self._export_dir = path
            elif path == 'auto':
                if self.options['pythia8_path']:
                    self._export_dir = self.options['pythia8_path']
                else:
                    self._export_dir = '.'
        else:
            if self._export_format != 'pythia8':
                # No valid path
                self.get_default_path()
                if '-noclean' not in args and os.path.exists(self._export_dir):
                    args.append('-noclean')
                    
            else:
                if self.options['pythia8_path']:
                    self._export_dir = self.options['pythia8_path']
                else:
                    self._export_dir = '.'

        self._export_dir = os.path.realpath(self._export_dir)


    def check_compute_widths(self, args):
        """ check and format calculate decay width:
        Expected format: NAME [other names] [--options]
        # fill the options if not present.
        # NAME can be either (anti-)particle name, multiparticle, pid
        """

        if len(args)<1:
            self.help_compute_widths()
            raise self.InvalidCmd('''compute_widths requires at least the name of one particle.
            If you want to compute the width of all particles, type \'compute_widths all\'''')

        particles = set()
        options = {'path':None, 'output':None,
                   'min_br':None, 'body_decay':4.0025, 'precision_channel':0.01,
                   'nlo':False, 'engine':None, 'corrections':None}
        # check that the firsts argument is valid
        
        for i,arg in enumerate(args):
            if arg.startswith('--'):
                if arg.startswith('--nlo'):
                    # --nlo, or --nlo=smwidth / --nlo=mcatnlo to choose the code
                    value = arg.partition('=')[2].lower()
                    if value not in ('', 'true', 'false', 'smwidth', 'mcatnlo'):
                        raise self.InvalidCmd('--nlo takes smwidth or mcatnlo, not %s' % value)
                    options['nlo'] = value if value in ('smwidth', 'mcatnlo') else value != 'false'
                    continue
                elif not '=' in arg:
                    raise self.InvalidCmd('Options required an equal (and then the value)')
                arg, value = arg.split('=',1)
                if arg[2:] not in options:
                    raise self.InvalidCmd('%s not valid options' % arg)
                options[arg[2:]] = value
                continue
            # check for pid
            if arg.isdigit():
                p = self._curr_model.get_particle(int(arg))
                if not p:
                    raise self.InvalidCmd('Model doesn\'t have pid %s for any particle' % arg)
                particles.add(abs(int(arg)))
            elif arg in self._multiparticles:
                particles.update([abs(id) for id in self._multiparticles[args[0]]])
            else:
                if not self._curr_model['case_sensitive']:
                    arg = arg.lower()                
                for p in self._curr_model['particles']:
                    if p['name'] == arg or p['antiname'] == arg:
                        particles.add(abs(p.get_pdg_code()))
                        break
                else:
                    if arg == 'all':
                        #sometimes the multiparticle all is not define
                        particles.update([abs(p.get_pdg_code())
                                        for p in self._curr_model['particles']])
                    else:
                        raise self.InvalidCmd('%s invalid particle name' % arg)

        if options['path'] and not os.path.isfile(options['path']):

            if os.path.exists(pjoin(MG5DIR, options['path'])):
                options['path'] = pjoin(MG5DIR, options['path'])
            elif self._model_v4_path and  os.path.exists(pjoin(self._model_v4_path, options['path'])):
                options['path'] = pjoin(self._curr_model_v4_path, options['path'])
            elif os.path.exists(pjoin(self._curr_model.path, options['path'])):
                options['path'] = pjoin(self._curr_model.path, options['path'])

            if os.path.isdir(options['path']) and os.path.isfile(pjoin(options['path'], 'param_card.dat')):
                options['path'] = pjoin(options['path'], 'param_card.dat')
            elif not os.path.isfile(options['path']):
                raise self.InvalidCmd('%s is not a valid path' % args[2])
            # check that the path is indeed a param_card:
            if madevent_interface.MadEventCmd.detect_card_type(options['path']) != 'param_card.dat':
                raise self.InvalidCmd('%s should be a path to a param_card' % options['path'])

        if not options['path']:
            param_card_text = self._curr_model.write_param_card()
            if not options['output']:
                dirpath = self._curr_model.get('modelpath')
                options['path'] = pjoin(dirpath, 'param_card.dat')
            else:
                options['path'] = options['output']
            ff = open(options['path'],'w')
            ff.write(param_card_text)
            ff.close()
        if not options['output']:
            options['output'] = options['path']

        if not options['min_br']:
            options['min_br'] = (float(options['body_decay']) % 1) / 5
        if options['engine'] is not None:
            options['engine'] = str(options['engine']).lower()
            if options['engine'] not in ('madspace', 'madevent'):
                raise self.InvalidCmd(
                    '--engine takes madspace or madevent, not %s' % options['engine'])
        if options['corrections'] is not None:
            try:
                options['corrections'] = check_param_card.parse_nlo_corrections(
                                                           options['corrections'])
            except check_param_card.InvalidParam as error:
                raise self.InvalidCmd(str(error))
            if not options['nlo']:
                raise self.InvalidCmd('--corrections needs --nlo')
            if options['nlo'] == 'smwidth':
                raise self.InvalidCmd('SMWidth computes the QCD and the electroweak '
                    'corrections together: --corrections is for --nlo=mcatnlo')
        return particles, options


    check_decay_diagram = check_compute_widths

    def get_default_path(self):
        """Set self._export_dir to the default (\'auto\') path"""

        if self._export_format in ['madevent', 'standalone_fortran']:
            # Detect if this script is launched from a valid copy of the Template,
            # if so store this position as standard output directory
            if 'TemplateVersion.txt' in os.listdir('.'):
                #Check for ./
                self._export_dir = os.path.realpath('.')
                return
            elif 'TemplateVersion.txt' in os.listdir('..'):
                #Check for ../
                self._export_dir = os.path.realpath('..')
                return
            elif self.stdin != sys.stdin:
                #Check for position defined by the input files
                input_path = os.path.realpath(self.stdin.name).split(os.path.sep)
                print("Not standard stdin, use input path")
                if input_path[-2] == 'Cards':
                    self._export_dir = os.path.sep.join(input_path[:-2])
                    if 'TemplateVersion.txt' in self._export_dir:
                        return


        if self._export_format in ['NLO', 'ewsudsa']:
            name_dir = lambda i: 'PROCNLO_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format == 'NLO_SA':
            name_dir = lambda i: 'PROC_FKS_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format in ['mg7', 'mg7_v5']:
            # mg7 is the default output format, so it takes the plain PROC_
            # prefix.  This deliberately shares a namespace with madevent
            # below: auto_path() picks the first free index, so the two never
            # collide on disk, they just interleave.
            name_dir = lambda i: 'PROC_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format.startswith('madevent'):
            name_dir = lambda i: 'PROC_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format.startswith('standalone'):
            # The madmatrix standalone is the default standalone, so it takes
            # the plain PROC_SA_ prefix and shares the auto-name namespace with
            # the Fortran standalone (and its msP/msF/rw variants).
            name_dir = lambda i: 'PROC_SA_%s_%s' % \
                                (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                           name_dir(i))
        elif self._export_format in ['matchbox_cpp', 'matchbox']:
            name_dir = lambda i: 'PROC_MATCHBOX_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format in ['plugin']:
            name_dir = lambda i: 'PROC_PLUGIN_%s_%s' % \
                                    (self._curr_model['name'], i)
            auto_path = lambda i: pjoin(self.writing_dir,
                                               name_dir(i))
        elif self._export_format == 'pythia8':
            if self.options['pythia8_path']:
                self._export_dir = self.options['pythia8_path']
            else:
                self._export_dir = '.'
            return
        else:
            self._export_dir = '.'
            return
        for i in range(500):
            if os.path.isdir(auto_path(i)):
                continue
            else:
                self._export_dir = auto_path(i)
                break
        if not self._export_dir:
            raise self.InvalidCmd('Can\'t use auto path,' + \
                                  'more than 500 dirs already')


#===============================================================================
# CheckValidForCmdWeb
#===============================================================================
class CheckValidForCmdWeb(CheckValidForCmd):
    """ Check the validity of input line for web entry
    (no explicit path authorized)"""

    class WebRestriction(MadGraph5Error):
        """class for WebRestriction"""

    def check_draw(self, args):
        """check the validity of line
        syntax: draw FILEPATH [option=value]
        """
        raise self.WebRestriction('direct call to draw is forbidden on the web')

    def check_display(self, args):
        """ check the validity of line in web mode """

        if args[0] == 'mg5_variable':
            raise self.WebRestriction('Display internal variable is forbidden on the web')

        CheckValidForCmd.check_history(self, args)

    def check_check(self, args):
        """ Not authorize for the Web"""

        raise self.WebRestriction('Check call is forbidden on the web')

    def check_history(self, args):
        """check the validity of line
        No Path authorize for the Web"""

        CheckValidForCmd.check_history(self, args)

        if len(args) == 2 and args[1] not in ['.', 'clean']:
            raise self.WebRestriction('Path can\'t be specify on the web.')


    def check_import(self, args):
        """check the validity of line
        No Path authorize for the Web"""

        if not args:
            raise self.WebRestriction('import requires at least one option')

        if args[0] not in self._import_formats:
            args[:] = ['command', './proc_card_mg5.dat']
        elif args[0] == 'proc_v4':
            args[:] = [args[0], './proc_card.dat']
        elif args[0] == 'command':
            args[:] = [args[0], './proc_card_mg5.dat']

        CheckValidForCmd.check_import(self, args)

    def check_install(self, args):
        """ No possibility to install new software on the web """
        if args == ['update','--mode=mg5_start']:
            return

        raise self.WebRestriction('Impossible to install program on the cluster')

    def check_load(self, args):
        """ check the validity of the line
        No Path authorize for the Web"""

        CheckValidForCmd.check_load(self, args)

        if len(args) == 2:
            if args[0] != 'model':
                raise self.WebRestriction('only model can be loaded online')
            if 'model.pkl' not in args[1]:
                raise self.WebRestriction('not valid pkl file: wrong name')
            if not os.path.realpath(args[1]).startswith(pjoin(MG4DIR, \
                                                                    'Models')):
                raise self.WebRestriction('Wrong path to load model')

    def check_save(self, args):
        """ not authorize on web"""
        raise self.WebRestriction('\"save\" command not authorize online')

    def check_open(self, args):
        """ not authorize on web"""
        raise self.WebRestriction('\"open\" command not authorize online')

    def check_output(self, args, default='madevent'):
        """ check the validity of the line"""

        # first pass to the default
        CheckValidForCmd.check_output(self, args, default=default)
        args[:] = ['.', '-f']

        self._export_dir = os.path.realpath(os.getcwd())
        # Check that we output madevent
        if 'madevent' != self._export_format:
                raise self.WebRestriction('only available output format is madevent (at current stage)')

#===============================================================================
# CompleteForCmd
#===============================================================================
class CompleteForCmd(cmd.CompleteCmd):
    """ The Series of help routine for the MadGraphCmd"""


    def nlo_completion(self,args,text,line,allowed_loop_mode=None):
        """ complete the nlo settings within square brackets. It uses the
         allowed_loop_mode for the proposed mode if specified, otherwise, it
         uses self._nlo_modes_for_completion"""

        # We are now editing the loop related options
        # Automatically allow for QCD perturbation if in the sm because the
        # loop_sm would then automatically be loaded
        nlo_modes = allowed_loop_mode if not allowed_loop_mode is None else \
                                                  self._nlo_modes_for_completion
        if isinstance(self._curr_model,loop_base_objects.LoopModel):
            pert_couplings_allowed = ['all']+self._curr_model['perturbation_couplings']
        else:
            pert_couplings_allowed = []
        if self._curr_model.get('name').startswith('sm'):
            pert_couplings_allowed = pert_couplings_allowed + ['QCD']
        # Find whether the loop mode is already set or not
        loop_specs = line[line.index('[')+1:]
        try:
            loop_orders = loop_specs[loop_specs.index('=')+1:]
        except ValueError:
            loop_orders = loop_specs
        possibilities = []
        possible_orders = [order for order in pert_couplings_allowed if \
                                                  order not in loop_orders]

        # Simplify obvious loop completion
        single_completion = ''
        if len(nlo_modes)==1:
                single_completion = '%s= '%nlo_modes[0]
                if len(possible_orders)==1:
                    single_completion = single_completion + possible_orders[0] + ' ] '
        # Automatically add a space if not present after [ or =
        if text.endswith('['):
            if single_completion != '':
                return self.list_completion(text, ['[ '+single_completion])
            else:
                return self.list_completion(text,['[ '])

        if text.endswith('='):
            return self.list_completion(text,[' '])

        if args[-1]=='[':
            possibilities = possibilities + ['%s= '%mode for mode in nlo_modes]
            if single_completion != '':
                return self.list_completion(text, [single_completion])
            else:
                if len(possible_orders)==1:
                    return self.list_completion(text, [poss+' %s ] '%\
                              possible_orders[0] for poss in possibilities])
                return self.list_completion(text, possibilities)

        if len(possible_orders)==1:
            possibilities.append(possible_orders[0]+' ] ')
        else:
            possibilities.extend(possible_orders)
        if any([(order in loop_orders) for order in pert_couplings_allowed]):
            possibilities.append(']')
        return self.list_completion(text, possibilities)

    def model_completion(self, text, process, line, categories = True, \
                                                      allowed_loop_mode = None,
                                                      formatting=True):
        """ complete the line with model information. If categories is True,
        it will use completion with categories. If allowed_loop_mode is
        specified, it will only complete with these loop modes."""

        # First check if we are within squared brackets so that specific
        # input for NLO settings must be completed
        args = self.split_arg(process)
        if len(args) > 2 and '>' in line and '[' in line and not ']' in line:
            return self.nlo_completion(args,text,line, allowed_loop_mode = \
                                                              allowed_loop_mode)

        while ',' in process:
            process = process[process.index(',')+1:]
        args = self.split_arg(process)
        couplings = []

        # Do no complete the @ for the process number.
        if len(args) > 1 and args[-1]=='@':
            return

        # Automatically allow for QCD perturbation if in the sm because the
        # loop_sm would then automatically be loaded
        if isinstance(self._curr_model,loop_base_objects.LoopModel):
            pert_couplings_allowed = ['all'] + self._curr_model['perturbation_couplings']
        else:
            pert_couplings_allowed = []
        if self._curr_model.get('name').startswith('sm'):
            pert_couplings_allowed = pert_couplings_allowed + ['QCD']

        # Remove possible identical names
        particles = misc.make_unique(self._particle_names + list(self._multiparticles.keys()))
        n_part_entered = len([1 for a in args if a in particles])

        # Force '>' if two initial particles.
        if n_part_entered == 2 and args[-1] != '>':
                return self.list_completion(text, '>')

        # Add non-particle names
        syntax = []
        couplings = []
        if len(args) > 0 and args[-1] != '>' and n_part_entered > 0:
            syntax.append('>')
        if '>' in args and args.index('>') < len(args) - 1:
            couplings.extend(sum([[c+"<=", c+"==", c+">",c+'^2<=',c+'^2==',c+'^2>' ] for c in \
                                              self._couplings+['WEIGHTED']],[]))
            syntax.extend(['@','$','/','>',','])
            if '[' not in line and ',' not in line and len(pert_couplings_allowed)>0:
                syntax.append('[')
            
        # If information for the virtuals has been specified already, do not
        # propose syntax or particles input anymore
        if '[' in line:
            syntax = []
            particles = []
            # But still allow for defining the process id
            couplings.append('@')

        if not categories:
            # The direct completion (might be needed for some completion using
            # this function but adding some other completions (like in check)).
            # For those, it looks ok in the category mode on my mac, but if
            # someone sees weird result on Linux systems, then use the
            # default completion for these features.
            return self.list_completion(text, particles+syntax+couplings)
        else:
            # A more elaborate one with categories
            poss_particles = self.list_completion(text, particles)
            poss_syntax = self.list_completion(text, syntax)
            poss_couplings = self.list_completion(text, couplings)
            possibilities = {}
            if poss_particles != []: possibilities['Particles']=poss_particles
            if poss_syntax != []: possibilities['Syntax']=poss_syntax
            if poss_couplings != []: possibilities['Coupling orders']=poss_couplings
            if len(list(possibilities.keys()))==1:
                return self.list_completion(text, list(possibilities.values())[0])
            else:
                return self.deal_multiple_categories(possibilities, formatting)

    def complete_generate(self, text, line, begidx, endidx, formatting=True):
        "Complete the generate command"

        # Return list of particle names and multiparticle names, as well as
        # coupling orders and allowed symbols
        args = self.split_arg(line[0:begidx])

        valid_sqso_operators=['==','<=','>']

        if any(line.endswith('^2 %s '%op) for op in valid_sqso_operators):
            return
        if args[-1].endswith('^2'):
            return self.list_completion(text,valid_sqso_operators)
        match_op = [o for o in valid_sqso_operators if o.startswith(args[-1])]            
        if len(args)>2 and args[-2].endswith('^2') and len(match_op)>0:
            if args[-1] in valid_sqso_operators:
                return self.list_completion(text,' ')
            if len(match_op)==1:
                return self.list_completion(text,[match_op[0][len(args[-1]):]])
            else:
                return self.list_completion(text,match_op)
        if len(args) > 2 and args[-1] == '@' or ( args[-1].endswith('=') and \
                            (not '[' in line or ('[' in line and ']' in line))):
            return

        if text.startswith('--'):
            filters = ['%s=%s' % (opt, name) for name in
                       misc.plugin_diagram_filter(self.plugin_path, None)
                       for opt in ['--diagram_filter', '--tree_diagram_filter',
                                   '--loop_diagram_filter']]
            return self.list_completion(text, ['--no_crossing', 
                                               '--no_warning=duplicate',
                                               '--diagram_filter',
                                               '--tree_diagram_filter',
                                               '--loop_diagram_filter',
                                               '--standalone'] + filters)

        try:
            return self.model_completion(text, ' '.join(args[1:]),line, formatting)
        except Exception as error:
            print(error)

        #if len(args) > 1 and args[-1] != '>':
        #    couplings = ['>']
        #if '>' in args and args.index('>') < len(args) - 1:
        #    couplings = [c + "=" for c in self._couplings] + ['@','$','/','>']
        #return self.list_completion(text, self._particle_names + \
        #                            self._multiparticles.keys() + couplings)

    def complete_convert(self, text, line, begidx, endidx,formatting=True):
        "Complete the compute_widths command"

        args = self.split_arg(line[0:begidx])
        
        # Format
        if len(args) == 1:
            return self.list_completion(text, ['model'])
        elif line[begidx-1] == os.path.sep:
            current_dir = pjoin(*[a for a in args if a.endswith(os.path.sep)])
            return self.path_completion(text, current_dir)
        else:
            return self.path_completion(text)
        

    def complete_compute_widths(self, text, line, begidx, endidx,formatting=True):
        "Complete the compute_widths command"

        args = self.split_arg(line[0:begidx])

        if args[-1] in  ['--path=', '--output=']:
            completion = {'path': self.path_completion(text)}
        elif line[begidx-1] == os.path.sep:
            current_dir = pjoin(*[a for a in args if a.endswith(os.path.sep)])
            if current_dir.startswith('--path='):
                current_dir = current_dir[7:]
            if current_dir.startswith('--output='):
                current_dir = current_dir[9:]
            completion = {'path': self.path_completion(text, current_dir)}
        else:
            completion = {}
            completion['options'] = self.list_completion(text,
                            ['--path=', '--output=', r'--min_br=0.\$',
                             r'--precision_channel=0.\$', '--body_decay=', '--nlo'])
            completion['particles'] = self.model_completion(text, '', line)

        return self.deal_multiple_categories(completion,formatting)

    complete_decay_diagram = complete_compute_widths

    def complete_add(self, text, line, begidx, endidx, formatting):
        "Complete the add command"

        args = self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            return self.list_completion(text, self._add_opts)

        if args[1] == 'process':
            return self.complete_generate(text, " ".join(args[1:]), begidx, endidx)
        
        elif args[1] == 'model':
            completion_categories = self.complete_import(text, line, begidx, endidx, 
                                                         allow_restrict=False, formatting=False)
            completion_categories['options'] = self.list_completion(text,['--modelname=','--recreate','--fock_states_only'])
            return self.deal_multiple_categories(completion_categories, formatting) 
            
    def complete_explain_restriction(self, text, line, begidx, endidx):
        """Complete the explain_restriction command: a restriction card of the
        current model, or a MODEL-RESTRICTION name.

        Every candidate must start with text: when the word being completed
        contains a '-', the readline wrapper strips that common prefix off each
        of them, so one which does not share it comes back mangled (a
        'loop_qcd_qed_sm' proposed for 'loop_sm-' would show up as '_qed_sm')."""

        args = [arg for arg in self.split_arg(line[0:begidx]) if arg != '--all']
        if len(args) > 1:
            return self.list_completion(text, ['--all'], line)

        if '-' in text and not text.startswith('-'):
            # the restrictions of a given model ('--all' also has a '-')
            model = text.rsplit('-', 1)[0]
            out = self.find_restrict_card(model, no_restrict=False)
            out += self.find_restrict_card(model, no_restrict=False,
                                           base_dir=pjoin(MG5DIR, 'models'))
        else:
            out = ['--all']
            if self._curr_model:
                model_path = self._curr_model.get('modelpath')
                out += [name for name in os.listdir(model_path)
                        if name.startswith('restrict_') and name.endswith('.dat')]
            model_dir = pjoin(MG5DIR, 'models')
            out += [name for name in os.listdir(model_dir)
                    if os.path.exists(pjoin(model_dir, name, 'couplings.py'))]

        return self.list_completion(text, misc.make_unique(out), line)

    def complete_customize_model(self, text, line, begidx, endidx):
        "Complete the customize_model command"

        args = self.split_arg(line[0:begidx])

        # Format
        return self.list_completion(text, ['--save=', '--explain',
                    '--explain=life', '--explain=final', '--explain=off',
                    '--all'])


    def complete_check(self, text, line, begidx, endidx, formatting=True):
        "Complete the check command"

        out = {}
        args = self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            return self.list_completion(text, self._check_opts)

        if len(args) >= 2 and args[1] == 'precision' and \
                all(a in process_checks.PRECISION_MODES for a in args[2:]):
            remaining = [m for m in process_checks.PRECISION_MODES if m not in args[2:]]
            if len(args) == 2:
                return self.list_completion(text, remaining)
            return self.deal_multiple_categories(
                {'Precision modes': self.list_completion(text, remaining),
                 'Process completion': self.model_completion(text, '', line,
                                                  categories=False)}, formatting)

        cms_check_mode = len(args) >= 2 and args[1]=='cms'

        cms_options = ['--name=','--tweak=','--seed=','--offshellness=',
          '--lambdaCMS=','--show_plot=','--report=','--lambda_plot_range=','--recompute_width=',
          '--CTModeRun=','--helicity=','--reduction=','--cms=','--diff_lambda_power=',
          '--loop_filter=','--resonances=']

        options = ['--energy=']
        if len(args) >= 2 and args[1] in ('timing', 'profile', 'stability'):
            options.extend(['--loop_pole_mode=', '--tirust_finite=', '--tirust_cache=',
                            '--tirust_cache_max_bytes=', '--tirust_qp_integrand='])
        if len(args) >= 2 and args[1] == 'precision':
            options.extend(['--nb_event=', '--backend='])
        if cms_options:
            options.extend(cms_options)

        # Directory continuation
        if args[-1].endswith(os.path.sep):
            return self.path_completion(text, pjoin(*[a for a in args \
                                                    if a.endswith(os.path.sep)]))
        # autocompletion for particles/couplings
        model_comp = self.model_completion(text, ' '.join(args[2:]),line,
                                  categories = True, allowed_loop_mode=['virt'])

        model_comp_and_path = self.deal_multiple_categories(\
          {'Process completion': self.model_completion(text, ' '.join(args[2:]),
          line, categories = False, allowed_loop_mode=['virt']),
          'Param_card.dat path completion:':self.path_completion(text),
          'options': self.list_completion(text,options)}, formatting)

        #Special rules for check cms completion
        if cms_check_mode:
            # A couple of useful value completions
            if line[-1]!=' ' and line[-2]!='\\' and not '--' in line[begidx:endidx] \
                              and args[-1].startswith('--') and '=' in args[-1]:
                examples = {
                  '--tweak=':
['default','alltweaks',"['default','allwidths->1.1*all_withds&seed333(Increased_widths_and_seed_333)','logp->logm&logm->logp(inverted_logs)']"],
                  '--lambdaCMS=':
['(1.0e-2,5)',"[float('1.0e-%d'%exp)\\ for\\ exp\\ in\\ range(8)]","[1.0,0.5,0.001]"],
                  '--lambda_plot_range=':
[' [1e-05,1e-02]','[0.01,1.0]'],
                  '--reduction=':
['1','1|2|3|4','1|2','3'],
                  '--cms=':
['QED&QCD,aewm1->10.0/lambdaCMS&as->0.1*lambdaCMS',
'NP&QED&QCD,aewm1->10.0/lambdaCMS&as->0.1*lambdaCMS&newExpansionParameter->newExpansionParameter*lambdaCMS'],
                  '--loop_filter=':
['None','n>3','n<4 and 6 in loop_pdgs and 3<=id<=7'],
                  '--resonances=':
['1','all','(24,(3,4))','[(24,(3,4)),(24,(4,5))]'],
                  '--analyze=':
['my_default_run.pkl',
'default_run.pkl,increased_widths.pkl(Increased_widths),logs_modified.pkl(Inverted_logs),seed_668.pkl(Different_seed)']
                    }
                for name, example in examples.items():
                    if  args[-1].startswith(name):
                        return self.deal_multiple_categories(
          {"Examples of completion for option '%s'"%args[-1].split('=')[0]:
#                    ['%d: %s'%(i+1,ex) for i, ex in enumerate(example)]},
                    ['%s'%ex for i, ex in enumerate(example)]},formatting,
                                                             forceCategory=True)
                if args[-1]=='--recompute_width=':
                    return self.list_completion(text,
                                         ['never','first_time','always','auto'])
                elif args[-1]=='--show_plot=':
                    return self.list_completion(text,['True','False'])
                elif args[-1]=='--report=':
                    return self.list_completion(text,['concise','full'])
                elif args[-1]=='--CTModeRun=':
                    return self.list_completion(text,['-1','1','2','3','4'])
                else:
                    return text
            if len(args)==2 or len(args)==3 and args[-1]=='-reuse':
                return self.deal_multiple_categories(
          {'Process completion': self.model_completion(text, ' '.join(args[2:]),
                        line, categories = False, allowed_loop_mode=['virt']),
                   'Param_card.dat path completion:': self.path_completion(text),
               'reanalyze result on disk / save output:':self.list_completion(
                                                  text,['-reuse','--analyze='])},
                                                     formatting)
            elif not any(arg.startswith('--') for arg in args):
                if '>' in args:
                    return self.deal_multiple_categories({'Process completion': 
                        self.model_completion(text, ' '.join(args[2:]),
                        line, categories = False, allowed_loop_mode=['virt']),
                        'options': self.list_completion(text,options)},
                                                         formatting)
                else:
                    return self.deal_multiple_categories({'Process completion': 
                        self.model_completion(text, ' '.join(args[2:]),
                        line, categories = False, allowed_loop_mode=['virt'])},
                                                         formatting)
            else:
                return self.list_completion(text,options)
            
        if len(args) == 2:
            return model_comp_and_path
        elif len(args) == 3:
            try:
                int(args[2])
            except ValueError:
                return model_comp
            else:
                return model_comp_and_path
        elif len(args) > 3:
            return model_comp


    def complete_tutorial(self, text, line, begidx, endidx):
        "Complete the tutorial command"

        # Format
        if len(self.split_arg(line[0:begidx])) == 1:
            return self.list_completion(text, self._tutorial_opts)

    def complete_define(self, text, line, begidx, endidx):
        """Complete particle information"""
        return self.model_completion(text, line[6:],line)

    def complete_display(self, text, line, begidx, endidx):
        "Complete the display command"

        args = self.split_arg(line[0:begidx])
        # Format
        if len(args) == 1:
            return self.list_completion(text, self._display_opts)

        if len(args) == 2 and args[1] == 'checks':
            return self.list_completion(text, ['failed'])

        if len(args) == 2 and args[1] == 'particles':
            return self.model_completion(text, line[begidx:],line)

    def complete_draw(self, text, line, begidx, endidx):
        "Complete the draw command"

        args = self.split_arg(line[0:begidx])

        # Directory continuation
        if args[-1].endswith(os.path.sep):
            return self.path_completion(text,
                                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                                        only_dirs = True)
        # Format
        if len(args) == 1:
            return self.path_completion(text, '.', only_dirs = True)


        #option
        if len(args) >= 2:
            opt = ['horizontal', 'external=', 'max_size=', 'add_gap=',
                                'non_propagating', '--']
            return self.list_completion(text, opt)

    def find_launch_mode(self, args):
        """identify the output type of the directory a launch command operates
        on, so that complete_launch can propose mode-specific options.
        Returns the mode (as returned by find_output_type) or None when it
        cannot be determined (e.g. no directory given yet)."""

        # locate the directory argument (first non-option argument after launch)
        path = None
        for arg in args[1:]:
            if arg.startswith('-'):
                continue
            candidates = [arg, pjoin(MG5DIR, arg)]
            if MG4DIR:
                candidates.append(pjoin(MG4DIR, arg))
            for candidate in candidates:
                if os.path.isdir(candidate):
                    path = os.path.realpath(candidate)
                    break
            if path:
                break

        # fall back to the latest exported directory (default launch target)
        if path is None and self._done_export:
            path = self._done_export[0]

        if path is None:
            return None

        try:
            return self.find_output_type(path)
        except Exception:
            return None

    def complete_launch(self, text, line, begidx, endidx,formatting=True):
        """ complete the launch command"""
        args = self.split_arg(line[0:begidx])

        # Directory continuation
        if args[-1].endswith(os.path.sep):
            return self.path_completion(text,
                                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                                        only_dirs = True)
        # Format
        if len(args) == 1:
            out = {'Path from ./': self.path_completion(text, '.', only_dirs = True)}
            if MG5DIR != os.path.realpath('.'):
                out['Path from %s' % MG5DIR] =  self.path_completion(text,
                                     MG5DIR, only_dirs = True, relative=False)
            if MG4DIR and MG4DIR != os.path.realpath('.') and MG4DIR != MG5DIR:
                out['Path from %s' % MG4DIR] =  self.path_completion(text,
                                     MG4DIR, only_dirs = True, relative=False)


        #option
        if len(args) >= 2:
            out={}

        mode = self.find_launch_mode(args)

        if mode and mode.startswith('standalone') and mode != 'standalone':
            # NB: `mode != 'standalone'` deliberately EXCLUDES the plain
            # `standalone` (madmatrix) output, which is launched through
            # MadMatrixLauncher, not through SALauncher.  It is not a typo:
            # every *other* standalone_* mode (standalone_fortran, _cpp, _msP,
            # _msF, _rw) is run through SALauncher/MadLoopLauncher, for which
            # only force + the timing analysis options are relevant.
            opt = ['-f', '--force', '--timings=', '--nb_run=']
            out['Options'] = self.list_completion(text, opt, line)
        elif mode == 'standalone':
            opt = ['-f', '--force']
            out['Options'] = self.list_completion(text, opt, line)
        elif line[0:begidx].endswith('--laststep='):
            opt = ['parton', 'pythia', 'pgs','delphes','auto']
            out['Options'] = self.list_completion(text, opt, line)
        else:
            opt = ['--cluster', '--multicore', '-i', '--name=', '-f','-m', '-n',
               '--interactive', '--laststep=parton', '--laststep=pythia',
               '--laststep=pgs', '--laststep=delphes','--laststep=auto']
            if mode == 'aMC@NLO':
                # parton-level run (-p/--parton) is an (a)MC@NLO-only option
                opt += ['-p', '--parton']
            out['Options'] = self.list_completion(text, opt, line)


        return self.deal_multiple_categories(out,formatting)

    def complete_load(self, text, line, begidx, endidx):
        "Complete the load command"

        args = self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            return self.list_completion(text, self._save_opts)

        # Directory continuation
        if args[-1].endswith(os.path.sep):
            return self.path_completion(text,
                                        pjoin(*[a for a in args if \
                                                      a.endswith(os.path.sep)]))

        # Filename if directory is not given
        if len(args) == 2:
            return self.path_completion(text)

    def complete_save(self, text, line, begidx, endidx):
        "Complete the save command"

        args = self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            return self.list_completion(text, self._save_opts)

        # Directory continuation
        if args[-1].endswith(os.path.sep):
            return self.path_completion(text,
                                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                                        only_dirs = True)

        # Filename if directory is not given
        if len(args) == 2:
            return self.path_completion(text) + self.list_completion(text, ['global'])

    @cmd.debug()
    def complete_open(self, text, line, begidx, endidx):
        """ complete the open command """

        args = self.split_arg(line[0:begidx])

        # Directory continuation
        if os.path.sep in args[-1] + text:
            return self.path_completion(text,
                                    pjoin(*[a for a in args if \
                                                      a.endswith(os.path.sep)]))

        possibility = []
        if self._done_export:
            path = self._done_export[0]
            possibility = ['index.html']
            if os.path.isfile(pjoin(path,'README')):
                possibility.append('README')
            if os.path.isdir(pjoin(path,'Cards')):
                possibility += [f for f in os.listdir(pjoin(path,'Cards'))
                                    if f.endswith('.dat')]
            if os.path.isdir(pjoin(path,'HTML')):
                possibility += [f for f in os.listdir(pjoin(path,'HTML'))
                                  if f.endswith('.html') and 'default' not in f]
        else:
            possibility.extend(['./','../'])
        if os.path.exists('MG5_debug'):
            possibility.append('MG5_debug')
        if os.path.exists('ME5_debug'):
            possibility.append('ME5_debug')

        return self.list_completion(text, possibility)

    @cmd.debug()
    def complete_output(self, text, line, begidx, endidx,
                        possible_options = ['f', 'noclean', 'nojpeg'],
                        possible_options_full = ['-f', '-noclean', '-nojpeg', '--noeps=True','--hel_recycling=False',
                                                 '--jamp_optim=', '--jamp_orbit=', '--t_strategy=', '--vector_size=4', '--nb_warp=1',
                                                 '--mask=False', '--prefix=', '--axial_gauge=True']):
        "Complete the output command"

        possible_format = list(self._export_formats)
        possible_format += misc.from_plugin_import(self.plugin_path, 'new_output', keyname=None, warning=False,
                       info=None)
        #don't propose directory use by MG_ME
        forbidden_names = ['MadGraphII', 'Template', 'pythia-pgs', 'CVS',
                            'Calculators', 'MadAnalysis', 'SimpleAnalysis',
                            'mg5', 'DECAY', 'EventConverter', 'Models',
                            'ExRootAnalysis', 'HELAS', 'Transfer_Fct', 'aloha',
                            'matchbox', 'matchbox_cpp', 'tests', 'launch']

        #name of the run =>proposes old run name
        args = self.split_arg(line[0:begidx])
        if len(args) >= 1:
            
            if len(args) > 1 and args[1] == 'pythia8':
                possible_options_full = list(possible_options_full) + ['--version=8.1','--version=8.2'] 
            
            if len(args) > 1 and args[1] == 'aloha':
                try:
                    return self.aloha_complete_output(text, line, begidx, endidx)
                except Exception as error:
                    print(error)
            if 'standalone_fortran' in args:
                possible_options_full = list(possible_options_full) + ['--prefix=int', '--prefix=proc', '--density=', '--zerowidth_decay=']

            # Directory continuation
            if args[-1].endswith(os.path.sep):
                return [name for name in self.path_completion(text,
                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                        only_dirs = True) if name not in forbidden_names]
            # options
            if args[-1][0] == '-' or len(args) > 1 and args[-2] == '-':
                return self.list_completion(text, possible_options)
            
            if len(args) > 2:
                return self.list_completion(text, possible_options_full)
            # Formats
            if len(args) == 1:
                format = possible_format + ['.' + os.path.sep, '..' + os.path.sep, 'auto']
                return self.list_completion(text, format)

            # directory names
            content = [name for name in self.path_completion(text, '.', only_dirs = True) \
                       if name not in forbidden_names]
            content += ['auto']
            content += possible_options_full
            return self.list_completion(text, content)

    def aloha_complete_output(self, text, line, begidx, endidx,formatting=True):
        "Complete the output aloha command"
        args = self.split_arg(line[0:begidx])
        completion_categories = {}

        forbidden_names = ['MadGraphII', 'Template', 'pythia-pgs', 'CVS',
                            'Calculators', 'MadAnalysis', 'SimpleAnalysis',
                            'mg5', 'DECAY', 'EventConverter', 'Models',
                            'ExRootAnalysis', 'Transfer_Fct', 'aloha',
                            'apidoc','vendor']


        # options
        options = ['--format=Fortran', '--format=Python','--format=gpu','--format=CPP','--output=']
        options = self.list_completion(text, options)
        if options:
            completion_categories['options'] = options

        if args[-1] == '--output=' or args[-1].endswith(os.path.sep):
            # Directory continuation
            completion_categories['path'] =  [name for name in self.path_completion(text,
                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                        only_dirs = True) if name not in forbidden_names]

        else:
            ufomodel = ufomodels.load_model(self._curr_model.get('name'))
            wf_opt = []
            amp_opt = []
            opt_conjg = []
            for lor in ufomodel.all_lorentz:
                amp_opt.append('%s_0' % lor.name)
                for i in range(len(lor.spins)):
                    wf_opt.append('%s_%i' % (lor.name,i+1))
                    if i % 2 == 0 and lor.spins[i] == 2:
                        opt_conjg.append('%sC%i_%i' % (lor.name,i //2 +1,i+1))
            completion_categories['amplitude routines'] = self.list_completion(text, amp_opt)
            completion_categories['Wavefunctions routines'] = self.list_completion(text, wf_opt)
            completion_categories['conjugate_routines'] = self.list_completion(text, opt_conjg)

        return self.deal_multiple_categories(completion_categories,formatting)

    def complete_set(self, text, line, begidx, endidx):
        "Complete the set command"
        #misc.sprint([text,line,begidx, endidx])
        args = self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            opts = misc.make_unique(list(self.options.keys()) + self._set_options)
            return self.list_completion(text, opts)

        if len(args) == 2:
            if args[1] in ['complex_mass_scheme',\
                           'loop_optimized_output', 'loop_color_flows',\
                           'include_lepton_initiated_processes',\
                           'low_mem_multicore_nlo_generation', 'nlo_mixed_expansion']:
                return self.list_completion(text, ['False', 'True', 'default'])
            elif args[1] in ['group_subprocesses']:
                return self.list_completion(text, ['False', 'True', 'Auto', 'gpu', 'nlo'])
            elif args[1] in ['ignore_six_quark_processes']:
                return self.list_completion(text, list(self._multiparticles.keys()))
            elif args[1].lower() == 'ewscheme':
                return self.list_completion(text, ["external", "MZ_MW_alpha"])
            elif args[1] == 'gauge':
                return self.list_completion(text, ['unitary', 'Feynman','default', 'axial', 'FD'])
            elif args[1] == 'OLP':
                return self.list_completion(text, MadGraphCmd._OLP_supported)
            elif args[1] == 'output_dependencies':
                return self.list_completion(text, 
                                     MadGraphCmd._output_dependencies_supported)
            elif args[1] == 'stdout_level':
                return self.list_completion(text, ['DEBUG','INFO','WARNING','ERROR',
                                                          'CRITICAL','default'])
            elif args[1] == 'fortran_compiler':
                return self.list_completion(text, ['f77','g77','gfortran','default'])
            elif args[1] == 'cpp_compiler':
                return self.list_completion(text, ['g++', 'c++', 'clang', 'default'])
            elif args[1] in ['nb_core', 'nb_core_pythia8', 'nb_core_delphes']:
                return self.list_completion(text, [str(i) for i in range(100)] + ['default'] )
            elif args[1] == 'run_mode':
                return self.list_completion(text, [str(i) for i in range(3)] + ['default'])
            elif args[1] == 'cluster_type':
                return self.list_completion(text, list(cluster.from_name.keys()) + ['default'])
            elif args[1] in ['cluster_queue', 'cluster_walltime',\
                             'cluster_requirement', 'cluster_vacatetime']:
                return []
            elif args[1] == 'automatic_html_opening':
                return self.list_completion(text, ['False', 'True', 'default'])
            else:
                # directory names
                second_set = [name for name in self.path_completion(text, '.', only_dirs = True)]
                return self.list_completion(text, second_set + ['default'])
        elif len(args) >2 and args[-1].endswith(os.path.sep):
                return self.path_completion(text,
                        pjoin(*[a for a in args if a.endswith(os.path.sep)]),
                        only_dirs = True)
        
    def complete_import(self, text, line, begidx, endidx, allow_restrict=True,
                        formatting=True):
        "Complete the import command"

        args=self.split_arg(line[0:begidx])

        # Format
        if len(args) == 1:
            opt =  self.list_completion(text, self._import_formats)
            if opt:
                return opt
            mode = 'all'
        elif args[1] in self._import_formats:
            mode = args[1]
        else:
            args.insert(1, 'all')
            mode = 'all'

        completion_categories = {}
        # restriction continuation (for UFO)
        if mode in ['model', 'all'] and '-' in  text:
            # deal with - in readline splitting (different on some computer)
            path = '-'.join([part for part in text.split('-')[:-1]])
            # remove the final - for the model name
            # find the different possibilities
            all_name = self.find_restrict_card(path, no_restrict=False)
            all_name += self.find_restrict_card(path, no_restrict=False,
                                        base_dir=pjoin(MG5DIR,'models'))

            if os.environ['PYTHONPATH']:
                for modeldir in os.environ['PYTHONPATH'].split(':'):
                    if not modeldir:
                            continue
                    all_name += self.find_restrict_card(path, no_restrict=False,
                                        base_dir=modeldir)
            all_name = misc.make_unique(all_name)
            # select the possibility according to the current line
            all_name = [name+' ' for name in  all_name if name.startswith(text)
                                                       and name.strip() != text]


            if all_name:
                completion_categories['Restricted model'] = all_name

        # Path continuation
        if os.path.sep in args[-1]:
            if mode.startswith('model') or mode == 'all':
                # Directory continuation
                try:
                    cur_path = pjoin(*[a for a in args \
                                                   if a.endswith(os.path.sep)])
                except Exception as error:
                    pass
                else:
                    all_dir = self.path_completion(text, cur_path, only_dirs = True)
                    if mode in ['model_v4','all']:
                        completion_categories['Path Completion'] = all_dir
                    # Only UFO model here
                    new = []
                    data =   [new.__iadd__(self.find_restrict_card(name, base_dir=cur_path, online=False))
                                                                for name in all_dir]
                    if data:
                        completion_categories['Path Completion'] = all_dir + new
            else:
                try:
                    cur_path = pjoin(*[a for a in args \
                                                   if a.endswith(os.path.sep)])
                except Exception:
                    pass
                else:
                    all_path =  self.path_completion(text, cur_path)
                    if mode == 'all':
                        new = []
                        data =   [new.__iadd__(self.find_restrict_card(name, base_dir=cur_path, online=False))
                                                               for name in all_path]
                        if data:
                            completion_categories['Path Completion'] = data[0]
                    else:
                        completion_categories['Path Completion'] = all_path

        # Model directory name if directory is not given
        if (len(args) == 2):
            is_model = True
            if mode == 'model':
                file_cond = lambda p : os.path.exists(pjoin(MG5DIR,'models',p,'particles.py'))
                mod_name = lambda name: name
            elif mode == 'model_v4':
                file_cond = lambda p :  (os.path.exists(pjoin(MG5DIR,'models',p,'particles.dat'))
                                      or os.path.exists(pjoin(self._mgme_dir,'Models',p,'particles.dat')))
                mod_name = lambda name :(name[-3:] != '_v4' and name or name[:-3])
            elif mode == 'all':
                mod_name = lambda name: name
                file_cond = lambda p : os.path.exists(pjoin(MG5DIR,'models',p,'particles.py')) \
                                      or os.path.exists(pjoin(MG5DIR,'models',p,'particles.dat')) \
                                      or os.path.exists(pjoin(self._mgme_dir,'Models',p,'particles.dat'))
            else:
                cur_path = pjoin(*[a for a in args \
                                                   if a.endswith(os.path.sep)])
                all_path =  self.path_completion(text, cur_path)
                completion_categories['model name'] = all_path
                is_model = False

            if is_model and os.path.sep not in text:
                model_list = [mod_name(name) for name in \
                                                self.path_completion(text,
                                                pjoin(MG5DIR,'models'),
                                                only_dirs = True) \
                                                if file_cond(name)]
                if mode == 'model' and 'PYTHONPATH' in os.environ:
                    for modeldir in os.environ['PYTHONPATH'].split(':'):
                        if not modeldir or not os.path.exists(modeldir):
                            continue
                        model_list += [name for name in self.path_completion(text,
                                       modeldir, only_dirs=True)
                                       if os.path.exists(pjoin(modeldir,name, 'particles.py'))]                    
                if mode == 'model':
                    model_list += [name for name in list(self._online_model.keys())+self._online_model2
                                    if name.startswith(text)]
                    
                if mode == 'model_v4':
                    completion_categories['model name'] = model_list
                elif allow_restrict:
                    # need to update the  list with the possible restriction
                    all_name = []
                    for model_name in model_list:
                        all_name += self.find_restrict_card(model_name,
                                            base_dir=pjoin(MG5DIR,'models'))
                else:
                    all_name = model_list
                
                #avoid duplication
                all_name = misc.make_unique(all_name)
                
                if mode == 'all':
                    cur_path = pjoin(*[a for a in args \
                                                        if a.endswith(os.path.sep)])
                    all_path =  self.path_completion(text, cur_path)
                    completion_categories['model name'] = all_path + all_name
                elif mode == 'model':
                    completion_categories['model name'] = all_name
            elif os.path.sep in text:
                try:
                    cur_path = pjoin(*[a for a in args \
                                            if a.endswith(os.path.sep)])
                except Exception:
                    cur_path = os.getcwd()
                all_path =  self.path_completion(text, cur_path)                
                completion_categories['model name'] = all_path 

        # Options
        if mode == 'all' and len(args)>1:
            mode = self.find_import_type(args[2])

        if len(args) >= 3 and mode.startswith('model') and not '-modelname' in line:
            if not text and not completion_categories:
                return ['--modelname']
            elif not (os.path.sep in args[-1] and line[-1] != ' '):
                completion_categories['options'] = self.list_completion(text, ['--modelname','-modelname','--noprefix'])
        if len(args) >= 3 and mode.startswith('banner') and not '--no_launch' in line:
            completion_categories['options'] = self.list_completion(text, ['--no_launch'])
        
        return self.deal_multiple_categories(completion_categories,formatting)
    
    _online_model = {'2HDM':[], 
                         'loop_qcd_qed_sm':['full','no_widths','with_b_mass ', 'with_b_mass_no_widths'],
                         'loop_qcd_qed_sm_Gmu':['ckm', 'full', 'no_widths'], 
                         '4Gen':[],
                         'DY_SM':[],
                         'EWdim6':['full'],
                         'heft':['ckm','full', 'no_b_mass','no_masses','no_tau_mass','zeromass_ckm'],
                         'nmssm':['full'],
                         'SMScalars':['full'],
                         'RS':[''],
                         'sextet_diquarks':[''],
                         'TopEffTh':[''],
                         'triplet_diquarks':[''],
                         'uutt_sch_4fermion':[''],
                         'uutt_tch_scalar':['']
                         }   
    _online_model2 = [] # fill by model on the db if user do "display modellist" 
    
    def find_restrict_card(self, model_name, base_dir='./', no_restrict=True,
                           online=True):
        """find the restriction file associate to a given model"""

        # check if the model_name should be keeped as a possibility
        if no_restrict:
            output = [model_name]
        else:
            output = []

        local_model = os.path.exists(pjoin(base_dir, model_name, 'couplings.py'))
        # check that the model is a valid model
        if online and not local_model and model_name in self._online_model:
            output += ['%s-%s' % (model_name, tag) for tag in self._online_model[model_name]]
            return output  
        
        if not local_model:
            # not valid UFO model
            return output

        if model_name.endswith(os.path.sep):
            model_name = model_name[:-1]

        # look for _default and treat this case
        if os.path.exists(pjoin(base_dir, model_name, 'restrict_default.dat')):
            output.append('%s-full' % model_name)

        # look for other restrict_file
        for name in os.listdir(pjoin(base_dir, model_name)):
            if name.startswith('restrict_') and not name.endswith('default.dat') \
                and name.endswith('.dat'):
                tag = name[9:-4] #remove restrict and .dat
                while model_name.endswith(os.path.sep):
                    model_name = model_name[:-1]
                output.append('%s-%s' % (model_name, tag))

        # return
        return output

    def complete_install(self, text, line, begidx, endidx):
        "Complete the import command"

        args = self.split_arg(line[0:begidx])
        # Format
        if len(args) == 1:
            return self.list_completion(text, sorted(set(self._install_opts) | set(self._advanced_install_opts)))
        elif len(args) and args[0] == 'update':
            return self.list_completion(text, ['-f','--timeout='])
        elif len(args) >= 2 and args[1] == 'tirust':
            return self.list_completion(text, ['--source=', '--oneloop-source=',
                '--prefix=', '--jobs=', '--update', '--force'])
        elif len(args) >= 2 and args[1] == 'madspace':
            options = ['-y', '--yes', '--bin', '--source',
                       '--cuda', '--no-cuda', '--hip', '--no-hip',
                       '--openblas', '--no-openblas',
                       '--simd', '--no-simd',
                       '--debug', '--full-debug', '--no-debug',
                       '--cuda-arch=', '--hip-arch=']
            for opt in options[:]:
                if any(a.startswith(opt) for a in args[2:]):
                    options.remove(opt)
            return self.list_completion(text, options)
        elif len(args)>=2 and args[1] in self._advanced_install_opts:
            options = ['--keep_source','--logging=']
            if args[1]=='pythia8':
                options.append('--pythia8_tarball=')
                options.append('--hepmc2')
            elif args[1] in ['MadAnalysis5','MadAnalysis']:
                #options.append('--no_MA5_further_install')
                options.append('--no_root_in_MA5')
                options.append('--update')
                options.append('--madanalysis5_tarball=')
                for prefix in ['--with', '--veto']:
                    for prog in ['fastjet', 'delphes', 'delphesMA5tune']:
                        options.append('%s_%s' % (prefix, prog))
                         
            for opt in options[:]:
                if any(a.startswith(opt) for a in args):
                    options.remove(opt)
            return self.list_completion(text, options)
        else:
            return self.list_completion(text, [])

#===============================================================================
# MadGraphCmd
#===============================================================================
class MadGraphCmd(HelpToCmd, CheckValidForCmd, CompleteForCmd, CmdExtended):
    """The command line processor of MadGraph"""

    writing_dir = '.'

    # Options and formats available
    _display_opts = ['particles', 'interactions', 'processes', 'diagrams',
                     'diagrams_text', 'multiparticles', 'couplings', 'lorentz',
                     'checks', 'parameters', 'options', 'coupling_order','variable',
                     'modellist', 'fockstates', 'boundstates']
    _add_opts = ['process', 'model']
    _save_opts = ['model', 'processes', 'options']
    # commands the running tutorial provides, also accepted as `tutorial X`:
    # people reach for `tutorial hint` as readily as `hint`
    _tutorial_step_cmds = ('hint', 'solution', 'next', 'repeat', 'back', 'skip')

    @property
    def _tutorial_opts(self):
        """Names 'tutorial' accepts: every tutorial, its aliases, and the
        housekeeping sub-commands."""
        return (tutorials.names(include_aliases=True) +
                ['stop', 'list', 'status', 'index', 'help'] +
                list(self._tutorial_step_cmds))
    _switch_opts = ['mg5','aMC@NLO','ML5']
    _check_opts = ['full', 'timing', 'stability', 'profile', 'permutation',
                   'gauge','lorentz', 'brs', 'cms', 'flavor', 'language',
                   'precision']
    _import_formats = ['model_v4', 'model', 'proc_v4', 'command', 'banner']
    _install_opts = ['Delphes', 'ExRootAnalysis',
                     'update', 'Golem95', 'QCDLoop', 'maddm', 'maddump',
                     'looptools', 'cuttools_iregi', 'MadSTR', 'RunningCoupling',
                     'madspace', 'ninjars', 'tirust']
    
    # The targets below are installed using the HEPToolsInstaller.py script
    _advanced_install_opts = ['pythia8','zlib','boost','lhapdf6','lhapdf5','collier',
                              'hepmc','ninja','oneloop','MadAnalysis5',
                              'yoda', 'rivet', 'fastjet', 'fjcontrib', 'contur', 'cmake', 'eMELA',
                              'cudacpp', 'hepmc3', 'pythia8_hepmc3', 'DMTCP']

    _install_opts.extend(_advanced_install_opts)

    # the only outputs with templates projecting bound-state constituents
    _onia_formats = ['madevent', 'standalone_fortran']
    _v4_export_formats = ['madevent', 'standalone_fortran', 'standalone_msP','standalone_msF',
                          'matrix', 'standalone_rw']
    _export_formats = _v4_export_formats + ['aloha',
                                            'matchbox_cpp', 'matchbox', 'mg7_v5', 'mg7',
                                            'standalone']
    _set_options = ['group_subprocesses',
                    'ignore_six_quark_processes',
                    'stdout_level',
                    'fortran_compiler',
                    'cpp_compiler',
                    'loop_optimized_output',
                    'complex_mass_scheme',
                    'include_lepton_initiated_processes',
                    'gauge',
                    'EWscheme',
                    'max_npoint_for_channel',
                    'max_t_for_channel',
                    'zerowidth_tchannel',
                    'default_unset_couplings',
                    'nlo_mixed_expansion',
                    'color_basis',
                    'merge_same_topologies',
                    'merge_quartic_vertices'
                    ]
    _valid_color_basis = ['auto', 'trace', 'ddm']
    _valid_nlo_modes = ['all','real','virt','sqrvirt','tree','noborn','LOonly', 'only',
                        'LIxtree']
    _valid_sqso_types = ['==','<=','=','>']
    _valid_amp_so_types = ['=','<=', '==', '>']
    _OLP_supported = ['MadLoop', 'GoSam']
    _output_dependencies_supported = ['external', 'internal','environment_paths']

    # The three options categories are treated on a different footage when a
    # set/save configuration occur. current value are kept in self.options
    options_configuration = {'pythia8_path': './HEPTools/pythia8',
                       'hwpp_path': './herwigPP',
                       'thepeg_path': './thepeg',
                       'hepmc_path': './hepmc',
                       'hepmc3_path': './HEPTools/hepmc3',
                       'madanalysis5_path':'./HEPTools/madanalysis5/madanalysis5',
                       'pythia-pgs_path':'./pythia-pgs',
                       'rivet_path' : './HEPTools/rivet',
                       'yoda_path' : './HEPTools/yoda',
                       'contur_path' : './HEPTools/contur',
                       'delphes_path':'./Delphes',
                       'exrootanalysis_path':'./ExRootAnalysis',
                       'syscalc_path': './SysCalc',
                       'timeout': 60,
                       'web_browser':None,
                       'eps_viewer':None,
                       'use_pigz':None,
                       'text_editor':None,
                       'fortran_compiler':None,
                       'f2py_compiler':None,
                       'f2py_compiler_py2':None,
                       'f2py_compiler_py3':None,
                       'cpp_compiler':None,
                       'checkpointing': False,
                       'cluster_type': 'condor',
                       'cluster_queue': None,
                       'cluster_status_update': (600, 30),
                       'cluster_walltime': None,
                       'cluster_requirement': None,
                       'cluster_vacatetime': '120',
                       'enforce_shared_disk': False,
                       'fastjet':'fastjet-config',
                       'eMELA':'eMELA-config',
                       'golem':'auto',
                       'samurai':None,
                       'ninja':'./HEPTools/lib',
                       'ninjars':None,
                       'tirust':None,
                       'collier':'./HEPTools/lib',
                       'dmtcp': None,
                       'lhapdf':'lhapdf-config',
                       'pineappl':'pineappl',
                       'lhapdf_py2': None,
                       'lhapdf_py3': None,
                       'cluster_temp_path':None,
                       'cluster_local_path': None,
                       'cvmfs_lhapdf_path': misc.CVMFS_LHAPDF_PATH,
                       'OLP': 'MadLoop',
                       'cluster_nb_retry':1,
                       'cluster_retry_wait':300,
                       'cluster_size':100,
                       'output_dependencies':'external',
                       'crash_on_error':False,
                       'auto_convert_model': True,
                       'acknowledged_v3.1_syntax': True,
                       'auto_update':7,
                       'heptools_install_dir': './HEPTools',
                       'plain': False,
                       }

    options_madgraph= {'group_subprocesses': 'Auto',
                          'ignore_six_quark_processes': False,
                          'low_mem_multicore_nlo_generation': False,
                          'complex_mass_scheme': False,
                          'include_lepton_initiated_processes': False,
                          'gauge':'unitary',
                          'stdout_level':None,
                          'loop_optimized_output':True,
                          'loop_color_flows':False,
                          'max_npoint_for_channel': 0, # 0 means automatically adapted
                          'default_unset_couplings': 99, # 99 means infinity
                          'max_t_for_channel': 99, # means no restrictions
                          'zerowidth_tchannel': True,
                          'nlo_mixed_expansion':True,
                          'apply_flavor_grouping': True,
                          'color_basis': 'auto',
                          'merge_same_topologies': True,
                          'merge_quartic_vertices': False
                        }

    options_madevent = {'automatic_html_opening':True,
                         'run_mode':2,
                         'nb_core': None,
                         'nb_core_pythia8': None,
                         'nb_core_delphes': None,
                         'notification_center': True
                         }


    # Variables to store object information
    _curr_model = None  #base_objects.Model()
    _curr_amps = diagram_generation.AmplitudeList()
    _curr_proc_defs = base_objects.ProcessDefinitionList()
    _curr_matrix_elements = helas_objects.HelasMultiProcess()
    _curr_helas_model = None
    _curr_exporter = None
    _second_exporter = None
    _done_export = False
    _curr_decaymodel = None

    helporder = ['Main commands', 'Documented commands']


    def preloop(self):
        """Initializing before starting the main loop"""

        self.prompt = MG7_PROMPT_TEXT if self.options.get('plain') else MG7_PROMPT
        if madgraph.ReadWrite: # prevent on read-only disk
            self.do_install('update --mode=mg5_start')

        # By default, load the UFO Standard Model
        logger.info("Loading default model: sm")
        self.exec_cmd('import model sm', printcmd=False, precmd=True)

        # preloop mother
        CmdExtended.preloop(self)


    def __init__(self, mgme_dir = '', *completekey, **stdin):
        """ add a tracker of the history """

        CmdExtended.__init__(self, *completekey, **stdin)

        # Set MG/ME directory path
        if mgme_dir:
            if os.path.isdir(pjoin(mgme_dir, 'Template')):
                self._mgme_dir = mgme_dir
                logger.info('Setting MG/ME directory to %s' % mgme_dir)
            else:
                logger.warning('Warning: Directory %s not valid MG/ME directory' % \
                             mgme_dir)
                self._mgme_dir = MG4DIR

        # check that make_opts exists
        # This file is shared by every MadGraph7 process running from this
        # installation: it is copied verbatim into each new output directory and
        # rewritten in place by set_fortran_compiler/set_cpp_compiler. Replacing
        # it by rename (atomic_copy) rather than by shutil.copy is what keeps a
        # concurrent reader from copying out a half-written make_opts -- which
        # parses fine, drops FC/$(libext)/-ffixed-line-length-132, and surfaces
        # only as column-72 Fortran errors in a completely unrelated build.
        make_opts = pjoin(MG5DIR, 'Template','LO','Source','make_opts')
        make_opts_source = pjoin(MG5DIR, 'Template','LO','Source','.make_opts')
        if not os.path.exists(make_opts):
            misc.atomic_copy(make_opts_source, make_opts)
        elif  os.path.getmtime(make_opts) <  os.path.getmtime(make_opts_source):
            misc.atomic_copy(make_opts_source, make_opts)
            
        # Variables to store state information
        self._multiparticles = {}
        self._boundstates = {}
        self._fockstates = []
        self.options = {}
        self._generate_info = "" # store the first generated process
        self._model_v4_path = None
        self._export_dir = None
        self._export_format = 'madevent'
        self._mgme_dir = MG4DIR
        self._cuttools_dir=str(os.path.join(self._mgme_dir,'vendor','CutTools'))
        self._iregi_dir=str(os.path.join(self._mgme_dir,'vendor','IREGI','src'))
        self._comparisons = None
        self._cms_checks = []
        self._nlo_modes_for_completion = ['all','virt','real','LOonly']
        self._second_exporter = None

        # Load the configuration file,i.e.mg7_configuration.txt
        self.set_configuration()

    def setup(self):
        """ Actions to carry when switching to this interface """

        # Refresh all the interface stored value as things like generated
        # processes and amplitudes are not to be reused in between different
        # interfaces
        # Clear history, amplitudes and matrix elements when a model is imported
        # Remove previous imports, generations and outputs from history
        self.history.clean(remove_bef_last='import',keep_switch=True)
        # Reset amplitudes and matrix elements
        self._done_export=False
        self._curr_amps = diagram_generation.AmplitudeList()
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()

        self._v4_export_formats = ['madevent', 'standalone_fortran','standalone_msP','standalone_msF',
                                   'matrix', 'standalone_rw']
        self._export_formats = self._v4_export_formats + ['mg7_v5', 'mg7', 'standalone']
        self._nlo_modes_for_completion = ['all','virt','real']

    def do_quit(self, line):
        """Not in help: Do quit"""

        if self._done_export and \
                    os.path.exists(pjoin(self._done_export[0],'RunWeb')):
            os.remove(pjoin(self._done_export[0],'RunWeb'))

        value = super(MadGraphCmd, self).do_quit(line)
        if madgraph.ReadWrite: #prevent to run on Read Only disk
            self.do_install('update --mode=mg5_end')
        misc.EasterEgg('quit')
        
        
        return value

    def extract_diagram_filter(self, args, option='--diagram_filter'):
        """Remove the --diagram_filter[=PLUGINNAME] option from args and return
        the filter to use: False if absent, True for the filter of
        PLUGIN/user_filter.py (bare option, historical behaviour) or the
        function new_diagram_filter of the plugin PLUGINNAME. The option name
        can be changed (--tree_diagram_filter, --loop_diagram_filter)."""

        diagram_filter = False
        for arg in list(args):
            if arg == option:
                diagram_filter = True
                args.remove(arg)
            elif arg.startswith(option + '='):
                args.remove(arg)
                try:
                    diagram_filter = misc.plugin_diagram_filter(
                                      self.plugin_path, arg.split('=', 1)[1])
                except MadGraph5Error as error:
                    raise self.InvalidCmd(str(error))
        return diagram_filter

    # Add a process to the existing multiprocess definition
    # Generate a new amplitude
    def do_add(self, line, counter=0):
        """Generate an amplitude for a given process and add to
        existing amplitudes
        or merge two model
        """

        # The four gluon merging is wanted while the diagrams are generated,
        # which is below the interface, so it travels on the module. Synced
        # here rather than only in the setter, since the option can also
        # arrive from mg7_configuration.txt.
        madgraph.merge_quartic_vertices = \
                             self.options.get('merge_quartic_vertices', False)
        # an added process arrives in the generated order whatever an earlier
        # output reordered, so the two have to be brought back together --
        # a value matching neither makes the next output redo all of them
        self._quartic_order = 'mixed'

        args = self.split_arg(line)

        
        warning_duplicate = True
        if '--no_warning=duplicate' in args:
            warning_duplicate = False
            args.remove('--no_warning=duplicate')

        diagram_filter = self.extract_diagram_filter(args)
        
        standalone_only = False
        if '--standalone' in args:
            standalone_only = True
            merge_crossing = True
            args.remove('--standalone')            

        merge_crossing = False
        if '--no_crossing' in args:
            merge_crossing = True
            args.remove('--no_crossing') 

        # Check the validity of the arguments
        self.check_add(args)

        if args[0] == 'model':
            return self.add_model(args[1:])
        
        # special option for 1->N to avoid generation of kinematically forbidden
        #decay.
        if args[-1].startswith('--optimize'):
            optimize = True
            args.pop()
        else:
            optimize = False

        if args[0] == 'process':
            # Rejoin line
            line = ' '.join(args[1:])

            # the '{...}' syntax selects particle polarizations -> remember it so
            # the polarization paper is cited at output time
            if '{' in line:
                self._uses_polarization = True

            # store the first process (for the perl script)
            if not self._generate_info:
                self._generate_info = line

            # Reset Helas matrix elements
            self._curr_matrix_elements = helas_objects.HelasMultiProcess()

            # Extract process from process definition
            if ',' in line:
                if ']' in line or '[' in line:
                    error_msg=\
"""The '[' and ']' syntax cannot be used in cunjunction with decay chains.
This implies that with decay chains:
  > Squared coupling order limitations are not available.
  > Loop corrections cannot be considered."""
                    raise MadGraph5Error(error_msg)
                else:
                    nb_proc = len([l for l in self.history if l.startswith(('generate','add process'))])
                    myprocdef, line = self.extract_decay_chain_process(line, proc_number=nb_proc)
                    # Redundant with above, but not completely as in the future
                    # one might think of allowing the core process to be 
                    # corrected by loops.
                    if myprocdef.are_decays_perturbed():
                        raise MadGraph5Error("Decay processes cannot be perturbed.")
                    # The two limitations below have some redundancy, but once
                    # again, they might be relieved (one at a time or together)
                    # int he future.
                    if myprocdef.decays_have_squared_orders() or \
                                                myprocdef['squared_orders']!={}:
                        raise MadGraph5Error("Decay processes cannot specify "+\
                                                  "squared orders constraints.")                        
                    if myprocdef.are_negative_orders_present():
                        raise MadGraph5Error("Decay processes cannot include negative"+\
                                                " coupling orders constraints.")                    
            else:
                nb_proc = len([l for l in self.history if l.startswith(('generate','add process'))])
                nb_proc += counter
                myprocdef = self.extract_process(line, proc_number=nb_proc)
                # 'left [treextree] right': hidden order selecting the
                # interference, minimal orders of the right-hand process
                diagram_generation.prepare_interference_process(myprocdef)

            

            # Check that we have something
            if not myprocdef:
                raise self.InvalidCmd("Empty or wrong format process, please try again.")
            # Check that we have the same number of initial states as
            # existing processes
            if self._curr_amps and self._curr_amps[0].get_ninitial() != \
               myprocdef.get_ninitial() and not standalone_only:
                raise self.InvalidCmd("Can not mix processes with different number of initial states.")

            # Check the propagator-only polarization braces: {G},{H},{Q},{W}
            # and {S} name a piece of a propagator numerator and are valid on
            # an internal line only.
            self.validate_propagator_polarization(myprocdef)

            #Check that we do not have situation like z{T} z
            if not myprocdef.check_polarization():
                logger.critical("Not Supported syntax:\n"+ \
                                "   Syntax like p p  > Z{T} Z are ambiguous" +\
                                "   Behavior is not guarantee to be stable within future version of the code." + \
                                "   Furthermore, you can have issue with symmetry factor (we do not guarantee [differential] cross-section."+\
                                "   We suggest you to abort this computation")
                ans = self.ask('Do you want to continue', 'no',['yes','no'])
                if ans == 'no':
                    raise self.InvalidCmd("Not supported syntax of type p p  > Z{T} Z")
                    
                
                

            self._curr_proc_defs.append(myprocdef)

            try:
                # Negative coupling order constraints can be given on at most one
                # coupling order (and either in squared orders or orders, not both)
                if len([1 for val in list(myprocdef.get('orders').values())+\
                              list(myprocdef.get('squared_orders').values()) if val<0])>1:
                    raise MadGraph5Error("Negative coupling order constraints"+\
                      " can only be given on one type of coupling and either on"+\
                                   " squared orders or amplitude orders, not both.")
    
                if myprocdef.get_ninitial() ==1 and  myprocdef.get('squared_orders'):
                    logger.warning('''Computation of interference term with decay is not 100% validated.  
                    Please check carefully your result.
                    One suggestion is also to compare the generation of your process with and without
                    set group_subprocesses True
                    (to write Before the generate command)
                    ''')
    
                cpu_time1 = time.time()
    
                # Generate processes
                if self.options['group_subprocesses'] == 'Auto':
                        collect_mirror_procs = True
                else:
                    collect_mirror_procs = self.options['group_subprocesses']
                ignore_six_quark_processes = \
                               self.options['ignore_six_quark_processes'] if \
                               "ignore_six_quark_processes" in self.options \
                               else []
    
                try:
                    myproc = diagram_generation.MultiProcess(myprocdef,
                                         collect_mirror_procs = collect_mirror_procs,
                                         ignore_six_quark_processes = ignore_six_quark_processes,
                                         optimize=optimize, diagram_filter=diagram_filter,
                                         merge_crossing=merge_crossing)
                    amplitudes = myproc.get('amplitudes')
                except diagram_generation.NoDiagramException:
                    if not myprocdef.get_interference_mode():
                        raise
                    raise self.InvalidCmd(
                        "No subprocess of '%s' has diagrams on both sides of "
                        "[treextree]: there is no interference to compute." %
                        myprocdef.nice_string(prefix=False))
    
                for amp in amplitudes:
                    if amp not in self._curr_amps:
                        self._curr_amps.append(amp)
                    elif warning_duplicate:
                        raise self.InvalidCmd( "Duplicate process %s found. Please check your processes." % \
                                                    amp.nice_string_processes())
            except Exception:
                self._curr_proc_defs.pop(-1)
                raise

            # Reset _done_export, since we have new process
            self._done_export = False

            cpu_time2 = time.time()

            nprocs = len(myproc.get('amplitudes'))
            ndiags = sum([amp.get_number_of_diagrams() for \
                              amp in myproc.get('amplitudes')])
            
            logger.info("%i processes with %i diagrams generated in %0.3f s" % \
                  (nprocs, ndiags, (cpu_time2 - cpu_time1)))
            ndiags = sum([amp.get_number_of_diagrams() for \
                              amp in self._curr_amps])
            logger.info("Total: %i processes with %i diagrams" % \
                  (len(self._curr_amps), ndiags))        
                
    def add_model(self, args):
        """merge two model"""

        if '--fock_states_only' in args:
            args.remove('--fock_states_only')
            return self.add_fock_states(args[0])
        
        model_path = args[0]

        # adding the taudecay library -> cite the TauDecay paper at output time
        if 'taudecay' in os.path.basename(model_path.rstrip('/')).lower():
            self._uses_taudecay = True
        recreate = ('--recreate' in args)
        if recreate:
            args.remove('--recreate')
        keep_decay = ('--keep_decay' in args)
        if keep_decay:
            args.remove('--keep_decay')
        output_dir = [a.split('=',1)[1] for a in args if a.startswith('--output')]
        if output_dir:
            output_dir = output_dir[0]
            recreate = True
            restrict_name = ''
            args.remove('--output=%s' % output_dir)
        else:
            name = os.path.basename(self._curr_model.get('modelpath'))
            restrict_name = self._curr_model.get('restrict_name')
            output_dir = pjoin(MG5DIR, 'models', '%s__%s' % (name,
                                                  os.path.basename(model_path)))
        
        if os.path.exists(output_dir):
            if recreate:
                shutil.rmtree(output_dir)
            else:
                logger.info('Model already created! Loading it from %s' % output_dir)
                oldmodel = self._curr_model.get('modelpath')
                new_model_name = output_dir
                if restrict_name:
                    new_model_name = '%s-%s' % (output_dir, restrict_name)
                try:
                    self.exec_cmd('import model %s' % new_model_name, errorhandling=False, 
                              printcmd=False, precmd=True, postcmd=True)
                except Exception as error:
                    logger.debug('fail to load model %s with error:\n %s' % (output_dir, error))
                    logger.warning('Fail to load the model. Restore previous model')
                    self.exec_cmd('import model %s' % oldmodel, errorhandling=False, 
                              printcmd=False, precmd=True, postcmd=True)                    
                    raise Exception('Invalid Model! Please retry with the option \'--recreate\'.')
                else:
                    return
        
        #Need to do the work!!!        
        import madgraph.models.usermod as usermod
        try:
            base_model = copy.deepcopy(usermod.UFOModel(self._curr_model.get('modelpath')))
        except Exception:
            base_model_tmp = usermod.UFOModel(self._curr_model.get('modelpath'))
            with misc.TMP_variable(base_model_tmp, 'model',None):
                base_model = copy.deepcopy(base_model_tmp)
            base_model.model = base_model_tmp.model
            del base_model_tmp
                    
        identify = dict(tuple(a.split('=')) for a in args if '=' in a)
        base_model.add_model(path=model_path, identify_particles=identify)
        base_model.write(output_dir)
        
        if keep_decay and os.path.exists(pjoin(self._curr_model.get('modelpath'), 'decays.py')):
            base_model.mod_file(pjoin(pjoin(self._curr_model.get('modelpath'), 'decays.py')),
                                pjoin(pjoin(output_dir, 'decays.py')))
        
        new_model_name = output_dir
        if restrict_name:
            new_model_name = '%s-%s' % (output_dir, restrict_name)
            
        if 'modelname' in self.history.get('full_model_line'):
            opts = '--modelname'
        else:
            opts='' 
        self.exec_cmd('import model %s %s' % (new_model_name, opts), errorhandling=False, 
                              printcmd=False, precmd=True, postcmd=True)         
        
    
    def add_fock_states(self, model_name):
        """Import only the Fock states (bound states) of another UFO model on top
        of the current one, without merging particles or interactions, e.g.
            import model heft
            add model sm_onia --fock_states_only
        A Fock state is only kept if its constituents exist in the current model."""

        import madgraph.models.import_ufo as import_ufo
        import madgraph.models.import_boundstates as ufo_boundstates

        if os.path.isdir(model_name):
            path = model_name
        else:
            try:
                path = import_ufo.find_ufo_path(model_name)
            except import_ufo.UFOImportError:
                # accept a restricted name such as sm_onia-c_mass
                path = import_ufo.find_ufo_path(model_name.rsplit('-', 1)[0])

        fockstates = ufo_boundstates.get_boundstates_ufo(path)
        if not fockstates:
            raise self.InvalidCmd('Model %s does not define any Fock state.' % model_name)

        known = set(f.get('name') for f in self._fockstates)
        particles = self._curr_model['particles']
        added, skipped = [], []
        for fock in fockstates:
            if not all(particles.get_copy(p) for p in fock.get('particles')):
                skipped.append(fock.get('name'))
            elif fock.get('name') not in known:
                self._fockstates.append(fock)
                known.add(fock.get('name'))
                added.append(fock.get('name'))

        if skipped:
            logger.warning('%i Fock states of %s skipped: their constituents are not in the current model.'
                           % (len(skipped), model_name))
        if not added:
            logger.info('No new Fock state added from %s.' % model_name)
            return

        logger.info('Added %i Fock states from %s.' % (len(added), model_name))
        logger.warning('The model contains non-relativistic bound states. Please consider citing arXiv:2510.26773 and arXiv:2607.26739 if relevant.')
        if not self._boundstates:
            self.add_default_boundstates()

    def do_convert(self, line):
        """convert model FULLPATH
           modify (in place) the UFO model to make it compatible with both python2 and python3
        """
        
        args = self.split_arg(line)
        if hasattr(self, 'do_convert_%s' % args[0]):
            getattr(self, 'do_convert_%s' % args[0])(args[1:])
            
    def do_convert_model(self, args):
        "Not in help: shortcut for convert model"
        
        if not os.path.isdir(args[0]):
            raise Exception( 'model to convert need to provide a full path')
        model_dir = args[0]
        
        
        if not ('-f' not in args or self.options['auto_convert_model']): 
            answer = self.ask('model conversion to support both py2 and py3 are done in place.\n They are NO guarantee of success.\n It can make the model to stop working under PY2 as well.\n Do you want to proceed?',
                     'y', ['y','n'])
            if answer != 'y':
                return

        import_ufo.convert_model_py2_to_py3(model_dir, force=True)
        
        
        
        
    
    # Define a multiparticle label
    def do_define(self, line, log=True):
        """Define a multiparticle"""

        self.avoid_history_duplicate('define %s' % line, ['define'])
        if not self._curr_model:
            self.do_import('model sm')
            self.history.append('define %s' % line)
        if not self._curr_model['case_sensitive']:
            # Particle names lowercase
            line = line.lower()
        # Make sure there are spaces around =, | and /
        line = line.replace("=", " = ")
        line = line.replace("|", " | ")
        line = line.replace("/", " / ")
        args = self.split_arg(line)
        # check the validity of the arguments
        self.check_define(args)

        label = args[0]
        remove_ids = []
        try:
            remove_index = args.index("/")
        except ValueError:
            pass
        else:
            remove_ids = args[remove_index + 1:]
            args = args[:remove_index]

        pdg_list = self.extract_particle_ids(args[1:])
        remove_list = self.extract_particle_ids(remove_ids)
        pdg_list = [p for p in pdg_list if p not in remove_list]

        self.optimize_order(pdg_list)
        self._multiparticles[label] = pdg_list
        if log:
            logger.info("Defined multiparticle %s" % \
                                             self.multiparticle_string(label))

    # Display
    def do_display(self, line, output=sys.stdout):
        """Display current internal status"""

        args = self.split_arg(line)
        #check the validity of the arguments
        self.check_display(args)

        if args[0] == 'diagrams':
            self.draw(' '.join(args[1:]))

        if args[0] == 'particles' and len(args) == 1:
            propagating_particle = []
            nb_unpropagating = 0
            for particle in self._curr_model['particles']:
                if particle.get('propagating'):
                    propagating_particle.append(particle)
                else:
                    nb_unpropagating += 1

            print("Current model contains %i particles:" % \
                    len(propagating_particle))
            part_antipart = [part for part in propagating_particle \
                             if not part['self_antipart']]
            part_self = [part for part in propagating_particle \
                             if part['self_antipart']]
            for part in part_antipart:
                print(part['name'] + '/' + part['antiname'], end=' ')
            print('')
            for part in part_self:
                print(part['name'], end=' ')
            print('')
            if nb_unpropagating:
                print('In addition of %s un-physical particle mediating new interactions.' \
                                     % nb_unpropagating)

        elif args[0] == 'particles':
            conserved = self._curr_model.get('conserved_charge')
            if conserved:
                print("Conserved charges in the current model: %s" % ', '.join(sorted(conserved)))
            for arg in args[1:]:
                if arg.isdigit() or (arg[0] == '-' and arg[1:].isdigit()):
                    particle = self._curr_model.get_particle(abs(int(arg)))
                else:
                    particle = self._curr_model['particles'].find_name(arg)
                if not particle:
                    raise self.InvalidCmd('no particle %s in current model' % arg)

                print("Particle %s has the following properties:" % particle.get_name())
                print(particle.nice_string())

        elif args[0] == 'interactions' and len(args) == 1:
            text = "Current model contains %i interactions\n" % \
                    len(self._curr_model['interactions'])
            for i, inter in enumerate(self._curr_model['interactions']):
                text += str(i+1) + ':'
                for part in inter['particles']:
                    if part['is_part']:
                        text += part['name']
                    else:
                        text += part['antiname']
                    text += " "
                text += " ".join(order + '=' + str(inter['orders'][order]) \
                                 for order in inter['orders'])
                text += " " + (inter['type'] if 'type' in inter else '')
                text += '\n'
            pydoc.pager(text)

        elif args[0] == 'interactions' and len(args)==2 and args[1].isdigit():
            for arg in args[1:]:
                if int(arg) > len(self._curr_model['interactions']):
                    raise self.InvalidCmd('no interaction %s in current model' % arg)
                if int(arg) == 0:
                    print('Special interactions which identify two particles')
                else:
                    print("Interactions %s has the following property:" % arg)
                    print(self._curr_model['interactions'][int(arg)-1].__str__(couplings=self._curr_model['couplings']))

        elif args[0] == 'interactions':
            request_part = args[1:]
            text = ''
            for i, inter in enumerate(self._curr_model['interactions']):
                present_part = [part['is_part'] and part['name'] or part['antiname']
                                 for part in inter['particles']
                                if (part['is_part'] and  part['name'] in request_part) or
                                   (not part['is_part'] and part['antiname'] in request_part)]
                if len(present_part) < len(request_part):
                    continue
                # check that all particles are selected at least once
                if set(present_part) != set(request_part):
                    continue
                # check if a particle is asked more than once
                if len(request_part) > len(set(request_part)):
                    for p in request_part:
                        if request_part.count(p) > present_part.count(p):
                            continue

                name = str(i+1) + ' : '
                for part in inter['particles']:
                    if part['is_part']:
                        name += part['name']
                    else:
                        name += part['antiname']
                    name += " "
                text += "\nInteractions %s has the following property:\n" % name
                text += self._curr_model['interactions'][i].__str__(couplings=self._curr_model['couplings'])

                text += '\n'
                print("%s %s %s" % (name,  inter['orders'], inter['type'] if 'type' in inter else 'tree'))
            if text =='':
                text += 'No matching for any interactions'
            pydoc.pager(text)


        elif args[0] == 'parameters' and len(args) == 1:
            text = "Current model contains %i parameters\n" % \
                    sum([len(part) for part in
                                       self._curr_model['parameters'].values()])
            keys = list(self._curr_model['parameters'].keys())
            def key_sort(x):
                if ('external',) == x:
                    return -1
                else:
                    return len(x)
            keys.sort(key=key_sort)
            for key in keys:
                item = self._curr_model['parameters'][key]
                text += '\nparameter type: %s\n' % str(key)
                for value in item:
                    if hasattr(value, 'expr'):
                        if value.value is not None:
                            text+= '        %s = %s = %s\n' % (value.name, value.expr ,value.value)
                        else:
                            text+= '        %s = %s\n' % (value.name, value.expr)
                    else:
                        if value.value is not None:
                            text+= '        %s = %s\n' % (value.name, value.value)
                        else:
                            text+= '        %s \n' % (value.name)
            pydoc.pager(text)

        elif args[0] == 'processes':
            for amp in self._curr_amps:
                print(amp.nice_string_processes())

        elif args[0] == 'diagrams_text':
            dirpath, no_open, merge = self._parse_display_output_args(args[1:])
            text = "\n".join([amp.nice_string() for amp in self._curr_amps])
            if dirpath:
                self._write_diagrams_text_files(dirpath, merge=merge)
            else:
                if no_open:
                    raise self.InvalidCmd('--no_open requires an explicit directory path, e.g. display diagrams_text ./ --no_open')
                if merge:
                    raise self.InvalidCmd('--merge requires an explicit directory path, e.g. display diagrams_text ./ --merge')
            if not no_open:
                pydoc.pager(text)

        elif args[0] == 'multiparticles':
            print('Multiparticle labels:')
            for key in self._multiparticles:
                print(self.multiparticle_string(key))

        elif args[0] == 'fockstates':
            print('Current model contains %i Fock states:'%(len(self._fockstates)))
            print(' '.join([fockstate.get('name') for fockstate in self._fockstates]))

        elif args[0] == 'boundstates':
            print('Bound state labels:')
            for key in self._boundstates:
                print(self.boundstate_string(key))

        elif args[0] == 'coupling_order':
            hierarchy = [(order, weight) for order, weight in
                         self._curr_model['order_hierarchy'].items()
                         if order != base_objects.INTERFERENCE_ORDER]
            hierarchy.sort(key=operator.itemgetter(1))
            # an order declared by the model can have no interaction left
            # carrying it -- a restriction card typically removes all of them.
            # Such an order is inert: it can not constrain a process.
            active = self._curr_model.get('coupling_orders')
            inert = []
            for order, weight in hierarchy:
                if order in active:
                    print(' %s : weight = %s' % (order, weight))
                else:
                    print(' %s : weight = %s [inert]' % (order, weight))
                    inert.append(order)
            if inert:
                print(' [inert]: no interaction of this model carries that'
                      ' order (the restriction card likely removed them all),')
                print('          so it can not be used to constrain a process.')

        elif args[0] == 'couplings' and len(args) == 1:
            if self._model_v4_path:
                print('No couplings information available in V4 model')
                return
            text = ''
            text = "Current model contains %i couplings\n" % \
                    sum([len(part) for part in
                                        self._curr_model['couplings'].values()])
            keys = list(self._curr_model['couplings'].keys())
            def key_sort(x):
                if ('external',) == x:
                    return -1
                else:
                    return len(x)
            keys.sort(key=key_sort)
            for key in keys:
                item = self._curr_model['couplings'][key]
                text += '\ncouplings type: %s\n' % str(key)
                for value in item:
                    if value.value is not None:
                        text+= '        %s = %s = %s\n' % (value.name, value.expr ,value.value)
                    else:
                        text+= '        %s = %s\n' % (value.name, value.expr)

            pydoc.pager(text)

        elif args[0] == 'couplings':
            if self._model_v4_path:
                print('No couplings information available in V4 model')
                return

            try:
                ufomodel = ufomodels.load_model(self._curr_model.get('name'))
                print('Note that this is the UFO information.')
                print(' "display couplings" present the actual definition')
                print('prints the current states of mode')
                print(eval('ufomodel.couplings.%s.nice_string()'%args[1]))
            except Exception:
                raise self.InvalidCmd('no couplings %s in current model' % args[1])

        elif args[0] == 'lorentz':
            print('in lorentz')
            if self._model_v4_path:
                print('No lorentz information available in V4 model')
                return
            elif len(args) == 1:
                ufomodel = ufomodels.load_model(self._curr_model.get('name'))
                print(dir(ufomodel.lorentz))
                return
            try:
                ufomodel = ufomodels.load_model(self._curr_model.get('name'))
                print(getattr(ufomodel.lorentz, args[1]).nice_string())
            except Exception as error:
                raise
                logger.info(str(error))
                raise self.InvalidCmd('no lorentz %s in current model' % args[1])

        elif args[0] == 'checks':
            outstr = ''
            if self._comparisons:
                comparisons = self._comparisons[0]
                if len(args) > 1 and args[1] == 'failed':
                    comparisons = [c for c in comparisons if not c['passed']]
                outstr += "Process check results:"
                for comp in comparisons:
                    outstr += "\n%s:" % comp['process'].nice_string()
                    outstr += "\n   Phase space point: (px py pz E)"
                    for i, p in enumerate(comp['momenta']):
                        outstr += "\n%2s    %+.9e  %+.9e  %+.9e  %+.9e" % tuple([i] + p)
                    outstr += "\n   Permutation values:"
                    outstr += "\n   " + str(comp['values'])
                    if comp['passed']:
                        outstr += "\n   Process passed (rel. difference %.9e)" % \
                              comp['difference']
                    else:
                        outstr += "\n   Process failed (rel. difference %.9e)" % \
                              comp['difference']

                used_aloha = sorted(self._comparisons[1])
                if used_aloha:
                    outstr += "\nChecked ALOHA routines:"
                for aloha in used_aloha:
                    aloha_str = aloha[0]
                    if aloha[1]:
                        aloha_str += 'C' + 'C'.join([str(ia) for ia in aloha[1]])
                    aloha_str += "_%d" % aloha[2]
                    outstr += "\n" + aloha_str
            
            outstr += '\n'
            for cms_check in self._cms_checks:
                outstr += '*'*102+'\n'
                outstr += 'Complex Mass Scheme check:\n'
                outstr += '    -> check %s\n'%cms_check['line']
                outstr += '*'*102+'\n'
                tmp_options = copy.copy(cms_check['options'])
                tmp_options['show_plot']=False
                outstr += process_checks.output_complex_mass_scheme(
                            cms_check['cms_result'], cms_check['output_path'], 
                                           tmp_options, self._curr_model) + '\n'
                outstr += '*'*102+'\n\n'
            pydoc.pager(outstr)

        elif args[0] == 'options':
            if len(args) == 1:
                to_print = lambda name: True
            else:
                to_print = lambda name: any(poss in name for poss in args[1:])

            outstr = "                          MadGraph7 Options    \n"
            outstr += "                          ----------------    \n"
            keys = list(self.options_madgraph.keys())
            keys.sort()
            for key in keys:
                if not to_print(key):
                    continue
                default = self.options_madgraph[key] 
                value = self.options[key]
                if value == default:
                    outstr += "  %25s \t:\t%s\n" % (key,value)
                else:
                    outstr += "  %25s \t:\t%s (user set)\n" % (key,value)
            outstr += "\n"
            outstr += "                         MadEvent Options    \n"
            outstr += "                          ----------------    \n"
            keys = list(self.options_madevent.keys())
            keys.sort()
            for key in keys:
                if not to_print(key):
                    continue
                default = self.options_madevent[key]
                value = self.options[key]
                if value == default:
                    outstr += "  %25s \t:\t%s\n" % (key,value)
                else:
                    outstr += "  %25s \t:\t%s (user set)\n" % (key,value)
            outstr += "\n"
            outstr += "                      Configuration Options    \n"
            outstr += "                      ---------------------    \n"
            keys = list(self.options_configuration.keys())
            keys.sort()
            for key in keys:
                if not to_print(key):
                    continue
                default = self.options_configuration[key]
                value = self.options[key]
                if value == default:
                    outstr += "  %25s \t:\t%s\n" % (key,value)
                else:
                    outstr += "  %25s \t:\t%s (user set)\n" % (key,value)

            output.write(outstr)
        elif args[0] in  ["variable"]:
            super(MadGraphCmd, self).do_display(line, output)
            
        elif args[0] in ["modellist", "model_list"]:
            outstr = []
            template = """%-30s | %-60s | %-25s """
            outstr.append(template % ('name', 'restriction', 'comment'))
            outstr.append('*'*150)
            already_done = []
            #local model #use
            
            if 'PYTHONPATH' in os.environ:
                pythonpath = os.environ['PYTHONPATH'].split(':')
            else:
                pythonpath = []

            for base in [pjoin(MG5DIR,'models')] + pythonpath:
                if not os.path.exists(base):
                    continue
                file_cond = lambda p : os.path.exists(pjoin(base,p,'particles.py'))
                mod_name = lambda name: name
                
                model_list = [mod_name(name) for name in \
                                                self.path_completion('',
                                                base,
                                                only_dirs = True) \
                                                if file_cond(name)]
                
                for model_name in model_list:
                    if model_name in already_done:
                        continue
                    all_name = self.find_restrict_card(model_name,
                                            base_dir=base,
                                            online=False)
                    already_done.append(model_name)
                    restrict = [name[len(model_name):] for name in all_name 
                                if len(name)>len(model_name)]
                    
                    comment = 'from models directory'
                    if base != pjoin(MG5DIR,'models'):
                        comment = 'from PYTHONPATH: %s' % base
                    lrestrict = ', '.join(restrict)
                    if len(lrestrict) > 50:
                        for i in range(-1,-len(restrict), -1):
                            lrestrict = ', '.join(restrict[:i])
                            if len(lrestrict)<50:
                                break
                        outstr.append(template % (model_name, lrestrict, comment))
                        outstr.append(template % ('', ', '.join(restrict[i:]), ''))
                    else:
                        outstr.append(template % (model_name, ', '.join(restrict), comment))
                outstr.append('*'*150)
                
            # Still have to add the one with internal information 
            for model_name in self._online_model:
                if model_name in already_done:
                    continue
                restrict = [tag for tag in self._online_model[model_name]]
                comment = 'automatic download from MadGraph7 server'
                outstr.append(template % (model_name, ','.join(restrict), comment))
                already_done.append(model_name)
                
            outstr.append('*'*150)  
            # other downloadable model
            data   = import_ufo.get_model_db()
            self._online_model2 = []
            for line in data:
                model_name, path = line.decode(errors='ignore').split()
                if model_name in already_done:
                    continue
                if model_name.endswith('_v4'):
                    continue
                
                if 'feynrules' in path:
                    comment = 'automatic download from FeynRules website'
                elif 'madgraph.phys' in path:
                     comment = 'automatic download from MadGraph7 server'
                else:
                    comment = 'automatic download.'
                restrict = 'unknown'
                outstr.append(template % (model_name, restrict, comment))
                self._online_model2.append(model_name)
            pydoc.pager('\n'.join(outstr))
            

    def multiparticle_string(self, key):
        """Returns a nicely formatted string for the multiparticle"""

        if self._multiparticles[key] and \
               isinstance(self._multiparticles[key][0], list):
            return "%s = %s" % (key, "|".join([" ".join([self._curr_model.\
                                     get('particle_dict')[part_id].get_name() \
                                                     for part_id in id_list]) \
                                  for id_list in self._multiparticles[key]]))
        else:
            return "%s = %s" % (key, " ".join([self._curr_model.\
                                    get('particle_dict')[part_id].get_name() \
                                    for part_id in self._multiparticles[key]]))

    def boundstate_string(self, key):
        """Returns a nicely formatted string for the bound state"""

        if key in self._boundstates:
            return f"{key} = {' '.join(self._boundstates[key])}"
        else:
            return f"Boundstate {key} is not defined."

    def do_tutorial(self, line):
        """Activate/deactivate the tutorial mode."""

        self.load_plugin_tutorials()
        args = self.split_arg(line)
        self.check_tutorial(args)
        name = args[0]

        if name == 'stop':
            session = tutorial_mixin.detach(self)
            logger_tuto.setLevel(logging.ERROR)
            if session is not None:
                logger.info("Thanks for using the %s tutorial!"
                            % session.tutorial.name)
            return

        if name in self._tutorial_step_cmds:
            # `tutorial hint` is the same as `hint`
            session = getattr(self, '_tutorial_session', None)
            if session is None:
                logger.info("No tutorial is running. Type 'tutorial' to start "
                            "one, or 'tutorial help'.")
                return
            session.suppress_next = True
            return getattr(self, 'do_%s' % name)(' '.join(args[1:]))

        if name in ('list', 'status', 'index', 'help'):
            # informational: never (re)start anything, and never let the
            # postcmd hook mistake this for the tutorial's intro step
            session = getattr(self, '_tutorial_session', None)
            if session is not None:
                session.suppress_next = True
            if name == 'list':
                self.print_tutorial_list()
            elif name == 'status':
                self.print_tutorial_status()
            elif name == 'index':
                self.print_tutorial_index()
            else:
                self.print_tutorial_help()
            return

        session = tutorials.start(name)
        if session is None:
            # check_tutorial only lets known names through, so this cannot
            # normally happen; be explicit rather than fail obscurely
            raise self.InvalidCmd('Unknown tutorial %s' % name)

        tutorial_mixin.attach(self, session)
        logger_tuto.setLevel(logging.INFO)

        if not self._mgme_dir:
            logger_tuto.info(\
                       "\n\tWarning: To use all features in this tutorial, " + \
                       "please run from a" + \
                       "\n\t         valid MG_ME directory.")

    def load_plugin_tutorials(self):
        """Let plugins add tutorials, once per session."""

        if getattr(self, '_tutorial_plugins_loaded', False):
            return
        self._tutorial_plugins_loaded = True
        try:
            tutorials.load_plugin_tutorials(self.plugin_path)
        except Exception as error:
            logger.debug('could not load plugin tutorials: %s', error)

    def print_tutorial_help(self):
        """What `tutorial help` prints: the commands a tutorial understands."""

        running = getattr(self, '_tutorial_session', None)

        logger.info("Commands available while a tutorial is running:",
                    '$MG:BOLD')
        logger.info("   hint        a nudge towards the command this step wants")
        logger.info("   solution    print one right answer -- it is never run "
                    "for you, you type it")
        logger.info("   next        same thing: show the command to type next")
        logger.info("   repeat      print the current step again")
        logger.info("   back        go back one step")
        logger.info("   skip        move on without doing this step")
        logger.info("   skip N      go to step N, running the commands that "
                    "lead there")
        logger.info("Anytime:", '$MG:BOLD')
        logger.info("   tutorial            choose a tutorial from the menu")
        logger.info("   tutorial NAME       start that one (switches if one is "
                    "already running)")
        logger.info("   tutorial list       show the tutorials on offer")
        logger.info("   tutorial status     how far you have got")
        logger.info("   tutorial index      the steps of the running tutorial, "
                    "numbered")
        logger.info("   tutorial help       this message")
        logger.info("   tutorial stop       leave tutorial mode")
        logger.info("A tutorial never blocks a command: anything you type runs "
                    "normally, and", '$MG:BOLD')
        logger.info("the tutorial just comments on it. Going off-script is "
                    "fine.", '$MG:BOLD')

        if running is None:
            logger.info("No tutorial is running, so the first group above is "
                        "not active yet.")
        else:
            done, total = running.progress()
            logger.info("Running '%s', step %d of %d."
                        % (running.tutorial.name, done, total))

    def print_tutorial_list(self, numbered=False):
        """Show the available tutorials, grouped by section.

        With `numbered`, the rows carry the number the menu accepts as an
        answer; returns the tutorials in that order so the caller can map a
        number back.
        """

        ordered = []
        for _key, title, group, notice in tutorials.by_section():
            if notice:
                logger.info("%s  (%s)" % (title, notice), '$MG:BOLD')
            else:
                logger.info("%s" % title, '$MG:BOLD')
            for tutorial in group:
                ordered.append(tutorial)
                if numbered:
                    logger.info("  %2d. %-12s %s" % (len(ordered), tutorial.name,
                                                     tutorial.description))
                else:
                    logger.info("      %-12s %s" % (tutorial.name,
                                                    tutorial.description))
        if not numbered:
            logger.info("Start one with 'tutorial NAME', or just 'tutorial' "
                        "to choose.")
        return ordered

    def print_tutorial_status(self):
        """Say where the user has got to."""

        session = getattr(self, '_tutorial_session', None)
        if session is None:
            logger.info("No tutorial is running. Type 'tutorial' to start one.")
            return
        done, total = session.progress()
        logger.info("Tutorial '%s': step %d of %d" %
                    (session.tutorial.name, done, total), '$MG:BOLD')
        for i, step in enumerate(session.tutorial.steps):
            mark = '>' if i == session.index else ('x' if i in session.seen else ' ')
            note = '   (answers a command in place)' if step.sticky else ''
            logger.info("  %s %2d. %s%s"
                        % (mark, i + 1, step.title or step.key, note))

    def print_tutorial_index(self):
        """`tutorial index`: the numbered steps, and how to go to one."""

        self.print_tutorial_status()
        if getattr(self, '_tutorial_session', None) is not None:
            logger.info("'>' is where you are, 'x' what you have seen. "
                        "'tutorial skip N' goes to step N.")

    def ask_tutorial(self, default=None):
        """Menu shown by a bare 'tutorial'.  Returns a name.

        Never blocks: without a real terminal (a command file, a pipe, or
        force mode) it keeps the historical meaning of a bare 'tutorial' and
        returns `default`.
        """

        available = tutorials.all_tutorials()
        if default is None:
            default = available[0].name
        # 'force' is set opportunistically (by `import command -f`, say) and is
        # not an attribute every interface carries, so it has to be read
        # defensively; isatty() can itself raise on a detached stdin
        try:
            interactive = self.use_rawinput and sys.stdin.isatty()
        except Exception:
            interactive = False
        if getattr(self, 'force', False) or not interactive:
            return default

        logger.info("Which tutorial would you like?", '$MG:BOLD')
        available = self.print_tutorial_list(numbered=True)
        choices = [tutorial.name for tutorial in available]
        choices += [str(i + 1) for i in range(len(available))] + ['stop']
        # timeout=0 means no time limit.  Everywhere else MG7 times a question
        # out so an unattended script cannot hang; a tutorial is the opposite
        # situation -- there is a person at the keyboard by definition, and if
        # they go and make a coffee while reading the menu we wait for them.
        answer = self.ask('Enter a number or a name', default, choices=choices,
                          timeout=0)
        if answer.isdigit() and 1 <= int(answer) <= len(available):
            return available[int(answer) - 1].name
        return answer



    def draw(self, line,selection='all',Dtype=''):
        """ draw the Feynman diagram for the given process.
        Dtype refers to born, real or loop"""

        args = self.split_arg(line)
        # accept the single dash form of the flags. This has to be done before
        # optparse sees them, since it would read '-no_open' as short options.
        alias = {'-no_open': '--no_open', '-merge': '--merge'}
        args = [alias.get(a, a) for a in args]

        # Let the parser consume the options first, so that args only contains
        # the (optional) output directory afterwards.
        (parsed_opts, args) = _draw_parser.parse_args(args)
        no_open = parsed_opts.no_open
        merge = parsed_opts.merge

        if not args:
            if no_open:
                raise self.InvalidCmd('--no_open requires an explicit directory path, e.g. display diagrams ./ --no_open')
            if merge:
                raise self.InvalidCmd('--merge requires an explicit directory path, e.g. display diagrams ./ --merge')
        elif not os.path.isdir(args[0]):
            # Create the output directory if an explicit path was given and
            # doesn't exist yet, so check_draw sees it as a valid directory.
            try:
                os.makedirs(args[0], exist_ok=True)
            except OSError as e:
                raise self.InvalidCmd(
                    "Cannot create output directory %s: %s" % (args[0], str(e)))

        # Check the validity of the arguments
        self.check_draw(args)

        # Check if we plot a decay chain
        if any([isinstance(a, diagram_generation.DecayChainAmplitude) for \
               a in self._curr_amps]) and not self._done_export:
            warn = 'WARNING: You try to draw decay chain diagrams without first running output.\n'
            warn += '\t  The decay processes will be drawn separately'
            logger.warning(warn)

        if madgraph.iolibs.drawing_eps.EpsDiagramDrawer.april_fool:
            parsed_opts.horizontal = True
            parsed_opts.external = True  
            parsed_opts.max_size = 0.3 
            parsed_opts.add_gap = 0.5  
        options = draw_lib.DrawOption(parsed_opts)
        start = time.time()


        # Collect amplitudes
        amplitudes = diagram_generation.AmplitudeList()

        for amp in self._curr_amps:
            amplitudes.extend(amp.get_amplitudes())

        eps_files = []
        for amp in amplitudes:
            filename = pjoin(args[0], 'diagrams_' + \
                                    amp.get('process').shell_string() + ".eps")
            eps_files.append(filename)

            if selection=='all' and Dtype != 'loop':
                diags=amp.get('diagrams')
            elif selection=='born':
                diags=amp.get('born_diagrams')
            elif selection=='loop' or Dtype == 'loop':
                diags=base_objects.DiagramList([d for d in
                        amp.get('loop_diagrams') if d.get('type')>0])
                if len(diags) > 5000:
                    logger.warning('Displaying only the first 5000 diagrams')
                    diags = base_objects.DiagramList(diags[:5000])

            plot = draw.MultiEpsDiagramDrawer(diags,
                                          filename,
                                          model=self._curr_model,
                                          amplitude=amp,
                                          legend=amp.get('process').input_string(),
                                          diagram_type=Dtype)


            logger.info("Drawing " + \
                         amp.get('process').nice_string())
            plot.draw(opt=options)
            logger.info("Wrote file " + filename)
            # --generate_only is the mg7 spelling of --no_open; honour both.
            if not no_open and not options.generate_only:
                self.exec_cmd('open %s' % filename)

        if merge and eps_files:
            output_pdf = pjoin(args[0], 'all_diagrams.pdf')
            output_pdf_abs = os.path.abspath(output_pdf)
            eps_files_sorted_abs = sorted(os.path.abspath(f) for f in eps_files)
            gs_cmd = ['gs', '-dBATCH', '-dNOPAUSE', '-q', '-sDEVICE=pdfwrite',
                      '-sOutputFile=' + output_pdf_abs] + eps_files_sorted_abs
            try:
                subprocess.check_call(gs_cmd, shell=False)
            except (subprocess.CalledProcessError, OSError) as e:
                logger.warning("Failed to merge diagrams into PDF with ghostscript: %s" % str(e))
                logger.warning("Make sure 'gs' (ghostscript) is installed and available in PATH.")
            else:
                logger.info("Merged diagrams into " + output_pdf)
                if not no_open and not options.generate_only:
                    self.exec_cmd('open %s' % output_pdf)

        stop = time.time()
        logger.info('time to draw %s' % (stop - start))

    def _parse_display_output_args(self, line_args):
        """Extract the optional output directory, --no_open and --merge flags.
        The directory is created if it does not exist yet, like for 'draw'."""

        # accept the single dash form of the flags. This has to be done before
        # optparse sees them, since it would read '-no_open' as short options.
        alias = {'-no_open': '--no_open', '-merge': '--merge'}
        (options, args) = _display_text_parser.parse_args(
                                          [alias.get(a, a) for a in line_args])

        if len(args) > 1:
            raise self.InvalidCmd('Too many arguments: %s' % ' '.join(args))
        if not args:
            return None, options.no_open, options.merge

        if not os.path.isdir(args[0]):
            try:
                os.makedirs(args[0], exist_ok=True)
            except OSError as e:
                raise self.InvalidCmd(
                    "Cannot create output directory %s: %s" % (args[0], str(e)))
        return args[0], options.no_open, options.merge

    def _write_diagrams_text_files(self, dirpath, merge=False):
        """Write one text file per process diagram. If merge=True, also concatenate all into all_diagrams_text.txt."""
        amplitudes = diagram_generation.AmplitudeList()
        for amp in self._curr_amps:
            amplitudes.extend(amp.get_amplitudes())

        txt_files = []
        for amp in amplitudes:
            filename = pjoin(dirpath, 'diagrams_' + amp.get('process').shell_string() + '.txt')
            with open(filename, 'w') as fs:
                fs.write(amp.nice_string())
            logger.info('Wrote file ' + filename)
            txt_files.append(filename)

        if merge and txt_files:
            merged_file = pjoin(dirpath, 'all_diagrams_text.txt')
            try:
                with open(merged_file, 'w') as out_fs:
                    for f in sorted(txt_files):
                        with open(f, 'r') as in_fs:
                            out_fs.write(in_fs.read())
                            out_fs.write('\n\n')
                logger.info("Merged diagrams text into " + merged_file)
            except IOError as e:
                logger.warning("Failed to merge text files: %s" % str(e))

    # Perform checks
    def do_check(self, line):
        """Check a given process or set of processes"""

        def create_lambda_values_list(lower_bound, N):
            """ Returns a list of values spanning the range [1.0, lower_bound] with
             lower_bound < 1.0 and with each interval [1e-i, 1e-(i+1)] covered
             by N values uniformly distributed. For example, lower_bound=1e-2
             and N=5 returns:
             [1, 0.8, 0.6, 0.4, 0.2, 0.1, 0.08, 0.06, 0.04, 0.02, 0.01]"""
            
            lCMS_values = [1]
            exp = 0
            n   = 0
            while lCMS_values[-1]>=lower_bound:
                n = (n+1)
                lCMS_values.append(float('1.0e-%d'%exp)*((N-n%N)/float(N)))
                if lCMS_values[-1]==lCMS_values[-2]:
                    lCMS_values.pop()
                exp = (n+1)//N
            
            lCMS_values = lCMS_values[:-1]
            if lCMS_values[-1]!=lower_bound:
                lCMS_values.append(lower_bound)
                
            return lCMS_values
        
        ###### BEGIN do_check

        # No exporter here, so 'auto' means the safe trace basis
        self.set_color_basis_mode()

        args = self.split_arg(line)
        automatic_reduction = (args and args[0] in ('timing', 'profile') and
                               not any(arg.startswith('--reduction=') for arg in args))
        # Check args validity
        param_card = self.check_check(args)

        options= {'events':None} # If the momentum needs to be picked from a event file
        if param_card and 'banner' == madevent_interface.MadEventCmd.detect_card_type(param_card):
            logger_check.info("Will use the param_card contained in the banner and  the events associated")
            import madgraph.various.banner as banner
            options['events'] = param_card
            mybanner = banner.Banner(param_card)
            param_card = mybanner.charge_card('param_card')

        aloha_lib.KERNEL.clean()
        # Back up the gauge for later
        gauge = str(self.options['gauge'])
        options['reuse'] = args[1]=="-reuse"
        args = args[:1]+args[2:] 
        # For the stability check the user can specify the statistics (i.e
        # number of trial PS points) as a second argument
        if args[0] in ['stability', 'profile']:
            options['npoints'] = int(args[1])
            args = args[:1]+args[2:]
        # For the precision check the floating point modes come first
        if args[0] == 'precision':
            options['precision_mode'] = args[1].split(':')
            args = args[:1]+args[2:]
        MLoptions={}
        i=-1
        CMS_options = {}
        while args[i].startswith('--'):
            option = args[i].split('=')
            if option[0] =='--energy':
                options['energy']=float(option[1])
            elif option[0] == '--events' and option[1]:
                if option[1] == 'None':
                    options['events'] = None
                elif not os.path.exists(option[1]):
                    raise Exception('path %s does not exist' % option[1])
                else:
                    options['events'] = option[1]
            elif option[0] == '--skip_evt':
                options['skip_evt']=int(option[1])
            elif option[0] == '--nb_event':
                try:
                    options['nb_event'] = int(float(option[1]))
                except ValueError:
                    raise self.InvalidCmd("The value of the 'nb_event' option"+\
                                       " must be a number, not %s."%option[1])
            elif option[0] == '--backend':
                if option[1] not in process_checks.PRECISION_BACKENDS:
                    raise self.InvalidCmd("The value of the 'backend' option must be"
                            " one of %s, not %s." % ('|'.join(process_checks.PRECISION_BACKENDS),
                                                     option[1]))
                options['backend'] = option[1]
            elif option[0]=='--split_orders':
                options['split_orders']=int(option[1])
            elif option[0]=='--helicity':
                try:
                    options['helicity']=int(option[1])
                except ValueError:
                    raise self.InvalidCmd("The value of the 'helicity' option"+\
                                       " must be an integer, not %s."%option[1])
            elif option[0]=='--reduction':
                MLoptions['MLReductionLib']=[int(ir) for ir in option[1].split('|')]
            elif option[0] in ('--tirust_finite', '--tirust_qp_integrand'):
                if option[1].lower() not in ('true', 'false'):
                    raise self.InvalidCmd('%s expects true or false.' % option[0])
                name = {'--tirust_finite':'TIRustComputeFinite',
                        '--tirust_qp_integrand':'UseQPIntegrandForTIRust'}[option[0]]
                MLoptions[name] = option[1].lower() == 'true'
            elif option[0] in ('--tirust_cache', '--tirust_cache_max_bytes', '--loop_pole_mode'):
                name = {'--tirust_cache':'TIRustGlobalCache',
                        '--tirust_cache_max_bytes':'TIRustCacheMaxBytes',
                        '--loop_pole_mode':'LoopPoleMode'}[option[0]]
                try:
                    MLoptions[name] = int(option[1])
                except ValueError:
                    raise self.InvalidCmd('%s expects an integer.' % option[0])
            elif option[0]=='--collier_mode':
                MLoptions['COLLIERMode']=int(option[1])
            elif option[0]=='--collier_cache':
                MLoptions['COLLIERGlobalCache']=int(option[1])
            elif option[0]=='--collier_req_acc':
                if option[1]!='auto':
                    MLoptions['COLLIERRequiredAccuracy']=float(option[1])
            elif option[0]=='--collier_internal_stability_test':
                MLoptions['COLLIERUseInternalStabilityTest']=eval(option[1])                
            elif option[0]=='--CTModeRun':
                try:
                    MLoptions['CTModeRun']=int(option[1])  
                except ValueError:
                    raise self.InvalidCmd("The value of the 'CTModeRun' option"+\
                                       " must be an integer, not %s."%option[1])
            elif option[0]=='--offshellness':
                CMS_options['offshellness'] = float(option[1])
                if CMS_options['offshellness']<=-1.0:
                    raise self.InvalidCmd('Offshellness must be number larger or'+
                           ' equal to -1.0, not %f'%CMS_options['offshellness'])
            elif option[0]=='--analyze':
                options['analyze'] = option[1]
            elif option[0]=='--show_plot':
                options['show_plot'] = 'true' in option[1].lower()
            elif option[0]=='--report':
                options['report'] = option[1].lower()
            elif option[0]=='--seed':
                options['seed'] = int(option[1])
            elif option[0]=='--name':
                if '.' in option[1]:
                    raise self.InvalidCmd("Do not specify the extension in the"+
                                                             " name of the run")
                CMS_options['name'] = option[1]
            elif option[0]=='--resonances':
                if option[1]=='all':
                    CMS_options['resonances']  = 'all'
                else:
                    try:
                        resonances=eval(option[1])
                    except:
                        raise self.InvalidCmd("Could not evaluate 'resonances'"+
                                                       " option '%s'"%option[1])
                    if isinstance(resonances,int) and resonances>0:
                        CMS_options['resonances']  = resonances
                    elif isinstance(resonances,list) and all(len(res)==2 and 
                        isinstance(res[0],int) and all(isinstance(i, int) for i in 
                                                     res[1]) for res in resonances):
                        CMS_options['resonances']  = resonances
                    else:
                        raise self.InvalidCmd("The option 'resonances' can only be 'all'"+
                               " or and integer or a list of tuples of the form "+
                               "(resPDG,(res_mothers_ID)). You gave '%s'"%option[1])
            elif option[0]=='--tweak':
                # Lists the sets of custom and widths modifications to apply
                value = option[1]
                # Set a shortcuts for applying all relevant tweaks
                if value=='alltweaks':
                    value=str(['default','seed667(seed667)','seed668(seed668)',
                      'allwidths->0.9*allwidths(widths_x_0.9)',
                      'allwidths->0.99*allwidths(widths_x_0.99)',
                      'allwidths->1.01*allwidths(widths_x_1.01)',
                      'allwidths->1.1*allwidths(widths_x_1.1)',                      
                      'logp->logm(logp2logm)','logm->logp(logm2logp)'])
                try:
                    tweaks = eval(value)
                    if isinstance(tweaks, str):
                        tweaks = [value]                         
                    elif not isinstance(tweaks,list):
                        tweaks = [value]
                except:
                    tweaks = [value]
                if not all(isinstance(t,str) for t in tweaks):
                    raise self.InvalidCmd("Invalid specification of tweaks: %s"%value)
                CMS_options['tweak'] = []
                for tweakID, tweakset in enumerate(tweaks):
                    specs =re.match(r'^(?P<tweakset>.*)\((?P<name>.*)\)$', tweakset)
                    if specs:
                        tweakset = specs.group('tweakset')
                        name    = specs.group('name')
                    else:
                        if tweakset!='default':
                            name = 'tweak_%d'%(tweakID+1)
                        else:
                            name = ''
                    new_tweak_set = {'custom':[],'params':{},'name':name}
                    for tweak in tweakset.split('&'):
                        if tweak=='default':
                            continue
                        if tweak.startswith('seed'):
                            new_tweak_set['custom'].append(tweak)
                            continue
                        try:
                            param, replacement = tweak.split('->')
                        except ValueError:
                            raise self.InvalidCmd("Tweak specification '%s'"%\
                                    tweak+" is incorrect. It should be of"+\
                                 " the form a->_any_function_of_(a,lambdaCMS).")
                        if param in ['logp','logm','log'] and \
                           replacement in ['logp','logm','log']:
                            new_tweak_set['custom'].append(tweak)
                            continue
                        try:
                            # for safety prefix parameters, because 'as' for alphas
                            # is a python reserved name for example
                            orig_param, orig_replacement = param, replacement
                            replacement = replacement.replace(param,
                                                        '__tmpprefix__%s'%param)
                            param = '__tmpprefix__%s'%param
                            res = float(eval(replacement.lower(),
                                         {'lambdacms':1.0,param.lower():98.85}))
                        except:                    
                            raise self.InvalidCmd("The substitution expression "+
                        "'%s' for the tweaked parameter"%orig_replacement+
                        " '%s' could not be evaluated. It must be an "%orig_param+
                        "expression of the parameter and 'lambdaCMS'.")
                        new_tweak_set['params'][param.lower()] = replacement.lower()
                    CMS_options['tweak'].append(new_tweak_set)

            elif option[0]=='--recompute_width':
                if option[1].lower() not in ['never','always','first_time','auto']:
                    raise self.InvalidCmd("The option 'recompute_width' can "+\
                  "only be 'never','always', 'first_time' or 'auto' (default).")
                CMS_options['recompute_width'] = option[1]
            elif option[0]=='--loop_filter':
                # Specify a loop, filter. See functions get_loop_filter and
                # user_filter in loop_diagram_generation.LoopAmplitude for
                # information on usage.
                CMS_options['loop_filter'] = '='.join(option[1:])
            elif option[0]=='--diff_lambda_power':
                #'secret' option to chose by which lambda power one should divide
                # the nwa-cms difference. Useful to set to 2 when doing the Born check
                # to see whether the NLO check will have sensitivity to the CMS
                # implementation
                try:
                    CMS_options['diff_lambda_power']=float(option[1])
                except ValueError:
                    raise self.InvalidCmd("the '--diff_lambda_power' option"+\
                            " must be an integer or float, not '%s'."%option[1])
            elif option[0]=='--lambda_plot_range':
                try:
                    plot_range=eval(option[1])
                except Exception as e:
                    raise self.InvalidCmd("The plot range specified %s"%option[1]+\
                                   " is not a valid syntax. Error:\n%s"%str(e))
                if not isinstance(plot_range,(list,tuple)) or \
                    len(plot_range)!=2 or any(not isinstance(p,(float,int)) 
                                                           for p in plot_range):                    
                    raise self.InvalidCmd("The plot range specified %s"\
                                                       %option[1]+" is invalid")
                CMS_options['lambda_plot_range']=list([float(p) for p in plot_range])
            elif option[0]=='--lambdaCMS':
                try:
                    lambda_values = eval(option[1])
                except SyntaxError:
                    raise self.InvalidCmd("'%s' is not a correct"%option[1]+
                                     " python expression for lambdaCMS values.")
                if isinstance(lambda_values,list):
                    if lambda_values[0]!=1.0:
                        raise self.InvalidCmd("The first value of the lambdaCMS values"+
                                " specified must be 1.0, not %s"%str(lambda_values))
                    for l in lambda_values:
                        if not isinstance(l,float):
                            raise self.InvalidCmd("All lambda CMS values must be"+
                                                          " float, not '%s'"%str(l))
                elif isinstance(lambda_values,(tuple,float)):
                    # Format here is then (lower_bound, N) were lower_bound is
                    # the minimum lambdaCMS value that must be probed and the
                    # integer N is the number of such values that must be 
                    # uniformly distributed in each intervale [1.0e-i,1.0e-(i+1)]
                    if isinstance(lambda_values, float):
                        # Use default of 10 for the number of lambda values
                        lower_bound = lambda_values
                        N = 10
                    else:
                        if isinstance(lambda_values[0],float) and \
                           isinstance(lambda_values[1],int):
                            lower_bound = lambda_values[0]
                            N = lambda_values[1]
                        else:
                            raise self.InvalidCmd("'%s' must be a "%option[1]+
                                               "tuple with types (float, int).")
                    lambda_values = create_lambda_values_list(lower_bound,N)
                else:
                    raise self.InvalidCmd("'%s' must be an expression"%option[1]+
                                          " for either a float, tuple or list.")
                lower_bound = lambda_values[-1]
                # and finally add 5 points for stability test on the last values
                # Depending on how the stab test will behave at NLO, we can 
                # consider automatically adding the values below
#                for stab in range(1,6):
#                    lambda_values.append((1.0+(stab/100.0))*lower_bound)

                CMS_options['lambdaCMS'] = lambda_values
            elif option[0]=='--cms':
                try:
                    CMS_expansion_orders, CMS_expansion_parameters = \
                                                            option[1].split(',')
                except ValueError:
                    raise self.InvalidCmd("CMS expansion specification '%s'"%\
                                                       args[i]+" is incorrect.")
                CMS_options['expansion_orders'] = [expansion_order for 
                             expansion_order in CMS_expansion_orders.split('&')]
                CMS_options['expansion_parameters'] = {}
                for expansion_parameter in CMS_expansion_parameters.split('&'):
                    try:
                        param, replacement = expansion_parameter.split('->')
                    except ValueError:
                        raise self.InvalidCmd("CMS expansion specification '%s'"%\
                          expansion_parameter+" is incorrect. It should be of"+\
                                 " the form a->_any_function_of_(a,lambdaCMS).")
                    try:
                        # for safety prefix parameters, because 'as' for alphas
                        # is a python reserved name for example
                        orig_param, orig_replacement = param, replacement
                        replacement = replacement.replace(param,
                                                        '__tmpprefix__%s'%param)
                        param = '__tmpprefix__%s'%param
                        res = float(eval(replacement.lower(),
                                         {'lambdacms':1.0,param.lower():98.85}))
                    except:                    
                        raise self.InvalidCmd("The substitution expression "+
                        "'%s' for CMS expansion parameter"%orig_replacement+
                        " '%s' could not be evaluated. It must be an "%orig_param+
                        "expression of the parameter and 'lambdaCMS'.")
                    # Put everything lower case as it will be done when
                    # accessing model variables
                    CMS_options['expansion_parameters'][param.lower()]=\
                                                             replacement.lower()
            else:
                raise self.InvalidCmd("The option '%s' is not reckognized."%option[0])

            i=i-1
        args = args[:i+1]
        
        if args[0]=='options':
            # Simple printout of the check command options
            logger_check.info("Options for the command 'check' are:")
            logger_check.info("{:<20}     {}".format('  name','default value'))
            logger_check.info("-"*40)
            for key, value in options.items():
                logger_check.info("{:<20} =   {}".format('--%s'%key,str(value)))
            return

        if args[0].lower()=='cmsoptions':
            # Simple printout of the special check cms options
            logger_check.info("Special options for the command 'check cms' are:")
            logger_check.info("{:<20}     {}".format('  name','default value'))
            logger_check.info("-"*40)
            for key, value in CMS_options.items():
                logger_check.info("{:<20} =   {}".format('--%s'%key,str(value)))
            return        
        
        # Set the seed here if not in cms check and if specified
        if args[0]!='cms' and options['seed']!=-1:
            # Not necessarily optimal as there could be additional call to
            # random() as the code develops, but at least it will encompass
            # everything in this way.
            
            if not hasattr(random, 'mg_seedset'):
                logger_check.info('Setting random seed to %d.'%options['seed'])
                random.seed(options['seed'])  
                random.mg_seedset = options['seed']
        
        proc_line = " ".join(args[1:])
        # Don't try to extract the process if just re-analyzing a saved run
        if not (args[0]=='cms' and options['analyze']!='None'):
            myprocdef = self.extract_process(proc_line)
            if myprocdef and myprocdef.get_interference_mode():
                raise self.InvalidCmd(
                    "The check command does not support %s interference "
                    "processes: generate the process and use 'output "
                    "standalone_fortran', whose check executable prints the "
                    "interference and, as cross-checks, the squared loop and "
                    "tree amplitudes (complete only with HelicityFilterLevel "
                    "0 in MadLoopParams.dat, the filter being set on the "
                    "interference)."
                    % myprocdef.get_interference_mode())

            # Check that we have something
            if not myprocdef:
                raise self.InvalidCmd("Empty or wrong format process, please try again.")
            # For the check command, only the mode 'virt' make sense.
            if myprocdef.get('NLO_mode')=='all':
                myprocdef.set('NLO_mode','virt')
        else:
            myprocdef = None
            
        # If the test has to write out on disk, it should do so at the location
        # specified below where the user must be sure to have writing access.
        output_path = os.getcwd()

        if args[0] in ['timing','stability', 'profile'] and not \
                                        myprocdef.get('perturbation_couplings'):
            raise self.InvalidCmd("Only loop processes can have their "+
                                  " timings or stability checked.")

        if args[0]=='gauge' and \
                    not myprocdef.get('perturbation_couplings') in [[],['QCD']]:
            raise self.InvalidCmd(
"""Feynman vs unitary gauge comparisons can only be done if there are no loop
   propagators affected by this gauge. Typically, either processes at tree level
   or including only QCD perturbations can be considered here.""")

        if args[0]=='gauge' and len(self._curr_model.get('gauge')) < 2:
            raise self.InvalidCmd("The current model does not allow for both "+\
                                                   "Feynman and unitary gauge.")

        # Disable some loggers
        loggers = [logging.getLogger('madgraph.diagram_generation'),
                   logging.getLogger('madgraph.loop_diagram_generation'),
                   logging.getLogger('ALOHA'),
                   logging.getLogger('madgraph.helas_objects'),
                   logging.getLogger('madgraph.loop_exporter'),
                   logging.getLogger('madgraph.export_v4'),
                   logging.getLogger('cmdprint'),
                   logging.getLogger('madgraph.model'),
                   logging.getLogger('madgraph.base_objects')]
        old_levels = [log.level for log in loggers]
        for log in loggers:
            log.setLevel(logging.WARNING)

        # run the check
        cpu_time1 = time.time()
        # Run matrix element generation check on processes

        # The aloha python output has trouble when doing (tree level of course)
        # python output and that loop_mode is True at the beginning.
        # So as a temporary fix for the problem that after doing a check at NLO
        # then a check at LO will fail, I make sure I set it to False if the
        # process is a tree-level one
        if myprocdef:
            if myprocdef.get('perturbation_couplings')==[]:
                aloha.loop_mode = False

        comparisons = []
        gauge_result = []
        gauge_result_no_brs = []
        lorentz_result =[]
        nb_processes = 0
        timings = []
        stability = []
        profile_time = []
        profile_stab = []
        cms_results = []
        flavor_result = []
        language_result = []
        precision_result = []

        if MLoptions.get('TIRustComputeFinite') is False and args[0] in ('timing', 'profile', 'stability'):
            raise self.InvalidCmd('TIRust poles-only mode uses the tensor diagnostic interface; amplitude checks require finite results.')
        if automatic_reduction and myprocdef and myprocdef.get('has_born'):
            from madgraph.various import ninjars_install
            MLoptions['MLReductionLib'] = ninjars_install.default_reduction_library(
                myprocdef.get('has_born'), self.options.get('ninjars'))

        if "_cuttools_dir" in dir(self):
            CT_dir = self._cuttools_dir
        else:
            CT_dir =""
            if "MLReductionLib" in MLoptions:
                if 1 in MLoptions["MLReductionLib"]:
                    MLoptions["MLReductionLib"].remove(1)
        # directories for TIR
        TIR_dir={}
        if "_iregi_dir" in dir(self):
            TIR_dir['iregi_dir']=self._iregi_dir
        else:
            if "MLReductionLib" in MLoptions:
                if 3 in MLoptions["MLReductionLib"]:
                    logger_check.warning('IREGI not available on your system; it will be skipped.')                    
                    MLoptions["MLReductionLib"].remove(3)


        if "MLReductionLib" in MLoptions:
            if 2 in MLoptions["MLReductionLib"]:
                logger_check.warning('PJFRY not supported anymore; it will be skipped.')                    
                MLoptions["MLReductionLib"].remove(2)
                    
        if 'golem' in self.options and isinstance(self.options['golem'],str):
            TIR_dir['golem_dir']=self.options['golem']
        else:
            if "MLReductionLib" in MLoptions:
                if 4 in MLoptions["MLReductionLib"]:
                    logger_check.warning('GOLEM not available on your system; it will be skipped.')
                    MLoptions["MLReductionLib"].remove(4)
        
        if 'samurai' in self.options and isinstance(self.options['samurai'],str):
            TIR_dir['samurai_dir']=self.options['samurai']
        else:
            if "MLReductionLib" in MLoptions:
                if 5 in MLoptions["MLReductionLib"]:
                    logger_check.warning('Samurai not available on your system; it will be skipped.')
                    MLoptions["MLReductionLib"].remove(5)
        
        if 'collier' in self.options and isinstance(self.options['collier'],str):
            TIR_dir['collier_dir']=self.options['collier']
        else:
            if "MLReductionLib" in MLoptions:
                if 7 in MLoptions["MLReductionLib"]:
                    logger_check.warning('Collier not available on your system; it will be skipped.')
                    MLoptions["MLReductionLib"].remove(7)
        
        if 'ninja' in self.options and isinstance(self.options['ninja'],str):
            TIR_dir['ninja_dir']=self.options['ninja']
        else:
            if "MLReductionLib" in MLoptions:
                if 6 in MLoptions["MLReductionLib"]:
                    logger_check.warning('Ninja not available on your system; it will be skipped.')
                    MLoptions["MLReductionLib"].remove(6)

        if isinstance(self.options.get('ninjars'), str):
            from madgraph.various import ninjars_install
            TIR_dir['ninjars_dir'] = self.options['ninjars']
            if 8 in MLoptions.get('MLReductionLib', []) and not ninjars_install.is_available(
                    self.options['ninjars']):
                raise self.InvalidCmd("NinjaRS is unavailable or unusable at %s. "
                                      "Run 'install ninjars --update'." %
                                      self.options['ninjars'])
        elif 8 in MLoptions.get('MLReductionLib', []):
            raise self.InvalidCmd("NinjaRS is disabled. Run 'install ninjars' "
                                  "or set ninjars to its library directory.")
        
        if isinstance(self.options.get('tirust'), str):
            from madgraph.various import tirust_install
            TIR_dir['tirust_dir'] = self.options['tirust']
            if 9 in MLoptions.get('MLReductionLib', []) and not tirust_install.is_available(
                    self.options['tirust']):
                raise self.InvalidCmd("TIRust is unavailable or unusable at %s. "
                                      "Run 'install tirust --update'." %
                                      self.options['tirust'])
        elif 9 in MLoptions.get('MLReductionLib', []):
            raise self.InvalidCmd("TIRust is disabled. Run 'install tirust' "
                                  "or set tirust to its library directory.")

        if args[0] in ['timing']:
            timings = process_checks.check_timing(myprocdef,
                                                  param_card = param_card,
                                                  cuttools=CT_dir,
                                                  tir=TIR_dir,
                                                  options = options,
                                                  cmd = self,
                                                  output_path = output_path,
                                                  MLOptions = MLoptions
                                                  )        

        if args[0] in ['stability']:
            stability=process_checks.check_stability(myprocdef,
                                                  param_card = param_card,
                                                  cuttools=CT_dir,
                                                  tir=TIR_dir,
                                                  options = options,
                                                  output_path = output_path,
                                                  cmd = self,
                                                  MLOptions = MLoptions)

        if args[0] in ['profile']:
            # In this case timing and stability will be checked one after the
            # other without re-generating the process.
            profile_time, profile_stab = process_checks.check_profile(myprocdef,
                                                  param_card = param_card,
                                                  cuttools=CT_dir,
                                                  tir=TIR_dir,
                                                  options = options,
                                                  MLOptions = MLoptions,
                                                  output_path = output_path,
                                                  cmd = self)

        if args[0] in  ['gauge', 'full'] and \
          len(self._curr_model.get('gauge')) == 2 and\
                        myprocdef.get('perturbation_couplings') in [[],['QCD']]:

            line = " ".join(args[1:])
            myprocdef = self.extract_process(line)
            if gauge == 'unitary':
                myprocdef_unit = myprocdef
            else:
                self.do_set('gauge unitary', log=False)
                myprocdef_unit = self.extract_process(line)
            if gauge == 'feynman':
                myprocdef_feyn = myprocdef
            else:
                self.do_set('gauge Feynman', log=False)
                myprocdef_feyn = self.extract_process(line)
            if myprocdef.get('perturbation_couplings') == [] and \
               (args[0] == 'full' or (args[0] == 'gauge')) and \
               0 in self._curr_model.get('gauge'):
                if gauge == 'axial':
                    myprocdef_axial = myprocdef
                else:
                    self.do_set('gauge axial', log=False)
                    myprocdef_axial = self.extract_process(line)
            else:
                myprocdef_axial = None
            if myprocdef.get('perturbation_couplings') == [] and \
               (args[0] == 'full' or (args[0] == 'gauge')) and \
               1 in self._curr_model.get('gauge'):
                if gauge == 'FD':
                    myprocdef_fd = myprocdef
                else:
                    self.do_set('gauge FD', log=False)
                    myprocdef_fd = self.extract_process(line)
            else:
                myprocdef_fd = None

            nb_part_unit = len(myprocdef_unit.get('model').get('particles'))
            nb_part_feyn = len(myprocdef_feyn.get('model').get('particles'))
            if nb_part_feyn == nb_part_unit:
                logger_check.error('No Goldstone present for this check!!')
            gauge_result_no_brs = process_checks.check_unitary_feynman(
                                                myprocdef_unit, myprocdef_feyn,
                                                myprocdef_axial,
                                                myprocdef_fd,
                                                param_card = param_card,
                                                options=options,
                                                cuttools=CT_dir,
                                                tir=TIR_dir,
                                                reuse = options['reuse'],
                                                output_path = output_path,
                                                cmd = self)
            
            # restore previous settings
            self.do_set('gauge %s' % gauge, log=False)
            nb_processes += len(gauge_result_no_brs)            

        if args[0] in  ['permutation', 'full']:
            comparisons = process_checks.check_processes(myprocdef,
                                            param_card = param_card,
                                            quick = True,
                                            cuttools=CT_dir,
                                            tir=TIR_dir,
                                            reuse = options['reuse'],
                                            cmd = self,
                                            output_path = output_path,
                                            options=options)
            nb_processes += len(comparisons[0])

        if args[0] in ['lorentz', 'full']:
            myprocdeff = copy.copy(myprocdef)
            lorentz_result = process_checks.check_lorentz(myprocdeff,
                                          param_card = param_card,
                                          cuttools=CT_dir,
                                          tir=TIR_dir,
                                          reuse = options['reuse'],
                                          cmd = self,
                                          output_path = output_path,
                                          options=options)
            nb_processes += len(lorentz_result)

        _merged_pdgs = myprocdef.get('model').get('merged_particles') if myprocdef else {}
        _proc_has_merged = myprocdef and any(
            abs(pid) in _merged_pdgs
            for leg in myprocdef.get('legs')
            for pid in leg.get('ids'))
        if args[0] in ['flavor'] or (args[0] == 'full' and _proc_has_merged):
            flavor_result = process_checks.check_flavor(myprocdef,
                                          param_card = param_card,
                                          options=options,
                                          cmd = self)
            nb_processes += len(flavor_result)

        if args[0] in ['language']:
            language_result = process_checks.check_language(myprocdef,
                                          param_card = param_card,
                                          options=options,
                                          cmd = self)
            nb_processes += len(language_result)

        if args[0] in ['precision']:
            precision_result = process_checks.check_precision(myprocdef,
                                          options['precision_mode'],
                                          param_card = param_card,
                                          options=options,
                                          cmd = self,
                                          output_path = output_path)
            nb_processes += len(precision_result)

        if args[0] in  ['brs', 'full']:
            gauge_result = process_checks.check_gauge(myprocdef,
                                          param_card = param_card,
                                          cuttools=CT_dir,
                                          tir=TIR_dir,
                                          reuse = options['reuse'],
                                          cmd = self,
                                          output_path = output_path,
                                          options=options)
            nb_processes += len(gauge_result)

        # The CMS check is typically more complicated and slower than others
        # so we don't run it automatically with 'full'.
        if args[0] in ['cms']:
            
            cms_original_setup = self.options['complex_mass_scheme']
            process_line = " ".join(args[1:])
            # Merge in the CMS_options to the options
            for key, value in CMS_options.items():
                if key=='tweak':
                    continue
                if key not in options:
                    options[key] = value
                else:
                    raise MadGraph5Error("Option '%s' is both in the option"%key+\
                                                   " and CMS_option dictionary.") 
            
            if options['analyze']=='None':
                cms_results = []
                for tweak in CMS_options['tweak']:
                    options['tweak']=tweak
                    # Try to guess the save path and try to load it before running
                    guessed_proc = myprocdef.get_process(
                      [leg.get('ids')[0] for leg in myprocdef.get('legs') 
                                                       if not leg.get('state')],
                      [leg.get('ids')[0] for leg in myprocdef.get('legs')
                                                           if leg.get('state')])
                    save_path = process_checks.CMS_save_path('pkl',
                    {'ordered_processes':[guessed_proc.base_string()],
                     'perturbation_orders':guessed_proc.get('perturbation_couplings')}, 
                             self._curr_model, options, output_path=output_path)
                    if os.path.isfile(save_path) and options['reuse']:
                        cms_result = save_load_object.load_from_file(save_path)
                        logger_check.info("The cms check for tweak %s is recycled from file:\n %s"%
                                                      (tweak['name'],save_path))
                        if cms_result is None:
                            raise self.InvalidCmd('The complex mass scheme check result'+
                            " file below could not be read.\n     %s"%save_path)
                    else:      
                        cms_result = process_checks.check_complex_mass_scheme(
                                              process_line,
                                              param_card = param_card,
                                              cuttools=CT_dir,
                                              tir=TIR_dir,
                                              cmd = self,
                                              output_path = output_path,
                                              MLOptions = MLoptions,
                                              options=options)
                        # Now set the correct save path
                        save_path = process_checks.CMS_save_path('pkl', cms_result, 
                             self._curr_model, options, output_path=output_path)
                    cms_results.append((cms_result,save_path,tweak['name']))
            else:
                cms_result = save_load_object.load_from_file(
                                               options['analyze'].split(',')[0])
                cms_results.append((cms_result,options['analyze'].split(',')[0],
                                               CMS_options['tweak'][0]['name']))
                if cms_result is None:
                    raise self.InvalidCmd('The complex mass scheme check result'+
                       " file below could not be read.\n     %s"
                                              %options['analyze'].split(',')[0])

            # restore previous settings
            self.do_set('complex_mass_scheme %s'%str(cms_original_setup),
                                                                      log=False)
            # Use here additional key 'ordered_processes'
            nb_processes += len(cms_result['ordered_processes'])

        cpu_time2 = time.time()
        logger_check.info("%i check performed in %s"% (nb_processes,
                                  misc.format_time(int(cpu_time2 - cpu_time1))))

        if args[0] in ['cms']:
                text = "Note that the complex mass scheme test in principle only\n"
                text+= "works for stable particles in final states.\n\ns"            
        if args[0] not in ['timing','stability', 'profile', 'cms']:
            if self.options['complex_mass_scheme']:
                text = "Note that Complex mass scheme gives gauge/lorentz invariant\n"
                text+= "results only for stable particles in final states.\n\ns"
            elif ((not args or args[0] not in ['language', 'precision']) and
                  not myprocdef.get('perturbation_couplings')):
                text = "Note That all width have been set to zero for those checks\n\n"
            else:
                text = "\n"
        else:
            text ="\n"

        if timings:
            text += 'Timing result for the '+('optimized' if \
              self.options['loop_optimized_output'] else 'default')+' output:\n'

            text += process_checks.output_timings(myprocdef, timings)
        if stability:
            text += 'Stability result for the '+('optimized' if \
              self.options['loop_optimized_output'] else 'default')+' output:\n'
            text += process_checks.output_stability(stability,output_path)

        if profile_time and profile_stab:
            text += 'Timing result '+('optimized' if \
                    self.options['loop_optimized_output'] else 'default')+':\n'
            text += process_checks.output_profile(myprocdef, profile_stab,
                             profile_time, output_path, options['reuse']) + '\n'
        if lorentz_result:
            text += 'Lorentz invariance results:\n'
            text += process_checks.output_lorentz_inv(lorentz_result) + '\n'
        if flavor_result:
            text += 'Flavor grouping check results:\n'
            text += process_checks.output_flavor(flavor_result) + '\n'
        if language_result:
            text += 'Language comparison results (Fortran SA / C++ SA / MG7 SA / Python):\n'
            text += process_checks.output_language(language_result) + '\n'
        if precision_result:
            text += 'Floating point precision results (madmatrix standalone):\n'
            text += process_checks.output_precision(precision_result) + '\n'
        if gauge_result:
            text += 'Gauge results:\n'
            text += process_checks.output_gauge(gauge_result) + '\n'
        if gauge_result_no_brs:
            gauge_labels = ['Unitary', 'Feynman']
            if any('value_axial' in res for res in gauge_result_no_brs[1:]):
                gauge_labels.append('Axial')
            if any('value_fd' in res for res in gauge_result_no_brs[1:]):
                gauge_labels.append('FD')
            text += 'Gauge results (switching between %s gauge):\n' % '/'.join(gauge_labels)
            text += process_checks.output_unitary_feynman(gauge_result_no_brs) + '\n'
        if cms_results:
            text += 'Complex mass scheme results (varying width in the off-shell regions):\n'
            cms_result = cms_results[0][0]
            if len(cms_results)>1:
                analyze = []
                for i, (cms_res, save_path, tweakname) in enumerate(cms_results):
                    save_load_object.save_to_file(save_path, cms_res)
                    logger_check.info("Pickle file for tweak '%s' saved to disk at:\n ->%s"%
                                                          (tweakname,save_path))
                    if i==0:
                        analyze.append(save_path)
                    else:
                        analyze.append('%s(%s)'%(save_path,tweakname))
                options['analyze']=','.join(analyze)
                options['tweak']  = CMS_options['tweak'][0]
            
            self._cms_checks.append({'line':line, 'cms_result':cms_result,
                                  'options':options, 'output_path':output_path})
            text += process_checks.output_complex_mass_scheme(cms_result,
              output_path, options, self._curr_model,
              output='concise_text' if options['report']=='concise' else 'text')+'\n'

        if comparisons and len(comparisons[0])>0:
            text += 'Process permutation results:\n'
            text += process_checks.output_comparisons(comparisons[0]) + '\n'
            self._comparisons = comparisons

        # We use the reuse tag for an alternative way of skipping the pager.
        if len(text.split('\n'))>20 and not '-reuse' in line and text!='':
            if 'test_manager' not in sys.argv[0]:
                pydoc.pager(text)

        # Restore diagram logger
        for i, log in enumerate(loggers):
            log.setLevel(old_levels[i])

        # Output the result to the interface directly if short enough or if it
        # was anyway not output to the pager
        if len(text.split('\n'))<=20 or options['reuse']:
            # Useful to really specify what logger is used for ML acceptance tests
            logging.getLogger('madgraph.check_cmd').info(text)
        else:
            logging.getLogger('madgraph.check_cmd').debug(text)

        # clean the globals created.
        process_checks.clean_added_globals(process_checks.ADDED_GLOBAL)
        if not options['reuse']:
            process_checks.clean_up(self._mgme_dir)


    def clean_process(self):
        """ensure that all processes are cleaned from memory.
        typically called from import model and generate XXX command
        """

        aloha_lib.KERNEL.clean()
        # Reset amplitudes
        self._curr_amps = diagram_generation.AmplitudeList()
        # Reset Process definition
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        # Reset Helas matrix elements
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        self._generate_info = ""
        # Reset the diagrams kept for an 'auto' merge_quartic_vertices, they
        # describe the amplitudes just dropped
        self._quartic_order = None
        self._quartic_pristine = None
        # Reset polarization-citation marker (a new process definition starts)
        self._uses_polarization = False
        self._uses_density_matrix = False
        self._uses_quarkonia = False
        # Reset _done_export, since we have new process
        self._done_export = False
        # Also reset _export_format and _export_dir
        self._export_format = None        
        
            
    # Generate a new amplitude
    def do_generate(self, line):
        """Main commands: Generate an amplitude for a given process"""

        self.clean_process()
        self._generate_info = line

        # reset P-wave onia counter for new process
        aloha.npwave = [0]

        # Call add process
        args = self.split_arg(line)
        args.insert(0, 'process')
        self.do_add(" ".join(args))

    # The braces that name a piece of the *propagator* numerator of a massive
    # vector and nothing else: they have no external-wavefunction counterpart
    # (there is no VXXXXX helicity for them), so on a genuine external leg the
    # integer would be written straight into the NHEL table and VXXXXX would
    # quietly return a meaningless vector. See aloha/create_aloha.py for the
    # numerators ("1G", "1H", ...) and [arXiv:2512.10015] for the definitions.
    # '{A}' (99) is deliberately absent: it is already refused on an external
    # leg by HelasWavefunction and keeps that behaviour unchanged here.
    PROPAGATOR_ONLY_POLARIZATIONS = {4: ('G', 'the metric piece -g^{mu nu}'),
                                     5: ('H', 'the Theta projector'),
                                     6: ('Q', 'the q^mu q^nu / q^2 tensor'),
                                     7: ('W', 'the Ward-protected full '
                                              'propagator'),
                                     9: ('S', 'the scalar piece '
                                              '(axial + finite width)'),
                                     }

    def validate_propagator_polarization(self, procdef):
        """Validate the propagator-only polarization braces of a
        ProcessDefinition and of its decay chains.

        '{G}', '{H}', '{Q}', '{W}' and '{S}' (pol=4,5,6,7,9) each name a
        rank-two piece of the propagator numerator of a massive vector,
        complete with its 1/(q^2-M^2+iM*Gamma) pole; none of them is a
        polarisation vector, and no external wavefunction for them exists
        (VXXXXX only knows nhel = -1,0,+1).

        They are therefore allowed on a leg that is handed over to a decay
        chain -- the propagator use, 't > w+{G} b, w+ > ta+ vt' -- and refused
        on a genuine external leg of the process, initial or final. There is
        no option to enable them on an external leg: there is nothing to
        enable. Without this check the raw integer reached the NHEL table and
        the generated code silently returned a wrong number.

        Raises InvalidCmd; returns None.
        """
        if procdef is None:
            return
        # pdgs that this level hands over to a decay chain: those legs become
        # internal propagators, which is the case these braces were written for.
        decayed_ids = set()
        for decay in procdef.get('decay_chains'):
            for leg in decay.get('legs'):
                if not leg.get('state'):
                    decayed_ids.update(leg.get('ids'))

        for leg in procdef.get('legs'):
            if decayed_ids.intersection(leg.get('ids')):
                # propagator: the leg is replaced by the decay chain
                continue
            for value in leg.get('polarization'):
                if value not in self.PROPAGATOR_ONLY_POLARIZATIONS:
                    continue
                tag, what = self.PROPAGATOR_ONLY_POLARIZATIONS[value]
                raise self.InvalidCmd(
                    'The polarization {%s} is %s of a massive vector '
                    'propagator, not a polarization vector: it exists '
                    'only for an internal line. It is allowed on a '
                    'particle that is decayed further (write '
                    '"t > w+{%s} b, w+ > ta+ vt"), and is not allowed on '
                    '%s-state particle of the process.'
                    % (tag, what, tag,
                       'a final' if leg.get('state') else 'an initial'))

        for decay in procdef.get('decay_chains'):
            self.validate_propagator_polarization(decay)

    def extract_process(self, line, proc_number = 0, overall_orders = {},
                        avoid_squared_orders=False):
        """Extract a process definition from a string. Returns
        a ProcessDefinition."""

        # 'left [LIxtree=QCD] right' / 'left [treextree] right': two processes
        # on one line, see extract_interference_process
        left, mode, right = split_interference_line(line)
        if mode:
            return self.extract_interference_process(left, mode, right,
                                    proc_number=proc_number,
                                    overall_orders=overall_orders,
                                    avoid_squared_orders=avoid_squared_orders)

        orig_line = line
        # Check basic validity of the line
        if not len(re.findall(r'>\D', line)) in [1,2]:
            self.do_help('generate')
            raise self.InvalidCmd('Wrong use of \">\" special character.')


        # Perform sanity modifications on the lines:
        # Add a space before and after any > , $ / | [ ]
        space_before = re.compile(r"(?P<carac>\S)(?P<tag>[\\[\\]/\,\\$\\>|])(?P<carac2>\S)")
        line = space_before.sub(r'\g<carac> \g<tag> \g<carac2>', line)

        # Use regular expressions to extract s-channel propagators,
        # forbidden s-channel propagators/particles, coupling orders
        # and process number, starting from the back

        # Start with process number (identified by "@")
        proc_number_pattern = re.compile(r"^(.+)@\s*(\d+)\s*(.*)$")
        proc_number_re = proc_number_pattern.match(line)
        if proc_number_re:
            proc_number = int(proc_number_re.group(2))
            line = proc_number_re.group(1)+ proc_number_re.group(3)
            #overall_order are already handle but it is better to pass the info to each group
        
        # Now check for perturbation orders, specified in between squared brackets
        perturbation_couplings_pattern = \
          re.compile(r"^(?P<proc>.+>.+)\s*\[\s*((?P<option>\w+)\s*\=)?\s*"+\
                               r"(?P<pertOrders>(\w+\s*)*)\s*\]\s*(?P<rest>.*)$")
        perturbation_couplings_re = perturbation_couplings_pattern.match(line)
        perturbation_couplings = ""
        LoopOption= 'tree'
        HasBorn= True
        if perturbation_couplings_re:
            perturbation_couplings = perturbation_couplings_re.group("pertOrders")
            option=perturbation_couplings_re.group("option")
            if option:
                if option in self._valid_nlo_modes:
                    LoopOption=option
                    if option=='sqrvirt':
                        LoopOption='virt'
                        HasBorn=False
                    elif option=='noborn':
                        HasBorn=False
                else:
                    raise self.InvalidCmd("NLO mode %s is not valid. "%option+\
                       "Valid modes are %s. "%str(self._valid_nlo_modes))
            else:
                LoopOption='all'

            line = perturbation_couplings_re.group("proc")+\
                     perturbation_couplings_re.group("rest")

        if LoopOption != 'tree' and self.options['gauge'] in ['FD','axial']:
            raise Exception('Gauge %s is only supported/validated for tree level amplitude'% self.options['gauge'])

        ## Now check for orders/squared orders/constrained orders
        order_pattern = re.compile(\
           r"^(?P<before>.+>.+)\s+(?P<name>(\w|(\^2))+)\s*(?P<type>"+\
                    r"(=|(<=)|(==)|(===)|(!=)|(>=)|<|>))\s*(?P<value>-?\d+)\s*?(?P<after>.*)")
        order_re = order_pattern.match(line)
        squared_orders = {}
        orders = {}
        constrained_orders = {}
        
        # define the various coupling order alias 
        coupling_alias = {}
        model_orders = self._curr_model.get('coupling_orders')
        if 'EW' in model_orders:
            if 'QED' not in model_orders:
                coupling_alias['QED'] = 'EW'
                coupling_alias['QED^2'] = 'EW^2'
            if 'aEW' not in model_orders:
                coupling_alias['aEW'] = 'EW^2=2*'
        elif 'QED' in model_orders:
            coupling_alias['EW'] = 'QED'
            coupling_alias['EW^2'] = 'QED^2'
            if 'aEW' not in model_orders:
                coupling_alias['aEW'] = 'QED^2=2*'
        if 'QCD' in model_orders:
            if 'aS' not in model_orders:
                coupling_alias['aS'] = 'QCD^2=2*'
        
        ## The 'split_orders' (i.e. those for which individual matrix element
        ## evaluations must be provided for each corresponding order value) are
        ## defined from the orders specified in between [] and any order for
        ## which there are squared order constraints.
        split_orders = []
        while order_re:
            type = order_re.group('type')
            name =  order_re.group('name')
            value = int(order_re.group('value'))
            if name in coupling_alias:
                old_name,old_value = name,value
                
                name = coupling_alias[name]
                if name.endswith('=2*'):
                    name = name[:-3]
                    value *= 2
                logger.info("change syntax %s=%s to %s=%s to correspond to UFO model convention", 
                            old_name, old_value, name, value)
            if name.endswith('^2'):
                basename = name[:-2]
                if basename not in list(model_orders) + ['WEIGHTED']:
                    valid = list(model_orders) +list(coupling_alias.keys()) + ['WEIGHTED']
                    raise self.InvalidCmd("model order %s not valid for this model (valid one are: %s). Please correct" % (name, ', '.join(valid))) 

                if type not in self._valid_sqso_types:
                    raise self.InvalidCmd("Type of squared order "+\
                                 "constraint '%s'"% type+" is not supported.")
                if type == '=':
                    logger.warning("Interpreting '%(n)s=%(v)s' as '%(n)s<=%(v)s'" %\
                                       {'n':name, 'v': value})
                    type = "<="
                squared_orders[basename] = (value,type)
            else:
                if name not in model_orders and name!='WEIGHTED':
                    valid = list(model_orders) + list(coupling_alias.keys())
                    raise self.InvalidCmd("model order %s not valid for this model (valid one are: %s). Please correct" % (name, ', '.join(valid))) 
                if type not in self._valid_amp_so_types:
                    raise self.InvalidCmd("Amplitude order constraints can only be of type %s"%\
                    (', '.join(self._valid_amp_so_types))+", not '%s'."%type)
                name = order_re.group('name')
                value = int(order_re.group('value'))
                if type in ['=', '<=']:
                    if type == '=' and value != 0:
                        logger.warning("Interpreting '%(n)s=%(v)s' as '%(n)s<=%(v)s'" %\
                                       {'n':name, 'v': value}) 
                    orders[name] = value
                elif type == "==":
                    constrained_orders[name] = (value, type)
                    if not avoid_squared_orders and name not in squared_orders:
                        squared_orders[name] = (2 * value,'==')
                    if True:#name not in orders:
                        orders[name] = value
                    
                elif type == ">":
                    constrained_orders[name] = (value, type)
                    if not avoid_squared_orders and name not in squared_orders:
                        squared_orders[name] = (2 * value,'>')
            
            line = '%s %s' % (order_re.group('before'),order_re.group('after')) 
            order_re = order_pattern.match(line)   
                   
        # handle the case where default is not 99 and some coupling defined
        if self.options['default_unset_couplings'] != 99 and \
                                                     (orders or squared_orders): 
                           
                to_set = [name for name in base_objects.visible_orders(
                                       self._curr_model.get('coupling_orders'))
                          if name not in orders and name not in squared_orders]
                if to_set:
                    logger.info('the following coupling will be allowed up to the maximal value of %s: %s' % 
                            (self.options['default_unset_couplings'], ', '.join(to_set)), '$MG:BOLD')
                for name in to_set:
                    orders[name] = int(self.options['default_unset_couplings'])
        
        #only allow amplitue restrctions >/ == for LO/tree level
        if constrained_orders and LoopOption != 'tree':
            raise self.InvalidCmd("Amplitude order constraints (for not LO processes) can only be of type %s"%\
                        (', '.join(['<=']))+", not '%s'."%type)

        # If the squared orders are defined but not the orders, assume 
        # orders=sq_orders. In case the squared order has a negative value or is
        # defined with the '>' operator, then this order correspondingly set to
        # be maximal (99) since there is no way to know, during generation, if 
        # the amplitude being constructed will be leading or not.
        # This only applies when no perturbation couplings are provided, ie
        # for LO-only generation
        if orders=={} and squared_orders!={} and not perturbation_couplings:
            for order in squared_orders.keys():
                if squared_orders[order][0]>=0 and squared_orders[order][1]!='>':
                    orders[order]=squared_orders[order][0]
                else:
                    orders[order]=99
        

        if not self._curr_model['case_sensitive']:
            # Particle names lowercase
            line = line.lower()

        # Now check for forbidden particles, specified using "/"
        slash = line.find("/")
        dollar = line.find("$")
        forbidden_particles = ""
        if slash > 0:
            if dollar > slash:
                forbidden_particles_re = re.match(r"^(.+)\s*/\s*(.+\s*)(\$.*)$", line)
            else:
                forbidden_particles_re = re.match(r"^(.+)\s*/\s*(.+\s*)$", line)
            if forbidden_particles_re:
                forbidden_particles = forbidden_particles_re.group(2)
                line = forbidden_particles_re.group(1)
                if len(forbidden_particles_re.groups()) > 2:
                    line = line + forbidden_particles_re.group(3)

        # Now check for forbidden schannels, specified using "$$"
        forbidden_schannels_re = re.match(r"^(.+)\s*\$\s*\$\s*(.+)\s*$", line)
        forbidden_schannels = ""
        if forbidden_schannels_re:
            forbidden_schannels = forbidden_schannels_re.group(2)
            line = forbidden_schannels_re.group(1)

        # Now check for forbidden onshell schannels, specified using "$"
        forbidden_onsh_schannels_re = re.match(r"^(.+)\s*\$\s*(.+)\s*$", line)
        forbidden_onsh_schannels = ""
        if forbidden_onsh_schannels_re:
            forbidden_onsh_schannels = forbidden_onsh_schannels_re.group(2)
            line = forbidden_onsh_schannels_re.group(1)

        # Now check for required schannels, specified using "> >"
        required_schannels_re = re.match("^(.+?)>(.+?)>(.+)$", line)
        required_schannels = ""
        if required_schannels_re:
            required_schannels = required_schannels_re.group(2)
            line = required_schannels_re.group(1) + ">" + \
                   required_schannels_re.group(3)

        args = self.split_arg(line)

        # Bound states are only supported without flavour grouping: the onium
        # templates project two explicit constituents, which a merged
        # (flavour-indexed) particle cannot provide.
        if self._curr_model and self._curr_model.get('merged_particles') and \
                self.has_fock_state(args):
            self.unmerge_flavors_for_onia()

        # Extract process
        boundstates = {}
        boundstates_keys = [key for key in self._boundstates.keys()]
        boundstates_keys_lower = [key.lower() for key in boundstates_keys]
        for index,part_name in enumerate(args):
            if part_name in boundstates_keys_lower:
                bound_name = boundstates_keys[boundstates_keys_lower.index(part_name)]
                boundstates[index] = self._boundstates[bound_name]

        if boundstates:
            # find all combinations of Fock states
            for index,key in enumerate(boundstates.keys()):
                if index==0:
                    all_combinations = [[(key,b)] for b in boundstates[key]]
                else:
                    all_combinations = [c+[(key,b)] for c in all_combinations for b in boundstates[key]]
            # filter symmetric final states
            already_generated = []
            unique_combinations = []
            for fockstates in all_combinations:
                state = sorted([fockstate[1] for fockstate in fockstates])
                if state not in already_generated:
                    unique_combinations.append(fockstates)
                    already_generated.append(state)

            # add processes
            last = len(unique_combinations)-1
            for idx,fockstates in enumerate(unique_combinations):
                copy_args = args
                for index,fockstate in fockstates:
                    copy_args[index] = fockstate
                process = f" ".join(["process"]+copy_args)
                logger.info("INFO: Trying to generate "+process)
                if not idx==last:
                    for order in model_orders:
                        try:
                            (order_val,order_op) = squared_orders[order]
                        except KeyError:
                            try:
                                order_val = orders[order]
                                order_op = '='
                            except KeyError:
                                continue
                        process += " "+order+order_op+str(order_val)
                    self.do_add(process)
                else:
                    args = [arg.lower() for arg in copy_args]

        myleglist = base_objects.MultiLegList()
        state = False

        if ('!a!' in args and 'j' in args):
            upc_with_jet = True
            self.do_define('aUPC = a j / g', log=False)
        else:
            upc_with_jet = False

        onium_index = 0
        aloha.dual_mode = 0
        # Extract process
        for part_name in args:
            if part_name == '>':
                if not myleglist:
                    raise self.InvalidCmd("No final state particles")
                state = True
                continue

            if part_name.endswith('*'):
                part_name = part_name[:-1]
                offshell = True
            else:
                offshell = False

            # check if particle is ONIA
            is_onium = False
            for fockstate in self._fockstates:
                if part_name == fockstate.get('name').lower():
                    is_onium = True
                    onium_info = fockstate
                    break
                elif part_name.lstrip('-').isdigit() and int(part_name)==fockstate.get('pdg_code'):
                    is_onium = True
                    onium_info = fockstate
                    break

            # check that only final-state particles are ONIA
            if is_onium and not state:
                raise self.InvalidCmd("initial particles cannot be onia")

            # check if the particle is tagged (!PART!)
            if part_name.startswith('!') and part_name.endswith('!'):
                part_name = part_name[1:-1]
                is_tagged = True
            elif part_name.endswith('!') and part_name.count('!') == 2 and part_name[:part_name.find('!')].isdigit():
                part_name = part_name.replace('!','')
                is_tagged = True
#                misc.sprint(part_name)
            else:
                is_tagged = False

            # check that only final-state particles are tagged
            if is_tagged and not state:
                if part_name!='a' and part_name!='22':
                    raise self.InvalidCmd("only initial photons can be tagged")
                elif upc_with_jet:
                    part_name = 'aUPC'.lower()

            mylegids = []
            polarization = []
            flavor = []
            if '{' in part_name:
                part_name, pol = part_name.split('{',1)
                pol, rest = pol.split('}',1)
                
                no_dup_name = part_name
                while True:
                    try:
                        spin = self._curr_model.get_particle(no_dup_name).get('spin')
                        mass = self._curr_model.get_particle(no_dup_name).get('mass')
                        break
                    except AttributeError:
                        if no_dup_name in self._multiparticles:
                            spins = set([self._curr_model.get_particle(p).get('spin') for p in self._multiparticles[no_dup_name]])
                            mass = set([self._curr_model.get_particle(p).get('mass') for p in self._multiparticles[no_dup_name]])

                            if len(spins) > 1:
                                raise self.InvalidCmd('Can not use polarised on multi-particles for multi-particles with various spin')
                            else:
                                spin = spins.pop()
                                break

                        elif no_dup_name[0].isdigit():
                            no_dup_name = no_dup_name[1:]
                        else:
                            raise self.InvalidCmd('%s is not defined in the model' % no_dup_name)

                if rest:
                    raise self.InvalidCmd('A space is required after the "}" symbol to separate particles')
                ignore  =False
                # A polarization restriction is a *set* of helicities, so the
                # same state must not be named twice -- neither literally
                # ("{++}") nor through a multi-valued label ("{+T}").  Keeping
                # a duplicate would silently double-count: get_helicity_matrix
                # runs itertools.product over this raw list while
                # get_denominator_factor ignores the repetition.  Remember
                # which label introduced each state so the refusal can name
                # both spellings.
                pol_origin = {}
                for i,p in enumerate(pol):
                    if ignore or p==',':
                        ignore= False
                        continue
                    pol_nb_before = len(polarization)
                    if p.upper() in ['T']:
                        if spin == 3:
                            polarization += [1,-1]
                        else:
                            raise self.InvalidCmd('"T" (transverse) polarization are only supported for spin one particle.')
                    elif p.upper() in ['L']:
                        if spin == 3:
                            logger.warning('"L" polarization is interpreted as left (-1); for longitudinal (0) please use "0".')
                        polarization += [-1]
                    elif p in ['R','r']:
                        polarization += [1]
                    elif p.upper() in ["A"]:
                        if spin == 3:
                            polarization += [99]
                        else:
                            raise self.InvalidCmd('"A" (auxiliary) polarization is only supported for spin one particles.')
                    elif p.upper() in ['G']:
                        if spin == 3:
                            polarization += [4]
                        else:
                            raise self.InvalidCmd('"G" (metric) polarization is only supported for spin one particles.')
                    elif p.upper() in ['H']:
                        if spin == 3:
                            polarization += [5]
                        else:
                            raise self.InvalidCmd('"H" (Theta) polarization is only supported for spin one particles.')
                    elif p.upper() in ['Q']:
                        if spin == 3:
                            polarization += [6]
                        else:
                            raise self.InvalidCmd('"Q" (qq = longitudinal - Theta) polarization is only supported for spin one particles.')
                    elif p.upper() in ['W']:
                        if spin == 3:
                            polarization += [7]
                        else:
                            raise self.InvalidCmd('"W" (Ward-protected full prop) polarization is only supported for spin one particles.')
                    elif p.upper() in ['S']:
                        if spin == 3:
                            polarization += [9]
                        else:
                            raise self.InvalidCmd('"S" (scalar=aux+width) polarization is only supported for spin one particles.')

                    elif p in ['+']:
                        if i +1 < len(pol) and pol[i+1].isdigit():
                            p = int(pol[i+1])
                            if abs(p) > 3: 
                                raise self.InvalidCmd("polarization are between -3 and 3")
                            polarization.append(p)
                            ignore = True
                        else:
                            polarization += [1]
                    elif p in ['-']:
                        if i+1 < len(pol) and pol[i+1].isdigit():
                            p = int(pol[i+1])
                            if abs(p) > 3: 
                                raise self.InvalidCmd("polarization are between -3 and 3")
                            polarization.append(-p)
                            ignore = True
                        else:
                            polarization += [-1]
                    elif p in [0,'0']:
                        if spin in [1,2]:
                            raise self.InvalidCmd('"0" (longitudinal) polarizations are not supported for scalars/fermions.')
                        elif spin in [3,5] and (mass == "ZERO" or "ZERO" in mass):
                            logger.info('"0" (longitudinal) polarization detected for massless boson.')
                            polarization += [0] # those mode will be bypass at generation time
                                                # important to keep it here in presence of multi-particles
                        else:
                            polarization += [0]
                    elif p.isdigit():
                        p = int(p)
                        if abs(p) > 3: 
                            raise self.InvalidCmd("polarization are between -3 and 3")
                        polarization.append(p)
                    else:
                        raise self.InvalidCmd('Invalid Polarization')

                    # 'p' may have been overwritten above, so read the label
                    # back from the string; 'ignore' tells whether this label
                    # consumed a second character (the "+2"/"-3" spellings).
                    # The names below are prefixed: 'state' and 'flavor' are
                    # live variables of the enclosing leg loop.
                    pol_label = pol[i:i+2] if ignore else pol[i]
                    pol_new = polarization[pol_nb_before:]
                    for pol_state in pol_new:
                        if pol_state in pol_origin:
                            raise self.InvalidCmd(
                              'Invalid polarization "{%(pol)s}": helicity '
                              '%(dup)s is selected more than once. "%(new)s" '
                              'selects %(newvals)s, but "%(old)s" already '
                              'selected %(dup)s. Each helicity may be named at '
                              'most once inside "{}" (e.g. "{T}" on its own '
                              'already selects both transverse helicities); '
                              'drop the redundant label.'
                              % {'pol': pol,
                                 'dup': polarization_state_name(pol_state),
                                 'new': pol_label,
                                 'old': pol_origin[pol_state],
                                 'newvals': ' and '.join(
                                    polarization_state_name(v)
                                    for v in pol_new)})
                        pol_origin[pol_state] = pol_label


            duplicate =1
            if part_name[0].isdigit() and len(part_name) > 1 and not part_name[1].isdigit(): 
                duplicate, part_name = int(part_name[0]), part_name[1:]

            if part_name in self._multiparticles:
                # final-state multiparticles cannot be tagged
                if is_tagged and state:
                    raise self.InvalidCmd("Multiparticles cannot be tagged")
                if isinstance(self._multiparticles[part_name][0], list):
                    raise self.InvalidCmd("Multiparticle %s is or-multiparticle" % part_name + \
                          " which can be used only for required s-channels")
                all_merged = sum(self._curr_model.merged_particles.values(),[])
                # support l+ l- when they are exactly the multiparticle definition with merged particles
                if self._multiparticles[part_name] in self._curr_model.merged_particles.values():
                    key = [k for k,v in self._curr_model.merged_particles.items() if v==self._multiparticles[part_name]][0]
                    mylegids.append(key)
                elif [-i for i in self._multiparticles[part_name]] in self._curr_model.merged_particles.values(): 
                    key = [k for k,v in self._curr_model.merged_particles.items() if v==[-i for i in self._multiparticles[part_name]]][0]
                    mylegids.append(-key)
                #check where none-merged particles are present in the multiparticle definition                    
                elif all(abs(i) not in all_merged for i in self._multiparticles[part_name]): 
                    mylegids.extend(self._multiparticles[part_name])
                else:
                    pdg_to_merge = {}
                    for pdg, merged_list in self._curr_model.merged_particles.items():
                        for mpart in merged_list:
                            pdg_to_merge[mpart] = pdg
                            pdg_to_merge[-mpart] = -pdg
                    for pid in self._multiparticles[part_name]:
                        if pid in pdg_to_merge:
                            merged_pdg = pdg_to_merge[pid]
                            if merged_pdg not in mylegids:
                                mylegids.append(merged_pdg)
                            # If not all merged components are in this multiparticle,
                            # record the present ones as a per-leg flavor restriction
                            # so diagram generation only allows those specific flavors.
                            # Completeness is checked per sign: `u d s c d~`
                            # holds every Q but only one Qx.
                            sign = 1 if pid > 0 else -1
                            if not all(sign * pdg in self._multiparticles[part_name]
                                       for pdg in self._curr_model.merged_particles[abs(merged_pdg)]):
                                if pid not in flavor:
                                    flavor.append(pid)
                        else:
                            mylegids.append(pid)

            elif is_onium:
                onium_name = onium_info.get('name')
                onium_id = onium_info.get('pdg_code')
                onium_principal = onium_info.get('principal')
                onium_spin = int((onium_info.get('spin')-1)/2)
                onium_orbit = onium_info.get('orbital')
                onium_j = onium_info.get('J')
                onium_color = onium_info.get('color')
                onium_charge = onium_info.get('charge')
                constituents = onium_info.get('particles')
                try:
                    onium_mass = onium_info.get('mass')
                except AttributeError:
                    onium_mass = -1.
                try:
                    onium_ldme = onium_info.get('ldme')
                except AttributeError:
                    onium_ldme = 1.

                # use dual mode for P-wave ONIA
                
                if onium_orbit >= 1:
                    aloha.dual_mode += 1
                for i in range(2):
                    mypart = self._curr_model['particles'].get_copy(constituents[i])

                    myleglist.append(base_objects.MultiLeg({'ids':[mypart.get_pdg_code()],
                                                        'state':state,
                                                        'polarization': polarization,
                                                        'onium': {'id':onium_id, 'name':onium_name,
                                                                  'N':onium_principal, 'S':onium_spin,
                                                                  'L':onium_orbit, 'J':onium_j,
                                                                  'C':onium_color, 'charge':onium_charge,
                                                                  'index':onium_index, 'mass':onium_mass,
                                                                  'ldme':onium_ldme
                                                                 }
                                                        	}))
                onium_index += 1
            elif part_name.isdigit() or part_name.startswith('-') and part_name[1:].isdigit():
                if abs(int(part_name)) in sum(self._curr_model.merged_particles.values(),[]):
                   for pdg in self._curr_model.merged_particles: 
                        if abs(int(part_name)) in self._curr_model.merged_particles[pdg]:
                            if int(part_name) > 0:
                                mylegids.append(pdg)
                            else:
                                mylegids.append(-pdg)
                            flavor = [int(part_name)]
                            break 
                elif int(part_name) in self._curr_model.get('particle_dict'):
                    mylegids.append(int(part_name))
                else:
                    raise self.InvalidCmd("No pdg_code %s in model" % part_name)
            else:
                mypart = self._curr_model['particles'].get_copy(part_name)
                
                if mypart:
                    pdg = mypart.get_pdg_code()
                    if abs(pdg) in sum(self._curr_model.merged_particles.values(),[]):
                        for mpdg in self._curr_model.merged_particles: 
                            if abs(pdg) in self._curr_model.merged_particles[mpdg]:
                                if pdg > 0:
                                    mylegids.append(mpdg)
                                else:
                                    mylegids.append(-mpdg)
                                flavor = [pdg] 
                                break
                    else:  
                        mylegids.append(pdg)


            if mylegids:
                for _ in range(duplicate):
                    if LoopOption in ['virt','sqrvirt','tree','noborn']:
                        # check that no tagged particles exist in this mode
                        if is_tagged:
                            raise self.InvalidCmd(
                                "%s mode does not handle tagged particles" % LoopOption)
                        myleglist.append(base_objects.MultiLeg({'ids':mylegids,
                                                            'state':state,
                                                            'polarization': polarization,
                                                            'flavor': flavor,
                                                            'onium': {},
                                                            'offshell': offshell}))
                    else:
                        myleglist.append(fks_tag.MultiTagLeg({'ids':mylegids,
                                                          'state':state,
                                                          'polarization': polarization,
                                                          'onium': {},
                                                          'is_tagged':is_tagged}))
            elif is_onium:
                pass
            else:
                raise self.InvalidCmd("No particle %s in model" % part_name)

        # Bound states are handled by the LO exporters only: nothing in the
        # FKS/loop path reads back the 'onium' leg properties and there is no
        # onia matrix-element template for it, so a perturbed process would
        # silently produce a wrong result rather than fail.
        if onium_index and perturbation_couplings.strip():
            raise self.InvalidCmd(
                "Onia are only supported at leading order: the perturbation "
                "'[%s]' can not be combined with a bound state."
                % perturbation_couplings.strip())

        if aloha.dual_mode:
            aloha.npwave.append(aloha.dual_mode)
            aloha.npwave = list(set(aloha.npwave))

        if any(['is_tagged' in l.keys()  and l['is_tagged'] and l['state'] for l in myleglist]):
            logger.warning('The process involves tagged particles. Please consider citing arXiv:2106.02059 if relevant.')
        if any(['is_tagged' in l.keys()  and l['is_tagged'] and not l['state'] for l in myleglist]):
            logger.warning('The process involves coherent photons in the initial-state. Please consider citing arXiv:2504.10104 if relevant.')

        # Apply the keyword 'all' for perturbed coupling orders.
        if perturbation_couplings.lower() in ['all', 'loonly']:
            if perturbation_couplings.lower() in ['loonly']:
                LoopOption = 'LOonly'
            perturbation_couplings=' '.join(self._curr_model['perturbation_couplings'])


        if [leg for leg in myleglist if leg.get('state') == True]:
            # We have a valid process
            # Extract perturbation orders
            perturbation_couplings_list = perturbation_couplings.split()
            if perturbation_couplings_list==['']:
                perturbation_couplings_list=[]
            # Correspondingly set 'split_order' from the squared orders and the
            # perturbation couplings list
            split_orders=misc.make_unique(perturbation_couplings_list+list(squared_orders.keys()))
            try:
                split_orders.sort(key=lambda elem: 0 if elem=='WEIGHTED' else
                                       self._curr_model.get('order_hierarchy')
                                       [elem if not elem.endswith('.sqrt') else elem[:-5]])
            except KeyError:
                raise self.InvalidCmd("The loaded model does not define a "+\
                    " coupling order hierarchy for these couplings: %s"%\
                      str([so for so in split_orders if so!='WEIGHTED' and so not 
                                 in list(self._curr_model['order_hierarchy'].keys())]))

            # If the loopOption is 'tree' then the user used the syntax 
            # [tree= Orders] for the sole purpose of setting split_orders. We
            # then empty the perturbation_couplings_list at this stage.
            if LoopOption=='tree':
                perturbation_couplings_list = []
            if perturbation_couplings_list and LoopOption not in ['real', 'LOonly']:
                if not isinstance(self._curr_model,loop_base_objects.LoopModel):
                    raise self.InvalidCmd(\
                      "The current model does not allow for loop computations.")
                else:
                    for pert_order in perturbation_couplings_list:
                        if pert_order not in self._curr_model['perturbation_couplings']:
                            raise self.InvalidCmd(\
                                "Perturbation order %s is not among" % pert_order + \
                                " the perturbation orders allowed for by the loop model.")
            if not self.options['loop_optimized_output'] and \
                         LoopOption not in ['tree','real'] and split_orders!=[]:
                logger.warning('The default output mode (loop_optimized_output'+\
                  ' = False) does not support evaluations for given powers of'+\
                  ' coupling orders. MadLoop output will therefore not be'+\
                  ' able to provide such quantities.')
                split_orders = []
                       
            # Now extract restrictions
            forbidden_particle_ids = \
                              self.extract_particle_ids(forbidden_particles)
            if forbidden_particle_ids and \
               isinstance(forbidden_particle_ids[0], list):
                raise self.InvalidCmd(\
                      "Multiparticle %s is or-multiparticle" % part_name + \
                      " which can be used only for required s-channels")
            forbidden_onsh_schannel_ids = \
                              self.extract_particle_ids(forbidden_onsh_schannels)
            forbidden_schannel_ids = \
                              self.extract_particle_ids(forbidden_schannels)
            if forbidden_onsh_schannel_ids and \
               isinstance(forbidden_onsh_schannel_ids[0], list):
                raise self.InvalidCmd("Multiparticle %s is or-multiparticle" % part_name + \
                      " which can be used only for required s-channels")
            if forbidden_schannel_ids and \
               isinstance(forbidden_schannel_ids[0], list):
                raise self.InvalidCmd("Multiparticle %s is or-multiparticle" % part_name + \
                      " which can be used only for required s-channels")
            
            try:
                required_schannel_ids = \
                               self.extract_particle_ids(required_schannels, crash_on_duplication=True)
            except DuplicateParticle:
                raise self.InvalidCmd("Invalid \"> A A >\" syntax. In older versions of MadGraph7, this was allowed but incorrectly interpreted as \"> A >\".")

            if required_schannel_ids and not \
                   isinstance(required_schannel_ids[0], list):
                required_schannel_ids = [required_schannel_ids]
            
            sqorders_values = dict([(k,v[0]) for k, v in squared_orders.items()])
            if len([1 for sqo_v in sqorders_values.values() if sqo_v<0])>1:
                raise self.InvalidCmd(
                  "At most one negative squared order constraint can be specified.")
            
            sqorders_types = dict([(k,v[1]) for k, v in squared_orders.items()]) 
            
            out = base_objects.ProcessDefinition({'legs': myleglist,
                              'model': self._curr_model,
                              'id': proc_number,
                              'orders': orders,
                              'squared_orders':sqorders_values,
                              'sqorders_types':sqorders_types,
                              'constrained_orders': constrained_orders,
                              'forbidden_particles': forbidden_particle_ids,
                              'forbidden_onsh_s_channels': forbidden_onsh_schannel_ids,
                              'forbidden_s_channels': forbidden_schannel_ids,
                              'required_s_channels': required_schannel_ids,
                              'overall_orders': overall_orders,
                              'perturbation_couplings': perturbation_couplings_list,
                              'has_born':HasBorn,
                              'NLO_mode':LoopOption,
                              'split_orders':split_orders
                              })
            return out
        #                       'is_decay_chain': decay_process\


    def extract_interference_process(self, left, mode, right, proc_number=0,
                                     overall_orders=None,
                                     avoid_squared_orders=False):
        """Build the ProcessDefinition of an interference process, as split by
        split_interference_line: 'left' is the left-hand process in the
        ordinary syntax, 'mode' is 'LIxtree' or 'treextree' and 'right' the
        right-hand (tree-level) process, None for the LIxtree default.

        The left-hand process is returned, with 'interference_mode' set and
        the right-hand ProcessDefinition in 'interference_process'. The
        quantity computed is 2 Re(A_left A_right^*): the squared-order
        constraints, which constrain that product, are given on the left-hand
        side only. Without a right-hand process, LIxtree interferes with the
        tree-level amplitudes of the same external legs, i.e. with what
        'generate <legs>' alone would give: no s-channel requirement, no order
        constraint and no exclusion is carried over from the loop process.
        """

        # An amplitude-level '==' or '>' constraint on the left-hand process
        # constrains the left-hand amplitudes only: unlike for an ordinary
        # process, it must not turn into a squared-order constraint, which
        # here would act on the left x right products (u d > u d QED==0
        # [treextree] u d > u d QCD==0 would get QED^2==0 and no interference
        # at all). Explicit '^2' constraints are kept.
        procdef = self.extract_process(left, proc_number=proc_number,
                    overall_orders=overall_orders if overall_orders else {},
                    avoid_squared_orders=True)
        if not procdef:
            raise self.InvalidCmd("Empty or wrong format process, please try again.")
        if procdef.get('decay_chains'):
            raise self.InvalidCmd("Decay chains are not supported for %s processes." % mode)

        if right is None:
            rightdef = base_objects.ProcessDefinition({
                                        'legs': copy.deepcopy(procdef['legs']),
                                        'model': procdef['model']})
        else:
            if ',' in right:
                raise self.InvalidCmd("Decay chains are not supported for %s processes." % mode)
            # the process number belongs to the whole definition, i.e. to
            # the left-hand process: the right-hand one keeps id 0
            rightdef = self.extract_process(right, avoid_squared_orders=True)
            if not rightdef:
                raise self.InvalidCmd("The right-hand process '%s' of the %s "
                                      "process is not valid." % (right, mode))
            if rightdef['squared_orders']:
                raise self.InvalidCmd(
                    "Squared-order constraints (%s) are not allowed on the "
                    "right-hand process of a %s process: they constrain the "
                    "interference, so they belong to the left-hand side, "
                    "between ']' and the right-hand process, as in "
                    "'g g > h > t t~ [LIxtree=QCD] QCD^2==6 g g > t t~'."
                    % (', '.join('%s^2%s%d' % (k, rightdef.get_squared_order_type(k), v)
                                 for k, v in rightdef['squared_orders'].items()),
                       mode))

        self.validate_interference_legs(procdef, rightdef, mode)

        procdef.set('interference_mode', mode)
        procdef.set('interference_process', rightdef)
        return procdef

    @staticmethod
    def interference_leg_pdgs(leg, model):
        """The set of signed pdg codes a MultiLeg stands for, with the merged
        (flavour-grouped) particles expanded into their members, restricted
        by the leg 'flavor' when it is set."""

        merged = getattr(model, 'merged_particles', None) or {}
        restriction = set(leg.get('flavor') or [])
        pdgs = set()
        for pid in leg.get('ids'):
            if abs(pid) in merged:
                sign = 1 if pid > 0 else -1
                members = set(sign * m for m in merged[abs(pid)])
                pdgs |= (members & restriction) or members
            else:
                pdgs.add(pid)
        return pdgs

    def validate_interference_legs(self, leftdef, rightdef, mode):
        """The two sides of an interference process must describe the same
        external legs, written in the same order: same number of initial and
        final particles, the same polarisation, and at each position every
        particle of the left-hand leg must be allowed by the right-hand one
        (the right-hand legs may be wider, e.g. 'j' against 'g'). Raises
        InvalidCmd otherwise."""

        left_legs, right_legs = leftdef.get('legs'), rightdef.get('legs')
        if leftdef.get_ninitial() != rightdef.get_ninitial() or \
                                            len(left_legs) != len(right_legs):
            raise self.InvalidCmd(
                "The two sides of a %s process must have the same external "
                "legs: '%s' and '%s' differ in the number of initial or final "
                "particles." % (mode, leftdef.nice_string(prefix=False),
                                rightdef.nice_string(prefix=False)))

        model = leftdef.get('model')
        names = lambda pdgs: ' '.join(sorted(model.get_particle(p).get_name()
                                             for p in pdgs))
        for i, (lleg, rleg) in enumerate(zip(left_legs, right_legs)):
            missing = self.interference_leg_pdgs(lleg, model) - \
                      self.interference_leg_pdgs(rleg, model)
            if lleg.get('state') != rleg.get('state') or missing:
                raise self.InvalidCmd(
                    "The two sides of a %s process must have the same external "
                    "legs, in the same order: leg %d of the right-hand process "
                    "does not contain %s. Write the right-hand legs in the "
                    "order of the left-hand ones." % (mode, i + 1,
                    names(missing) if missing else 'the same state'))
            if sorted(lleg.get('polarization')) != sorted(rleg.get('polarization')):
                raise self.InvalidCmd(
                    "The two sides of a %s process must have the same "
                    "polarisation on each leg (leg %d differs)." % (mode, i + 1))

    def create_loop_induced(self, line, myprocdef=None):
        """ Routine to create the MultiProcess for the loop-induced case"""
        
        args = self.split_arg(line)
        
        warning_duplicate = True
        if '--no_warning=duplicate' in args:
            warning_duplicate = False
            args.remove('--no_warning=duplicate')
        
        # Check the validity of the arguments
        self.check_add(args)
        if args[0] == 'process':
            args = args[1:]
        
        # special option for 1->N to avoid generation of kinematically forbidden
        #decay.
        if args[-1].startswith('--optimize'):
            optimize = True
            args.pop()
        else:
            optimize = False

        # Extract potential loop_filter  
        loop_filter=None        
        for arg in args:
            if arg.startswith('--loop_filter='):
                loop_filter = arg[14:]
            #if not isinstance(self, extended_cmd.CmdShell):
            #    raise self.InvalidCmd, "loop_filter is not allowed in web mode"
        args = [a for a in args if not a.startswith('--loop_filter=')]
        diagram_filter = self.extract_diagram_filter(args)
        # the options of the NLO (FKS) generation, which falls back to this
        # mode when it finds no Born diagram: no Born diagram is generated
        # here, the loop filter is the diagram filter of this mode
        if self.extract_diagram_filter(args, '--tree_diagram_filter'):
            raise self.InvalidCmd("No Born diagram for %s: it can not be "
                "filtered with --tree_diagram_filter (in the loop-induced mode "
                "use --diagram_filter or --loop_diagram_filter)." %
                ' '.join(a for a in args if not a.startswith('--')))
        diagram_filter = self.extract_diagram_filter(args,
                                    '--loop_diagram_filter') or diagram_filter
        
        if not myprocdef:
            myprocdef = self.extract_process(' '.join(args))
        # LIxtree: hidden order selecting the interference, right-hand orders
        diagram_generation.prepare_interference_process(myprocdef)
        
        myprocdef.set('NLO_mode', 'noborn')
            
        # store the first process (for the perl script)
        if not self._generate_info:
            self._generate_info = line
                
        # Reset Helas matrix elements
        #self._curr_matrix_elements = helas_objects.HelasLoopInducedMultiProcess()


        # Check that we have the same number of initial states as
        # existing processes
        if self._curr_amps and self._curr_amps[0].get_ninitial() != \
               myprocdef.get_ninitial():
            raise self.InvalidCmd("Can not mix processes with different number of initial states.")               
      
        if self._curr_amps and (not isinstance(self._curr_amps[0], loop_diagram_generation.LoopAmplitude) or \
             self._curr_amps[0]['has_born']):
            raise self.InvalidCmd("Can not mix loop induced process with not loop induced process")
            
        # Negative coupling order constraints can be given on at most one
        # coupling order (and either in squared orders or orders, not both)
        if len([1 for val in list(myprocdef.get('orders').values())+\
                      list(myprocdef.get('squared_orders').values()) if val<0])>1:
            raise MadGraph5Error("Negative coupling order constraints"+\
              " can only be given on one type of coupling and either on"+\
                           " squared orders or amplitude orders, not both.")

        cpu_time1 = time.time()

        # Generate processes
        if self.options['group_subprocesses'] == 'Auto':
                collect_mirror_procs = True
        else:
            collect_mirror_procs = self.options['group_subprocesses']
        ignore_six_quark_processes = \
                       self.options['ignore_six_quark_processes'] if \
                       "ignore_six_quark_processes" in self.options \
                       else []

        # Decide here whether one needs a LoopMultiProcess or a MultiProcess

        try:
            myproc = loop_diagram_generation.LoopInducedMultiProcess(myprocdef,
                                 collect_mirror_procs = collect_mirror_procs,
                                 ignore_six_quark_processes = ignore_six_quark_processes,
                                 optimize=optimize,
                                 loop_filter=loop_filter,
                                 diagram_filter=diagram_filter)
            amplitudes = myproc.get('amplitudes')
        except diagram_generation.NoDiagramException:
            if myprocdef.get_interference_mode() != 'LIxtree':
                raise
            raise self.InvalidCmd(
                "No subprocess of '%s' has both loop-induced diagrams and "
                "tree-level diagrams of '%s': there is no interference to "
                "compute." % (myprocdef.nice_string(prefix=False).split('[')[0].strip(),
                    myprocdef.get('interference_process').nice_string(prefix=False)))

        for amp in amplitudes:
            if amp not in self._curr_amps:
                self._curr_amps.append(amp)
                if amp['has_born']:
                    raise Exception
            elif warning_duplicate:
                raise self.InvalidCmd("Duplicate process %s found. Please check your processes." % \
                                            amp.nice_string_processes())

        # Reset _done_export, since we have new process
        self._done_export = False
        self._curr_proc_defs.append(myprocdef)

        cpu_time2 = time.time()

        nprocs = len(myproc.get('amplitudes'))
        ndiags = sum([amp.get_number_of_diagrams() for \
                          amp in myproc.get('amplitudes')])
        logger.info("%i processes with %i diagrams generated in %0.3f s" % \
              (nprocs, ndiags, (cpu_time2 - cpu_time1)))
        ndiags = sum([amp.get_number_of_diagrams() for \
                          amp in self._curr_amps])
        logger.info("Total: %i processes with %i diagrams" % \
              (len(self._curr_amps), ndiags))

    @staticmethod
    def split_process_line(procline):
        """Takes a valid process and return
           a tuple (core_process, options). This removes
             - any NLO specifications.
             - any options
           [Used by MadSpin]
        """

        # remove the tag "[*]": this tag is used in aMC@LNO ,
        # but it is not a valid syntax for LO
        line=procline
        pos1=line.find("[")
        if pos1>0:
            pos2=line.find("]")
            if pos2 >pos1:
                line=line[:pos1]+line[pos2+1:]
        #
        # Extract the options:
        #
        # A. Remove process number (identified by "@")
        proc_number_pattern = re.compile(r"^(.+)@\s*(\d+)\s*(.*)$")
        proc_number_re = proc_number_pattern.match(line)
        if proc_number_re:
            line = proc_number_re.group(1) + proc_number_re.group(3)

        # B. search for the beginning of the option string
        pos=1000
        # start with order
        order_pattern = re.compile(r"^(.+)\s+(\w+)\s*=\s*(\d+)\s*$")
        order_re = order_pattern.match(line)
        if (order_re):
            pos_order=line.find(order_re.group(2))
            if pos_order>0 and pos_order < pos : pos=pos_order

        # then look for slash or dollar
        slash = line.find("/")
        if slash > 0 and slash < pos: pos=slash
        dollar = line.find("$")
        if dollar > 0 and dollar < pos: pos=dollar

        if pos<1000:
            proc_option=line[pos:]
            line=line[:pos]
        else:
            proc_option=""

        return line, proc_option

    def _expand_merged_pdgs(self, pid_set):
        """Expand merged-particle PDG codes (e.g. _quark=81) into the signed
        individual-flavor PDGs defined by the model's ``merged_particles`` map.

        ``get_final_part`` must report the *real* final-state PDG ids (MadSpin
        matches them against the actual particles in the events). With the
        merged-flavor multiparticles now used by default (``j = g _quark
        _anti_quark``), the raw ids would otherwise be the merged codes
        (81/-81), which never appear in the events.
        """
        try:
            merged = self._curr_model.get('merged_particles') or {}
        except Exception:
            merged = {}
        if not merged:
            return set(pid_set)
        result = set()
        for pid in pid_set:
            base = abs(pid)
            if base in merged:
                sign = 1 if pid > 0 else -1
                result.update(sign * real for real in merged[base])
            else:
                result.add(pid)
        return result

    def get_final_part(self, procline):
        """Takes a valid process and return
           a set of id of final states particles. [Used by MadSpin]
        """

        if not self._curr_model['case_sensitive']:
            procline = procline.lower()
        pids = self._curr_model.get('name2pdg')

        # method.
        # 1) look for decay.
        #     in presence of decay call this routine recursively and veto
        #     the particles which are decayed

        # Deal with decay chain
        if ',' in procline:
            core, decay = procline.split(',', 1)
            core_final = self.get_final_part(core)

            #split the decay
            all_decays = decay.split(',')
            nb_level,  tmp_decay = 0, ''
            decays = []
            # deal with ()
            for one_decay in all_decays:
                if '(' in one_decay:
                    nb_level += 1
                if ')' in one_decay:
                    nb_level -= 1

                if nb_level:
                    if tmp_decay:
                        tmp_decay += ', %s' % one_decay
                    else:
                        tmp_decay = one_decay
                elif tmp_decay:
                    final = '%s,%s' % (tmp_decay, one_decay)
                    final = final.strip()
                    assert final[0] == '(' and final[-1] == ')'
                    final = final[1:-1]
                    decays.append(final)
                    tmp_decay = ''
                else:
                    decays.append(one_decay)
            # remove from the final states all particles which are decayed
            for one_decay in decays:
                first = one_decay.split('>',1)[0].strip()
                if first in pids:
                    pid = set([pids[first]])
                elif first in self._multiparticles:
                    pid = set(self._multiparticles[first])
                else:
                    raise Exception('invalid particle name: %s. ' % first)
                # work in real-PDG space so the removal matches the (already
                # expanded) core final state for merged-flavor labels.
                pid = self._expand_merged_pdgs(pid)
                core_final.difference_update(pid)
                core_final.update(self.get_final_part(one_decay))

            return core_final

        # NO DECAY CHAIN
        final = set()
        final_states = re.search(r'> ([^\/\$\=\@>]*)(\[|\s\S+\=|\$|\/|\@|$)', procline)
        particles = final_states.groups()[0]
        for particle in particles.split():
            if '{' in particle:
                particle = particle.split('{')[0]
            if particle in pids:
                final.add(pids[particle])
            elif particle in self._multiparticles:
                final.update(set(self._multiparticles[particle]))
            elif particle[0].isdigit():
                if particle[1:] in pids:
                    final.add(pids[particle[1:]])
                elif particle in self._multiparticles:
                    final.update(set(self._multiparticles[particle[1:]]))

        return self._expand_merged_pdgs(final)

    def extract_particle_ids(self, args, crash_on_duplication=False):
        """Extract particle ids from a list of particle names. If
        there are | in the list, this corresponds to an or-list, which
        is represented as a list of id lists. An or-list is used to
        allow multiple required s-channel propagators to be specified
        (e.g. Z/gamma)."""

        if isinstance(args, str):
            args.replace("|", " | ")
            args = self.split_arg(args)
        all_ids = []
        ids=[]
        for part_name in args:
            mypart = self._curr_model['particles'].get_copy(part_name)
            if mypart:
                ids.append([mypart.get_pdg_code()])
            elif part_name in self._multiparticles:
                ids.append(self._multiparticles[part_name])
            elif part_name == "|":
                # This is an "or-multiparticle"
                if ids:
                    all_ids.append(ids)
                ids = []
            elif part_name.isdigit() or (part_name.startswith('-') and part_name[1:].isdigit()):
                ids.append([int(part_name)])
            else:
                raise self.InvalidCmd("No particle %s in model" % part_name)
        all_ids.append(ids)
        # Flatten id list, to take care of multiparticles and
        # or-multiparticles
        res_lists = []
        for i, id_list in enumerate(all_ids):
            res_lists.extend(diagram_generation.expand_list_list(id_list))
        # Trick to avoid duplication while keeping ordering
        if not crash_on_duplication:
            for ilist, idlist in enumerate(res_lists):
                set_dict = {}
                res_lists[ilist] = [set_dict.setdefault(i,i) for i in idlist \
                            if i not in set_dict]
        else:
            for ilist, idlist in enumerate(res_lists):
                set_dict = {}
                test = [set_dict.setdefault(i,i) for i in idlist \
                            if i not in set_dict]
                if len(test) != len(idlist):
                    raise DuplicateParticle('Particle can not be duplicate')

        if len(res_lists) == 1:
            res_lists = res_lists[0]

        return res_lists

    def optimize_order(self, pdg_list):
        """Optimize the order of particles in a pdg list, so that
        similar particles are next to each other. Sort according to:
        1. pdg > 0, 2. spin, 3. color, 4. mass > 0"""

        if not pdg_list:
            return
        if not isinstance(pdg_list[0], int):
            return

        model = self._curr_model
        pdg_list.sort(key = lambda i: i < 0)
        pdg_list.sort(key = lambda i: model.get_particle(i).is_fermion())
        pdg_list.sort(key = lambda i: model.get_particle(i).get('color'),
                      reverse = True)
        pdg_list.sort(key = lambda i: \
                      model.get_particle(i).get('mass').lower() != 'zero')

    def extract_decay_chain_process(self, line, level_down=False, proc_number=0):
        """Recursively extract a decay chain process definition from a
        string. Returns a ProcessDefinition."""

        # Start with process number (identified by "@") and overall orders
        proc_number_pattern = re.compile(r"^(.+)@\s*(\d+)\s*((\w+\s*\<?=\s*\d+\s*)*)$")
        proc_number_re = proc_number_pattern.match(line)
        overall_orders = {}
        if proc_number_re:
            proc_number = int(proc_number_re.group(2))
            line = proc_number_re.group(1)
            if proc_number_re.group(3):
                order_pattern = re.compile(r"^(.*?)\s*(\w+)\s*\<?=\s*(\d+)\s*$")
                order_line = proc_number_re.group(3)
                order_re = order_pattern.match(order_line)
                while order_re:
                    overall_orders[order_re.group(2)] = int(order_re.group(3))
                    order_line = order_re.group(1)
                    order_re = order_pattern.match(order_line)            
            logger.info(line)
            

        index_comma = line.find(",")
        index_par = line.find(")")
        min_index = index_comma
        if index_par > -1 and (index_par < min_index or min_index == -1):
            min_index = index_par

        if min_index > -1:
            core_process = self.extract_process(line[:min_index], proc_number,
                                                overall_orders, avoid_squared_orders=True)
        else:
            core_process = self.extract_process(line, proc_number,
                                                overall_orders, avoid_squared_orders=True)

        #level_down = False

        while index_comma > -1:
            line = line[index_comma + 1:]
            if not line.strip():
                break
            index_par = line.find(')')
            # special cases: parenthesis but no , => remove the parenthesis!
            if line.lstrip()[0] == '(' and index_par !=-1 and \
                                                    not ',' in line[:index_par]:
                par_start = line.find('(')
                line = '%s %s' % (line[par_start+1:index_par], line[index_par+1:]) 
                index_par = line.find(')')
            if line.lstrip()[0] == '(':
                # Go down one level in process hierarchy
                #level_down = True
                line = line.lstrip()[1:]
                # This is where recursion happens
                decay_process, line = \
                            self.extract_decay_chain_process(line,
                                                             level_down=True)
                index_comma = line.find(",")
                index_par = line.find(')')
            else:
                index_comma = line.find(",")
                min_index = index_comma
                if index_par > -1 and \
                       (index_par < min_index or min_index == -1):
                    min_index = index_par
                if min_index > -1:
                    decay_process = self.extract_process(line[:min_index])
                else:
                    decay_process = self.extract_process(line)

            core_process.get('decay_chains').append(decay_process)

            if level_down:
                if index_par == -1:
                    raise self.InvalidCmd("Missing ending parenthesis for decay process")

                if index_par < index_comma:
                    line = line[index_par + 1:]
                    level_down = False
                    break

        if level_down:
            index_par = line.find(')')
            if index_par == -1:
                raise self.InvalidCmd("Missing ending parenthesis for decay process")
            line = line[index_par + 1:]

        # Return the core process (ends recursion when there are no
        # more decays)
        return core_process, line


    # Import files
    def do_import(self, line, force=False, options={}):
        """Main commands: Import files with external formats"""

        args = self.split_arg(line)
        # Check argument's validity
        self.check_import(args)
        if args[0].startswith('model'):
            self._model_v4_path = None
            # Reset amplitudes and matrix elements
            self.clean_process()
            # Import model
            if args[0].endswith('_v4'):
                logger.critical("Support for V4 model is deprecated and known to not be fully working in this version of MadGraph7. Please consider to use an older (Long Term Stable) version if you can not use UFO model")
                self._curr_model, self._model_v4_path = \
                                 import_v4.import_model(args[1], self._mgme_dir)
            else:
                # avoid loading the qcd/qed model twice
                if (args[1].startswith('loop_qcd_qed_sm') or\
                    args[1].split('/')[-1].startswith('loop_qcd_qed_sm')) and\
                     self.options['gauge']!='Feynman':
                    logger.info('Switching to Feynman gauge because '+\
                          'it is the only one supported by the model %s.'%args[1])
                    self._curr_model = None
                    self.do_set('gauge Feynman',log=False)
                prefix = not '--noprefix' in args
                if prefix:
                    aloha.aloha_prefix='mdl_'
                else:
                    aloha.aloha_prefix=''
                
                options['apply_flavor_grouping'] = self.options.get('apply_flavor_grouping', True)

                try:
                    self._curr_model = import_ufo.import_model(args[1], prefix=prefix,
                        complex_mass_scheme=self.options['complex_mass_scheme'],
                        options=options)
                except ufomodels.UFOError as err:
                    model_path, _,_ = import_ufo.get_path_restrict(args[1])
                    if self.options['auto_convert_model']:
                        logger.info("fail to load model but auto_convert_model is on True. Trying to convert the model")
                        
                        self.exec_cmd('convert model %s' % model_path, errorhandling=False, printcmd=True, precmd=False, postcmd=False)
                        logger.info('retry the load of the model')
                        tmp_opt = dict(self.options)
                        tmp_opt['auto_convert_model'] = False
                        with misc.TMP_variable(self, 'options', tmp_opt):
                            try:
                                self.exec_cmd('import %s' % line, errorhandling=False, printcmd=True, precmd=False, postcmd=False)
                            except Exception:
                                raise err
                    else:
                        raise self.InvalidCmd('UFO model is not compatible with Python 3. You can convert it via the command \nconvert model %s\nYou can also type \"set auto_convert_model T\" to automatically convert all python2 module to be python3 compatible in the future.' % model_path)
                if os.path.sep in args[1] and "import" in self.history[-1]:
                    self.history[-1] = 'import model %s' % self._curr_model.get('modelpath+restriction')

                if self.options['gauge'] in ['unitary', 'axial']:
                    if not force and isinstance(self._curr_model,\
                                              loop_base_objects.LoopModel) and \
                         self._curr_model.get('perturbation_couplings') not in \
                                                                   [[],['QCD']]:
                        if 1 not in self._curr_model.get('gauge') :
                            logger_stderr.warning('This model does not allow Feynman '+\
                              'gauge. You will only be able to do tree level '+\
                                                'and QCD loop computations with it.')
                        else:
                            logger.info('Change to the gauge to Feynman because '+\
                          'this loop model allows for more than just tree level'+\
                                                      ' and QCD perturbations.')
                            self.do_set('gauge Feynman', log=False)
                            return
                    if 0 not in self._curr_model.get('gauge') :
                        logger_stderr.warning('Change the gauge to Feynman since '+\
                                       'the model does not allow unitary gauge')
                        self.do_set('gauge Feynman', log=False)
                        return
                else:
                    if 1 not in self._curr_model.get('gauge') :
                        logger_stderr.warning('Change the gauge to unitary since the'+\
                          ' model does not allow Feynman gauge.'+\
                                                  ' Please re-import the model')
                        self._curr_model = None
                        self.do_set('gauge unitary', log= False)
                        return
            if self._curr_model:
                self._curr_model._curr_gauge = self.options['gauge']

            if '-modelname' not in args:
                self._curr_model.pass_particles_name_in_mg_default()

            # Do post-processing of model
            self.process_model()
            # Reset amplitudes and matrix elements and global checks
            self._curr_amps = diagram_generation.AmplitudeList()
            # Reset proc defs
            self._curr_proc_defs = base_objects.ProcessDefinitionList()
            self._curr_matrix_elements = helas_objects.HelasMultiProcess()
            process_checks.store_aloha = []
            self.advise_neglected_masses()

        elif args[0] == 'command':

            if not os.path.isfile(args[1]):
                raise self.InvalidCmd("Path %s is not a valid pathname" % args[1])
            else:
                # Check the status of export and try to use file position if no
                #self._export dir are define
                self.check_for_export_dir(args[1])
                # Execute the card
                self.import_command_file(args[1])

        elif args[0] == 'banner':
            type = madevent_interface.MadEventCmd.detect_card_type(args[1])
            if type != 'banner':
                raise self.InvalidCmd('The File should be a valid banner')
            ban = banner_module.Banner(args[1])
            # Check that this is MG5 banner
            if 'mg5proccard' in ban:
                # ProcCard joins the lines older versions wrapped with '\'
                for line in banner_module.ProcCard(ban['mg5proccard'].split('\n')):
                    if line.startswith('#') or line.startswith('<'):
                        continue
                    self.exec_cmd(line)
            else:
                raise self.InvalidCmd('Only MG5 banner are supported')

            if not self._done_export:
                self.exec_cmd('output . -f')

            ban.split(self._done_export[0])
            logger.info('All Cards from the banner have been place in directory %s' % pjoin(self._done_export[0], 'Cards'))
            if '--no_launch' not in args:
                self.exec_cmd('launch')

        elif args[0] == 'proc_v4':

            if len(args) == 1 and self._export_dir:
                proc_card = pjoin(self._export_dir, 'Cards', \
                                                                'proc_card.dat')
            elif len(args) == 2:
                proc_card = args[1]
                # Check the status of export and try to use file position is no
                # self._export dir are define
                self.check_for_export_dir(os.path.realpath(proc_card))
            else:
                raise MadGraph5Error('No default directory in output')


            #convert and execute the card
            self.import_mg4_proc_card(proc_card)

    def remove_pointless_decay(self, param_card):
        """ For simple decay chain: remove diagram that are not in the BR.
            param_card should be a ParamCard instance."""

        assert isinstance(param_card, check_param_card.ParamCard)

        # Collect amplitudes
        amplitudes = diagram_generation.AmplitudeList()
        for amp in self._curr_amps:
            amplitudes.extend(amp.get_amplitudes())

        decay_tables = param_card['decay'].decay_table
        to_remove = []
        for amp in amplitudes:
            mother = [l.get('id') for l in amp['process'].get('legs') \
                                                        if not l.get('state')]
            if 1 == len(mother):
                try:
                    decay_table = decay_tables[abs(mother[0])]
                except KeyError:
                    logger.warning("No decay table for %s. decay of this particle with MadSpin should be discarded" % abs(mother[0]))
                    continue # No BR for this particle -> accept all.
                # create the tuple associate to the decay mode
                child = [l.get('id') for l in amp['process'].get('legs') \
                                                              if l.get('state')]
                                        
                if not mother[0] > 0:
                    child = [x if self._curr_model.get_particle(x)['self_antipart']
                             else -x for x in child]
                child.sort()
                child.insert(0, len(child))
                #check if the decay is present or not:
                if tuple(child) not in list(decay_table.keys()):
                    if any(id in self._curr_model.get('merged_particles') for id in child):
                        all_keys =[list(k) for k in decay_table.keys()]
                        for one_key in all_keys:
                            for i,pid in enumerate(one_key):
                                if i ==0:
                                    continue
                                for mid,pdgs in self._curr_model.get('merged_particles').items():
                                    if pid in pdgs:
                                        one_key[i] = mid
                                    if -pid in pdgs:
                                        one_key[i] = -mid
                        for i,k in enumerate(all_keys):
                            new_k = list(k[1:])
                            new_k.sort()
                            new_k.insert(0, k[0])
                            all_keys[i] = tuple(new_k)            
                        if tuple(child) not in all_keys:
                            to_remove.append(amp)
                    else:
                        to_remove.append(amp)
        def remove_amp(amps, to_remove):
            for amp in amps[:]:
                if amp in to_remove:
                    amps.remove(amp)
                if isinstance(amp, diagram_generation.DecayChainAmplitude):
                    remove_amp(amp.get('decay_chains'),to_remove)
                    for decay in amp.get('decay_chains'):
                        remove_amp(decay.get('amplitudes'), to_remove)
        remove_amp(self._curr_amps, to_remove)
        logger.debug("Removed %s amplitudes that are not in the decay table" % len(to_remove))


    def import_ufo_model(self, model_name):
        """ import the UFO model """

        self._curr_model = import_ufo.import_model(model_name)

    def process_model(self):
        """Set variables _particle_names and _couplings for tab
        completion, define multiparticles"""

         # Set variables for autocomplete
        self._particle_names = [p.get('name') for p in self._curr_model.get('particles')\
                                                    if p.get('propagating')] + \
                 [p.get('antiname') for p in self._curr_model.get('particles') \
                                                    if p.get('propagating')]

        self._couplings = misc.make_unique(sum([list(i.get('orders').keys()) for i in \
                                        self._curr_model.get('interactions')], []))

        self.add_default_multiparticles()
        # A new model starts without any Fock state: those of a previously
        # imported model must not leak in. Use 'add model X --fock_states_only'
        # to put the bound states of one model on top of another.
        self._boundstates = {}
        self.add_default_fockstates()
        if self._fockstates:
            logger.warning('The model contains non-relativistic bound states. Please consider citing arXiv:2510.26773 and arXiv:2607.26739 if relevant.')
            self.add_default_boundstates()


    def import_mg4_proc_card(self, filepath):
        """ read a V4 proc card, convert it and run it in mg5"""

        # change the status of this line in the history -> pass in comment
        if self.history and self.history[-1].startswith('import proc_v4'):
            self.history[-1] = '#%s' % self.history[-1]

        # read the proc_card.dat
        reader = files.read_from_file(filepath, import_v4.read_proc_card_v4)
        if not reader:
            raise self.InvalidCmd('\"%s\" is not a valid path' % filepath)

        if self._mgme_dir:
            # Add comment to history
            self.exec_cmd("# Import the model %s" % reader.model, precmd=True)
            line = self.exec_cmd('import model_v4 %s --debug -modelname' % \
                                 (reader.model), precmd=True, force=True)
        else:
            logging.error('No MG_ME installation detected')
            return


        # Now that we have the model we can split the information
        lines = reader.extract_command_lines(self._curr_model)
        for line in lines:
            self.exec_cmd(line, precmd=True)

        return

    def add_default_multiparticles(self):
        """ add default particle from file interface.multiparticles_default.txt
        """

        defined_multiparticles = list(self._multiparticles.keys())
        removed_multiparticles = []
        # First check if the defined multiparticles are allowed in the
        # new model
        
        for key in list(self._multiparticles.keys()):
            try:
                for part in self._multiparticles[key]:
                    self._curr_model.get('particle_dict')[part]
                if self._curr_model.get_particle(key):
                    raise Exception
            except Exception:
                del self._multiparticles[key]
                defined_multiparticles.remove(key)
                removed_multiparticles.append(key)

        # Now add default multiparticles
        for line in open(pjoin(MG5DIR, 'input', \
                                      'multiparticles_default.txt')):
            if line.startswith('#'):
                continue
            try:
                if not self._curr_model['case_sensitive']:
                    multipart_name = line.lower().split()[0]
                else:
                    multipart_name = line.split()[0]
                if multipart_name not in self._multiparticles:
                    #self.do_define(line)
                    self.exec_cmd('define %s' % line, printcmd=False, precmd=True)
                
            except self.InvalidCmd as why:
                logger.warning('impossible to set default multiparticles %s because %s' %
                                        (line.split()[0],why))
                if self.history[-1] == 'define %s' % line.strip():
                    self.history.pop(-1)
                else:
                    misc.sprint([self.history[-1], 'define %s' % line.strip()])

        scheme = "old"
        photon = False
        # The flavour scheme is a property of the model: the heaviest quark
        # that is still massless (Model.get_flavour_scheme). The run_card
        # default for maxjetflavor is derived from the very same number, so
        # the jet definition and maxjetflavor always agree.
        nflav = self._curr_model.get_flavour_scheme()
        for qcd_container in ['p', 'j']:
            if qcd_container not in self._multiparticles:
                continue
            multi = self._multiparticles[qcd_container]
            if nflav is None:
                break

            for pdg in (4, 5):
                if pdg <= nflav and pdg not in multi:
                    multi.extend([pdg, -pdg])
                    scheme = nflav
                elif pdg > nflav and pdg in multi:
                    multi.remove(pdg)
                    if -pdg in multi:
                        multi.remove(-pdg)
                    scheme = nflav

            # check if the photon has to be added to j and p
            if 'perturbation_couplings' in list(self._curr_model.keys()) and \
              'QED' in self._curr_model['perturbation_couplings']:
                if 22 not in multi:
                    multi.append(22)
                    photon = True
            elif 22 in multi:
                multi.remove(22)
                photon = False
                
        if scheme in [3,4,5] and not photon:
            self.optimize_order(multi)
            # only re-register the containers that still exist: a model may
            # define a real particle called 'j' (or 'p'), in which case the
            # multiparticle was dropped above and must not come back.
            for container in ['p', 'j']:
                if container in self._multiparticles:
                    self._multiparticles[container] = multi
            logger.warning("Pass the definition of \'j\' and \'p\' to %s flavour scheme." % scheme)
            for container in ['p', 'j']:
                if container in defined_multiparticles:
                    defined_multiparticles.remove(container)
            self.history.append("define p = %s # pass to %s flavors" % \
                                (' ' .join([repr(i) for i in self._multiparticles['p']]), 
                                 scheme) 
                               )
            self.history.append("define j = p")

        if photon:
            logger.warning("Pass the definition of \'j\' and \'p\' to %s flavour scheme, including the photon." % scheme)
            for container in ['p', 'j']:
                if container in defined_multiparticles:
                    defined_multiparticles.remove(container)
            self.history.append("define p = %s # pass to %s flavors" % \
                                (' '.join([str(i) for i in self._multiparticles['p']]), 
                                 scheme) 
                               )
            self.history.append("define j = p")
        
        if defined_multiparticles:
            if 'all' in defined_multiparticles:
                defined_multiparticles.remove('all')
            logger.info("Kept definitions of multiparticles %s unchanged" % \
                                         " / ".join(defined_multiparticles))

        for removed_part in removed_multiparticles:
            if removed_part in self._multiparticles:
                removed_multiparticles.remove(removed_part)

        if removed_multiparticles:
            logger.info("Removed obsolete multiparticles %s" % \
                                         " / ".join(removed_multiparticles))

        # add all tag
        line = []
        for part in self._curr_model.get('particles'):
            line.append('%s %s' % (part.get('name'), part.get('antiname')))
        line = 'all =' + ' '.join(line)
        self.do_define(line)

    @staticmethod
    def heptools_install_target(heptools_install_dir):
        """Where 'install <tool>' puts a tool, and which configuration file
        records the resulting path ('' meaning this installation's own).

        A prefix inside this installation is private to it, so its paths belong
        in its own configuration; only a prefix explicitly pointed at a shared
        location is recorded per user. Writing installation-specific absolute
        paths into the shared file is what makes another MadGraph installation
        pick up this one's HEPTools.
        """

        prefix = heptools_install_dir or pjoin(MG5DIR, 'HEPTools')
        if not os.path.isabs(prefix):
            prefix = pjoin(MG5DIR, prefix)
        prefix = os.path.realpath(prefix)
        if os.path.commonpath([prefix, MG5DIR]) == MG5DIR:
            return prefix, ''
        return prefix, misc.user_config_file(create=True) or ''

    def add_default_boundstates(self):
        """Add default bound states from file boundstates_default.txt in the input folder"""

        # Load default bound states from boundstates_default.txt
        boundstates_file = pjoin(MG5DIR, 'input', 'boundstates_default.txt')
        # Check if the file exists!
        if not os.path.isfile(boundstates_file):
            logger.warning(f"Bound states file {boundstates_file} not found.")
            return

        with open(boundstates_file) as f:
            for line in f:
                if line.startswith('#'):
                    continue
                # The first item on the line is the quarkonium, the rest is the list of Fock states
                boundstate_label, bound_state = line.split("=", 1)
                boundstate_label = boundstate_label.strip()
                bound_state = bound_state.strip()
                fock_states = bound_state.strip().split()
                self._boundstates[boundstate_label] = fock_states

                logger.info(f"Defined boundstate {boundstate_label} = {bound_state}")

    def has_onium_amplitude(self):
        """True if one of the generated processes has a bound state."""

        for amp in self._curr_amps or []:
            try:
                amps = amp.get_amplitudes() if hasattr(amp, 'get_amplitudes') else [amp]
                for one_amp in amps:
                    if any(leg.get('onium') for leg in one_amp.get('process').get('legs')):
                        return True
            except Exception:
                # amplitude containers of other interfaces (NLO, ...) never
                # hold a bound state: onia are refused there at generation
                continue
        return False

    def get_rge_parameters_used(self):
        """Parameters evolved by the RGE of the model (running.py, aS excluded)
        on which a coupling of the generated diagrams depends."""

        model = self._curr_model
        if not model or not model.get('running_elements'):
            return set()
        couplings = set()
        for amp in self._curr_amps or []:
            try:
                amps = amp.get_amplitudes() if hasattr(amp, 'get_amplitudes') else [amp]
                for one_amp in amps:
                    for diag in one_amp.get('diagrams'):
                        for vertex in diag.get('vertices'):
                            if not vertex.get('id'):
                                continue
                            inter = model.get_interaction(vertex.get('id'))
                            couplings.update(inter.get('couplings').values())
            except Exception:
                # unknown amplitude layout (loop, NLO...): assume the worst
                couplings.update(c.name for coups in model.get('couplings').values()
                                 for c in coups)
        return model.get_rge_parameters_used(couplings)

    def warn_rge_not_supported(self):
        """The RGE of running.py is only implemented in the madevent and
        aMC@NLO Fortran code: say loudly that the other outputs keep the
        running parameters at their param_card value."""

        used = self.get_rge_parameters_used()
        if not used:
            return
        logger.warning(
            "The model evolves some parameters with the scale (running.py), "
            "and the process depends on %s. 'output %s' does NOT implement this "
            "running: these parameters keep the value given in the param_card "
            "(at the scale Q= of their block) for every event, whatever "
            "fixed_extra_scale / mue_ref_fixed / mue_over_ref say. Only alpha_s "
            "runs. Use 'output madevent' to include the running."
            % (', '.join(sorted(used)), self._export_format))

    def has_fock_state(self, args):
        """True if one of the process tokens names a Fock state or a bound-state
        label (which expands into Fock states)."""

        names = set(f.get('name').lower() for f in self._fockstates)
        pdgs = set(str(f.get('pdg_code')) for f in self._fockstates)
        labels = set(k.lower() for k in self._boundstates)
        for arg in args:
            arg = arg.lower().rstrip('*')
            if arg in names or arg in labels or arg in pdgs:
                return True
        return False

    def unmerge_flavors_for_onia(self):
        """Reload the current model without flavour grouping, keeping the
        multiparticles and the Fock states the user already has."""

        if self._curr_amps:
            raise self.InvalidCmd("Bound states require the model without flavour "
                "grouping, but processes were already generated with it. Use "
                "'set apply_flavor_grouping False' (and re-import the model) "
                "before the first generate.")

        model_name = self._curr_model.get('modelpath+restriction')
        logger.info("Bound states are not supported with flavour grouping: "
                    "reloading the model without it (apply_flavor_grouping = False).")
        saved_multiparticles = copy.deepcopy(self._multiparticles)
        saved_fockstates = list(self._fockstates)
        saved_boundstates = dict(self._boundstates)
        # the import resets the generate line, which output needs for the
        # proc card (procdef_mg5.dat)
        saved_generate_info = self._generate_info
        self.exec_cmd('set apply_flavor_grouping False', precmd=False)
        self.exec_cmd('import model %s' % model_name, precmd=False)
        assert not self._curr_model.get('merged_particles')
        self._multiparticles = saved_multiparticles
        self._fockstates = saved_fockstates
        self._boundstates = saved_boundstates
        self._generate_info = saved_generate_info

    def add_default_fockstates(self):
        """Load the Fock states shipped by the current model (its boundstates.py),
        replacing any Fock state of a previously imported model."""
        import madgraph.models.import_boundstates as ufo_boundstates
        self._fockstates = ufo_boundstates.get_boundstates_ufo(self._curr_model)

        return self._fockstates

    def install_cuttools_iregi(self):
        """Recompile from scratch the CutTools and IREGI libraries of vendor/
        with the current fortran compiler, for instance after an update of
        gfortran (the loop runs refuse a CutTools compiled by another one)."""

        compiler = self.options['fortran_compiler'] or 'gfortran'
        try:
            version = misc.get_gfortran_version(compiler)
        except Exception:
            raise self.InvalidCmd('Fortran compiler "%s" not found: check the '
                                  'option fortran_compiler.' % compiler)

        ct_dir = pjoin(MG5DIR, 'vendor', 'CutTools')
        current = misc.detect_current_compiler(pjoin(ct_dir, 'makefile'))
        if current != compiler:
            misc.mod_compilator(ct_dir, compiler, current)
        logger.info('Compiling CutTools with %s (version %s). This can take a '
                    'couple of minutes...' % (compiler, version), '$MG:BOLD')
        misc.compile(['clean'], cwd=ct_dir, job_specs=False)
        misc.compile(cwd=ct_dir, job_specs=False)
        for name in ['libcts.a', 'mpmodule.mod']:
            if not os.path.exists(pjoin(ct_dir, 'includects', name)):
                raise MadGraph5Error('CutTools could not be compiled in %s.'
                                     % ct_dir)

        iregi_dir = pjoin(MG5DIR, 'vendor', 'IREGI', 'src')
        current = misc.detect_current_compiler(pjoin(iregi_dir,
                                                     'makefile_ML5_lib'))
        if current != compiler:
            misc.mod_compilator(iregi_dir, compiler, current)
        logger.info('Compiling IREGI with %s (version %s). This can take a '
                    'couple of minutes...' % (compiler, version), '$MG:BOLD')
        # the IREGI makefiles locate their sources through $(PWD)
        env = dict(os.environ, PWD=iregi_dir)
        misc.compile(['-f', 'makefile_ML5_lib', 'clean'], cwd=iregi_dir,
                     job_specs=False, env=env)
        misc.compile(['-f', 'makefile_ML5_lib'], cwd=iregi_dir,
                     job_specs=False, env=env)
        if not os.path.exists(pjoin(iregi_dir, 'libiregi.a')):
            raise MadGraph5Error('IREGI could not be compiled in %s.'
                                 % iregi_dir)
        # the same record as CutTools, checked before the loop runs
        with open(pjoin(iregi_dir, 'compiler_version.log'), 'w') as fsock:
            fsock.write('%s\n' % version)
        logger.info('CutTools and IREGI recompiled.')

    def install_pythia8_main164(self, prefix, config_file, add_options):
        """Compile main164, the Pythia8 program MadEvent showers with, for both
        HepMC2 and HepMC3 (installing the HepMC version Pythia8 was not
        configured with if needed), so that the pythia8_card can pick either
        with 'HEPMCoutput:format'. Record the HepMC3 installation in hepmc3_path
        if none is set yet."""

        pythia8_path = self.options['pythia8_path']
        try:
            misc.get_pythia8_main164(pythia8_path)
        except (MadGraph5Error, OSError) as error:
            logger.warning('Pythia8 is installed but its main164 could not be ' +
                'compiled, so MadEvent cannot shower with it yet:\n%s' % error)
            return
        # the main164 an MLM shower uses to split its jet rates per jet sample,
        # patched if needed: built now rather than at the first MLM shower
        try:
            misc.get_pythia8_main164(pythia8_path, jet_sample_djrs=True)
        except (MadGraph5Error, OSError) as error:
            logger.info('main164 could not be built to split the jet rates per ' +
                'jet sample (the DJR plots of MLM showers will show their sum ' +
                'only):\n%s' % error)
        # the HepMC3 of a Pythia8 built against it (pythia8_hepmc3)
        if not self.options['hepmc3_path'] and misc.find_hepmc(3, [pjoin(prefix, 'hepmc3')]):
            self.options['hepmc3_path'] = pjoin(prefix, 'hepmc3')
            self.exec_cmd('save options %s hepmc3_path' % config_file, printcmd=False, log=False)
        native = misc.pythia8_hepmc_version(misc.find_pythia8_main164(pythia8_path)[1])
        if native not in [2, 3]:
            return
        other = 5 - native
        hepmc_tool = 'hepmc3' if other == 3 else 'hepmc'
        hepmc_dir = pjoin(prefix, hepmc_tool)
        if not misc.find_hepmc(other, [hepmc_dir]):
            logger.info('Installing HepMC%d, so that Pythia8 can also write HepMC%d events.'
                        % (other, other), '$MG:BOLD')
            try:
                self.advanced_install(hepmc_tool, additional_options=add_options+['--force'])
            except self.InvalidCmd as error:
                logger.warning('Pythia8 will only write HepMC%d events: %s' % (native, error))
                return
        try:
            misc.get_pythia8_main164(pythia8_path, hepmc_version=other,
                                     hepmc_paths=[hepmc_dir])
        except (MadGraph5Error, OSError) as error:
            logger.warning('main164 of Pythia8 could not be compiled for HepMC%d, ' % other +
                'so that Pythia8 will only write HepMC%d events:\n%s' % (native, error))

    def advanced_install(self, tool_to_install,
                               HepToolsInstaller_web_address=None,
                               additional_options=[]):
        """ Uses the HEPToolsInstaller.py script maintened online to install
        HEP tools with more complicated dependences.
        Additional options will be added to the list when calling HEPInstaller"""
        
        # prevent border effects
        add_options = list(additional_options)

        # Always refresh the installer if already present
        if not os.path.isdir(pjoin(MG5DIR,'HEPTools','HEPToolsInstallers')):
            if HepToolsInstaller_web_address is None:
                raise MadGraph5Error("The option 'HepToolsInstaller_web_address'"+\
                             " must be specified in function advanced_install"+\
                                " if the installers are not already downloaded.")
            if not os.path.isdir(pjoin(MG5DIR,'HEPTools')):
                os.mkdir(pjoin(MG5DIR,'HEPTools'))
        elif not HepToolsInstaller_web_address is None:
            shutil.rmtree(pjoin(MG5DIR,'HEPTools','HEPToolsInstallers'))
        if not HepToolsInstaller_web_address is None:
            # Download HEPToolsInstaller (unless the --local option is used)
            if not '--local' in add_options:
                logger.info('Downloading the HEPToolInstaller at:\n   %s'%
                                                      HepToolsInstaller_web_address)
                # Guess if it is a local or web address
                if '//' in HepToolsInstaller_web_address:
                    misc.wget(HepToolsInstaller_web_address,
                              pjoin(MG5DIR,'HEPTools','HEPToolsInstallers.tar.gz'),
                              stderr=open(os.devnull,'w'), stdout=open(os.devnull,'w'),
                                                                             cwd=MG5DIR)
                else:
                    # If it is a local tarball, then just copy it
                    shutil.copyfile(HepToolsInstaller_web_address,
                               pjoin(MG5DIR,'HEPTools','HEPToolsInstallers.tar.gz'))
                # Untar the file
                returncode = misc.call(['tar', '-xzpf', 'HEPToolsInstallers.tar.gz'],
                         cwd=pjoin(MG5DIR,'HEPTools'), stdout=open(os.devnull, 'w'))
                # Remove the tarball
                os.remove(pjoin(MG5DIR,'HEPTools','HEPToolsInstallers.tar.gz'))
            # FOR DEBUGGING ONLY (if '--local' in add_options), take HEPToolsInstaller locally
            else:
                add_options.remove('--local')
                logger.warning('you are using a local installer. This is intended for debugging only!')
                if os.path.isdir(pjoin(MG5DIR,'HEPTools','HEPToolsInstallers')):
                    shutil.rmtree(pjoin(MG5DIR,'HEPTools','HEPToolsInstallers'))
                misc.copytree(os.path.abspath(pjoin(MG5DIR,os.path.pardir,
           'HEPToolsInstallers')),pjoin(MG5DIR,'HEPTools','HEPToolsInstallers'))

        # Potential change in naming convention
        name_map = {'lhapdf6_py3': 'lhapdf6'}
        try:
            tool = name_map[tool_to_install]
        except:
            tool = tool_to_install
     
        # Compiler options
        compiler_options = []
        if self.options['cpp_compiler'] is not None:
            compiler_options.append('--cpp_compiler=%s'%
                                                   self.options['cpp_compiler'])
            compiler_options.append('--cpp_standard_lib=%s'%
               misc.detect_cpp_std_lib_dependence(self.options['cpp_compiler']))
        elif misc.which('g++'):
            compiler_options.append('--cpp_standard_lib=%s'%
               misc.detect_cpp_std_lib_dependence('g++'))
        else:
            compiler_options.append('--cpp_standard_lib=%s'%
               misc.detect_cpp_std_lib_dependence(None))

        if not self.options['fortran_compiler'] is None:
            compiler_options.append('--fortran_compiler=%s'%
                                               self.options['fortran_compiler'])

        prefix, config_file = self.heptools_install_target(
                                       self.options['heptools_install_dir'])

        # Special rules for certain tools
        if tool in ['madanalysis5', 'rivet']:
            add_options.append('--mg5_path=%s'%MG5DIR)
            if not any(opt.startswith(('--with_fastjet', '--veto_fastjet')) for opt in add_options):
                fastjet_config  = misc.which(self.options['fastjet'])
                if fastjet_config:
                    add_options.append('--with_fastjet=%s'%fastjet_config)
                elif tool in ['madanalysis5']:
                    add_options.append('--with_fastjet')

        if tool in ['madanalysis5']:
            if self.options['delphes_path'] and os.path.isdir(
                  os.path.normpath(pjoin(MG5DIR,self.options['delphes_path']))):
                add_options.append('--with_delphes3=%s'%\
                   os.path.normpath(pjoin(MG5DIR,self.options['delphes_path'])))

        if tool in ['pythia8', 'pythia8_hepmc3', 'eMELA']:
            # All what's below is to handle the lhapdf dependency of Pythia8
            lhapdf_config  = misc.which(self.options['lhapdf'])
            lhapdf_version = None
            if lhapdf_config is None:
                lhapdf_version = None
            else:
                try:
                    version = misc.Popen(
                           [lhapdf_config,'--version'], stdout=subprocess.PIPE)
                    lhapdf_version = int(version.stdout.read().decode(errors='ignore')[0])
                    if lhapdf_version not in [5,6]:
                        raise 
                except:
                    raise self.InvalidCmd('Could not detect LHAPDF version. Make'+
                           " sure '%s --version ' runs properly."%lhapdf_config)
        
            if lhapdf_version is None:
                answer = self.ask(question=
"\033[33;34mLHAPDF was not found. Do you want to install LHPADF6? "+
"(recommended) \033[0m \033[33;32my\033[0m/\033[33;31mn\033[0m >",
                                                default='y',text_format='33;32')
                if not answer.lower() in ['y','']:
                    lhapdf_path = None
                else:
                    self.advanced_install('lhapdf6',
                                          additional_options=add_options)
                    lhapdf_path = pjoin(MG5DIR,'HEPTools','lhapdf6')
                    lhapdf_version = 6
            else:
                lhapdf_path = os.path.abspath(pjoin(os.path.dirname(\
                                                 lhapdf_config),os.path.pardir))
            if lhapdf_version is None:
                logger.warning('You decided not to link the '+ tool + ' installation'+
                  ' to LHAPDF. Beware that only built-in PDF sets can be used then.')
            else:
                logger.info(tool + 'will be linked to LHAPDF v%d.'%lhapdf_version)
            logger.info('Now installing' + tool + '. Be patient...','$MG:color:GREEN')
            lhapdf_option = []
            if lhapdf_version is None:
                lhapdf_option.append('--with_lhapdf6=OFF')
                lhapdf_option.append('--with_lhapdf5=OFF')                
            elif lhapdf_version==5:
                lhapdf_option.append('--with_lhapdf5=%s'%lhapdf_path)
                lhapdf_option.append('--with_lhapdf6=OFF')
            elif lhapdf_version==6:
                lhapdf_option.append('--with_lhapdf5=OFF')
                lhapdf_option.append('--with_lhapdf6=%s'%lhapdf_path)
            # Make sure each option in add_options appears only once
            add_options.append('--mg5_path=%s'%MG5DIR)
            add_options = misc.make_unique(add_options)

             # And that the option '--force' is placed last.
            add_options = [opt for opt in add_options if opt!='--force']+\
                        (['--force'] if '--force' in add_options else [])
            return_code = misc.call([sys.executable, pjoin(MG5DIR,'HEPTools',
             'HEPToolsInstallers','HEPToolInstaller.py'), tool,
             '--prefix=%s' % prefix]
                        + lhapdf_option + compiler_options + add_options)
        else:
            logger.info('Now installing %s. Be patient...'%tool)
            # Make sure each option in add_options appears only once
            add_options.append('--mg5_path=%s'%MG5DIR)
            add_options = misc.make_unique(add_options)
            add_options.append('--mg5_path=%s'%MG5DIR)
             # And that the option '--force' is placed last.
            add_options = [opt for opt in add_options if opt!='--force']+\
                        (['--force'] if '--force' in add_options else [])
            return_code = misc.call([sys.executable, pjoin(MG5DIR,'HEPTools',
              'HEPToolsInstallers', 'HEPToolInstaller.py'), tool,'--prefix=%s'%
              prefix] + compiler_options + add_options)
        if return_code in [0,11]:
            if tool_to_install not in self.install_plugin:
                logger.info("%s successfully installed in %s."%(
                   tool_to_install, prefix),'$MG:color:GREEN')
            else:
                logger.info("%s successfully installed in PLUGIN directory."%(
                   tool_to_install),'$MG:color:GREEN')                

            if tool=='madanalysis5':
                if not any(o.startswith(('--with_','--veto_','--update')) for o in add_options):
                    logger.info('    To install recasting capabilities of madanalysis5 and/or', '$MG:BOLD')
                    logger.info('    to allow delphes analysis at parton level.','$MG:BOLD')
                    logger.info('    Please run \'install MadAnalysis5 --with_delphes --update\':', '$MG:BOLD')
            
        elif return_code == 66:
            answer = self.ask(question=
"""\033[33;34mTool %s already installed in %s."""%(tool_to_install, prefix)+
""" Do you want to overwrite its installation?\033[0m \033[33;32my\033[0m/\033[33;31mn\033[0m >"""
    ,default='y',text_format='33;32')
            if not answer.lower() in ['y','']:
                logger.info("Installation of %s aborted."%tool_to_install,
                                                              '$MG:color:GREEN')
                return
            else:
                return self.advanced_install(tool_to_install,
                              additional_options=add_options+['--force'])            
        else:
            if tool=='madanalysis5' and '--update' not in add_options and \
                                 ('--no_MA5_further_install' not in add_options):
                if not __debug__:
                    logger.warning('Default installation of Madanalys5 failed.')
                    logger.warning("MadGraph7 will now attempt to reinstall it with the options '--no_MA5_further_install --no_root_in_MA5'.")
                    logger.warning("This will however limit MA5 applicability for hadron-level analysis.")
                    logger.warning("If you would like to prevent MadGraph7 to re-attempt MA5 installation, start MadGraph7 with './bin/madgraph --debug'.")
                    for option in ['--no_MA5_further_install', '--no_root_in_MA5', '--force']:
                        if option not in add_options:
                            add_options.append(option)
                    self.advanced_install('madanalysis5', 
                               HepToolsInstaller_web_address=HepToolsInstaller_web_address,
                               additional_options=add_options)
                else:
                    logger.critical("Default installation of Madanalys5 failed, we suggest you try again with the options '--no_MA5_further_install --no_root_in_MA5'.")
            raise self.InvalidCmd("Installation of %s failed."%tool_to_install)

        # Post-installation treatment
        if tool in ['pythia8', 'pythia8_hepmc3']:
            self.options['pythia8_path'] = pjoin(prefix,'pythia8')
            self.exec_cmd('save options %s pythia8_path' % config_file, printcmd=False, log=False)
            self.install_pythia8_main164(prefix, config_file, add_options)
        elif tool == 'lhapdf6':
                self.options['lhapdf_py3'] = pjoin(prefix,'lhapdf6_py3','bin', 'lhapdf-config')
                self.exec_cmd('save options %s lhapdf_py3' % config_file)
                self.options['lhapdf'] = self.options['lhapdf_py3']
        elif tool == 'eMELA':
            self.options['eMELA'] = pjoin(prefix,'bin', 'eMELA-config')
            self.exec_cmd('save options %s eMELA' % config_file)
        elif tool == 'lhapdf5':
            self.options['lhapdf'] = pjoin(prefix,'lhapdf5','bin', 'lhapdf-config')
            self.exec_cmd('save options %s lhapdf' % config_file, printcmd=False, log=False)            
        elif tool == 'madanalysis5':
            self.options['madanalysis5_path'] = pjoin(prefix, 'madanalysis5','madanalysis5')
            self.exec_cmd('save options madanalysis5_path', printcmd=False, log=False)
        elif tool == 'collier':
            self.options['collier'] = pjoin(prefix,'lib')
            self.exec_cmd('save options %s collier' % config_file, printcmd=False, log=False)      
        elif tool == 'ninja':
            if not misc.get_ninja_quad_prec_support(pjoin(
                                              prefix,'ninja','lib')):
                logger.warning(
"""Successful installation of Ninja, but without support for quadruple precision
arithmetics. If you want to enable this (hence improving the treatment of numerically
unstable points in the loop matrix elements) you can try to reinstall Ninja with:
  MadGraph7>install ninja
After having made sure to have selected a C++ compiler in the 'cpp' option of
MadGraph7 that supports quadruple precision (typically g++ based on gcc 4.6+).""")
            self.options['ninja'] = pjoin(prefix,'lib')
            self.exec_cmd('save options %s ninja' % config_file, printcmd=False, log=False)
        elif tool == 'contur':
            to_save = ['contur_path']
            # check that rivet/yoda are correctly linked:
            self.options['%s_path' % tool] = pjoin(prefix, tool)
            if os.path.exists(pjoin(prefix, 'yoda')):
                self.options['yoda_path'] = pjoin(prefix, 'yoda')
                to_save.append('yoda_path')
            if os.path.exists(pjoin(prefix, 'rivet')):
                self.options['rivet_path'] = pjoin(prefix, 'rivet')
                to_save.append('rivet_path')
            if os.path.exists(pjoin(prefix, 'fastjet')):
                self.options['fastjet'] = pjoin(prefix, 'fastjet','bin', 'fastjet-config')
                to_save.append('fastjet')
            if os.path.exists(pjoin(prefix, 'hepmc')):
                self.options['hepmc_path'] = pjoin(prefix, 'hepmc')
                to_save.append('hepmc_path') 
            self.exec_cmd('save options %s %s'  % (config_file,' '.join(to_save)),
                 printcmd=False, log=False)  
        elif tool == 'rivet':
            to_save = ['rivet_path']
            # check that rivet/yoda are correctly linked:
            self.options['%s_path' % tool] = pjoin(prefix, tool)
            if os.path.exists(pjoin(prefix, 'yoda')):
                self.options['yoda_path'] = pjoin(prefix, 'yoda')
                to_save.append('yoda_path')
            if os.path.exists(pjoin(prefix, 'fastjet')):
                self.options['fastjet'] = pjoin(prefix, 'fastjet','bin', 'fastjet-config')
                to_save.append('fastjet')
            if os.path.exists(pjoin(prefix, 'hepmc')):
                self.options['hepmc_path'] = pjoin(prefix, 'hepmc')
                to_save.append('hepmc_path') 
            self.exec_cmd('save options %s %s'  % (config_file,' '.join(to_save)),
                 printcmd=False, log=False)
        elif tool == 'fastjet':
            self.options['fastjet'] = pjoin(prefix, tool,'bin', 'fastjet-config') 
            self.exec_cmd('save options %s fastjet'  % (config_file),
                 printcmd=False, log=False)  
        elif '%s_path' % tool in self.options:
            self.options['%s_path' % tool] = pjoin(prefix, tool)
            self.exec_cmd('save options %s %s_path'  % (config_file,tool), printcmd=False, log=False)      
        else:
            logger.warning("path not saved for %s", tool)
        # Now warn the user if he didn't add HEPTools first in his environment
        # variables.
        path_to_be_set = []
        if sys.platform == "darwin":
            library_variables = ["DYLD_LIBRARY_PATH"]
        else:
            library_variables = ["LD_LIBRARY_PATH"]
        for variable in library_variables:
            if (variable not in os.environ) or \
                not any(os.path.abspath(pjoin(MG5DIR,'HEPTools','lib'))==\
                os.path.abspath(path) for path in os.environ[variable].split(os.pathsep)):
                path_to_be_set.append((variable,
                               os.path.abspath(pjoin(MG5DIR,'HEPTools','lib'))))
        for variable in ["PATH"]:
            if (variable not in os.environ) or \
                not any(os.path.abspath(pjoin(MG5DIR,'HEPTools','bin'))==\
                os.path.abspath(path) for path in os.environ[variable].split(os.pathsep)):
                path_to_be_set.append((variable,
                               os.path.abspath(pjoin(MG5DIR,'HEPTools','bin'))))
            if (variable not in os.environ) or \
                not any(os.path.abspath(pjoin(MG5DIR,'HEPTools','include'))==\
                os.path.abspath(path) for path in os.environ[variable].split(os.pathsep)):
                path_to_be_set.append((variable,
                               os.path.abspath(pjoin(MG5DIR,'HEPTools','include'))))
       
        if len(path_to_be_set)>0:
            shell_type = misc.get_shell_type()
            if shell_type in ['bash',None]:
                modification_line = r"printf '\n# MadGraph7 paths:\n%s\n' >> ~/.bashrc"%\
                (r'\n'.join('export %s=%s%s'%
                (var,path,'%s$%s'%(os.pathsep,var)) for var,path in path_to_be_set))
            elif shell_type=='tcsh':
                modification_line = r"printf '\n# MadGraph7 paths:\n%s\n' >> ~/.cshrc"%\
                (r'\n'.join('setenv %s %s%s'%
                (var,path,'%s$%s'%(os.pathsep,var)) for var,path in path_to_be_set))

            logger.debug("==========")
            logger.debug("We recommend that you add to the following paths"+\
             " to your environment variables, so that you are guaranteed that"+\
             " at runtime, MadGraph7 will use the tools you have just installed"+\
             " and not some other versions installed elsewhere on your system.\n"+\
             "You can do so by running the following command in your terminal:"
             "\n   %s"%modification_line) 
            logger.debug("==========")
    
         # Return true for successful installation
        return True

    install_plugin = ['maddm', 'maddump', 'MadSTR', 'cudacpp']
    install_ad = {'pythia-pgs':['arXiv:0603175'],
                          'Delphes':['arXiv:1307.6346'],
                          'Delphes2':['arXiv:0903.2225'],
                          'SysCalc':['arXiv:1801.08401'],
                          'Golem95':['arXiv:0807.0605'],
                          'QCDLoop':['arXiv:0712.1851'],
                          'pythia8':['arXiv:1410.3012'],
                          'lhapdf6':['arXiv:1412.7420'],
                          'lhapdf5':['arXiv:0605240'],
                          'hepmc':['CPC 134 (2001) 41-46'],
                          'ninja':['arXiv:1203.0291','arXiv:1403.1229','arXiv:1604.01363'],
                          'MadAnalysis5':['arXiv:1206.1599'],
                          'collier':['arXiv:1604.06792'],
                          'oneloop':['arXiv:1007.4716'],
                          'maddm':['arXiv:1804.00444'],
                          'maddump':['arXiv:1812.06771'],
                          'MadSTR':['arXiv:1612.00440']}
    
    install_server = ['http://madgraph.phys.ucl.ac.be/package_info.dat',
                         'http://madgraph.mi.infn.it/package_info.dat']

    install_name = {'Delphes2':'Delphes',
                'Delphes3':'Delphes', 'pythia-pgs':'pythia-pgs',
                'ExRootAnalysis': 'ExRootAnalysis','MadAnalysis':'madanalysis5',
                'SysCalc':'SysCalc', 'Golem95': 'golem95',
                    'lhapdf6' : 'lhapdf6_py3',
                'QCDLoop':'QCDLoop','MadAnalysis5':'madanalysis5',
                'maddm':'maddm'
                }

    def do_install(self, line, paths=None, additional_options=[]):
        """Install optional package from the MG suite.
        The argument 'additional_options' will be passed to the advanced_install
        functions. If it contains the option '--force', then the advanced_install
        function will overwrite any existing installation of the tool without 
        warnings.
        """

        # Make sure to avoid any border effect on custom_additional_options
        add_options = list(additional_options)
        
        args = self.split_arg(line)
        #check the validity of the arguments
        install_options = self.check_install(args)

        if sys.platform == "darwin":
            program = "curl"
        else:
            program = "wget"

        # special command for auto-update
        if args[0] == 'update':
            self.install_update(['update']+install_options['update_options'],wget=program)
            return
        elif args[0] == 'looptools':
            self.install_reduction_library(force=True)
            return
        elif args[0] == 'ninjars':
            from madgraph.various import ninjars_install
            prefix, config_file = self.heptools_install_target(
                self.options['heptools_install_dir'])
            libdir = ninjars_install.install(
                MG5DIR, prefix,
                arguments=install_options['options_for_HEPToolsInstaller'] + add_options,
                fortran_compiler=self.options['fortran_compiler'],
                jobs=self.options['nb_core'])
            if libdir is not None:
                self.options['ninjars'] = libdir
                _, config_file = self.heptools_install_target(
                    os.path.dirname(os.path.dirname(libdir)))
                self.exec_cmd('save options %s ninjars' % config_file,
                              printcmd=False, log=False)
            return
        elif args[0] == 'tirust':
            from madgraph.various import tirust_install
            prefix, config_file = self.heptools_install_target(
                self.options['heptools_install_dir'])
            def save_tirust_configuration(libdir):
                _, target_config = self.heptools_install_target(
                    os.path.dirname(os.path.dirname(libdir)))
                try:
                    tirust_install.save_configuration(self, target_config, libdir)
                except Exception as error:
                    raise MadGraph5Error('TIRust configuration could not be saved; '
                        'the installation update was not committed: %s' % error) from error
            libdir = tirust_install.install(
                MG5DIR, prefix,
                arguments=install_options['options_for_HEPToolsInstaller'] + add_options,
                fortran_compiler=self.options['fortran_compiler'],
                jobs=self.options['nb_core'],
                on_publish=save_tirust_configuration)
            if libdir is not None:
                self.options['tirust'] = libdir
            return
        elif args[0] == 'cuttools_iregi':
            self.install_cuttools_iregi()
            return
        elif args[0] == 'madspace':
            install_script = pjoin(MG5DIR, 'madspace', 'install.py')
            install_args = args[1:]
            # The source build compiles in parallel only if it is told how many
            # jobs it may use (see set_build_parallelism in install.py), so hand
            # it MG5's nb_core unless an explicit -j was given on the line.
            if not any(a == '-j' or a.startswith('-j') or a.startswith('--jobs')
                       for a in install_args):
                install_args = install_args + ['-j', str(self.options['nb_core'])]
            subprocess.run([sys.executable, install_script] + install_args)
            return

        plugin = self.install_plugin
        
        advertisements = self.install_ad


        if args[0] in advertisements:
#            logger.info('{:^80}'.format("-"*70), '$MG:BOLD')
#            logger.info('{:^80}'.format("You are installing '%s', please cite ref(s):"%args[0]), '$MG:BOLD')
#            logger.info('{:^80}'.format(', '.join(advertisements[args[0]])), '$MG:color:GREEN')
#            logger.info('{:^80}'.format("when using results produced with this tool."), '$MG:BOLD')
#            logger.info('{:^80}'.format("-"*70), '$MG:BOLD')
            logger.info("   You are installing '%s', please cite ref(s): \033[92m%s\033[0m. " % (args[0], ', '.join(advertisements[args[0]])), '$MG:BOLD')

        source = None
        # Load file with path of the different program:
        import urllib.request, urllib.parse, urllib.error
        if paths:
            path = paths
        else:
            path = {}
    
            data_path = self.install_server

#           Force here to choose one particular server
            if any(a.startswith('--source=') for a in args):
                source = [a[9:] for a in args if a.startswith('--source=')][-1]
                if source == 'uiuc':
                    r = [1]
                elif source == 'ucl':
                    r = [0]
                else:
                    if source[-1].isdigit() or source[-1] == '/':
                        source += '/package_info.dat'
                    data_path.append(source)
                    r = [2]
            else: 
                r = random.randint(0,1)
                r = [r, (1-r)]
                if 'MG5aMC_WWW' in os.environ and os.environ['MG5aMC_WWW']:
                    data_path.append(os.environ['MG5aMC_WWW']+'/package_info.dat')
                    r.insert(0, 2)



            for index in r:
                cluster_path = data_path[index]
                try:
                    data = urllib.request.urlopen(cluster_path)
                except Exception as error:
                    misc.sprint(str(error), cluster_path)
                    continue
                if data.getcode() != 200:
                    continue
                
                break
                
            else:
                raise MadGraph5Error('''Impossible to connect any of us servers.
                Please check your internet connection or retry later''')
            for wwwline in data:
                split = wwwline.decode(errors='ignore').split()
                if len(split)!=2:
                    if '--source' not in line:
                        source = {0:'uiuc',1:'ucl'}[index]
                        return self.do_install(line+' --source='+source, paths=paths, additional_options=additional_options)
                path[split[0]] = split[1]

################################################################################
# TEMPORARY HACK WHERE WE ADD ENTRIES TO WHAT WILL BE EVENTUALLY ON THE WEB
################################################################################
#            path['XXX'] = 'YYY'
################################################################################

        if args[0] == 'Delphes':
            args[0] = 'Delphes3'


        try:
            name = self.install_name
            name = name[args[0]]
        except KeyError:
            name = args[0]
        if args[0] in ['madstr', 'madSTR']:
            args[0] = 'MadSTR'
            name = 'MadSTR'
            
        if args[0] in self._advanced_install_opts:
            # Now launch the advanced installation of the tool args[0]
            # path['HEPToolsInstaller'] is the online address where to download
            # the installers if necessary.
            add_options.extend(install_options['options_for_HEPToolsInstaller'])
            if not any(opt.startswith('--logging=') for opt in add_options):
                add_options.append('--logging=%d' % logger.level)
            # Pythia8 is built against HepMC3 (the HepMC2 version of its main164
            # is compiled afterwards), unless --hepmc2 asks for the HepMC2 build.
            if name == 'pythia8':
                if '--hepmc2' in add_options:
                    add_options.remove('--hepmc2')
                else:
                    name = 'pythia8_hepmc3'
                    add_options = [opt.replace('--pythia8_tarball=', '--pythia8_hepmc3_tarball=')
                                   for opt in add_options]

            return self.advanced_install(name, path['HEPToolsInstaller'],
                                        additional_options = add_options)


        if args[0] == 'Delphes':
            args[0] = 'Delphes3'        


        #check outdated install
        substitution={'Delphes2':'Delphes','pythia-pgs':'pythia8'}
        if args[0] in substitution:
            logger.critical("Please Note that this package is NOT maintained anymore by their author(s).\n"+\
               "  You should consider installing and using %s, with:\n"%substitution[args[0]]+
               "   > install %s"%substitution[args[0]])
            ans = self.ask('Do you really want to continue?', 'n', ['y','n'])
            if ans !='y':
                return
            
        try:
            os.system('rm -rf %s' % pjoin(MG5DIR, name))
        except Exception:
            pass

        if args[0] not in path:
            if not source:
                if index ==1:
                    othersource = 'ucl'
                else:
                    othersource = 'uiuc'
                # try with the mirror
                misc.sprint('try other mirror', othersource, ' '.join(args))
                return self.do_install('%s --source=%s' % (' '.join(args), othersource), 
                                       paths, additional_options) 
            else:
                if name in advertisements and 'xxx' in advertisements[name][0]:
                    logger.warning("Program not yet released. Please try later")
                else:
                    raise Exception("Online server are corrupted. No tarball available for %s" % name)
                return
            
        # Load that path
        logger.info('Downloading %s' % path[args[0]])
        misc.wget(path[args[0]], '%s.tgz' % name, cwd=MG5DIR)

        # Untar the file
        returncode = misc.call(['tar', '-xzpf', '%s.tgz' % name], cwd=MG5DIR,
                                     stdout=open(os.devnull, 'w'))

        if returncode:
            raise MadGraph5Error('Fail to download correctly the File. Stop')

        if name == "RunningCoupling":
            name = "Template/Running"

        # Check that the directory has the correct name
        if not os.path.exists(pjoin(MG5DIR, name)):
            created_name = [n for n in os.listdir(MG5DIR) if n.lower().startswith(
                                         name.lower()) and not n.endswith('gz')]
            if not created_name:
                raise MadGraph5Error('The file was not loaded correctly. Stop')
            else:
                created_name = created_name[0]
            files.mv(pjoin(MG5DIR, created_name), pjoin(MG5DIR, name))

        if hasattr(self, 'post_install_%s' %name):
            return getattr(self, 'post_install_%s' %name)()

        logger.info('compile %s. This might take a while.' % name)

        # Modify Makefile for pythia-pgs on Mac 64 bit
        if args[0] == "pythia-pgs" and sys.maxsize > 2**32:
            path = os.path.join(MG5DIR, 'pythia-pgs', 'src', 'make_opts')
            text = open(path).read()
            text = text.replace('MBITS=32','MBITS=64')
            open(path, 'w').writelines(text)
            if not os.path.exists(pjoin(MG5DIR, 'pythia-pgs', 'libraries','pylib','lib')):
                os.mkdir(pjoin(MG5DIR, 'pythia-pgs', 'libraries','pylib','lib'))

        make_flags = [] #flags for the compilation
        # Compile the file
        # Check for F77 compiler
        if 'FC' not in os.environ or not os.environ['FC']:
            if self.options['fortran_compiler'] and self.options['fortran_compiler'] != 'None':
                compiler = self.options['fortran_compiler']
            elif misc.which('gfortran'):
                compiler = 'gfortran'
            elif misc.which('g77'):
                compiler = 'g77'
            else:
                raise self.InvalidCmd('Require g77 or Gfortran compiler')

            path = None
            base_compiler= ['FC=g77','FC=gfortran']
            if args[0] == "pythia-pgs":
                path = os.path.join(MG5DIR, 'pythia-pgs', 'src', 'make_opts')
            if path:
                text = open(path).read()
                for base in base_compiler:
                    text = text.replace(base,'FC=%s' % compiler)
                open(path, 'w').writelines(text)
            os.environ['FC'] = compiler
        
        # For Golem95, use autotools.
        if name == 'golem95':
            # Run the configure script
            ld_path = misc.Popen(['./configure', 
            '--prefix=%s'%str(pjoin(MG5DIR, name)),'FC=%s'%os.environ['FC']],
            cwd=pjoin(MG5DIR,'golem95'),stdout=subprocess.PIPE).communicate()[0].decode(errors='ignore')


        # For QCDLoop, use autotools.
        if name == 'QCDLoop':
            # Run the configure script
            ld_path = misc.Popen(['./configure', 
            '--prefix=%s'%str(pjoin(MG5DIR, name)),'FC=%s'%os.environ['FC'],
            'F77=%s'%os.environ['FC']], cwd=pjoin(MG5DIR,name),
                                        stdout=subprocess.PIPE).communicate()[0].decode(errors='ignore')

        # For Delphes edit the makefile to add the proper link to correct library
        if args[0] == 'Delphes3':
            #change in the makefile 
            #DELPHES_LIBS = $(shell $(RC) --libs) -lEG $(SYSLIBS)
            # to 
            #DELPHES_LIBS = $(shell $(RC) --libs) -lEG $(SYSLIBS) -Wl,-rpath,/Applications/root_v6.04.08/lib/
            rootsys = os.environ['ROOTSYS']
            text = open(pjoin(MG5DIR, 'Delphes','Makefile')).read()
            text = text.replace('DELPHES_LIBS = $(shell $(RC) --libs) -lEG $(SYSLIBS)', 
                         'DELPHES_LIBS = $(shell $(RC) --libs) -lEG $(SYSLIBS) -Wl,-rpath,%s/lib/' % rootsys)
            open(pjoin(MG5DIR, 'Delphes','Makefile'),'w').write(text)
            
        # For SysCalc link to lhapdf
        if name == 'SysCalc':
            if self.options['lhapdf']:
                ld_path = misc.Popen([self.options['lhapdf'], '--libdir'],
                                     stdout=subprocess.PIPE).communicate()[0].decode(errors='ignore')
                ld_path = ld_path.replace('\n','')
                if 'LD_LIBRARY_PATH' not in os.environ:
                    os.environ['LD_LIBRARY_PATH'] = ld_path
                elif not os.environ['LD_LIBRARY_PATH']:
                    os.environ['LD_LIBRARY_PATH'] = ld_path
                elif ld_path not in os.environ['LD_LIBRARY_PATH']:
                    os.environ['LD_LIBRARY_PATH'] += ';%s' % ld_path
                if self.options['lhapdf'] != 'lhapdf-config':
                    if misc.which('lhapdf-config') != os.path.realpath(self.options['lhapdf']):
                        os.environ['PATH'] = '%s:%s' % (os.path.realpath(self.options['lhapdf']),os.environ['PATH']) 
            else:
                raise self.InvalidCmd('lhapdf is required to compile/use SysCalc. Specify his path or install it via install lhapdf6')
            if self.options['cpp_compiler']:
                make_flags.append('CXX=%s' % self.options['cpp_compiler'])
            

        if name in plugin:
            logger.info('no compilation needed for plugin. Loading plugin information')
            try:
                shutil.rmtree(pjoin(MG5DIR, 'PLUGIN', name))
            except Exception:
                pass
            shutil.move(pjoin(os.path.join(MG5DIR, name)), os.path.join(MG5DIR, 'PLUGIN', name))
            # read the __init__.py to check if we need to add a new executable
            pyvers=sys.version[0]
            try:
                __import__('PLUGIN.%s' % name, globals(), locals(), [])
                plugin = sys.modules['PLUGIN.%s' % name] 
                new_interface = plugin.new_interface
                new_output = plugin.new_output
                latest_validated_version = getattr(plugin,
                                         'latest_validated_mg7_version',
                                         getattr(plugin, 'latest_validated_version', ''))
            except Exception as error:
                print(error)
                logger.warning('Plugin is not compatible with Python 3! It will run with python2')
                text = open(os.path.join(MG5DIR, 'PLUGIN', name, '__init__.py')).read()
                if re.search(r'^\s*new_interface\s*=\s*(?!None).', text, re.M):
                    new_interface = True
                    pyvers = 2
                else:
                    misc.sprint(text)
                new_output = []
                latest_validated_version = ''
                misc.sprint(pyvers)
                    
            logger.info('Plugin %s correctly interfaced. Latest official validition for MadGraph7 version %s.' % (name, '.'.join(repr(i) for i in latest_validated_version)))
            if new_interface:
                ff = open(pjoin(MG5DIR, 'bin', '%s.py' % name) , 'w') 
                if __debug__:
                    text = '''#! /usr/bin/env python{1}
import os
import sys
root_path = os.path.split(os.path.dirname(os.path.realpath( __file__ )))[0]
exe_path = os.path.join(root_path,'bin','madgraph')
sys.argv.pop(0)
os.system('%s  -tt %s %s --mode={0}' %(sys.executable, str(exe_path) , ' '.join(sys.argv) ))
'''.format(name,'' if pyvers == 2 else pyvers)                    
                else:
                    text = '''#! /usr/bin/env python{1}
import os
import sys
root_path = os.path.split(os.path.dirname(os.path.realpath( __file__ )))[0]
exe_path = os.path.join(root_path,'bin','madgraph')
sys.argv.pop(0)
os.system('%s  -O -W ignore::DeprecationWarning %s %s --mode={0}' %(sys.executable, str(exe_path) , ' '.join(sys.argv) ))
'''.format(name,'' if pyvers == 2 else pyvers)                     
                ff.write(text)
                ff.close()
                import stat
                os.chmod(pjoin(MG5DIR, 'bin', '%s.py' % name), stat.S_IRWXU)
                logger.info('To use this module, you need to quit MadGraph7 and run the executable bin/%s.py' % name)
            status=0
                
        elif logger.level <= logging.INFO:
            devnull = open(os.devnull,'w')
            try:
                misc.call(['make', 'clean'], stdout=devnull, stderr=-2)
            except Exception:
                pass
            if name == 'pythia-pgs':
                #SLC6 needs to have this first (don't ask why)
                status = misc.call(['make'], cwd = pjoin(MG5DIR, name, 'libraries', 'pylib'))
            if name in ['golem95','QCDLoop']:
                status = misc.call(['make','install'], 
                                               cwd = os.path.join(MG5DIR, name))
            else:
                status = misc.call(['make']+make_flags, cwd = os.path.join(MG5DIR, name))
            devnull.close()
        else:
            try:
                misc.compile(['clean'], mode='', cwd = os.path.join(MG5DIR, name))
            except Exception:
                pass
            if name == 'pythia-pgs':
                #SLC6 needs to have this first (don't ask why)
                status = self.compile(mode='', cwd = pjoin(MG5DIR, name, 'libraries', 'pylib'))
            if name in ['golem95','QCDLoop']:
                status = misc.compile(['install'], mode='', 
                                          cwd = os.path.join(MG5DIR, name))
            else:
                status = self.compile(make_flags, mode='',
                                               cwd = os.path.join(MG5DIR, name))

        if not status:
            logger.info('Installation succeeded')
        else:
            # For pythia-pgs check when removing the "-fno-second-underscore" flag
            if name == 'pythia-pgs':
                to_comment = ['libraries/PGS4/src/stdhep-dir/mcfio/arch_mcfio',
                              'libraries/PGS4/src/stdhep-dir/src/stdhep_Arch']
                for f in to_comment:
                    f = pjoin(MG5DIR, name, *f.split('/'))
                    text = "".join(l for l in open(f) if 'fno-second-underscore' not in l)
                    fsock = open(f,'w').write(text)
                try:
                    misc.compile(['clean'], mode='', cwd = os.path.join(MG5DIR, name))
                except Exception:
                    pass
                status = self.compile(mode='', cwd = os.path.join(MG5DIR, name))
            if not status:
                logger.info('Compilation succeeded')
            else:
                logger.warning('Error detected during the compilation. Please check the compilation error and run make manually.')


        if args[0] == 'Delphes2':
            data = open(pjoin(MG5DIR, 'Delphes','data','DetectorCard.dat')).read()
            data = data.replace('data/', 'DELPHESDIR/data/')
            out = open(pjoin(MG5DIR, 'Template','Common', 'Cards', 'delphes_card_default.dat'), 'w')
            out.write(data)
        if args[0] == 'Delphes3':
            if os.path.exists(pjoin(MG5DIR, 'Delphes','cards')):
                card_dir = pjoin(MG5DIR, 'Delphes','cards')
            else:
                card_dir = pjoin(MG5DIR, 'Delphes','examples')
            files.cp(pjoin(card_dir,'delphes_card_CMS.tcl'),
                     pjoin(MG5DIR,'Template', 'Common', 'Cards', 'delphes_card_default.dat'))
            files.cp(pjoin(card_dir,'delphes_card_CMS.tcl'),
                     pjoin(MG5DIR,'Template', 'Common', 'Cards', 'delphes_card_CMS.dat'))
            files.cp(pjoin(card_dir,'delphes_card_ATLAS.tcl'),
                     pjoin(MG5DIR,'Template', 'Common', 'Cards', 'delphes_card_ATLAS.dat'))
            
            if not self.options['pythia-pgs_path'] and not self.options['pythia8_path']:
                logger.warning("We noticed that no parton-shower module are installed/linked. \n In order to use Delphes from MadGraph7 please install/link pythia8.")

        #reset the position of the executable
        options_name = {'Delphes': 'delphes_path',
                           'Delphes2': 'delphes_path',
                           'Delphes3': 'delphes_path',
                           'ExRootAnalysis': 'exrootanalysis_path',
                           'SysCalc': 'syscalc_path',
                           'pythia-pgs':'pythia-pgs_path',
                           'Golem95': 'golem'}

        if args[0] in options_name:
            opt = options_name[args[0]]
            if opt=='golem':
                self.options[opt] = pjoin(MG5DIR,name,'lib')
                self.exec_cmd('save options %s' % opt, printcmd=False)
            elif self.options[opt] != self.options_configuration[opt]:
                self.options[opt] = self.options_configuration[opt]
                self.exec_cmd('save options %s' % opt, printcmd=False)
                    

    def install_update(self, args, wget):
        """ check if the current version of mg5 is up-to-date.
        and allow user to install the latest version of MG5 """

        def apply_patch(filetext):
            """function to apply the patch"""
            text = filetext.read().decode(errors='ignore')
            
            pattern = re.compile(r'''^=== renamed directory \'(?P<orig>[^\']*)\' => \'(?P<new>[^\']*)\'''')
            #= = = renamed directory 'Template' => 'Template/LO'
            for orig, new in pattern.findall(text):
                misc.copytree(pjoin(MG5DIR, orig), pjoin(MG5DIR, 'UPDATE_TMP'))
                full_path = os.path.dirname(pjoin(MG5DIR, new)).split('/')
                for i, name in enumerate(full_path):
                    path = os.path.sep.join(full_path[:i+1])
                    if path and not os.path.isdir(path):
                        os.mkdir(path)
                misc.copytree(pjoin(MG5DIR, 'UPDATE_TMP'), pjoin(MG5DIR, new))
                shutil.rmtree(pjoin(MG5DIR, 'UPDATE_TMP'))
            # track rename since patch fail to apply those correctly.
            pattern = re.compile(r'''=== renamed file \'(?P<orig>[^\']*)\' => \'(?P<new>[^\']*)\'''')
            #=== renamed file 'Template/SubProcesses/addmothers.f' => 'madgraph/iolibs/template_files/addmothers.f'
            for orig, new in pattern.findall(text):
                print('move %s to %s' % (orig, new))
                try:
                    files.cp(pjoin(MG5DIR, orig), pjoin(MG5DIR, new), error=True)
                except IOError:
                    full_path = os.path.dirname(pjoin(MG5DIR, new)).split('/')
                    for i, name in enumerate(full_path):
                        path = os.path.sep.join(full_path[:i+1])
                        if path and not os.path.isdir(path):
                            os.mkdir(path)
                files.cp(pjoin(MG5DIR, orig), pjoin(MG5DIR, new), error=True)
            # track remove/re-added file:
            pattern = re.compile(r'''^=== added file \'(?P<new>[^\']*)\'''',re.M)
            all_add = pattern.findall(text)
            #pattern = re.compile(r'''=== removed file \'(?P<new>[^\']*)\'''')
            #all_rm = pattern.findall(text)
            pattern=re.compile(r'''=== removed file \'(?P<new>[^\']*)\'(?=.*=== added file \'(?P=new)\')''',re.S)
            print('this step can take a few minutes. please be patient')
            all_rm_add = pattern.findall(text)
            #=== added file 'tests/input_files/full_sm/interactions.dat'
            for new in all_add:
                if new in all_rm_add:
                    continue
                if os.path.isfile(pjoin(MG5DIR, new)):
                    os.remove(pjoin(MG5DIR, new))
            #pattern = re.compile(r'''=== removed file \'(?P<new>[^\']*)\'''')
            #=== removed file 'tests/input_files/full_sm/interactions.dat'
            #for old in pattern.findall(text):
            #    if not os.path.isfile(pjoin(MG5DIR, old)):
            #        full_path = os.path.dirname(pjoin(MG5DIR, old)).split('/')
            #        for i, _ in enumerate(full_path):
            #            path = os.path.sep.join(full_path[:i+1])
            #            if path and not os.path.isdir(path):
            #                os.mkdir(path)
            #        subprocess.call(['touch', pjoin(MG5DIR, old)])

            p= subprocess.Popen(['patch', '-p1'], stdin=subprocess.PIPE,
                                                              cwd=MG5DIR)
            p.communicate(text.encode())

            # check file which are not move
            #=== modified file 'Template/LO/Cards/run_card.dat'
            #--- old/Template/Cards/run_card.dat     2012-12-06 10:01:04 +0000
            #+++ new/Template/LO/Cards/run_card.dat  2013-12-09 02:35:59 +0000
            pattern=re.compile('''=== modified file \'(?P<new>[^\']*)\'[^\n]*\n\\-\\-\\- old/(?P<old>\\S*)[^\n]*\n\\+\\+\\+ new/(?P=new)''',re.S)
            for match in pattern.findall(text):
                new = pjoin(MG5DIR, match[0])
                old = pjoin(MG5DIR, match[1])
                if new == old:
                    continue
                elif os.path.exists(old):
                    if not os.path.exists(os.path.dirname(new)):
                        split = new.split('/')
                        for i in range(1,len(split)):
                            path = '/'.join(split[:i])
                            if not os.path.exists(path):
                                print('mkdir', path)
                                os.mkdir(path)
                    files.cp(old,new)
            #=== renamed file 'Template/bin/internal/run_delphes' => 'Template/Common/bin/internal/run_delphes'
            #--- old/Template/bin/internal/run_delphes       2011-12-09 07:28:10 +0000
            #+++ new/Template/Common/bin/internal/run_delphes        2012-10-23 02:41:37 +0000
            #pattern=re.compile('''=== renamed file \'(?P<old>[^\']*)\' => \'(?P<new>[^\']*)\'[^\n]*\n\-\-\- old/(?P=old)[^\n]*\n\+\+\+ new/(?P=new)''',re.S)
            #for match in pattern.findall(text):
            #    old = pjoin(MG5DIR, match[0])
            #    new = pjoin(MG5DIR, match[1])
            #    if new == old:
            #       continue
            #    elif os.path.exists(old):
            #        if not os.path.exists(os.path.dirname(new)):
            #            split = new.split('/')
            #            for i in range(1,len(split)):
            #                path = '/'.join(split[:i])
            #                if not os.path.exists(path):
            #                    print 'mkdir', path
            #                    os.mkdir(path)
            #        files.cp(old,new)

            # check that all files in bin directory are executable
            for path in misc.glob('*', pjoin(MG5DIR, 'bin')):
                misc.call(['chmod', '+x', path])
            for path in misc.glob(pjoin('*','bin','*'), pjoin(MG5DIR, 'Template')):
                misc.call(['chmod', '+x', path])
            for path in misc.glob(pjoin('*','bin','internal','*'), pjoin(MG5DIR, 'Template')):
                misc.call(['chmod', '+x', path])
            for path in misc.glob(pjoin('*','*', '*.py'), pjoin(MG5DIR, 'Template')):
                misc.call(['chmod', '+x', path])
            for path in misc.glob(pjoin('*','*','*.sh'), pjoin(MG5DIR, 'Template')):
                misc.call(['chmod', '+x', path])

            #add empty files/directory
            pattern=re.compile('''^=== touch (file|directory) \'(?P<new>[^\']*)\'''',re.M)
            for match in pattern.findall(text):
                if match[0] == 'file':
                    new = os.path.dirname(pjoin(MG5DIR, match[1]))
                else:
                    new = pjoin(MG5DIR, match[1])
                if not os.path.exists(new):
                    split = new.split('/')
                    for i in range(1,len(split)+1):
                        path = '/'.join(split[:i])
                        if path and not os.path.exists(path):
                            print('mkdir', path)
                            os.mkdir(path)
                if match[0] == 'file':
                    print('touch ', pjoin(MG5DIR, match[1]))
                    misc.call(['touch', pjoin(MG5DIR, match[1])])
            # add new symlink
            pattern=re.compile('''^=== link file \'(?P<new>[^\']*)\' \'(?P<old>[^\']*)\'''', re.M)
            for new, old in pattern.findall(text):
                    if not os.path.exists(pjoin(MG5DIR, new)):
                        files.ln(pjoin(MG5DIR,old), os.path.dirname(pjoin(MG5DIR,new)), os.path.basename(new))

            # Re-compile CutTools and IREGI
            if os.path.isfile(pjoin(MG5DIR,'vendor','CutTools','includects','libcts.a')):
                misc.compile(arg=['-j1'],cwd=pjoin(MG5DIR,'vendor','CutTools'),nb_core=1)
            if os.path.isfile(pjoin(MG5DIR,'vendor','IREGI','src','libiregi.a')):
                misc.compile(cwd=pjoin(MG5DIR,'vendor','IREGI','src'))

            # check if it need to download binary:
            pattern = re.compile(r"""^Binary files old/(\S*).*and new/(\S*).*$""", re.M)
            if pattern.search(text):
                return True
            else:
                return False
        
        mode = [arg.split('=',1)[1] for arg in args if arg.startswith('--mode=')]
        if mode:
            mode = mode[-1]
        else:
            mode = "userrequest"
        force = any([arg=='-f' for arg in args])
        timeout = [arg.split('=',1)[1] for arg in args if arg.startswith('--timeout=')]
        if timeout:
            try:
                timeout = int(timeout[-1])
            except ValueError:
                raise self.InvalidCmd('%s: invalid argument for timeout (integer expected)'%timeout[-1])
        else:
            timeout = self.options['timeout']
        input_path = [arg.split('=',1)[1] for arg in args if arg.startswith('--input=')]

        if input_path:
            fsock = open(input_path[0])
            need_binary = apply_patch(fsock)
            logger.info('manual patch apply. Please test your version.')
            if need_binary:
                logger.warning('Note that some files need to be loaded separately!')
            sys.exit(0)

        options = ['y','n','on_exit']
        if mode == 'mg5_start':
            timeout = 2
            default = 'n'
            update_delay = float(self.options['auto_update']) * 24 * 3600
            if update_delay == 0:
                return
        elif mode == 'mg5_end':
            timeout = 5
            default = 'n'
            update_delay = float(self.options['auto_update']) * 24 * 3600
            if update_delay == 0:
                return
            options.remove('on_exit')
        elif mode == "userrequest":
            default = 'y'
            update_delay = 0
        else:
            raise self.InvalidCmd('Unknown mode for command install update')

        if not os.path.exists(os.path.join(MG5DIR,'input','.autoupdate')):# or \
                #os.path.exists(os.path.join(MG5DIR,'.bzr')):
            error_text = """This version of MG5 doesn\'t support auto-update. Common reasons are:
            1) This version was loaded via bazaar (use bzr pull to update instead).
            2) This version is a beta release of MG5."""
            if mode == 'userrequest':
                raise self.ConfigurationError(error_text)
            return

        if not misc.which('patch'):
            error_text = """Not able to find program \'patch\'. Please reload a clean version
            or install that program and retry."""
            if mode == 'userrequest':
                raise self.ConfigurationError(error_text)
            return

        # read the data present in .autoupdate
        data = {'last_message':0}
        for line in open(os.path.join(MG5DIR,'input','.autoupdate')):
            if not line.strip():
                continue
            sline = line.split()
            data[sline[0]] = int(sline[1])

        #check validity of the file
        if 'version_nb' not in data:
            if mode == 'userrequest':
                error_text = 'This version of MG5 doesn\'t support auto-update. (Invalid information)'
                raise self.ConfigurationError(error_text)
            return
        elif 'last_check' not in data:
            data['last_check'] = time.time()

        #check if we need to update.
        if time.time() - float(data['last_check']) < float(update_delay):
            return

        logger.info('Checking if MG5 is up-to-date... (takes up to %ss)' % timeout)
        class TimeOutError(Exception): pass

        def handle_alarm(signum, frame):
            raise TimeOutError

        signal.signal(signal.SIGALRM, handle_alarm)
        signal.alarm(timeout)
        to_update = 0
        try:
            filetext = urllib.request.urlopen('http://madgraph.phys.ucl.ac.be/mg5amc3_build_nb')
            signal.alarm(0)
            text = filetext.read().decode(errors='ignore').split('\n')
            web_version = int(text[0].strip())
            try:
                msg_version = int(text[1].strip())
                message = '\n'.join(text[2:])
            except:
                msg_version = 0
                message = ""
        except (TimeOutError, ValueError, IOError):
            signal.alarm(0)
            print('failed to connect server')
            if mode == 'mg5_end':
                # wait 24h before next check
                fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
                fsock.write("version_nb   %s\n" % data['version_nb'])
                fsock.write("last_check   %s\n" % (\
                int(time.time()) - 3600 * 24 * (self.options['auto_update'] -1)))
                fsock.write("last_message   %s\n" % data['last_message'])
                fsock.close()
            return

        if msg_version > data['last_message']:
            data['last_message'] = msg_version
            logger.info("************* INFORMATION *************", '$MG:BOLD')
            logger.info(message.replace('\n','\n    '))
            logger.info("************* INFORMATION *************", '$MG:BOLD')
            fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
            fsock.write("version_nb   %s\n" % data['version_nb'])
            fsock.write("last_check   %s\n" % (\
            int(time.time()) - 3600 * 24 * (int(self.options['auto_update']) -1)))
            fsock.write("last_message   %s\n" % data['last_message'])
            fsock.close()
            
        if os.path.exists(os.path.join(MG5DIR,'.bzr')):
            logger.info("bzr version: use bzr pull to update")
            return 
        
        if web_version == data['version_nb']:
            logger.info('No new version of MG5 available')
            # update .autoupdate to prevent a too close check
            fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
            fsock.write("version_nb   %s\n" % data['version_nb'])
            fsock.write("last_check   %s\n" % int(time.time()))
            fsock.write("last_message   %s\n" % data['last_message'])
            fsock.close()
            return
        elif data['version_nb'] > web_version:
            logger_stderr.info('impossible to update: local %s web %s' % (data['version_nb'], web_version))
            fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
            fsock.write("version_nb   %s\n" % data['version_nb'])
            fsock.write("last_check   %s\n" % int(time.time()))
            fsock.write("last_message   %s\n" % data['last_message'])
            fsock.close()
            return
        else:
            if not force:
                answer = self.ask('New Version of MG5 available! Do you want to update your current version?',
                                  default, options)
            else:
                answer = default


        if answer == 'y':
            logger.info('start updating code')
            fail = 0
            for i in range(data['version_nb'], web_version):
                try:
                    filetext = urllib.request.urlopen('http://madgraph.phys.ucl.ac.be/patch/build%s.patch' %(i+1))
                except Exception:
                    print('fail to load patch to build #%s' % (i+1))
                    fail = i
                    break
                need_binary = apply_patch(filetext)
                if need_binary:
                    path = "https://madgraph.mi.infn.it//binary/binary_file%s.tgz" %(i+1)
                    name = "extra_file%i" % (i+1)
                    misc.wget(path, '%s.tgz' % name, cwd=MG5DIR)
                    # Untar the file
                    returncode = misc.call(['tar', '-xzpf', '%s.tgz' % name], cwd=MG5DIR,
                                     stdout=open(os.devnull, 'w'))

            fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
            if not fail:
                fsock.write("version_nb   %s\n" % web_version)
            else:
                fsock.write("version_nb   %s\n" % fail)
            fsock.write("last_check   %s\n" % int(time.time()))
            fsock.close()
            logger.info('Checking current version. (type ctrl-c to bypass the check)')
            subprocess.call([os.path.join('tests','test_manager.py')],
                                                                  cwd=MG5DIR)            
            print('new version installed, please relaunch mg5')
            try:
                misc.atomic_copy(pjoin(MG5DIR, 'Template','LO','Source','.make_opts'),
                                 pjoin(MG5DIR, 'Template','LO','Source','make_opts'))
            except:
                pass
            sys.exit(0)
        elif answer == 'n':
            # prevent for a future check
            fsock = open(os.path.join(MG5DIR,'input','.autoupdate'),'w')
            fsock.write("version_nb   %s\n" % data['version_nb'])
            fsock.write("last_check   %s\n" % int(time.time()))
            fsock.close()
            logger.info('Update bypassed.')
            logger.info('The next check for a new version will be performed in %s days' \
                        % abs(self.options['auto_update']))
            logger.info('In order to change this delay. Enter the command:')
            logger.info('set auto_update X')
            logger.info('Putting X to zero will prevent this check at anytime.')
            logger.info('You can upgrade your version at any time by typing:')
            logger.info('install update')
        else: #answer is on_exit
            #ensure that the test will be done on exit
            #Do not use the set command here!!
            self.options['auto_update'] = -1 * self.options['auto_update']



    def set_configuration(self, config_path=None, final=True):
        """ assign all configuration variable from file
            ./input/mg7_configuration.txt. assign to default if not define """

        if not self.options:
            self.options = dict(self.options_configuration)
            self.options.update(self.options_madgraph)
            self.options.update(self.options_madevent)

        if not config_path:
            config_path = misc.base_config_file()
            if config_path:
                self.set_configuration(config_path, final=False)
            config_path = misc.user_config_file()
            if config_path and os.path.exists(config_path):
                self.set_configuration(config_path, final=False)
            config_path = os.path.relpath(misc.install_config_file(MG5DIR))
            return self.set_configuration(config_path, final)

        if not os.path.exists(config_path):
            files.cp(pjoin(MG5DIR,'input',misc.CONFIG_TEMPLATE_NAME), config_path)
        if madgraph.ReadWrite:
            # user-editable default files: run_card defaults (LO/NLO/mg7) and
            # the launch switch defaults. Each is materialised from its own
            # '.'-prefixed template, and checked on its own: a user who has an
            # old installation carrying only some of them still gets the rest.
            for name in ('default_run_card_lo.dat', 'default_run_card_nlo.dat',
                         'default_run_card_mg7.toml', 'default_switch.txt'):
                target = pjoin(MG5DIR, 'input', name)
                template = pjoin(MG5DIR, 'input', '.%s' % name)
                if not os.path.exists(target) and os.path.exists(template):
                    files.cp(template, target)

        config_file = open(config_path)

        # read the file and extract information
        logger.info('load MG7 configuration from %s ' % config_file.name)
        for line in config_file:
            if '#' in line:
                line = line.split('#',1)[0]
            line = line.replace('\n','').replace('\r\n','')
            try:
                name, value = line.split('=',1)
            except ValueError:
                #misc.sprint('ignore line in mg7_configuration.txt: %s' % line)
                pass
            else:
                name = name.strip()
                value = value.strip()
                if cmd.is_removed_option(name):
                    # an old configuration file: drop the entry rather than
                    # carrying a dead option around in self.options
                    continue
                if name not in ['mg5_path', 'f2py_compiler', 'f2py_compiler_py2','f2py_compiler_py3', 'lhapdf']:
                    self.options[name] = value
                elif hasattr(self, 'set2_%s' % name) and value:
                    func = getattr(self, 'set2_%s' % name)
                    func(value.split())
                if value.lower() == "none" or value=="":
                    self.options[name] = None
        config_file.close()      
        self.options['stdout_level'] = logging.getLogger('madgraph').level
        if not final:
            return self.options # the return is useful for unittest

        # Treat each expected input
        # 1: Pythia8_path and hewrig++ paths
        # try absolute and relative path
        for key in self.options:
            if key in ['pythia8_path', 'hwpp_path', 'thepeg_path', 'hepmc_path',
                       'hepmc3_path', 'madanalysis5_path']:
                if self.options[key] in ['None', None]:
                    self.options[key] = None 
                    continue
                path = self.options[key]
                #this is for pythia8
                if key == 'pythia8_path' and not os.path.isfile(pjoin(MG5DIR, path, 'include', 'Pythia8', 'Pythia.h')):
                    if not os.path.isfile(pjoin(path,  'include', 'Pythia8', 'Pythia.h')):
                        self.options['pythia8_path'] = None
                    else:
                        continue
                #this is for madanalysis5
                if key == 'madanalysis5_path' and not os.path.isfile(pjoin(MG5DIR, path,'bin','ma5')):
                    if not os.path.isfile(pjoin(path,'bin','ma5')):
                        self.options['madanalysis5_path'] = None
                    else:
                        ma5path = pjoin(MG5DIR, path) if os.path.isfile(pjoin(MG5DIR, path)) else path
                        message = misc.is_MA5_compatible_with_this_MG5(ma5path)
                        if not message is None:
                            self.options['madanalysis5_path'] = None
                            logger.warning(message)
                            continue
 
                #this is for hw++
                if key == 'hwpp_path' and not os.path.isfile(pjoin(MG5DIR, path, 'include', 'Herwig++', 'Analysis', 'BasicConsistency.hh')):
                    if not os.path.isfile(pjoin(path, 'include', 'Herwig++', 'Analysis', 'BasicConsistency.hh')):
                        self.options['hwpp_path'] = None
                    else:
                        continue
                # this is for thepeg
                elif key == 'thepeg_path' and not os.path.isfile(pjoin(MG5DIR, path, 'include', 'ThePEG', 'ACDC', 'ACDCGenCell.h')):
                    if not os.path.isfile(pjoin(path, 'include', 'ThePEG', 'ACDC', 'ACDCGenCell.h')):
                        self.options['thepeg_path'] = None
                    else:
                        continue
                # this is for hepmc
                elif key == 'hepmc_path' and not os.path.isfile(pjoin(MG5DIR, path, 'include', 'HepMC', 'HEPEVT_Wrapper.h')):
                    if not os.path.isfile(pjoin(path, 'include', 'HepMC', 'HEPEVT_Wrapper.h')):
                        self.options['hepmc_path'] = None
                    else:
                        continue
                # this is for hepmc3 (hepmc_path being the HepMC2 installation)
                elif key == 'hepmc3_path' and not os.path.isfile(pjoin(MG5DIR, path, 'include', 'HepMC3', 'GenEvent.h')):
                    if not os.path.isfile(pjoin(path, 'include', 'HepMC3', 'GenEvent.h')):
                        self.options['hepmc3_path'] = None
                    else:
                        continue

            elif key in ['golem','samurai']:
                if isinstance(self.options[key],str) and self.options[key].lower() == 'auto':
                    # try to find it automatically on the system                                                                                                                                            
                    program = misc.which_lib('lib%s.a'%key)
                    if program != None:
                        fpath, _ = os.path.split(program)
                        logger.info('Using %s library in %s' % (key,fpath))
                        self.options[key]=fpath
                    else:
                        # Try to look for it locally
                        local_install = { 'golem':'golem95',
                                         'samurai':'samurai'}
                        if os.path.isfile(pjoin(MG5DIR,local_install[key],'lib', 'lib%s.a' % key)):
                            self.options[key]=pjoin(MG5DIR,local_install[key],'lib')
                        else:
                            self.options[key]=None
                    # Make sure that samurai version is recent enough
                    if key=='samurai' and \
                       isinstance(self.options[key],str) and \
                       self.options[key].lower() != 'auto':
                        if os.path.isfile(pjoin(self.options[key],os.pardir,'AUTHORS')):
                            try:
                                version = open(pjoin(self.options[key],os.pardir,
                                                          'VERSION'),'r').read()
                            except IOError:
                                version = None
                            if version is None:
                                self.options[key] = None
                                logger.info('--------')
                                logger.info(
"""The version of 'samurai' automatically detected seems too old to be compatible
with MadGraph7 and it will be turned off. Ask the authors for the latest version if
you want to use samurai. 
If you want to enforce its use as-it-is, then specify directly its library folder
in the MadGraph7 option 'samurai' (instead of leaving it to its default 'auto').""")
                                logger.info('--------')

            elif key.endswith('path'):
                pass
            elif key in ['run_mode', 'auto_update']:
                self.options[key] = int(self.options[key])
            elif key in ['cluster_type','automatic_html_opening']:
                pass
            elif key in ['notification_center']:
                if self.options[key] in ['False', 'True']:
                    self.allow_notification_center = eval(self.options[key])
                    self.options[key] = self.allow_notification_center
            elif key in ['lhapdf_py3', 'lhapdf_py2']:
                if self.options[key] not in [None, 'none', 'None']:
                    # Default: try to set parameter
                    try:
                        self.do_set("%s %s --no_save" % (key, self.options[key]), log=False)
                    except MadGraph5Error as error:
                        print(error)
                        logger.warning("Option %s from config file not understood" \
                                    % key)
                    else:
                        if key in self.options_madgraph:
                            self.history.append('set %s %s' % (key, self.options[key]))
            elif key not in ['text_editor','eps_viewer','use_pigz','web_browser', 'stdout_level',
                             'f2py_compiler', 'f2py_compiler_py2', 'f2py_compiler_py3']:
                # Default: try to set parameter
                try:
                    self.do_set("%s %s --no_save" % (key, self.options[key]), log=False)
                except MadGraph5Error as error:
                    print(error)
                    logger.warning("Option %s from config file not understood" \
                                   % key)
                else:
                    if key in self.options_madgraph:
                        self.history.append('set %s %s' % (key, self.options[key]))

        # Configure the way to open a file:
        launch_ext.open_file.configure(self.options)
        # Configure the way to compress a file:
        misc.configure_gzip(self.options)
        return self.options

    def check_for_export_dir(self, filepath):
        """Check if the file is in a valid export directory and assign it to
        export path if it is"""

        # keep previous if a previous one is defined
        if self._export_dir:
            return

        if os.path.exists(pjoin(os.getcwd(), 'Cards')):
            self._export_dir = os.getcwd()
            return

        path_split = filepath.split(os.path.sep)
        if len(path_split) > 2 and path_split[-2] == 'Cards':
            self._export_dir = os.path.sep.join(path_split[:-2])
            return

    def setup_mg7_environment(self, lhapdf=True):
        """Export what an mg7 run needs from MG5's configuration.

        These used to be built into the environment of the bin/generate_events
        subprocess. Running in process, the same values have to reach the tools
        the run shells out to (the madspace build, the real LHAPDF library used
        by systematics/MadSpin/reweight), and the only channel those have is
        os.environ -- so set it here rather than per child process.

        ``lhapdf=False`` leaves LHAPDF out, for a run without PDFs (the survey
        of a decay).
        """
        # The one-off madspace build picks up a cmake installed through MG5's
        # 'install cmake' from here (heptools_install_dir may point outside
        # MG5DIR).
        heptools_dir = self.options.get('heptools_install_dir')
        if heptools_dir:
            if not os.path.isabs(heptools_dir):
                heptools_dir = pjoin(MG5DIR, heptools_dir)
            os.environ['MADGRAPH_HEPTOOLS_DIR'] = os.path.abspath(heptools_dir)

        if not lhapdf:
            return

        # The resolved LHAPDF location. The launcher resolves it the same way on
        # its own (launch.lhapdf_paths), so this only matters for the real
        # LHAPDF library used by the post-processing tools, which reads
        # LHAPDF_DATA_PATH natively.
        lhapdf = misc.resolve_lhapdf(self.options, root=MG5DIR, create=True)
        search = lhapdf.data_paths or (
            [lhapdf.download_path] if lhapdf.download_path else [])
        if search:
            os.environ['LHAPDF_DATA_PATH'] = os.pathsep.join(search)
        if lhapdf.config:
            os.environ['MADGRAPH_LHAPDF_CONFIG'] = lhapdf.config

    def do_launch(self, line):
        """Main commands: Ask for editing the parameter and then
        Execute the code (madevent/standalone/...)
        """

        #ensure that MG option are not modified by the launch routine
        current_options = dict([(name, self.options[name]) for name in self.options_madgraph])
        start_cwd = os.getcwd()

        args = self.split_arg(line)
        # check argument validity and normalise argument
        (options, args) = _launch_parser.parse_args(args)
        self.check_launch(args, options)
        options = options.__dict__
        # args is now MODE PATH

        if args[0] == 'amcatnlo_fks_sa':
            # the FKS Born building-block check: ExtLauncher.run() first offers
            # to edit the param_card (skipped under -f), then launch_program()
            # builds and runs the lightweight check_fks (honouring --energy /
            # --timings / --nb_run).
            ext_program = launch_ext.FKSSALauncher(self, args[1],
                                            options=self.options, **options)
            ext_program.run()
            os.chdir(start_cwd) #ensure to go to the initial path
            # ensure that MG options are not changed!
            for key, value in current_options.items():
                self.options[key] = value
            return

        if args[0] == 'standalone':
            ext_program = launch_ext.MadMatrixLauncher(self, args[1],
                                                options=self.options, **options)

        elif args[0].startswith('standalone'):
            if os.path.isfile(os.path.join(os.getcwd(),args[1],'Cards',\
              'MadLoopParams.dat')) and not os.path.isfile(os.path.join(\
              os.getcwd(),args[1],'SubProcesses','check_poles.f')):
                ext_program = launch_ext.MadLoopLauncher(self, args[1], \
                                                options=self.options, **options)
            else:
                ext_program = launch_ext.SALauncher(self, args[1], \
                                                options=self.options, **options)
        elif args[0] == 'madevent':
            if options['interactive']:
                if os.path.exists(pjoin(args[1], 'bin','internal', 'launch_plugin.py')):
                    with  misc.TMP_variable(sys, 'path', sys.path + [pjoin(args[1], 'bin', 'internal')]):
                        from importlib import reload
                        try:
                            reload('launch_plugin')
                        except Exception as error:
                            import launch_plugin
                    ME = launch_plugin.MEINTERFACE(me_dir=args[1], options=self.options)
                elif isinstance(self, cmd.CmdShell):
                    ME = madevent_interface.MadEventCmdShell(me_dir=args[1], options=self.options)
                else:
                    ME = madevent_interface.MadEventCmd(me_dir=args[1],options=self.options)
                    ME.pass_in_web_mode()
                stop = self.define_child_cmd_interface(ME)
                return stop

            #check if this is a cross-section
            if not self._generate_info:
                # This relaunch an old run -> need to check if this is a
                # cross-section or a width
                info = open(pjoin(args[1],'SubProcesses','procdef_mg5.dat')).read()
                generate_info = info.split('# Begin PROCESS',1)[1].split('\n')[1]
                generate_info = generate_info.split('#')[0]
            else:
                generate_info = self._generate_info

            if len(generate_info.split('>')[0].strip().split())>1:
                ext_program = launch_ext.MELauncher(args[1], self,
                                shell = isinstance(self, cmd.CmdShell),
                                options=self.options,**options)
            else:
                # This is a width computation
                ext_program = launch_ext.MELauncher(args[1], self, unit='GeV',
                                shell = isinstance(self, cmd.CmdShell),
                                options=self.options,**options)

        elif args[0] == 'pythia8':
            ext_program = launch_ext.Pythia8Launcher( args[1], self, **options)

        elif args[0] == 'aMC@NLO':
            if options['interactive']:
                if isinstance(self, cmd.CmdShell):
                    ME = amcatnlo_run.aMCatNLOCmdShell(me_dir=args[1], options=self.options)
                else:
                    ME = amcatnlo_run.aMCatNLOCmd(me_dir=args[1],options=self.options)
                    ME.pass_in_web_mode()
                # transfer interactive configuration
                config_line = [l for l in self.history if l.strip().startswith('set')
                               and not cmd.is_question_answer(l)]
                for line in config_line:
                    ME.exec_cmd(line)
                stop = self.define_child_cmd_interface(ME)
                return stop
            ext_program = launch_ext.aMCatNLOLauncher( args[1], self,
                                                       shell = isinstance(self, cmd.CmdShell),
                                                        **options)
        elif args[0] == 'mg7':
            me_dir = args[1]
            # An mg7 output runs in this process, exactly like a madevent one:
            # the run interface becomes a child cmd interface, which gives it
            # MG5's inputfile (so the launch question reads the same script and
            # hands back what it does not understand), MG5's error handling and
            # crash_on_error, and the loggers already configured here.
            self.setup_mg7_environment()

            # Install madspace *before* importing the launcher (importing it is
            # what needs madspace). The bootstrap has to be told whether it may
            # take over the terminal: in a subprocess it could read that off
            # sys.argv/sys.stdin, but in process those describe MG5, not the run.
            from madgraph.iolibs.template_files.mg7 import bootstrap as mg7_bootstrap
            mg7_bootstrap.ensure_madspace(
                interactive=bool(self.use_rawinput) and not options['force'],
                jobs=self.options['nb_core'])
            from madgraph.iolibs.template_files.mg7 import launch as mg7_launch

            MG7 = mg7_launch.MG7Cmd(me_dir=me_dir, options=self.options)
            if options['interactive']:
                stop = self.define_child_cmd_interface(MG7)
                return stop

            mother = self

            class ext_program:
                @staticmethod
                def run():
                    child = mother.define_child_cmd_interface(MG7, interface=False)
                    command = 'generate_events'
                    if options['force']:
                        command += ' -f'
                    if options['name']:
                        command += ' --name=%s' % options['name']
                    if options['laststep']:
                        command += ' --laststep=%s' % options['laststep']
                    child.run_cmd(command)
                    child.run_cmd('quit')

        else:
            os.chdir(start_cwd) #ensure to go to the initial path
            raise self.InvalidCmd('%s cannot be run from MG5 interface' % args[0])


        ext_program.run()
        os.chdir(start_cwd) #ensure to go to the initial path
        # ensure that MG options are not changed!
        for key, value in current_options.items():
            self.options[key] = value

    def do_load(self, line):
        """Not in help: Load information from file"""

        args = self.split_arg(line)
        # check argument validity
        self.check_load(args)

        cpu_time1 = time.time()
        if args[0] == 'model':
            self._curr_model = save_load_object.load_from_file(args[1])
            if self._curr_model.get('parameters'):
                # This is a UFO model
                self._model_v4_path = None
            else:
                # This is a v4 model
                self._model_v4_path = import_v4.find_model_path(\
                    self._curr_model.get('name').replace("_v4", ""),
                    self._mgme_dir)

            # Do post-processing of model
            self.process_model()

            #save_model.save_model(args[1], self._curr_model)
            if isinstance(self._curr_model, base_objects.Model):
                cpu_time2 = time.time()
                logger.info("Loaded model from file in %0.3f s" % \
                      (cpu_time2 - cpu_time1))
            else:
                raise self.RWError('Could not load model from file %s' \
                                      % args[1])
        elif args[0] == 'processes':
            amps,proc_defs = save_load_object.load_from_file(args[1])
            if isinstance(amps, diagram_generation.AmplitudeList):
                cpu_time2 = time.time()
                logger.info("Loaded processes from file in %0.3f s" % \
                      (cpu_time2 - cpu_time1))
                if amps:
                    model = amps[0].get('process').get('model')
                    if not model.get('parameters'):
                        # This is a v4 model.  Look for path.
                        self._model_v4_path = import_v4.find_model_path(\
                                   model.get('name').replace("_v4", ""),
                                   self._mgme_dir)
                    else:
                        self._model_v4_path = None
                    # If not exceptions from previous steps, set
                    # _curr_amps and _curr_model
                    self._curr_amps = amps
                    self._curr_model = model
                    self._curr_proc_defs = proc_defs
                    logger.info("Model set from process.")
                    # Do post-processing of model
                    self.process_model()
                self._done_export = None
            else:
                raise self.RWError('Could not load processes from file %s' % args[1])


    def post_install_RunningCoupling(self):

        shutil.move(pjoin(MG5DIR,'RunningCoupling'), pjoin(MG5DIR,'Template', 'Running'))

    # Masses that a generation almost never wants. The light quarks are
    # massless in every flavour scheme customize_model offers, and an electron
    # or a muon mass buys nothing at collider energies. c, b and tau are left
    # out on purpose: a massive b (the 4F scheme) or tau is a deliberate and
    # very common choice, and this must not nag about it.
    NEGLECTED_MASSES = [1, 2, 3, 11, 13]
    # the model the advice below has already been given for.  MG7 re-imports
    # the model behind the user's back -- 'set gauge', 'set
    # complex_mass_scheme', and 'check gauge' four times over -- and each one
    # comes through do_import, so without this the same paragraph is printed
    # five times for one command.
    _advised_masses_for = None

    def advise_neglected_masses(self):
        """Point at customize_model when the model keeps a light fermion mass.

        A non-zero mass for u, d, s, e or mu costs something in every process
        those particles appear in: the Yukawa vertices they enable bring extra
        diagrams, and the helicity configurations which vanish for a massless
        fermion stop vanishing. At collider energies the mass itself is
        negligible, so that is a price paid for nothing, and no restriction has
        to ship with the model for the user to drop it: the flavour and lepton
        mass schemes are generic options of customize_model.

        Said once per model: every re-import of the same one is MG7 rebuilding
        it for a gauge or a scheme, and repeating the paragraph there is noise.

        Informative only. A model may well mean those masses -- a low-energy
        process, a Yukawa-sensitive one -- so this says what is there and what
        can be done about it, and decides nothing.
        """

        model = self._curr_model
        if not model:
            return
        try:
            # said once per model: a re-import of the one in front of the user
            # is MG7 rebuilding it, not a new model to comment on
            identity = (model.get('name'), model.get('modelpath'))
        except Exception:
            identity = None
        if identity is not None and identity == self._advised_masses_for:
            return
        self._advised_masses_for = identity

        try:
            massive = [pdg for pdg in self.NEGLECTED_MASSES
                       if build_restrict_lib.is_massive(model, pdg)
                       and build_restrict_lib.can_be_massive(model, pdg)]
        except Exception:
            # an informative message is never a reason to fail an import
            return
        if not massive:
            return

        names = ', '.join(build_restrict_lib.PARTICLE_NAME[pdg]
                          for pdg in massive)
        options = []
        if any(pdg in build_restrict_lib.LIGHT_QUARKS for pdg in massive):
            options.append("'flavour scheme'")
        if any(pdg in build_restrict_lib.LEPTONS for pdg in massive):
            options.append("'nb of massive leptons'")
        logger.info("This model keeps a non-zero mass for %s. Such a mass is "
            "negligible at collider energies but not free: it brings in the "
            "Yukawa vertices of those particles and the helicity "
            "configurations which would otherwise vanish, in every process "
            "they appear in.\n  'customize_model' sets them to zero (option%s "
            "%s), and 'customize_model --save=NAME' keeps the result as a "
            "restriction you can import later.",
            names, '' if len(options) == 1 else 's', ' and '.join(options))

    def get_customize_categories(self, model, reference_model):
        """the list of the options proposed by customize_model for a given
        model: the generic (model independent) ones and, on top of them, the
        ones defined in the build_restrict.py of the model (if any).
        model is the model without any restriction, reference_model is the
        model as currently loaded (it only defines the default of the options)
        """

        categories = build_restrict_lib.get_generic_categories(model,
                                                               reference_model)
        # the (block, lhacode) already handled by the generic options
        generic_target = set()
        for category in categories:
            for option in category:
                generic_target.update(build_restrict_lib.get_rules_target(option))

        model_path = model.get('modelpath')
        if not os.path.exists(pjoin(model_path, 'build_restrict.py')):
            return categories

        ufo_model = ufomodels.load_model(model_path)
        if not hasattr(ufo_model, 'build_restrict'):
            return categories

        externals = self.get_external_lhacode(model)
        # the categories of the model are module level objects: without a copy
        # the status set during a previous (possibly aborted) customize_model
        # would be the starting point of this one
        for category in copy.deepcopy(ufo_model.build_restrict.all_categories):
            kept = build_restrict_lib.Category(category.name)
            superseded, obsolete = [], []
            for option in self.group_options(category):
                target = set()
                for rule in option:
                    target.update(build_restrict_lib.get_rules_target(rule))
                # An option of the model can target a parameter which is now
                # handled by one of the generic options. Keeping both would let
                # the user set contradictory values, so the model one is dropped.
                if target & generic_target:
                    superseded.append(option[0].name)
                elif not (target & externals):
                    # the parameters of that option are not in the model anymore
                    obsolete.append(option[0].name)
                else:
                    kept += option
            for message, options in [('superseded by the generic mass scheme options',
                                      superseded),
                                     ('not based on parameters of this model',
                                      obsolete)]:
                if options:
                    logger.debug('customize_model: option(s) of the %s model '
                                 'dropped (%s): %s', model.get('name'), message,
                                 ', '.join(options))
            if kept:
                categories.append(kept)

        return categories

    @staticmethod
    def group_options(category):
        """a Category is a flat list of rules, the ones of a given option being
        introduced by the rule with first=True. Return the list of options,
        each of them being the list of its rules."""

        options = []
        for rule in category:
            if rule.first or not options:
                options.append([])
            options[-1].append(rule)
        return options

    @staticmethod
    def get_loaded_restriction_card(model):
        """The restriction card `model` was loaded with, parsed -- None when it
        was loaded without one, or the card is not on disk anymore."""

        card = getattr(model, 'restrict_card', None)
        if isinstance(card, check_param_card.ParamCard):
            return card
        if isinstance(card, str) and os.path.isfile(card):
            try:
                return check_param_card.ParamCard(card)
            except Exception:
                return None
        return None

    @staticmethod
    def get_reference_name(model):
        """how to name, in a message, the restriction a model was loaded with"""

        card = getattr(model, 'restrict_card', None)
        if isinstance(card, str) and os.path.isfile(card):
            return os.path.basename(card)
        return 'the restriction of %s' % model.get('name')

    def get_loaded_default_card(self, full_model, reference_model, externals):
        """The values the customized model starts from: the ones of the model
        as it was loaded, so that the inputs of the restriction it was imported
        with ('sm-ckm') are propagated.

        A parameter that restriction had fixed has no value worth propagating
        -- it was set to zero/one or merged with another one -- so it recovers
        the value of the UFO. Return the card and those parameters."""

        default_card = self.get_full_param_card(full_model) # the UFO values
        if reference_model is None:
            return default_card, []

        kept = self.get_external_lhacode(reference_model)
        loaded = self.get_full_param_card(reference_model)
        # an SLHA2 restriction keeps the parameters it fixed in the param_card,
        # so 'not external anymore' does not catch them: the ones sitting at
        # zero/one, or sharing the value of another one, were fixed as well
        dropped, merged = self.get_parameter_classes(loaded, kept)
        fixed = dropped | merged

        recovered = []
        for block in default_card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            for param in default_card[block]:
                key = (block.lower(), tuple(param.lhacode))
                if key not in externals:
                    continue # an informative entry, not a parameter
                if key not in kept or key in fixed:
                    recovered.append(key) # fixed at load time: keep the UFO one
                    continue
                value = loaded.get_value(block, tuple(param.lhacode),
                                         default='__not_set__')
                if value != '__not_set__':
                    param.value = value

        return default_card, recovered

    def build_default_card(self, full_model, baseline, ask_instance):
        """the values of the parameters of the customized model, once the
        'set default' commands are taken into account"""

        if ask_instance.default_source == 'ufo':
            param_card = self.get_full_param_card(full_model)
        else:
            param_card = check_param_card.ParamCard(baseline)
            source = ask_instance.default_card_values
            if source is not None:
                for block in param_card:
                    if block.startswith(('qnumbers', 'decay_table')) \
                                                        or 'info' in block:
                        continue
                    for param in param_card[block]:
                        value = source.get_value(block, tuple(param.lhacode),
                                                 default='__not_set__')
                        if value != '__not_set__':
                            param.value = value

        for (lhablock, lhacode), value in ask_instance.default_values.items():
            try:
                param_card[lhablock.lower()].get(list(lhacode)).value = value
            except (KeyError, IndexError):
                logger.warning('%s %s is not in the param_card of the model '
                               'anymore: its default value is ignored.',
                               lhablock, list(lhacode))
        return param_card

    def warn_recovered_defaults(self, recovered, restricted, param_card,
                                        model_path, reference, ask_instance):
        """say which parameters could not take the value of the model as it was
        loaded, because the restriction it came with had fixed them"""

        # the ones the user gave a value to did not fall back on anything
        given = set((lhablock.lower(), lhacode)
                    for lhablock, lhacode in ask_instance.default_values)
        source = ask_instance.default_card_values
        if source is not None:
            given.update(key for key in recovered
                         if source.get_value(key[0], key[1],
                                             default='__not_set__') != '__not_set__')

        lha2name = self.get_lha2name(model_path)
        back = [key for key in recovered
                if key not in restricted and key not in given
                and param_card.has_param(key[0], list(key[1]))]
        if not back:
            return
        them = 'it' if len(back) == 1 else 'them'
        # an SLHA2 restriction fixes dozens of them, so the list is truncated
        logger.warning('%s: value taken from the UFO model, since %s had fixed '
            '%s and the model you loaded therefore carries no value for %s. '
            '\'set default\' can give another one.',
            self.short_list([self.name_of_lha(lha2name, key) for key in back]),
            reference, them, them)

    @staticmethod
    def get_full_param_card(model):
        """the param_card of a model, with the default value of every parameter"""

        out_path = io.StringIO()
        param_writer.ParamCardWriter(model, out_path)
        return check_param_card.ParamCard(out_path.getvalue().split('\n'))

    @staticmethod
    def get_external_lhacode(model):
        """the (lhablock, lhacode) of all the external parameters of a model"""

        return set((param.lhablock.lower(), tuple(param.lhacode))
                   for param in model['parameters'][('external',)])

    @staticmethod
    def randomize_param_card(param_card, externals):
        """Replace the values of the card which are 0, 1 or identical to another
        one by a random value: those values would otherwise be simplified by
        the restriction machinery while the user did not ask for it.
        0 and 1 are replaced by a random value in ]0,1[, a duplicated value v
        by a random value in ]v,2v[ (the order of magnitude of a parameter is
        physical: replacing MZ by 0.3 does break most of the models).
        Two kind of parameters are left untouched: the zero widths (giving a
        width to a particle which does not have one is not physical and changes
        the model) and the technical parameters of the 'loop' block (MU_R, ...).
        externals restricts this to the parameters which are really read from
        the card (a param_card also contains informative entries)."""

        used = {} # per block: two parameters are only merged inside a block
        for block in param_card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            if block.lower() == 'loop':
                continue
            used.setdefault(block.lower(), set())
            for param in param_card[block]:
                if (block.lower(), tuple(param.lhacode)) not in externals:
                    continue
                try:
                    value = float(param.value)
                except (TypeError, ValueError):
                    continue # 'auto' width and co.
                if value == 0. and block.lower() == 'decay':
                    continue
                seen = used[block.lower()]
                if value in (0., 1.) or abs(value) in seen:
                    while True:
                        if value in (0., 1.):
                            new_value = random.random()
                        else:
                            new_value = value * (1 + random.random())
                        if new_value not in (0., 1.) and abs(new_value) not in seen:
                            break
                    value = new_value
                    param.value = value
                seen.add(abs(value))

    @staticmethod
    def resolve_set_equal(set_equal):
        """'set_equal A B' followed by 'set_equal B C' means that A, B and C all
        take the value of C. Applying the pairs in the order they were typed
        would instead give A the value B had before it was itself re-pointed,
        so each pair is first resolved to the root of its chain."""

        link = dict(set_equal)
        out = []
        for target, source in set_equal:
            root, seen = source, set([target])
            while root in link and root not in seen:
                seen.add(root)
                root = link[root]
            if root == target:
                # a cycle ('set_equal A B' + 'set_equal B A'): any member of the
                # cycle is a valid root, keep the one the user gave
                root = source
            out.append((target, root))
        return out

    @staticmethod
    def apply_customize_rules(param_card, categories, set_zero, set_one,
                                                                     set_equal):
        """write in param_card the restrictions asked by the user.
        categories are the (toggled) options of the question, set_zero/set_one
        are lists of (lhablock, lhacode) and set_equal a list of
        ((lhablock, lhacode), (lhablock, lhacode)) where the first parameter
        is forced to the value of the second one."""

        def get_param(lhablock, lhacode, loglevel=logging.WARNING):
            try:
                return param_card[lhablock.lower()].get(list(lhacode))
            except (KeyError, IndexError):
                logger.log(loglevel, '%s %s is not a parameter of this model. '
                           'Corresponding restriction is ignored.',
                           lhablock, list(lhacode))
                return None

        restricted = set()
        for category in categories:
            for option in category:
                for (lhablock, lhacode, value) in option.get_rules():
                    # an option of the model can be partially obsolete
                    param = get_param(lhablock, lhacode, logging.DEBUG)
                    if param is not None:
                        param.value = value
                        restricted.add((lhablock.lower(), tuple(lhacode)))

        for value, entries in [(0., set_zero), (1., set_one)]:
            for (lhablock, lhacode) in entries:
                param = get_param(lhablock, lhacode)
                if param is not None:
                    param.value = value
                    restricted.add((lhablock.lower(), tuple(lhacode)))

        # done last so that 'set_equal A B' where B is itself restricted does
        # propagate the restricted value to A
        for (lhablock, lhacode), (lhablock2, lhacode2) in set_equal:
            target = get_param(lhablock, lhacode)
            source = get_param(lhablock2, lhacode2)
            if target is not None and source is not None:
                target.value = source.value
                restricted.add((lhablock.lower(), tuple(lhacode)))

        return restricted

    @staticmethod
    def get_restriction_signature(model):
        """A summary of everything that the restriction of a model did remove
        or merge. Two restrictions done with different (random) input values
        have to return the same signature."""

        # the flavour grouped couplings are named with a counter which is not
        # reset between two imports: those names carry no information here
        clean = lambda text: re.sub(r'\bFLV_\d+\b', 'FLV', str(text))

        interactions = []
        for vertex in model.get('interactions'):
            interactions.append((
                tuple(sorted(p.get('pdg_code') for p in vertex.get('particles'))),
                tuple(sorted(str(lor) for lor in vertex.get('lorentz'))),
                tuple(sorted(clean('%s:%s' % (key, value))
                             for key, value in vertex.get('couplings').items()))))

        couplings = [clean(coup.name) for value in model.get('couplings').values()
                                                          for coup in value]
        externals = ['%s %s' % (param.lhablock.lower(), list(param.lhacode))
                     for param in model['parameters'][('external',)]]
        particles = ['%s %s %s' % (p.get('pdg_code'), p.get('mass'), p.get('width'))
                     for p in model.get('particles')]

        return {'interactions': sorted(interactions),
                'couplings': sorted(couplings),
                'external parameters': sorted(externals),
                'masses/widths': sorted(particles)}

    def build_restricted_model(self, model_path, param_card, externals,
                                categories, set_zero, set_one, set_equal):
        """apply one full restriction of the model. The input values which
        would be simplified by accident are randomized first.
        return the restricted model, the associated restriction card and the
        set of the (lhablock, lhacode) really restricted."""

        restrict_card = check_param_card.ParamCard(param_card)
        self.randomize_param_card(restrict_card, externals)
        restricted = self.apply_customize_rules(restrict_card, categories,
                                                set_zero, set_one, set_equal)

        # the restriction is applied by import_model (and not directly by
        # RestrictModel) so that the model is the very same -flavour grouping
        # included- as the one obtained by 'import model NAME-restriction'
        tmp_dir = tempfile.mkdtemp()
        try:
            restrict_path = pjoin(tmp_dir, 'restrict_customize.dat')
            restrict_card.write(restrict_path)
            model = import_ufo.import_model(model_path, restrict=restrict_path)
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

        return model, restrict_card, restricted

    def get_default_param_card(self, model, default_card, restricted,
                                                               set_equal=()):
        """the param_card of the (restricted) model where all the parameters
        which were not restricted by the user are set back to the default value
        of the model."""

        out_path = io.StringIO()
        param_writer.ParamCardWriter(model, out_path)
        param_card = check_param_card.ParamCard(out_path.getvalue().split('\n'))

        for block in param_card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            for param in param_card[block]:
                if (block.lower(), tuple(param.lhacode)) in restricted:
                    continue # the user asked for that value: keep it
                value = default_card.get_value(block, tuple(param.lhacode),
                                               default='__not_found__')
                if value != '__not_found__':
                    param.value = value

        # a parameter identified to another one has to follow it, including
        # when the value of that one was restored above
        for (lhablock, lhacode), (lhablock2, lhacode2) in set_equal:
            try:
                target = param_card[lhablock.lower()].get(list(lhacode))
                source = param_card[lhablock2.lower()].get(list(lhacode2))
            except (KeyError, IndexError):
                continue # merged by the restriction (or removed from the model)
            target.value = source.value

        return param_card

    #===========================================================================
    # customize_model --explain: which choice removed which coupling
    #===========================================================================
    def get_restriction_groups(self, categories, set_zero, set_one, set_equal,
                                                                      lha2name):
        """the user choices, as (label, set of (lhablock, lhacode)) pairs. Those
        are the units the removal of a coupling is attributed to."""

        def name(key):
            return self.name_of_lha(lha2name, key)

        groups = []
        for category in categories:
            for option in self.group_options(category):
                keys = set()
                for rule in option:
                    keys.update((lhablock.lower(), tuple(lhacode))
                        for lhablock, lhacode, value in rule.get_rules())
                if not keys:
                    continue # option not selected
                label = option[0].name
                if isinstance(option[0], build_restrict_lib.ChoiceOption):
                    label = '%s = %s' % (label, option[0].status)
                groups.append((label, keys))

        for command, entries in [('set_zero', set_zero), ('set_one', set_one)]:
            for key in entries:
                key = (key[0].lower(), tuple(key[1]))
                groups.append(('%s %s' % (command, name(key)), set([key])))
        for target, source in set_equal:
            target = (target[0].lower(), tuple(target[1]))
            groups.append(('set_equal %s %s' % (name(target),
                       name((source[0].lower(), tuple(source[1])))), set([target])))

        return groups

    @staticmethod
    def get_parameter_classes(param_card, externals):
        """what the restriction does to the param_card itself for those values:
        (the external parameters it turns internal because they are 0 or 1, the
        ones it fuses because they share the value of another one of the same
        block). Mirrors detect_special_parameters/detect_identical_parameters."""

        dropped, by_value = set(), {}
        for block in param_card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            for param in param_card[block]:
                key = (block.lower(), tuple(param.lhacode))
                if key not in externals:
                    continue
                try:
                    value = float(param.value)
                except (TypeError, ValueError):
                    continue
                if value in (0., 1.):
                    dropped.add(key)
                elif block.lower() != 'decay': # widths are never fused
                    by_value.setdefault((block.lower(), abs(value)), []).append(key)

        fused = set()
        for keys in by_value.values():
            if len(keys) > 1:
                fused.update(keys)
        return dropped, fused

    @staticmethod
    def get_coupling_classes(model, param_card):
        """evaluate all the couplings for the values of param_card and return
        (the ones the restriction would drop, the ones it would fuse with at
        least one other). Same thresholds/rounding as detect_identical_couplings
        so that the report matches what the restriction really does."""

        def rounded(value):
            out = []
            for part in (value.real, value.imag):
                if part:
                    part = round(part,
                        int(abs(round(math.log(abs(part), 10), 0)) + 10))
                out.append(part)
            return tuple(out)

        model.set_parameters_and_couplings(check_param_card.ParamCard(param_card))
        zero, by_value = set(), {}
        for name, value in model.get('coupling_dict').items():
            value = complex(value)
            if abs(value) < 1e-13:
                zero.add(name)
            else:
                by_value.setdefault(rounded(value), []).append(name)

        fused = set()
        for names in by_value.values():
            if len(names) > 1:
                fused.update(names)
        return zero, fused

    @staticmethod
    def get_interaction_impact(model, couplings):
        """(removed, modified) number of interactions if couplings are zero"""

        removed, modified = 0, 0
        for vertex in model.get('interactions'):
            names = set()
            for value in vertex.get('couplings').values():
                if isinstance(value, base_objects.FLV_Coupling):
                    values = list(value.get('flavors').values())
                else:
                    values = [value]
                names.update(v[1:] if v.startswith('-') else v for v in values)
            if not names:
                continue
            if names.issubset(couplings):
                removed += 1
            elif names & couplings:
                modified += 1
        return removed, modified

    def explain_restriction(self, model_path, externals, groups, unrestricted,
                                    restricted, base=None, full=False):
        """Report what each of the user choices does to the couplings of the
        model: which ones it drops and which ones it fuses with another.

        For each choice the couplings are evaluated with that choice -and only
        that one- applied, so a coupling can legitimately have several causes
        (in the sm 'yb*conjugate(CKM1x3)' is dropped by the 5F scheme as well as
        by the diagonal CKM). Nothing is removed or changed here: this only
        reads values, so the report can not alter the resulting model."""

        # done before the header so that the (noisy) log of the model import
        # does not land in the middle of the report
        if base is None:
            base = model_reader.ModelReader(
                        import_ufo.import_model(model_path, restrict=False))
        self.log_report_banner('Restriction report: analysing %d restriction(s),'
                               ' one evaluation of the couplings each'
                               % len(groups))

        # what is already zero/fused without any restriction is a property of
        # the model, not something the user did
        base_zero, base_fused = self.get_coupling_classes(base, unrestricted)
        all_zero, all_fused = self.get_coupling_classes(base, restricted)
        all_zero -= base_zero
        all_fused -= base_fused
        base_pdrop, base_pfuse = self.get_parameter_classes(unrestricted, externals)
        logger.info('  in total: %d coupling(s) dropped, %d fused (%d and %d are'
                    ' already so in the unrestricted model)' % (len(all_zero),
                    len(all_fused), len(base_zero), len(base_fused)),
                    '$MG:color:GREEN')

        # what each choice does on its own. Reported as it is computed: on a
        # large model each of those is a full evaluation of the couplings.
        alone = []
        for label, keys in groups:
            probe = check_param_card.ParamCard(unrestricted)
            for (lhablock, lhacode) in keys:
                try:
                    probe[lhablock].get(list(lhacode)).value = \
                            restricted[lhablock].get(list(lhacode)).value
                except (KeyError, IndexError):
                    continue
            zero, fused = self.get_coupling_classes(base, probe)
            pdrop, pfuse = self.get_parameter_classes(probe, externals)
            alone.append((label, zero - base_zero, fused - base_fused,
                          (pdrop - base_pdrop) | (pfuse - base_pfuse)))
            self.log_restriction_group(base, alone[-1], full)

        # the cross-choice information is only available once they all ran
        # how many of the restrictions cover each coupling. Counting (instead
        # of intersecting every pair) keeps this linear on a card which has
        # hundreds of restrictions, and does not confuse two groups which
        # happen to have the same label
        explained, covered_by = set(), {}
        for label, zero, fused, params in alone:
            entries = zero | fused
            explained |= entries
            for name in entries:
                covered_by[name] = covered_by.get(name, 0) + 1
        shared = set(name for name, nb in covered_by.items() if nb > 1)
        conjunction = (all_zero | all_fused) - explained

        nb = None if full else 8
        if shared:
            logger.info('  %d coupling(s) are covered by more than one '
                        'restriction: %s' % (len(shared),
                        self.short_list(shared, nb)), '$MG:color:BLUE')
        if conjunction:
            logger.info('  %d coupling(s) only through several of them at once:'
                        ' %s' % (len(conjunction),
                        self.short_list(conjunction, nb)), '$MG:color:BLUE')
        self.log_report_banner()

        return alone, (base_zero, base_fused), conjunction

    REPORT_WIDTH = 78

    @classmethod
    def log_report_banner(cls, text=None):
        """a separator -and optionally a title- around a restriction report.
        Those reports are printed in the middle of the (verbose) log of a model
        import, so they need to stand out."""

        logger.info('=' * cls.REPORT_WIDTH, '$MG:color:GREEN')
        if text is not None:
            logger.info(' %s' % text, '$MG:color:GREEN')
            logger.info('=' * cls.REPORT_WIDTH, '$MG:color:GREEN')

    def log_restriction_group(self, model, entry, full=False):
        """the part of the --explain report which concerns a single choice"""

        label, zero, fused, params = entry
        if not zero and not fused and not params:
            logger.info('  %-38s changes nothing' % label, '$MG:color:BLACK')
            return
        nb_removed, nb_modified = self.get_interaction_impact(model, zero)
        logger.info('  %-38s %d coupling(s) dropped, %d fused, %d '
                    'interaction(s) removed%s' % (label, len(zero), len(fused),
                    nb_removed,
                    ', %d modified' % nb_modified if nb_modified else ''),
                    '$MG:BOLD')
        indent = '  %-38s   ' % ''
        if zero:
            self.log_names(indent, 'dropped:', zero, full)
        if fused:
            self.log_names(indent, 'fused:  ', fused, full)
        if params:
            logger.info('  %-38s   %d parameter(s) restricted (set to 0/1 '
                        'or merged)', '', len(params))

    @staticmethod
    def short_list(names, nb=8):
        """a readable list of names, truncated after nb of them (nb=None to
        keep them all)"""

        names = sorted(names, key=natural_key)
        if nb is None or len(names) <= nb:
            return ', '.join(names)
        return '%s, ... (%d more)' % (', '.join(names[:nb]), len(names) - nb)

    @staticmethod
    def wrap_list(names, width=64):
        """the names, cut into lines of at most width characters"""

        lines, current, length = [], [], 0
        for name in sorted(names, key=natural_key):
            if current and length + len(name) + 2 > width:
                lines.append(', '.join(current))
                current, length = [], 0
            current.append(name)
            length += len(name) + 2
        if current:
            lines.append(', '.join(current))
        return lines or ['']

    def log_names(self, indent, title, names, full):
        """'title: a, b, c', on several lines when they are all wanted"""

        if not full:
            logger.info('%s%s %s', indent, title, self.short_list(names))
            return
        lines = self.wrap_list(names)
        logger.info('%s%s %s', indent, title, lines[0])
        for line in lines[1:]:
            logger.info('%s%s %s', indent, ' ' * len(title), line)

    @staticmethod
    def get_lha2name(model_path):
        """(lhablock in lower case, lhacode) -> the name of the parameter as
        the UFO -and so the user- spells it (no 'mdl_' prefix). The block is
        lowered because a UFO spells it as it likes ('Wolfenstein' in the sm)."""

        ufo_model = ufomodels.load_model(model_path)
        return dict(((param.lhablock.lower(), tuple(param.lhacode)), param.name)
                    for param in ufo_model.all_parameters
                    if param.nature == 'external')

    @staticmethod
    def name_of_lha(lha2name, key):
        """the name of a (lhablock, lhacode), whatever the case of the block"""

        return lha2name.get((key[0].lower(), tuple(key[1])), None) or \
               '%s %s' % (key[0], list(key[1]))

    @staticmethod
    def get_card_restriction_groups(param_card, externals, lha2name=None):
        """the restrictions a param_card contains, as the (label, keys) groups
        a report attributes a removal to: the parameters it sets to zero or to
        one, and the families which share a value inside a block."""

        lha2name = lha2name or {}

        def name(key):
            return MadGraphCmd.name_of_lha(lha2name, key)

        groups, by_value = [], {}
        for block in param_card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            for param in param_card[block]:
                key = (block.lower(), tuple(param.lhacode))
                if key not in externals:
                    continue
                try:
                    value = float(param.value)
                except (TypeError, ValueError):
                    continue
                if value in (0., 1.):
                    groups.append(('%s = %d' % (name(key), value), set([key])))
                elif block.lower() != 'decay': # widths are never fused
                    by_value.setdefault((block.lower(), abs(value)), []).append(key)

        for value in sorted(by_value):
            keys = by_value[value]
            if len(keys) > 1:
                groups.append((' = '.join(name(key) for key in keys), set(keys)))
        return groups

    def do_explain_restriction(self, line):
        """explain what a restriction card removes from a model"""

        args = self.split_arg(line)
        self.check_explain_restriction(args)
        full = '--all' in args
        args = [arg for arg in args if arg != '--all']

        model_path, restrict_file = self.get_restriction_to_explain(args)
        logger.info('Explaining %s on the model %s', os.path.basename(restrict_file),
                    os.path.basename(model_path.rstrip('/')))

        model = import_ufo.import_model(model_path, restrict=False)
        externals = self.get_external_lhacode(model)
        default_card = self.get_full_param_card(model)

        restricted = check_param_card.ParamCard(restrict_file)
        groups = self.get_card_restriction_groups(restricted, externals,
                                            self.get_lha2name(model_path))
        if not groups:
            logger.info('%s does not restrict anything in this model.',
                        os.path.basename(restrict_file))
            return

        # everything the card does not restrict has to come from the model, so
        # the reference is the default values, with the ones which would be
        # simplified by accident randomized (as customize_model does)
        unrestricted = check_param_card.ParamCard(default_card)
        self.randomize_param_card(unrestricted, externals)

        self.explain_restriction(model_path, externals, groups, unrestricted,
                                 restricted, full=full)

    def get_restriction_to_explain(self, args):
        """(model path, restriction card) of an 'explain_restriction' argument:
        a card, a 'model-restriction' name, or nothing for the current model"""

        if not args:
            model = self._curr_model
            # RestrictModel keeps it as an attribute, not as a key
            restrict_file = getattr(model, 'restrict_card', None)
            if not isinstance(restrict_file, str):
                raise self.InvalidCmd('The current model is not restricted by '
                    'a card. Give one (or a model name like sm-ckm) to explain.')
            if not os.path.isfile(restrict_file):
                raise self.InvalidCmd('The card the current model was built '
                    'from (%s) is not on disk anymore. Give the path of a card '
                    '(or a model name like sm-ckm) to explain.' % restrict_file)
            return model.get('modelpath'), restrict_file

        if os.path.isfile(args[0]):
            if not self._curr_model:
                raise self.InvalidCmd('Import a model before explaining one of '
                                      'its restriction cards.')
            return self._curr_model.get('modelpath'), args[0]

        try:
            model_path, restrict_file, restrict_name = \
                                        import_ufo.get_path_restrict(args[0])
        except Exception as error:
            raise self.InvalidCmd('%s is neither a restriction card nor a model'
                                  ' name: %s' % (args[0], error))
        if not restrict_file:
            raise self.InvalidCmd('%s does not select any restriction card.'
                                  % args[0])
        return model_path, restrict_file

    def do_customize_model(self, line):
        """create a restriction card in a interactive way"""

        args = self.split_arg(line)
        self.check_customize_model(args)

        name = ([a.split('=', 1)[1] for a in args if a.startswith('--save=')]
                                                                      + [None])[0]
        explain = resolve_explain_mode(args)
        full = '--all' in args
        model_path = self._curr_model.get('modelpath')
        # the model as currently loaded: only used to know which of the generic
        # options are already applied (it defines their default value)
        reference_model = self._curr_model

        try:
            self.customize_model(model_path, reference_model, name, explain,
                                 full)
        except Exception:
            # do not leave the interface with the unrestricted model
            self._curr_model = reference_model
            raise

    def customize_model(self, model_path, reference_model, name, explain=None,
                                                                   full=False):
        """the body of do_customize_model. model_path is the model to
        customize, reference_model the model as currently loaded and name the
        name of the restriction to save (None to only modify the model in
        memory). explain is 'life' to report what each command changes while
        the question is answered, 'final' to report which choice is responsible
        for what once it is closed, None for no report at all."""

        # (re)import the full model (get rid of the default restriction)
        self._curr_model = import_ufo.import_model(model_path, restrict=False)
        categories = self.get_customize_categories(self._curr_model,
                                                   reference_model)

        # the values the customized model starts from, before any 'set default'
        externals = self.get_external_lhacode(self._curr_model)
        baseline, recovered = self.get_loaded_default_card(self._curr_model,
                                                    reference_model, externals)

        explainer = None
        if explain == 'life':
            explainer = RestrictionExplainer(self, model_path, baseline,
                                             externals, categories)

        # the question starts from the restriction the model was loaded with:
        # without it, what that restriction had fixed -- zeros, ones, merged
        # parameters -- came back at its UFO value, so customizing
        # SMEFTatNLO-NLO silently switched operators, masses and widths back on
        ask_instance = self.ask('', '0', [], ask_class=AskforCustomize,
                                categories=categories, explainer=explainer,
                                baseline_card=baseline,
                                loaded_card=self.get_loaded_restriction_card(
                                                            reference_model),
                                loaded_name=self.get_reference_name(
                                                            reference_model),
                                return_instance=True)[1]

        set_zero = ask_instance.set_zero
        set_one = ask_instance.set_one
        set_equal = self.resolve_set_equal(ask_instance.set_equal)
        new_formula = ask_instance.new_formula
        new_coupling = ask_instance.new_coupling

        if new_formula or new_coupling:
            # changing a formula can not be done via a restriction card:
            # a new UFO model has to be written on disk
            if name:
                raise self.InvalidCmd(
                    'Modifying a formula is not compatible with the --save option.\n'
                    '  Run \'customize_model\' without --save: you will be asked for\n'
                    '  the name of the new model to create.')
            old_externals = self.get_external_lhacode(self._curr_model)
            model_path = self.create_customized_ufo(model_path, new_formula,
                                                                  new_coupling)
            self._curr_model = import_ufo.import_model(model_path, restrict=False)
            self.warn_rules_lost_by_formula(categories,
                    old_externals - self.get_external_lhacode(self._curr_model))
            # the parameters changed, so the values they start from have to be
            # read again from the model which is now used
            baseline, recovered = self.get_loaded_default_card(self._curr_model,
                    reference_model, self.get_external_lhacode(self._curr_model))

        # the values of the model, used to restore the non restricted
        # parameters, with what 'set default' asked for on top of them
        externals = self.get_external_lhacode(self._curr_model)
        default_card = self.build_default_card(self._curr_model, baseline,
                                               ask_instance)

        logger.info('Loading the resulting model')
        model, restrict_card, restricted = self.build_restricted_model(
            model_path, default_card, externals, categories, set_zero, set_one,
            set_equal)

        if explain == 'final':
            groups = self.get_restriction_groups(categories, set_zero, set_one,
                                          set_equal, ask_instance.lha2name)
            try:
                unrestricted = check_param_card.ParamCard(default_card)
                self.randomize_param_card(unrestricted, externals)
                restricted = check_param_card.ParamCard(unrestricted)
                self.apply_customize_rules(restricted, categories, set_zero,
                                                        set_one, set_equal)
                self.explain_restriction(model_path, externals, groups,
                        unrestricted, restricted,
                        base=explainer.model if explainer else None, full=full)
            except Exception as error:
                # the report is informative only: never let it break the command
                logger.warning('Could not build the restriction report: %s', error)

        if name:
            # The restriction is driven by the value of the parameters, so a
            # (un)lucky set of random values could remove more -or less- than
            # what the user asked for. Redo it with another set of values and
            # check that we do end up with the very same model.
            logger.info('Checking the stability of the restriction')
            check_model = self.build_restricted_model(model_path, default_card,
                        externals, categories, set_zero, set_one, set_equal)[0]
            signature = self.get_restriction_signature(model)
            check_signature = self.get_restriction_signature(check_model)
            diff = [key for key, value in signature.items()
                    if value != check_signature[key]]
            if diff and madgraph.ADMIN_DEBUG:
                for key in diff:
                    only1 = [v for v in signature[key] if v not in check_signature[key]]
                    only2 = [v for v in check_signature[key] if v not in signature[key]]
                    misc.sprint(key, 'only in run1:', only1[:5])
                    misc.sprint(key, 'only in run2:', only2[:5])
            if diff:
                logger.warning('Two restrictions of the model done with different '
                    'input values do not lead to the same model.\n'
                    '  Difference(s) found for: %s\n'
                    '  This typically means that the model has (hidden) relations '
                    'between its parameters.\n'
                    '  The restriction is therefore NOT applied.', ', '.join(diff))
                raise self.InvalidCmd('customize_model can not be applied to this model.')

        self._curr_model = model
        # the card it was just built from was a temporary file which
        # build_restricted_model has already removed: do not leave the model
        # pointing at it (explain_restriction would read it)
        self._curr_model.restrict_card = None
        # restore the default value of everything the user did not restrict
        param_card = self.get_default_param_card(model, default_card, restricted,
                                                 set_equal)
        self._curr_model.set_parameters_and_couplings(param_card)
        # rewrite it so that the informative entries (dependent parameters) of
        # the card are the ones of the model with its default values
        param_card = self.get_full_param_card(self._curr_model)
        if ask_instance.default_source != 'ufo':
            self.warn_recovered_defaults(recovered, restricted, param_card,
                            model_path, self.get_reference_name(reference_model),
                            ask_instance)
        self.process_model()

        if name:
            restrict_path = pjoin(model_path, 'restrict_%s.dat' % name)
            logger.info('Save restriction file as %s' % restrict_path)
            restrict_card.write(restrict_path)
            param_path = pjoin(model_path, 'param_%s.dat' % name)
            logger.info('Save default card file as %s' % param_path)
            param_card.write(param_path)
            self._curr_model['name'] += '-%s' % name
            # that one does exist, so 'explain_restriction' can read it back
            self._curr_model.restrict_card = restrict_path

    @staticmethod
    def warn_rules_lost_by_formula(categories, lost):
        """A 'formula' command turns an external parameter into an internal
        one, so a restriction pointing at that parameter can not be written in
        the param_card anymore. Those are silently skipped when the card is
        filled, so say here which options are concerned."""

        if not lost:
            return
        affected = set()
        for category in categories:
            for option in category:
                target = set((lhablock.lower(), tuple(lhacode))
                             for lhablock, lhacode, value in option.get_rules())
                if target & lost:
                    affected.add(option.name)
        if affected:
            logger.warning('The following option(s) can not be fully applied '
                'anymore: %s.\n  A \'formula\' command turned one of the '
                'parameters they act on into an internal parameter of the new '
                'model, so that parameter is not in the param_card anymore and '
                'the corresponding restriction is dropped.',
                ', '.join(sorted(affected)))

    def create_customized_ufo(self, model_path, new_formula, new_coupling,
                                                                    name=None):
        """write on disk a new UFO model where the formula of some parameters
        and/or couplings are the one asked by the user. Return the path of the
        new model."""

        import madgraph.models.usermod as usermod

        if not name:
            default = '%s_customized' % os.path.basename(model_path.rstrip('/'))
            name = self.ask('Please enter the name of the new model', default,
                                                  ask_class=AskforModelName)
            name = str(name).strip()
        if not AskforModelName.name_pattern.match(name):
            raise self.InvalidCmd('\'%s\' is not a valid model name '
                '(letters, digits and underscores only).' % name)

        output_dir = pjoin(MG5DIR, 'models', name)
        if os.path.exists(output_dir):
            answer = self.ask('Model %s already exists. Overwrite it?' % name,
                              'n', ['y', 'n'])
            if answer != 'y':
                raise self.InvalidCmd('Model %s already exists.' % name)
            shutil.rmtree(output_dir)

        try:
            base_model = copy.deepcopy(usermod.UFOModel(model_path))
        except Exception:
            base_model_tmp = usermod.UFOModel(model_path)
            with misc.TMP_variable(base_model_tmp, 'model', None):
                base_model = copy.deepcopy(base_model_tmp)
            base_model.model = base_model_tmp.model
            del base_model_tmp

        # the external parameters which become internal have to be removed from
        # the restriction cards shipped with the original model
        removed = []
        for param_name, expr in new_formula:
            for param in base_model.parameters:
                if param.name != param_name:
                    continue
                logger.info('%s is now an internal parameter: %s = %s',
                            param.name, param.name, expr)
                removed.append((param.lhablock.lower(), tuple(param.lhacode)))
                param.nature = 'internal'
                param.value = expr
                del param.lhablock
                del param.lhacode
                break
            else:
                raise self.InvalidCmd('%s is not a parameter of the model' % param_name)

        for coupling_name, expr in new_coupling:
            for coupling in base_model.couplings:
                if coupling.name != coupling_name:
                    continue
                logger.info('%s is redefined as: %s', coupling.name, expr)
                coupling.value = expr
                break
            else:
                raise self.InvalidCmd('%s is not a coupling of the model' % coupling_name)

        base_model.write(output_dir)

        # optional files of the UFO which write() does not propagate but which
        # are needed for the new model to behave like the original one
        for filename in ['build_restrict.py', 'running.py', 'decays.py', 'README']:
            if os.path.exists(pjoin(model_path, filename)):
                files.cp(pjoin(model_path, filename), output_dir)

        # write() only propagates the restrict_XXX.dat, but the associated
        # param_XXX.dat (default values) has to follow them
        for card in os.listdir(model_path):
            if card.startswith('param_') and card.endswith('.dat') and \
                   os.path.exists(pjoin(model_path, card.replace('param_', 'restrict_', 1))):
                files.cp(pjoin(model_path, card), output_dir)

        if removed:
            for card in os.listdir(output_dir):
                if not card.startswith(('restrict_', 'param_')) or \
                                                    not card.endswith('.dat'):
                    continue
                param_card = check_param_card.ParamCard(pjoin(output_dir, card))
                for lhablock, lhacode in removed:
                    if param_card.has_param(lhablock, list(lhacode)):
                        param_card.remove_param(lhablock, list(lhacode))
                # same precision as usermod uses for those cards
                param_card.write(pjoin(output_dir, card), precision=7)

        logger.info('New model created in %s', output_dir)
        return output_dir

    def do_save(self, line, check=True, to_keep={}, log=True):
        """Not in help: Save information to file"""

        
        args = self.split_arg(line)
        # Check argument validity
        if check:
            self.check_save(args)

        if args[0] == 'model':
            if self._curr_model:
                #save_model.save_model(args[1], self._curr_model)
                if save_load_object.save_to_file(args[1], self._curr_model):
                    logger.info('Saved model to file %s' % args[1])
            else:
                raise self.InvalidCmd('No model to save!')
        elif args[0] == 'processes':
            if self._curr_amps:
                if save_load_object.save_to_file(args[1], (self._curr_amps,self._curr_proc_defs) ):
                    logger.info('Saved processes to file %s' % args[1])
            else:
                raise self.InvalidCmd('No processes to save!')

        elif args[0] == 'options':
            partial_save = False
            to_define = {}
            
            if any(not arg.startswith('--') and arg in self.options 
                                                               for arg in args):
                # store in file only those ones
                partial_save = True
                all_arg = [arg for arg in args[1:] if not arg.startswith('--') and
                           arg in self.options]
                for key in all_arg:
                    to_define[key] = self.options[key] 
            else:
                # First look at options which should be put in MG5DIR/input
                for key, default in self.options_configuration.items():
                    if self.options_configuration[key] != self.options[key] and not self.options_configuration[key] is None:
                        to_define[key] = self.options[key]
    
                if not '--auto' in args:
                    for key, default in self.options_madevent.items():
                        if self.options_madevent[key] != self.options[key] != None:
                            if '_path' in key and os.path.basename(self.options[key]) == 'None':
                                continue
                            to_define[key] = self.options[key]
                        elif key in ['cluster_queue', 'cluster_walltime',\
                                     'cluster_requirement', 'cluster_vacatetime']\
                                     and self.options[key] is None:
                            to_define[key] = self.options[key]
    
                if '--all' in args:
                    for key, default in self.options_madgraph.items():
                        if self.options_madgraph[key] != self.options[key] != None and \
                          key != 'stdout_level':
                            to_define[key] = self.options[key]
                elif not '--auto' in args:
                    for key, default in self.options_madgraph.items():
                        if self.options_madgraph[key] != self.options[key] != None and  key != 'stdout_level':
                            logger.info('The option %s is modified [%s] but will not be written in the configuration files.' \
                                        % (key,self.options_madgraph[key]) )
                            logger.info('If you want to make this value the default for future session, you can run \'save options --all\'')

            if len(args) >1 and not args[1].startswith('--') and args[1] not in self.options:
                filepath = args[1]
            else:
                filepath = misc.install_config_file(MG5DIR)

            basedir = MG5DIR
            if partial_save and os.path.exists(filepath):
                basefile = filepath
            else:
                basefile = pjoin(MG5DIR, 'input', misc.CONFIG_TEMPLATE_NAME)
                
            

            if to_keep:
                to_define = to_keep
            self.write_configuration(filepath, basefile, basedir, to_define)

    def help_set2_ignore_six_quark_processes(self):
        logger.info("ignore_six_quark_processes multi_part_label",'$MG:color:GREEN')
        logger.info(" > (default none) ignore processes with at least 6 of any")
        logger.info("   of the quarks given in multi_part_label.")
        logger.info(" > These processes give negligible contribution to the")
        logger.info("   cross section but have subprocesses/channels.")

    def set2_ignore_six_quark_processes(self, args, log=True):
        """Set the list of quarks to ignore processes with six quarks in the
        final state.  The argument is a multiparticle label.
        Example: set ignore_six_quark_processes p
        or: set ignore_six_quark_processes none
        """
        args = ['ignore_six_quark_processes'] + args

        self.check_set(args)

        if args[1].lower() == 'false':
            self.options[args[0]] = False
            return
        self.options[args[0]] = misc.make_unique([abs(p) for p in \
                                    self._multiparticles[args[1]]\
                                    if self._curr_model.get_particle(p).\
                                    is_fermion() and \
                                    self._curr_model.get_particle(abs(p)).\
                                    get('color') == 3])
        if log:
            logger.info('Ignore processes with >= 6 quarks (%s)' % \
                    ",".join([\
                        self._curr_model.get_particle(q).get('name') \
                        for q in self.options[args[0]]]))

    def help_set2_group_subprocesses(self):
        """Help for set group_subprocesses command"""
        logger.info("group_subprocesses True/False/Auto/gpu: ",'$MG:color:GREEN')
        logger.info(" > (default Auto) Smart grouping of subprocesses into ")
        logger.info("   directories, mirroring of initial states, and ")
        logger.info("   combination of integration channels.")
        logger.info(" > Example: p p > j j j w+ gives 5 directories and 184 channels",'$MG:BOLD')
        logger.info("   (cf. 65 directories and 1048 channels for regular output)",'$MG:BOLD')
        logger.info(" > Auto means False for decay computation and True for collisions.")
        logger.info(" > gpu means a single matrix-element type per directory",'$MG:BOLD')

    def set2_group_subprocesses(self, args, log=True):
        """Set the grouping of subprocesses mode. Options are:
           auto: let MG5 decide the best option (default)
              nlo: group subprocesses for NLO computations
              gpu: group subprocesses for GPU computations
              True: group subprocesses for CPU computations
              False: do not group subprocesses (MG4 style)
        """   
        args = ['group_subprocesses'] + args

        self.check_set(args)

        if args[1].lower() not in ['auto', 'nlo', 'gpu']:
            self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, name="group_subprocesses")
        else:
            if args[1].lower() == 'nlo':
                self.options[args[0]] = "NLO"
            elif args[1].lower() == 'gpu':
                self.options[args[0]] = "gpu"
            else:
                self.options[args[0]] = "Auto"
        if log:
            logger.info('Set group_subprocesses to %s' % \
                                                str(self.options[args[0]]))
            logger.info('Note that you need to regenerate all processes')
        self._curr_amps = diagram_generation.AmplitudeList()
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        if self.options[args[0]] == 'gpu':
            export_v4.ProcessExporterFortranMEGroup.grouped_mode = 'gpu'
        else:
            export_v4.ProcessExporterFortranMEGroup.grouped_mode = 'madevent'

        # remove flavor special handling for non grouped case
        if args[1].lower() == 'False':
            self._curr_model.unmerge_flavors()


    def set2_stdout_level(self, args, log=True):
        """Set the level of output information.  Options are:
              DEBUG, INFO, WARNING, ERROR, CRITICAL, 5
        """
        args = ['stdout_level'] + args
        self.check_set(args)
        if args[1].isdigit():
            level = int(args[1])
        else:
            level = eval('logging.' + args[1])
        logging.root.setLevel(level)
        logging.getLogger('madgraph').setLevel(level)
        logging.getLogger('madevent').setLevel(level)
        self.options[args[0]] = level
        if log:
            logger.info('set output information to level: %s' % level)

    def set2_EWscheme(self, args, log=True):
        """Set the electroweak scheme to be used in the model. Options are:
           sm: Standard Model scheme (default)
           external: external scheme where you are responsible of the validity
                        of the input parameters.
        """
        args = ['EWscheme'] + args
        self.check_set(args)

        if args[1] == 'external':
            logger.info("Change EW scheme to %s for the model %s. Note that YOU are responsible of the full validity of the input in that scheme." %\
                                            (self._curr_model.get('name'), args[1]))
        else:
            logger.info("Change EW scheme to %s for the model %s. Note that SM is assume here.")
        logger.info("Importing a new model will restore the default scheme")

        self._curr_model.change_electroweak_mode(args[1])
    set2_ewscheme = set2_EWscheme

    def help_set2_complex_mass_scheme(self):
        """Help for set complex_mass_scheme command"""
        logger.info("complex_mass_scheme True|False",'$MG:color:GREEN')
        logger.info(" > (default False) Set complex mass scheme.")
        logger.info(" > This automatically change the EW scheme of the model to have mass as input parameters.")
        logger.info(" > Complex mass scheme is not yet supported for loop processes.")


    def set2_complex_mass_scheme(self, args, log=True):
        """Activate/Deactivate the complex mass scheme in the model. Options are:
           True: activate the complex mass scheme
           False: deactivate the complex mass scheme
           Can be done either before/after model import.
        """

        args = ['complex_mass_scheme'] + args
        self.check_set(args)

        old = self.options[args[0]]
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, "complex_mass_scheme")
        aloha.complex_mass = self.options[args[0]]
        aloha_lib.KERNEL.clean()
        if self.options[args[0]]:
            if old:
                if log:
                    logger.info('Complex mass already activated.')
                return
            if log:
                logger.info('Activate complex mass scheme.')
        else:
            if not old:
                if log:
                    logger.info('Complex mass already deactivated.')
                return
            if log:
                logger.info('Deactivate complex mass scheme.')
        if not self._curr_model:
            return
        self.do_import("model %s" % self._curr_model.get('name'), options={'allow_qed_cms':True})

    def help_set2_gauge(self):
        """Help for set gauge command"""
        logger.info("gauge unitary|Feynman|axial|FD",'$MG:color:GREEN')
        logger.info(" > (default unitary) choose the gauge of the non QCD part.")
        logger.info(" > axial is also named the parton-shower gauge (for massless particles only).")
        logger.info(" > FD is for Feynman Diagram gauge: (see 2203.10440 and 2405.01256). This is the extension of the axial gauge to massive particles.")
        logger.info(" > For loop processes, only Feynman gauge is employable.")

        

    def set2_gauge(self, args, log=True):
        """Set the gauge to be used in the model. Options are:
              unitary: Unitary gauge
              feynman: Feynman gauge
              axial: Parton-shower gauge
              FD: Four-Dimensional gauge (see 2203.10440 and 2405.01256)
        """
        args = ['gauge'] + args
        self.check_set(args)

        # Treat the case where they are no model loaded
        if not self._curr_model:
            if args[1] == 'unitary':
                aloha.unitary_gauge = True
            elif args[1] == 'axial':
                aloha.unitary_gauge = 2 
            elif args[1] == 'FD':
                aloha.unitary_gauge = 3 
            else:
                aloha.unitary_gauge = False
            aloha_lib.KERNEL.clean()
            self.options[args[0]] = args[1]
            if log: logger.info('Passing to gauge %s.' % args[1])
            return

        # They are a valid model
        able_to_mod = True
        if args[1] == 'unitary':
            if 0 in self._curr_model.get('gauge'):
                aloha.unitary_gauge = True
            else:
                able_to_mod = False
                if log: logger.warning('Note that unitary gauge is not allowed for your current model %s' \
                                        % self._curr_model.get('name'))
        elif args[1] == 'axial':
            if 0 in self._curr_model.get('gauge'):
                aloha.unitary_gauge = 2
            else:
                able_to_mod = False
                if log: logger.warning('Note that parton-shower gauge is not allowed for your current model %s' \
                                        % self._curr_model.get('name'))
        elif args[1] == 'FD':
            logger.warning("WARNING: NOT ALL MODEL ARE SUPPORTING THIS GAUGE. PLEASE CHECK/CITE 2203.10440 and 2405.01256")
            if 1 in self._curr_model.get('gauge'):
                aloha.unitary_gauge = 3
            else:
                able_to_mod = False
                if log: logger.warning('Note that FD gauge is not allowed for your current model %s' \
                                        % self._curr_model.get('name'))   
        else:
            if 1 in self._curr_model.get('gauge'):
                aloha.unitary_gauge = False
            else:
                able_to_mod = False
                if log: logger.warning('Note that Feynman gauge is not allowed for your current model %s' \
                                        % self._curr_model.get('name'))

        self._curr_model._curr_gauge = args[1]
        if self.options['gauge'] == args[1]:
            return
        
        
        self.options[args[0]] = args[1]

        if able_to_mod and log and args[0] == 'gauge' and \
            args[1] == 'unitary' and not self.options['gauge']=='unitary' and \
            isinstance(self._curr_model,loop_base_objects.LoopModel) and \
                not self._curr_model['perturbation_couplings'] in [[],['QCD']]:
            logger.warning('You will only be able to do tree level'+\
                                ' and QCD corrections in the unitary gauge.')



        #re-init all variable
        model_name = self._curr_model.get('modelpath+restriction')
        self._curr_model = None
        self._curr_amps = diagram_generation.AmplitudeList()
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        self._curr_helas_model = None
        self._curr_exporter = None
        self._second_exporter = None
        self._done_export = False
        import_ufo._import_once = []
        if able_to_mod:
            # We don't want to go through the MasterCommand again
            # because it messes with the interface switching when
            # importing a loop model from MG5
            if 'modelname' in self.history.get('full_model_line'):
                opts = '--modelname'
            else:
                opts=''
            MadGraphCmd.do_import(self,'model %s %s' % (model_name, opts), force=True)
        elif log:
            logger.info('Note that you have to reload the model')





    def set2_fortran_compiler(self, args, log=True):
        """Set the fortran compiler to be used in the code generation.
        Example: set fortran_compiler gfortran
        or: set fortran_compiler None
        """

        args = ['fortran_compiler'] + args
        self.check_set(args)

        if args[1] != 'None':
            if log:
                logger.info('set fortran compiler to %s' % args[1])
            self.options['fortran_compiler'] = args[1]
        else:
            self.options['fortran_compiler'] = None

    def set2_default_unset_couplings(self, args, log=True):
        """Set the default value for unset couplings in the model.
        Example: set default_unset_couplings 0
        Default is 99 
        Note that this is used when at least one coupling is defined in the process.
        """
        args = ['default_unset_couplings'] + args
        self.check_set(args)    
        self.options['default_unset_couplings'] = banner_module.ConfigFile.format_variable(args[1], int, name="default_unset_couplings")

    def set2_f2py_compiler(self, args, log=True):
        """Set the f2py compiler to be used in the code generation.
        Example: set f2py_compiler f2py3.10
        trick (for config file): set f2py_compiler f2py3.10 --python=3.10
        only apply the setting if the python version match the current one
        """

        if "--no_save" in args:
            raise Exception 

        args = ['f2py_compiler'] + args
        self.check_set(args)

        if len(args) > 2 and args[2].startswith('--python='):
            py_version = args[2].split('=')[1]
            major_version = int(py_version.split('.')[0])
            minor_version = int(py_version.split('.')[1])
            if major_version != sys.version_info[0] or \
               minor_version != sys.version_info[1]:
               return 
            
        to_do = True
        if args[0].endswith('_py2'):
            to_do = False
        # not supported anymore
        #elif args[0].endswith('_py3') and False:
        #    to_do = False
        if to_do:
            if args[1] != 'None':
                if log:
                    logger.info('set f2py compiler to %s' % args[1])
            
                self.options['f2py_compiler'] = args[1]
            else:
                self.options['f2py_compiler'] = None

    set2_f2py_compiler_py2 = set2_f2py_compiler
    set2_f2py_compiler_py3 = set2_f2py_compiler

    def help_set2_loop_optimized_output(self):
        """Help for set loop_optimized_output command"""
        logger.info("loop_optimized_output True|False",'$MG:color:GREEN')
        logger.info(" > Exploits the open loop thechnique for considerable")
        logger.info("   improvement.")
        logger.info(" > CP relations among helicites are detected and the helicity")
        logger.info("   filter has more potential.")


    def set2_loop_optimized_output(self, args, log=True):
        """This option corresponds to using the polynomial decomposition of the integrand 
        numerator (Eq. 2.6 of 1507.00020), to optimise the use of OPP reduction and allow 
        to interface TIR tools. For debugging and validation purposes it is useful to be 
        able to turn this option off (before generating the loop matrix element code) 
        and to force MadLoop to recompute the complete integrand numerator for each new value 
        of the loop-momentum specified by the OPP reduction procedure.
        """
        args = ['loop_optimized_output'] + args
        self.check_set(args)    


        if log:
                logger.info('set loop optimized output to %s' % args[1])
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        self.options[args[0]] = args[1]
        if not self.options['loop_optimized_output'] and \
                                            self.options['loop_color_flows']:
            logger.warning("Turning off option 'loop_color_flows'"+\
                " since it is not available for non-optimized loop output.")
            self.do_set('loop_color_flows False',log=False)

    def help_set2_nlo_mixed_expansion(self):
        logger.info("nlo_mixed_expansion <value>",'$MG:color:GREEN') 
        logger.info("deactivates mixed expansion support at NLO, goes back to MG5aMCv2 behavior")

    def set2_nlo_mixed_expansion(self, args, log=True):
        """Set the nlo mixed expansion option.
        True is default. False go back to MG5 2.x behavior.
        Example: set nlo_mixed_expansion True
        """
        args = ['nlo_mixed_expansion'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1],bool,args[0])
        
    def help_set2_loop_color_flows(self):
        """Help for set loop_color_flows command"""
        logger.info("loop_color_flows True|False",'$MG:color:GREEN')
        logger.info(" > Only relevant for the loop optimized output.")
        logger.info(" > Reduces the loop diagrams at the amplitude level")
        logger.info("   rendering possible the computation of the loop amplitude")
        logger.info("   for a fixed color flow or color configuration.")
        logger.info(" > This option can considerably slow down the loop ME")
        logger.info("   computation time, especially when summing over all color")
        logger.info("   and helicity configuration, hence turned off by default.")        

    def set2_loop_color_flows(self, args, log=True):
        """ usage set loop_color_flows True|False
        The computation of partial colour sub-amplitudes (i.e. amplitudes for fixed 
        colour flows) is turned off by default for the case of NLO virtual matrix elements 
        and turned on for loop-induced matrix elements.. This is because in the former case 
        it comes at the price of giving up loop reduction at the squared amplitude level,
        hence slowing down MadLoop execution speed since the number of OPP reductions is 
        no longer independent of the number of contributing helicity configurations. 
        This option can however be turned on (before MadLoop writes out the source code 
        for the process) since colour sub-amplitudes can be necessary for certain applications, 
        such as NLO event generation within the context of a controlled colour expansion
        and/or Monte-Carlo over colours. 
        """
        
        args = ['loop_color_flows'] + args
        self.check_set(args)

        if log:
                logger.info('set loop color flows to %s' % args[1])
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        self.options[args[0]] = args[1]
        if self.options['loop_color_flows'] and \
                                    not self.options['loop_optimized_output']:
            logger.warning("Turning on option 'loop_optimized'"+\
                                    " needed for loop color flow computation.")
            self.do_set('loop_optimized_output True',False)

    def set2_eMELA(self, args, log=True):
        """Set the eMELA-config path.
        Example: set eMELA /PATH/TO/eMELA-config
        or: set eMELA None
        """
        args = ['eMELA'] + args
        self.check_set(args)
        
        try:
            p = subprocess.Popen([args[1], '--version'], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
            output, error = p.communicate()
            output = output.decode()
            res = 0
        except Exception:
            res = 1

        if res != 0 or error:
            if args[1] != 'None':
                logger.info('%s does not seem to correspond to a valid eMELA-config ' % args[1] + \
                'executable.\n Please set the \'fastjet\'' + \
                'variable to the full (absolute) /PATH/TO/eMELA-config (including eMELA-config).' +
                    '\n MadGraph7> set eMELA /PATH/TO/eMELA-config\n')
            self.options[args[0]] = None
            if self.history and 'eMELA' in self.history[-1]:
                self.history.pop()
        else: #everything is fine
            logger.info('set eMELA to %s' % args[1])
            self.options[args[0]] = args[1]

    def set2_fastjet(self, args, log=True):
        """Set the fastjet-config path.
        Example: set fastjet /PATH/TO/fastjet-config
        or: set fastjet None
        """
        args = ['fastjet'] + args
        self.check_set(args)
        
        try:
            p = subprocess.Popen([args[1], '--version'], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
            output, error = p.communicate()
            output = output.decode(errors='ignore')
            res = 0
        except Exception:
            res = 1

        if res != 0 or error:
            logger.info('%s does not seem to correspond to a valid fastjet-config ' % args[1] + \
                'executable (v3+). We will use fjcore instead.\n Please set the \'fastjet\'' + \
                'variable to the full (absolute) /PATH/TO/fastjet-config (including fastjet-config).' +
                    '\n MadGraph7> set fastjet /PATH/TO/fastjet-config\n')
            self.options[args[0]] = None
            if self.history and 'fastjet' in self.history[-1]:
                self.history.pop()
        elif int(output.split('.')[0]) < 3:
            logger.warning('%s is not ' % args[1] + \
                    'v3 or greater. Please install FastJet v3+.')
            self.options[args[0]] = None
            self.history.pop()
        else: #everything is fine
            logger.info('set fastjet to %s' % args[1])
            self.options[args[0]] = args[1]


    def setup_path_for_options(self,name, args, log=True):
        """Set the path for golem/samurai/ninja/ninjars/tirust/collier options.
        Example: set golem /PATH/TO/golem/lib
        or: set golem None
        """
        args = [name] + args[:]
        if not (args[0] in ['ninja','ninjars','tirust','collier'] and args[1]=='./HEPTools/lib'):
            if args[1] in ['None',"''",'""']:
                self.options[args[0]] = None
            else:
                program = misc.which_lib(os.path.join(args[1],'lib%s.a'%args[0]))
                if program!=None:
                    res = 0
                    logger.info('set %s to %s' % (args[0],args[1]))
                    self.options[args[0]] = args[1]
                else:
                    res = 1
    
                if res != 0 :
                    logger.warning('%s does not seem to correspond to a valid %s lib ' % (args[1],args[0]) + \
                            '. Please enter the full PATH/TO/%s/lib .\n'%args[0] + \
                            'You will NOT be able to run %s otherwise.\n'%args[0])
        else:
           self.options[args[0]] = args[1] 
        

    set2_golem = lambda self, *args, **opts : self.setup_path_for_options('golem'   , *args, **opts)
    set2_samurai = lambda self, *args, **opts : self.setup_path_for_options('samurai' , *args, **opts)  
    set2_ninja = lambda self, *args, **opts : self.setup_path_for_options('ninja'   , *args,   **opts)
    set2_ninjars = lambda self, *args, **opts : self.setup_path_for_options('ninjars', *args, **opts)
    set2_tirust = lambda self, *args, **opts : self.setup_path_for_options('tirust', *args, **opts)
    set2_collier = lambda self,*args, **opts : self.setup_path_for_options('collier' , *args, **opts)

    def set2_lhapdf(self, args, log=True):
        """Set the lhapdf-config path.
        Example: set lhapdf /PATH/TO/lhapdf-config
        or: set lhapdf None
        trick (for config file): set f2py_compiler f2py3.10 --python=3.10
        only apply the setting if the python version match the current one
        """
        
        args = ['lhapdf'] + args
        self.check_set(args)  
        
        # allow filter for python version  
        if len(args) > 2 and args[2].startswith('--python='):
            py_version = args[2].split('=')[1]
            major_version = int(py_version.split('.')[0])
            minor_version = int(py_version.split('.')[1])
            if major_version != sys.version_info[0] or \
               minor_version != sys.version_info[1]:
               return  
            # remove the --python- argument to not include it in the option/configuration file
            del args[2]

        to_do = True
        if args[0].endswith('_py2'):
            to_do = False
        #elif args[0].endswith('_py3') and False:
        #    to_do = False
        if to_do:
            try:
                res = misc.call([args[1], '--version'], stdout=subprocess.PIPE,
                                                                stderr=subprocess.PIPE)
                logger.info('set lhapdf to %s' % args[1])
                self.options['lhapdf'] = args[1]
                self.options[args[0]] = args[1]
            except Exception:
                res = 1
            if res != 0 and args[1] != 'None':
                # the shipped default just means "no LHAPDF here", which the
                # mg7 output does not need (it downloads the PDF sets itself)
                log_level = logging.DEBUG if args[1] == 'lhapdf-config' else logging.INFO
                logger.log(log_level, '%s does not seem to correspond to a valid lhapdf-config ' % args[1] + \
                        'executable. \nPlease set the \'lhapdf\' variable to the (absolute) ' + \
                        '/PATH/TO/lhapdf-config (including lhapdf-config).\n' + \
                        'Note that you can still compile and run aMC@NLO with the built-in PDFs,\n' + \
                        'and the mg7 output downloads its PDF sets without LHAPDF\n' + \
                        ' MadGraph7> set lhapdf /PATH/TO/lhapdf-config\n')
               
    set2_lhapdf_py2 = set2_lhapdf
    set2_lhapdf_py3 = set2_lhapdf




    def set2_timeout(self, args, log=True):
        """Time allowed to answer question (if no answer takes default value)
            Note that pressing tab always stops the timer (or any other keys)."""
        args = ['timeout'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])
    
    def set2_auto_update(self, args, log=True):
        """Number of days between two automatic update checks (0 means never)
           Default: 7 days"""
        args = ['auto_update'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])
                
    def set2_cluster_nb_retry(self, args, log=True):
        """Number of retries for a failed cluster job (default: 1)"""
        args = ['cluster_nb_retry'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])

    def help_set2_max_t_for_channel(self):
        logger.info("max_t_for_channel <value>",'$MG:color:GREEN')
        logger.info(" > (default '0') [Used ONLY for tree-level output with madevent]")
        logger.info(" > Forbids the inclusion of channel of integration with more than X")
        logger.info(" > T channel propagators. Such channel can sometimes be quite slow to integrate")

    def set2_max_t_for_channel(self, args, log=True):
        """ This parameter controls the maximum number of t-channel"""
        args = ['max_t_for_channel'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])

    def set2_cluster_retry_wait(self, args, log=True):
        """Time (in seconds) to wait before retrying a failed cluster job (default: 300s)"""
        args = ['cluster_retry_wait'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])

    def set2_cluster_size(self, args, log=True):
        """ Used only for loop-induced mode and in cluster mode, helps the code to control how many
              processes are sent to the cluster at the same time (default: 100)"""
        args = ['cluster_size'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])
        
    def help_set2_max_npoint_for_channel(self):
        logger.info("max_npoint_for_channel <value>",'$MG:color:GREEN')
        logger.info(" > (default '0') [Used ONLY for loop-induced outputs with madevent]")
        logger.info(" > Sets the maximum 'n' of n-points loops to be used for")
        logger.info(" > setting up the integration multichannels.") 
        logger.info(" > The default value of zero automatically picks the apparent")
        logger.info(" > appropriate choice which is to sometimes pick box loops")
        logger.info(" > but never higher n-points ones.")
        logger.info(" > This parameter to take effect, must to be modified prior the generation of the source code of the process considered.")
        logger.info(" > In general, we do not observe any significant gain (when not detrimental) when setting this parameter to 4 or larger (except in the case of gg → zz)")



    def set2_max_npoint_for_channel(self, args, log=True):
        """ This parameter controls what topologies enter
            the multi-channeling to be used for integrating loop-induced processes. For instance,
            when set to 4, all loop diagrams with 4 or less loop propagators seed their own channel
            of integration. This means that tree topologies obtained by shrinking up to box loop
            diagrams are considered for the multi-channeling and therefore integrated separately.
            In general, we do not observe any significant gain (when not detrimental) when setting
            this parameter to 4 or larger (except in the case of gg → zz). We stress here that,
            for this parameter to take effect, it must to be modified prior the generation of the
            source code of the process considered."""
        args = ['max_npoint_for_channel'] + args
        self.check_set(args)
        self.options[args[0]] = int(args[1])

    def set2_cvmfs_lhapdf_path(self, args, log=True):
        """default=/cvmfs/sft.cern.ch/lcg/external/lhapdfsets/current
        Directory of the LHAPDF sets mirrored via CVMFS. When that directory is
        mounted, a PDF set found there is read directly from it: it is neither
        downloaded nor copied into lib/PDFsets, and therefore not transferred to
        the cluster nodes (which mount the same read-only filesystem).
        A path that is not mounted is simply ignored; set the option to None to
        switch the fallback off.
        """
        args = ['cvmfs_lhapdf_path'] + args
        self.check_set(args)
        value = args[1].strip()
        self.options[args[0]] = None if value in ['None', 'none', ''] else value

    def set2_cluster_local_path(self, args, log=True):
        """default=None 
        This parameter avoids either to transfer PDF sets to the cluster nodes or 
        to read them directly on a central disk. This path should point to a (node specific) 
        directory containing the associated PDF sets (either those from LHAPDF or built-in ones). 
        A typical usage is to set this path to a local directory mirrored via cvmfs.
        """
        args = ['cluster_local_path'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()
    

    def set2_cluster_status_update(self, args, log=True):
        """Set the time interval and number of checks for updating the cluster job status.
           The code starts by to check the status after the second interval (in seconds).
           After few iterations the jobs switch to the first interval (in seconds).
           The code can switch back to the second interval when reaching the end of the submissions.
           The user can type ctrl-c to force to switch back to the second (smaller) interval.
        Default is (600, 30)
        Example: set cluster_status_update 300 5
        or: set cluster_status_update (300,5)
        """
        args = ['cluster_status_update'] + args
        self.check_set(args)
        
        if '(' in args[1]:
            data = ' '.join([a for a in args[1:] if not a.startswith('-')])
            data = data.replace('(','').replace(')','').replace(',',' ').split()
            first, second = data[:2]
        else:
            first, second = args[1:3]

        self.options[args[0]] = (int(first), int(second))
        
    def set2_madanalysis5_path(self, args, log=True):
        """Set the madanalysis5 path.
        Example: set madanalysis5_path /PATH/TO/madanalysis5
        or: set madanalysis5_path None
        """
        args = ['madanalysis5_path'] + args
        self.check_set(args)

        ma5path = pjoin(MG5DIR, args[1]) if os.path.isfile(pjoin(MG5DIR, args[1])) else args[1]
        message = misc.is_MA5_compatible_with_this_MG5(ma5path)
        if message is None:
            self.options['madanalysis5_path'] = args[1]
        else:
            logger.warning(message)

    def help_set2_OLP(self):
        logger.info("OLP ProgramName",'$MG:color:GREEN')
        logger.info(" > (default 'MadLoop') [Used for virtual generation]")
        logger.info(" > Chooses what One-Loop Program to use for the virtual")
        logger.info(" > matrix element generation via the BLAH accord.")
        logger.info(" Example: set OLP Gosam", "$MG:color:BOLD")
        logger.info(" > Ensure the external OLP is installed and accessible (e.g., gosam.py in PATH for GoSam).")







    def set2_OLP(self, args, log=True):
        """Select the One-Loop Provider (OLP) for NLO computations in MadGraph7. 
        By default, MG5 uses its internal engine MadLoop. 
        This option allows switching to an external OLP via the BLHA interface (e.g., GoSam, OpenLoops).
        Example: set OLP Gosam
        Ensure the external OLP is installed and accessible (e.g., gosam.py in PATH for GoSam).
        Supported providers depend on your MG5 version and configuration.
        """
        args = ['OLP'] + args
        self.check_set(args)
        if self.options['low_mem_multicore_nlo_generation'] and args[1] != "MadLoop":
            raise self.InvalidCmd('Not possible to set OLP with both \"low_mem_multicore_nlo_generation\" and python3')
        # Reset the amplitudes, MatrixElements and exporter as they might
        # depend on this option
        self._curr_amps = diagram_generation.AmplitudeList()
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        self._curr_exporter = None
        self._second_exporter = None
        self.options[args[0]] = args[1]

    def help_set2_output_dependencies(self):
        logger.info("output_dependencies <mode>",'$MG:color:GREEN')
        logger.info(" > (default 'external') [Use for NLO outputs]")
        logger.info(" > Choses how the external dependences (such as CutTools)")
        logger.info(" > of NLO outputs are handled. Possible values are:")
        logger.info("     o external: Some of the libraries the output depends")
        logger.info("       on are links to their installation in MG5 root dir.")
        logger.info("     o internal: All libraries the output depends on are")
        logger.info("       copied and compiled locally in the output directory.")
        logger.info("     o environment_paths: The location of all libraries the ")
        logger.info("       output depends on should be found in your env. paths.")  
        logger.info(" > This affects whether the template  bundles its build‑time/runtime dependencies (self‑contained) or relies on centrally installed ones.")



    def set2_output_dependencies(self, args, log=True):
        """Syntax: set output_dependencies <mode>
           
           Control how third‑party code and libraries required by a process are handled in 
           the output directory produced by output. This affects whether the template 
           bundles its build‑time/runtime dependencies (self‑contained) 
           or relies on centrally installed ones.
           Default: external
           
        
           Modes:
           o external: Some of the libraries the output depends
             on are links to their installation in MG5 root dir.
           o internal: All libraries the output depends on are
             copied and compiled locally in the output directory.
           o environment_paths: The location of all libraries the
             output depends on should be found in your env. paths.           
        """
        
        args = ['output_dependencies'] + args
        self.check_set(args)
        
        self.options[args[0]] = args[1]

    def set2_plain(self, args, log=True):
        """Enable/Disable coloured output (equivalent to ./bin/madgraph --plain).
        Example: set plain True
        or: set plain False [Default]
        """
        args = ['plain'] + args
        self.check_set(args)
        if args[1] not in ['None', 'True', 'False']:
            raise self.InvalidCmd('expected bool for plain')
        self.options[args[0]] = eval(args[1])

        if self.options['plain']:
            os.environ['MG7_NO_COLOR'] = '1'
            coloring_logging.NO_COLOR = True
            self.prompt = MG7_PROMPT_TEXT
        else:
            os.environ.pop('MG7_NO_COLOR', None)
            coloring_logging.NO_COLOR = False
            self.prompt = MG7_PROMPT

    def set2_notification_center(self, args, log=True):
        """Enable/Disable the notification center (on desktop ubuntu/mac).
        Example: set notification_center True
        or: set notification_center False
        default is True
        The option is ignored if the notification center is not available on the system.
        """
        args = ['notification_center'] + args
        self.check_set(args)    
        if args[1] in ['None','True','False']:
            self.options[args[0]] = eval(args[1])
            self.allow_notification_center = self.options[args[0]]
        else:
            raise self.InvalidCmd('expected bool for notification_center')

    def set2_crash_on_error(self, args, log=True):
        """Set whether the code should crash or just go back to the prompt and interpret 
        the next command (default).
        Example: set crash_on_error True
        or: set crash_on_error False [Default]
        or: set crash_on_error never [never crash]
        if crash_on_error is True, the code will stop with a non zero exit code.
        """

        args = ['crash_on_error'] + args
        self.check_set(args)
        try:
            tmp = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
        except Exception:
            if args[1].lower() in ['never']:
                tmp = args[1].lower()
            else: 
                raise
        self.options[args[0]] = tmp

    def set2_auto_convert_model(self, args, log=True):
        """Set whether the code should automatically convert UFO models from
        python2 format to python3 format when imported in a python3 MadGraph7 session.
        Example: set auto_convert_model True [Default]
        Note that the UFO model will be overwritten which might be problematic.
        However, the syntax conversion is usually straightforward and is still python2 compatible.
        """
        args = ['auto_convert_model'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])

    def set2_acknowledged_v3_1_syntax(self, args, log=True):
        """Set whether the user acknowledge that he is aware of the new v3.1 UFO syntax.
        This is required to use some specific generate syntax at NLO.
        Default is set to True since MG5aMC v3.6.7
        """
        args = ['acknowledged_v3.1_syntax'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
        
    def help_set2_zerowidth_tchannel(self):
        logger.info("zerowidth_tchannel <value>",'$MG:color:GREEN')
        logger.info(" > (default: True) [Used ONLY for tree-level output with madevent]")
        logger.info(" > set the width to zero for all T-channel propagator --no impact on complex-mass scheme mode")
        


    def set2_zerowidth_tchannel(self, args, log=True):
        """Set whether the code should use zero-width for t-channel propagators.
        Default is set to True. (since v2.8.0)
        Example: set zerowidth_tchannel False 
        """ 
        args = ['zerowidth_tchannel'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0]) 

    def help_set2_merge_quartic_vertices(self):
        logger.info("merge_quartic_vertices <value>",'$MG:color:GREEN')
        logger.info(" > (default: False) [pure gluon amplitudes]")
        logger.info(" > Sum each four gluon contribution into the cubic")
        logger.info(" >  amplitude carrying the same colour factor.")
        logger.info(" > False  : off")
        logger.info(" > speed  : fewest amplitude calls (best on cpu)")
        logger.info(" > slots  : smallest wavefunction store (for gpu, where")
        logger.info(" >          that store is per thread); costs the sums")
        logger.info(" > auto   : below 6 legs only the amplitude merges, which")
        logger.info(" >          are free; above, slots when the matrix elements")
        logger.info(" >          go to a gpu backend and speed otherwise")

    def set2_merge_quartic_vertices(self, args, log=True):
        """Sum the four gluon contributions into the cubic amplitude carrying
        the same colour factor.

        Read while the diagrams are generated, so it has to be set before
        'generate' -- 'speed' and 'slots' fix the diagram order there and an
        output time option would come too late. 'auto' generates in the
        'speed' order and lets each output reorder, see
        apply_quartic_diagram_order.

        Example: set merge_quartic_vertices auto
        """
        args = ['merge_quartic_vertices'] + args
        self.check_set(args)
        value = args[1].lower()
        if value in ('slots', 'speed', 'auto'):
            pass
        elif value in ('false', '0', 'none', 'off'):
            value = False
        elif value in ('true', '1', 'on'):
            value = 'speed'
        else:
            raise self.InvalidCmd(
                "merge_quartic_vertices takes False, speed, slots or auto,"
                " not '%s'" % args[1])
        self.options[args[0]] = value
        madgraph.merge_quartic_vertices = value
        if log:
            logger.info('set merge_quartic_vertices to %s' % value)

    def set2_store_rwgt_info(self,args, log=True):
        """Set whether the code should generate systematics information in the output LHE file at NLO
        Default is set to False.
        Example: set store_rwgt_info True
        """
        args = ['store_rwgt_info'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
        
    def set2_cluster_queue(self, args, log=True):
        """Set the name of the queue to which cluster jobs will be submitted.
        Example: set cluster_queue long
        or: set cluster_queue None
        """
        args = ['cluster_queue'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()

    def set2_cluster_walltime(self, args, log=True):
        """Set the maximum walltime for cluster jobs (format depend of the cluster).
        Example: set cluster_walltime 48:00:00
        """
        args = ['cluster_walltime'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()

    def set2_low_mem_multicore_nlo_generation(self, args, log=True):
        """Set whether the code should use low memory mode and multicore
          when generating NLO code with multiple cores
        Default is set to False.
        Example: set low_mem_multicore_nlo_generation True
        """
        args = ['low_mem_multicore_nlo_generation'] + args
        self.check_set(args)
        if self.options['OLP'] != 'MadLoop':
            raise self.InvalidCmd('Not possible to set \"low_mem_multicore_nlo_generation\" for an OLP different of MadLoop when running  python3')
        else:
            self.options[args[0]] = args[1]
    
    def set2_use_pigz(self, args, log=True):
        """Usage: set use_pigz <value>
        pigz is a parallel implementation of gzip.
        Three possible values:
           None: autodetect (use pigz if available)
           False: stick to gzip
           True: use pigz"""
        args = ['use_pigz'] + args
        self.check_set(args)
        if args[1] in ['None','True','False']:
            self.options[args[0]] = eval(args[1])
        else:
            raise self.InvalidCmd('expected bool for use_pigz')
        misc.configure_gzip(self.options)

    def help_set2_cluster_temp_path(self):

        logger.info("cluster_temp_path PATH",'$MG:color:GREEN')
        logger.info(" > (default None) [Used in Madevent Output]")
        logger.info(" > Allow to perform the run in PATH directory")
        logger.info(" > This allow to not run on the central disk. ")
        logger.info(" > This is not used by condor cluster (since condor has")
        logger.info("   its own way to prevent it).")
      


    def set2_cluster_temp_path(self, args, log=True):
        """Path to a node directory to avoid direct writing on the central disk
           Note that condor clusters avoid direct writing by default (therefore this
           options does not affect condor clusters)
        """
        return self.set_default('cluster_temp_path', args, log=log)

    def set2_cpp_compiler(self, args, log=True):
        """Set the C++ compiler to be used in the code generation.
        Example: set cpp_compiler g++
        """
        return self.set_default('cpp_compiler', args, log=log)
    
    def set2_nb_core(self, args, log=True):
        """Set the number of core to be used for parallelized tasks.
        Example: set nb_core 4
        """
        if args[0] in ['None', None, '0', 0]:
            import multiprocessing
            self.options['nb_core'] = multiprocessing.cpu_count()
        else:
            self.options['nb_core'] = int(args[0])

    def set2_nb_core_pythia8(self, args, log=True):
        """Set the number of cores/jobs used by the Pythia8 step only.
        Falls back to the global nb_core option when left to None.
        Example: set nb_core_pythia8 8
        """
        return self.set_default('nb_core_pythia8', args, log=log)

    def set2_nb_core_delphes(self, args, log=True):
        """Set the number of cores/jobs used by the Delphes step only.
        Falls back to the global nb_core option when left to None.
        Example: set nb_core_delphes 8
        """
        return self.set_default('nb_core_delphes', args, log=log)

    def set2_cluster_type(self, args, log=True):
        """Set the cluster type to be used for cluster jobs submission.
        Example: set cluster_type condor
        customized cluster types can be defined via plugins.
        built-in types are: pbs|sge|condor|lsf|ge|slurm|htcaas|htcaas2
        """
        return self.set_default('cluster_type', args, log=log)
    
    def set2_text_editor(self, args, log=True):
        """Set the text editor to be used to open files from the MadGraph7 interface.
        Example: set text_editor emacs
        Example: set text_editor code
        Example: set text_editor gedit 
        Default is to use the system default editor ($EDITOR) falling back to vim.
        """
        return self.set_default('text_editor', args, log=log)


    def set2_run_mode(self, args, log=True):
        """Syntax: set run_mode <mode>
        Control how MadGraph7 runs the various steps of event generation.
        Modes:
           - 0: sequential execution of all steps
           - 1: use a job scheduler for cluster execution (set via the cluster_type parameter)
           - 2: parallel execution on the current machine (multi-core) [default]
                use nb_core option to set the number of cores (default is all)
        """
        return self.set_default('run_mode', args, log=log)
        
    def set2_automatic_html_opening(self, args, log=True):
        """Set whether the code should automatically open the html status page when
        running madevent execution (default: yes).
        """
        return self.set_default('automatic_html_opening', args, log=log)
    
    def set2_web_browser(self, args, log=True):
        """Set the web browser to be used to open html pages from the MadGraph7 interface.
        Example: set web_browser firefox
        Default is to use the system default browser.
        """
        return self.set_default('web_browser', args, log=log)
    
    def help_set2_include_lepton_initiated_processes(self):

        logger.info("include_lepton_initiated_processes True|False",'$MG:color:GREEN')
        logger.info(" > (default False) Do not include processes with leptons in the initial state (nlo gen. only).")

    
    def set2_include_lepton_initiated_processes(self, args, log=True):
        """Set whether lepton-initiated processes should be included in the generation.
        Default is False.
        Example: set include_lepton_initiated_processes True
        """
        return self.set_default('include_lepton_initiated_processes', args, log=log)

    def set2_checkpointing(self, args, log=True):
        """ Usage: set checkpointing True|False
         Default; False
         Checkpoint is created before the walltime limit and the calculation is resumed on another machine. 
         Requeuing of checkpointed job is handled automatically by the scheduler. 
         Implementation for SLURM and HTCondor is provided. 
         Checkpointing is possible only for NLO calculations (any calculation step). 
         Periodic checkpointing is supported, period is set to 24 hours.  
         This options requires DMTCP to be installed on the cluster. ("install DMTCP" command is available in MadGraph7).
         Related options: 
           -  cluster_requirement
           -  cluster_vacatetime
           -  enforce_shared_disk (only relevant for HTCondor)
           -  dmtcp  
        """
        args = ['checkpointing'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
    
    def set2_cluster_requirement(self, args, log=True):
        """
        Microarchitecture or CPU model may be specified. This is useful for inhomogenious clusters. 
        To restart from a DMTCP checkpoint, instruction sets from the previous machine are required.
        """
        args = ['cluster_requirement'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()
    
    def set2_cluster_vacatetime(self, args, log=True):
        """
        Used only if checkpointing is True.
        Grace period before the job removal/requeuing allocated for checkpoint creation.
        """
        args = ['cluster_vacatetime'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()

    def set2_enforce_shared_disk(self, args, log=True):
        """Usage: set enforce_shared_disk True|False 
        Only relevant for HTCondor clusters. 
        -> Enforce shared disk usage. 
           By default HTCondor I/O goes via sandbox (local disk). 
           Data transfer takes place before and after the job. 
           Local checkpoint storage may result in a checkpoint loss in the hardware failure scenario.
        """
        args = ['enforce_shared_disk'] + args
        self.check_set(args)
        self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])

    def set2_dmtcp(self, args, log=True):
        """ Usage: set dmtcp /PATH/TO/dmtcp_install_directory
            useful only if checkpointing is True.
            DMTCP installation directory should contain bin/dmtcp_restart and bin/dmtcp_launch
        """
        args = ['dmtcp'] + args
        self.check_set(args)
        self.options[args[0]] = args[1].strip()

    def set2_apply_flavor_grouping(self, args, log=True):
        """Set whether the code should apply flavor grouping in the generation of LO processes.
        Default: True
        """
        self.options['apply_flavor_grouping'] = banner_module.ConfigFile.format_variable(args[0], bool, 'apply_flavor_grouping')

    def help_set2_color_basis(self):
        logger.info("color_basis <value>",'$MG:color:GREEN')
        logger.info(" > (default: auto) select the color basis used for processes")
        logger.info("   whose color structure is purely adjoint (multi-gluon).")
        logger.info(" > trace: the (n-1)! basis of traces of fundamental generators")
        logger.info(" > ddm:   the (n-2)! Del Duca-Dixon-Maltoni half-ladder basis")
        logger.info("          (n-1 times fewer JAMPs, (n-1)^2 times smaller color matrix)")
        logger.info(" > auto:  ddm for the output formats which do not need a color")
        logger.info("          flow decomposition (standalone), trace otherwise")

    def set2_color_basis(self, args, log=True):
        """Set the color basis used for fully adjoint (multi-gluon) processes.
        Example: set color_basis ddm
        """
        args = ['color_basis'] + args
        self.check_set(args)
        value = args[1].lower()
        if value not in self._valid_color_basis:
            raise self.InvalidCmd('color_basis needs one of %s, got %s' % \
                                  (self._valid_color_basis, args[1]))
        self.options['color_basis'] = value

    def set2_merge_same_topologies(self, args, log=True):
        """Set whether the mg7 output should merge diagrams sharing the same topology
        (ignoring spin, color and charge) into a single integration channel.
        Default: True
        """
        self.options['merge_same_topologies'] = banner_module.ConfigFile.format_variable(args[0], bool, 'merge_same_topologies')



# not documented options:
#   	            	contur_path         
#delphes_path             	eps_viewer               	exrootanalysis_path
#hepmc_path               	hepmc3_path              	hwpp_path
#pineappl                 	pythia-pgs_path          	pythia8_path
#rivet_path               	                 	syscalc_path
#thepeg_path              	yoda_path

    def set_default(self, name, args, log=True):
        """Generic function to set default options.
        """
        args = [name] + args
        self.check_set(args)
        if args[1] in ['None','True','False']:
            self.options[args[0]] = eval(args[1])
        else:
            self.options[args[0]] = args[1]

    # Set an option
    def do_set(self, line, log=True, model_reload=True):
        """Set an option, which will be default for coming generations/outputs.
        """
        # Be careful:
        # This command is associated to a post_cmd: post_set.
        # This command mainly delegates to set2_xxx functions.
        # which is the recommended way to provide help via docstrings.
        args = self.split_arg(line)

        if args and cmd.is_removed_option(args[0]):
            cmd.warn_removed_option(args[0], args[1] if len(args) > 1 else None)
            return

        if hasattr(self, 'set2_%s' % args[0]):
            func = getattr(self, 'set2_%s' % args[0])
            return func(args[1:], log=log)
        elif '.' in args[0] and hasattr(self, 'set2_%s' % args[0].replace('.', '_')):
            func = getattr(self, 'set2_%s' % args[0].replace('.', '_'))
            return func(args[1:], log=log)
        

        # generic case 

        # Check the validity of the arguments
        self.check_set(args)
        if args[0] in self.options:
            if args[1] in ['None','True','False']:
                self.options[args[0]] = eval(args[1])
            else:
                self.options[args[0]] = args[1]
            return


        if args[0] == 'ignore_six_quark_processes':
            raise Exception('This option is now handled by a dedicated function.')
            # set_ignore_six_quark_processes(args[1:], log=log)
        elif args[0] == 'group_subprocesses':
            raise Exception('This option is now handled by a dedicated function.')
            # set_group_subprocesses(args[1:], log=log)
        elif args[0] == "stdout_level":
            raise Exception('This option is now handled by a dedicated function.')
            # set_stdout_level(args[1:], log=log)
        elif args[0].lower() == "ewscheme":
            raise Exception('This option is now handled by a dedicated function.')
            # set_ewscheme(args[1:], log=log)
        elif args[0] == "complex_mass_scheme":
            raise Exception('This option is now handled by a dedicated function.')
            # set_complex_mass_scheme(args[1:], log=log)
        elif args[0] == "gauge":
            raise Exception('This option is now handled by a dedicated function.')
            # set_gauge(args[1:], log=log)
        elif args[0] == 'fortran_compiler':
            raise Exception('This option is now handled by a dedicated function.')
            # set_fortran_compiler(args[1:], log=log)
        elif args[0] == 'default_unset_couplings':
            raise Exception('This option is now handled by a dedicated function.')
            # set_default_unset_couplings(args[1:], log=log)
        elif args[0].startswith('f2py_compiler'):
            raise Exception('This option is now handled by a dedicated function.')
            # set_f2py_compiler(args[1:], log=log)            
        elif args[0] == 'loop_optimized_output':
            raise Exception('This option is now handled by a dedicated function.')
            # set_loop_optimized_output(args[1:], log=log)
        elif args[0] == "nlo_mixed_expansion":
            raise Exception('This option is now handled by a dedicated function.')
            # set_nlo_mixed_expansion(args[1:], log=log)
        elif args[0] == 'loop_color_flows':
            raise Exception('This option is now handled by a dedicated function.')
            # set_color_flows(args[1:], log=log)
        elif args[0] == 'eMELA':
            raise Exception('This option is now handled by a dedicated function.')
            # set_eMELA(args[1:], log=log)
        elif args[0] == 'fastjet':
            raise Exception('This option is now handled by a dedicated function.')
            # set_fastjet(args[1:], log=log)
        elif args[0] in ['golem','samurai','ninja','ninjars','tirust','collier']:
            raise Exception('This option is now handled by a dedicated function.')
            # setup_path_for_options(args, log=log)
        elif args[0].startswith('lhapdf'):
            raise Exception('This option is now handled by a dedicated function.')
            # set_lhapdf(args[1:], log=log)
        elif args[0] in ['timeout', 'auto_update', 'cluster_nb_retry', 'max_t_for_channel',
                         'cluster_retry_wait', 'cluster_size', 'max_npoint_for_channel']:
            raise Exception('This option is now handled by a dedicated function.')
            # getattr(self, 'set_%s' % args[0])(args[1:],
        elif args[0] in ['cluster_local_path']:
            raise Exception('This option is now handled by a dedicated function.')
            # getattr(self, 'set_%s' % args[0])(args[1:
        elif args[0] == 'cluster_status_update':
            raise Exception('This option is now handled by a dedicated function.')
            # getattr(self, 'set_%s' % args[0])(args[1:
        elif args[0] == 'madanalysis5_path':
            raise Exception('This option is now handled by a dedicated function.')
            # set_madanalysis5_path(args[1:], log=log)
        elif args[0] == 'OLP':
            raise Exception('This option is now handled by a dedicated function.')
            # set_OLP(args[1:], log=log)
        elif args[0] =='output_dependencies':
            raise Exception('This option is now handled by a dedicated function.')
            # set_output_dependencies(args[1:], log=log)      
        elif args[0] =='notification_center':
            raise Exception('This option is now handled by a dedicated function.')
            # set_notification_center(args[1:], log=log)
        # True/False formatting
        elif args[0] in ['crash_on_error', 'auto_convert_model', 'acknowledged_v3.1_syntax']:
            raise Exception('This option is now handled by a dedicated function.')
            # set_crash_on_error(args[1:], log=log)
            # set_auto_convert_model(args[1:], log=log)
            # set_acknowledged_v3_1_syntax(args[1:], log=log
        elif args[0] in ['zerowidth_tchannel']:
            raise Exception('This option is now handled by a dedicated function.')
            # set_zerowidth_tchannel(args[1:], log=log) 
        elif args[0] in ['use_syst']:
            logger.warning('The option use_syst is deprecated.')
            self.options[args[0]] = banner_module.ConfigFile.format_variable(args[1], bool, args[0])
        elif args[args[0]] in ['store_rwgt_info']:
            raise Exception('This option is now handled by a dedicated function.')
            # set_store_rwgt_info(args[1:], log=log)
        elif args[0] in ['cluster_queue', 'cluster_walltime', 'checkpointing',\
                         'cluster_requirement', 'cluster_vacatetime', 'enforce_shared_disk']:
            raise Exception('This option is now handled by a dedicated function.')
            # getattr(self, 'set_%s' % args[0])(args[1:],
            # log=log)  
        elif args[0] in ['low_mem_multicore_nlo_generation']:	  
            raise Exception('This option is now handled by a dedicated function.')
            # set_low_mem_multicore_nlo_generation(args[1:], log=log)  
            


    def post_set(self, stop, line):
        """Check if we need to save this in the option file"""

        args = self.split_arg(line)
        # Check the validity of the arguments
        try:
            self.check_set(args, log=False)
        except Exception:
            return stop

        # respect if a condition on python version is given
        if '--python' in line:
            major, minor = re.findall(r'--python=(\d).(\d+)', line)[-1]
            if (major != str(sys.version_info[0]) or
                minor != str(sys.version_info[1])):
                return stop


        if args[0] in self.options_configuration and '--no_save' not in args:
            self.exec_cmd('save options %s' % args[0] , log=False)
        elif args[0] in self.options_madevent:
            if not '--no_save' in line:
                logger.info('This option will be the default in any output that you are going to create in this session.')
                logger.info('In order to keep this changes permanent please run \'save options\'')
        else:
            #MadGraph7 configuration
            if not self.history or self.history[-1].split() != line.split():
                self.history.append('set %s' % line)
                self.avoid_history_duplicate('set %s' % args[0], ['define', 'set'])

        return stop

    def do_open(self, line):
        """Open a text file/ eps file / html file"""

        args = self.split_arg(line)
        # Check Argument validity and modify argument to be the real path
        self.check_open(args)
        file_path = args[0]

        launch_ext.open_file(file_path)

    # Output formats whose matrix elements can run on a gpu, where the
    # wavefunction store is per thread. See set2_merge_quartic_vertices.
    _gpu_me_formats = ['mg7', 'mg7_v5', 'standalone']
    # Diagram order currently materialised in _curr_amps, and the diagrams as
    # they came out of the generation. Both only used for 'auto'.
    _quartic_order = None
    _quartic_pristine = None

    def apply_quartic_diagram_order(self, options):
        """Resolve an 'auto' merge_quartic_vertices against the backend which
        is about to be handed the matrix elements.

        What the two modes disagree on is the diagram order, and that is fixed
        while the diagrams are generated. 'auto' generates in the 'speed'
        order and reorders here instead, which is only possible because
        'slots' is that same order reversed.

        The reordering has to start from the diagrams as generated, not from
        the ones in hand: an export mutates what it is given, and reversing
        mutated diagrams gives an equivalent but differently numbered result.
        """

        if self.options.get('merge_quartic_vertices') != 'auto':
            return

        target = options['me_exporter'].get('name', self._export_format)
        gpu = target in self._gpu_me_formats or \
            options['me_exporter'].get('exporter', options['exporter']) == 'gpu'
        wanted = 'slots' if gpu else 'speed'
        madgraph.merge_quartic_vertices = wanted

        # Keep the diagrams of the amplitudes the seed rule applied to -- the
        # order of any other one is not ours to touch. Both have to be read
        # before the first export: it is the last moment the diagrams are the
        # generated ones, and it also drops the marks saying they came from a
        # seed. Amplitudes added later are picked up on the way past.
        if self._quartic_pristine is None:
            self._quartic_pristine = []
        for amp in self._curr_amps[len(self._quartic_pristine):]:
            self._quartic_pristine.append(
                copy.deepcopy(amp.get('diagrams'))
                if (getattr(amp, 'seed_forbidden_cubic_ids', None) and
                    getattr(amp, 'quartic_unroll_tags', None)) else None)
        if all(pristine is None for pristine in self._quartic_pristine):
            return
        logger.info("merge_quartic_vertices: '%s' for the %s matrix elements"
                    % (wanted, target))
        # the generation leaves them in the 'speed' order
        if wanted == (self._quartic_order or 'speed'):
            return
        for amp, pristine in zip(self._curr_amps, self._quartic_pristine):
            if pristine is None:
                continue
            diagrams = copy.deepcopy(pristine)
            if wanted == 'slots':
                diagrams.reverse()
            amp.set('diagrams', base_objects.DiagramList(diagrams))
        self._quartic_order = wanted
        # anything cached was built in the other order
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()

    def do_output(self, line):
        """Main commands: Initialize a new Template or reinitialize one"""

        args = self.split_arg(line)
        # Check Argument validity
        self._export_plugin = None
        self.check_output(args)

        if self._export_format not in self._onia_formats + ['aloha'] and \
                self.has_onium_amplitude():
            raise self.InvalidCmd("Bound states (onia) can only be written out "
                    "with 'output %s', not with 'output %s'."
                    % ("' or 'output ".join(self._onia_formats), self._export_format))

        if self._export_format not in self._v4_export_formats + ['aloha']:
            self.warn_rge_not_supported()

        noclean = '-noclean' in args
        force = '-f' in args
        nojpeg = '-nojpeg' in args
        if '--noeps=True' in args:
            nojpeg = True
        # density-matrix standalone output
        if '--density' in args:
            self._uses_density_matrix = True
        flaglist = []

        if '--postpone_model' in args:
            flaglist.append('store_model')
        if '--hel_recycling=False' in args:
            flaglist.append('no_helrecycling')

        me_exporter = False
        if any(arg.startswith('--me_exporter=') for arg in args):
            #forbid helicity recycling with cpp/cuda mixed mode
            if "--hel_recycling=False" not in args:
                args.append('--hel_recycling=False')
            for arg in args:
                if arg.startswith('--me_exporter='):
                    flaglist.append('me_exporter=%s' % arg.split("=",1)[1])
                    me_exporter = arg.split("=",1)[1]
                    break

        #forbid helicity recycling for spin 3/2 and spin 2
        if any(spin > 3 for spin in self._curr_model.get_all_spin()):
            flaglist.append('no_helrecycling')
            args.append('--hel_recycling=False')
                    
        line_options = dict( (arg[2:].split('=')  if "=" in arg else (arg[2:], True))
                             for arg in args if arg.startswith('--'))
#        line_options = dict(arg[2:].split('=') for arg in args if arg.startswith('--') and '=' not in arg)
        main_file_name = ""
        try:
            main_file_name = args[args.index('-name') + 1]
        except Exception:
            pass


        ################
        # ALOHA OUTPUT #
        ################
        if self._export_format == 'aloha':
            # catch format
            format = [d[9:] for d in args if d.startswith('--format=')]
            if not format:
                format = 'Fortran'
            else:
                format = format[-1]
            # catch output dir
            output = [d for d in args if d.startswith('--output=')]
            if not output:
                # the model name can carry a restriction suffix and says
                # nothing about where the model lives, so ask the model
                # itself for the directory it was imported from.
                try:
                    output = self._curr_model.get('modelpath')
                except Exception:
                    output = import_ufo.find_ufo_path(self._curr_model['name'])
                output = pjoin(output, format)
                if not os.path.isdir(output):
                    os.mkdir(output)
            else:
                output = output[-1]
                if not os.path.isdir(output):
                    raise self.InvalidCmd('%s is not a valid directory' % output)
            logger.info('creating routines in directory %s ' % output)
            # build the calling list for aloha
            names = [d for d in args if not d.startswith('-')]
            wanted_lorentz = aloha_fct.guess_routine_from_name(names)
            # Create and write ALOHA Routine
            aloha_model = create_aloha.AbstractALOHAModel.from_model(self._curr_model)
            aloha_model.add_Lorentz_object(self._curr_model.get('lorentz'))
            if wanted_lorentz:
                aloha_model.compute_subset(wanted_lorentz)
            else:
                aloha_model.compute_all(save=False, custom_propa=True)
            aloha_model.write(output, format)
            return

        #################
        ## Other Output #
        #################
        # Configuration of what to do:
        # check: check status of the directory
        # exporter: which exporter to use (v4/cpp/...)
        # output: [Template/dir/None] copy the Template, just create dir or do nothing
        config = {}
        config['madevent'] =       {'check': True,  'exporter': 'v4',  'output':'Template'}
        config['matrix'] =         {'check': False, 'exporter': 'v4',  'output':'dir'}
        config['standalone_fortran'] = {'check': True, 'exporter': 'v4',  'output':'Template'}
        config['standalone_msF'] = {'check': False, 'exporter': 'v4',  'output':'Template'}
        config['standalone_msP'] = {'check': False, 'exporter': 'v4',  'output':'Template'}
        config['standalone_rw'] =  {'check': False, 'exporter': 'v4',  'output':'Template'}
        config['pythia8'] =        {'check': False, 'exporter': 'cpp', 'output':'dir'}
        config['matchbox_cpp'] =   {'check': True, 'exporter': 'cpp', 'output': 'Template'}
        config['matchbox'] =       {'check': True, 'exporter': 'v4',  'output': 'Template'}
        config['mg7_v5'] =         {'check': True, 'exporter': 'cpp', 'output': 'Template'}
        config['mg7'] =            {'check': True, 'exporter': 'cpp', 'output': 'Template'}
        config['standalone'] =     {'check': True, 'exporter': 'cpp', 'output': 'Template'}

        if self._export_format == 'plugin':
            options = {'check': self._export_plugin.check, 'exporter':self._export_plugin.exporter, 'output':self._export_plugin.output}
        else:
            options = config[self._export_format]
        
        if me_exporter and me_exporter in config:
            options['me_exporter'] = config[me_exporter]
            options['me_exporter']['name'] = me_exporter
        elif me_exporter:
            # check for PLUGIN format
            output_cls = misc.from_plugin_import(self.plugin_path, 'new_output',
                                                 me_exporter, warning=True, 
                                                 info='Addition matrix-element will be done with PLUGIN: %(plug)s')
            options['me_exporter'] = {'check': output_cls.check, 'exporter':output_cls.exporter, 'output':output_cls.output}
            options['me_exporter']['name'] = me_exporter
        else:
            options['me_exporter'] = {}

        # now that the backend getting the matrix elements is known, an 'auto'
        # merge_quartic_vertices can be resolved -- before anything is built
        self.apply_quartic_diagram_order(options)

        # A loop-induced process is exported by this tree-level do_output (see
        # create_loop_induced), but only the formats in LOOP_INDUCED_FORMATS
        # have a loop backend to route it to. Refuse the others here, ahead of
        # the directory cleaning just below, so that a guaranteed refusal never
        # deletes an existing output directory first. The factories carry the
        # same check, but they run after that cleaning.
        if self._curr_amps and isinstance(self._curr_amps[0],
                                    loop_diagram_generation.LoopAmplitude):
            # --me_exporter= writes into the same directory, so it has to be
            # checked here too
            for format in [self._export_format,
                           options['me_exporter'].get('name')]:
                if format and format not in export_v4.LOOP_INDUCED_FORMATS:
                    raise self.InvalidCmd(
                        export_v4.loop_induced_not_supported_msg(
                            format, self._curr_amps[0].get('process')))

        # A tree x tree interference ('left [treextree] right') needs the
        # selection of squared split orders in the generated code: other
        # formats would silently return |A_left + A_right|^2.
        # (a decay-chain amplitude has no 'process', and is never one)
        interference = [amp for amp in self._curr_amps if 'process' in amp
            and amp['process'].get_interference_mode() == 'treextree']
        if interference:
            for format in [self._export_format,
                           options['me_exporter'].get('name')]:
                if format and format not in \
                           diagram_generation.TREE_INTERFERENCE_FORMATS:
                    raise self.InvalidCmd(
                        "The '%s' output format cannot select the "
                        "interference of a treextree process (it would "
                        "return |A_left + A_right|^2): use one of %s."
                        % (format, ', '.join(
                               diagram_generation.TREE_INTERFERENCE_FORMATS)))

        # check
        if os.path.realpath(self._export_dir) == os.getcwd():
            if len(args) == 0:
                i=0
                while 1:
                    if os.path.exists('Pythia8_proc_%i' %i):
                        i+=1
                    else:
                        break
                os.mkdir('Pythia8_proc_%i' %i) 
                self._export_dir = pjoin(self._export_dir, 'Pythia8_proc_%i' %i)
                logger.info('Create output in %s' % self._export_dir)
            elif not args[0] in ['.', '-f']:
                raise self.InvalidCmd('Wrong path directory to create in local directory use \'.\'')
        elif not noclean and os.path.isdir(self._export_dir) and options['check']:
            if not force:
                # Don't ask if user already specified force or noclean
                logger.info('INFO: directory %s already exists.' % self._export_dir)
                logger.info('If you continue this directory will be deleted and replaced.')
                answer = self.ask('Do you want to continue?', 'y', ['y','n'])
            else:
                answer = 'y'
            if answer != 'y':
                raise self.InvalidCmd('Stopped by user request')
            else:
                shutil.rmtree(self._export_dir)

        # Choose here whether to group subprocesses or not, if the option was
        # set to 'Auto' and propagate this choice down the line:
        if self.options['group_subprocesses'] in [True, False]:
            group_processes = self.options['group_subprocesses']
        elif self.options['group_subprocesses'] == 'Auto':
            # By default we set it to True
            group_processes = True
            # But we turn if off for decay processes which
            # have been defined with multiparticle labels, because then
            # branching ratios necessitates to keep subprocesses independent.
            # That applies only if there is more than one subprocess of course.
            if self._curr_amps[0].get_ninitial() == 1 and \
                                                     len(self._curr_amps)>1:
                
                processes = [amp.get('process') for amp in self._curr_amps if 'process' in  list(amp.keys())]
                if len(set(proc.get('id') for proc in processes))!=len(processes):
                    # Special warning for loop-induced
                    if any(proc['perturbation_couplings'] != [] for proc in
                               processes) and self._export_format == 'madevent':
                        logger.warning("""
|| The loop-induced decay process you have specified contains several
|| subprocesses and, in order to be able to compute individual branching ratios, 
|| MadGraph7 will *not* group them. Integration channels will also be considered
|| for each diagrams and as a result integration will be inefficient.
|| It is therefore recommended to perform this simulation by setting the MadGraph7
|| option 'group_subprocesses' to 'True' (before the output of the process).
|| Notice that when doing so, processes for which one still wishes to compute
|| branching ratios independently can be specified using the syntax:
||   -> add process <proc_def>
""")
                    group_processes = False
        else:
            group_processes = True
    
        #Exporter + Template
        if options['exporter'] == 'v4':
            self._curr_exporter = export_v4.ExportV4Factory(self, noclean, 
                                             group_subprocesses=group_processes,
                                             cmd_options=line_options)
        elif options['exporter'] in ['cpp', 'gpu']:
            self._curr_exporter = export_cpp.ExportCPPFactory(self, group_subprocesses=group_processes,
                                                              cmd_options=line_options)

        if options['me_exporter'] and options['me_exporter']['exporter'] != options['exporter']:

            if options['me_exporter']['exporter'] == 'v4':
                with misc.TMP_variable(self, '_export_format', options['me_exporter']['name']):
                    self._me_curr_exporter = export_v4.ExportV4Factory(self, noclean, 
                                                group_subprocesses=group_processes,
                                                cmd_options=line_options)
            elif options['me_exporter']['exporter']  in ['cpp','gpu']:
                # check for PLUGIN format
                output_cls = misc.from_plugin_import(self.plugin_path, 'new_output',
                                                 options['me_exporter']['name'], warning=True, 
                                                 info='Output will be done with PLUGIN: %(plug)s')
                if output_cls:
                    self._export_plugin = output_cls


                with misc.TMP_variable(self, '_export_format', options['me_exporter']['name']):
                    self._me_curr_exporter = export_cpp.ExportCPPFactory(self, group_subprocesses=group_processes,
                                                                cmd_options=line_options)
        else:           
            self._me_curr_exporter = False
            

        self._curr_exporter.pass_information_from_cmd(self)
        if self._me_curr_exporter:
            self._me_curr_exporter.pass_information_from_cmd(self)
        
        if options['output'] == 'Template':
            self._curr_exporter.copy_template(self._curr_model)
            if self._me_curr_exporter:
                self._me_curr_exporter.copy_template(self._curr_model)
        elif options['output'] == 'dir' and not os.path.isdir(self._export_dir):
            os.makedirs(self._export_dir)

        # Reset _done_export, since we have new directory
        self._done_export = False

        if self._export_format == "madevent":
            # for MadEvent with MadLoop decide if we keep the box as channel of 
            #integration or not. Forbid them for matching and for h+j
            if self.options['max_npoint_for_channel']:
                base_objects.Vertex.max_n_loop_for_multichanneling = int(self.options['max_npoint_for_channel'])
            else:
                base_objects.Vertex.max_n_loop_for_multichanneling = 3 
            base_objects.Vertex.max_tpropa = int(self.options['max_t_for_channel'])   

        # Perform export and finalize right away
        self.export(nojpeg, main_file_name, group_processes, args)

        # Automatically run finalize
        self.finalize(nojpeg, flaglist=flaglist)

        # Remember that we have done export
        self._done_export = (self._export_dir, self._export_format)

        # Reset _export_dir, so we don't overwrite by mistake later
        self._export_dir = None

    # Export a matrix element
    def set_color_basis_mode(self, *exporters):
        """Set the color basis used for fully adjoint (multi-gluon) processes.
        The (n-2)! Del Duca-Dixon-Maltoni basis can only be used by the output
        formats which never need a color flow decomposition, so in 'auto' mode
        every exporter involved must support it."""

        mode = self.options.get('color_basis', 'auto')
        exporters = [exporter for exporter in exporters if exporter]
        if mode == 'auto':
            use_ddm = bool(exporters) and \
                all(getattr(exporter, 'support_ddm_color_basis', False)
                    for exporter in exporters)
        else:
            use_ddm = (mode == 'ddm')

        # An exporter which has to write a color flow per event also needs the
        # trace basis next to the DDM one
        with_flow = any(getattr(exporter, 'ddm_needs_flow_basis', False)
                        for exporter in exporters)

        color_amp.set_ddm_basis(use_ddm, with_flow=with_flow)
        if use_ddm:
            logger.debug('Using the Del Duca-Dixon-Maltoni color basis for '
                         'fully adjoint processes (flow basis: %s)', with_flow)

    def export(self, nojpeg = False, main_file_name = "", group_processes=True,
                                                                       args=[]):
        """Export a generated amplitude to file."""

        self.set_color_basis_mode(self._curr_exporter, self._me_curr_exporter)
        try:
            return self._export(nojpeg, main_file_name, group_processes, args)
        finally:
            # the color basis is tied to this output, it must not leak to the
            # next command
            color_amp.set_ddm_basis(False)

    def _export(self, nojpeg = False, main_file_name = "", group_processes=True,
                                                                       args=[]):
        """Export a generated amplitude to file, with the color basis already
        selected."""

        # Define the helas call  writer
        if hasattr(self._curr_exporter, 'helas_exporter') and self._curr_exporter.helas_exporter:
            self._curr_helas_model = self._curr_exporter.helas_exporter(self._curr_model, options=self.options)
        elif self._curr_exporter.exporter == 'cpp':       
            self._curr_helas_model = helas_call_writers.CPPUFOHelasCallWriter(self._curr_model)
        elif self._curr_exporter.exporter == 'gpu':       
            self._curr_helas_model = helas_call_writers.GPUFOHelasCallWriter(self._curr_model)
        elif self._curr_exporter.exporter == 'v4':
            if self._model_v4_path:
                self._curr_helas_model = helas_call_writers.FortranHelasCallWriter(self._curr_model)
            else:
                options = {'zerowidth_tchannel': self.options['zerowidth_tchannel']}
                if self._curr_amps and self._curr_amps[0].get_ninitial() == 1:
                    options['zerowidth_tchannel'] = False
                self._curr_helas_model = helas_call_writers.FortranUFOHelasCallWriter(self._curr_model,
                                                                                      options=options)
        else:
            raise Exception('unable to associate an helas format')

        # Define the helas call  writer if a second exporter is needed
        self._me_curr_helas_model = False
        if self._me_curr_exporter:
            if self._curr_exporter.exporter == self._me_curr_exporter.exporter:
                self._me_curr_helas_model = self._curr_helas_model 
            else:
                if hasattr(self._me_curr_exporter, 'helas_exporter') and self._me_curr_exporter.helas_exporter:
                    self._me_curr_helas_model = self._me_curr_exporter.helas_exporter(self._curr_model, options=self.options)
                elif self._me_curr_exporter.exporter == 'cpp':       
                    self._me_curr_helas_model = helas_call_writers.CPPUFOHelasCallWriter(self._curr_model)
                elif self._me_curr_exporter.exporter == 'gpu':       
                    self._me_curr_helas_model = helas_call_writers.GPUFOHelasCallWriter(self._curr_model)
                elif self._model_v4_path:
                    assert self._me_curr_exporter.exporter == 'v4'
                    self._me_curr_helas_model = helas_call_writers.FortranHelasCallWriter(self._curr_model)
                else:                    
                    self._me_curr_helas_model = helas_call_writers.FortranUFOHelasCallWriter(self._curr_model,
                                                                                             options=options)

        version = [arg[10:] for arg in args if arg.startswith('--version=')]
        if version:
            version = version[-1]
        else:
            version = '8.2'

        def generate_matrix_elements(self, group_processes=True):
            """Helper function to generate the matrix elements before
            exporting. Uses the main function argument 'group_processes' to decide 
            whether to use group_subprocess or not. (it has been set in do_output to
            the appropriate value if the MG5 option 'group_subprocesses' was set
            to 'Auto'."""

            if self._export_format in ['standalone_msP', 'standalone_msF', 'standalone_mw']:
                to_distinguish = []
                for part in self._curr_model.get('particles'):
                    if part.get('name') in args and part.get('antiname') in args and\
                       part.get('name') != part.get('antiname'):
                        to_distinguish.append(abs(part.get('pdg_code')))
            # Sort amplitudes according to number of diagrams,
            # to get most efficient multichannel output
            self._curr_amps.sort(key=lambda x: x.get_number_of_diagrams(),reverse=True)

            cpu_time1 = time.time()
            ndiags = 0
            if not self._curr_matrix_elements.get_matrix_elements():
                if group_processes:
                    cpu_time1 = time.time()
                    dc_amps = diagram_generation.DecayChainAmplitudeList(\
                        [amp for amp in self._curr_amps if isinstance(amp, \
                                        diagram_generation.DecayChainAmplitude)])
                    non_dc_amps = diagram_generation.AmplitudeList(\
                             [amp for amp in self._curr_amps if not \
                              isinstance(amp, \
                                         diagram_generation.DecayChainAmplitude)])
                    subproc_groups = group_subprocs.SubProcessGroupList()
                    matrix_elements_opts = {'optimized_output':
                                       self.options['loop_optimized_output']}
                    
                    grouping_criteria = self._curr_exporter.grouped_mode
                    if grouping_criteria == 'gpu':
                        grouping_criteria = 'madevent'
                    if non_dc_amps:
                        subproc_groups.extend(\
                          group_subprocs.SubProcessGroup.group_amplitudes(\
                          non_dc_amps,grouping_criteria, 
                                     matrix_elements_opts=matrix_elements_opts))

                    if dc_amps:
                        dc_subproc_group = \
                                  group_subprocs.DecayChainSubProcessGroup.\
                                  group_amplitudes(dc_amps, grouping_criteria,
                                      matrix_elements_opts=matrix_elements_opts)
                        subproc_groups.extend(dc_subproc_group.\
                                    generate_helas_decay_chain_subproc_groups())

                    ndiags = sum([len(m.get('diagrams')) for m in \
                              subproc_groups.get_matrix_elements()])
                    
                    if self._curr_exporter.grouped_mode == "gpu":
                        subproc_groups = subproc_groups.split_nonidentical_grouping()

                    self._curr_matrix_elements = subproc_groups
                    # assign a unique id number to all groups
                    uid = 0
                    last_error = None
                    for group in subproc_groups:
                        try:
                            groupme = group.get('matrix_elements')
                        except  helas_objects.HelasMatrixElement.NoFlavorError as error:
                            last_error = error
                            continue
                        uid += 1 # update the identification number
                        for me in groupme:
                            me.get('processes')[0].set('uid', uid)
                    if uid == 0 and last_error:
                        raise last_error
                else: # Not grouped subprocesses
                    mode = {}
                    if self._export_format in [ 'standalone_msP' , 
                                             'standalone_msF', 'standalone_rw']:
                        mode['mode'] = 'MadSpin'
                    # The conditional statement tests whether we are dealing
                    # with a loop induced process.
                    if isinstance(self._curr_amps[0], 
                                         loop_diagram_generation.LoopAmplitude):
                        mode['optimized_output']=self.options['loop_optimized_output']
                        HelasMultiProcessClass = loop_helas_objects.LoopHelasProcess
                        compute_loop_nc = True
                    else:
                        HelasMultiProcessClass = helas_objects.HelasMultiProcess
                        compute_loop_nc = False
                    
                    self._curr_matrix_elements = HelasMultiProcessClass(
                      self._curr_amps, compute_loop_nc=compute_loop_nc,
                                                       matrix_element_opts=mode)
                    
                    ndiags = sum([len(me.get('diagrams')) for \
                                  me in self._curr_matrix_elements.\
                                  get_matrix_elements()])
                    # assign a unique id number to all process
                    uid = 0
                    for me in self._curr_matrix_elements.get_matrix_elements()[:]:
                        uid += 1 # update the identification number
                        me.get('processes')[0].set('uid', uid)

            cpu_time2 = time.time()


            return ndiags, cpu_time2 - cpu_time1


        if self._me_curr_exporter:
            self._curr_exporter.grouped_mode = 'gpu'
            # temporary should be passed to
            # self._curr_exporter.grouped_mode = self._me_curr_exporter.grouped_mode
            # or the most restricted of the two

        # When the flavor-mask optimization is disabled (`--mask=False`) the
        # matrix element must be directly evaluable for *every* flavor
        # combination, not just one representative per permutation class.  Ask
        # the flavor machinery to enumerate all combinations: permutation-
        # duplicate diagrams then keep a valid flavor and are not trimmed, while
        # genuinely unphysical diagrams (no flavor at all) are still removed.
        helas_objects.HelasMatrixElement.enumerate_all_flavors = \
            not getattr(self._curr_exporter, 'use_flavor_mask', True)

        ndiags, cpu_time = generate_matrix_elements(self,group_processes)

        calls = 0


        path = self._export_dir
            
        cpu_time1 = time.time()

        # First treat madevent and pythia8 exports, where we need to
        # distinguish between grouped and ungrouped subprocesses

        # MadEvent
        if self._export_format == 'madevent':
            if self._me_curr_exporter:
                second_exporter = self._me_curr_exporter
                second_helas = self._me_curr_helas_model
                self._second_exporter = second_exporter
                self._second_exporter.in_madevent_mode = True
            else:
                second_exporter = None
                second_helas = None

            calls += self._curr_exporter.export_processes(self._curr_matrix_elements,
                                                         self._curr_helas_model,
                                                         second_exporter=second_exporter,
                                                         second_helas=second_helas
                                                         )
            # if self._me_curr_exporter:
            #     # grouping mode
            #     if isinstance(self._curr_matrix_elements, group_subprocs.SubProcessGroupList) and\
            #         self._me_curr_exporter.grouped_mode:
            #         misc.sprint("group mode")
            #         modify, self._curr_matrix_elements = self._me_curr_exporter.modify_grouping(self._curr_matrix_elements)
            #         if modify:
            #             matrix_elements = self._curr_matrix_elements.get_matrix_elements()

            #         for me_number, me in enumerate(self._curr_matrix_elements):
            #             calls = calls + \
            #                 self._me_curr_exporter.generate_subprocess_directory(\
            #                     me, self._me_curr_helas_model, me_number)               
                
            #     # ungroup mode
            #     else:
            #         misc.sprint("ungroup mode")
            #         modify, self._curr_matrix_elements = self._me_curr_exporter.modify_grouping(self._curr_matrix_elements)
            #         misc.sprint(modify, type(self._curr_matrix_elements))
            #         for nb,me in enumerate(self._curr_matrix_elements[:]):
            #             new_calls = self._me_curr_exporter.generate_subprocess_directory(\
            #                         me, self._curr_helas_model, nb)
            #             if  isinstance(new_calls, int):
            #                 if new_calls ==0:
            #                     self._curr_matrix_elements.remove(me)
            #                 else:
            #                     calls = calls + new_calls



            
                #try:
                #    cmd.Cmd.onecmd(self, 'history .')
                #except Exception:
                #    misc.sprint('command history fails.', 10)
                #    pass

        # Pythia 8
        elif self._export_format == 'pythia8':
            # Output the process files
            process_names = []
            if isinstance(self._curr_matrix_elements, group_subprocs.SubProcessGroupList):
                for (group_number, me_group) in enumerate(self._curr_matrix_elements):
                    exporter = self._curr_exporter.generate_process_directory(\
                            me_group.get('matrix_elements'), self._curr_helas_model,
                            process_string = me_group.get('name'),
                            process_number = group_number+1,
                            version = version)
                    process_names.append(exporter.process_name)
            else:
                exporter =  self._curr_exporter.generate_process_directory(\
                            self._curr_matrix_elements, self._curr_helas_model,
                            process_string = self._generate_info, version = version)
                process_names.append(exporter.process_file_name)

            wanted_lorentz = self._curr_matrix_elements.get_used_lorentz()
            # Output the model parameter and ALOHA files
            model_name, model_path = exporter.convert_model_to_pythia8(\
                            self._curr_model, self._export_dir, wanted_lorentz=wanted_lorentz)

            # Generate the main program file
            filename, make_filename = \
                      self._curr_exporter.generate_example_file_pythia8(path,
                                                               model_path,
                                                               process_names,
                                                               exporter,
                                                               main_file_name)
                      
                      
        matrix_elements = self._curr_matrix_elements.get_matrix_elements()
        if any(l.get('flavor') is None for l in matrix_elements[0].get('processes')[0].get('legs')):
            [m.get_external_flavors() for m in matrix_elements]  #precompute all flavors
        # Just the matrix.f files
        if self._export_format == 'matrix':
            for me in matrix_elements:
                filename = pjoin(path, 'matrix_' + \
                           me.get('processes')[0].shell_string() + ".f")
                if os.path.isfile(filename):
                    logger.warning("Overwriting existing file %s" % filename)
                else:
                    logger.info("Creating new file %s" % filename)
                calls = calls + self._curr_exporter.write_matrix_element_v4(\
                    writers.FortranWriter(filename),\
                    me, self._curr_helas_model)
        elif self._export_format in ['madevent', 'pythia8']:
            pass
        # grouping mode
        elif isinstance(self._curr_matrix_elements, group_subprocs.SubProcessGroupList) and\
            self._curr_exporter.grouped_mode:
            modify, self._curr_matrix_elements = self._curr_exporter.modify_grouping(self._curr_matrix_elements)
            if modify:
                matrix_elements = self._curr_matrix_elements.get_matrix_elements()

            for me_number, me in enumerate(self._curr_matrix_elements):
                calls = calls + \
                    self._curr_exporter.generate_subprocess_directory(\
                        me, self._curr_helas_model, me_number)               
        
        # ungroup mode
        else:
            for nb,me in enumerate(matrix_elements[:]):
                new_calls = self._curr_exporter.generate_subprocess_directory(\
                            me, self._curr_helas_model, nb)
                if  isinstance(new_calls, int):
                    if new_calls ==0:
                        matrix_elements.remove(me)
                    else:
                        calls = calls + new_calls

        if self._generate_info and hasattr(self._curr_exporter, 'write_procdef_mg5'):
            # Write the procdef_mg5.dat file with process info
            card_path = pjoin(self._export_dir ,'SubProcesses', \
                                     'procdef_mg5.dat')
            self._curr_exporter.write_procdef_mg5(card_path,
                                self._curr_model['name'],
                                self._generate_info)


        cpu_time2 = time.time() - cpu_time1

        logger.info(("Generated helas calls for %d subprocesses " + \
              "(%d diagrams) in %0.3f s") % \
              (len(matrix_elements),
               ndiags, cpu_time))

        if calls:
            if "cpu_time2" in locals():
                logger.info("Wrote files for %d helas calls in %0.3f s" % \
                            (calls, cpu_time2))
            else:
                logger.info("Wrote files for %d helas calls" % \
                            (calls))

        if self._export_format == 'pythia8':
            logger.info("- All necessary files for Pythia 8 generated.")
            logger.info("- Run \"launch\" and select %s.cc," % filename)
            logger.info("  or go to %s/examples and run" % path)
            logger.info("      make -f %s" % make_filename)
            logger.info("  (with process_name replaced by process name).")
            logger.info("  You can then run ./%s to produce events for the process" % \
                        filename)

        # Replace the amplitudes with the actual amplitudes from the
        # matrix elements, which allows proper diagram drawing also of
        # decay chain processes
        matrix_elements = self._curr_matrix_elements.get_matrix_elements()
        self._curr_amps = diagram_generation.AmplitudeList(\
               [me.get('base_amplitude') for me in \
                matrix_elements])

    def finalize(self, nojpeg, online = False, flaglist=[]):
        """Make the html output, write proc_card_mg5.dat and create
        madevent.tar.gz for a MadEvent directory"""

        compiler_dict = {'fortran': self.options['fortran_compiler'],
                             'cpp': self.options['cpp_compiler'],
                             'f2py': self.options['f2py_compiler']}

        # Handling of the model.
        if self._model_v4_path:
            logger.info('Copy %s model files to directory %s' % \
                            (os.path.basename(self._model_v4_path), self._export_dir))
            self._curr_exporter.export_model_files(self._model_v4_path)
            self._curr_exporter.export_helas(pjoin(self._mgme_dir,'HELAS'))        
        else:
            # wanted_lorentz are the lorentz structures which are
            # actually used in the wavefunctions and amplitudes in
            # these processes
            wanted_lorentz = self._curr_matrix_elements.get_used_lorentz()
            wanted_couplings = self._curr_matrix_elements.get_used_couplings()

            if self._export_format == 'madevent' and not 'no_helrecycling' in flaglist and \
                not isinstance(self._curr_amps[0], loop_diagram_generation.LoopAmplitude):
                for (name, flag, out) in wanted_lorentz[:]:
                    if out == 0:
                        newflag = list(flag) + ['P1N']
                        wanted_lorentz.append((name, tuple(newflag), -1))
                
            # For a unique output of multiple type of exporter need to store this
            # information.             
            if hasattr(self, 'previous_lorentz'):
                wanted_lorentz = misc.make_unique(self.previous_lorentz + wanted_lorentz)
                wanted_couplings = misc.make_unique(self.previous_couplings + wanted_couplings)
                del self.previous_lorentz
                del self.previous_couplings        
            if 'store_model' in flaglist:
                self.previous_lorentz = wanted_lorentz
                self.previous_couplings = wanted_couplings
            else:
                for npwave in aloha.npwave:
                    aloha.dual_mode = npwave
                    self._curr_exporter.convert_model(self._curr_model,
                                                   wanted_lorentz,
                                                   wanted_couplings,
                                                   npwave=npwave)
                aloha.dual_mode = 0
                if hasattr(self, '_me_curr_exporter') and self._me_curr_exporter:
                    self._me_curr_exporter.convert_model(self._curr_model, 
                                               wanted_lorentz,
                                               wanted_couplings)

            # exporting the files related to bound states
            if self._export_format in self._onia_formats:
                self._curr_exporter.export_onia_files(self._curr_matrix_elements)
        
        # move the old options to the flaglist system.
        if nojpeg:
            flaglist.append('nojpeg')
        if online:
            flaglist.append('online')

            

        if self._export_format in ['NLO', 'ewsudsa', 'NLO_SA']:
            ## write fj_lhapdf_opts file
            # Create configuration file [path to executable] for amcatnlo
            filename = os.path.join(self._export_dir, 'Cards', 'amcatnlo_configuration.txt')
            opts_to_keep = ['lhapdf', 'fastjet', 'pythia8_path', 'hwpp_path', 'thepeg_path', 
                                                     'hepmc_path', 'hepmc3_path', 'eMELA']
            to_keep = {}
            for opt in opts_to_keep:
                if self.options[opt]:
                    to_keep[opt] = self.options[opt]
            self.do_save('options %s' % filename.replace(' ', r'\ '), check=False, \
                    to_keep = to_keep)

        elif self._export_format in ['madevent']:
            # Create configuration file [path to executable] for madevent
            filename = os.path.join(self._export_dir, 'Cards', 'me5_configuration.txt')
            self.do_save('options %s' % filename.replace(' ', r'\ '), check=False,
                         to_keep={'mg5_path':MG5DIR})

        # Dedicated finalize function.
        add_options = {}
        if self._second_exporter:
            add_options['second_exporter'] = self._second_exporter
        self._curr_exporter.finalize(self._curr_matrix_elements,
                                    self.history,
                                    self.options,
                                    flaglist,
                                    **add_options)

        # Record into the generated directory the references that are already
        # known at generation time (framework, model, ALOHA/HELAS, UFO format).
        # These are picked up by every run launched from this output and merged
        # into its final citations.bib.
        self.write_generation_citations()

        if self._export_format in ['madevent', 'standalone_fortran', 'matchbox', 'mg7']:
            logger.info('Output to directory ' + self._export_dir + ' done.')

        if self._export_format in ['madevent', 'NLO']:
            logger.info('Type \"launch\" to generate events from this process, or see')
            logger.info(self._export_dir + '/README')
            logger.info('Run \"open index.html\" to see more information about this process.')

    def write_generation_citations(self):
        """Persist, into the generated directory, the references that are
        already known at generation time: the MadGraph7 framework, the
        UFO model format (or HELAS for v4 models), the ALOHA/HELAS helicity
        routines.  Writes citations.log (machine-readable, collected by every
        run) plus a ready-to-use citations.bib and a citations.md summary.
        """
        runnable = ['madevent', 'standalone_fortran', 'NLO',
                    'matchbox', 'mg7', 'mg7_v5', 'standalone']
        if self._export_format not in runnable or not self._export_dir:
            return
        try:
            import madgraph.various.citation as citation
        except ImportError:
            return

        try:
            model_name = self._curr_model.get('name') if self._curr_model else ''
        except Exception:
            model_name = ''

        # legacy v4 models are HELAS-based (no UFO/ALOHA); UFO otherwise
        pairs = citation.generation_pairs(model_name,
                                          is_ufo=not self._model_v4_path)
        # TODO: if a UFO model ever exposes its own INSPIRE key (e.g. a
        # __citation__ attribute), append it here so the physics-model paper is
        # cited too.

        # optional generation choices: gauge, polarization, TauDecay
        pairs += citation.optional_generation_pairs(
            gauge=str(self.options.get('gauge', 'unitary')),
            polarization=getattr(self, '_uses_polarization', False),
            taudecay=getattr(self, '_uses_taudecay', False))

        # MadSpace + MadNIS: used by the mg7 / standalone integration engine
        if self._export_format in ('mg7', 'mg7_v5', 'standalone'):
            pairs += [('Heimel:2026hgp',
                       'phase-space integration with MadSpace'),
                      ('Heimel:2023ngj',
                       'normalising flows for integration (MadNIS)')]
            if self._export_format == 'standalone':
                pairs.append(('Hagebock:2025jyk',
                               'data-parallel matrix-element evaluation (MadMatrix)'))

        # NLO output: FKS subtraction (MadFKS) and, when virtuals are
        # generated by MadLoop, the one-loop matrix elements
        if self._export_format == 'NLO':
            pairs.append(('Frederix:2009yq',
                           'FKS subtraction (MadFKS)'))
            try:
                has_virt = bool(self._fks_multi_proc.get_virt_amplitudes())
            except Exception:
                has_virt = False
            if has_virt and self.options.get('OLP', 'MadLoop') == 'MadLoop':
                pairs.append(('Hirschi:2011pa',
                               'one-loop matrix elements (MadLoop)'))

        # running couplings (model-level RGE)
        try:
            if self._curr_model and self._curr_model.get('running_elements'):
                pairs.append(('Aoude:2022aro',
                               'running couplings (RGE effects on SMEFT model)'))
        except Exception:
            pass

        # quarkonium / leptonium (NRQCD/NRQED) models: detect from model name
        _quarkonia_kws = ('nrqcd', 'nrqed', 'quarkon', 'leptonium')
        try:
            _mn = (self._curr_model.get('name') or '').lower() if self._curr_model else ''
        except Exception:
            _mn = ''
        if getattr(self, '_uses_quarkonia', False) or any(k in _mn for k in _quarkonia_kws):
            pairs.append(('ColpaniSerri:2025vdz',
                           'S-wave quarkonium/leptonium production (NRQCD/NRQED)'))

        # spin-density matrix output
        if getattr(self, '_uses_density_matrix', False):
            pairs.append(('Durupt:2025wuk',
                           'spin-density matrices and quantum observables'))

        try:
            gen_log = pjoin(self._export_dir, 'citations.log')
            citation.write_log(gen_log, pairs)
            citation.render(citation.collect_file(gen_log), self._export_dir)
        except Exception as error:
            logger.debug('could not write generation citations: %s', error)

    def do_help(self, line):
        """ propose some useful possible action """

        super(MadGraphCmd,self).do_help(line)

        if line:
            return

        if len(self.history) == 0:
            last_action_2 = 'mg5_start'
            last_action = 'mg5_start'
        else:
            args = self.history[-1].split()
            last_action = args[0]
            if len(args)>1:
                last_action_2 = '%s %s' % (last_action, args[1])
            else:
                last_action_2 = 'none'



    def get_model(self):
        """the model of the current session. The card question of `launch` on
        a standalone output calls this (via update_dependent) on its mother
        interface, as it calls MadEventCmd.get_model for madevent."""
        return self._curr_model

    # Calculate decay width
    def do_compute_widths(self, line, model=None, do2body=True, decaymodel=None):
        """Documented commands:Generate amplitudes for decay width calculation, with fixed
           number of final particles (called level)
           syntax; compute_widths particle [other particles] [--options=]

            - particle/other particles can also be multiparticle name (can also be
           pid of the particle)

           --body_decay=X [default=4.0025] allow to choose the precision.
                if X is an integer: compute all X body decay
                if X is a float <1: compute up to the time that total error < X
                if X is a float >1: stops at the first condition.

           --path=X. Use a given file for the param_card. (default UFO built-in)

           special argument:
               - skip_2body: allow to not consider those decay (use FR)
               - model: use the model pass in argument.

        """



        self.change_principal_cmd('MadGraph')

        try:
            import madgraph.various.citation as citation
            citation.cite('Alwall:2014bza',
                'automatic decay-width computation (MadWidth)')
        except ImportError:
            pass

        if not re.search(r'--nlo(?:\s|$|=(?!false))', line):
            warning_text = """Please note that the automatic computation of the width is
    only valid in narrow-width approximation and at tree-level."""
            logger.warning(warning_text)
            
        if not model:
            modelname = self._curr_model.get('modelpath+restriction')
            with misc.MuteLogger(['madgraph'], ['INFO']):
                model = import_ufo.import_model(modelname, decay=True)
        self._curr_model = model
            
        if not isinstance(model, model_reader.ModelReader):
            model = model_reader.ModelReader(model)

        nlo = re.search(r'--nlo(?:=(\w+))?(?:\s|$)', line)
        nlo_code = nlo.group(1).lower() if nlo and nlo.group(1) else None
        if nlo_code not in (None, 'true', 'false', 'smwidth', 'mcatnlo'):
            raise self.InvalidCmd('--nlo takes smwidth or mcatnlo, not %s' % nlo_code)
        if nlo_code == 'false':
            nlo = None
        if nlo_code in ('true', 'false'):
            nlo_code = None
        # SMWidth does not choose its corrections (QCD and EW): asking for some is
        # asking for MC@NLO
        mcatnlo_only = re.search(r'--corrections=', line) is not None
        if nlo and (nlo_code == 'smwidth' or
                    (nlo_code is None and not mcatnlo_only and self.has_smwidth(model))):
            # the dedicated code of the model for the NLO widths (the SM)
            return self.compute_widths_SMWidth(line, model=model)

        # the decay model of this computation, if the LO step makes one: the NLO
        # step needs the tree-level diagrams of the same model, and a second decay
        # model made from the first one's model finds its vertices twice
        self._widths_decaymodel = None

        decay_info, particles, opts = self._compute_widths_lo(line, model, do2body,
                                                              decaymodel)
        if nlo:
            # no dedicated code, or MC@NLO asked for: the two-body decays are run at
            # NLO with MC@NLO
            decay_info = self.compute_widths_nlo(particles, opts, decay_info,
                                                 model, decaymodel)
        return decay_info

    def _compute_widths_lo(self, line, model, do2body, decaymodel):
        """The LO widths of do_compute_widths. Returns the decay_info (the
        partial widths of every particle, {pid: [[decay products, width], ...]}),
        the particles and the options of the command."""

        # check the argument and return those in a dictionary format
        particles, opts = self.check_compute_widths(self.split_arg(line))

        if opts['path']:
            correct = True
            param_card = check_param_card.ParamCard(opts['path'])
            for param in param_card['decay']:
                if check_param_card.auto_width_options(param.value) is not None:
                    param.value = 1
                    param.format = 'float'
                    correct = False
            if not correct:
                if opts['output']:
                    param_card.write(opts['output'])
                    opts['path'] = opts['output']
                else:
                    param_card.write(opts['path'])

        data = model.set_parameters_and_couplings(opts['path'])
        

        # find UFO particles linked to the require names.
        if do2body:
            skip_2body = True
            decay_info = {}
            for pid in particles:
                particle = model.get_particle(pid)
                if not hasattr(particle, 'partial_widths'):
                    skip_2body = False
                    break
                elif not decay_info:
                    logger_mg.info('Get two body decay from FeynRules formula')
                decay_info[pid] = []
                mass = abs(eval(str(particle.get('mass')), data).real)
                data = model.set_parameters_and_couplings(opts['path'], scale= mass)
                total = 0
    
                # check if the value of alphas is set to zero and raise warning if appropriate
                if 'aS' in data and data['aS'] == 0 and particle.get('color') != 1:
                    logger.warning("aS set to zero for this particle since the running is not defined for such low mass.")
                        
                for mode, expr in particle.partial_widths.items():
                    tmp_mass = mass
                    for p in mode:
                        try:
                            value_mass = eval(str(p.mass), data)
                        except Exception:
                            # the p object can still be UFO reference. since the 
                            # mass name might have changed load back the MG5 one.
                            value_mass = eval(str(model.get_particle(p.pdg_code).get('mass')), data)
                        tmp_mass -= abs(value_mass)             
                    if tmp_mass <=0:
                        continue
    
                    decay_to = [p.get('pdg_code') for p in mode]
                    value = eval(expr,{'cmath':cmath},data).real
                    if -1e-10 < value < 0:
                        value = 0
                    if -1e-5 < value < 0:
                        logger.warning('Partial width for %s > %s negative: %s automatically set to zero' %
                                       (particle.get('name'), ' '.join([p.get('name') for p in mode]), value))
                        value = 0
                    elif value < 0:
                        raise Exception('Partial width for %s > %s negative: %s' % \
                                       (particle.get('name'), ' '.join([p.get('name') for p in mode]), value))
                    elif 0 < value < 0.1 and particle['color'] !=1:
                        logger.warning("partial width of particle %s lower than QCD scale:%s. Set it to zero. (%s)" \
                                   % (particle.get('name'), value, decay_to))
                        value = 0
                                     
                    decay_info[particle.get('pdg_code')].append([decay_to, value])
                    total += value
            else:
                madevent_interface.MadEventCmd.update_width_in_param_card(decay_info,
                                                       opts['path'], opts['output'])
                if float(opts['body_decay']) == 2:
                    return decay_info, particles, opts
        else:
            skip_2body = True

        #
        # add info from decay module
        #
        
        self.do_decay_diagram('%s %s' % (' '.join([repr(id) for id in particles]),
                                         ' '.join('--%s=%s' % (key,value)
                                                  for key,value in opts.items()
                                                  if key not in ['precision_channel', 'engine',
                                                                 'corrections'])
                                         ), skip_2body=skip_2body, model=decaymodel)
        self._widths_decaymodel = self._curr_decaymodel

        if self._curr_amps:
            logger.info('Pass to numerical integration for computing the widths:')
        else:            
            logger.info('No need for N body-decay (N>2). Results are in %s' % opts['output'])
            return decay_info, particles, opts

        engine = opts['engine'] or 'madspace'
        if engine == 'madspace' and (self.options.get('complex_mass_scheme') or
                                     aloha.complex_mass):
            # the mg7 output has no complex mass scheme: its matrix elements
            # would not even compile
            if opts['engine']:
                raise self.InvalidCmd('madspace does not support the complex mass '
                                      'scheme. Use --engine=madevent.')
            logger_mg.info('The complex mass scheme is not supported by madspace: '
                           'the widths are computed with madevent.')
            engine = 'madevent'
        if engine == 'madspace':
            try:
                decay_info = self.integrate_widths_madspace(opts, decay_info)
            except Exception as error:
                if opts['engine']:
                    # asked for explicitly: do not hide that it does not work
                    raise
                logger.warning('The width integration with madspace failed (%s).\n'
                               'Falling back to madevent. Use --engine=madevent '
                               'to select it and silence this message.', error)
                logger.debug('madspace width failure', exc_info=True)
            else:
                madevent_interface.MadEventCmd.update_width_in_param_card(decay_info,
                                                           opts['path'], opts['output'])
                if self._curr_model['name'] == 'mssm' or self._curr_model['name'].startswith('mssm-'):
                    check_param_card.convert_to_slha1(opts['output'])
                return decay_info, particles, opts

        # Do the MadEvent integration!!
        with misc.TMP_directory(dir=os.getcwd()) as path:
            decay_dir = pjoin(path,'temp_decay')
            logger_mg.info('More info in temporary files:\n    %s/index.html' % (decay_dir))
            with misc.MuteLogger(['madgraph','ALOHA','cmdprint','madevent'], [40,40,40,40]):
                self.exec_cmd('output madevent %s -f' % decay_dir,child=False)
                
                #modify some parameter of the default run_card
                run_card = banner_module.RunCard(pjoin(decay_dir,'Cards','run_card.dat'))
                if run_card['ickkw']:
                    run_card['ickkw'] = 0
                    run_card['xqcut'] = 0
                    run_card.remove_all_cut()
                    run_card.write(pjoin(decay_dir,'Cards','run_card.dat'))
                
                # Need to write the correct param_card in the correct place !!!
                if os.path.exists(opts['output']):
                    files.cp(opts['output'], pjoin(decay_dir, 'Cards', 'param_card.dat'))
                else:
                    files.cp(opts['path'], pjoin(decay_dir, 'Cards', 'param_card.dat'))
                if self._curr_model['name'] == 'mssm' or self._curr_model['name'].startswith('mssm-'):
                    check_param_card.convert_to_slha1(pjoin(decay_dir, 'Cards', 'param_card.dat'))
                # call a ME interface and define as it as child for correct error handling
                me_cmd = madevent_interface.MadEventCmd(decay_dir)
                for name, val in self.options.items():
                    if name in me_cmd.options and me_cmd.options[name] != val:
                        try:
                            me_cmd.exec_cmd('set %s %s --no_save' % (name, val)) 
                        except madgraph.InvalidCmd:
                            continue
                #me_cmd.options.update(self.options)
                #me_cmd.configure_run_mode(self.options['run_mode'])
                #self.define_child_cmd_interface(me_cmd, interface=False)
                me_cmd.model_name = self._curr_model['name'] #needed for mssm
                me_cmd.options['automatic_html_opening'] = False

                me_opts=[('accuracy', opts['precision_channel']), # default 0.01
                         ('points', 1000),
                         ('iterations',9)]
                me_cmd.exec_cmd('survey decay -f %s' % (
                       " ".join(['--%s=%s' % val for val in me_opts])),
                      postcmd=False)
                try:
                    me_cmd.exec_cmd('combine_events', postcmd=False)
                    me_cmd.exec_cmd('store_events', postcmd=False)
                except Exception as err:
                    logger.debug(str(err))

                me_cmd.collect_decay_widths()
                me_cmd.do_quit('')
                # cleaning
                del me_cmd

            param = check_param_card.ParamCard(pjoin(decay_dir, 'Events', 'decay','param_card.dat'))

        for pid in particles:
            width = param['decay'].get((pid,)).value
            particle = self._curr_model.get_particle(pid) 
            #if particle['color'] !=1 and 0 < width.real < 0.1:
            #    logger.warning("width of colored particle \"%s(%s)\" lower than QCD scale: %s. Set width to zero "
            #                   % (particle.get('name'), pid, width.real))
            #    width = 0
                
            
            if not pid in param['decay'].decay_table:
                continue
            if pid not in decay_info:
                decay_info[pid] = []
            for BR in param['decay'].decay_table[pid]:
                if len(BR.lhacode) == 3 and skip_2body:
                    continue
                if 0 < BR.value * width <0.1 and particle['color'] !=1:
                    logger.warning("partial width of particle %s lower than QCD scale:%s. Set it to zero. (%s)" \
                                   % (particle.get('name'), BR.value * width, BR.lhacode[1:]))
                                     
                    continue
                
                decay_info[pid].append([BR.lhacode[1:], BR.value * width])

        madevent_interface.MadEventCmd.update_width_in_param_card(decay_info,
                                                   opts['path'], opts['output'])

        if self._curr_model['name'] == 'mssm' or self._curr_model['name'].startswith('mssm-'):
            check_param_card.convert_to_slha1(opts['output'])
        return decay_info, particles, opts



    def run_madspace_decay_widths(self, decay_dir, precision):
        """Integrate the decays of an mg7 output with madspace, in a process of
        its own (see launch.compute_decay_widths), and return their widths."""
        result_file = pjoin(decay_dir, 'decay_widths.json')
        log_file = pjoin(decay_dir, 'decay_widths.log')
        cmd = [sys.executable, pjoin(decay_dir, 'bin', 'generate_events'),
               '--decay-widths=%s' % result_file, '--precision=%s' % precision]
        if self.options['nb_core']:
            cmd.append('--nb-core=%s' % self.options['nb_core'])
        with open(log_file, 'w') as log:
            returncode = subprocess.call(cmd, cwd=decay_dir, stdout=log,
                                         stderr=subprocess.STDOUT,
                                         stdin=subprocess.DEVNULL)
        if returncode:
            with open(log_file) as log:
                tail = ''.join(log.readlines()[-15:])
            raise MadGraph5Error('madspace failed to integrate the decays '
                                 '(exit status %s):\n%s' % (returncode, tail))
        with open(result_file) as fin:
            return json.load(fin)

    def integrate_widths_madspace(self, opts, decay_info):
        """Integrate the N-body decays of self._curr_amps with madspace.

        Counterpart of the MadEvent integration of do_compute_widths: the
        amplitudes of the decay_diagram command are written as an mg7 output
        and its survey (madspace) gives the partial widths. One output
        directory per decaying particle, since a madspace decay directory has a
        single decaying mass. The partial widths are added to a copy of
        decay_info (the same {pid: [[decay products, width], ...]} the
        two-body formulas fill), which is returned: when a particle fails
        after others succeeded, the caller still has the decay_info it would
        hand to MadEvent.
        """
        from madgraph.iolibs.template_files.mg7 import bootstrap as mg7_bootstrap
        # the survey of a decay uses no PDF: only the build needs the environment
        self.setup_mg7_environment(lhapdf=False)
        mg7_bootstrap.ensure_madspace(interactive=False,
                                      jobs=self.options['nb_core'])
        decay_info = copy.deepcopy(decay_info)

        amps_by_pid = collections.OrderedDict()
        for amp in self._curr_amps:
            pid = abs(amp.get('process').get('legs')[0].get('id'))
            amps_by_pid.setdefault(pid, []).append(amp)

        all_amps = self._curr_amps
        start = time.time()
        try:
            for pid, amps in amps_by_pid.items():
                self._curr_amps = diagram_generation.AmplitudeList(amps)
                # 'output' only builds the matrix elements when there are none:
                # without this every particle after the first would export the
                # matrix elements of the previous one
                self._curr_matrix_elements = helas_objects.HelasMultiProcess()
                particle = self._curr_model.get_particle(pid)
                with misc.TMP_directory(dir=os.getcwd()) as path:
                    decay_dir = pjoin(path, 'temp_decay')
                    with misc.MuteLogger(['madgraph','ALOHA','cmdprint','madevent',
                                          'madgraph7'], [40]*5):
                        self.exec_cmd('output mg7 %s -f' % decay_dir, child=False)
                        # the param_card to use is the one of the madevent run
                        if os.path.exists(opts['output']):
                            files.cp(opts['output'], pjoin(decay_dir, 'Cards', 'param_card.dat'))
                        else:
                            files.cp(opts['path'], pjoin(decay_dir, 'Cards', 'param_card.dat'))
                        if self._curr_model['name'] == 'mssm' or self._curr_model['name'].startswith('mssm-'):
                            check_param_card.convert_to_slha1(pjoin(decay_dir, 'Cards', 'param_card.dat'))
                        results = self.run_madspace_decay_widths(
                            decay_dir, float(opts['precision_channel']))

                # one entry per final state: a decay can come in several flavour
                # assignments or subprocesses
                partial = collections.OrderedDict()
                for res in results:
                    key = tuple(sorted(res['outgoing']))
                    partial[key] = partial.get(key, 0.) + res['width']
                total = sum(partial.values())
                error = sum(res['error']**2 for res in results) ** 0.5
                logger_mg.info('%s: width from the N-body decays = %.5g +- %.2g GeV',
                               particle.get('name'), total, error)
                if pid not in decay_info:
                    decay_info[pid] = []
                for decay_to, width in partial.items():
                    if 0 < width < 0.1 and particle['color'] != 1:
                        logger.warning("partial width of particle %s lower than QCD scale:%s. Set it to zero. (%s)" \
                                       % (particle.get('name'), width, list(decay_to)))
                        continue
                    decay_info[pid].append([list(decay_to), width])
        finally:
            self._curr_amps = all_amps
            self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        logger_mg.debug('madspace widths computed in %.1f s', time.time() - start)
        return decay_info

    @staticmethod
    def has_smwidth(model):
        """Does the model come with SMWidth, the dedicated code (HDECAY) of the
        NLO widths of the Standard Model?"""
        return os.path.exists(pjoin(model.get('modelpath'), 'SMWidth'))

    def compute_widths_nlo(self, particles, opts, decay_info, model, decaymodel=None):
        """NLO widths of the two-body decays, with MC@NLO (aMC@NLO at fixed
        order). Used by 'compute_widths --nlo' when the model has no dedicated
        code for it (SMWidth), or with '--corrections'.

        ``decay_info`` holds the LO widths. The corrections are those of
        opts['corrections']: QCD (the default), QED (the electroweak ones), or both.
        A two-body decay is run at NLO and its width replaced when it has a QCD
        correction -- a colour charge in the decaying particle or in a decay product
        -- or, with the electroweak corrections, always: every decay has one. The
        decays into three bodies or more stay at LO, which is what '--body_decay=3'
        asks for with '--nlo'. The param_card is rewritten with the sums.

        A decay that cannot be run (a model without loop information, ...) keeps
        its LO width, with a warning. Returns the new decay_info."""

        corrections = (opts.get('corrections') or 'QCD').split('+')
        if 'QED' in corrections and 'QED' not in (self._curr_model.get('perturbation_couplings') or []):
            logger.warning('The model has no QED loop information: the electroweak '
                'corrections are computed with the loop model MG finds for it '
                '(loop_qcd_qed_sm), whose electroweak input scheme and parameters may '
                'not be those of the card. Load a model with loop information '
                '(loop_qcd_qed_sm, loop_qcd_qed_sm_Gmu) to choose them.')
        channels = []
        for pid in particles:
            decaying = model.get_particle(pid)
            for index, (decay_to, width) in enumerate(decay_info.get(pid, [])):
                if len(decay_to) != 2 or not width:
                    continue
                products = [model.get_particle(abs(code)) for code in decay_to]
                if 'QED' not in corrections and \
                        all(p.get('color') == 1 for p in [decaying] + products):
                    continue # no QCD correction
                channels.append((pid, index, tuple(decay_to)))
        if not channels:
            logger_mg.info('None of the two-body decays has a %s correction: '
                           'the widths are the LO ones.', '+'.join(corrections))
            return decay_info

        orders = self.two_body_born_orders(sorted(set(pid for pid, _, _ in channels)),
                                           opts, decaymodel)
        model_ref = self._curr_model.get('modelpath+restriction')
        param_card = opts['output'] if os.path.exists(opts['output']) else opts['path']
        precision = float(opts['precision_channel'])

        with misc.MuteLogger(['madgraph'], [40]):
            default_names = base_objects.Model.load_default_name()

        def process_line(pid, decay_to):
            names = [self.particle_name(model, pid, default_names)] + \
                    [self.particle_name(model, code, default_names) for code in decay_to]
            born = orders.get((pid, tuple(sorted(decay_to))))
            if born is None:
                raise MadGraph5Error('no tree-level diagram for this decay')
            hierarchy = self._curr_model.get('order_hierarchy') or {'QCD': 1, 'QED': 2}
            born = ' '.join('%s=%d' % (name, born.get(name, 0)) for name in hierarchy)
            return '%s > %s %s %s [%s]' % (names[0], names[1], names[2], born,
                                           ' '.join(corrections))

        # Flavours the model treats alike (u and c, d and s, W > u d~ and W > c s~
        # in the SM) have the same LO width to the last digit and the same NLO
        # width: run one of them. The same decaying particle, the same colours,
        # masses and charges of the decay products, and the same LO width.
        # The electroweak corrections also see the isospin partner of the decay
        # products, in the loops: the b, whose partner is the top quark, is not a d
        # (Z > b b~ is 1.5% lower than Z > d d~ at NLO EW). Only the light quarks of
        # a type, and the leptons and the neutrinos of the three families, are taken
        # as alike for them; any other particle has its own run.
        def kind(code):
            code = abs(code)
            for name, codes in (('d', (1, 3)), ('u', (2, 4)), ('l', (11, 13, 15)),
                                ('v', (12, 14, 16))):
                if code in codes:
                    return name
            return code

        def signature(channel):
            pid, index, decay_to = channel
            products = [model.get_particle(abs(code)) for code in decay_to]
            flavours = tuple(sorted(str(kind(code)) for code in decay_to)) \
                       if 'QED' in corrections else ()
            return (pid, tuple(sorted((p.get('color'), str(p.get('mass')), p.get('charge'))
                                      for p in products)), flavours,
                    float('%.9g' % decay_info[pid][index][1]))

        signatures = [signature(channel) for channel in channels]
        unique = []
        for number, sig in enumerate(signatures):
            if sig not in [signatures[first] for first in unique]:
                unique.append(number)
        workers = max(1, min(len(unique), 4))
        cores = max(1, (self.options['nb_core'] or os.cpu_count() or 1) // workers)

        logger_mg.info('NLO %s width of %d two-body decay(s) with MC@NLO (%d run(s)) ...',
                       '+'.join(corrections), len(channels), len(unique))
        start = time.time()
        with misc.TMP_directory(dir=os.getcwd()) as path:
            def run(number):
                pid, _, decay_to = channels[number]
                try:
                    return self.run_mcatnlo_width(
                        pjoin(path, 'nlo_%d' % number), process_line(pid, decay_to),
                        model_ref, param_card, precision, cores)
                except Exception as error:
                    return error

            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                done = dict(zip(unique, pool.map(run, unique)))
        outcomes = [done[next(first for first in unique if signatures[first] == sig)]
                    for sig in signatures]

        decay_info = copy.deepcopy(decay_info)
        for (pid, index, decay_to), outcome in zip(channels, outcomes):
            name = '%s > %s' % (self.particle_name(model, pid, default_names),
                    ' '.join(self.particle_name(model, code, default_names)
                             for code in decay_to))
            lo = decay_info[pid][index][1]
            if isinstance(outcome, Exception):
                logger.warning('NLO width of %s failed (%s): the LO width %.5g GeV is kept.',
                               name, outcome, lo)
                continue
            width, error = outcome
            logger_mg.info('NLO width of %s: %.5g +- %.2g GeV (LO %.5g GeV, NLO/LO = %.3f)',
                           name, width, error, lo, width / lo)
            decay_info[pid][index][1] = width
        logger_mg.debug('NLO widths computed in %.1f s', time.time() - start)

        madevent_interface.MadEventCmd.update_width_in_param_card(
                                      decay_info, opts['output'], opts['output'])
        return decay_info

    @staticmethod
    def particle_name(model, code, default=None):
        """The name of the particle of pdg code ``code`` (negative: the antiparticle)
        in the MG convention (mu-, ta+, ...), which is the one of a session that imports
        the model: the NLO runs generate their process in such a session, whereas
        the model of the decays keeps the names of the UFO (m-, tt+). ``default`` is
        the table of these names, read when it is not given."""
        if default is None:
            with misc.MuteLogger(['madgraph'], [40]):
                default = base_objects.Model.load_default_name()
        if code in default:
            return default[code]
        particle = model.get_particle(abs(code))
        return particle.get('name') if code > 0 else particle.get('antiname')

    def two_body_born_orders(self, pids, opts, decaymodel=None):
        """The coupling orders of the tree-level two-body decays of the particles
        ``pids``: {(pid, sorted decay products): {'QED': 1}}. The NLO process
        needs them, 'generate t > w+ b [QCD]' cannot guess them."""
        all_amps = self._curr_amps
        try:
            self.do_decay_diagram('%s --body_decay=2 --path=%s' % (
                  ' '.join(str(pid) for pid in pids), opts['path']),
                  skip_2body=False, model=decaymodel or self._widths_decaymodel)
            orders = {}
            for amp in self._curr_amps:
                legs = amp.get('process').get('legs')
                key = (abs(legs[0].get('id')), tuple(sorted(l.get('id') for l in legs[1:])))
                orders[key] = dict(amp.get('diagrams')[0].get('orders'))
        finally:
            self._curr_amps = all_amps
        return orders

    def run_mcatnlo_width(self, workdir, process, model_ref, param_card, precision, nb_core):
        """The NLO (QCD) partial width of a decay, with aMC@NLO at fixed order:
        'process' is generated with its [QCD] correction, exported, and run, in
        processes of their own. ``param_card`` gives the values of the
        parameters. Returns the width and its error, in GeV."""
        os.makedirs(workdir)
        proc_dir = pjoin(workdir, 'PROC_NLO')

        def run(cmd, log_name):
            log_path = pjoin(workdir, log_name)
            with open(log_path, 'w') as log:
                returncode = subprocess.call(cmd, cwd=workdir, stdout=log,
                                             stderr=subprocess.STDOUT,
                                             stdin=subprocess.DEVNULL)
            with open(log_path) as log:
                text = log.read()
            if returncode or re.search(r'Error detected|interrupted with error|Traceback', text):
                lines = [l.strip() for l in text.splitlines() if l.strip()]
                # the error of MG, 'InvalidCmd : ...', or the last line
                message = next((l for l in reversed(lines)
                                if re.match(r'\w*(Error|Exception|Cmd)\w* ?:', l)),
                               lines[-1] if lines else 'exit status %s' % returncode)
                raise MadGraph5Error('%s (%s)' % (message, log_path))
            return text

        script = pjoin(workdir, 'generate.mg5')
        with open(script, 'w') as fsock:
            fsock.write('set automatic_html_opening False --no_save\n')
            fsock.write('set nb_core %s --no_save\n' % nb_core)
            if aloha.complex_mass:
                fsock.write('set complex_mass_scheme True\n')
            # the gauge of the session, which a model such as loop_qcd_qed_sm needs
            gauge = self.options.get('gauge')
            if gauge and gauge not in ('unitary', 'default'):
                fsock.write('set gauge %s\n' % gauge)
            fsock.write('import model %s\n' % model_ref)
            fsock.write('generate %s\n' % process)
            fsock.write('output %s -f\n' % proc_dir)
        run([sys.executable, pjoin(MG5DIR, 'bin', 'madgraph'), script], 'generate.log')

        # the parameters of the user, in the card the loop model wrote
        card = pjoin(proc_dir, 'Cards', 'param_card.dat')
        check_param_card.merge_param_card_values(param_card, card)
        run_card = pjoin(proc_dir, 'Cards', 'run_card.dat')
        with open(run_card) as fsock:
            text = fsock.read()
        text = re.sub(r'(?m)^(\s*)[-\d.eE+]+(\s*=\s*req_acc_FO\b)',
                      lambda m: '%s%s%s' % (m.group(1), precision, m.group(2)), text)
        with open(run_card, 'w') as fsock:
            fsock.write(text)

        script = pjoin(workdir, 'launch.txt')
        with open(script, 'w') as fsock:
            fsock.write('set automatic_html_opening False --no_save\n')
            fsock.write('set nb_core %s --no_save\n' % nb_core)
            fsock.write('launch NLO -f\n')
        run([sys.executable, pjoin(proc_dir, 'bin', 'aMCatNLO'), script], 'launch.log')

        pattern = re.compile(r'\(Partial\) decay width:\s*([-+\d.eE]+)\s*\+-\s*([-+\d.eE]+)\s*GeV')
        for summary in sorted(glob.glob(pjoin(proc_dir, 'Events', '*', 'summary.txt')),
                              reverse=True):
            with open(summary) as fsock:
                found = pattern.search(fsock.read())
            if found:
                return float(found.group(1)), float(found.group(2))
        raise MadGraph5Error('no width in the results of aMC@NLO (%s)' % workdir)

    # Calculate decay width with SMWidth
    def compute_widths_SMWidth(self, line, model=None):
        """Compute widths with SMWidth.
        """

        # check the argument and return those in a dictionary format
        particles, opts = self.check_compute_widths(self.split_arg(line))

        if opts['path']:
            correct = True
            param_card = check_param_card.ParamCard(opts['path'])
            for param in param_card['decay']:
                if check_param_card.auto_width_options(param.value) is not None:
                    param.value = 1
                    param.format = 'float'
                    correct = False
            if not correct:
                if opts['output']:
                    param_card.write(opts['output'])
                    opts['path'] = opts['output']
                else:
                    param_card.write(opts['path'])

        if not model:
            model_path = self._curr_model.get('modelpath')
            model_name = self._curr_model.get('name')
            currmodel = self._curr_model
        else:
            model_path = model.get('modelpath')
            model_name = model.get('name')
            currmodel = model

        if not os.path.exists(pjoin(model_path, 'SMWidth')):
            raise self.InvalidCmd("Model %s is not valid for computing NLO width with SMWidth"%model_name)

        # determine the EW scheme
        externparam = [(param.lhablock.lower(),param.name.lower()) for param \
                           in currmodel.get('parameters')[('external',)]]

        if ('sminputs','aewm1') in externparam:
            # alpha(MZ) scheme
            arg2 = "1"
        elif ('sminputs','mdl_gf') in externparam or ('sminputs','gf') in externparam:
            # Gmu scheme
            arg2 = "2"
        else:
            raise Exception("Do not know the EW scheme in the model %s"%model_name)

        #compile the code
        if not os.path.exists(pjoin(model_path, 'SMWidth','smwidth')):
            logger.info('Compiling SMWidth. This has to be done only once and'+\
                            ' can take a couple of minutes.','$MG:BOLD')
            current = misc.detect_current_compiler(pjoin(model_path, 'SMWidth',
                                                         'makefile_MW5'))
            new = 'gfortran' if self.options_configuration['fortran_compiler'] is None else \
                self.options_configuration['fortran_compiler']
            if current != new:
                misc.mod_compilator(pjoin(model_path, 'SMWidth'), new, current)
                misc.mod_compilator(pjoin(model_path, 'SMWidth','oneloop'), new, current)
                misc.mod_compilator(pjoin(model_path, 'SMWidth','hdecay'), new, current)
            misc.compile(cwd=pjoin(model_path, 'SMWidth'))

        # look for the ident_card.dat
        carddir=os.path.dirname(opts['path'])
        has_ident = 'ident_card.dat' in os.listdir(carddir or '.')
        # smwidth keeps the path of the cards in 100 characters: with a longer one
        # it reads nothing and every width comes out as zero. It runs in its own
        # directory, on copies of the cards with short names.
        smdir = pjoin(model_path, 'SMWidth')
        copies = ['smwidth_card_%d.dat' % os.getpid()]
        files.cp(opts['path'], pjoin(smdir, copies[0]))
        identpath = " "
        if has_ident:
            copies.append('smwidth_ident_%d.dat' % os.getpid())
            files.cp(pjoin(carddir, 'ident_card.dat'), pjoin(smdir, copies[1]))
            identpath = copies[1]
        #run the code
        try:
            output,error = misc.Popen(['./smwidth', copies[0], identpath, arg2],
                                      stdout=subprocess.PIPE,
                                      stdin=subprocess.PIPE,
                                      cwd=smdir).communicate()
        finally:
            for name in copies:
                if os.path.exists(pjoin(smdir, name)):
                    os.remove(pjoin(smdir, name))
        pattern = re.compile(r'''  decay\s+(\+?\-?\d+)\s+(\+?\-?\d+\.\d+E\+?\-?\d+)''',re.I)
        width_list = pattern.findall(output.decode(errors='ignore'))
        if not width_list:
            raise MadGraph5Error('SMWidth returned no width:\n%s' %
                                 '\n'.join(output.decode(errors='ignore').splitlines()[-8:]))
        width_dict = {}
        for pid,width in width_list:
            width_dict[int(pid)] = float(width)

        decay_info = {}
        for pid in particles:
            if not pid in width_dict:
                width = 0
            else:
                width = width_dict[pid]
            # the total only: HDECAY does not give the channels
            decay_info[pid] = [[[], width]]
            param = param_card['decay'].get((pid,))
            param.value = width
            param.format = 'float'
            if pid == 25:
                refs=['hep-ph/9704448','arXiv:1801.09506 [hep-ph]']
                logger.info(" You are using program 'HDECAY', please cite refs: \033[92m%s\033[0m. " % ', '.join(refs), '$MG:BOLD')
            if pid not in param_card['decay'].decay_table:
                continue
            del param_card['decay'].decay_table[pid] # reset the BR
        # write the output file. (the new param_card)
        if opts['output']:
            param_card.write(opts['output'])
            logger.info('Results are written in %s' % opts['output'])
        else:
            param_card.write(opts['path'])
            logger.info('Results are written in %s' % opts['path'])
        return decay_info

    # Calculate decay width
    def do_decay_diagram(self, line, skip_2body=False,  model=None):
        """Not in help: Generate amplitudes for decay width calculation, with fixed
           number of final particles (called level)
           syntax; decay_diagram part_name level param_path
           args; part_name level param_path
           part_name = name of the particle you want to calculate width
           level = a.) when level is int,
                       it means the max number of decay products
                   b.) when level is float,
                       it means the required precision for width.
           param_path = path for param_card
           (this is necessary to determine whether a channel is onshell or not)
           e.g. calculate width for higgs up to 2-body decays.
           calculate_width h 2 [path]
           N.B. param_card must be given so that the program knows which channel
           is on shell and which is not.

           special argument:
               - skip_2body: allow to not consider those decay (use FR)
               - model: use the model pass in argument.
        """

        if model:
            self._curr_decaymodel = model


        args = self.split_arg(line)
        #check the validity of the arguments
        particles, args = self.check_decay_diagram(args)
        #print args
        pids = particles
        level = float(args['body_decay'])
        param_card_path = args['path']
        min_br = float(args['min_br'])

        # Reset amplitudes
        self._curr_amps = diagram_generation.AmplitudeList()
        self._curr_proc_defs = base_objects.ProcessDefinitionList()
        # Reset Helas matrix elements
        self._curr_matrix_elements = helas_objects.HelasMultiProcess()
        # Reset _done_export, since we have new process
        self._done_export = False
        # Also reset _export_format and _export_dir
        self._export_format = None


        # Setup before find_channels
        if not model:
            self._curr_decaymodel = decay_objects.DecayModel(self._curr_model,
                                                         True)
            self._curr_decaymodel.read_param_card(param_card_path)
        else:
            self._curr_decaymodel = model
        model = self._curr_decaymodel

        if  isinstance(pids, int):
            pids = [pids]

        first =True
        for part_nb,pid in enumerate(pids):
            part = self._curr_decaymodel.get_particle(pid)
            if part.get('width').lower() == 'zero':
                continue
            logger_mg.info('get decay diagram for %s' % part['name'])
            # Find channels as requested
            if level // 1 == level and level >1:
                level = int(level)
                self._curr_decaymodel.find_channels(part, level, min_br)
                if not skip_2body:
                    amp = part.get_amplitudes(2)
                    if amp:
                        self._curr_amps.extend(amp)

                for l in range(3, level+1):
                    amp = part.get_amplitudes(l)
                    if amp:
                        self._curr_amps.extend(amp)
            else:
                max_level = level // 1
                if max_level < 2:
                    max_level = 999
                precision = level % 1
                if first:
                    model.find_all_channels(2,generate_abstract=False)
                    first = False
                if not skip_2body:
                    amp = part.get_amplitudes(2)
                    if amp:
                        self._curr_amps.extend(amp)
                clevel = 2
                while part.get('apx_decaywidth_err').real > precision:
                    clevel += 1
                    if clevel > max_level:
                        logger_mg.info('    stop to %s body-decay. approximate error: %s' %
                                   (max_level, part.get('apx_decaywidth_err')) )
                        break
                    if clevel > 3:
                        logger_mg.info('    current estimated error: %s go to %s-body decay:' %\
                                        (part.get('apx_decaywidth_err'), clevel))
                    part.find_channels_nextlevel(model, min_br)
                    #part.group_channels_2_amplitudes(clevel, model, min_br)
                    amp = part.get_amplitudes(clevel)
                    if amp:
                        self._curr_amps.extend(amp)
                    part.update_decay_attributes(False, True, True, model)


        # Set _generate_info
        if len(self._curr_amps) > 0:
            process = self._curr_amps[0]['process'].nice_string()
            #print process
            self._generate_info = process[9:]
            #print self._generate_info
        elif skip_2body:
            logger.info("No three body-decay (or higher) is found for %s", pids) 
        else:
            logger.info("No decay is found for %s", pids)

class MadGraphCmdWeb(CheckValidForCmdWeb, MadGraphCmd):
    """Temporary parser"""

#===============================================================================
# Command Parser
#===============================================================================
# DRAW
_draw_usage = "draw FILEPATH [options]\n" + \
         "-- draw the diagrams in eps format\n" + \
         "   Files will be FILEPATH/diagrams_\"process_string\".eps \n" + \
         "   Example: draw plot_dir . \n"
_draw_parser = misc.OptionParser(usage=_draw_usage)
_draw_parser.add_option("", "--horizontal", default=False,
                   action='store_true', help="force S-channel to be horizontal")
_draw_parser.add_option("", "--external", default=0, type='float',
                    help="authorizes external particles to end at top or " + \
                    "bottom of diagram. If bigger than zero this tune the " + \
                    "length of those line.")
_draw_parser.add_option("", "--max_size", default=1.5, type='float',
                         help="this forbids external line bigger than max_size")
_draw_parser.add_option("", "--non_propagating", default=True, \
                          dest="contract_non_propagating", action='store_false',
                          help="avoid contractions of non propagating lines")
_draw_parser.add_option("", "--add_gap", default=0, type='float', \
                          help="set the x-distance between external particles")
_draw_parser.add_option("", "--no_open", default=False,
                          action='store_true',
                          help="save diagrams without opening them (requires an explicit directory)")
_draw_parser.add_option("", "--merge", default=False,
                          action='store_true',
                          help="merge all diagram .eps files into a single PDF file using ghostscript (requires an explicit directory)")

_display_text_usage = "display diagrams_text [DIRPATH] [options]\n" + \
         "-- write the diagrams in text format\n" + \
         "   Files will be DIRPATH/diagrams_\"process_string\".txt \n" + \
         "   Example: display diagrams_text . \n"
_display_text_parser = misc.OptionParser(usage=_display_text_usage)
_display_text_parser.add_option("", "--no_open", default=False,
                          action='store_true',
                          help="save the diagrams without opening the pager (requires an explicit directory)")
_display_text_parser.add_option("", "--merge", default=False,
                          action='store_true',
                          help="merge all diagram .txt files into all_diagrams_text.txt (requires an explicit directory)")

_draw_parser.add_option("", "--generate_only", default=False, action='store_true', \
                          help="forbid to display the generate file and only generate the eps file")
# LAUNCH PROGRAM
_launch_usage = "launch [DIRPATH] [options]\n" + \
         "-- execute the madevent/standalone/standalone_fortran/pythia8/NLO output present in DIRPATH\n" + \
         "   By default DIRPATH is the latest created directory \n" + \
         "   (for pythia8, it should be the Pythia 8 main directory) \n" + \
         "   Example: launch PROC_sm_1 --name=run2 \n" + \
         "   Example: launch ../pythia8 \n"
_launch_parser = misc.OptionParser(usage=_launch_usage)
_launch_parser.add_option("-f", "--force", default=False, action='store_true',
                                help="Use the card present in the directory in order to launch the different program")
_launch_parser.add_option("-n", "--name", default='', type='str',
                                help="Provide a name to the run (for madevent run)")
_launch_parser.add_option("-c", "--cluster", default=False, action='store_true',
                                help="submit the job on the cluster")
_launch_parser.add_option("-m", "--multicore", default=False, action='store_true',
                                help="submit the job on multicore core")

_launch_parser.add_option("-i", "--interactive", default=False, action='store_true',
                                help="Use Interactive Console [if available]")
_launch_parser.add_option("-s", "--laststep", default='',
                                help="last program run in MadEvent run. [auto|parton|pythia|pgs|delphes]")
_launch_parser.add_option("-R", "--reweight", default=False, action='store_true',
                            help="Run the reweight module (reweighting by different model parameter")
_launch_parser.add_option("-M", "--madspin", default=False, action='store_true',
                            help="Run the madspin package")
_launch_parser.add_option("", "--timings", default=0, type='int',
                            help="[standalone_fortran] Number of SMATRIX calls per flavor per run for timing analysis (0=disabled)")
_launch_parser.add_option("", "--nb_run", default=1, type='int',
                            help="[standalone_fortran] Number of timing repetitions for statistics (used with --timings); 0 = good-helicity check (print matrix-element values instead of a timing table)")
_launch_parser.add_option("", "--energy", default=0, type='float',
                            help="[FKS standalone] sqrt(s) of the phase-space point (0=built-in default)")

#===============================================================================
# Interface for customize question.
#===============================================================================
class RestrictionExplainer(object):
    """Evaluates the couplings/parameters of a model for the choices made so
    far at the customize_model question and reports what changed since the
    previous call, so that 'customize_model --explain' gives a live feedback
    after each command instead of only a report at the end.

    It only reads values (one evaluation of the couplings per call): it can not
    change the model which is being built."""

    def __init__(self, cmd, model_path, default_card, externals, categories):

        self.cmd = cmd
        self.externals = externals
        self.model = model_reader.ModelReader(
                        import_ufo.import_model(model_path, restrict=False))
        # the values which would be simplified by accident are randomized, as
        # they are for the real restriction
        self.unrestricted = check_param_card.ParamCard(default_card)
        cmd.randomize_param_card(self.unrestricted, externals)

        # the starting point is the question as it opens, i.e. the default
        # value of the options, not the unrestricted model
        self.state = self.evaluate(self.apply(categories, [], [], []))
        cmd.log_report_banner('Restriction report (live): the default choices of'
                              ' this model already drop %d coupling(s), fuse %d'
                              ' and restrict %d parameter(s).'
                              % tuple(len(entries) for entries in self.state))
        logger.info(' Each command you enter is followed by what it changes.',
                    '$MG:color:GREEN')
        MadGraphCmd.log_report_banner()

    def apply(self, categories, set_zero, set_one, set_equal):
        """the param_card for the choices made so far"""

        param_card = check_param_card.ParamCard(self.unrestricted)
        self.cmd.apply_customize_rules(param_card, categories, set_zero,
                        set_one, self.cmd.resolve_set_equal(set_equal))
        return param_card

    def evaluate(self, param_card):
        """(dropped couplings, fused couplings, parameters leaving the card)"""

        zero, fused = self.cmd.get_coupling_classes(self.model, param_card)
        dropped, merged = self.cmd.get_parameter_classes(param_card,
                                                         self.externals)
        return zero, fused, dropped | merged

    def update(self, categories, set_zero, set_one, set_equal, lha2name=None):
        """evaluate the choices made so far and log what the last command
        changed"""

        new = self.evaluate(self.apply(categories, set_zero, set_one, set_equal))
        self.report(self.state, new, lha2name or {})
        self.state = new

    def report(self, old, new, lha2name):
        """the difference between two states, in plain words"""

        old_zero, old_fused, old_param = old
        new_zero, new_fused, new_param = new

        def name(key):
            if not isinstance(key, tuple):
                return str(key)
            return MadGraphCmd.name_of_lha(lha2name, key)

        changes = [('+', new_zero - old_zero, 'coupling(s) dropped'),
                   ('-', old_zero - new_zero, 'coupling(s) back in the model'),
                   ('+', new_fused - old_fused, 'coupling(s) fused'),
                   # a coupling which is now dropped is not 'fused' anymore:
                   # reporting it a second time would only be confusing
                   ('-', (old_fused - new_fused) - new_zero,
                    'coupling(s) not fused anymore'),
                   ('+', new_param - old_param,
                    'parameter(s) restricted (set to 0/1 or merged)'),
                   ('-', old_param - new_param,
                    'parameter(s) free again')]

        changed = False
        for sign, entries, title in changes:
            if not entries:
                continue
            changed = True
            logger.info('  %s%d %s: %s' % (sign, len(entries), title,
                        self.cmd.short_list([name(key) for key in entries])),
                        '$MG:color:GREEN' if sign == '+' else '$MG:color:BLUE')
        if not changed:
            logger.info('  no change on the couplings/parameters of the model',
                        '$MG:color:BLACK')


class AskforModelName(cmd.SmartQuestion):
    """Ask for a (free text) model name. The only reason for this class to
    exist is that a question with no pre-defined answer is otherwise not
    scriptable (any line of the script would be refused)."""

    name_pattern = re.compile(r'^\w+$')

    def special_check_answer_in_input_file(self, line, default):
        # only accept something which can be a model name: a script which does
        # not answer this question must not have its next command swallowed
        line = line.strip()
        if self.name_pattern.match(line):
            return line
        return None


class AskforCustomize(cmd.SmartQuestion):
    """A class for asking a question where in addition you can have the
    set command define and modifying the param_card/run_card correctly"""

    def __init__(self, question, allow_arg=[], default=None,
                                            mother_interface=None, *arg, **opt):

        categories = opt.pop('categories', None)

        model = mother_interface._curr_model
        model_path = model.get('modelpath')
        # the UFO objects are used (and not the MG5 ones) since the user knows
        # the model under that form (no 'mdl_' prefix, ...)
        ufo_model = ufomodels.load_model(model_path)
        #2) Import the option available in the model
        if categories is None:
            categories = ufo_model.build_restrict.all_categories
        self.all_categories = categories

        self.external_params = dict((param.name.lower(), param)
                                    for param in ufo_model.all_parameters
                                    if param.nature == 'external')
        self.internal_params = dict((param.name.lower(), param)
                                    for param in ufo_model.all_parameters
                                    if param.nature != 'external')
        self.ufo_couplings = dict((coupling.name.lower(), coupling)
                                  for coupling in ufo_model.all_couplings)
        # (lhablock, lhacode) -> name, to display a parameter as the user knows it
        self.lha2name = MadGraphCmd.get_lha2name(model_path)

        # the customizations which are not a simple on/off switch
        self.set_zero = []    # [(lhablock, lhacode)]
        self.set_one = []     # [(lhablock, lhacode)]
        self.set_equal = []    # [((lhablock, lhacode), (lhablock, lhacode))]
        self.new_formula = [] # [(parameter name, expression)]
        self.new_coupling = []# [(coupling name, expression)]
        self.formula_target = {} # parameter name -> (lhablock, lhacode)
        self._identifiable = None # cache for the set_equal completion
        # where the value of a parameter comes from. By default the model as it
        # was loaded (baseline_card), otherwise what 'set default' asked for
        self.baseline_card = opt.pop('baseline_card', None)
        self.default_source = None      # None, 'ufo', or the path of a card
        self.default_card_values = None # that card, parsed
        self.default_values = {}        # (lhablock, lhacode) -> value
        # customize_model --explain: report each command as it is entered
        self.explainer = opt.pop('explainer', None)
        # the restriction the model was loaded with is where the question
        # starts: its zeros, ones and merged parameters as rules, so that
        # `done` rebuilds that very model and `set NAME free` releases one
        self.loaded_restriction = None
        self.start_from_restriction(opt.pop('loaded_card', None),
                                    opt.pop('loaded_name', None))

        question = self.get_question()
        # determine the possible value and how they are linked to the restriction
        #options.
        allow_arg = ['0']
        self.name2options = {}
        for category in self.all_categories:
            for options in category:
                if not options.first:
                    continue
                self.name2options[str(len(allow_arg))] = options
                self.name2options[options.name.replace(' ','')] = options
                allow_arg.append(len(allow_arg))
        allow_arg.append('done')

        cmd.SmartQuestion.__init__(self, question, allow_arg, default, mother_interface)

    @property
    def answer(self):
        """what do_customize_model gets back from ask(). The value returned by
        cmdloop() in interactive mode, so that a scripted answer (which does
        not go through cmdloop) returns the very same object."""
        return self.all_categories

    @property
    def question(self):
        """The question is fully derived from the current state, so it is
        rebuilt on every read: a command answered from a script never goes
        through reask(), and would otherwise be shown the state of the
        question as it was before any of the commands ran."""
        return self.get_question()

    @question.setter
    def question(self, value):
        pass # derived, see above

    def default(self, line):
        """Default action if line is not recognized"""

        line = line.strip()
        args = line.split()
        if line == '' and self.default_value is not None:
            self.value = self.default_value
        # check if input is a command
        elif args and hasattr(self, 'do_%s' % args[0]):
            getattr(self, 'do_%s' % args[0])(' '.join(args[1:]))
        elif line.strip() != '0' and line.strip() != 'done' and \
            str(line) != 'EOF' and line.strip() in self.allow_arg:
            option = self.name2options[line.strip()]
            if isinstance(option, build_restrict_lib.ChoiceOption):
                option.next_status()
            else:
                option.status = not option.status
            self.value = 'repeat'
            self.explain_change()
        else:
            self.value = line

        return self.all_categories

    def reask(self, reprint_opt=True, line=None):
        """ """
        reprint_opt = True
        cmd.SmartQuestion.reask(self, reprint_opt, line=line)

    def do_set(self, line):
        """set one of the options of the question, or -when the first argument
        is a parameter of the model- a shortcut for the set_zero/set_one/
        set_equal commands: 'set yt 0', 'set yt 1', 'set yt = yb'"""

        self.value = 'repeat'

        # 'set yt = yb', 'set yt= yb' and 'set yt=yb' are the same thing
        args = re.sub(r'\s*=\s*', ' = ', line).split()
        if not args:
            logger.warning('Invalid set command. Syntax is: set NAME VALUE')
            return

        if args[0].lower() == 'default':
            return self.set_default(args[1:])
        if args[0] in self.name2options:
            return self.set_option(args)
        if len(args) >= 2 and args[1].lower() == 'all' \
                          and self.get_block_parameters(args[0]):
            return self.set_parameter(args)
        if args[0].lower() in self.external_params or \
                                    args[0].lower() in self.internal_params:
            return self.set_parameter(args)

        logger.warning('Invalid set command: %s is neither one of the options '
                       'nor a parameter of the model.\n  Valid options are: %s',
                       args[0], ', '.join(x for x in self.name2options
                                                        if not x.isdigit()))

    def set_option(self, args):
        """set NAME VALUE where NAME is one of the options of the question"""

        if len(args) != 2:
            logger.warning('Invalid set command. Not correct number of argument')
            return

        option = self.name2options[args[0]]
        if isinstance(option, build_restrict_lib.ChoiceOption):
            try:
                option.set_status(args[1])
            except ValueError as error:
                logger.warning(str(error))
            else:
                self.explain_change()
            return

        if args[1] in ['True','1','.true.','T',1,True,'true','TRUE']:
            option.status = True
        elif args[1] in ['False','0','.false.','F',0,False,'false','FALSE']:
            option.status = False
        else:
            logger.warning('%s is not True/False. Didn\'t do anything.' % args[1])
            return
        self.explain_change()

    def set_default(self, args):
        """'set default UFO', 'set default PATH' and 'set default NAME [=] VALUE'
        choose where the values written in the param_card come from. They are
        the values of the model, not a restriction: use set_zero/set_one to
        remove a parameter from the model."""

        if not args:
            logger.warning('Invalid set default command. Syntax is: '
                'set default UFO | PATH | NAME [=] VALUE')
            return

        if len(args) == 1:
            # both forms start from scratch: they undo every 'set default'
            # entered before them
            if args[0].lower() == 'ufo':
                self.default_source = 'ufo'
                self.default_card_values = None
                self.default_values = {}
                logger.info('Default values taken from the UFO model.')
                return
            if not os.path.isfile(args[0]):
                logger.warning('%s is neither \'UFO\' nor a file. Syntax is: '
                    'set default UFO | PATH | NAME [=] VALUE', args[0])
                return
            try:
                card = check_param_card.ParamCard(args[0])
            except Exception as error:
                logger.warning('%s is not a valid param_card: %s', args[0], error)
                return
            self.default_source = args[0]
            self.default_card_values = card
            self.default_values = {}
            logger.info('Default values taken from %s (for the parameters it '
                        'defines, the ones of the model for the others).', args[0])
            return

        keys, value = self.resolve_parameters(args)
        if keys is None:
            return
        if value and value[0] == '=':
            value = value[1:]
        if len(value) != 1:
            logger.warning('Invalid set default command. Syntax is: '
                'set default UFO | PATH | NAME [=] VALUE (NAME can also be '
                '\'BLOCK all\')')
            return
        try:
            value = float(value[0])
        except ValueError:
            logger.warning('%s is not a number. Syntax is: '
                           'set default NAME [=] VALUE', value[0])
            return
        for key in keys:
            self.default_values[key] = value

    def get_default_value(self, param):
        """the value a parameter will get: what 'set default' asked for, then
        the model as it was loaded, then the UFO"""

        key = (param.lhablock, tuple(param.lhacode))
        if key in self.default_values:
            return self.default_values[key]
        cards = [self.default_card_values]
        if self.default_source != 'ufo':
            cards.append(self.baseline_card)
        for card in cards:
            if card is None:
                continue
            value = card.get_value(param.lhablock.lower(),
                                   tuple(param.lhacode), default='__not_set__')
            if value != '__not_set__':
                return value
        return param.value

    def set_parameter(self, args):
        """'set NAME 0', 'set NAME 1' and 'set NAME = OTHER' are the same as
        set_zero/set_one/set_equal. NAME can also be 'BLOCK all'."""

        keys, value = self.resolve_parameters(args)
        if keys is None:
            return
        if value and value[0] == '=':
            value = value[1:]
        if len(value) != 1:
            logger.warning('Invalid set command. For a parameter the syntax is:'
                ' set NAME 0 / set NAME 1 / set NAME = OTHERNAME / set NAME '
                'free (NAME can be \'BLOCK all\' for the 0, 1 and free forms)')
            return
        value = value[0]
        if value == '0':
            self.apply_restriction(keys, 0)
        elif value == '1':
            self.apply_restriction(keys, 1)
        elif value.lower() == 'free':
            # back to the value it starts from: undoes one rule, where `clear`
            # would undo every one of them
            for key in keys:
                self.forget_parameter(key)
            self.explain_change()
        elif value.lower() in self.external_params:
            if len(keys) > 1:
                logger.warning('A whole block can only be set to 0 or to 1, '
                               'not to the value of another parameter.')
                return
            self.do_set_equal('%s %s' % (args[0], value))
        else:
            logger.warning('%s can only be set to 0, to 1, to the value of '
                'another external parameter, or free (\'%s\' is none of '
                'them).', args[0], value)

    #===========================================================================
    # customization of a single parameter/coupling
    #===========================================================================
    def get_external_parameter(self, name):
        """return the (lhablock, lhacode) of an external parameter of the model
        (None if the parameter is not a valid external parameter)"""

        param = self.external_params.get(name.lower(), None)
        if param is None:
            if name.lower() in self.internal_params:
                logger.warning('%s is an internal parameter of the model. Only '
                    'external parameters (i.e. parameters of the param_card) '
                    'can be restricted.', name)
            else:
                logger.warning('%s is not a parameter of this model.', name)
            return None
        return (param.lhablock, tuple(param.lhacode))

    def get_block_parameters(self, name):
        """the external parameters of a block of the param_card, None when name
        is not one of its blocks"""

        params = [param for param in self.external_params.values()
                  if param.lhablock.lower() == name.lower()]
        return params or None

    def resolve_parameters(self, args):
        """what a designation refers to, as a list of (lhablock, lhacode): the
        name of a parameter, or 'BLOCK all' for every parameter of a block.
        Return it with the arguments which are left."""

        if not args:
            return None, args
        if len(args) >= 2 and args[1].lower() == 'all':
            params = self.get_block_parameters(args[0])
            if params is None:
                logger.warning('%s is not a block of the param_card of this '
                               'model.', args[0])
                return None, args[2:]
            return [(param.lhablock, tuple(param.lhacode))
                    for param in params], args[2:]
        key = self.get_external_parameter(args[0])
        if key is None:
            return None, args[1:]
        return [key], args[1:]

    def apply_restriction(self, keys, value):
        """fix a list of parameters to zero or to one"""

        for key in keys:
            self.forget_parameter(key)
            # forget_parameter rebinds the lists, so they are read back here
            if value:
                self.set_one.append(key)
            else:
                self.set_zero.append(key)
        self.explain_change()

    def do_set_zero(self, line):
        """set an external parameter -or a whole block- of the model to zero"""

        self.value = 'repeat'
        keys, rest = self.resolve_parameters(line.split())
        if keys is None:
            return
        if rest:
            logger.warning('Invalid set_zero command. Syntax is: '
                           'set_zero NAME | BLOCK all')
            return
        self.apply_restriction(keys, 0)

    def do_set_one(self, line):
        """set an external parameter -or a whole block- of the model to one"""

        self.value = 'repeat'
        keys, rest = self.resolve_parameters(line.split())
        if keys is None:
            return
        if rest:
            logger.warning('Invalid set_one command. Syntax is: '
                           'set_one NAME | BLOCK all')
            return
        self.apply_restriction(keys, 1)

    def do_set_equal(self, line):
        """force an external parameter to take the value of another one"""

        self.value = 'repeat'
        args = line.split()
        if len(args) != 2:
            logger.warning('Invalid set_equal command. Syntax is: set_equal NAME1 NAME2')
            return
        param = self.get_external_parameter(args[0])
        param2 = self.get_external_parameter(args[1])
        if param is None or param2 is None:
            return
        if param == param2:
            logger.warning('Can not set a parameter equal to itself.')
            return
        if param[0].lower() != param2[0].lower():
            # the model restriction only merges two parameters of a same block:
            # both will stay in the param_card (with the same value)
            logger.warning('%s and %s are in two different blocks of the '
                'param_card (%s and %s): the interactions will be simplified as '
                'if they were identical but both will remain independent '
                'entries of the param_card (you will have to keep them equal).\n'
                '  Use \'formula %s = %s\' to link them for good (this writes a '
                'new model on disk).', args[0], args[1], param[0], param2[0],
                args[0], args[1])
        self.forget_parameter(param)
        self.set_equal.append((param, param2))
        self.explain_change()

    def do_formula(self, line):
        """define an external parameter as a formula of other parameters.
        This requires to write a new UFO model on disk."""

        self.value = 'repeat'
        if '=' not in line:
            logger.warning('Invalid formula command. Syntax is: formula NAME = EXPRESSION')
            return
        name, expr = line.split('=', 1)
        name, expr = name.strip(), expr.strip()
        if name.lower() not in self.external_params:
            logger.warning('%s is not an external parameter of this model.', name)
            return
        if not expr:
            logger.warning('Invalid formula command: empty expression.')
            return
        for variable in self.get_variables(expr):
            if variable == name.lower():
                logger.warning('%s can not be defined in term of itself.', name)
                return
            if variable not in self.external_params:
                logger.warning('%s is not an external parameter of this model. '
                    'Such formula is likely to fail when loading the model.', variable)
        param = self.get_external_parameter(name)
        name = self.external_params[name.lower()].name
        self.forget_parameter(param)
        self.new_formula = [(n, e) for (n, e) in self.new_formula if n != name]
        self.formula_target[name] = param
        self.new_formula.append((name, expr))
        self.warn_not_explained()

    def do_coupling(self, line):
        """change the definition of one of the coupling of the model.
        This requires to write a new UFO model on disk."""

        self.value = 'repeat'
        if '=' not in line:
            logger.warning('Invalid coupling command. Syntax is: coupling NAME = EXPRESSION')
            return
        name, expr = line.split('=', 1)
        name, expr = name.strip(), expr.strip()
        if name.lower() not in self.ufo_couplings:
            logger.warning('%s is not a coupling of this model.', name)
            return
        if not expr:
            logger.warning('Invalid coupling command: empty expression.')
            return
        name = self.ufo_couplings[name.lower()].name
        self.new_coupling = [(n, e) for (n, e) in self.new_coupling if n != name]
        self.new_coupling.append((name, expr))
        self.warn_not_explained()

    @staticmethod
    def get_variables(expr):
        """the (lower case) name of all the variables used in an expression"""

        known = set(['cmath', 'math', 'abs', 'complex', 'complexconjugate',
                     're', 'im', 'sqrt', 'pi', 'exp', 'log', 'sin', 'cos',
                     'tan', 'asin', 'acos', 'atan', 'sec', 'csc', 'cot'])
        out = []
        for variable in re.findall(r'\b[A-Za-z_]\w*\b', expr):
            if variable.lower() in known or variable.lower() in out:
                continue
            out.append(variable.lower())
        return out

    def warn_not_explained(self):
        """formula/coupling change the model itself, not the values written in
        the restriction card, so --explain can not evaluate them here"""

        if self.explainer is not None:
            logger.info('  the effect of that command can only be seen once the '
                        'new model is written (it is not a restriction)')

    def explain_change(self):
        """with --explain, report what the command which just ran changed"""

        if self.explainer is None:
            return
        try:
            self.explainer.update(self.all_categories, self.set_zero,
                            self.set_one, self.set_equal, self.lha2name)
        except Exception as error:
            # informative only: a failure here must not stop the customization
            logger.warning('Could not report the effect of that command: %s',
                           error)

    def start_from_restriction(self, card, name=None):
        """Fill the rules with what the restriction card `card` does.

        Mirrors what the restriction itself does to a card
        (detect_special_parameters / detect_identical_parameters): a parameter
        at 0 or 1 is fixed there, and parameters of the same block sharing a
        value are merged.  Parameters an option of the question already covers
        -- a massless b, a diagonal CKM -- are left to that option, so they are
        not listed twice.  Two parameters merged with opposite signs cannot be
        written as `set A = B`: they are left free.
        """

        if card is None:
            return
        by_lha = dict(((param.lhablock.lower(), tuple(param.lhacode)),
                       (param.lhablock, tuple(param.lhacode)))
                      for param in self.external_params.values())
        covered = set()
        for category in self.all_categories:
            for option in category:
                for lhablock, lhacode, _ in option.get_rules():
                    if not isinstance(lhacode, (list, tuple)):
                        lhacode = [lhacode]
                    covered.add((lhablock.lower(), tuple(lhacode)))

        zeros, ones, groups = [], [], {}
        for block in card:
            if block.startswith(('qnumbers', 'decay_table')) or 'info' in block:
                continue
            for param in card[block]:
                lha = (block.lower(), tuple(param.lhacode))
                if lha not in by_lha or lha in covered:
                    continue
                try:
                    value = float(param.value)
                except (TypeError, ValueError):
                    continue # an 'auto' width
                if value == 0.:
                    zeros.append(by_lha[lha])
                elif value == 1.:
                    ones.append(by_lha[lha])
                elif block.lower() != 'decay': # widths are never merged
                    groups.setdefault((block.lower(), value), []).append(
                                                                  by_lha[lha])
        equal = [(key, keys[0]) for keys in groups.values() if len(keys) > 1
                 for key in keys[1:]]
        if zeros or ones or equal:
            self.set_zero, self.set_one, self.set_equal = zeros, ones, equal
            self.loaded_restriction = name or 'the loaded one'

    def forget_parameter(self, param):
        """remove any previous customization of a given parameter"""

        if param is None:
            return
        self.set_zero = [p for p in self.set_zero if p != param]
        self.set_one = [p for p in self.set_one if p != param]
        self.set_equal = [(p, p2) for (p, p2) in self.set_equal if p != param]
        self.new_formula = [(n, e) for (n, e) in self.new_formula
                            if self.formula_target.get(n, None) != param]

    def do_clear(self, line):
        """forget all the parameter/coupling modifications entered so far"""

        self.value = 'repeat'
        self.set_zero = []
        self.set_one = []
        self.set_equal = []
        self.new_formula = []
        self.new_coupling = []
        self.formula_target = {}
        self.default_source = None
        self.default_card_values = None
        self.default_values = {}
        self.explain_change()

    #===========================================================================
    # looking at the model while answering the question
    #===========================================================================
    def do_display(self, line):
        """display the parameters/couplings of the model, so that one knows
        what to give to set_zero/set_one/set_equal"""

        self.value = 'repeat'
        args = line.split()
        if not args:
            logger.warning('Invalid display command. Syntax is: '
                           'display parameters|couplings [NAME]')
            return
        if args[0].startswith('param'):
            self.display_parameters(args[1:])
        elif args[0].startswith('coupl'):
            self.display_couplings(args[1:])
        else:
            logger.warning('Invalid display command. %s is not one of '
                           'parameters/couplings.', args[0])

    def get_current_restrictions(self):
        """(lhablock, lhacode) -> what the choices made so far do to it"""

        out = {}
        for category in self.all_categories:
            for option in category:
                for lhablock, lhacode, value in option.get_rules():
                    out[(lhablock.lower(), tuple(lhacode))] = \
                                        '%g (%s)' % (value, option.name)
        for param in self.set_zero:
            out[(param[0].lower(), param[1])] = '0'
        for param in self.set_one:
            out[(param[0].lower(), param[1])] = '1'
        for param, param2 in self.set_equal:
            out[(param[0].lower(), param[1])] = \
                        MadGraphCmd.name_of_lha(self.lha2name, param2)
        for name, expr in self.new_formula:
            key = self.formula_target.get(name, None)
            if key:
                out[(key[0].lower(), key[1])] = expr
        return out

    def display_parameters(self, args):
        """the external parameters, by block, with the effect of the choices
        made so far. Without argument the full list, with one only the block or
        the parameters whose name contains it."""

        pattern = args[0].lower() if args else None
        restricted = self.get_current_restrictions()
        exact = self.external_params.get(pattern, None)

        def match(param):
            if pattern is None:
                return True
            if exact is not None:
                return param is exact # an exact name wins over a substring
            return pattern == param.lhablock.lower() or \
                   pattern in param.name.lower()

        selected = {}
        for param in self.external_params.values():
            if match(param):
                selected.setdefault(param.lhablock, []).append(param)

        if not selected:
            if not self.display_internal(pattern):
                if args:
                    logger.info('No parameter of this model matches \'%s\'.',
                                args[0])
                else:
                    logger.info('This model has no external parameter.')
            return

        nb = sum(len(params) for params in selected.values())
        if pattern is None and nb > 300:
            logger.info('This model has %d external parameters. Give a block or '
                'a part of a name to list them:\n    %s', nb,
                '\n    '.join('%-20s %d parameter(s)' % (block, len(params))
                              for block, params in sorted(selected.items())))
            return

        for block in sorted(selected):
            logger.info('%s', block)
            for param in sorted(selected[block],
                                key=lambda p: self.natural_key(p.name)):
                key = (block.lower(), tuple(param.lhacode))
                logger.info('    %-22s %-8s %-14s %s', param.name,
                            ' '.join(str(code) for code in param.lhacode),
                            self.format_value(self.get_default_value(param)),
                            '-> %s' % restricted[key] if key in restricted else '')
        if pattern is not None:
            self.display_internal(pattern)

    def display_internal(self, pattern):
        """the internal parameters matching pattern. They can not be restricted
        but the user has to be able to find out why."""

        if pattern is None:
            return False
        if pattern in self.internal_params:
            matching = [self.internal_params[pattern]]
        else:
            matching = [param for param in self.internal_params.values()
                        if pattern in param.name.lower()]
        if not matching:
            return False
        logger.info('internal parameter(s) (computed from the ones of the '
                    'param_card, they can not be restricted):')
        for param in sorted(matching, key=lambda p: self.natural_key(p.name)):
            logger.info('    %-22s = %s', param.name, param.value)
            if len(matching) <= self.EXPAND_MAX_MATCH:
                self.log_expansion_conclusion(param.name,
                                    self.expand_expression(param.value))
        return True

    # a definition is unfolded only when the user asked for a few of them, and
    # only down to that many levels
    EXPAND_MAX_MATCH = 5
    EXPAND_MAX_DEPTH = 8

    def expand_expression(self, expr, depth=1, seen=None, restricted=None,
                                                                   found=None):
        """print the definition of every parameter appearing in expr, and
        recursively of the ones appearing in those definitions, down to the
        parameters of the param_card. That is where a coupling which is dropped
        comes from, so the ones the current choices restrict are marked.
        Return the restricted parameters the expression depends on."""

        if seen is None:
            seen = set()
        if restricted is None:
            restricted = self.get_current_restrictions()
        if found is None:
            found = []
        if depth > self.EXPAND_MAX_DEPTH:
            logger.info('%s...', '    ' * (depth + 1))
            return found

        indent = '    ' * (depth + 1)
        for name in self.get_variables(str(expr)):
            param = self.external_params.get(name, None)
            if param is not None:
                # a parameter of the param_card: this is where it stops, and
                # where the reason of a drop is to be found
                key = (param.lhablock.lower(), tuple(param.lhacode))
                logger.info('%s%-22s = %-12s (%s %s)%s' % (indent, param.name,
                            self.format_value(self.get_default_value(param)),
                            param.lhablock,
                            list(param.lhacode),
                            '   -> %s' % restricted[key] if key in restricted
                            else ''),
                            '$MG:BOLD' if key in restricted else '$MG:color:BLACK')
                if key in restricted and (param.name, restricted[key]) not in found:
                    found.append((param.name, restricted[key]))
                continue
            param = self.internal_params.get(name, None)
            if param is None:
                continue # a function of the model, a number, ...
            if name in seen:
                logger.info('%s%-22s = (see above)', indent, param.name)
                continue
            seen.add(name)
            logger.info('%s%-22s = %s', indent, param.name, param.value)
            self.expand_expression(param.value, depth + 1, seen, restricted, found)
        return found

    @staticmethod
    def log_expansion_conclusion(name, found):
        """the one line answer to 'why is that one dropped?'"""

        if not found:
            logger.info('    %s does not depend on any parameter your choices '
                        'restrict.' % name, '$MG:color:BLUE')
            return
        logger.info('    %s depends on %s' % (name,
                    ', '.join('%s -> %s' % entry for entry in found)),
                    '$MG:color:GREEN')

    def display_couplings(self, args):
        """the couplings of the model, with their expression"""

        pattern = args[0].lower() if args else None
        if pattern in self.ufo_couplings:
            # an exact name wins: 'display couplings GC_1' is about GC_1, not
            # about GC_1, GC_10, GC_100, ...
            matching = [self.ufo_couplings[pattern]]
        else:
            matching = [coupling for coupling in self.ufo_couplings.values()
                        if pattern is None or pattern in coupling.name.lower()]
        if not matching:
            if args:
                logger.info('No coupling of this model matches \'%s\'.', args[0])
            else:
                logger.info('This model has no coupling.')
            return
        if pattern is None and len(matching) > 300:
            logger.info('This model has %d couplings. Give a name -or a part '
                        'of one- to list them.', len(matching))
            return
        for coupling in sorted(matching, key=lambda c: self.natural_key(c.name)):
            logger.info('    %-14s = %s' % (coupling.name, coupling.value),
                        '$MG:BOLD')
            if len(matching) <= self.EXPAND_MAX_MATCH:
                self.log_expansion_conclusion(coupling.name,
                                    self.expand_expression(coupling.value))

    @staticmethod
    def format_value(value):
        """the default value of a parameter, as the param_card shows it"""

        try:
            return '%.6g' % float(value)
        except (TypeError, ValueError):
            return str(value)

    @staticmethod
    def natural_key(name):
        """sort GC_9 before GC_10"""

        return [int(part) if part.isdigit() else part
                for part in re.split(r'(\d+)', name)]

    def complete_display(self, text, line, begidx, endidx):
        """ Complete the display command"""

        signal.alarm(0) # avoid timer if any
        args = self.split_arg(line[0:begidx])
        if len(args) == 1:
            return self.list_completion(text, ['parameters', 'couplings'], line)
        if args[1].startswith('coupl'):
            return self.list_completion(text,
                    [coupling.name for coupling in self.ufo_couplings.values()],
                    line)
        blocks = sorted(set(param.lhablock
                            for param in self.external_params.values()))
        return self.list_completion(text, blocks +
                    [param.name for param in self.external_params.values()], line)

    def get_question(self):
        """define the current question."""

        question = ''
        i = 0
        for category in self.all_categories:
            question += category.name + ':\n'
            for options in category:
                if not options.first:
                    continue
                i += 1
                question += '    %s: %s [%s]\n' % (i, options.name,
                                options.display(options.status))
                if isinstance(options, build_restrict_lib.ChoiceOption):
                    question += '        possible values: %s%s\n' % (
                        ', '.join(options.labels),
                        ' (%s)' % options.description if options.description else '')
        question += 'Enter a number to change it\'s status or press enter to validate.\n'

        fmt = lambda key: '%s (%s %s)' % (
                    MadGraphCmd.name_of_lha(self.lha2name, key).split(' ')[0],
                    key[0], list(key[1]))

        def lines_for(keys, value):
            """one line per parameter, or 'BLOCK all' when a whole block is
            concerned -- which is how the user typed it in the first place"""

            by_block, out = {}, []
            for key in keys:
                by_block.setdefault(key[0], []).append(key)
            for block, block_keys in by_block.items():
                whole = self.get_block_parameters(block)
                if whole and len(block_keys) == len(whole):
                    out.append('    %s all = %s' % (block, value))
                else:
                    out += ['    %s = %s' % (fmt(key), value)
                            for key in block_keys]
            return out

        current = lines_for(self.set_zero, 0) + lines_for(self.set_one, 1)
        for param, param2 in self.set_equal:
            current.append('    %s = %s' % (fmt(param), fmt(param2)))
        for name, expr in self.new_formula:
            current.append('    %s = %s' % (name, expr))
        for name, expr in self.new_coupling:
            current.append('    %s = %s' % (name, expr))
        question += 'parameter/coupling modifications (use set_zero/set_one):\n'
        if self.loaded_restriction:
            question += ('    (starting from %s, the restriction the model was '
                         'loaded with:\n     \'set NAME free\' releases one, '
                         '\'clear\' all of them)\n' % self.loaded_restriction)
        if current:
            question += '\n'.join(current) + '\n'
        else:
            question += '    none\n'

        if self.default_source or self.default_values:
            question += 'default values: %s\n' % (
                'the UFO model' if self.default_source == 'ufo'
                else self.default_source or 'the model as it was loaded')
            by_value = {}
            for key, value in self.default_values.items():
                by_value.setdefault(value, []).append(key)
            for value in sorted(by_value):
                question += '\n'.join(lines_for(by_value[value], value)) + '\n'

        question += 'For the other commands (set_equal, formula, coupling, display, clear),\n'
        question += 'or for scripting this function, please type: \'help\''
        return question

    def complete_set(self, text, line, begidx, endidx):
        """ Complete the set command"""
        signal.alarm(0) # avoid timer if any
        args = self.split_arg(line[0:begidx])

        if len(args) == 1:
            # an option of the question, or a parameter ('set MB 0')
            possibilities = [x for x in self.name2options if not x.isdigit()]
            possibilities += [param.name
                              for param in self.external_params.values()]
            return self.list_completion(text, possibilities, line)

        option = self.name2options.get(args[1], None)
        if isinstance(option, build_restrict_lib.ChoiceOption):
            return self.list_completion(text, option.labels, line)
        elif option is not None:
            return self.list_completion(text, ['True', 'False'], line)

        param = self.external_params.get(args[1].lower(), None)
        if param is None:
            return []
        # 0, 1, or one of the parameters it can really be merged with
        names = self.get_identifiable().get(param.lhablock.lower(), [])
        return self.list_completion(text, ['0', '1'] +
                            [n for n in names if n != param.name], line)

    def complete_set_zero(self, text, line, begidx, endidx):
        """ Complete the set_zero command: a parameter, or a block and 'all'"""
        signal.alarm(0) # avoid timer if any
        args = self.split_arg(line[0:begidx])
        if len(args) > 1:
            return self.list_completion(text, ['all'], line)
        blocks = sorted(set(param.lhablock
                            for param in self.external_params.values()))
        return self.list_completion(text, blocks +
                  [param.name for param in self.external_params.values()], line)

    complete_set_one = complete_set_zero
    complete_formula = complete_set_zero

    def get_identifiable(self):
        """the external parameters which can really be merged with another one,
        grouped by block. The restriction only fuses two parameters of a same
        block of the param_card, and never two widths."""

        if self._identifiable is None:
            by_block = {}
            for param in self.external_params.values():
                if param.lhablock.lower() == 'decay':
                    continue
                by_block.setdefault(param.lhablock.lower(), []).append(param.name)
            self._identifiable = dict((block, sorted(names))
                            for block, names in by_block.items() if len(names) > 1)
        return self._identifiable

    def complete_set_equal(self, text, line, begidx, endidx):
        """Complete the set_equal command. Only the parameters which can
        actually be merged are proposed, and for the second argument only the
        ones of the same block as the first."""

        signal.alarm(0) # avoid timer if any
        args = self.split_arg(line[0:begidx])
        identifiable = self.get_identifiable()

        if len(args) == 1:
            return self.list_completion(text,
                    sum([names for names in identifiable.values()], []), line)
        elif len(args) == 2:
            param = self.external_params.get(args[1].lower(), None)
            if param is None:
                return []
            names = identifiable.get(param.lhablock.lower(), [])
            return self.list_completion(text,
                            [n for n in names if n != param.name], line)

    def complete_coupling(self, text, line, begidx, endidx):
        """ Complete the coupling command"""
        signal.alarm(0) # avoid timer if any
        return self.list_completion(text,
                  [coup.name for coup in self.ufo_couplings.values()], line)

    def do_help(self, line):
        '''help message'''

        print('This allows you to optimize your model to your needs.')
        print('Enter the number associate to the possible restriction/add-on')
        print(' to change the status of this restriction/add-on.')
        print('')
        print('In order to allow scripting of this function you can use the ')
        print('function \'set\'. This function takes two argument:')
        print('set NAME VALUE')
        print('   NAME is the description of the option where you remove all spaces')
        print('   VALUE is either True/False or, for the options with more than')
        print('         two values, one of the value proposed within the bracket')
        print('         (an unambiguous abbreviation is enough: 5 for 5F)')
        print(' Example: For the question')
        print('''     sm customization:
        1: diagonal ckm [True]
     mass scheme:
        2: flavour scheme [4F]
        3: nb of massive leptons [1]
    Enter a number to change it's status or press enter to validate.''')
        print(''' you can answer by''')
        print('   set diagonalckm False')
        print('   set flavourscheme 5F        (or just: set flavourscheme 5)')
        print('   set nbofmassiveleptons 0')
        print('')
        print('On top of those options, the following commands are available:')
        print('   set_zero NAME          : set the external parameter NAME to zero')
        print('   set_one NAME           : set the external parameter NAME to one')
        print('     NAME can be \'BLOCK all\' to act on a whole block of the')
        print('     param_card: set_zero decay all, set CEFT all 0, ...')
        print('   set_equal NAME1 NAME2  : force NAME1 to take the value of NAME2')
        print('   clear                  : forget all those modifications')
        print('   display parameters [X] : the parameters of the model (all of')
        print('                            them, or the block/names matching X)')
        print('   By default the parameters keep the value they have in the model')
        print('   you loaded. To change that:')
        print('   set default UFO        : take the values of the UFO instead')
        print('   set default PATH       : take them from that param_card')
        print('   set default NAME VALUE : set the value of one parameter, or of')
        print('                            a whole block: set default CEFT all 0')
        print('   UFO and PATH start from scratch: they undo the \'set default\'')
        print('   entered before them. Those are values, not restrictions:')
        print('   use set_zero to remove a parameter from the model.')
        print('                            Those are values, not restrictions:')
        print('                            use set_zero to remove a parameter.')
        print('   display couplings [X]  : the couplings, with their expression.')
        print('                            When X selects a few of them, every')
        print('                            parameter of the expression is')
        print('                            unfolded down to the param_card, so')
        print('                            that one sees why one is dropped.')
        print('')
        print('The \'set\' command is a shortcut for the three of them when its')
        print('first argument is a parameter of the model:')
        print('   set NAME 0             same as set_zero NAME')
        print('   set NAME 1             same as set_one NAME')
        print('   set BLOCK all 0        same as set_zero BLOCK all')
        print('   set NAME = OTHERNAME   same as set_equal NAME OTHERNAME')
        print('')
        print('The two following commands change a formula of the model. They can')
        print('not be stored in a restriction card, so a new UFO model is written')
        print('on disk (you will be asked for its name). They are therefore not')
        print('compatible with the --save=NAME option.')
        print('   formula NAME = EXPRESSION   : NAME (an external parameter) becomes')
        print('                                 an internal parameter of the model')
        print('   coupling NAME = EXPRESSION  : change the definition of a coupling')

    def cmdloop(self, intro=None):
        cmd.SmartQuestion.cmdloop(self, intro)
        return self.all_categories



#===============================================================================
# __main__
#===============================================================================

if __name__ == '__main__':

    run_option = sys.argv
    if len(run_option) > 1:
        # The first argument of sys.argv is the name of the program
        input_file = open(run_option[1], 'rU')
        cmd_line = MadGraphCmd(stdin=input_file)
        cmd_line.use_rawinput = False #put it in non interactive mode
        cmd_line.cmdloop()
    else:
        # Interactive mode
        MadGraphCmd().cmdloop()
