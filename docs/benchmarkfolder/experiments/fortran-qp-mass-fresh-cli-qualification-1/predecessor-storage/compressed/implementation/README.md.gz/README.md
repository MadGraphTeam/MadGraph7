# Private current-source TIRust QP mass-square successor

This is a source-only successor for current production source
`0fcd2cd873d61d134837e1d9e87afb13a47824fd` and the unchanged `eb3d67fd…` native
library. It changes no production, installed library, reference checkout,
campaign, public evidence or Git state. No compiler, loader, reducer or amplitude
has run for this successor. Source tests do not qualify numerical behavior.

The complete current public CT, NinjaRS, TIRust and LOOP-helper templates remain
byte-identical. Seven current files are copied into `base/`; nine candidate
files in `src/` add private helpers and private TIRust QP adapters. Every public
legacy routine renders byte-identically in both amplitude-storage branches.
No NinjaRS private mass adapter is added. No Rust, native API or precision change
is proposed. Genuine binary128 input transport and QP numerator contraction are
already provided by the existing implementation.

The optimized call writer reuses the exact prior guarded writer method. Each
complete `IF(CTMODE.LT.4)` block is one exporter list item. Modes−1 and0–3 retain
the exact original call and evaluate no new MP actual argument. Modes4–6 pass
each original DP model mass beside its existing MP model symbol. The generated
split-call subroutine gains the same LSCALE/CTMODE COMMON declaration as its
existing caller. Symbols follow `get_masses()` and the existing model MP prefix:
zero, card-real, derived-real and CMS masses retain their selected model identity.
No numerical lookup, card reparsing or hard-coded particle mapping is added.

Every legacy LOOP helper is retained. A private `_QPMASS` clone keeps its
existing filters, DP mass construction, DP-based complex-mass classification,
momentum accumulation and CHOOSE_LOOPLIB. **Only after actual selection**, and
only when `DOING_QP` and `MLReductionLib(I_LIB)==9`, it squares the existing MP
masses in the original cyclic `[last, first, …]` order and calls the private QP
TIRust entry. All other backend calls keep the original DP mass-square array.
The wrapper's defensive direct-DP delegation remains in place. Other selected
QP backends still receive the paired helper's additional read-only MP actuals;
this source work does not claim their runtime/IEEE or performance qualification.

The private TIRust diagnostic and contraction bodies are exact copies of current
public bodies, differing only in names, the complex-QP mass formal, and the
private contraction-to-diagnostic target. The writable MASSES copy and existing
direction switch remain. Kinematic reconstruction, pole modes, cache/check
selection, scale construction, tensor map, normalization, stability and failure
propagation are unchanged. The public mass ABI remains DP for legacy callers.

Ten tests pass in normal and optimized Python with process creation blocked.
They use actual MadGraph call-writer/exporter objects and check nine helper
families through six propagators, both storage branches, all200 retained EW
symbol mappings, custom MP prefixes, availability closure and split boundaries.
They reproduce every candidate file and verify production inputs unchanged.
Their mock `NSQUAREDSO=2` rendering is a source test, not a physical CLI export.
The integer-only precision controls are separately labelled:

* Current `u u~ > z g g` really has43 MB and43 MT arguments. Its card MB=4.7
  promotes a binary64 mass into MP storage; squaring that value needs105
  significant bits and is exact in binary128. DP squaring loses approximately
  `1.741e-15`. This is recovered square precision, not evidence of a mass input
  having more than53 bits.
* A nearest-binary128 sqrt(2), proved with integer rounding-cell inequalities,
  and a complex dyadic mass with bits below binary64 precision discriminate
  true QP input values. Exact rational expected squares and the real derived-MW
  and complex-pole model source expressions are retained. These unit controls
  have not executed in Fortran and are not physical model/finite-term truth.

`protocol.json` specifies separate future BUILD and normal checked RUN gates.
The current n3 full100-learning process and automatic-QP anchor16 are suitable
for the nonzero bottom-square discriminator. Cache0/−1, unchanged DP controls,
actual MP argument/square words and ordinary host rescue checks are mandatory.
Changed QP mass inputs can legitimately change QP finite words and estimated
accuracy; exact output equality is required for DP, while QP changes need the
existing numerical gate and independent truth checks. No bare fixed120 result
can supply checked-QP acceptance. A genuine derived/CMS mass-input physical
qualification remains separate.

The historical prototype,218 caller fixtures and old37-refusal threshold result
remain untouched. The old physical results used library49af…, unchecked120 and
accuracy−1; mass transport did not remove those refusals. This successor fixes
neither generic composite-shell clamping, CMS stress, physical conditioning nor
the existing reducer-dependent scale expressions. Runtime benefit, DP overhead,
mixed rescue chains, external model reinitialization and every other physical
acceptance item remain unqualified. Overall goal completion is not claimed.

Verify only the owned source inventory and exact derivation, without a compiler:

```sh
python3 -B verify.py
python3 -B verify.py --working-root /absolute/path/to/madgraph7_madloop_tirust
```

The second form also checks the explicitly pinned source dependencies and
current production files. Neither form loads a reducer or executes tests or an
old controller. Historical absolute paths in dependency metadata are inert in
the default verification. `prepare.py` is exclusive preparation provenance;
do not rerun it in this frozen directory. To rerun source tests, use a new
private working copy and retain new logs separately; the frozen receipts are
never overwritten. Future source generation/build requires a new independently
reviewed controller seal and explicit phase admission.
