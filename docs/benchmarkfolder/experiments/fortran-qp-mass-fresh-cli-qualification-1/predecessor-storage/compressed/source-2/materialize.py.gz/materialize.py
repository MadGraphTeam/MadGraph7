"""Deterministic source continuation from the exact complete current CLI export.

No process generation, compiler or reducer is run. Public routine bytes are
retained; the added bodies derive from the exact current emitted routines.
"""
import re


def require(value, message):
    if not value:
        raise ValueError(message)


def logical_blocks(text):
    lines = text.splitlines(keepends=True)
    i = 0
    while i < len(lines):
        first = i
        line = lines[i]
        if not line.strip() or line[0] in 'Cc*!':
            yield first, i+1, None
            i += 1
            continue
        require(not line[132:].strip(), 'Executable source beyond qualified column132')
        statement = line[6:132].strip()
        i += 1
        while i < len(lines) and len(lines[i]) > 5 and lines[i][0] not in 'Cc*!' and lines[i][5] not in ' 0\n':
            require(not lines[i][132:].strip(), 'Continuation beyond qualified column132')
            statement += ' ' + lines[i][6:132].strip()
            i += 1
        yield first, i, statement


def split_args(text):
    level = 0
    result = []
    start = 0
    for i, char in enumerate(text):
        if char == '(':
            level += 1
        elif char == ')':
            level -= 1
            require(level >= 0, 'Unbalanced argument list')
        elif char == ',' and level == 0:
            result.append(text[start:i].strip())
            start = i+1
    require(level == 0, 'Unbalanced argument list')
    result.append(text[start:].strip())
    return result


def fixed(statement):
    result = []
    rest = statement.strip()
    while len(rest) > 65:
        cut = max(rest.rfind(',', 0, 65)+1, rest.rfind(' ', 0, 66))
        require(cut > 0, 'Unwrappable fixed-form token')
        result.append(('      ' if not result else '     $ ')+rest[:cut].rstrip())
        rest = rest[cut:].lstrip()
    result.append(('      ' if not result else '     $ ')+rest)
    require(all(len(line) <= 72 for line in result), 'Fixed-form wrap overflow')
    return '\n'.join(result)+'\n'


def replace(text, callback):
    lines = text.splitlines(keepends=True)
    result = []
    for first, last, statement in logical_blocks(text):
        replacement = callback(statement) if statement is not None else None
        result.append(''.join(lines[first:last]) if replacement is None else replacement)
    return ''.join(result)


def routines(text):
    lines = text.splitlines(keepends=True)
    found = {}
    start = name = arguments = None
    for first, last, statement in logical_blocks(text):
        if statement is None:
            continue
        match = re.fullmatch(r'SUBROUTINE\s+(\w+)\s*\((.*)\)', statement, re.I)
        if match:
            require(name is None, 'Nested/unterminated routine')
            start, name, arguments = first, match[1].upper(), split_args(match[2])
        elif statement.upper() == 'END' and name is not None:
            require(name not in found, 'Duplicate routine')
            found[name] = {'text': ''.join(lines[start:last]), 'args': arguments}
            start = name = arguments = None
    require(name is None, 'Unterminated routine')
    return found


def qp_symbols(text, zero='MP__ZERO'):
    result = {zero: 'REAL*16 local zero'}
    for _, _, statement in logical_blocks(text):
        if statement is None:
            continue
        match = re.fullmatch(r'(REAL\*16|COMPLEX\*32)\s+(.+)', statement, re.I)
        if match:
            for token in split_args(match[2]):
                result[token.split('(')[0].strip().upper()] = match[1].upper()
    return result


# Exact mapper from the earlier independently reviewed mass prototype.
def mass_actual(dp_actual, declarations, mp_prefix):
    match = re.fullmatch(r'DCMPLX\(\s*([A-Z][A-Z0-9_]*)\s*\)', dp_actual, re.I)
    if not match:
        raise ValueError('Unqualified model mass expression: '+dp_actual)
    symbol = match[1].upper()
    mp_symbol = mp_prefix+symbol
    if mp_symbol not in declarations:
        raise ValueError('Missing genuine MP model symbol: '+mp_symbol)
    return 'CMPLX('+mp_symbol+',KIND=16)', symbol, mp_symbol


def clone_helper(name, row):
    n = int(name.split('_LOOP_')[1].split('_')[0])
    formals = row['args']
    mass_formals = ['M'+str(i) for i in range(1,n+1)]
    require(all(formals.count(x) == 1 for x in mass_formals), 'Every denominator mass must be a unique formal')
    paired = [part for arg in formals for part in ([arg,'MP_'+arg] if arg in mass_formals else [arg])]
    seen = {k:0 for k in ('header','formal','array','delegation','selection','tirust')}
    def change(statement):
        upper = statement.upper()
        if upper.startswith('SUBROUTINE '+name+'('):
            seen['header'] += 1
            return fixed('SUBROUTINE '+name+'_QPMASS('+','.join(paired)+')')
        if upper.replace(' ','') == 'COMPLEX*16'+','.join(mass_formals):
            seen['formal'] += 1
            return fixed(statement)+fixed('COMPLEX*32 '+','.join('MP_'+m for m in mass_formals))
        if upper.replace(' ','') == 'COMPLEX*16M2L(NLOOPLINE)':
            seen['array'] += 1
            return fixed(statement)+fixed('COMPLEX*32 MP_M2L(NLOOPLINE)')
        if upper.replace(' ','') == 'DOING_QP=(CTMODE.GE.4)':
            seen['delegation'] += 1
            return (fixed('IF(CTMODE.LT.4) THEN')+fixed('CALL '+name+'('+','.join(formals)+')')+
                fixed('RETURN')+fixed('ENDIF')+fixed(statement))
        if upper.startswith('CALL ML5_0_CHOOSE_LOOPLIB('):
            seen['selection'] += 1
            squares = ['MP_M2L(1)=MP_M%d**2'%n]+['MP_M2L(%d)=MP_M%d**2'%(i,i-1) for i in range(2,n+1)]
            return fixed(statement)+fixed('IF(DOING_QP.AND.MLReductionLib(I_LIB).EQ.9) THEN')+''.join(fixed(s) for s in squares)+fixed('ENDIF')
        if upper.startswith('CALL ML5_0_MP_TIRUST_LOOP('):
            seen['tirust'] += 1
            require(',MP_PL,M2L,RANK,' in upper.replace(' ',''), 'Unexpected TIRust QP call')
            return fixed(statement.replace('MP_TIRUST_LOOP(', 'MP_TIRUST_LOOP_QPMASS(').replace(',MP_PL,M2L,RANK', ',MP_PL,MP_M2L,RANK'))
        return None
    result = replace(row['text'], change)
    require(all(count == 1 for count in seen.values()), 'Private helper exact replacement counts differ: '+str(seen))
    return result


def clone_adapter(name, row):
    seen = {'header':0,'formal':0,'inner':0}
    def change(statement):
        upper = statement.upper()
        if upper.startswith('SUBROUTINE '+name+'('):
            seen['header'] += 1
            return fixed(statement.replace(name+'(',name+'_QPMASS('))
        if upper.replace(' ','') == 'COMPLEX*16M2L(NLOOPLINE)':
            seen['formal'] += 1
            return fixed('COMPLEX*32 M2L(NLOOPLINE)')
        if upper.startswith('CALL ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC('):
            seen['inner'] += 1
            return fixed(statement.replace('MP_TIRUST_TENSOR_DIAGNOSTIC(', 'MP_TIRUST_TENSOR_DIAGNOSTIC_QPMASS('))
        return None
    result = replace(row['text'], change)
    require(seen == {'header':1,'formal':1,'inner':int(name.endswith('_LOOP'))}, 'Unexpected adapter replacement counts')
    return result


def candidate(ct, tirust, caller, mp_model):
    old_helpers = routines(ct)
    helpers = {name:row for name,row in old_helpers.items() if re.fullmatch(r'ML5_0_LOOP_\d+(?:_\d+)?',name)}
    require(bool(helpers),'No actual CLI LOOP helper family')
    new_ct = ct+'\n'+''.join(clone_helper(name,row) for name,row in helpers.items())
    old_tirust = routines(tirust)
    new_tirust = tirust+'\n'+''.join(clone_adapter(name,old_tirust[name]) for name in (
        'ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC','ML5_0_MP_TIRUST_LOOP'))
    declarations = qp_symbols(mp_model)
    groups = []
    include_seen = 0
    caller_lines=caller.splitlines(keepends=True)
    exact_calls={statement:''.join(caller_lines[first:last]) for first,last,statement in logical_blocks(caller)
                 if statement is not None and re.fullmatch(r'CALL\s+ML5_0_LOOP_\d+(?:_\d+)?\(.*\)',statement,re.I)}
    def change(statement):
        nonlocal include_seen
        if statement.upper() == "INCLUDE 'COUPL.INC'":
            include_seen += 1
            return fixed(statement)+fixed('REAL*8 LSCALE')+fixed('INTEGER CTMODE')+fixed('COMMON/ML5_0_CT/LSCALE,CTMODE')
        match = re.fullmatch(r'CALL\s+(ML5_0_LOOP_\d+(?:_\d+)?)\((.*)\)',statement,re.I)
        if not match:
            return None
        name=match[1].upper(); actuals=split_args(match[2]); formals=helpers[name]['args']
        require(len(actuals)==len(formals),'Actual/formal arity differs')
        n=int(name.split('_LOOP_')[1].split('_')[0]);new=[];mass_pairs=[]
        for formal,actual in zip(formals,actuals,strict=True):
            new.append(actual)
            if re.fullmatch(r'M\d+',formal):
                mp,symbol,mp_symbol=mass_actual(actual,declarations,'MP__')
                new.append(mp);mass_pairs.append({'formal':formal,'DP_actual':actual,'MP_actual':mp,'model_symbol':symbol,'MP_symbol':mp_symbol})
        require(len(mass_pairs)==n,'Not every mass was paired')
        group=int(actuals[-1]);require(group not in {x['group'] for x in groups},'Duplicate CLI group')
        groups.append({'group':group,'entrypoint':name,'rank':int(actuals[-3]),'original_actuals':actuals,'paired_actuals':new,'mass_pairs':mass_pairs})
        # Original statement bytes are retained exactly inside the DP branch.
        return fixed('IF(CTMODE.LT.4) THEN')+exact_calls[statement]+fixed('ELSE')+fixed('CALL '+name+'_QPMASS('+','.join(new)+')')+fixed('ENDIF')
    new_caller = replace(caller,change)
    require(include_seen==1 and len(groups)>0,'Incomplete source caller family')
    return {'CT_interface.f':new_ct,'TIRUST_interface.f':new_tirust,'loop_CT_calls_1.f':new_caller}, {
        'schema':'exact-current-CLI-qp-mass-continuation-proof-v1','groups':groups,'helpers':list(helpers),
        'legacy_CT_prefix_exact':new_ct.startswith(ct),'legacy_TIRUST_prefix_exact':new_tirust.startswith(tirust),
        'declared_MP_symbols':declarations,'actual_selected_backend_guard':9,
        'public_legacy_ABIs_unchanged':True,'complete_CLI_baseline_required':True,
        'UseQPIntegrandForTIRust_required':True,'UseQPIntegrandFalse_and_dynamic_models_tested':False,
    }


def observed(sources, role):
    require(role in (0,1),'Unknown observer role')
    ct=sources['CT_interface.f'];tir=sources['TIRUST_interface.f'];all_helpers=routines(ct)
    selected={name:row for name,row in all_helpers.items() if re.fullmatch(
        r'ML5_0_LOOP_\d+(?:_\d+)?'+('_QPMASS' if role else ''),name)}
    require(bool(selected),'No active observed helper family')
    for name,row in selected.items():
        n=int(name.split('_LOOP_')[1].split('_')[0])
        masses=['MP_M'+str(i) if role else 'CMPLX(M%d,KIND=16)'%i for i in range(1,n+1)]
        qpsquare='MP_M2L' if role else 'CMPLX(M2L,KIND=16)'
        hook=(fixed('IF(DOING_QP.AND.MLReductionLib(I_LIB).EQ.9) THEN')+
            fixed('CALL MGMASS_GROUP(%d,CTMODE,NLOOPLINE,RANK,ID,(/%s/),M2L,%s)'%(role,','.join(masses),qpsquare))+fixed('ENDIF'))
        if role:
            statements=list(logical_blocks(row['text']));seen=False
            def change(s):
                nonlocal seen
                if s.upper().replace(' ','').startswith('IF(MLREDUCTIONLIB(I_LIB).EQ.1)THEN'):
                    require(not seen,'Duplicate dispatcher');seen=True;return hook+fixed(s)
                return None
        else:
            seen=False
            def change(s):
                nonlocal seen
                if s.upper().startswith('CALL ML5_0_CHOOSE_LOOPLIB('):
                    require(not seen,'Duplicate selector');seen=True;return fixed(s)+hook
                return None
        changed=replace(row['text'],change);require(seen,'Observer group hook missing')
        require(ct.count(row['text'])==1,'Helper source ownership ambiguous');ct=ct.replace(row['text'],changed)
    suffix='_QPMASS' if role else ''
    rows=routines(tir)
    diag_name='ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC'+suffix
    diagnostic=rows[diag_name]['text'];native_seen=False
    def native_hook(s):
        nonlocal native_seen
        if s.upper().startswith('CALL TIRUST_TENSOR_EVALUATE('):
            require(not native_seen,'Duplicate native adapter call');native_seen=True
            return (fixed('CALL MGMASS_NATIVE(%d,CTMODE,NLOOPLINE,RANK,SHIFTS,INVARIANTS,MASSES,SCALE)'%role)+
                fixed(s)+fixed('CALL MGMASS_STATUS(STATUS)'))
        return None
    changed=replace(diagnostic,native_hook);require(native_seen,'No native hook');tir=tir.replace(diagnostic,changed)
    loop_name='ML5_0_MP_TIRUST_LOOP'+suffix
    loop=rows[loop_name]['text'];coef_seen=False
    def coefficient_hook(s):
        nonlocal coef_seen
        if s.upper().startswith('CALL '+diag_name+'('):
            require(not coef_seen,'Duplicate contraction diagnostic');coef_seen=True
            # The actual n3 CLI family is interference reduction, NSQUAREDSO1.
            return fixed('CALL MGMASS_COEFS(%d,NLOOPLINE,RANK,ID,NCOEF_R(RANK),LOOPCOEFS(0:NCOEF_R(RANK)-1,SQSOINDEX,ID))'%role)+fixed(s)
        return None
    changed=replace(loop,coefficient_hook);require(coef_seen,'No actual numerator hook');tir=tir.replace(loop,changed)
    return {**sources,'CT_interface.f':ct,'TIRUST_interface.f':tir}
