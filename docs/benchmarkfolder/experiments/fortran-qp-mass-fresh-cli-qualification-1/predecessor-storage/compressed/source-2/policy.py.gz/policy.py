"""Preserve all original compilation policies; select only four source units."""
from pathlib import Path
import shlex
import shutil

NEEDED=('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f','check_sa.f')


def require(value,message):
    if not value:raise ValueError(message)


def private_makefile(text,observed=False):
    old='$(FC) $(FFLAGS) -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)'
    require(text.count(old)==1,'Original link recipe must be unique')
    new=('$(FC) $(FFLAGS) -Wl,-Map,private-link.map,--cref -o $(PROG) check_sa.o '+
         ('mgmass_observer.o ' if observed else '')+'$(PROCESS) $(LINKLIBS)')
    return text.replace(old,new,1)


def select_commands(text,compiler,environment,observed=False):
    selected={};links=[]
    for line in text.replace('\\\n',' ').splitlines():
        argv=shlex.split(line)
        if not argv:continue
        sources=[a for a in argv if not a.startswith('-') and Path(a).suffix.lower() in {'.f','.f90','.f95','.f03','.f08','.for'}]
        names=[a for a in sources if Path(a).name in NEEDED]
        outputs=[argv[i+1] for i,a in enumerate(argv[:-1]) if a=='-o']
        link='-c' not in argv and 'check' in outputs
        if not names and not link:continue
        require(not any(a in {';','&&','||','|','>','>>','<','&'} for a in argv),'Compound selected command')
        actual=shutil.which(argv[0],path=environment.get('PATH'))
        require(actual and Path(actual).resolve()==Path(compiler).resolve(),'Wrong selected compiler')
        require(argv.count('-o')==1 and len(outputs)==1 and not any(a.startswith('@') for a in argv),'Ambiguous selected output/response')
        if link:
            require(not sources and outputs==['check'] and '-ltirust' in argv,'Invalid selected link')
            require(('mgmass_observer.o' in argv)==observed,'Observer ownership differs')
            require('mtirust.o' not in argv,'Installed wrapper archive must be retained')
            links.append(argv)
        else:
            require(argv.count('-c')==1 and len(sources)==len(names)==1 and sources[0]==Path(sources[0]).name,'Unexpected selected source')
            name=sources[0]
            require(outputs==[Path(name).stem+'.o'] and name not in selected,'Duplicate/wrong selected output')
            selected[name]=argv
    require(set(selected)==set(NEEDED) and len(links)==1,'Incomplete exact selected build closure')
    return [(name,selected[name]) for name in NEEDED],links[0]


def verify_policy(original,actual,compiler):
    require(original['environment']==actual['environment']=={},'Compiler injection changed')
    require(set(original['scopes'])==set(actual['scopes']),'Compiler scopes changed')
    for scope,wanted in original['scopes'].items():
        observed=actual['scopes'][scope]
        require(set(wanted['recipes'])==set(observed['recipes']),'Source recipe set changed')
        for name,recipe in wanted['recipes'].items():
            require(compiler._signature(recipe)==compiler._signature(observed['recipes'][name]),
                    'Original compiler/flags changed: '+scope+'/'+name)
    flags=actual['scopes']['process']['recipes']['TIRUST_interface.f']['flags']
    require(flags==['-w','-fPIC','-ffixed-line-length-132'],'Original TIRust flags must be retained')
    return {'all_original_compiler_policies_preserved':True,'TIRUST_interface_flags':flags,'optimization_experiment':False}
