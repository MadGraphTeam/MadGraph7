"""Pure transforms of the frozen n1/n3 workers; no numerical timer hooks.

Both optimization roles receive exactly the same worker. IEEE records are
observations of actual pre/post state; they do not identify newly raised flags
which were already set, or prove that internal code never raised/cleared flags.
"""
import ast
import hashlib
from pathlib import Path

BASE_WORKERS = {
    'e1e0334777c59a2e673722ad2fa3b631089e52c332b6bfd79621404f49cbaf17': 3,
    'f9f1679df57dea235518a9f50570c4a2a1f975b32136114c71cf6222e2a62093': 5,
}
CAPTURE_HELPER = 'docs/benchmarkfolder/experiments/fortran-qp-transport-profile-controller-3/worker_flags.py'
CAPTURE_HELPER_SHA256 = 'e716448ca25b7f095ce942bf50f600b6c49688211279d25be8f428407d78930e'
EXACT_FILES = ('exact-words.dat', 'exact-ieee.dat')
TIMED_FILES = ('timing.dat', 'values.dat', 'timed_status.dat',
               'timed-exact-words.dat', 'timed-ieee.dat')
ANCHOR_FILES = ('anchor-timing.dat', 'anchor-status.dat', 'anchor-exact.dat',
                'anchor-ieee.dat', 'anchor-values.dat')


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Expected one unchanged worker anchor: ' + repr(old))
    return text.replace(old, new, 1)


def capture_source():
    """Read one pinned Python string literal, without importing/executing it."""
    path = Path.cwd() / CAPTURE_HELPER
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != CAPTURE_HELPER_SHA256:
        raise ValueError('Pinned read-only IEEE helper changed')
    values = [ast.literal_eval(node.value) for node in ast.parse(raw).body
              if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'CAPTURE' for target in node.targets)]
    if len(values) != 1 or not isinstance(values[0], str):
        raise ValueError('Ambiguous IEEE capture helper')
    return values[0].replace('QP_CAPTURE_FP', 'O3_CAPTURE_FP')


DECLARATIONS = '''      INTEGER O3_FLAGS(5,2),O3_HALTING(5,2),O3_ROUND(2)
      INTEGER O3_PHASE,O3_POINT
      INTEGER*8 O3_WORDS(5)
      LOGICAL O3_TIMED
'''

EXACT = '''C     Untimed exact answer/accuracy words and read-only IEEE observations.
      IF(TRIM(COMMAND).EQ.'EXACT') THEN
         IF(SEQUENCE.NE.PREVIOUS_SEQUENCE+1.OR.NLOOPS.NE.0)
     $      GOTO 800
         PREVIOUS_SEQUENCE=SEQUENCE
         OPEN(76,FILE='exact-words.dat',STATUS='NEW')
         OPEN(77,FILE='exact-ieee.dat',STATUS='NEW')
         DO K=1,NPOINTS
            P=POINTS(:,:,K)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL O3_CAPTURE_FP(O3_FLAGS(:,1),O3_HALTING(:,1),
     $           O3_ROUND(1))
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            CALL O3_CAPTURE_FP(O3_FLAGS(:,2),O3_HALTING(:,2),
     $           O3_ROUND(2))
            DO O3_PHASE=1,2
               WRITE(77,'(3I8,10I4)') K,O3_PHASE,
     $              O3_ROUND(O3_PHASE),O3_FLAGS(:,O3_PHASE),
     $              O3_HALTING(:,O3_PHASE)
            ENDDO
            DO J=0,NDIM
               O3_WORDS(1:4)=TRANSFER(ANS(:,J),O3_WORDS(1:4))
               O3_WORDS(5)=TRANSFER(ACC(MIN(J,NSO)),O3_WORDS(5))
               WRITE(76,'(3I8,5(1X,Z16.16))') K,J,CODE,O3_WORDS
            ENDDO
         ENDDO
         CLOSE(76)
         CLOSE(77)
         WRITE(74,'(A,I12)') 'EXACTED ',SEQUENCE
         FLUSH(74)
         GOTO 100
      ENDIF
'''

ANCHOR = '''C     Optional n3 point anchors; includes the same public-call setup.
      IF(TRIM(COMMAND).EQ.'ANCHOR_DP'.OR.
     $   TRIM(COMMAND).EQ.'ANCHOR_QP') THEN
         IF(SEQUENCE.NE.PREVIOUS_SEQUENCE+1.OR.NLOOPS.LE.0)
     $      GOTO 800
         IF(NEXTERNAL.NE.5) GOTO 800
         O3_POINT=1
         IF(TRIM(COMMAND).EQ.'ANCHOR_QP') THEN
            O3_POINT=16
            IF(NLOOPS.NE.1) GOTO 800
         ENDIF
         PREVIOUS_SEQUENCE=SEQUENCE
         TIMED_CODES=0
         CALL O3_CAPTURE_FP(O3_FLAGS(:,1),O3_HALTING(:,1),
     $        O3_ROUND(1))
         CALL SYSTEM_CLOCK(T0)
         DO L=1,NLOOPS
            P=POINTS(:,:,O3_POINT)
            TOTAL=P(:,1)+P(:,2)
            MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
            CALL UPDATE_AS_PARAM()
            ANS=0D0
            CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
            IF(CODE.LT.0.OR.CODE.GT.499) STOP 4
            TIMED_CODES(CODE)=TIMED_CODES(CODE)+1
         ENDDO
         CALL SYSTEM_CLOCK(T1)
         CALL O3_CAPTURE_FP(O3_FLAGS(:,2),O3_HALTING(:,2),
     $        O3_ROUND(2))
         ELAPSED=DBLE(T1-T0)/DBLE(RATE)
         OPEN(76,FILE='anchor-timing.dat',STATUS='REPLACE')
         WRITE(76,'(2ES26.17E3)') COLD,ELAPSED
         CLOSE(76)
         OPEN(76,FILE='anchor-status.dat',STATUS='REPLACE')
         DO I=0,499
            IF(TIMED_CODES(I).GT.0) WRITE(76,'(I5,1X,I20)')
     $           I,TIMED_CODES(I)
         ENDDO
         CLOSE(76)
         OPEN(76,FILE='anchor-exact.dat',STATUS='REPLACE')
         OPEN(77,FILE='anchor-ieee.dat',STATUS='REPLACE')
         DO O3_PHASE=1,2
            WRITE(77,'(3I8,10I4)') O3_POINT,O3_PHASE,
     $           O3_ROUND(O3_PHASE),O3_FLAGS(:,O3_PHASE),
     $           O3_HALTING(:,O3_PHASE)
         ENDDO
         DO J=0,NDIM
            O3_WORDS(1:4)=TRANSFER(ANS(:,J),O3_WORDS(1:4))
            O3_WORDS(5)=TRANSFER(ACC(MIN(J,NSO)),O3_WORDS(5))
            WRITE(76,'(3I8,5(1X,Z16.16))') O3_POINT,J,CODE,O3_WORDS
         ENDDO
         CLOSE(76)
         CLOSE(77)
         OPEN(76,FILE='anchor-values.dat',STATUS='REPLACE')
         DO J=0,NDIM
            WRITE(76,'(3I8,5ES26.17E3)') O3_POINT,J,CODE,
     $           ANS(:,J),ACC(MIN(J,NSO))
         ENDDO
         CLOSE(76)
         WRITE(74,'(A,2I12)') 'ANCHORED ',SEQUENCE,NLOOPS
         FLUSH(74)
         GOTO 100
      ENDIF
'''

TIMED_EXACT = '''C     Final full100 words and batch observations, outside the clock.
      IF(O3_TIMED) THEN
         OPEN(76,FILE='timed-exact-words.dat',STATUS='REPLACE')
         OPEN(77,FILE='timed-ieee.dat',STATUS='REPLACE')
         DO O3_PHASE=1,2
            WRITE(77,'(3I8,10I4)') 0,O3_PHASE,O3_ROUND(O3_PHASE),
     $           O3_FLAGS(:,O3_PHASE),O3_HALTING(:,O3_PHASE)
         ENDDO
         DO K=1,NPOINTS
            DO J=0,NDIM
               O3_WORDS(1:4)=TRANSFER(VALUES(:,J,K),O3_WORDS(1:4))
               O3_WORDS(5)=TRANSFER(ACCURACIES(MIN(J,NSO),K),
     $              O3_WORDS(5))
               WRITE(76,'(3I8,5(1X,Z16.16))') K,J,CODES(K),O3_WORDS
            ENDDO
         ENDDO
         CLOSE(76)
         CLOSE(77)
      ENDIF
'''


def worker(text):
    """Return the identical common observer for either frozen n1/n3 worker."""
    checksum = hashlib.sha256(text.encode()).hexdigest()
    if checksum not in BASE_WORKERS:
        raise ValueError('Worker is not an unchanged frozen n1/n3 source: ' + checksum)
    text = once(text, '      CHARACTER*16 COMMAND\n', '      CHARACTER*16 COMMAND\n' + DECLARATIONS)
    text = once(text, '      IF(NDIM.NE.MAX(NSO,NSQSO_BORN)) STOP 2\n',
                '      IF(NDIM.NE.MAX(NSO,NSQSO_BORN)) STOP 2\n' +
                '      IF(NDIM.NE.1.OR.NSO.NE.1.OR.NSQSO_BORN.NE.1) STOP 31\n')
    text = once(text, '      IF(NPOINTS.LE.0) STOP 1\n',
                '      IF(NPOINTS.LE.0) STOP 1\n      IF(NPOINTS.NE.100) STOP 31\n')
    marker = "      IF(TRIM(COMMAND).NE.'RUN') GOTO 800\n"
    dispatch = "      O3_TIMED=.FALSE.\n" + EXACT + ANCHOR + '''      O3_TIMED=TRIM(COMMAND).EQ.'TIMED'
      IF(O3_TIMED) COMMAND='RUN'
'''
    text = once(text, marker, dispatch + marker)
    text = once(text, '      TIMED_CODES=0\n      CALL SYSTEM_CLOCK(T0)\n', '''      TIMED_CODES=0
      IF(O3_TIMED) CALL O3_CAPTURE_FP(O3_FLAGS(:,1),
     $ O3_HALTING(:,1),O3_ROUND(1))
      CALL SYSTEM_CLOCK(T0)
''')
    text = once(text, '      CALL SYSTEM_CLOCK(T1)\n      ELAPSED=DBLE(T1-T0)/DBLE(RATE)\n', '''      CALL SYSTEM_CLOCK(T1)
      IF(O3_TIMED) CALL O3_CAPTURE_FP(O3_FLAGS(:,2),
     $ O3_HALTING(:,2),O3_ROUND(2))
      ELAPSED=DBLE(T1-T0)/DBLE(RATE)
''')
    text = once(text, "      WRITE(74,'(A,2I12)') 'DONE ',SEQUENCE,NLOOPS\n",
                TIMED_EXACT + "      WRITE(74,'(A,2I12)') 'DONE ',SEQUENCE,NLOOPS\n")
    return text + capture_source()
