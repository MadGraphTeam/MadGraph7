# Dormant genuine-QP mass caller units

This subtree is source-only. No compiler, linker, loader or Fortran executable
has run. The ten normal/optimized tests use synthetic text from the independent
integer oracle; those are parser tests, never recorded native output.

`helper.f` renders the actual private `LOOP_3_QPMASS` template from source index
`75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25`.
It has three propagators, rank2, one group, `NSQUAREDSO=1`, three initialized
wavefunctions and the private `QPMUNIT_` namespace. This is an explicit source
fixture, not an actual full CLI physical process. Both driver and helper import
the real current `ALOHA_OBJECT.mod`; both helper/stubs and driver include the
real current `MadLoopParams.inc`. `build-spec.json` pins those bytes, their
source/provenance, compiler and original process flags. Binary module bytes are
not copied into this source packet.

The driver embeds an actual new call-writer-generated complete guarded block.
Its unit model variables are a binary128 sqrt(2), a complex dyadic value with
real/imaginary terms below binary64 precision, and binary64 4.7 promoted to
binary128. The first two discriminate genuine113-bit input arguments; the
third discriminates QP squaring of an otherwise promoted DP mass. The strict
independent oracle derives nearest-binary128 sqrt(2) by integer rounding-cell
inequalities, performs exact rational complex squaring/rounding, and encodes
binary64/binary128 storage directly with integers. For these selected inputs
it also proves separately rounded complex products give the same final words.
It never computes an expected answer through a reducer or native math library.

The recording CHOOSE stub returns index2/backend9 while index1, the requested
list entry, is backend8. Both actual helper calls, CTMode4 and5, must therefore
use the **actual selected** index9 guard after CHOOSE and pass the QP squares
in cyclic order `[mass3,mass1,mass2]`. The only linked reduction target is a
recording MP stub. Legacy LOOP, CutTools and generic TIR targets fail closed;
Ninja/NinjaRS/Samurai availability is false in this unit render. The stub
returns labelled synthetic coefficients solely to observe argument/status
plumbing. No real reducer, choice kernel, contraction, counterterm or physics
calculation is present.

The recording MP target sees the mass array before a real `MP_SWITCH_ORDER`.
Thus equal CT4/CT5 recorded arrays do not qualify actual direction reversal.
The driver records the unit model arguments, paired DP arguments, received QP
mass-square words, synthetic returned words, stable/common/call counters and
read-only IEEE state. No IEEE control/flag setter is used. Nearest rounding and
disabled halting are required for this normal unit; invalid, divide-by-zero,
overflow or underflow flags fail. Inexact may be raised and must remain sticky.
The initial five flags must be zero; no inherited flag is cleared to pass.

`parser.py` exposes `parse(text) -> dict` and accepts exactly36 ordered records:
the header, initial/prepared state, two complete call journals and the final
footer. All raw storage words must match the integer oracle, including the
genuine-QP bits and the105-bit exact bottom-mass square. Missing/duplicate
records, wrong order/backend/group, narrowed arguments, fatal flags, changed
rounding/halting, cleared inexact or wrong completion counters fail explicitly.
Success from arbitrary supplied text does not prove that an executable ran;
the parent RUN owner must join the actual command, ELF/runtime and cleanup.

`build-spec.json` supplies four dormant compile argv lists and one link argv
using `{units}` and `{work}` placeholders. `records.f90` must compile first so
the remaining units can import its module. Reuse the exact original process
flags `-w -fPIC -ffixed-line-length-132`; the same fixed-form flag is harmless
for the logger's `.f90` free-form source. The real ALOHA module is read only;
neither ALOHA routines nor a reducer library is linked. A separately admitted
BUILD must check actual linker LOAD, PT_INTERP and runtime providers. Its
system/compiler closure is a subset, and must not be confused with the physical
amplitude's fifteen-provider runtime closure. Execution belongs to a separately
reviewed parent `units` RUN phase; this subtree authorizes none.

These units can qualify the compiled caller's MP mass transport and squaring
if they later execute successfully. They cannot qualify full CLI generation,
SM derived/CMS model initialization, current choice/reversal kernels, physical
amplitude accuracy, checked QP rescues, cache behavior or performance. Historical
mass-transport refusals remain unchanged. The current default-true numerator
policy is separate; no `UseQPIntegrandForTIRust=.FALSE.` qualification follows.
