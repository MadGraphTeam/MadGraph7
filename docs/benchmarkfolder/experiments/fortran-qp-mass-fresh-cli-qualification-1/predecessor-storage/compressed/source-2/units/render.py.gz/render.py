#!/usr/bin/env python3
"""Exclusive source-only unit rendering. No compiler, loader or native worker."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest import mock

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'.tirust-build/qp-mass-current-backend9-source-1'
SOURCE_SHA='75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25'
CASE=ROOT/'.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n3_uux_zgg'
sys.path.insert(0,str(ROOT))
import aloha
from madgraph.core import base_objects,helas_objects
from madgraph.loop import loop_helas_objects
from madgraph.iolibs import file_writers
from madgraph.various import misc


def require(value,message):
    if not value:raise ValueError(message)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path,value):
    with path.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')


def guarded_call():
    path=SOURCE/'src/madgraph/iolibs/helas_call_writers.py'
    spec=importlib.util.spec_from_file_location('qpmass_units_call_writer',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    seed=helas_objects.HelasWavefunction({'number':1,'is_loop':True})
    names=['MDL_MW','MDL_MT','MDL_MB'];widths=['ZERO','MDL_WT','ZERO']
    lines=[helas_objects.HelasWavefunction({
        'particle':base_objects.Particle({'mass':name,'width':width}), 'is_loop':True,
        'mothers':helas_objects.HelasWavefunctionList([seed])}) for name,width in zip(names,widths,strict=True)]
    amp=loop_helas_objects.LoopHelasAmplitude({
        'wavefunctions':helas_objects.HelasWavefunctionList([seed,seed]+lines),
        'mothers':helas_objects.HelasWavefunctionList([helas_objects.HelasWavefunction({'number':i}) for i in [1,2,3]]),
        'amplitudes':helas_objects.HelasAmplitudeList([helas_objects.HelasAmplitude({'number':1})]),
        'pairing':[1,1,1],'number':1,'loop_group_id':0})
    writer=module.FortranUFOHelasCallWriterOptimized(base_objects.Model())
    with mock.patch.object(aloha,'complex_mass',True),mock.patch.object(loop_helas_objects.LoopHelasAmplitude,'get_analytic_info',return_value=2):
        result=writer.get_amplitude_call(amp)%{'proc_prefix':'QPMUNIT_'}
    require('CMPLX(MP__CMASS_MDL_MT,KIND=16)' in result,'Actual CMS symbol selection missing')
    return result


def main():
    require(sha(SOURCE/'source-index.json')==SOURCE_SHA,'Source seal changed')
    source_index=json.loads((SOURCE/'source-index.json').read_text())
    for name,wanted in source_index['files'].items():
        path=SOURCE/name;require(path.stat().st_size==wanted['bytes'] and sha(path)==wanted['sha256'],'Source payload changed')
    for name in ('helper.f','driver.f','guarded-call.txt','rendering.json','build-spec.json'):
        require(not (HERE/name).exists(),'Unit preparation is exclusive')
    context=dict(AmplitudeReduction=False,LoopInduced=False,samurai_available=False,
        ninja_available=False,ninja_supports_quad_prec=False,ninjars_available=False,
        ninjars_supports_quad_prec=False,tirust_available=True,tirust_supports_quad_prec=True)
    mapping=dict(proc_prefix='QPMUNIT_',nloopline=3,nwfsargs_header='',nexternal=5,
        nloopamps=1,nctamps=0,nwavefuncs=3,nloop_groups=1,ncomb=1,nSquaredSO=1,
        wfsargs='W1,W2,W3,',wfsargsdecl='W1,W2,W3',margs='M1,M2,M3,',
        margsdecl='M1,M2,M3',mp_margsdecl='MP_M1,MP_M2,MP_M3',pairingargs='',pairingdecl='',
        nwfsargs=3,weset='WE(1)=W1\nWE(2)=W2\nWE(3)=W3',
        mset='M2L(1)=M3**2\nM2L(2)=M1**2\nM2L(3)=M2**2',
        pairingset='DO I=1,NLOOPLINE\nPAIRING(I)=1\nENDDO',
        qp_mass_args='M1,MP_M1,M2,MP_M2,M3,MP_M3,',
        qp_mass_legacy_args='W1,W2,W3,M1,M2,M3,RANK,SQUAREDSOINDEX,LOOPNUM',
        qp_mass_square_assignment='MP_M2L(1)=MP_M3**2\nMP_M2L(2)=MP_M1**2\nMP_M2L(3)=MP_M2**2',
        real_dp_format='REAL*8',real_mp_format='REAL*16',complex_dp_format='COMPLEX*16',
        complex_mp_format='COMPLEX*32',mass_dp_format='COMPLEX*16')
    template=SOURCE/'src/madgraph/iolibs/template_files/loop_optimized/helas_loop_amplitude_qpmass.inc'
    body=misc.apply_template(template.read_text(),mapping)
    with file_writers.FortranWriter(str(HERE/'helper.f')) as stream:stream.writelines(body,context=context)
    call=guarded_call()
    with (HERE/'guarded-call.txt').open('x') as stream:stream.write(call+'\n')
    driver=(HERE/'driver.f.in').read_text()
    require(driver.count('@GUARDED_CALL@')==1,'Driver call token missing')
    with file_writers.FortranWriter(str(HERE/'driver.f')) as stream:
        stream.writelines(driver.replace('@GUARDED_CALL@',call),context=context)
    require('MP_TIRUST_LOOP_QPMASS' in (HERE/'helper.f').read_text(),'Expected private recording target missing')
    require('MP_NINJARS_LOOP' not in (HERE/'helper.f').read_text(),'Reducer availability exclusion failed')
    sources=['records.f90','helper.f','stubs.f','driver.f']
    dependency_paths=[CASE/'Source/DHELAS/aloha_object.mod',CASE/'Source/DHELAS/aloha_functions.f',
        CASE/'SubProcesses/MadLoopParams.inc',CASE/'compilation.json',SOURCE/'source-index.json',
        template,SOURCE/'src/madgraph/iolibs/helas_call_writers.py']
    compiler=Path('/nix/store/5km6kqfhjr16939ak9l1crzsh6x96f68-gfortran-wrapper-15.2.0/bin/gfortran')
    dependency_paths.append(compiler)
    dependencies={str(p):sha(p) for p in dependency_paths}
    base_flags=['-w','-fPIC','-ffixed-line-length-132']
    common=base_flags+['-I','{work}','-I',str(CASE/'Source/DHELAS'),'-I',str(CASE/'SubProcesses'),'-J','{work}']
    compiles=[{'label':'units-'+Path(name).stem,'argv':[str(compiler),*common,'-c','{units}/'+name,'-o','{work}/'+Path(name).stem+'.o']} for name in sources]
    dump(HERE/'build-spec.json',{'schema':'source-only-qp-mass-units-build-spec-v1','sources':sources,
        'dependencies':dependencies,'compiler_flags_same_as_original_process':base_flags,
        'compiler_commands_executed':0,'compile_commands':compiles,
        'link_command':[str(compiler),*['{work}/'+Path(name).stem+'.o' for name in sources],'-o','{work}/unit_mass_check'],
        'runtime_binding':'Actual unit PT_INTERP/listing and hashes must be checked separately; expect a subset of compiler/system providers, no reducer DSOs.',
        'execution_command':['{work}/unit_mass_check'],'execution_admitted':False,
        'only_recording_stubs_linked':True,'real_CHOOSER_or_direction_switch_or_reducer_qualified':False})
    dump(HERE/'rendering.json',{'schema':'qp-mass-actual-source-unit-render-v1','source_index_sha256':SOURCE_SHA,
        'template_sha256':sha(template),'context':context,'mapping':mapping,
        'dependency_hashes':dependencies,'generated_hashes':{name:sha(HERE/name) for name in ['helper.f','driver.f','guarded-call.txt']},
        'actual_generated_CALL_writer_used':True,'actual_ALOHA_module_hash_bound':True,
        'actual_MadLoopParams_inc_hash_bound':True,'fresh_NSQUAREDSO_fixture':1,'compiler_calls':0,'native_calls':0})
    print(json.dumps({'rendered':True,'NSQUAREDSO':1,'modes':[4,5],'compiler_calls':0,'native_calls':0},sort_keys=True))


if __name__=='__main__':main()
