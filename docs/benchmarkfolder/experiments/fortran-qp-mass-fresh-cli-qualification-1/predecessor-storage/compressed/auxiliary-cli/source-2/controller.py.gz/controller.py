#!/usr/bin/env python3
"""One dormant stock CLI export; default mode only reads and hashes files."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WORK = ROOT / '.tirust-build/qp-mass-cli-generation-work-2'
REPORT = ROOT / '.tirust-build/qp-mass-cli-generation-execution-2'
MG = WORK / 'mg-current-qpmass'
OUTPUT = WORK / 'output/qcd_n3_uux_zgg'
CPU, CAP, CLEANUP = 12, 300., 60.
LIMITS = {'address_space_bytes':16*1024**3, 'file_bytes':512*1024**2, 'core_bytes':0}
CLEANUP_HELPER = 'docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/process_cleanup.py'
DEADLINE_HELPER = 'docs/benchmarkfolder/campaigns/invariant-symmetry-1/preparation-1/run.py'
DEPENDENCY_HELPER = 'docs/benchmarkfolder/experiments/current-cms-replay-supervisor-1/prerequisites.py'
EXPECTED = None


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def pin():
    return read(HERE / 'input-pins.json')


def load(name, path):
    path = Path(path)
    if not path.is_relative_to(HERE):
        require(sha(path)==pin()['support_files'][str(path.relative_to(ROOT))]['sha256'],
                'Pinned support helper changed: '+str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def dependency():
    module = load('qpmass_cli_dependencies', ROOT / DEPENDENCY_HELPER)
    module.DATA = read(HERE / 'dependencies.json')
    return module


def tool(name):
    return read(HERE / 'toolchain-pins.json')['required_tools'][name]['path']


def environment(cwd=ROOT):
    row = pin()
    helper = load('qpmass_cli_environment', HERE / 'tool_environment.py')
    env = helper.reconstruct(read(HERE / 'toolchain-pins.json'),
        row['compiler_environment_names'], row['original_compiler_environment'],
        row['library_paths'].values())
    for name in ('PYTHONPATH','PYTHONHOME','PYTHONSTARTUP'):
        env.pop(name, None)
    env.update(PWD=str(cwd), XDG_CONFIG_HOME=str(WORK/'xdg/config'),
        XDG_STATE_HOME=str(WORK/'xdg/state'), XDG_DATA_HOME=str(WORK/'xdg/data'),
        PYTHONNOUSERSITE='1')
    return env


def verify_record(path, record):
    path = Path(path)
    if record['sha256'] is None:
        require(not path.is_file(), 'Previously absent source appeared: '+str(path))
        link = record.get('link')
        require((path.is_symlink() and os.readlink(path)==link) if link is not None
                else not path.exists() and not path.is_symlink(), 'Absent/link source changed: '+str(path))
    else:
        require(path.is_file() and sha(path)==record['sha256']
                and path.stat().st_size==record['bytes'], 'Pinned file changed: '+str(path))
        if 'mode' in record:
            require(path.stat().st_mode&0o777==record['mode'], 'Pinned file mode changed: '+str(path))


def verify_source():
    require(Path.cwd()==ROOT, 'Run from the MadGraph working repository')
    require(EXPECTED and sha(HERE/'source-index.json')==EXPECTED, 'Exact reviewed source seal required')
    index = read(HERE/'source-index.json')
    verify_payload_inventory(index)
    for name, record in index['files'].items():
        verify_record(HERE/name, record)
    row = pin()
    for name, record in row['source_files'].items():
        verify_record(ROOT/name, record)
    for record in row['overlay_files'].values():
        verify_record(ROOT/record['source'], record)
    for name, record in row['support_files'].items():
        verify_record(ROOT/name, record)
    for name, record in row['protected_configuration'].items():
        verify_record(name, record)
    for key in ('physical_card','numerical_card'):
        verify_record(row[key]['path'], row[key])
    verify_record(row['original_make_opts']['path'], row['original_make_opts'])
    for name, record in row['metadata_query_tools'].items():
        verify_record(name, record)
        require(os.access(name, os.X_OK), 'Metadata query tool not executable: '+name)
    for name, records in row['reference_generated_files'].items():
        for role, directory in (('original','original_generated_dir'),
                ('preview_original','preview_original_dir'), ('preview_candidate','preview_candidate_dir')):
            verify_record(Path(row[directory])/name, records[role])
    helper = load('qpmass_cli_environment', HERE/'tool_environment.py')
    tools = helper.validate(read(HERE/'toolchain-pins.json'), environment())
    dependency().check_donors()
    return {'source_bindings':len(row['source_files']), 'overlays':row['overlay_counts'],
        'tools':tools, 'CLI_invocations':0, 'compiler_queries':0, 'compiler_invocations':0,
        'scientific_native_calls':0, 'default_mode':'pure read-only preflight'}


def verify_payload_inventory(index):
    expected=set(index['files'])|{'source-index.json'}
    actual=set()
    expected_dirs={str(parent) for name in expected for parent in Path(name).parents if str(parent)!='.'}
    for path in HERE.rglob('*'):
        name=str(path.relative_to(HERE))
        require(not path.is_symlink(), 'Proposal payload/directory symlink forbidden: '+name)
        require(path.resolve().is_relative_to(HERE.resolve()), 'Proposal path escaped source root: '+name)
        if path.is_file():actual.add(name)
        else:require(path.is_dir() and name in expected_dirs,'Unexpected proposal directory: '+name)
    require(actual==expected,'Proposal payload inventory differs: '+str(sorted(actual^expected)))


def stage_checkout():
    require(not WORK.exists(), 'Fresh work destination required; no automatic retry')
    MG.mkdir(parents=True)
    row = pin()
    for name, record in row['source_files'].items():
        target = MG/name
        require(target.resolve().is_relative_to(MG.resolve()), 'Source path escaped checkout')
        if record['sha256'] is None:
            if record.get('link') is not None:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.symlink_to(record['link'])
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/name, target, follow_symlinks=True)
        verify_record(target, record)
    for name, record in row['overlay_files'].items():
        target = MG/name
        require(target.resolve().is_relative_to(MG.resolve()), 'Overlay escaped checkout')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/record['source'], target)
        verify_record(target, record)
    dependency().copy_private('candidate', MG)
    require(not (MG/'.git').exists(), 'Isolated checkout must not inherit Git state')
    config = MG/'input/mg7_configuration.txt'
    require(not config.exists(), 'Unexpected copied user/install configuration')
    settings = {'auto_update':'0','automatic_html_opening':'False','nb_core':'1',
        'fortran_compiler':tool('gfortran'),'cpp_compiler':tool('g++'),
        **row['library_paths']}
    config.write_text((MG/'input/.mg7_configuration_default.txt').read_text()+'\n'+
        ''.join(name+' = '+value+'\n' for name,value in settings.items()))
    OUTPUT.parent.mkdir(parents=True)
    save(REPORT/'staging.json', {'source_inventory_entries':len(row['source_files']),
        'overlay_counts':row['overlay_counts'], 'private_dependency_copies':123,
        'untracked_startup_configuration':str(config), 'no_Git_operations':True})


def source_inventory(directory):
    suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
    return {str(path.relative_to(directory)):{'sha256':sha(path),'bytes':path.stat().st_size}
        for subtree in ('Source','SubProcesses')
        for path in sorted((directory/subtree).rglob('*'))
        if path.is_file() and (path.suffix.lower() in suffixes or path.name.startswith('makefile')
            or path.name in ('make_opts','MadLoop_makefile_definitions'))}


def verify_private_source():
    row=pin()
    for name, record in row['source_files'].items():
        verify_record(MG/name, row['overlay_files'].get(name,record))
    for name, record in row['overlay_files'].items():
        verify_record(MG/name,record)


def make_opts_policy():
    original=Path(pin()['original_make_opts']['path']).read_text()
    actual=(OUTPUT/'Source/make_opts').read_text()
    expected=original.replace('DEFAULT_CPP_COMPILER=g++\n',
        'DEFAULT_CPP_COMPILER='+tool('g++')+'\n').replace('DEFAULT_F_COMPILER=gfortran\n',
        'DEFAULT_F_COMPILER='+tool('gfortran')+'\n')
    require(expected!=original,'Original compiler-selector lines changed')
    save(REPORT/'make-opts-policy.json', {'original_sha256':sha(pin()['original_make_opts']['path']),
        'actual_sha256':sha(OUTPUT/'Source/make_opts'),
        'only_allowed_changes':['DEFAULT_CPP_COMPILER: exact pinned path',
            'DEFAULT_F_COMPILER: exact pinned path'], 'all_other_bytes_exact':actual==expected,
        'expanded_recipe_or_compiler_wrapper_execution_not_independently_recaptured':True})
    require(actual==expected,'Generated compiler flag policy changed beyond exact compiler selectors')


def generate():
    admission = read(REPORT/'admission.json')
    require(admission['parent_pid']==os.getppid() and admission['source_sha256']==EXPECTED,
            'Missing separate supervisor admission')
    require(os.sched_getaffinity(0)=={CPU}, 'Native child CPU differs')
    for kind, name in ((resource.RLIMIT_AS,'address_space_bytes'),
            (resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]), 'Native child resource limit differs')
    verify_source()
    stage_checkout()
    argv=[tool('python3'), '-B', './bin/madgraph', '--plain', str(HERE/'generate.mg5')]
    save(REPORT/'generation.command.json', {'argv':argv,'cwd':str(MG),
        'environment':{'PYTHONHASHSEED':'0','MAKEFLAGS':environment()['MAKEFLAGS'],
            'OMP_NUM_THREADS':'1','RAYON_NUM_THREADS':'1','XDG_CONFIG_HOME':str(WORK/'xdg/config')},
        'expected_children':'compiler/version metadata queries; stock Source/MODEL+DHELAS compilation/archive',
        'make_internal_children_individually_recorded':False})
    with (REPORT/'generation.log').open('xb') as stream:
        result=subprocess.run(argv,cwd=MG,env=environment(MG),stdout=stream,stderr=subprocess.STDOUT)
    save(REPORT/'generation.command-terminal.json', {'returncode':result.returncode,
        'log_sha256':sha(REPORT/'generation.log')})
    require(result.returncode==0,'Actual CLI failed; stop with no automatic retry')
    raw=(REPORT/'generation.log').read_text()
    require(not any(marker in raw for marker in ('Error detected','interrupted in sub-command',
        'Traceback (most recent call last)','Compiling CutTools','Compiling IREGI','Re-compiling it now')),
        'CLI failure/dependency-rebuild marker')
    require(sorted(p.name for p in (OUTPUT/'SubProcesses').glob('P*') if p.is_dir())==[pin()['subprocess']],
            'Expected exactly one n3 subprocess')
    require(not any((OUTPUT/'SubProcesses').rglob('*.o'))
        and not any((OUTPUT/'SubProcesses').rglob('check')), 'Unexpected subprocess build/native entrypoint')
    verify_private_source()
    make_opts_policy()
    deps=dependency();deps.check_private('candidate',MG)
    availability=deps.check_generated('candidate',OUTPUT,'SubProcesses/'+pin()['subprocess'])
    original_card=sha(OUTPUT/'Cards/param_card.dat')
    shutil.copy2(pin()['physical_card']['path'],OUTPUT/'Cards/param_card.dat')
    shutil.copy2(pin()['numerical_card']['path'],OUTPUT/'Cards/MadLoopParams.dat')
    for key,target in (('physical_card',OUTPUT/'Cards/param_card.dat'),
            ('numerical_card',OUTPUT/'Cards/MadLoopParams.dat')):
        verify_record(target,pin()[key])
    comparison=load('qpmass_cli_comparison',HERE/'compare.py')
    compared=comparison.compare_trees(Path(pin()['original_generated_dir']),
        OUTPUT/'SubProcesses'/pin()['subprocess'], Path(pin()['preview_original_dir']),
        Path(pin()['preview_candidate_dir']))
    save(REPORT/'source-comparison.json',compared)
    require(compared['original_preview_exact'] and compared['private_names_exact'],
        'Reviewed original/private routine family differs')
    require(compared['public_legacy_bodies_exact'], 'Actual CLI changed a public legacy routine')
    save(REPORT/'result.json', {'status':'generated_pending_source_review',
        'source_sha256':EXPECTED, 'actual_CLI_invocations':1, 'amplitude_evaluations':0,
        'source_inventory':source_inventory(OUTPUT), 'availability':availability,
        'stock_Model_DHELAS_build_objects':len(list((OUTPUT/'Source').rglob('*.o'))),
        'original_generated_param_card_sha256':original_card,
        'physical_card_sha256':sha(OUTPUT/'Cards/param_card.dat'),
        'numerical_card_sha256':sha(OUTPUT/'Cards/MadLoopParams.dat'),
        'comparison_sha256':sha(REPORT/'source-comparison.json'),
        'later_source_review_required':True,'later_selected_unit_build_or_physical_run_admitted':False})
    verify_source()


def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),
            (resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind)
        require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited resource hard limit too small')
        resource.setrlimit(kind,(value,value))


def supervise():
    cleanup=load('qpmass_cli_cleanup',ROOT/CLEANUP_HELPER)
    clock=load('qpmass_cli_deadline',ROOT/DEADLINE_HELPER)
    clock.STAGE_SECONDS=CAP;clock.CLEANUP_RESERVE=CLEANUP
    require(not REPORT.exists(),'Fresh execution destination required; no automatic retry')
    REPORT.mkdir(parents=True)
    entry={'source_sha256':EXPECTED,'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,
        'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running'}
    ownership=load('qpmass_cli_ownership',HERE/'ownership.py')
    owned=None;child=None;raw_record=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,clock.StageDeadline() as deadline:
            entry['deadline_monotonic']=deadline.end
            limits();verify_source();requests.check()
            require(not WORK.exists(),'Fresh work destination required')
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(HERE/'controller.py'),
                '--child','--source',EXPECTED]
            save(REPORT/'admission.json',{**entry,'parent_pid':os.getpid(),'command':argv})
            with (REPORT/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    child=subprocess.Popen(argv,cwd=ROOT,env=environment(),stdout=stream,
                        stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(child.pid)
                    owned=cleanup.OwnedChild(child)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=child.pid;save(REPORT/'started.json',entry)
                entry['returncode']=owned.wait(requests);requests.check()
                budget=min(55.,max(0.,deadline.end-time.monotonic()))
                entry['cleanup']=owned.stop(cooperative_seconds=budget*45/55,
                    terminate_seconds=budget*5/55,kill_seconds=budget*5/55);cleaned=True
            require(not entry['cleanup']['survivors'],'Owned children survived cleanup')
            require(entry['returncode']==0,'Generation failed; retained with no retry')
            verify_source();requests.check()
            entry.update(status='passed',result_sha256=sha(REPORT/'result.json'),
                qualification='Actual export only; source correspondence pending separate review')
            save(REPORT/'terminal.json',entry)
    except BaseException as error:
        if child is not None and not cleaned:
            try:
                if owned is not None:
                    budget=min(55.,max(0.,entry['deadline_monotonic']-time.monotonic()))
                    entry['cleanup']=owned.stop(cooperative_seconds=budget*45/55,
                        terminate_seconds=budget*5/55,kill_seconds=budget*5/55)
                else:
                    entry['cleanup']=ownership.raw_cleanup(child,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:
                entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error))
        save(REPORT/'terminal.json',entry)
        raise


def main():
    global EXPECTED
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--child',action='store_true',help=argparse.SUPPRESS)
    args=parser.parse_args();EXPECTED=args.source
    if args.child:
        generate()
    elif args.execute:
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB)
            supervise()
    else:
        print(json.dumps(verify_source(),sort_keys=True))


if __name__=='__main__':
    main()
