"""Actual two-ELF compile/link hooks. No native operation at import/preflight."""
from pathlib import Path
import hashlib,json,re,shlex,shutil
import clone_aliases

CHANGED=('CT_interface.f','TIRUST_interface.f','TIR_interface.f','loop_matrix.f','loop_CT_calls_1.f','mp_compute_loop_coefs.f','helas_calls_ampb_1.f','mp_helas_calls_ampb_1.f')
MODULES=('invariant_bounds.f90','owned_snapshots.f90','owned_exact_geometry.f90','owned_certificate.f90','owned_math.f90','owned_route_data.f90','point_match.f90')
SUB=Path('SubProcesses/P0_epem_mupmum')

def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def identity(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def check(p,pin):
    require(Path(p).is_file() and identity(p)=={k:pin[k] for k in ('bytes','sha256')},'changed bound input '+str(p))

def protected(b):
    data=read(b.HERE/'input-pins.json')
    for name,pin in data['files'].items():check(Path(name) if Path(name).is_absolute() else b.ROOT/name,pin)
    tools=read(b.HERE/'toolchain-pins.json')
    admission=b.local('tool_environment').validate(tools,b.environment())
    clone_aliases.validate_link_metadata(clone_aliases.link_metadata(Path(data['donor'])),data['original_links'])
    clone_aliases.validate_shared(Path(data['donor']),data['shared_aliases'])
    require(len(data['clean_sources'])==269 and len(data['runtime'])==15,'wrong source/runtime closure')
    require(data['runtime'][data['native_path']]=='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9','wrong native reducer')
    return {'clean_source_entries':269,'runtime_providers':15,'native_sha256':data['runtime'][data['native_path']],
            'tool_admission':admission,'compiler_queries':0,'loader_queries':0,'native_main_calls':0}

def compile_recipes(original):
    commands={}
    scope=original['compiler_flags']['scopes']['process']
    linked={Path(x).with_suffix('.f').name for x in original['objects']}
    for line in scope['expanded_make_output'].splitlines():
        argv=shlex.split(line)
        if not argv or '-c' not in argv or '-o' not in argv:continue
        source=argv[argv.index('-c')+1]
        if source in linked:
            require(source not in commands,'duplicate original compile recipe')
            require(argv[argv.index('-o')+1]==str(Path(source).with_suffix('.o')),'unexpected output recipe')
            commands[source]=argv
    require(len(commands)==19 and set(commands)==linked,'exact19 linked recipes required')
    for name,argv in commands.items():
        expected=['-w','-fPIC','-ffixed-line-length-132']+(['-O3'] if name=='polynomial.f' else [])
        require(scope['recipes'][name]['flags']==expected,'original scientific compiler flags differ')
    return commands

def replace_source(path,raw,output):
    clone_aliases.writable_relative(path.relative_to(output))
    require(path.parent.resolve().is_relative_to(output.resolve()),'source write through outside directory')
    if path.is_symlink():path.unlink()
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)

def source_inventory(output):
    return {str(p.relative_to(output)):identity(p) for p in sorted(output.rglob('*')) if p.is_file() and
            (p.suffix.lower() in ('.f','.f90','.inc','.c','.h') or p.name in ('makefile','make_opts','MadLoop_makefile_definitions'))}

def compile_argv(template,source,output):
    argv=list(template);argv[argv.index('-c')+1]=source;argv[argv.index('-o')+1]=output
    return argv

def query_callback(b,case,logs,prefix,link):
    compiler=link[0]
    names={a[2:] for a in link if a.startswith('-l')}|{'gfortran','quadmath','gcc','gcc_s','m','c'}
    filenames={f'lib{name}{suffix}' for name in names for suffix in ('.a','.so')}|{'crt1.o','Scrt1.o','crti.o','crtn.o','crtbegin.o','crtbeginS.o','crtend.o','crtendS.o'}
    seen=set();requests=set()
    def run(argv,label):
        args=list(map(str,argv));require(label not in seen and tuple(args) not in requests and len(seen)<128,'repeated/unbounded callback; no retry');seen.add(label);requests.add(tuple(args))
        if label.startswith('prelink-query-'):
            require(len(args)==2 and args[0]==compiler and (args[1]=='-print-search-dirs' or
                args[1].startswith('-print-file-name=') and args[1].split('=',1)[1] in filenames),'unadmitted prelink query')
        elif label=='actual-pt-interp-runtime':
            expected=read(b.HERE/'input-pins.json')
            require(args==[expected['interpreter'],'--list',str((case/'check').resolve())],'unadmitted loader query')
        else:raise ValueError('unadmitted callback '+label)
        return b.command(args,case,logs,prefix+'-'+label)
    return run

def build(b,directory):
    before=protected(b);data=read(b.HERE/'input-pins.json');original=read(b.ROOT/data['original_receipt'])
    recipes=compile_recipes(original);fc=recipes['CT_interface.f'][0]
    require(fc==read(b.HERE/'toolchain-pins.json')['required_tools']['gfortran']['path'],'wrong original compiler')
    base_flags=recipes['CT_interface.f'][1:recipes['CT_interface.f'].index('-c')]
    include=recipes['CT_interface.f'][recipes['CT_interface.f'].index('-o')+2:]
    loader=b.support(b.LOADER_PATH);runtime=b.local('cms_runtime');results={}
    process_objects=[Path(x).name for x in original['objects']]
    require(len(process_objects)==19 and len(set(process_objects))==19,'wrong process object list')
    for variant in ('legacy','candidate'):
        output=directory/variant
        clone_aliases.clone(Path(data['donor']) if variant=='legacy' else directory/'legacy',output,data['donor'],data['shared_aliases'],data['original_links'])
        case=output/SUB;logs=case/'owned-build-commands';logs.mkdir()
        source_set=data['clean_sources'] if variant=='legacy' else data['candidate_sources']
        for name,pin in source_set.items():
            path=b.ROOT/pin['path'];check(path,pin);replace_source(output/name,path.read_bytes(),output)
        # Cache0 applies equally to baseline and candidate before compilation.
        replace_source(case/'tir_cache_size.inc',b'      PARAMETER(TIR_CACHE_SIZE=0)\n',output)
        replace_source(case/'check_sa.f',(b.HERE/'drivers'/(variant+'.f')).read_bytes(),output)
        for name in ('param_card.dat','MadLoopParams.dat'):
            raw=(b.HERE/'cards'/name).read_bytes()
            for target in {output/'Cards'/name,case/name,output/'SubProcesses/MadLoop5_resources'/name,*output.rglob(name)}:
                replace_source(target,raw,output)
        for name,pin in data['libraries'].items():check(output/name,pin)
        for name,pin in data['module_inputs'].items():check(output/name,pin)
        canonical_library_leaves={**data['libraries'],**{n:v for n,v in data['module_inputs'].items() if n.startswith('lib/')}}
        require(len(canonical_library_leaves)==5,'exact five canonical library/module leaves required')
        library_inventory={name:identity(output/name) for name in canonical_library_leaves}
        require(library_inventory==canonical_library_leaves,'canonical reused library/module bytes differ')
        if variant=='legacy':selected=sorted(recipes)
        else:selected=sorted(set(CHANGED)|{'check_sa.f'})
        preserved={name:identity(case/name) for name in process_objects if str(Path(name).with_suffix('.f')) not in selected}
        for name in selected:(case/Path(name).with_suffix('.o')).unlink(missing_ok=True)
        extra=[]
        if variant=='candidate':
            for name in MODULES:
                obj=str(Path(name).with_suffix('.o'))
                argv=compile_argv(recipes['CT_interface.f'],name,obj)
                b.command(argv,case,logs,'module-'+Path(name).stem);extra.append(obj)
            # Strict C-header dependency closure, bound before C compilation.
            cc=data['C_compiler'];dep=b.command([cc,'-fPIC','-O2','-M','-MT','owned-token','invariant_environment.c'],case,logs,'C-dependencies')
            words=shlex.split(dep.replace('\\\n',' ').split(':',1)[1])
            actual={str((case/x).resolve()) for x in words}
            allowed=set(data['C_headers'])|{str((case/'invariant_environment.c').resolve())}
            require(actual<=allowed and len(actual)>1,'unbound C header dependency')
            b.command([cc,'-fPIC','-O2','-c','invariant_environment.c','-o','invariant_environment.o'],case,logs,'C-token-compile')
            extra.append('invariant_environment.o')
        for name in selected:b.command(recipes[name],case,logs,'compile-'+Path(name).stem)
        require(all(identity(case/name)==pin for name,pin in preserved.items()),'fresh unchanged process object changed')
        # Expand only pinned make variables; execute no make scientific target.
        (case/'owned-info.mk').write_text('include makefile\n.PHONY: owned-info\nowned-info:\n\t@$(info FC $(FC))$(info FFLAGS $(FFLAGS))$(info LINKLIBS $(LINKLIBS))$(info LDFLAGS $(LDFLAGS)) :\n')
        info=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['make']['path'],'-s','--no-print-directory','-f','owned-info.mk','owned-info'],case,logs,'make-link-info')
        fields={line.split()[0]:shlex.split(line)[1:] for line in info.splitlines() if line.strip()}
        require(set(fields)=={'FC','FFLAGS','LINKLIBS','LDFLAGS'} and fields['FC']==[fc] and fields['FFLAGS']==base_flags,'original compiler/link flag policy differs')
        require(fields['LDFLAGS']==data['original_LDFLAGS'] and fields['LINKLIBS'][-len(fields['LDFLAGS']):]==fields['LDFLAGS'],'captured original LDFLAGS differs/omitted from LINKLIBS')
        link=[fc,*fields['FFLAGS'],'-Wl,-Map,owned-link.map,--cref','-o','check',*process_objects,*extra,*fields['LINKLIBS']]
        callback=query_callback(b,case,logs,variant,link)
        pre=loader.prelink(link,case,b.environment(),callback)
        # Authenticate and prebind all15 original providers BEFORE link/list.
        for name,wanted in data['runtime'].items():
            require(digest(name)==wanted and pre['bound'].get(name,wanted)==wanted,'runtime changed/conflicted before link')
        pre['bound'].update(data['runtime']);pre['explicit_CMS_runtime_before_link']=dict(data['runtime'])
        b.dump(case/'owned-prelink.json',pre)
        b.command(link,case,logs,'link')
        loads=loader.requireactualmap((case/'owned-link.map').read_text(),case,pre,case/'check')
        static=runtime.derive(case/'check',pre,data['runtime'],b.environment()['LD_LIBRARY_PATH'])
        require(static['files']==data['runtime'],'static runtime closure differs before loader')
        b.dump(case/'owned-static-runtime.json',static)
        observed=loader.query_runtime(case/'check',data['runtime'],pre,callback)
        nm=b.command([read(b.HERE/'toolchain-pins.json')['required_tools']['nm']['path'],'--defined-only','check'],case,logs,'symbols')
        names=re.findall(r'^[0-9a-fA-F]+\s+[A-Za-z]\s+(\S+)$',nm,re.M)
        expected_private=data['candidate_symbols'] if variant=='candidate' else []
        require(all(names.count(x)==1 for x in expected_private),'private definition missing/duplicate')
        if variant=='legacy':require(not any('_pm_' in x or '_pointmatch_' in x or '_owned_' in x for x in names),'baseline private scientific symbol present')
        require({x:names.count(x) for x in names if '__mtirust_MOD_' in x}=={x:1 for x in data['mtirust_symbols']},'installed MTIRUST ownership differs')
        require(all(identity(case/name)==pin for name,pin in preserved.items()),'link changed fresh unchanged process object')
        results[variant]={'path':str(case/'check'),'sha256':digest(case/'check'),'source_inventory':source_inventory(output),
            'objects':{str(p.relative_to(output)):identity(p) for p in output.rglob('*.o') if p.is_file()},
            'canonical_reused_library_leaves':library_inventory,'immutable_shared_aliases':clone_aliases.validate_shared(output,data['shared_aliases']),
            'extra_objects':extra,'recompiled_units':selected,'preserved_fresh_process_objects':preserved,
            'prelink_sha256':digest(case/'owned-prelink.json'),'link_map_sha256':digest(case/'owned-link.map'),
            'static_runtime_sha256':digest(case/'owned-static-runtime.json'),'runtime':observed,'actual_link_loads':loads,
            'native_main_calls':0,'link_command':link}
    for variant in results:clone_aliases.validate_shared(directory/variant,data['shared_aliases'])
    require(protected(b)==before,'protected source/tool/runtime changed during BUILD')
    b.dump(directory/'result.json',{'status':'passed','source_index_sha256':b.EXPECTED_SOURCE,'variants':results,
        'native_main_calls':0,'model_calls':0,'reducer_calls':0,'performance_qualified':False,
        'snapshot_owner_qualified':False,'q_lowering_qualified':False,'full_caller_qualified':False,'scientific_dispatch_enabled':False})
