"""Exact two read-only shared aliases; no general symlink allowance."""
from pathlib import Path
import hashlib
SHARED={'lib/ninjars_include','lib/ninjars_lib'}
CAP=256*1024**2

def require(ok,message):
    if not ok:raise ValueError(message)
def identity(p):
    b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def link_metadata(root):
    return {str(p.relative_to(root)):{'readlink':str(p.readlink()),'resolved':str(p.resolve()),'directory':p.is_dir()}
            for p in sorted(Path(root).rglob('*')) if p.is_symlink()}
def validate_link_metadata(found,expected):
    require(found==expected,'unexpected/retargeted source alias')
def validate_shared(root,aliases):
    require(set(aliases)==SHARED,'exact two shared aliases required')
    inventory={}
    for name,row in aliases.items():
        p=Path(root)/name;target=Path(row['canonical_target'])
        require(p.is_symlink() and str(p.readlink())==row['readlink'] and p.resolve()==target,'shared alias retargeted')
        entries={x.name:x for x in target.iterdir()}
        require(set(entries)==set(row['exact_regular_leaf_inventory']),'shared alias inventory changed')
        actual={}
        for leaf,pin in row['exact_regular_leaf_inventory'].items():
            f=entries[leaf]
            require(not f.is_symlink() and f.is_file(),'shared leaf must remain regular')
            actual[leaf]=identity(f)
            require(actual[leaf]==pin,'shared archive/include/module leaf changed')
        inventory[name]={'readlink':str(p.readlink()),'canonical_target':str(p.resolve()),'exact_regular_leaf_inventory':actual}
    return inventory
def below_shared(relative):
    p=Path(relative)
    return any(p==Path(name) or Path(name) in p.parents for name in SHARED)
def planned_action(relative,size,cap=CAP):
    require(cap==CAP,'file cap may not be raised')
    if below_shared(relative):return 'immutable-shared-reference'
    require(0<=size<=cap,'copy would exceed retained256MiB file cap')
    return 'copy-private-file'
def writable_relative(relative):
    p=Path(relative)
    require(not p.is_absolute() and '..' not in p.parts and not below_shared(p),'write outside private mutable source/card/object paths')
def clone(donor,output,original,aliases,original_links):
    donor,output=Path(donor),Path(output)
    expected=original_links if donor.resolve()==Path(original).resolve() else {
        name:{'readlink':row['readlink'],'resolved':row['canonical_target'],'directory':True} for name,row in aliases.items()}
    validate_link_metadata(link_metadata(donor),expected);validate_shared(donor,aliases)
    def ignore(directory,names):
        return [n for n in names if str((Path(directory)/n).relative_to(donor)) in SHARED or
            n=='__pycache__' or n.startswith('owned-') or n.endswith(('.pyc','.fifo','HelFilter.dat','LoopFilter.dat')) or n in ('check','worker-raw')]
    def copy_private(source,destination):
        relative=Path(destination).relative_to(output);writable_relative(relative)
        require(Path(destination).parent.resolve().is_relative_to(output.resolve()),'copy destination escapes clone')
        planned_action(relative,Path(source).stat().st_size)
        return __import__('shutil').copy2(source,destination)
    __import__('shutil').copytree(donor,output,symlinks=False,ignore=ignore,copy_function=copy_private)
    for name,row in aliases.items():(output/name).symlink_to(row['canonical_target'],target_is_directory=True)
    expected={name:{'readlink':row['readlink'],'resolved':row['canonical_target'],'directory':True} for name,row in aliases.items()}
    validate_link_metadata(link_metadata(output),expected);validate_shared(output,aliases);validate_shared(donor,aliases)
