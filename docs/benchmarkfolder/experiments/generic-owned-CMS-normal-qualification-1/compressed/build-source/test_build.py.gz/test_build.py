"""Pure source/recipe/callback checks; no compiler or loader executions."""
from pathlib import Path
import copy,json,unittest
import cms_build as c
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
class PlainCMSBuild(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=c.read(HERE/'input-pins.json');cls.old=c.read(ROOT/cls.data['original_receipt'])
    def test_exact19_original_recipes_and_fresh10_reuse(self):
        r=c.compile_recipes(self.old);self.assertEqual(len(r),19)
        self.assertEqual(len(set(r)-set(c.CHANGED)-{'check_sa.f'}),10)
    def test_polynomial_only_O3_and_no_new_optimization(self):
        r=c.compile_recipes(self.old)
        self.assertIn('-O3',r['polynomial.f'])
        self.assertFalse(any(any(x.startswith('-O') for x in argv) for name,argv in r.items() if name!='polynomial.f'))
    def test_unsupported_flag_recipe_refuses(self):
        old=copy.deepcopy(self.old);old['compiler_flags']['scopes']['process']['recipes']['CT_interface.f']['flags'].append('-ffast-math')
        with self.assertRaises(ValueError):c.compile_recipes(old)
    def test_complete_origin_runtime_and_all8_plus_helpers(self):
        self.assertEqual(len(self.data['clean_sources']),269);self.assertEqual(len(self.data['runtime']),15)
        self.assertEqual(len(c.CHANGED),8);self.assertEqual(len(c.MODULES),7)
        self.assertLess(c.MODULES.index('owned_exact_geometry.f90'),c.MODULES.index('owned_math.f90'))
        self.assertLess(c.MODULES.index('owned_certificate.f90'),c.MODULES.index('owned_math.f90'))
    def test_public_source_prefixes_and_exact_unchanged_sources(self):
        changed=0
        for name,pin in self.data['clean_sources'].items():
            if name not in self.data['candidate_sources']:continue
            old=(ROOT/pin['path']).read_bytes();new=(ROOT/self.data['candidate_sources'][name]['path']).read_bytes()
            if Path(name).name in c.CHANGED:
                self.assertTrue(new.startswith(old),name);changed+=1
            elif Path(name).name!='tir_cache_size.inc':self.assertEqual(old,new,name)
        self.assertEqual(changed,8)
    def test_plain_drivers_bind_real_two_entries_and_no_observer(self):
        for lane,name in (('legacy','ML5_0_SLOOPMATRIX_THRES'),('candidate','ML5_0_PM_SLOOPMATRIX_THRES')):
            source=(HERE/'drivers'/(lane+'.f')).read_text().upper()
            self.assertIn(name,source);self.assertNotIn('USE ML5_0_CMS_OBSERVER',source)
            self.assertNotIn('@',source)
            self.assertIn('FORCE_STABILITY_CHECK(.TRUE.)',source)
    def test_cache0_normal_card_controls(self):
        rows=(HERE/'cards/MadLoopParams.dat').read_text().splitlines()
        for name,value in (('MLReductionLib','9'),('CTModeRun','-1'),('LoopPoleMode','-1'),('TIRustGlobalCache','0')):
            i=rows.index('#'+name);self.assertEqual(rows[i+1].strip(),value)
    def test_exact_native_and_wrapper_owner_list(self):
        self.assertEqual(self.data['runtime'][self.data['native_path']],'eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9')
        self.assertEqual(len(self.data['candidate_symbols']),18)
        self.assertEqual(len(set(self.data['candidate_symbols'])),18)
        self.assertTrue(self.data['mtirust_symbols'])
    def test_compile_argument_rebinding_changes_only_source_output(self):
        original=c.compile_recipes(self.old)['CT_interface.f'];new=c.compile_argv(original,'owned_math.f90','owned_math.o')
        self.assertEqual(len(original),len(new));self.assertEqual(sum(a!=b for a,b in zip(original,new)),2)
    def test_strict_callback_accepts_only_bounded_current_compiler_or_loader_queries(self):
        class Fake:
            HERE=HERE
            calls=[]
            def command(self,args,*unused):self.calls.append(args);return 'source-only-mock'
        b=Fake();fc=c.compile_recipes(self.old)['CT_interface.f'][0]
        cb=c.query_callback(b,HERE,HERE,'mock',[fc,'-o','check','-lmodel'])
        self.assertEqual(cb([fc,'-print-search-dirs'],'prelink-query-000'),'source-only-mock')
        self.assertEqual(cb([fc,'-print-file-name=libmodel.a'],'prelink-query-001'),'source-only-mock')
        with self.assertRaises(ValueError):cb([fc,'-print-file-name=libmodel.a'],'prelink-query-002')
        with self.assertRaises(ValueError):cb([fc,'-c','unbound.f'],'prelink-query-003')
        with self.assertRaises(ValueError):cb(['/bin/echo','bad'],'unbound')
        with self.assertRaises(ValueError):cb([self.data['interpreter'],'--list','other'],'actual-pt-interp-runtime')
        self.assertEqual(len(b.calls),2)
    def test_no_native_or_RUN_admission_and_original_supervisor_reused(self):
        source=(HERE/'controller.py').read_text()
        self.assertIn("b.CAPS={'build':1800.}",source)
        self.assertIn("b.CLEANUP=60.",source)
        self.assertIn("b.BOOTSTRAP_STARTED=START",source)
        self.assertIn('bf281d5f97e6d442da8740d21954ceac1cf817314063f7bcfe17a6c6fe9b3ca9',source)
        self.assertIn('RUN is not admitted or implemented',source)
        self.assertFalse(self.data['native_admitted'])

    def test_exact_CMS_static_closure_on_original_ELF_bytes(self):
        import cms_runtime
        bound={'bound':{**self.old['prelink_bound'],**self.data['runtime']}}
        paths=':'.join([str(ROOT/'HEPTools/ninja/lib'),str(ROOT/'HEPTools/collier'),str(ROOT/'HEPTools/ninjars/lib'),str(Path(self.data['native_path']).parent)])
        actual=cms_runtime.derive(self.old['executable'],bound,self.data['runtime'],paths)
        self.assertEqual(actual['files'],self.data['runtime'])
        self.assertEqual(actual['compiler_or_loader_invocations'],0)
        self.assertEqual(cms_runtime.absolute_paths('','absolute RUNPATH'),[])
        for text in ('/a::/b','$ORIGIN/lib','relative'):
            with self.assertRaises(ValueError):cms_runtime.absolute_paths(text,'absolute RUNPATH')
    def test_static_closure_rejects_wrong_first_provider_before_loader(self):
        import cms_runtime
        bound={'bound':{**self.old['prelink_bound'],**self.data['runtime']}}
        wrong=next(str(Path(p).parent) for p in self.data['runtime'] if Path(p).name.startswith('libgfortran.so'))
        paths=':'.join([wrong,str(ROOT/'HEPTools/ninja/lib'),str(ROOT/'HEPTools/collier'),str(ROOT/'HEPTools/ninjars/lib'),str(Path(self.data['native_path']).parent)])
        with self.assertRaisesRegex(ValueError,'first existing runtime candidate differs'):
            cms_runtime.derive(self.old['executable'],bound,self.data['runtime'],paths)

    def test_only_exact_two_immutable_aliases_survive(self):
        import clone_aliases as a
        self.assertEqual(set(self.data['shared_aliases']),a.SHARED)
        metadata={name:{'readlink':row['readlink'],'resolved':row['canonical_target'],'directory':True} for name,row in self.data['shared_aliases'].items()}
        a.validate_link_metadata(metadata,metadata)
        changed=dict(metadata);changed['lib/unexpected']={'readlink':'/tmp','resolved':'/tmp','directory':True}
        with self.assertRaises(ValueError):a.validate_link_metadata(changed,metadata)
        changed={k:dict(v) for k,v in metadata.items()};changed['lib/ninjars_lib']['resolved']='/tmp'
        with self.assertRaises(ValueError):a.validate_link_metadata(changed,metadata)
    def test_large_archive_metadata_is_referenced_never_copied(self):
        import clone_aliases as a
        big=298293528
        self.assertGreater(big,a.CAP)
        for name in a.SHARED:
            self.assertEqual(a.planned_action(name+'/libninjars.a',big),'immutable-shared-reference')
        self.assertEqual(a.planned_action('lib/libmodel.a',15079324),'copy-private-file')
        with self.assertRaises(ValueError):a.planned_action('lib/ninjars_fake/libninjars.a',big)
        with self.assertRaises(ValueError):a.planned_action('any',1,512*1024**2)
    def test_source_card_object_writes_cannot_use_shared_or_escaping_paths(self):
        import clone_aliases as a
        for name in ('Cards/param_card.dat','SubProcesses/P0/check_sa.o','SubProcesses/P0/owned_math.mod'):
            a.writable_relative(name)
        for name in ('lib/ninjars_include/mninjars.mod','lib/ninjars_lib/libninjars.a','../outside','/outside'):
            with self.assertRaises(ValueError):a.writable_relative(name)
        with self.assertRaises(ValueError):c.replace_source(Path('/tmp/unowned-source'),b'no',HERE)
    def test_shared_leaf_inventory_has_full_archive_and_module_hashes(self):
        for row in self.data['shared_aliases'].values():
            leaves=row['exact_regular_leaf_inventory']
            self.assertEqual(len(leaves),8)
            self.assertEqual(leaves['libninjars.a']['bytes'],298293528)
            self.assertEqual(leaves['libninjars.a']['sha256'],'0edfa89d7d83161a6ce3fdf0bb1fbca928b73d2b5ec44211a3b2efa186a155d6')
            self.assertEqual(leaves['mninjars.mod']['bytes'],2102)
    def test_narrow_clone_never_weakens_global_symlink_or_cap_check(self):
        source=(HERE/'clone_aliases.py').read_text()
        self.assertIn("validate_link_metadata(link_metadata(output),expected)",source)
        self.assertIn("copy_function=copy_private",source)
        self.assertIn("planned_action(relative,Path(source).stat().st_size)",source)
        self.assertIn("writable_relative(relative)",source)
        wrapper=(HERE/'controller.py').read_text()
        self.assertIn('generic-owned-CMS-plain-build-work-2',wrapper)
        self.assertNotIn('generic-owned-CMS-plain-build-work-1',wrapper)

    def test_canonical_library_and_alias_inventory_are_distinct_from_rglob(self):
        names=set(self.data['libraries'])|{n for n in self.data['module_inputs'] if n.startswith('lib/')}
        self.assertEqual(len(names),5)
        self.assertIn('lib/mpmodule.mod',names)
        source=(HERE/'cms_build.py').read_text()
        self.assertIn("'canonical_reused_library_leaves':library_inventory",source)
        self.assertIn("'immutable_shared_aliases':clone_aliases.validate_shared(output,data['shared_aliases'])",source)
        self.assertIn("for name,pin in data['module_inputs'].items():check(output/name,pin)",source)
