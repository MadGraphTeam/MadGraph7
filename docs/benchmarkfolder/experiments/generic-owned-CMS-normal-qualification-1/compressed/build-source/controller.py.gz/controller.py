"""DORMANT actual CMS plain BUILD; reuse the closed snapshot supervisor."""
from pathlib import Path
import hashlib,importlib.util,json,sys,time
START=time.monotonic()
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2'
BASE_CONTROLLER_SHA='bf281d5f97e6d442da8740d21954ceac1cf817314063f7bcfe17a6c6fe9b3ca9'
BASE_INDEX_SHA='41797bbf9e25eb1836932307f66ad74f413714dd38cf1485e07cc8f2d74160d9'

def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def load(name,p,sha):
    require(digest(p)==sha,'changed source '+str(p))
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m

def configure():
    require(digest(BASE/'source-index.json')==BASE_INDEX_SHA,'closed supervisor source changed')
    b=load('plain_cms_closed_supervisor',BASE/'controller.py',BASE_CONTROLLER_SHA)
    sys.path.insert(0,str(HERE))
    b.HERE=HERE;b.ROOT=ROOT;b.WORK=ROOT/'.tirust-build/generic-owned-CMS-plain-build-work-2'
    b.CAPS={'build':1800.};b.CLEANUP=60.;b.CPU=12
    b.LIMITS={'address_space_bytes':16*1024**3,'file_bytes':256*1024**2,'core_bytes':0}
    b.BOOTSTRAP_STARTED=START;b.__file__=str(Path(__file__).resolve())
    oldload=b.load
    def local(name):
        b.authenticate_source_index()
        if name in ('cms_build','cms_runtime'):return oldload('plain_cms_'+name,HERE/(name+'.py'),read(HERE/'source-index.json')['files'][name+'.py']['sha256'])
        require(name in ('ownership','tool_environment','unit_runtime'),'unsupported local helper '+name)
        return oldload('plain_cms_closed_'+name,BASE/(name+'.py'),read(BASE/'source-index.json')['files'][name+'.py']['sha256'])
    b.local=local
    def protected():return local('cms_build').protected(b)
    def work_namespace():
        require(b.PHASE=='build' and b.WORK==ROOT/'.tirust-build/generic-owned-CMS-plain-build-work-2','wrong plain build phase/work')
        require(not b.WORK.is_symlink() and b.WORK.resolve().is_relative_to(ROOT),'unsafe work root')
        require(not (b.WORK/'build').is_symlink(),'unsafe build namespace')
    b.protected=protected;b.work_namespace=work_namespace
    def preflight(stage_created=False):
        b.verify_source();work_namespace()
        require(12 in __import__('os').sched_getaffinity(0),'CPU12 unavailable')
        if not stage_created:require(not (b.WORK/'build').exists(),'retained BUILD namespace exists; no retry')
        return {'status':'source-only-preflight-passed','phase':'build','compiler_queries':0,'loader_queries':0,'native_main_calls':0,
                'cap_seconds':1800,'cleanup_reserve_seconds':60,'CPU':12,'CPU_reserved':False,'resource_limits':b.LIMITS}
    b.preflight=preflight;b.build_locked=lambda directory:local('cms_build').build(b,directory)
    def no_run(*args):raise ValueError('RUN is not admitted or implemented in this plain BUILD packet')
    b.run_locked=no_run;b.verify_build=no_run
    oldenv=b.environment
    def environment():
        e=oldenv();providers=read(HERE/'input-pins.json')['runtime']
        native=[str(Path(x).parent) for x in providers if Path(x).name=='libmadloop_tirust.so']
        require(len(native)==1,'ambiguous eb3 provider')
        e['LD_LIBRARY_PATH']=':'.join([str(ROOT/'HEPTools/ninja/lib'),str(ROOT/'HEPTools/collier'),str(ROOT/'HEPTools/ninjars/lib'),native[0]])
        e.pop('LD_PRELOAD',None);e.pop('LD_AUDIT',None)
        e.update(RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
        return e
    b.environment=environment
    return b

if __name__=='__main__':configure().main()
