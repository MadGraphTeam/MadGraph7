      SUBROUTINE ML5_0_MP_HELAS_CALLS_AMPB_1(P,NHEL,H,IC)
C     
      USE ML5_0_POLYNOMIAL_CONSTANTS
      USE ALOHA_OBJECT
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=4)
      INTEGER    NCOMB
      PARAMETER (NCOMB=16)

      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=2)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=76, NLOOPGROUPS=26, NCTAMPS=67)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=143)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=8,NLOOPWAVEFUNCS=130)
      REAL*16     ZERO
      PARAMETER (ZERO=0.0E0_16)
      COMPLEX*32     IZERO
      PARAMETER (IZERO=CMPLX(0.0E0_16,0.0E0_16,KIND=16))
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*16 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      INTEGER FLAVOR(NEXTERNAL)
      DATA FLAVOR /NEXTERNAL*1/
      COMPLEX*32 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)
C     
C     GLOBAL VARIABLES
C     

      INCLUDE 'mp_coupl_same_name.inc'

      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/ML5_0_FILTERS/GOODAMP,GOODHEL

      INTEGER SQSO_TARGET
      COMMON/ML5_0_SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/ML5_0_SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      COMPLEX*32 AMP(NBORNAMPS)
      COMMON/ML5_0_MP_AMPS/AMP
      TYPE(MP_ALOHA) W(NWAVEFUNCS)
      COMMON/ML5_0_MP_W/W

      COMPLEX*32 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*32 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/ML5_0_MP_WL/WL,PL

      COMPLEX*32 AMPL(3,NCTAMPS)
      COMMON/ML5_0_MP_AMPL/AMPL

C     
C     ----------
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.MP_CT_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

      CALL MP_OXXXXX(P(0,1),ZERO,NHEL(1),-1, FLAVOR(1),W(1))
      CALL MP_IXXXXX(P(0,2),ZERO,NHEL(2),+1, FLAVOR(2),W(2))
      CALL MP_IXXXXX(P(0,3),ZERO,NHEL(3),-1, FLAVOR(3),W(3))
      CALL MP_OXXXXX(P(0,4),ZERO,NHEL(4),+1, FLAVOR(4),W(4))
      CALL MP_FFV1P0_3(W(2),W(1),GC_3,CMPLX(ZERO,KIND=16),W(5))
C     Amplitude(s) for born diagram with ID 1
      CALL MP_FFV1_0(W(3),W(4),W(5),GC_3,AMP(1))
      CALL MP_FFV2_4P0_3(W(2),W(1),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(6))
C     Amplitude(s) for born diagram with ID 2
      CALL MP_FFV2_4_0(W(3),W(4),W(6),GC_68,GC_77,AMP(2))
C     Counter-term amplitude(s) for loop diagram number 3
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,1))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,2))
C     Counter-term amplitude(s) for loop diagram number 4
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,3))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,4))
      CALL MP_FFV1P0_3(W(3),W(4),GC_3,CMPLX(ZERO,KIND=16),W(7))
C     Counter-term amplitude(s) for loop diagram number 5
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,5))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,6))
      CALL MP_FFV2_4P0_3(W(3),W(4),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(8))
C     Counter-term amplitude(s) for loop diagram number 6
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,7))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,8))
C     Counter-term amplitude(s) for loop diagram number 14
      CALL MP_FFV2_6_0(W(3),W(4),W(5),R2_EEACP,R2_EEACM,AMPL(1,9))
C     Counter-term amplitude(s) for loop diagram number 15
      CALL MP_FFV2_6_0(W(3),W(4),W(6),R2_EEZCP,R2_EEZCM,AMPL(1,10))
C     Counter-term amplitude(s) for loop diagram number 16
      CALL MP_FFV2_6_0(W(2),W(1),W(7),R2_EEACP,R2_EEACM,AMPL(1,11))
C     Counter-term amplitude(s) for loop diagram number 17
      CALL MP_FFV2_6_0(W(2),W(1),W(8),R2_EEZCP,R2_EEZCM,AMPL(1,12))
C     Counter-term amplitude(s) for loop diagram number 20
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(6),W(8),R2_ZZBOSON1
     $ ,R2_ZZBOSON2,R2_ZZBOSON3,AMPL(1,13))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW_1EPS,C_UVZMASS2EW_1EPS,C_UVZMASS3EW_1EPS,AMPL(2
     $ ,14))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW,C_UVZMASS2EW,C_UVZMASS3EW,AMPL(1,15))
C     Counter-term amplitude(s) for loop diagram number 23
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(7),R2_AABOSON1
     $ ,R2_AABOSON2,R2_AABOSON3,AMPL(1,16))
C     Counter-term amplitude(s) for loop diagram number 27
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(8),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,17))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,18))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,19))
C     Counter-term amplitude(s) for loop diagram number 31
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(7),W(6),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,20))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,21))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,22))
C     Counter-term amplitude(s) for loop diagram number 39
      CALL MP_FFV2_0(W(3),W(4),W(5),R2_LLACP,AMPL(1,23))
C     Counter-term amplitude(s) for loop diagram number 40
      CALL MP_FFV2_0(W(3),W(4),W(6),R2_LLZCP,AMPL(1,24))
C     Counter-term amplitude(s) for loop diagram number 42
      CALL MP_FFV2_0(W(2),W(1),W(8),R2_LLZCP,AMPL(1,25))
C     Counter-term amplitude(s) for loop diagram number 43
      CALL MP_FFV2_0(W(2),W(1),W(7),R2_LLACP,AMPL(1,26))
C     Counter-term amplitude(s) for loop diagram number 62
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,27))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,28))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,29))
C     Counter-term amplitude(s) for loop diagram number 63
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,30))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,31))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,32))
C     Counter-term amplitude(s) for loop diagram number 64
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,33))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,34))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,35))
C     Counter-term amplitude(s) for loop diagram number 65
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,36))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,37))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,38))
C     Counter-term amplitude(s) for loop diagram number 66
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,39))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,40))
C     Counter-term amplitude(s) for loop diagram number 67
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,41))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,42))
C     Counter-term amplitude(s) for loop diagram number 68
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,43))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,44))
C     Counter-term amplitude(s) for loop diagram number 69
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,45))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,46))
C     Counter-term amplitude(s) for loop diagram number 70
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(7),R2_AAU,R2_AAT3,AMPL(1,47))
C     Counter-term amplitude(s) for loop diagram number 71
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(8),R2_AZU,R2_AZT3,AMPL(1,48))
C     Counter-term amplitude(s) for loop diagram number 72
      CALL MP_R2_GG_1_R2_GG_3_0(W(7),W(6),R2_AZU,R2_AZT3,AMPL(1,49))
C     Counter-term amplitude(s) for loop diagram number 73
      CALL MP_R2_GG_1_R2_GG_3_0(W(6),W(8),R2_ZZU,R2_ZZT3,AMPL(1,50))
C     Counter-term amplitude(s) for loop diagram number 74
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,51))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW_1EPS
     $ ,C_UVAMASS2EW_1EPS,AMPL(2,52))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW
     $ ,C_UVAMASS2EW,AMPL(1,53))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,54))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,55))
C     Counter-term amplitude(s) for loop diagram number 75
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,56))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,57))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,58))
C     Counter-term amplitude(s) for loop diagram number 76
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,59))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,60))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,61))
C     Counter-term amplitude(s) for loop diagram number 77
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,62))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,63))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,64))
C     Counter-term amplitude(s) for loop diagram number 78
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,65))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,66))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,67))
C     At this point, all CT amps needed for (QED=6), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 2000

      GOTO 1001
 2000 CONTINUE
      MP_CT_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END


C PRIVATE OWNED COMPOSITE SOURCE PROTOTYPE.
      SUBROUTINEML5_0_OWNED_MP_HELAS_CALLS_AMPB_1(P,NHEL,H,IC,OS_REF_QP,
     $OS_VALID_QP,OS_PENDING_QP,OS_PENDING_VALID_QP,OS_GENUINE_QP)
C     
      USE ML5_0_POLYNOMIAL_CONSTANTS
      USE ALOHA_OBJECT
      USE ML5_0_OWNED_SNAPSHOTS,ONLY:OS_IK=>SNAPSHOT_IK,OWNED_RESET_DP,O
     $WNED_RESET_QP,OWNED_PREPARE_DP,OWNED_PREPARE_QP,OWNED_COMMIT_DP,OW
     $NED_COMMIT_QP
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=4)
      INTEGER    NCOMB
      PARAMETER (NCOMB=16)

      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=2)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=76, NLOOPGROUPS=26, NCTAMPS=67)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=143)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=8,NLOOPWAVEFUNCS=130)
      REAL*16     ZERO
      PARAMETER (ZERO=0.0E0_16)
      COMPLEX*32     IZERO
      PARAMETER (IZERO=CMPLX(0.0E0_16,0.0E0_16,KIND=16))
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*16 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      INTEGER FLAVOR(NEXTERNAL)
      DATA FLAVOR /NEXTERNAL*1/
      COMPLEX*32 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)
C     
C     GLOBAL VARIABLES
C     

      INCLUDE 'mp_coupl_same_name.inc'

      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/ML5_0_FILTERS/GOODAMP,GOODHEL

      INTEGER SQSO_TARGET
      COMMON/ML5_0_SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/ML5_0_SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      COMPLEX*32 AMP(NBORNAMPS)
      COMMON/ML5_0_MP_AMPS/AMP
      TYPE(MP_ALOHA) W(NWAVEFUNCS)
      COMMON/ML5_0_MP_W/W

      COMPLEX*32 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*32 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/ML5_0_MP_WL/WL,PL

      COMPLEX*32 AMPL(3,NCTAMPS)
      COMMON/ML5_0_MP_AMPL/AMPL

C     
C     ----------
      INTEGER(OS_IK),INTENT(INOUT)::OS_REF_QP(2,0:3,NEXTERNAL),OS_PENDIN
     $G_QP(2,0:3,NEXTERNAL)
      LOGICAL,INTENT(INOUT)::OS_VALID_QP(NEXTERNAL),OS_PENDING_VALID_QP(
     $NEXTERNAL)
      LOGICAL OS_OK
      LOGICAL,INTENT(IN)::OS_GENUINE_QP
C     BEGIN CODE
      CALL OWNED_RESET_QP(OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PENDING
     $_VALID_QP,OS_OK)
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.MP_CT_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

      CALL OWNED_PREPARE_QP(1,P(0:3,1),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_OXXXXX(P(0,1),ZERO,NHEL(1),-1, FLAVOR(1),W(1))
      CALL OWNED_COMMIT_QP(1,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(2,P(0:3,2),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_IXXXXX(P(0,2),ZERO,NHEL(2),+1, FLAVOR(2),W(2))
      CALL OWNED_COMMIT_QP(2,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(3,P(0:3,3),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_IXXXXX(P(0,3),ZERO,NHEL(3),-1, FLAVOR(3),W(3))
      CALL OWNED_COMMIT_QP(3,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(4,P(0:3,4),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_OXXXXX(P(0,4),ZERO,NHEL(4),+1, FLAVOR(4),W(4))
      CALL OWNED_COMMIT_QP(4,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_FFV1P0_3(W(2),W(1),GC_3,CMPLX(ZERO,KIND=16),W(5))
C     Amplitude(s) for born diagram with ID 1
      CALL MP_FFV1_0(W(3),W(4),W(5),GC_3,AMP(1))
      CALL MP_FFV2_4P0_3(W(2),W(1),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(6))
C     Amplitude(s) for born diagram with ID 2
      CALL MP_FFV2_4_0(W(3),W(4),W(6),GC_68,GC_77,AMP(2))
C     Counter-term amplitude(s) for loop diagram number 3
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,1))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,2))
C     Counter-term amplitude(s) for loop diagram number 4
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,3))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,4))
      CALL MP_FFV1P0_3(W(3),W(4),GC_3,CMPLX(ZERO,KIND=16),W(7))
C     Counter-term amplitude(s) for loop diagram number 5
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,5))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,6))
      CALL MP_FFV2_4P0_3(W(3),W(4),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(8))
C     Counter-term amplitude(s) for loop diagram number 6
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,7))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,8))
C     Counter-term amplitude(s) for loop diagram number 14
      CALL MP_FFV2_6_0(W(3),W(4),W(5),R2_EEACP,R2_EEACM,AMPL(1,9))
C     Counter-term amplitude(s) for loop diagram number 15
      CALL MP_FFV2_6_0(W(3),W(4),W(6),R2_EEZCP,R2_EEZCM,AMPL(1,10))
C     Counter-term amplitude(s) for loop diagram number 16
      CALL MP_FFV2_6_0(W(2),W(1),W(7),R2_EEACP,R2_EEACM,AMPL(1,11))
C     Counter-term amplitude(s) for loop diagram number 17
      CALL MP_FFV2_6_0(W(2),W(1),W(8),R2_EEZCP,R2_EEZCM,AMPL(1,12))
C     Counter-term amplitude(s) for loop diagram number 20
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(6),W(8),R2_ZZBOSON1
     $ ,R2_ZZBOSON2,R2_ZZBOSON3,AMPL(1,13))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW_1EPS,C_UVZMASS2EW_1EPS,C_UVZMASS3EW_1EPS,AMPL(2
     $ ,14))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW,C_UVZMASS2EW,C_UVZMASS3EW,AMPL(1,15))
C     Counter-term amplitude(s) for loop diagram number 23
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(7),R2_AABOSON1
     $ ,R2_AABOSON2,R2_AABOSON3,AMPL(1,16))
C     Counter-term amplitude(s) for loop diagram number 27
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(8),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,17))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,18))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,19))
C     Counter-term amplitude(s) for loop diagram number 31
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(7),W(6),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,20))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,21))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,22))
C     Counter-term amplitude(s) for loop diagram number 39
      CALL MP_FFV2_0(W(3),W(4),W(5),R2_LLACP,AMPL(1,23))
C     Counter-term amplitude(s) for loop diagram number 40
      CALL MP_FFV2_0(W(3),W(4),W(6),R2_LLZCP,AMPL(1,24))
C     Counter-term amplitude(s) for loop diagram number 42
      CALL MP_FFV2_0(W(2),W(1),W(8),R2_LLZCP,AMPL(1,25))
C     Counter-term amplitude(s) for loop diagram number 43
      CALL MP_FFV2_0(W(2),W(1),W(7),R2_LLACP,AMPL(1,26))
C     Counter-term amplitude(s) for loop diagram number 62
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,27))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,28))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,29))
C     Counter-term amplitude(s) for loop diagram number 63
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,30))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,31))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,32))
C     Counter-term amplitude(s) for loop diagram number 64
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,33))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,34))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,35))
C     Counter-term amplitude(s) for loop diagram number 65
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,36))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,37))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,38))
C     Counter-term amplitude(s) for loop diagram number 66
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,39))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,40))
C     Counter-term amplitude(s) for loop diagram number 67
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,41))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,42))
C     Counter-term amplitude(s) for loop diagram number 68
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,43))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,44))
C     Counter-term amplitude(s) for loop diagram number 69
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,45))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,46))
C     Counter-term amplitude(s) for loop diagram number 70
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(7),R2_AAU,R2_AAT3,AMPL(1,47))
C     Counter-term amplitude(s) for loop diagram number 71
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(8),R2_AZU,R2_AZT3,AMPL(1,48))
C     Counter-term amplitude(s) for loop diagram number 72
      CALL MP_R2_GG_1_R2_GG_3_0(W(7),W(6),R2_AZU,R2_AZT3,AMPL(1,49))
C     Counter-term amplitude(s) for loop diagram number 73
      CALL MP_R2_GG_1_R2_GG_3_0(W(6),W(8),R2_ZZU,R2_ZZT3,AMPL(1,50))
C     Counter-term amplitude(s) for loop diagram number 74
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,51))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW_1EPS
     $ ,C_UVAMASS2EW_1EPS,AMPL(2,52))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW
     $ ,C_UVAMASS2EW,AMPL(1,53))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,54))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,55))
C     Counter-term amplitude(s) for loop diagram number 75
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,56))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,57))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,58))
C     Counter-term amplitude(s) for loop diagram number 76
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,59))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,60))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,61))
C     Counter-term amplitude(s) for loop diagram number 77
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,62))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,63))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,64))
C     Counter-term amplitude(s) for loop diagram number 78
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,65))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,66))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,67))
C     At this point, all CT amps needed for (QED=6), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 2000

      GOTO 1001
 2000 CONTINUE
      MP_CT_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END

C PRIVATE CURRENT-POINT MATCHED SOURCE ONLY.
      SUBROUTINEML5_0_PM_MP_HELAS_CALLS_AMPB_1(P,NHEL,H,IC,OS_REF_QP,OS_
     $VALID_QP,OS_PENDING_QP,OS_PENDING_VALID_QP,OS_GENUINE_QP)
C     
      USE ML5_0_POLYNOMIAL_CONSTANTS
      USE ALOHA_OBJECT
      USE ML5_0_OWNED_SNAPSHOTS,ONLY:OS_IK=>SNAPSHOT_IK,OWNED_RESET_DP,O
     $WNED_RESET_QP,OWNED_PREPARE_DP,OWNED_PREPARE_QP,OWNED_COMMIT_DP,OW
     $NED_COMMIT_QP
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=4)
      INTEGER    NCOMB
      PARAMETER (NCOMB=16)

      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=2)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=76, NLOOPGROUPS=26, NCTAMPS=67)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=143)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=8,NLOOPWAVEFUNCS=130)
      REAL*16     ZERO
      PARAMETER (ZERO=0.0E0_16)
      COMPLEX*32     IZERO
      PARAMETER (IZERO=CMPLX(0.0E0_16,0.0E0_16,KIND=16))
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*16 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      INTEGER FLAVOR(NEXTERNAL)
      DATA FLAVOR /NEXTERNAL*1/
      COMPLEX*32 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)
C     
C     GLOBAL VARIABLES
C     

      INCLUDE 'mp_coupl_same_name.inc'

      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/ML5_0_FILTERS/GOODAMP,GOODHEL

      INTEGER SQSO_TARGET
      COMMON/ML5_0_SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/ML5_0_SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      COMPLEX*32 AMP(NBORNAMPS)
      COMMON/ML5_0_MP_AMPS/AMP
      TYPE(MP_ALOHA) W(NWAVEFUNCS)
      COMMON/ML5_0_MP_W/W

      COMPLEX*32 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*32 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/ML5_0_MP_WL/WL,PL

      COMPLEX*32 AMPL(3,NCTAMPS)
      COMMON/ML5_0_MP_AMPL/AMPL

C     
C     ----------
      INTEGER(OS_IK),INTENT(INOUT)::OS_REF_QP(2,0:3,NEXTERNAL),OS_PENDIN
     $G_QP(2,0:3,NEXTERNAL)
      LOGICAL,INTENT(INOUT)::OS_VALID_QP(NEXTERNAL),OS_PENDING_VALID_QP(
     $NEXTERNAL)
      LOGICAL OS_OK
      LOGICAL,INTENT(IN)::OS_GENUINE_QP
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.MP_CT_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF
      CALLOWNED_RESET_QP(OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PENDING_
     $VALID_QP,OS_OK)

      CALL OWNED_PREPARE_QP(1,P(0:3,1),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_OXXXXX(P(0,1),ZERO,NHEL(1),-1, FLAVOR(1),W(1))
      CALL OWNED_COMMIT_QP(1,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(2,P(0:3,2),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_IXXXXX(P(0,2),ZERO,NHEL(2),+1, FLAVOR(2),W(2))
      CALL OWNED_COMMIT_QP(2,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(3,P(0:3,3),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_IXXXXX(P(0,3),ZERO,NHEL(3),-1, FLAVOR(3),W(3))
      CALL OWNED_COMMIT_QP(3,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL OWNED_PREPARE_QP(4,P(0:3,4),OS_REF_QP,OS_VALID_QP,OS_PENDING_
     $QP,OS_PENDING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_OXXXXX(P(0,4),ZERO,NHEL(4),+1, FLAVOR(4),W(4))
      CALL OWNED_COMMIT_QP(4,OS_REF_QP,OS_VALID_QP,OS_PENDING_QP,OS_PEND
     $ING_VALID_QP,OS_GENUINE_QP,OS_OK)
      CALL MP_FFV1P0_3(W(2),W(1),GC_3,CMPLX(ZERO,KIND=16),W(5))
C     Amplitude(s) for born diagram with ID 1
      CALL MP_FFV1_0(W(3),W(4),W(5),GC_3,AMP(1))
      CALL MP_FFV2_4P0_3(W(2),W(1),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(6))
C     Amplitude(s) for born diagram with ID 2
      CALL MP_FFV2_4_0(W(3),W(4),W(6),GC_68,GC_77,AMP(2))
C     Counter-term amplitude(s) for loop diagram number 3
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,1))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(5),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,2))
C     Counter-term amplitude(s) for loop diagram number 4
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,3))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(3),W(4),W(6),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,4))
      CALL MP_FFV1P0_3(W(3),W(4),GC_3,CMPLX(ZERO,KIND=16),W(7))
C     Counter-term amplitude(s) for loop diagram number 5
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW_1EPS
     $ ,C_UVEPEMA2EW_1EPS,AMPL(2,5))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(7),C_UVEPEMA1EW
     $ ,C_UVEPEMA2EW,AMPL(1,6))
      CALL MP_FFV2_4P0_3(W(3),W(4),GC_68,GC_77,CMPLX(CMASS_MDL_MZ
     $ ,KIND=16),W(8))
C     Counter-term amplitude(s) for loop diagram number 6
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW_1EPS
     $ ,C_UVEPEMZ2EW_1EPS,AMPL(2,7))
      CALL MP_L_VEXVEA21_L_VEXVEA22_0(W(2),W(1),W(8),C_UVEPEMZ1EW
     $ ,C_UVEPEMZ2EW,AMPL(1,8))
C     Counter-term amplitude(s) for loop diagram number 14
      CALL MP_FFV2_6_0(W(3),W(4),W(5),R2_EEACP,R2_EEACM,AMPL(1,9))
C     Counter-term amplitude(s) for loop diagram number 15
      CALL MP_FFV2_6_0(W(3),W(4),W(6),R2_EEZCP,R2_EEZCM,AMPL(1,10))
C     Counter-term amplitude(s) for loop diagram number 16
      CALL MP_FFV2_6_0(W(2),W(1),W(7),R2_EEACP,R2_EEACM,AMPL(1,11))
C     Counter-term amplitude(s) for loop diagram number 17
      CALL MP_FFV2_6_0(W(2),W(1),W(8),R2_EEZCP,R2_EEZCM,AMPL(1,12))
C     Counter-term amplitude(s) for loop diagram number 20
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(6),W(8),R2_ZZBOSON1
     $ ,R2_ZZBOSON2,R2_ZZBOSON3,AMPL(1,13))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW_1EPS,C_UVZMASS2EW_1EPS,C_UVZMASS3EW_1EPS,AMPL(2
     $ ,14))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(6),W(8)
     $ ,C_UVZMASS1EW,C_UVZMASS2EW,C_UVZMASS3EW,AMPL(1,15))
C     Counter-term amplitude(s) for loop diagram number 23
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(7),R2_AABOSON1
     $ ,R2_AABOSON2,R2_AABOSON3,AMPL(1,16))
C     Counter-term amplitude(s) for loop diagram number 27
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(5),W(8),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,17))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,18))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(5),W(8)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,19))
C     Counter-term amplitude(s) for loop diagram number 31
      CALL MP_R2_GG_1_R2_GG_2_R2_GG_3_0(W(7),W(6),R2_AZBOSON1
     $ ,R2_AZBOSON2,R2_AZBOSON3,AMPL(1,20))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW_1EPS,C_UVAZMASS2EW_1EPS,C_UVAZMASS3EW_1EPS
     $ ,AMPL(2,21))
      CALL MP_L_WMWPMASS1_L_WMWPMASS2_L_WMWPMASS3_0(W(7),W(6)
     $ ,C_UVAZMASS1EW,C_UVAZMASS2EW,C_UVAZMASS3EW,AMPL(1,22))
C     Counter-term amplitude(s) for loop diagram number 39
      CALL MP_FFV2_0(W(3),W(4),W(5),R2_LLACP,AMPL(1,23))
C     Counter-term amplitude(s) for loop diagram number 40
      CALL MP_FFV2_0(W(3),W(4),W(6),R2_LLZCP,AMPL(1,24))
C     Counter-term amplitude(s) for loop diagram number 42
      CALL MP_FFV2_0(W(2),W(1),W(8),R2_LLZCP,AMPL(1,25))
C     Counter-term amplitude(s) for loop diagram number 43
      CALL MP_FFV2_0(W(2),W(1),W(7),R2_LLACP,AMPL(1,26))
C     Counter-term amplitude(s) for loop diagram number 62
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,27))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,28))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAD,AMPL(1,29))
C     Counter-term amplitude(s) for loop diagram number 63
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,30))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,31))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZD,AMPL(1,32))
C     Counter-term amplitude(s) for loop diagram number 64
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,33))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,34))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZD,AMPL(1,35))
C     Counter-term amplitude(s) for loop diagram number 65
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,36))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,37))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZD,AMPL(1,38))
C     Counter-term amplitude(s) for loop diagram number 66
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,39))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAU,AMPL(1,40))
C     Counter-term amplitude(s) for loop diagram number 67
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,41))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZU,AMPL(1,42))
C     Counter-term amplitude(s) for loop diagram number 68
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,43))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZU,AMPL(1,44))
C     Counter-term amplitude(s) for loop diagram number 69
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,45))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZU,AMPL(1,46))
C     Counter-term amplitude(s) for loop diagram number 70
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(7),R2_AAU,R2_AAT3,AMPL(1,47))
C     Counter-term amplitude(s) for loop diagram number 71
      CALL MP_R2_GG_1_R2_GG_3_0(W(5),W(8),R2_AZU,R2_AZT3,AMPL(1,48))
C     Counter-term amplitude(s) for loop diagram number 72
      CALL MP_R2_GG_1_R2_GG_3_0(W(7),W(6),R2_AZU,R2_AZT3,AMPL(1,49))
C     Counter-term amplitude(s) for loop diagram number 73
      CALL MP_R2_GG_1_R2_GG_3_0(W(6),W(8),R2_ZZU,R2_ZZT3,AMPL(1,50))
C     Counter-term amplitude(s) for loop diagram number 74
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,51))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW_1EPS
     $ ,C_UVAMASS2EW_1EPS,AMPL(2,52))
      CALL MP_L_WMWPMASS1_L_WMWPMASS3_0(W(5),W(7),C_UVAMASS1EW
     $ ,C_UVAMASS2EW,AMPL(1,53))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,54))
      CALL MP_R2_GG_1_0(W(5),W(7),R2_AAL,AMPL(1,55))
C     Counter-term amplitude(s) for loop diagram number 75
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,56))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,57))
      CALL MP_R2_GG_1_0(W(5),W(8),R2_AZL,AMPL(1,58))
C     Counter-term amplitude(s) for loop diagram number 76
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,59))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,60))
      CALL MP_R2_GG_1_0(W(7),W(6),R2_AZL,AMPL(1,61))
C     Counter-term amplitude(s) for loop diagram number 77
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,62))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,63))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZL,AMPL(1,64))
C     Counter-term amplitude(s) for loop diagram number 78
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,65))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,66))
      CALL MP_R2_GG_1_0(W(6),W(8),R2_ZZV,AMPL(1,67))
C     At this point, all CT amps needed for (QED=6), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 2000

      GOTO 1001
 2000 CONTINUE
      MP_CT_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END
