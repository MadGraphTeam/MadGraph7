"""Pure normal-RUN protocol, input and stop-policy controls."""
from pathlib import Path
import json,time,types,unittest
import cms_run as c
HERE=Path(__file__).resolve().parent
class NormalRUN(unittest.TestCase):
    def test_six_independent_requests_no_retry_and_critical_separation(self):
        rows=c.request_matrix();self.assertEqual(len(rows),6);self.assertEqual(len({r['id'] for r in rows}),6)
        for lane in ('legacy','candidate'):
            self.assertEqual([r['ids'] for r in rows if r['lane']==lane],[[1,7,12],[20],[21]])
        self.assertEqual(sum(r['expected_legacy_critical_failure_allowed'] for r in rows),2)
    def test_READY_PID_exact(self):
        c.ready_reply(['READY','123'],123)
        for row in (['READY','124'],['READY','123','extra'],['READY','0123']):
            with self.assertRaises(ValueError):c.ready_reply(row,123)
    def test_learning_bounds_and_readiness(self):
        self.assertTrue(c.learned_reply(['LEARNED','123','1','1','24','12'],123,1))
        self.assertFalse(c.learned_reply(['LEARNED','123','1','0','learning-status'],123,1))
        for row in (['LEARNED','123','2','1','24','12'],['LEARNED','123','1','1','1013','12'],
                    ['LEARNED','123','1','1','24','11'],['LEARNED','123','1','0','unknown']):
            with self.assertRaises(ValueError):c.learned_reply(row,123,1)
    def test_DONE_full_identity_and_status(self):
        self.assertEqual(c.done_reply(['DONE','123','2','1','20','419','0'],123,2,1,20),(419,0))
        for row in (['DONE','123','2','1','21','419','0'],['DONE','123','2','1','20','419','3'],
                    ['DONE','123','3','1','20','419','0'],['DONE','123','2','1','20','419','0','extra']):
            with self.assertRaises(ValueError):c.done_reply(row,123,2,1,20)
    def test_EXIT_sequence_exact(self):
        c.exit_reply(['EXIT','123','4'],123,4)
        with self.assertRaises(ValueError):c.exit_reply(['EXIT','123','3'],123,4)
    def protocol(self,buffer):
        p=c.Protocol.__new__(c.Protocol);p.b=types.SimpleNamespace(require_supervisor=lambda:None,ABSOLUTE_END=time.monotonic()+500,CLEANUP=60)
        p.process=types.SimpleNamespace(poll=lambda:None);p.buffer=bytearray(buffer);p.transcript=[];p.save=lambda:None
        return p
    def test_protocol_preserves_buffered_messages(self):
        p=self.protocol(b'READY 123\nLEARNED 123 1 1 24 12\n')
        self.assertEqual(p.message(),['READY','123']);self.assertEqual(p.message(),['LEARNED','123','1','1','24','12'])
        self.assertEqual(len(p.transcript),2)
    def test_terminal_buffered_tail_refuses(self):
        p=self.protocol(b'EXTRA\n')
        with self.assertRaisesRegex(ValueError,'trailing buffered'):p.terminal_empty()
    def test_terminal_unread_tail_refuses_or_empty_accepts(self):
        p=self.protocol(b'');p.fd=-999;old=c.os.read
        try:
            c.os.read=lambda fd,n:b'EXTRA\n'
            with self.assertRaisesRegex(ValueError,'trailing unread'):p.terminal_empty()
            c.os.read=lambda fd,n:b'';p.terminal_empty()
            def blocked(fd,n):raise BlockingIOError()
            c.os.read=blocked;p.terminal_empty()
        finally:c.os.read=old
        source=(HERE/'cms_run.py').read_text()
        self.assertLess(source.index('process.wait(timeout='),source.index('protocol.terminal_empty()'))
    def test_final_raw_hash_join_occurs_after_native_exit(self):
        source=(HERE/'cms_run.py').read_text()
        guard="require(digest(raw)==parsed['raw_sha256'],'raw evidence changed after final DONE')"
        self.assertIn(guard,source)
        self.assertLess(source.index('protocol.terminal_empty()'),source.index(guard))
        self.assertLess(source.index(guard),source.index("'raw_sha256':digest(raw)"))
    def test_protocol_timeout_obeys_original_cleanup_cutoff(self):
        p=self.protocol(b'');p.b.ABSOLUTE_END=time.monotonic()+59
        with self.assertRaises(ValueError):p.message()
    def test_protocol_nonASCII_and_empty_refuse(self):
        with self.assertRaises(UnicodeDecodeError):self.protocol(b'READY \xff\n').message()
        with self.assertRaises(ValueError):self.protocol(b'\n').message()
    def test_point_stream_metadata_and_original_decimal_coordinates(self):
        expected={'training':list(range(1,13)),'controls':[1,7,12],'critical20':[20],'critical21':[21]}
        for name,ids in expected.items():
            rows=(HERE/'inputs'/(name+'.dat')).read_text().splitlines();self.assertEqual(int(rows[0]),len(ids))
            self.assertEqual(len(rows),1+5*len(ids));self.assertEqual([int(rows[1+5*i]) for i in range(len(ids))],ids)
            self.assertTrue(all(len(rows[2+5*i+j].split())==4 for i in range(len(ids)) for j in range(4)))
    def test_source_bound_all_input_words(self):
        words=c.point_words(HERE/'inputs/training.dat',HERE/'inputs/controls.dat',HERE/'inputs/critical20.dat',HERE/'inputs/critical21.dat')
        self.assertEqual(set(words),set(range(1,13))|{20,21})
        self.assertEqual(words[1][0][0],'407F400000000000')
        self.assertEqual(len(words[20]),4)
        self.assertTrue(all(len(w)==16 for cols in words.values() for col in cols for w in col))
        self.assertIn('expected_points=expected_points',(HERE/'cms_run.py').read_text())
    def test_Popen_unassigned_handle_stops_only_authenticated_owned_group(self):
        for record_fails in (False,True):
            events=[]
            def record(*args):
                events.append('record')
                if record_fails:raise ValueError('evidence failure')
            def stop():events.append('owned-group');raise RuntimeError('stopped')
            b=types.SimpleNamespace(record_worker_failure=record,stop_owned_group=stop)
            with self.assertRaisesRegex(RuntimeError,'stopped'):c.worker_failure(b,None,None,None,None,None,True)
            self.assertEqual(events,['record','owned-group'])
        events=[];b=types.SimpleNamespace(record_worker_failure=lambda *a:events.append('known'),stop_owned_group=lambda:events.append('group'))
        c.worker_failure(b,None,None,object(),None,None,True);self.assertEqual(events,['known'])
        events.clear();c.worker_failure(b,None,None,None,None,None,False);self.assertEqual(events,['known'])
        source=(HERE/'cms_run.py').read_text()
        self.assertLess(source.index('launch_environment=b.environment()'),source.index('launch_attempted=True'))
        self.assertLess(source.index('launch_attempted=True'),source.index('process=subprocess.Popen'))
    def test_exact_cwd_resource_staging_matches_auto_lookup(self):
        resources=json.loads((HERE/'input-pins.json').read_text())['resources']
        layout=c.resource_layout(resources)
        self.assertEqual(len(layout),4)
        for src,dst,pin in layout:
            self.assertEqual(src.parent,Path('SubProcesses/MadLoop5_resources'))
            self.assertEqual(dst.parent,c.SUB);self.assertEqual(dst.name,src.name)
            self.assertEqual(pin,resources[str(src)])
        source=(HERE/'cms_run.py').read_text()
        self.assertLess(source.index("'cwd resource copy differs'"),source.index('process=subprocess.Popen'))
        self.assertIn("'worker changed cwd resource'",source)
    def test_resource_layout_refuses_extra_missing_renamed_or_other_sources(self):
        resources=json.loads((HERE/'input-pins.json').read_text())['resources']
        for mutation in ('extra','missing','renamed','path'):
            changed=dict(resources);key=next(iter(changed))
            if mutation=='extra':changed['SubProcesses/MadLoop5_resources/extra.dat']=changed[key]
            if mutation=='missing':changed.pop(key)
            if mutation=='renamed':changed['SubProcesses/MadLoop5_resources/other.dat']=changed.pop(key)
            if mutation=='path':changed['other/'+Path(key).name]=changed.pop(key)
            with self.assertRaises(ValueError):c.resource_layout(changed)
    def test_exact_one_field_runtime_stability_delta(self):
        original=(HERE.parents[1]/'.tirust-build/generic-owned-CMS-plain-build-proposal-2/cards/MadLoopParams.dat').read_bytes()
        current=(HERE/'cards/MadLoopParams.dat').read_bytes()
        policy=c.validate_runtime_card(original,current)
        self.assertEqual(policy['stability_threshold'],1e-6)
        self.assertEqual(current,original.replace(b'#MLStabThres\n1.000000d-03\n',b'#MLStabThres\n1.000000d-06\n'))
        for changed in (original,current+b'\n',current.replace(b'#NRotations_DP\n0',b'#NRotations_DP\n1'),current.replace(b'1.000000d-06',b'1.0d-6')):
            with self.assertRaises(ValueError):c.validate_runtime_card(original,changed)
        with self.assertRaises(ValueError):c.validate_runtime_card(original+b'\n',current)
    def test_original_card_is_verified_before_every_private_delta_copy(self):
        source=(HERE/'cms_run.py').read_text()
        self.assertLess(source.index("digest(target)==ORIGINAL_CARD_SHA"),source.index("policy['runtime_sha256']"))
        self.assertIn('runtime_policy(b)',source)
        self.assertIn("'runtime-card-policy.json'",source)
    def test_true_normal_full_cache0_cards(self):
        rows=(HERE/'cards/MadLoopParams.dat').read_text().splitlines()
        for key,value in (('MLReductionLib','9'),('CTModeRun','-1'),('LoopPoleMode','-1'),('TIRustGlobalCache','0'),('UseQPIntegrandForTIRust','.TRUE.'),('TIRustComputeFinite','.TRUE.'),('MLStabThres','1.000000d-06')):
            self.assertEqual(rows[rows.index('#'+key)+1].strip().upper(),value.upper())
    def test_source_stops_after_semantic_learning_or_candidate_failure(self):
        source=(HERE/'cms_run.py').read_text()
        self.assertLess(source.index("learned=analysis.parse_raw"),source.index("for i,point_id in enumerate"))
        self.assertIn("learned['accepted_for_continuation']",source)
        self.assertIn("parsed['accepted_for_continuation'] or parsed['expected_legacy_critical_failure']",source)
        self.assertIn("if request['id']=='candidate-controls':",source)
        self.assertIn("require(comparison['passed']",source)
    def test_reuses_closed_two_ELFs_and_qualified_clone_no_Fortran_compile(self):
        source=(HERE/'cms_run.py').read_text();wrapper=(HERE/'controller.py').read_text()
        self.assertIn('clone_aliases.clone(source,output',source)
        self.assertIn("checked_copy(Path(row['path']),case/'check'",source)
        self.assertIn("b.CAPS={'run':1800.}",wrapper)
        self.assertIn('no compiler/BUILD in RUN packet',wrapper)
        self.assertNotIn('subprocess.run(',source)
    def test_all_required_actual_mapping_and_input_checks_remain(self):
        source=(HERE/'cms_run.py').read_text()
        for name in ('maps-ready.json','maps-learned.json','maps-done-'):
            self.assertIn(name,source)
        self.assertIn("rec['code']==code and rec['class']==status_class",source)
        self.assertIn("parsed['pid']==process.pid",source)
        self.assertIn("worker changed physical/numerical cards",source)
        self.assertIn('b.record_worker_failure',source)
