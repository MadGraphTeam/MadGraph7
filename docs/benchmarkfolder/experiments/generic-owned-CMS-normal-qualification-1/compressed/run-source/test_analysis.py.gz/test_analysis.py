"""Synthetic RAW64 parser tests only; stdlib bootstrap precedes denial."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import struct
from fractions import Fraction
import sys
import unittest

FORBIDDEN=[]
def audit(event,args):
    if event.startswith(('subprocess.','ctypes.','socket.')) or event in {'os.system','os.exec','os.posix_spawn','os.fork','pty.spawn'}:
        FORBIDDEN.append(event);raise RuntimeError('forbidden process/native/network')
sys.addaudithook(audit)
spec=importlib.util.spec_from_file_location('private_normal_analysis',Path(__file__).with_name('normal_run_analysis.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
READY=[0,1,0,0]+[0]*11
INIT=[1,0,0,0]+[0]*11

def word(value):return struct.pack('>d',value).hex().upper()
def pwords(point):return [[word(float(point*10+leg*4+mu+1)) for mu in range(4)] for leg in range(4)]
def frame(phase,index,point,code=219,cls=2,streak=0,before=READY,after=READY,ans=None,acc=None):
    answers=ans or [[word(10.0),word(-2.0),word(0.2),word(0.01)] for _ in range(2)]
    accuracies=acc or [word(1e-9)]*2
    out=[f'CALL {phase} {index} {point} {code} {cls} {streak} 4 '+('T' if before is not None else 'F')]
    if before is not None:out.append('BEFORE '+' '.join(map(str,before)))
    out+=['AFTER '+' '.join(map(str,after)),'MUR '+word(1000.0)]
    for leg,col in enumerate(pwords(point),1):
        for mu,w in enumerate(col):out.append(f'P {mu} {leg} {w}')
    for order,col in enumerate(answers):
        for mu,w in enumerate(col):out.append(f'ANS {mu} {order} {w}')
    for order,w in enumerate(accuracies):out.append(f'ACC {order} {w}')
    return '\n'.join(out+['CALL_END'])+'\n'

def raw(requests=(1,7,12),measured=None,bootstrap_code=139):
    text='CMS_DRIVER_RAW64_V1 PID 12345\nDIMENSIONS 4 1 1 1 9\n'
    text+=frame('LEARN',0,1,bootstrap_code,1 if bootstrap_code==139 else 0,0,None,INIT)
    for index in range(1,13):text+=frame('LEARN',index,index,streak=index,before=INIT if index==1 else READY)
    text+='LEARNED 1 12 12 219\n'
    for index,point in enumerate(requests,1):text+=frame('RUN',index,point,**((measured or {}).get(point,{})))
    return text

class Analysis(unittest.TestCase):
    def parse(self,text=None,lane='candidate',ids=(1,7,12),**kw):return a.parse_raw(raw(ids) if text is None else text,lane=lane,request_ids=ids,**kw)
    def test_valid_complete_ordinary_and_exact_words(self):
        result=self.parse()
        self.assertTrue(result['accepted_for_continuation']);self.assertTrue(result['learning']['ready'])
        self.assertEqual(result['learning']['outer_calls'],13)
        self.assertEqual(result['learning']['maximum_possible_inner_calls'],26)
        self.assertEqual(len(result['measurements']),3)
        for row in result['measurements']:
            self.assertEqual(row['status_class'],2);self.assertTrue(row['finite'])
            self.assertEqual([len(x) for x in row['rawANS']],[4,4]);self.assertEqual(len(row['rawACC']),2)
            self.assertEqual(row['status']['actual_precision'],'DP')
        json.dumps(result,allow_nan=False)
        for key in ('scientifically_qualified','accuracy_qualified','full_caller_qualified','independent_finite_truth'):self.assertFalse(result[key])
    def test_done_prefixes_and_learning_only(self):
        for ids in [(),(1,),(1,7),(1,7,12),(20,),(21,)]:self.assertTrue(self.parse(ids=ids)['accepted_for_continuation'])
        with self.assertRaises(a.AnalysisError):self.parse(raw((1,7)),ids=(1,))
        with self.assertRaises(a.AnalysisError):self.parse(ids=(7,))
    def test_bootstrap_unknown_retained(self):
        result=self.parse(raw(bootstrap_code=-999))
        self.assertEqual(result['learning']['records'][0]['code'],-999)
        self.assertIsNone(result['learning']['records'][0]['status']['actual_precision'])
        self.assertTrue(result['learning']['ready'])
    def test_successful_learning_cannot_be_spoofed(self):
        text=raw()
        changes=[('LEARNED 1 12 12 219','LEARNED 1 11 12 219'),
                 ('CALL LEARN 7 7 219 2 7','CALL LEARN 7 8 219 2 7'),
                 ('CALL LEARN 8 8 219 2 8','CALL LEARN 8 8 219 2 9'),
                 ('CALL LEARN 9 9 219 2 9','CALL LEARN 9 9 219 1 9'),
                 ('CALL LEARN 10 10 219 2 10','CALL LEARN 11 10 219 2 10')]
        for old,new in changes:
            with self.subTest(old=old):
                with self.assertRaises(a.AnalysisError):self.parse(text.replace(old,new,1))
    def test_valid_learning_status_failure_stops_and_retains(self):
        text='CMS_DRIVER_RAW64_V1 PID 12345\nDIMENSIONS 4 1 1 1 9\n'
        text+=frame('LEARN',0,1,139,1,0,None,INIT)
        text+=frame('LEARN',1,1,419,0,0,INIT,READY)
        text+='LEARNING_FAILED learning-status\n'
        result=self.parse(text,ids=())
        self.assertFalse(result['accepted_for_continuation']);self.assertFalse(result['learning']['ready'])
        self.assertEqual(result['learning']['records'][-1]['code'],419)
        self.assertFalse(result['expected_legacy_critical_failure'])
    def test_legacy_critical_refusal_only_after_learning(self):
        for point in (20,21):
            text=raw((point,),{point:{'code':419,'cls':0}})
            legacy=self.parse(text,lane='legacy',ids=(point,))
            self.assertTrue(legacy['expected_legacy_critical_failure']);self.assertTrue(legacy['accepted_for_continuation'])
            self.assertIsNone(legacy['measurements'][0]['status']['actual_precision'])
            self.assertFalse(self.parse(text,ids=(point,))['accepted_for_continuation'])
        control=self.parse(raw((1,),{1:{'code':419,'cls':0}}),lane='legacy',ids=(1,))
        self.assertFalse(control['expected_legacy_critical_failure']);self.assertFalse(control['accepted_for_continuation'])
    def test_nonfinite_payload_retained_no_json_nan(self):
        answers=[[word(10.),'7FF8000000000042',word(.2),word(.01)] for _ in range(2)]
        text=raw((20,),{20:{'ans':answers}})
        candidate=self.parse(text,ids=(20,));legacy=self.parse(text,lane='legacy',ids=(20,))
        self.assertFalse(candidate['accepted_for_continuation']);self.assertFalse(candidate['measurements'][0]['finite'])
        self.assertTrue(legacy['expected_legacy_critical_failure'])
        self.assertEqual(candidate['measurements'][0]['nonfinite'][0]['word'],'7FF8000000000042')
        json.dumps(candidate,allow_nan=False)
    def test_foreign_alias_not_invented_tirust_qp(self):
        text=raw((20,),{20:{'code':319,'cls':0}})
        result=self.parse(text,lane='legacy',ids=(20,))
        status=result['measurements'][0]['status']
        self.assertEqual(status['actual_backend'],1);self.assertEqual(status['actual_precision'],'QP')
        self.assertFalse(result['expected_legacy_critical_failure']);self.assertFalse(result['accepted_for_continuation'])
        qp=self.parse(raw((20,),{20:{'code':313,'cls':2}}),ids=(20,))
        self.assertEqual(qp['measurements'][0]['status']['actual_precision'],'QP')
        self.assertEqual(qp['measurements'][0]['status']['actual_backend'],9)
    def test_nonfinite_input_not_expected_legacy_failure(self):
        text=raw((20,),{20:{'code':419,'cls':0}})
        old='P 0 1 '+pwords(20)[0][0]
        text=text.replace(old,'P 0 1 7FF0000000000000',1)
        result=self.parse(text,lane='legacy',ids=(20,))
        self.assertFalse(result['accepted_for_continuation']);self.assertFalse(result['expected_legacy_critical_failure'])
    def test_duplicate_missing_reordered_and_partial_words_reject(self):
        text=raw()
        changes=[text.replace('ANS 0 0','ANS 1 0',1),text.replace('ACC 0','ACC 1',1),
                 text.replace('CALL_END\n','',1),text[:-1],text+'CALL_END\n',
                 text.replace('DIMENSIONS 4 1 1 1 9','DIMENSIONS 4 1 1 1 8'),
                 text.replace(' 4024000000000000',' 402400000000000',1)]
        for changed in changes:
            with self.assertRaises(a.AnalysisError) as ctx:self.parse(changed)
            self.assertEqual(ctx.exception.raw_text,changed)
    def test_state_domain_readiness_and_unsupported(self):
        text=raw()
        with self.assertRaises(a.AnalysisError):self.parse(text.replace('AFTER 1 0','AFTER 2 0',1))
        altered=READY.copy();altered[14]=-1
        result=self.parse(raw((20,),{20:{'after':altered,'code':419,'cls':0}}),lane='legacy',ids=(20,))
        self.assertFalse(result['accepted_for_continuation']);self.assertFalse(result['expected_legacy_critical_failure'])
    def test_stale_dp_fpe_not_rejected_solely_when_qp_succeeds(self):
        altered=READY.copy();altered[2]=1
        result=self.parse(raw((20,),{20:{'after':altered,'code':313,'cls':2}}),ids=(20,))
        self.assertTrue(result['accepted_for_continuation'])
        self.assertEqual(result['measurements'][0]['state_after'][2],1)
    def test_external_frozen_point_echo_and_changed_repeated_point(self):
        expected={i:pwords(i) for i in range(1,13)}
        self.assertTrue(self.parse(expected_points=expected)['external_input_echo_verified'])
        bad=dict(expected);bad[1]=pwords(2)
        with self.assertRaises(a.AnalysisError):self.parse(expected_points=bad)
        text=raw();marker='CALL LEARN 1 1';pos=text.index(marker)
        text=text[:pos]+text[pos:].replace('P 0 1 '+pwords(1)[0][0],'P 0 1 '+word(999.),1)
        with self.assertRaises(a.AnalysisError):self.parse(text)
    def test_negative_accuracy_and_unexpected_init_stop(self):
        bad=self.parse(raw((20,),{20:{'acc':[word(-1.)]*2}}),ids=(20,))
        self.assertFalse(bad['accepted_for_continuation']);self.assertFalse(bad['measurements'][0]['accuracy_available'])
        init=self.parse(raw((20,),{20:{'code':139,'cls':1}}),lane='legacy',ids=(20,))
        self.assertFalse(init['expected_legacy_critical_failure']);self.assertFalse(init['accepted_for_continuation'])
    def test_report_only_comparison_and_independent_flags(self):
        result=a.compare_ordinary(self.parse(lane='legacy'),self.parse())
        self.assertTrue(result['passed']);self.assertTrue(result['ordinary_target_passed'])
        self.assertEqual(len(result['residuals']),24)
        self.assertTrue(result['report_only']);self.assertFalse(result['independent_finite_truth'])
        self.assertFalse(result['scientifically_qualified'])
    def test_comparison_opposite_and_huge_words_no_false_overflow_pass(self):
        text=raw();bad=text.replace('ANS 1 0 '+word(-2.),'ANS 1 0 '+word(2.))
        # Mutating all rows consistently leaves training valid; compare actual controls.
        result=a.compare_ordinary(self.parse(lane='legacy'),self.parse(bad))
        self.assertFalse(result['passed'])
        huge1=raw().replace(word(-2.),word(1e308));huge2=raw().replace(word(-2.),word(-1e308))
        result=a.compare_ordinary(self.parse(huge1,lane='legacy'),self.parse(huge2))
        self.assertFalse(result['passed']);json.dumps(result,allow_nan=False)
    def test_signed_zero_retained_and_pole_size_exception(self):
        text=raw().replace('ANS 2 0 '+word(.2),'ANS 2 0 '+word(0.))
        changed=text.replace('ANS 2 0 '+word(0.),'ANS 2 0 '+word(-0.))
        result=a.compare_ordinary(self.parse(text,lane='legacy'),self.parse(changed))
        self.assertTrue(result['passed'])
        self.assertTrue(any(not r['bitwise_equal'] for r in result['residuals']))
        tiny=raw().replace('ANS 2 0 '+word(.2),'ANS 2 0 '+word(1e-12))
        opposite=tiny.replace('ANS 2 0 '+word(1e-12),'ANS 2 0 '+word(-1e-12))
        self.assertTrue(a.compare_ordinary(self.parse(tiny,lane='legacy'),self.parse(opposite))['passed'])
    def test_report_rejects_short_missing_or_reordered_measurements(self):
        for changed_rows in ([],[0],[0,1],[2,1,0]):
            left=self.parse(lane='legacy');right=self.parse()
            left['measurements']=[left['measurements'][i] for i in changed_rows]
            right['measurements']=[right['measurements'][i] for i in changed_rows]
            with self.assertRaises(ValueError):a.compare_ordinary(left,right)
        left=self.parse(lane='legacy');right=self.parse();left['measurements'][2]['point_id']=7
        with self.assertRaises(ValueError):a.compare_ordinary(left,right)
    def test_no_forbidden_events(self):self.assertEqual(FORBIDDEN,[])

if __name__=='__main__':
    result=unittest.main(exit=False,verbosity=2).result
    print('FORBIDDEN_ATTEMPTS',len(FORBIDDEN))
    raise SystemExit(not result.wasSuccessful() or bool(FORBIDDEN))
