"""Prepare immutable normal-RUN source/data bindings only; no target execution."""
from pathlib import Path
import hashlib,json,shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2'
def identity(p):
    b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
def require(ok,msg):
    if not ok:raise ValueError(msg)
def prepare():
    require(identity(PARENT/'source-index.json')['sha256']=='fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb','closed build source changed')
    build=ROOT/'.tirust-build/generic-owned-CMS-plain-build-work-2/build'
    require(identity(build/'terminal.json')['sha256']=='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2','reviewed BUILD2 terminal changed')
    require(identity(build/'result.json')['sha256']=='a3085e4db3ad63f4484e73c37c73ee24ce9ac06efaf7c65b25715a9e0144e072','BUILD2 result changed')
    inputs=read(PARENT/'input-pins.json')
    # Reuse source/objects/provider pins; actual RUN preflight verifies all inputs.
    for name in ('toolchain-pins.json','ancestry.json'):(HERE/name).write_bytes((PARENT/name).read_bytes())
    (HERE/'cards').mkdir()
    for name in ('param_card.dat','MadLoopParams.dat'):(HERE/'cards'/name).write_bytes((PARENT/'cards'/name).read_bytes())
    for f in (PARENT/'source-index.json',build/'terminal.json',build/'result.json'):
        inputs['files'][str(f.relative_to(ROOT))]=identity(f)
    root_review=ROOT/'.tirust-build/generic-owned-CMS-plain-build-independent-review-2/receipt.json'
    require(identity(root_review)['sha256']=='015ca5d7035252f48128509632f50e3b8ff214fbada765124565158a1ac43377','BUILD2 independent review changed')
    inputs['files'][str(root_review.relative_to(ROOT))]=identity(root_review)
    corpus=ROOT/'docs/benchmarkfolder/experiments/current-cms-replay-proposal-1/points/cms_ew_n2_epem_mupmum.dat'
    meta=corpus.with_suffix('.json')
    require(identity(corpus)['sha256']=='a0b0bf140915a5b65600eda9dc6ca87f7e4749f6d3b1cab3ecf4b28616051b60','frozen CMS corpus changed')
    require(identity(meta)['sha256']=='e27239fb2ef0e8b136a4c5f9b6d60aa5c6cf58bdd9cbf88a6da68b9b6d69f042','CMS metadata changed')
    rows=corpus.read_text().splitlines(keepends=True);require(rows[0].strip()=='21' and len(rows)==85,'corpus shape changed')
    require([i for i,r in enumerate(read(meta)['points'],1) if r['kind']=='ordinary']==list(range(1,13)),'ordinary learning set differs')
    (HERE/'inputs').mkdir()
    sets={'training':list(range(1,13)),'controls':[1,7,12],'critical20':[20],'critical21':[21]}
    fixtures={}
    for label,ids in sets.items():
        # IDs are trace metadata. Coordinates are original decimal bytes, no floating generation.
        raw=str(len(ids))+'\n'+''.join(str(i)+'\n'+''.join(rows[1+4*(i-1):1+4*i]) for i in ids)
        path=HERE/'inputs'/(label+'.dat');path.write_text(raw);fixtures[label]={'ids':ids,**identity(path)}
    for f in (corpus,meta):inputs['files'][str(f.relative_to(ROOT))]=identity(f)
    inputs.update(RUN_source_only=True,RUN_admitted=False,compiler_calls=0,loader_queries=0,native_main_calls=0)
    (HERE/'input-pins.json').write_text(json.dumps(inputs,indent=2,sort_keys=True)+'\n')
    plan={'schema':'plain-normal-CMS-RUN-v1','native_admitted':False,'new_Fortran_compile':False,
        'reviewed_build':'be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2',
        'worker_count':6,'lanes':['legacy','candidate'],'cohorts':{'controls':[1,7,12],'critical20':[20],'critical21':[21]},
        'normal_learning':{'training':list(range(1,13)),'bootstrap_calls':1,'learning_max':1012,'steady_consecutive_required':12,'INIT_ready_required':True,'restore_or_force_filters':False},
        'total_seconds':1800,'cleanup_seconds':60,'protocol_call_seconds':180,'CPU':12,'CPU_reserved':False,
        'limits':{'address_space_bytes':16*1024**3,'file_bytes':256*1024**2,'core_bytes':0},'shared_mutex':True,
        'cards':{'MLReductionLib':[9,0],'CTModeRun':-1,'LoopPoleMode':-1,'TIRustGlobalCache':0,'TIRustComputeFinite':True,'UseQPIntegrandForTIRust':True,'TIR_CACHE_SIZE':0},
        'stop_policy':'all learning/infrastructure/candidate/control failures stop; only measured legacy20/21 numeric failures after complete learning are expected per request; no retries',
        'ordinary_gate':{'criterion':'existing LoopMEComparator','tolerance':3e-6,'target':1e-8,'stop_before_candidate_critical_if_failed':True},
        'runtime_gate':'actual original15 provider mappings+exact cloned ELF at READY,LEARNED,eachDONE; original PID/start/session/parent/CPU binding',
        'clone_policy':'reuse exact qualified2-alias policy; never copy298MBNinjaRSarchive; all inputs/cards/mutations in private clone/evidence',
        'point_streams':fixtures,'own_plain_observer_parity':False,'constructor_owner_qualified':False,'q_lowering_qualified':False,'full_caller_qualified':False,'scientific_dispatch_enabled':False,'performance_qualified':False}
    (HERE/'validation-plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'source_only':True,'workers':6,'new_Fortran_compile':False,'fixture_streams':4,'native_admitted':False},sort_keys=True))
if __name__=='__main__':prepare()
