# Dormant actual CMS plain BUILD

This packet compiles the actual normal CMS caller and owned snapshots from
source3c7b6023 active candidate2; it is not another standalone ABI experiment.
No compiler/link/loader or numerical execution has occurred during preparation.
BUILD requires a separate exact root admission. RUN is deliberately absent.

Two ELFs are prepared: exact clean legacy/public source and the source-only
candidate with its private normal threshold entry. The real normal driver uses
12 ordinary CMS points for bounded learning and later accepts separate saved
ordinary/20/21 requests. Its plain renders have no observer dependency. Building
it does not grant learning, ownership, q/dot, IEEE, physics or performance claims.

The compact controller reuses the exact closed snapshot controller bf281d5f…,
source41797bbf…, retaining its original bootstrap absolute deadline, supervisor
PID/start/session/argv binding, work cutoff, cleanup reserve and retained-child
failure cleanup. The only admitted future phase is BUILD:1800s total including
60s cleanup, CPU12 nonexclusive/shared mutex,16GiB AS,256MiB file,core0. These
are proposed caps, not permission. Pure preflight performs no tool query.

Fresh baseline compilation covers all19 process objects with the new driver.
Candidate compilation covers all8 changed process units+driver,7 actual modules
and the C token; only10 unchanged process objects from the fresh baseline may
survive unchanged. Every source/include input comes from the audited clean269
CLI family or sealed candidate2. MODEL/DHELAS modules and4 archives reuse their
exact audited source/recipe/object bindings. Old6-patched candidate objects never
provide new lowering evidence. Both cache layers are0. Normal cards retain
CTModeRun=-1 and LoopPoleMode=-1; FORCE_STABILITY_CHECK is TRUE in the driver.

Compiler recipes are the original audited19 linked recipes, preserving -w,
-fPIC,-ffixed-line-length-132, with -O3 only on polynomial.f. No make scientific
build target is executed: make expands only its pinned link variables. The
original installed MTIRUST wrapper and native eb3d67fd… remain unchanged. Strict
callbacks permit only finite compiler CRT/search queries and the actual bound
interpreter --list call, without retries. All15 original providers are bound
before link/list; actual LOAD/map/static ELF closure must pass before loader
execution. Native main/model/reducer calls in BUILD are zero.

The source tests cover exact flags,19/8/10 closure, public prefixes, normal cards,
helper order, callback refusals and real plain driver bindings. Native compile
can still discover Fortran/ABI defects; failures remain in a fresh retained work
namespace. Numerical RUN needs a separately reviewed successor after this BUILD
closes; bounded journal/observer work proceeds independently in proposal1.
