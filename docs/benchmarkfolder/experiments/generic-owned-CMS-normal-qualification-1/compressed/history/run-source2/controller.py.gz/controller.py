"""DORMANT six-request normal CMS RUN; no new Fortran compilation."""
from pathlib import Path
import hashlib,importlib.util,json,sys,time
START=time.monotonic();HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/generic-owned-CMS-plain-build-proposal-2'
PARENT_INDEX='fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb'
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def load(name,p,sha):
    require(digest(p)==sha,'changed source '+str(p));spec=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def configure():
    require(digest(PARENT/'source-index.json')==PARENT_INDEX,'reviewed build source changed')
    index=read(PARENT/'source-index.json')
    # Authenticate every reused supervisor/clone/environment source before import.
    for name,pin in index['files'].items():
        f=PARENT/name;require(f.stat().st_size==pin['bytes'] and digest(f)==pin['sha256'],'changed parent source '+name)
    parent=load('normal_CMS_closed_builder',PARENT/'controller.py',index['files']['controller.py']['sha256'])
    b=parent.configure();b.HERE=HERE;b.ROOT=ROOT;b.WORK=ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-2'
    b.CAPS={'run':1800.};b.CLEANUP=60.;b.CPU=12;b.BOOTSTRAP_STARTED=START;b.__file__=str(Path(__file__).resolve())
    oldlocal=b.local
    def local(name):
        if name in ('cms_run','normal_run_analysis'):
            b.authenticate_source_index();pin=read(HERE/'source-index.json')['files'][name+'.py']
            return load('normal_CMS_'+name,HERE/(name+'.py'),pin['sha256'])
        return oldlocal(name)
    b.local=local
    def work_namespace():
        require(b.PHASE=='run' and b.WORK==ROOT/'.tirust-build/generic-owned-CMS-plain-run-work-2','wrong RUN namespace')
        require(not b.WORK.is_symlink() and b.WORK.resolve().is_relative_to(ROOT) and not (b.WORK/'run').is_symlink(),'unsafe RUN namespace')
    b.work_namespace=work_namespace;b.verify_build=lambda:local('cms_run').verified_build(b)
    def preflight(stage_created=False):
        b.verify_source();work_namespace();b.verify_build()
        require(12 in __import__('os').sched_getaffinity(0),'CPU12 unavailable')
        if not stage_created:require(not (b.WORK/'run').exists(),'retained RUN exists; no retry')
        return {'status':'source-only-preflight-passed','phase':'run','compiler_queries':0,'loader_queries':0,'native_main_calls':0,
            'workers':6,'total_seconds':1800,'cleanup_seconds':60,'per_protocol_call_seconds':180,'CPU':12,'CPU_reserved':False,'resource_limits':b.LIMITS}
    b.preflight=preflight;b.run_locked=lambda directory:local('cms_run').run(b,directory)
    b.build_locked=lambda *unused:(_ for _ in ()).throw(ValueError('no compiler/BUILD in RUN packet'))
    return b
if __name__=='__main__':configure().main()
