"""Normal physical RUN hooks using only exact closed two-ELF BUILD outputs."""
from pathlib import Path
import hashlib,json,os,selectors,shutil,struct,subprocess,time
SUB=Path('SubProcesses/P0_epem_mupmum')
SOURCE='fb73546348a4daaf736c8c17b91670225cafa4f36fe93e5a066b81c3464a7ccb'
TERMINAL='be89129beb16a82d65624748aa6948d1d955358d910efc9956845ae6efff98f2'
RESULT='a3085e4db3ad63f4484e73c37c73ee24ce9ac06efaf7c65b25715a9e0144e072'

def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def request_matrix():
    return [{'id':lane+'-'+cohort,'lane':lane,'cohort':cohort,'ids':ids,'measurement':'inputs/'+cohort+'.dat',
        'expected_legacy_critical_failure_allowed':lane=='legacy' and cohort!='controls'}
        for lane in ('legacy','candidate') for cohort,ids in (('controls',[1,7,12]),('critical20',[20]),('critical21',[21]))]

def point_words(*streams):
    """Source-bound decimal input echoes; any native conversion mismatch refuses."""
    found={}
    for stream in streams:
        rows=Path(stream).read_text().splitlines();n=int(rows[0])
        require(n>0 and len(rows)==1+5*n,'input stream shape')
        for i in range(n):
            key=int(rows[1+5*i]);words=[]
            for line in rows[2+5*i:6+5*i]:
                fields=line.split();require(len(fields)==4,'input four-vector shape')
                words.append([struct.pack('>d',float(x.replace('D','E').replace('d','e'))).hex().upper() for x in fields])
            require(key not in found or found[key]==words,'duplicate input point differs')
            found[key]=words
    return found

def verified_build(b):
    folder=b.ROOT/'.tirust-build/generic-owned-CMS-plain-build-work-2/build'
    require(b.REVIEWED_BUILD==TERMINAL and digest(folder/'terminal.json')==TERMINAL,'exact independently reviewed BUILD2 terminal required')
    term=read(folder/'terminal.json');require(term['status']=='passed' and term['returncode']==0 and not term['cleanup']['survivors'],'BUILD2 not successfully closed')
    require(term['result_sha256']==RESULT==digest(folder/'result.json'),'BUILD2 result changed')
    result=read(folder/'result.json');require(result['source_index_sha256']==SOURCE and set(result['variants'])=={'legacy','candidate'},'wrong BUILD2 source/lanes')
    inputs=read(b.HERE/'input-pins.json');build=b.local('cms_build')
    import clone_aliases
    for lane,row in result['variants'].items():
        output=folder/lane;case=output/SUB
        require(row['path']==str(case/'check') and not (case/'check').is_symlink() and digest(case/'check')==row['sha256'],'closed ELF changed')
        require(build.source_inventory(output)==row['source_inventory'],'closed Fortran/source/include inputs changed')
        for name,pin in row['objects'].items():require(identity(output/name)==pin,'closed object changed')
        for name,sha in row['actual_link_loads'].items():require(digest(name)==sha,'closed actual link input changed')
        for name,key in (('owned-prelink.json','prelink_sha256'),('owned-link.map','link_map_sha256'),('owned-static-runtime.json','static_runtime_sha256')):
            require(digest(case/name)==row[key],'closed link/runtime proof changed')
        require(row['runtime']['files']==inputs['runtime'],'wrong closed15-provider runtime')
        for name,sha in row['runtime']['files'].items():require(digest(name)==sha,'closed runtime provider changed')
        require(clone_aliases.validate_shared(output,inputs['shared_aliases'])==row['immutable_shared_aliases'],'closed alias inventory changed')
    return result


def ready_reply(fields,pid):
    require(fields==['READY',str(pid)],'wrong native READY')
def learned_reply(fields,pid,seq):
    require(len(fields)>=4 and fields[:3]==['LEARNED',str(pid),str(seq)],'wrong LEARNED identity/sequence')
    if fields[3]=='0':
        require(len(fields)==5 and fields[4] in ('training-input','measurement-input','dimensions','real64-format','learning-status','learning-limit'),'unknown learning failure')
        return False
    require(len(fields)==6 and fields[3]=='1' and 1<=int(fields[4])<=1012 and fields[5]=='12','invalid completed learning bounds/readiness')
    return True
def done_reply(fields,pid,seq,index,point):
    require(len(fields)==7 and fields[:5]==['DONE',str(pid),str(seq),str(index),str(point)],'wrong DONE identity/sequence/point')
    require(fields[6] in ('0','1','2'),'unknown driver numerical class')
    return int(fields[5]),int(fields[6])
def exit_reply(fields,pid,seq):
    require(fields==['EXIT',str(pid),str(seq)],'wrong native EXIT')

class Protocol:
    def __init__(self,b,process,fd,folder):
        self.b,self.process,self.fd,self.folder=b,process,fd,folder;self.buffer=bytearray();self.seq=0
        self.selector=selectors.DefaultSelector();self.selector.register(fd,selectors.EVENT_READ)
        self.transcript=[]
    def message(self):
        end=min(time.monotonic()+180.,self.b.ABSOLUTE_END-self.b.CLEANUP)
        while True:
            self.b.require_supervisor()
            if b'\n' in self.buffer:
                line,_,remaining=self.buffer.partition(b'\n');self.buffer=bytearray(remaining)
                fields=line.decode('ascii').split();require(fields,'empty driver protocol')
                self.transcript.append({'direction':'RECV','fields':fields});self.save();return fields
            require(time.monotonic()<end,'native driver protocol180s/original cutoff')
            if self.selector.select(min(.1,max(0.,end-time.monotonic()))):
                self.buffer.extend(os.read(self.fd,4096));require(len(self.buffer)<=4096,'oversize native protocol')
            else:require(self.process.poll() is None,'native driver exited before protocol response')
    def send(self,command,request):
        self.b.require_supervisor();self.seq+=1;fields=[command,str(self.seq),str(request)]
        self.transcript.append({'direction':'SEND','fields':fields});self.save()
        self.process.stdin.write(' '.join(fields)+'\n');self.process.stdin.flush();return self.seq
    def save(self):
        # Rewrite only this owned evidence file; failed transcripts are retained.
        (self.folder/'protocol.json').write_text(json.dumps(self.transcript,indent=2,sort_keys=True)+'\n')
    def terminal_empty(self):
        # Called only after the retained native process has exited successfully.
        require(not self.buffer,'trailing buffered native protocol evidence')
        try:tail=os.read(self.fd,4096)
        except BlockingIOError:tail=b''
        require(not tail,'trailing unread native protocol evidence')
    def close(self):self.selector.close()

def checked_copy(source,target,root,sha,cap):
    import clone_aliases
    clone_aliases.writable_relative(target.relative_to(root))
    require(target.parent.resolve().is_relative_to(root.resolve()) and source.stat().st_size<=cap,'ELF/input copy escapes or exceeds cap')
    shutil.copy2(source,target);require(digest(target)==sha,'private ELF/input copy differs')

def worker_failure(b,folder,error,process,started,raw,launch_attempted):
    # Popen can create the OS child before its Python handle is assigned.
    # The failure-only authenticated stage group fallback covers that gap.
    if launch_attempted and process is None:
        try:b.record_worker_failure(folder,error,process,started,raw)
        finally:b.stop_owned_group()
    else:b.record_worker_failure(folder,error,process,started,raw)

def one(b,directory,request,row):
    import clone_aliases
    data=read(b.HERE/'input-pins.json');source=Path(row['path']).parent.parent.parent
    output=directory/'workers'/request['id'];output.parent.mkdir(exist_ok=True)
    clone_aliases.clone(source,output,data['donor'],data['shared_aliases'],data['original_links'])
    case=output/SUB;folder=directory/'evidence'/request['id'];folder.mkdir(parents=True)
    checked_copy(Path(row['path']),case/'check',output,row['sha256'],b.LIMITS['file_bytes'])
    require(b.local('cms_build').source_inventory(output)==row['source_inventory'],'private RUN source/include copy changed')
    for name,pin in data['resources'].items():require(identity(output/name)==pin,'private resource copy differs')
    require(not any(output.rglob('*HelFilter.dat')) and not any(output.rglob('*LoopFilter.dat')),'fresh worker inherited filters')
    # All cards remain full normal/cache0; reject any post-build card change.
    for name in ('param_card.dat','MadLoopParams.dat'):
        want=digest(b.HERE/'cards'/name)
        paths=list(output.rglob(name));require(paths,'missing private card '+name)
        for p in paths:require(p.resolve().is_relative_to(output.resolve()) and digest(p)==want,'private card differs/escapes')
    training=case/'training.dat';measurement=case/'measurement.dat'
    for src,target in ((b.HERE/'inputs/training.dat',training),(b.HERE/request['measurement'],measurement)):
        checked_copy(src,target,output,digest(src),b.LIMITS['file_bytes'])
    pipe=case/'native-protocol.fifo';os.mkfifo(pipe,0o600);fd=os.open(pipe,os.O_RDWR|os.O_NONBLOCK)
    expected_points=point_words(training,measurement)
    raw=folder/'driver.raw64';process=started=protocol=None;launch_attempted=False
    argv=[str(case/'check'),str(training),str(measurement),str(pipe),str(raw)]
    b.dump(folder/'command.json',{'argv':argv,'cwd':str(case),'source_index_sha256':b.EXPECTED_SOURCE,'reviewed_build':TERMINAL,'request':request,'new_session':False})
    try:
        with (folder/'stderr.txt').open('xb') as error:
            launch_environment=b.environment();b.require_supervisor()
            launch_attempted=True
            process=subprocess.Popen(argv,cwd=case,env=launch_environment,stdin=subprocess.PIPE,stdout=error,stderr=subprocess.STDOUT,text=True,bufsize=1)
            started=b.support(b.CLEANUP_PATH).identity(process.pid);require(started is not None,'native worker identity unavailable')
            b.dump(folder/'started.json',{'pid':process.pid,'identity':started,'source_executable_sha256':row['sha256']})
            protocol=Protocol(b,process,fd,folder);reply=protocol.message();ready_reply(reply,process.pid)
            runtime_row={'path':str(case/'check'),'sha256':row['sha256'],'runtime':row['runtime']}
            b.dump(folder/'maps-ready.json',b.mapped(process,runtime_row,started))
            seq=protocol.send('LEARN',0);reply=protocol.message()
            learned_ok=learned_reply(reply,process.pid,seq)
            if not learned_ok:
                try:
                    failed=b.local('normal_run_analysis').parse_raw(raw.read_text(),lane=request['lane'],request_ids=[],expected_points=expected_points)
                    b.dump(folder/'learning-failure.json',failed)
                finally:raise ValueError('normal ordinary learning failed; raw/protocol retained')
            b.dump(folder/'maps-learned.json',b.mapped(process,runtime_row,started))
            analysis=b.local('normal_run_analysis')
            learned=analysis.parse_raw(raw.read_text(),lane=request['lane'],request_ids=[],expected_points=expected_points)
            b.dump(folder/'learning-analysis.json',learned)
            require(learned['pid']==process.pid and learned['learning']['ready'] and learned['accepted_for_continuation'],'semantic ordinary learning failed; no measurement permitted')
            parsed=None
            for i,point_id in enumerate(request['ids'],1):
                seq=protocol.send('RUN',i);reply=protocol.message()
                code,status_class=done_reply(reply,process.pid,seq,i,point_id)
                parsed=analysis.parse_raw(raw.read_text(),lane=request['lane'],request_ids=request['ids'][:i],expected_points=expected_points)
                require(parsed['pid']==process.pid and parsed['learning']['ready'],'raw PID/normal readiness differs')
                rec=parsed['measurements'][-1]
                require(rec['code']==code and rec['class']==status_class,'raw/protocol numerical status differs')
                b.dump(folder/('measurement-'+str(i)+'.json'),parsed)
                b.dump(folder/('maps-done-'+str(i)+'.json'),b.mapped(process,runtime_row,started))
                require(parsed['accepted_for_continuation'] or parsed['expected_legacy_critical_failure'],'unexpected candidate/control numerical failure; no further calls')
            seq=protocol.send('EXIT',0);exit_reply(protocol.message(),process.pid,seq)
            process.stdin.close();process.wait(timeout=min(10.,max(.001,b.ABSOLUTE_END-b.CLEANUP-time.monotonic())))
            require(process.returncode==0,'native worker exit failed');protocol.terminal_empty()
            require(digest(raw)==parsed['raw_sha256'],'raw evidence changed after final DONE')
        require(b.local('cms_build').source_inventory(output)==row['source_inventory'],'worker changed source/include inputs')
        require(digest(case/'check')==row['sha256'],'worker ELF changed')
        clone_aliases.validate_shared(output,data['shared_aliases'])
        for name,pin in data['resources'].items():require(identity(output/name)==pin,'worker changed input resource')
        for name in ('param_card.dat','MadLoopParams.dat'):
            require(all(digest(p)==digest(b.HERE/'cards'/name) and p.resolve().is_relative_to(output.resolve()) for p in output.rglob(name)),'worker changed physical/numerical cards')
        result={'request':request,'pid':process.pid,'returncode':process.returncode,'raw_sha256':digest(raw),
                'stderr_sha256':digest(folder/'stderr.txt'),'analysis':parsed,'no_retry':True,'orchestration_closed':True}
        b.dump(folder/'result.json',result);return result
    except BaseException as exc:
        worker_failure(b,folder,exc,process,started,raw,launch_attempted);raise
    finally:
        if protocol is not None:protocol.close()
        os.close(fd)
        if pipe.exists():pipe.unlink()

def run(b,directory):
    built=verified_build(b);before=b.protected();results={};comparison=None
    for request in request_matrix():
        b.require_supervisor();results[request['id']]=one(b,directory,request,built['variants'][request['lane']])
        if request['id']=='candidate-controls':
            comparison=b.local('normal_run_analysis').compare_ordinary(results['legacy-controls']['analysis'],results['candidate-controls']['analysis'])
            b.dump(directory/'ordinary-comparison.json',comparison)
            require(comparison['passed'],'ordinary coefficient3e-6 comparison failed; no further candidate requests')
    require(comparison is not None and comparison['passed'],'ordinary comparison missing/failed')
    require(b.protected()==before,'protected input/provider changed during RUN')
    verified_build(b)
    b.dump(directory/'result.json',{'status':'passed','source_index_sha256':b.EXPECTED_SOURCE,'reviewed_build_sha256':TERMINAL,
        'requests':results,'ordinary_comparison':comparison,'native_processes':6,
        'expected_legacy_critical_failures':[k for k,v in results.items() if v['analysis']['expected_legacy_critical_failure']],
        'all_requests_numerically_valid':all(not v['analysis']['expected_legacy_critical_failure'] for v in results.values()),'compiler_calls':0,'loader_queries':0,
        'performance_qualified':False,'constructor_ownership_qualified':False,'q_at_use_lowering_qualified':False,
        'full_caller_qualified':False,'numerator_lifetime_qualified':False,'scientific_dispatch_enabled':False,
        'scope':'Plain normal learning/physics observations; independent truth and four-lane observer parity remain open.'})
