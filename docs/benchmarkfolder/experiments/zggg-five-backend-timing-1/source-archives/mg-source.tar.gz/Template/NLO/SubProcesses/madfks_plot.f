c Wrapper routines for the fixed order analyses
      subroutine initplot
      use extra_weights
      implicit none
      include 'run.inc'
      include "nexternal.inc"
      integer nwgt
      character(len=50),allocatable :: weights_info(:),ctemp(:)
      character*13 temp
      integer i,npdfs,ii,jj,n,kk,nn
      double precision xsecScale_acc(maxscales,maxscales,maxdynscales)
     $     ,xsecPDFr_acc(0:maxPDFs,maxPDFsets)
      common /scale_pdf_print/xsecScale_acc,xsecPDFr_acc
      logical pineappl
      common /for_pineappl/ pineappl
      include "pineappl_common.inc"
      nwgt=1
      if (.not.allocated(weights_info)) allocate(weights_info(1))
      weights_info(nwgt)="central value               "
      if (do_rwgt_scale) then
         do kk=1,dyn_scale(0)
c set the weights_info string for scale variations
            if (lscalevar(kk)) then
               do ii=1,nint(scalevarF(0))
                  do jj=1,nint(scalevarR(0))
                     nwgt=nwgt+1
                     allocate(ctemp(nwgt))
                     ctemp(1:nwgt-1)=weights_info
                     call move_alloc(ctemp,weights_info)
                     if (ickkw.ne.-1) then
                        write(weights_info(nwgt),
     &                                '(a4,i4,x,a4,f6.3,x,a4,f6.3)')
     $                       "dyn=",dyn_scale(kk),"muR=",scalevarR(jj)
     $                       ,"muF=",scalevarF(ii)
                     else
                        write(weights_info(nwgt),
     &                                '(a4,i4,x,a4,f6.3,x,a4,f6.3)')
     $                       "dyn=",dyn_scale(kk),"muS=",scalevarR(jj)
     $                       ,"muH=",scalevarF(ii)
                     endif
                  enddo
               enddo
            else
               nwgt=nwgt+1
               allocate(ctemp(nwgt))
               ctemp(1:nwgt-1)=weights_info
               call move_alloc(ctemp,weights_info)
               if (ickkw.ne.-1) then
                  write(weights_info(nwgt),'(a4,i4,x,a4,f6.3,x,a4,f6.3)')
     $                 "dyn=",dyn_scale(kk),"muR=",scalevarR(1)
     $                 ,"muF=",scalevarF(1)
               else
                  write(weights_info(nwgt),'(a4,i4,x,a4,f6.3,x,a4,f6.3)')
     $                 "dyn=",dyn_scale(kk),"muS=",scalevarR(1)
     $                 ,"muH=",scalevarF(1)
               endif
            endif
         enddo
      endif
      if (do_rwgt_pdf) then
         do nn=1,lhaPDFid(0)
            if (lpdfvar(nn)) then
               write (*,*) "Including central PDF with "/
     $              /"uncertainties for "//lhaPDFsetname(nn)
            else
               write (*,*) "Including central PDF for "
     $              //lhaPDFsetname(nn)
            endif
c     Load all the PDF sets (the 1st one has already by loaded by the call
c     to "setrun")
            if (nn.gt.1) then
               call initpdfsetbynamem(nn,lhaPDFsetname(nn))
               if (lpdfvar(nn)) then
                  call numberPDFm(nn,nmemPDF(nn))
                  if (nmemPDF(nn).eq.1) then
                     nmemPDF(nn)=0
                     lpdfvar(nn)=.false.
                  endif
               else
                  nmemPDF(nn)=0
               endif
            endif
            if(nmemPDF(nn)+1.gt.maxPDFs)then
               write(*,*)'Too many PDFs: increase maxPDFs in '/
     $              /'extra_weights.f to ',nmemPDF(nn)+1
               stop
            endif
c set the weights_info string for PDF variation
            if (lpdfvar(nn)) then
               do n=0,nmemPDF(nn)
                  nwgt=nwgt+1
                  allocate(ctemp(nwgt))
                  ctemp(1:nwgt-1)=weights_info
                  call move_alloc(ctemp,weights_info)
                  write(temp,'(a4,i8)') "PDF=",lhaPDFid(nn)+n
                  write(weights_info(nwgt),'(a)') trim(adjustl(temp))/
     $                 /' '//trim(adjustl(lhaPDFsetname(nn)))
               enddo
            else
               nwgt=nwgt+1
               allocate(ctemp(nwgt))
               ctemp(1:nwgt-1)=weights_info
               call move_alloc(ctemp,weights_info)
               write(temp,'(a4,i8)') "PDF=",lhaPDFid(nn)
               write(weights_info(nwgt),'(a)') trim(adjustl(temp))/
     $              /' '//trim(adjustl(lhaPDFsetname(nn)))
            endif
         enddo
c start with central member of the first set
         call InitPDFm(1,0)
      endif
      if(pineappl)then
c Initialize grid parameters to negative values.
         appl_Q2min   = -1d0
         appl_Q2max   = -1d0
         appl_xmin    = -1d0
         appl_xmax    = -1d0
         appl_nQ2     = -1
         appl_Q2order = -1
         appl_nx      = -1
         appl_xorder  = -1
      endif
      call analysis_begin(nwgt,weights_info)
c To keep track of the accumulated results:
      do kk=1,dyn_scale(0)
         if (lscalevar(kk)) then
            do ii=1,nint(scalevarF(0))
               do jj=1,nint(scalevarR(0))
                  xsecScale_acc(jj,ii,kk)=0d0
               enddo
            enddo
         else
            xsecScale_acc(1,1,kk)=0d0
         endif
      enddo
      do nn=1,lhaPDFid(0)
         if (lpdfvar(nn)) then
            do n=0,nmemPDF(nn)
               xsecPDFr_acc(n,nn)=0d0
            enddo
         else
            xsecPDFr_acc(0,nn)=0d0
         endif
      enddo
      return
      end


      subroutine topout
      use extra_weights
      use mint_module
      implicit none
      include "nexternal.inc"
      include 'run.inc'
      integer ii,jj,n,kk,nn
      logical useitmax
      common/cuseitmax/useitmax
      real*8 xnorm
      double precision xsecScale_acc(maxscales,maxscales,maxdynscales)
     $     ,xsecPDFr_acc(0:maxPDFs,maxPDFsets)
      common /scale_pdf_print/xsecScale_acc,xsecPDFr_acc
      logical pineappl
      common /for_pineappl/ pineappl
      include "pineappl_common.inc"
c
      xnorm=1.d0/float(ncalls0)
      if(useitmax)xnorm=xnorm/float(itmax)
c Normalization factor for the PineAPPL grids
      if(pineappl) appl_norm_histo = 1d0 / (dble(ncalls0)*dble(itmax))
      call analysis_end(xnorm)
c Write the accumulated results to a file
      open (unit=34,file='scale_pdf_dependence.dat',status='unknown')
      if (.not.useitmax) xnorm=xnorm/float(itmax)
      if (do_rwgt_scale) then
         write (34,*) "scale variations:"
         do kk=1,dyn_scale(0)
            if (lscalevar(kk)) then
               write (34,*) dyn_scale(kk),nint(scalevarR(0))
     $              ,nint(scalevarF(0))
               write (34,*) ((xsecScale_acc(jj,ii,kk)*xnorm,jj=1
     $              ,nint(scalevarR(0))),ii=1,nint(scalevarF(0)))
            else
               write (34,*) dyn_scale(kk),1,1
               write (34,*) xsecScale_acc(1,1,kk)*xnorm
            endif
         enddo
      endif
      if (do_rwgt_pdf) then
         write (34,*) "pdf variations:"
         do nn=1,lhaPDFid(0)
            if (lpdfvar(nn)) then
               write (34,*) trim(adjustl(lhaPDFsetname(nn))),
     $              nmemPDF(nn)+1
               write (34,*) (xsecPDFr_acc(n,nn)*xnorm,n=0,nmemPDF(nn))
            else
               write(34,*) lhaPDFsetname(nn),nmemPDF(nn) + 1
               write (34,*) xsecPDFr_acc(0,nn)*xnorm
            endif
         enddo
      endif
      write (34,*) " "
      close(34)
      return                
      end


      subroutine outfun(pp,ybst_til_tolab,www,iPDG,itype)
C
C *WARNING**WARNING**WARNING**WARNING**WARNING**WARNING**WARNING**WARNING*
C
C In MadFKS, the momenta PP given in input to this function are in the
C reduced parton c.m. frame. If need be, boost them to the lab frame.
C The rapidity of this boost is
C
C       YBST_TIL_TOLAB
C
C also given in input
C
C This is the rapidity that enters in the arguments of the sinh() and
C cosh() of the boost, in such a way that
C       ylab = ycm - ybst_til_tolab
C where ylab is the rapidity in the lab frame and ycm the rapidity
C in the center-of-momentum frame.
C
C *WARNING**WARNING**WARNING**WARNING**WARNING**WARNING**WARNING**WARNING*
      use extra_weights
      implicit none
      include 'nexternal.inc'
      include 'run.inc'
      include 'genps.inc'
      double precision pp(0:3,nexternal),ybst_til_tolab
      integer itype
      double precision p(0:4,nexternal),pplab(0:3,nexternal),chybst
     $     ,shybst,chybstmo
      integer i,j,ibody,i_wgt,ii,jj,kk,n,nn
      double precision xd(3)
      data (xd(i),i=1,3) /0d0,0d0,1d0/
      integer istatus(nexternal),iPDG(nexternal)
      double precision pmass(nexternal)
      common/to_mass/pmass
      double precision www(*)
      double precision xsecScale_acc(maxscales,maxscales,maxdynscales)
     $     ,xsecPDFr_acc(0:maxPDFs,maxPDFsets)
      common /scale_pdf_print/xsecScale_acc,xsecPDFr_acc
      integer amp_pos_plot
      common /campposplot/ amp_pos_plot
      logical pineappl
      common /for_pineappl/ pineappl
      include "pineappl_common.inc"
c Born, n-body or (n+1)-body contribution. For more information
C  about itype, see the comments about plot_id inside
C  the fill_plot subroutine of fks_singular.f
      if(itype.eq.11) then
         ibody=1 ! (n+1)-body
      elseif(itype.ge.12 .and. itype.le.14)then
         ibody=2 ! n-body
      elseif(itype.eq.20)then
         ibody=3 ! Born
      elseif(itype.ge.100.and.itype.le.102)then
         ibody=10+itype-100 ! EW sudakov
      else
         write(*,*)'Error in outfun: unknown itype',itype
         stop
      endif
c Boost the momenta to the lab frame:
      chybst=cosh(ybst_til_tolab)
      shybst=sinh(ybst_til_tolab)
      chybstmo=chybst-1.d0
      do i=1,nexternal
         call boostwdir2(chybst,shybst,chybstmo,xd,pp(0,i),pplab(0,i))
      enddo
c Fill the arrays (momenta, status and PDG):
      do i=1,nexternal
         if (i.le.nincoming) then
            istatus(i)=-1
         else
            istatus(i)=1
         endif
         do j=0,3
            p(j,i)=pplab(j,i)
         enddo
         p(4,i)=pmass(i)
      enddo
      if(pineappl)then
         appl_itype = ibody
         if(ibody.eq.2)then
c      special treatment for collinear
c      and soft collinear counterterms
c      (see comments inside the fill_plots subroutine)
           if(itype.eq.13)then
            !collinear counterterm
             appl_itype = 4
           elseif(itype.eq.14)then
            !solf-collinear counterterm
             appl_itype = 5
           endif
         endif
         appl_amp_pos   = amp_pos_plot
         appl_www_histo = www(1)
      endif
      call analysis_fill(p,istatus,ipdg,www,ibody)
      if(pineappl)then
        ! this call is necessary since PineAPPL
        ! already combine the different contributions
        ! with the same kinematics, while histograms
        ! are filled contribution by contribution.
        call APPL_delete_itype
      endif
c Fill the accumulated results
      i_wgt=1
      if (do_rwgt_scale) then
         do kk=1,dyn_scale(0)
            if (lscalevar(kk)) then
               do ii=1,nint(scalevarF(0))
                  do jj=1,nint(scalevarR(0))
                     i_wgt=i_wgt+1
                     xsecScale_acc(jj,ii,kk)=xsecScale_acc(jj,ii,kk)
     $                    +www(i_wgt)
                  enddo
               enddo
            else
               i_wgt=i_wgt+1
               xsecScale_acc(1,1,kk)=xsecScale_acc(1,1,kk)
     $              +www(i_wgt)
            endif
         enddo
      endif
      if (do_rwgt_pdf) then
         do nn=1,lhaPDFid(0)
            if (lpdfvar(nn)) then
               do n=0,nmemPDF(nn)
                  i_wgt=i_wgt+1
                  xsecPDFr_acc(n,nn)=xsecPDFr_acc(n,nn)+www(i_wgt)
               enddo
            else
               i_wgt=i_wgt+1
               xsecPDFr_acc(0,nn)=xsecPDFr_acc(0,nn)+www(i_wgt)
            endif
         enddo
      endif
 999  return      
      end
