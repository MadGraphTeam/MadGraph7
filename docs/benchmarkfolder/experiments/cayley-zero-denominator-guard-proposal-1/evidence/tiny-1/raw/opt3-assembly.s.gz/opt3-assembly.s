	.file	"cayley_zero_guard_opt3.4082973f7f928873-cgu.0"
	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3:
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception0
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	(%rdi), %rax
	movl	%eax, %ecx
	andl	$3, %ecx
	cmpl	$1, %ecx
	je	.LBB0_1
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB0_1:
	.cfi_def_cfa_offset 48
	leaq	-1(%rax), %rbx
	movq	-1(%rax), %r14
	movq	7(%rax), %r12
	movq	(%r12), %rax
	testq	%rax, %rax
	je	.LBB0_3
.Ltmp0:
	movq	%r14, %rdi
	callq	*%rax
.Ltmp1:
.LBB0_3:
	movq	8(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB0_5
	movq	16(%r12), %rdx
	movq	%r14, %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB0_5:
	movl	$24, %esi
	movl	$8, %edx
	movq	%rbx, %rdi
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmpq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB0_6:
	.cfi_def_cfa_offset 48
.Ltmp2:
	movq	%rax, %r15
	movq	8(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB0_8
	movq	16(%r12), %rdx
	movq	%r14, %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB0_8:
	movl	$24, %esi
	movl	$8, %edx
	movq	%rbx, %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end0:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end0-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc
	.section	.gcc_except_table._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3,"a",@progbits
	.p2align	2, 0x0
GCC_except_table0:
.Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp0-.Lfunc_begin0
	.uleb128 .Ltmp1-.Ltmp0
	.uleb128 .Ltmp2-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp1-.Lfunc_begin0
	.uleb128 .Lfunc_end0-.Ltmp1
	.byte	0
	.byte	0
.Lcst_end0:
	.p2align	2, 0x0

	.section	.text._RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.hidden	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3
	.globl	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3
	.p2align	4
	.type	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs82cP7IqP7wY_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end1-_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end2-_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end3-_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5xnVew21iJH_22cayley_zero_guard_opt3
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end4:
	.size	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end4-_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main,"ax",@progbits
	.hidden	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main
	.globl	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main
	.p2align	4
	.type	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main,@function
_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main:
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception1
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$520, %rsp
	.cfi_def_cfa_offset 576
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	callq	*_RNvNtNtCs82cP7IqP7wY_3std2io5stdio5stdin@GOTPCREL(%rip)
	movq	%rax, 488(%rsp)
	leaq	488(%rsp), %rdi
	callq	*_RNvMs1_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_5Stdin4lock@GOTPCREL(%rip)
	movq	%rax, 64(%rsp)
	andb	$1, %dl
	movb	%dl, 72(%rsp)
	leaq	64(%rsp), %rdi
	leaq	128(%rsp), %rbx
	movq	_RNvXs8_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_9StdinLockNtB7_7BufRead9read_line@GOTPCREL(%rip), %r15
	movq	$0, 368(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	%rbx, 472(%rsp)
.LBB5_1:
	movq	$0, 128(%rsp)
	movq	$1, 136(%rsp)
	movq	$0, 144(%rsp)
.Ltmp3:
	movq	%rbx, %rsi
	callq	*%r15
.Ltmp4:
	testb	$1, %al
	je	.LBB5_6
	movq	$-1, %rbx
	movq	%rdx, %r14
	movq	128(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB5_5
.LBB5_4:
	movq	136(%rsp), %rdi
	movl	$1, %edx
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB5_5:
	movq	384(%rsp), %rcx
	cmpq	$-2, %rbx
	je	.LBB5_115
	jmp	.LBB5_14
	.p2align	4
.LBB5_6:
	testq	%rdx, %rdx
	je	.LBB5_11
	movq	136(%rsp), %r14
	movq	144(%rsp), %rcx
	testq	%rcx, %rcx
	je	.LBB5_12
	cmpb	$10, -1(%r14,%rcx)
	jne	.LBB5_13
	movq	%rcx, %rax
	decq	%rax
	movq	%rax, 144(%rsp)
	je	.LBB5_114
	cmpb	$13, -2(%r14,%rcx)
	leaq	-2(%rcx), %rcx
	cmoveq	%rcx, %rax
	movq	%rax, %rcx
	movq	128(%rsp), %rbx
	cmpq	$-2, %rbx
	je	.LBB5_115
	jmp	.LBB5_14
.LBB5_11:
	movq	$-2, %rbx
	movq	128(%rsp), %rsi
	testq	%rsi, %rsi
	jne	.LBB5_4
	jmp	.LBB5_5
.LBB5_12:
	xorl	%ecx, %ecx
.LBB5_13:
	movq	128(%rsp), %rbx
	cmpq	$-2, %rbx
	je	.LBB5_115
.LBB5_14:
	cmpq	$-1, %rbx
	je	.LBB5_126
	movq	%rbx, 16(%rsp)
	leaq	(%r14,%rcx), %rax
	movq	$0, 408(%rsp)
	movq	%rcx, 416(%rsp)
	movq	%r14, 424(%rsp)
	movq	%rcx, 384(%rsp)
	movq	%rcx, 432(%rsp)
	movq	%r14, 24(%rsp)
	movq	%r14, 440(%rsp)
	movq	%rax, 448(%rsp)
	movq	$0, 456(%rsp)
	movw	$1, 464(%rsp)
	leaq	408(%rsp), %rdi
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next
	testq	%rax, %rax
	je	.LBB5_148
	movq	%rax, %rbx
	movq	%rdx, %r14
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$64, %edi
	movl	$8, %esi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB5_147
	movq	%rax, %rbp
	movq	%rbx, (%rax)
	movq	%r14, 8(%rax)
	movups	408(%rsp), %xmm0
	movups	424(%rsp), %xmm1
	movups	440(%rsp), %xmm2
	movups	456(%rsp), %xmm3
	movaps	%xmm3, 176(%rsp)
	movaps	%xmm2, 160(%rsp)
	movaps	%xmm1, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	leaq	128(%rsp), %rdi
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next
	testq	%rax, %rax
	je	.LBB5_146
	movq	%rax, %r13
	movq	%rdx, %rbx
	movl	$1, %r14d
	movl	$4, %r15d
	movq	%rbp, %rdx
	movl	$1, %ecx
	cmpq	%r15, %r14
	je	.LBB5_19
.LBB5_22:
	movq	%r15, 32(%rsp)
	movq	%rbp, 8(%rsp)
	jmp	.LBB5_25
	.p2align	4
.LBB5_19:
	leaq	(%r15,%r15), %rax
	testq	%r15, %r15
	cmoveq	%rcx, %rax
	cmpq	$5, %rax
	movl	$4, %r12d
	cmovaeq	%rax, %r12
	movabsq	$576460752303423488, %rcx
	cmpq	%rcx, %rax
	jae	.LBB5_119
	movq	%r12, 32(%rsp)
	shlq	$4, %r12
	testq	%r15, %r15
	je	.LBB5_23
	movq	%r15, %rsi
	shlq	$4, %rsi
	movl	$8, %edx
	movq	%rbp, %rdi
	movq	%r12, %rcx
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_realloc@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB5_24
	jmp	.LBB5_151
.LBB5_23:
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%r12, %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB5_151
.LBB5_24:
	movq	%rax, 8(%rsp)
	movq	%rax, %rdx
.LBB5_25:
	movq	%r14, %rax
	shlq	$4, %rax
	movq	%r13, (%rdx,%rax)
	movq	%rdx, 480(%rsp)
	movq	%rbx, 8(%rdx,%rax)
	incq	%r14
	movzbl	185(%rsp), %r8d
	movq	128(%rsp), %rdi
	movq	136(%rsp), %rcx
	movq	144(%rsp), %r13
	movq	168(%rsp), %rdx
	movzbl	184(%rsp), %esi
	movq	160(%rsp), %r10
	movq	176(%rsp), %r11
	movq	%rdi, %r15
	movl	%r8d, %ebp
	jmp	.LBB5_28
	.p2align	4
.LBB5_26:
	xorl	%ebp, %ebp
	movq	%r11, %rdi
	movq	%r11, %r15
.LBB5_27:
	subq	%r9, %rbx
	jne	.LBB5_52
.LBB5_28:
	testb	$1, %bpl
	jne	.LBB5_53
	movq	%r15, %r9
.LBB5_30:
	cmpq	%rdx, %r10
	je	.LBB5_50
	movq	%r10, %r15
	movq	%r11, %rbx
	movzbl	(%r10), %ebp
	testb	%bpl, %bpl
	js	.LBB5_33
	leaq	1(%r15), %r10
	jmp	.LBB5_38
	.p2align	4
.LBB5_33:
	movl	%ebp, %r11d
	andl	$31, %r11d
	movzbl	1(%r15), %eax
	andl	$63, %eax
	cmpb	$-33, %bpl
	jbe	.LBB5_36
	movzbl	2(%r15), %r12d
	shll	$6, %eax
	andl	$63, %r12d
	orl	%eax, %r12d
	cmpb	$-16, %bpl
	jb	.LBB5_37
	leaq	4(%r15), %r10
	movzbl	3(%r15), %ebp
	andl	$7, %r11d
	shll	$18, %r11d
	shll	$6, %r12d
	andl	$63, %ebp
	orl	%r12d, %ebp
	orl	%r11d, %ebp
	jmp	.LBB5_38
.LBB5_36:
	leaq	2(%r15), %r10
	shll	$6, %r11d
	orl	%eax, %r11d
	movl	%r11d, %ebp
	jmp	.LBB5_38
.LBB5_37:
	leaq	3(%r15), %r10
	shll	$12, %r11d
	orl	%r11d, %r12d
	movl	%r12d, %ebp
	.p2align	4
.LBB5_38:
	movq	%r10, %r11
	subq	%r15, %r11
	addq	%rbx, %r11
	cmpl	$32, %ebp
	ja	.LBB5_40
	movl	%ebp, %eax
	movabsq	$4294983168, %r15
	btq	%rax, %r15
	jb	.LBB5_26
.LBB5_40:
	cmpl	$133, %ebp
	jb	.LBB5_30
	movl	%ebp, %eax
	shrl	$8, %eax
	cmpl	$31, %eax
	jg	.LBB5_45
	testl	%eax, %eax
	je	.LBB5_48
	cmpl	$22, %eax
	jne	.LBB5_30
	cmpl	$5760, %ebp
	sete	%al
	testb	$1, %al
	je	.LBB5_30
	jmp	.LBB5_26
.LBB5_45:
	cmpl	$32, %eax
	je	.LBB5_49
	cmpl	$48, %eax
	jne	.LBB5_30
	cmpl	$12288, %ebp
	sete	%al
	testb	$1, %al
	je	.LBB5_30
	jmp	.LBB5_26
.LBB5_48:
	movzbl	%bpl, %eax
	movq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space14WHITESPACE_MAP@GOTPCREL(%rip), %r15
	movzbl	(%r15,%rax), %eax
	testb	$1, %al
	je	.LBB5_30
	jmp	.LBB5_26
.LBB5_49:
	movzbl	%bpl, %eax
	movq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space14WHITESPACE_MAP@GOTPCREL(%rip), %r15
	movzbl	(%r15,%rax), %eax
	shrb	%al
	testb	$1, %al
	je	.LBB5_30
	jmp	.LBB5_26
	.p2align	4
.LBB5_50:
	movb	$1, %r8b
	movq	%r9, %r15
	movb	$1, %bpl
	movq	%rcx, %rbx
	testb	%sil, %sil
	jne	.LBB5_27
	cmpq	%r9, %rcx
	jne	.LBB5_27
	jmp	.LBB5_53
	.p2align	4
.LBB5_52:
	movq	%r10, 160(%rsp)
	movq	%r11, 176(%rsp)
	movq	%rdi, 128(%rsp)
	movb	%r8b, 185(%rsp)
	addq	%r9, %r13
	movq	32(%rsp), %r15
	movq	8(%rsp), %rbp
	movl	$1, %ecx
	movq	480(%rsp), %rdx
	cmpq	%r15, %r14
	je	.LBB5_19
	jmp	.LBB5_22
	.p2align	4
.LBB5_53:
	movq	%r14, 128(%rsp)
	cmpq	$8, %r14
	jne	.LBB5_150
	movq	8(%rsp), %rdx
	movups	(%rdx), %xmm0
	movups	%xmm0, 504(%rsp)
	movq	16(%rdx), %r12
	movq	24(%rdx), %r13
	movq	%r12, 392(%rsp)
	movq	%r13, 400(%rsp)
	cmpq	$8, %r13
	movq	24(%rsp), %r14
	movq	16(%rsp), %rbp
	jne	.LBB5_56
	movabsq	$7308895159548338530, %rax
	cmpq	%rax, (%r12)
	je	.LBB5_58
	jmp	.LBB5_152
.LBB5_56:
	movl	$59, %r15d
	cmpq	$9, %r13
	jne	.LBB5_153
	movq	(%r12), %rax
	movabsq	$8386094384959873379, %rcx
	xorq	%rcx, %rax
	movzbl	8(%r12), %ecx
	xorq	$101, %rcx
	orq	%rax, %rcx
	jne	.LBB5_153
.LBB5_58:
	movq	32(%rdx), %rax
	movq	40(%rdx), %rcx
	cmpq	$1, %rcx
	je	.LBB5_61
	testq	%rcx, %rcx
	movabsq	$1152921504606846975, %r10
	je	.LBB5_156
	movzbl	(%rax), %esi
	jmp	.LBB5_63
.LBB5_61:
	movzbl	(%rax), %esi
	movb	$1, %dl
	cmpl	$43, %esi
	movabsq	$1152921504606846975, %r10
	je	.LBB5_122
	cmpl	$45, %esi
	je	.LBB5_122
.LBB5_63:
	xorl	%edx, %edx
	cmpb	$43, %sil
	sete	%dl
	movq	%rcx, %rsi
	subq	%rdx, %rsi
	addq	%rdx, %rax
	negq	%rdx
	cmpq	$17, %rsi
	jae	.LBB5_68
	testq	%rsi, %rsi
	je	.LBB5_72
	addq	%rdx, %rcx
	negq	%rcx
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB5_66:
	movzbl	(%rax,%rsi), %r8d
	leal	-65(%r8), %r9d
	andl	$-33, %r9d
	addl	$10, %r9d
	leal	-48(%r8), %edi
	cmpl	$58, %r8d
	cmovael	%r9d, %edi
	cmpl	$15, %edi
	ja	.LBB5_142
	shlq	$4, %rdx
	movl	%edi, %edi
	orq	%rdi, %rdx
	incq	%rsi
	movq	%rcx, %rdi
	addq	%rsi, %rdi
	jne	.LBB5_66
	jmp	.LBB5_73
.LBB5_68:
	addq	%rdx, %rcx
	negq	%rcx
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB5_69:
	movzbl	(%rax,%rsi), %r9d
	leal	-65(%r9), %r8d
	leal	-48(%r9), %edi
	cmpq	%r10, %rdx
	ja	.LBB5_121
	andl	$-33, %r8d
	addl	$10, %r8d
	cmpb	$58, %r9b
	cmovael	%r8d, %edi
	cmpl	$16, %edi
	jae	.LBB5_142
	shlq	$4, %rdx
	movl	%edi, %edi
	orq	%rdi, %rdx
	incq	%rsi
	movq	%rcx, %rdi
	addq	%rsi, %rdi
	jne	.LBB5_69
	jmp	.LBB5_73
.LBB5_72:
	xorl	%edx, %edx
	.p2align	4
.LBB5_73:
	movq	%rdx, 80(%rsp)
	movq	8(%rsp), %rcx
	movq	48(%rcx), %rax
	movq	56(%rcx), %rcx
	cmpq	$1, %rcx
	je	.LBB5_76
	testq	%rcx, %rcx
	je	.LBB5_157
	movzbl	(%rax), %esi
	jmp	.LBB5_78
.LBB5_76:
	movzbl	(%rax), %esi
	movb	$1, %dl
	cmpl	$43, %esi
	je	.LBB5_124
	cmpl	$45, %esi
	je	.LBB5_124
.LBB5_78:
	xorl	%edx, %edx
	cmpb	$43, %sil
	sete	%dl
	movq	%rcx, %rsi
	subq	%rdx, %rsi
	addq	%rdx, %rax
	negq	%rdx
	cmpq	$17, %rsi
	jae	.LBB5_83
	testq	%rsi, %rsi
	je	.LBB5_87
	addq	%rdx, %rcx
	negq	%rcx
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB5_81:
	movzbl	(%rax,%rsi), %r8d
	leal	-65(%r8), %r9d
	andl	$-33, %r9d
	addl	$10, %r9d
	leal	-48(%r8), %edi
	cmpl	$58, %r8d
	cmovael	%r9d, %edi
	cmpl	$15, %edi
	ja	.LBB5_143
	shlq	$4, %rdx
	movl	%edi, %edi
	orq	%rdi, %rdx
	incq	%rsi
	movq	%rcx, %rdi
	addq	%rsi, %rdi
	jne	.LBB5_81
	jmp	.LBB5_88
.LBB5_83:
	addq	%rdx, %rcx
	negq	%rcx
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB5_84:
	movzbl	(%rax,%rsi), %r9d
	leal	-65(%r9), %r8d
	leal	-48(%r9), %edi
	cmpq	%r10, %rdx
	ja	.LBB5_123
	andl	$-33, %r8d
	addl	$10, %r8d
	cmpb	$58, %r9b
	cmovael	%r8d, %edi
	cmpl	$16, %edi
	jae	.LBB5_143
	shlq	$4, %rdx
	movl	%edi, %edi
	orq	%rdi, %rdx
	incq	%rsi
	movq	%rcx, %rdi
	addq	%rsi, %rdi
	jne	.LBB5_84
	jmp	.LBB5_88
.LBB5_87:
	xorl	%edx, %edx
	.p2align	4
.LBB5_88:
	movq	%rdx, 88(%rsp)
	movq	8(%rsp), %rbx
	movq	64(%rbx), %rdi
	movq	72(%rbx), %rsi
	callq	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix
	testb	$1, %al
	jne	.LBB5_128
	shrq	$32, %rax
	movl	%eax, 40(%rsp)
	movq	80(%rbx), %rdi
	movq	88(%rbx), %rsi
	callq	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix
	testb	$1, %al
	jne	.LBB5_129
	shrq	$32, %rax
	movl	%eax, 44(%rsp)
	movq	96(%rbx), %rdi
	movq	104(%rbx), %rsi
	callq	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix
	testb	$1, %al
	jne	.LBB5_130
	shrq	$32, %rax
	movl	%eax, 48(%rsp)
	movq	112(%rbx), %rdi
	movq	120(%rbx), %rsi
	callq	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix
	movq	%rax, %rbx
	testb	$1, %bl
	jne	.LBB5_131
	movl	$61, %edi
	callq	*fedisableexcept@GOTPCREL(%rip)
	movl	$43, %r15d
	testl	%eax, %eax
	js	.LBB5_132
	movl	$61, %edi
	callq	*feclearexcept@GOTPCREL(%rip)
	movl	%eax, 128(%rsp)
	testl	%eax, %eax
	jne	.LBB5_133
	movl	44(%rsp), %edi
	callq	*fesetround@GOTPCREL(%rip)
	movl	%eax, 128(%rsp)
	testl	%eax, %eax
	jne	.LBB5_134
	movl	40(%rsp), %edi
	testl	%edi, %edi
	je	.LBB5_97
	callq	*feraiseexcept@GOTPCREL(%rip)
	movl	%eax, 128(%rsp)
	testl	%eax, %eax
	jne	.LBB5_138
.LBB5_97:
	movl	48(%rsp), %edi
	testl	%edi, %edi
	je	.LBB5_99
	callq	*feenableexcept@GOTPCREL(%rip)
	testl	%eax, %eax
	js	.LBB5_140
.LBB5_99:
	movl	$61, %edi
	callq	*fetestexcept@GOTPCREL(%rip)
	movl	%eax, 52(%rsp)
	callq	*fegetround@GOTPCREL(%rip)
	movl	%eax, 56(%rsp)
	callq	*fegetexcept@GOTPCREL(%rip)
	movl	%eax, 60(%rsp)
	shrq	$32, %rbx
	leaq	128(%rsp), %rbx
	je	.LBB5_104
	leaq	504(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3(%rip), %rcx
	movq	%rcx, 136(%rsp)
	leaq	392(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	%rcx, 152(%rsp)
	leaq	80(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	_RNvXsC_NtNtCs6nm8tU1dKu4_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 168(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rcx, 176(%rsp)
	movq	%rax, 184(%rsp)
	leaq	52(%rsp), %rax
	movq	%rax, 192(%rsp)
	movq	_RNvXs9_NtNtNtCs6nm8tU1dKu4_4core3fmt3num3implNtB9_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 200(%rsp)
	leaq	56(%rsp), %rcx
	movq	%rcx, 208(%rsp)
	movq	%rax, 216(%rsp)
	leaq	60(%rsp), %rcx
	movq	%rcx, 224(%rsp)
	movq	%rax, 232(%rsp)
.Ltmp14:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.19(%rip), %rdi
	movq	%rbx, %rsi
	callq	*_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp15:
.Ltmp16:
	callq	*_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6stdout@GOTPCREL(%rip)
.Ltmp17:
	movq	%rax, 408(%rsp)
.Ltmp18:
	leaq	408(%rsp), %rdi
	callq	*_RNvXse_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_6StdoutNtB7_5Write5flush@GOTPCREL(%rip)
.Ltmp19:
	testq	%rax, %rax
	jne	.LBB5_141
.LBB5_104:
	movsd	80(%rsp), %xmm0
	movsd	%xmm0, 128(%rsp)
	#APP
	#NO_APP
	movsd	128(%rsp), %xmm0
	movsd	88(%rsp), %xmm1
	movsd	%xmm1, 128(%rsp)
	#APP
	#NO_APP
	movsd	128(%rsp), %xmm1
	cmpq	$8, %r13
	jne	.LBB5_106
	movabsq	$7308895159548338530, %rax
	cmpq	%rax, (%r12)
	je	.LBB5_113
.LBB5_106:
	callq	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate
.LBB5_107:
	movq	%rax, 96(%rsp)
	movsd	%xmm0, 104(%rsp)
	leaq	96(%rsp), %rax
	#APP
	#NO_APP
	movl	$61, %edi
	callq	*fetestexcept@GOTPCREL(%rip)
	movl	%eax, 116(%rsp)
	callq	*fegetround@GOTPCREL(%rip)
	movl	%eax, 120(%rsp)
	callq	*fegetexcept@GOTPCREL(%rip)
	movl	%eax, 124(%rsp)
	movl	$61, %edi
	callq	*fedisableexcept@GOTPCREL(%rip)
	testl	%eax, %eax
	js	.LBB5_135
	cmpb	$0, 96(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.22(%rip), %rax
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.23(%rip), %rcx
	cmovneq	%rcx, %rax
	movq	%rax, 408(%rsp)
	movq	104(%rsp), %rax
	movl	$0, %ecx
	cmoveq	%rcx, %rax
	movq	%rax, 496(%rsp)
	movq	$4, 416(%rsp)
	leaq	504(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3(%rip), %rcx
	movq	%rcx, 136(%rsp)
	leaq	392(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	%rcx, 152(%rsp)
	leaq	80(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	_RNvXsC_NtNtCs6nm8tU1dKu4_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip), %rdx
	movq	%rdx, 168(%rsp)
	leaq	88(%rsp), %rax
	movq	%rax, 176(%rsp)
	movq	%rdx, 184(%rsp)
	leaq	40(%rsp), %rax
	movq	%rax, 192(%rsp)
	movq	_RNvXs9_NtNtNtCs6nm8tU1dKu4_4core3fmt3num3implNtB9_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 200(%rsp)
	leaq	44(%rsp), %rsi
	movq	%rsi, 208(%rsp)
	movq	%rax, 216(%rsp)
	leaq	48(%rsp), %rsi
	movq	%rsi, 224(%rsp)
	movq	%rax, 232(%rsp)
	leaq	52(%rsp), %rsi
	movq	%rsi, 240(%rsp)
	movq	%rax, 248(%rsp)
	leaq	116(%rsp), %rsi
	movq	%rsi, 256(%rsp)
	movq	%rax, 264(%rsp)
	leaq	56(%rsp), %rsi
	movq	%rsi, 272(%rsp)
	movq	%rax, 280(%rsp)
	leaq	120(%rsp), %rsi
	movq	%rsi, 288(%rsp)
	movq	%rax, 296(%rsp)
	leaq	60(%rsp), %rsi
	movq	%rsi, 304(%rsp)
	movq	%rax, 312(%rsp)
	leaq	124(%rsp), %rsi
	movq	%rsi, 320(%rsp)
	movq	%rax, 328(%rsp)
	leaq	408(%rsp), %rax
	movq	%rax, 336(%rsp)
	movq	%rcx, 344(%rsp)
	leaq	496(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	%rdx, 360(%rsp)
.Ltmp28:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.24(%rip), %rdi
	movq	%rbx, %rsi
	callq	*_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp29:
	movq	32(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB5_111
	shlq	$4, %rsi
	movl	$8, %edx
	movq	8(%rsp), %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB5_111:
	testq	%rbp, %rbp
	leaq	64(%rsp), %rdi
	movq	_RNvXs8_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_9StdinLockNtB7_7BufRead9read_line@GOTPCREL(%rip), %r15
	je	.LBB5_1
	movl	$1, %edx
	movq	%r14, %rdi
	movq	%rbp, %rsi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	leaq	64(%rsp), %rdi
	jmp	.LBB5_1
.LBB5_113:
	callq	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline
	jmp	.LBB5_107
.LBB5_114:
	xorl	%ecx, %ecx
	movq	128(%rsp), %rbx
	cmpq	$-2, %rbx
	jne	.LBB5_14
.LBB5_115:
	movq	64(%rsp), %rbx
	cmpb	$0, 72(%rsp)
	jne	.LBB5_117
	movq	_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count18GLOBAL_PANIC_COUNT@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	shlq	%rax
	testq	%rax, %rax
	jne	.LBB5_136
.LBB5_117:
	xorl	%eax, %eax
	xchgl	%eax, (%rbx)
	cmpl	$2, %eax
	je	.LBB5_127
.LBB5_118:
	addq	$520, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB5_119:
	.cfi_def_cfa_offset 576
	xorl	%r12d, %r12d
.LBB5_120:
	movq	376(%rsp), %rax
	movq	%r12, (%rax)
	movq	96(%rsp), %rdi
	movq	392(%rsp), %rsi
.Ltmp33:
	callq	*_RNvNtCs2MEDghdBxT2_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp34:
	jmp	.LBB5_155
.LBB5_121:
	andl	$-34, %r8d
	addl	$10, %r8d
	cmpb	$58, %r9b
	cmovael	%r8d, %edi
	xorl	%edx, %edx
	cmpl	$16, %edi
	adcb	$1, %dl
.LBB5_122:
	movb	%dl, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.8(%rip), %r8
	jmp	.LBB5_125
.LBB5_123:
	andl	$-34, %r8d
	addl	$10, %r8d
	cmpb	$58, %r9b
	cmovael	%r8d, %edi
	xorl	%edx, %edx
	cmpl	$16, %edi
	adcb	$1, %dl
.LBB5_124:
	movb	%dl, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.9(%rip), %r8
.LBB5_125:
	leaq	128(%rsp), %rdx
.Ltmp31:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.30(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.31(%rip), %rcx
	movl	$43, %esi
	callq	*_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp32:
	jmp	.LBB5_155
.LBB5_126:
	movq	%r14, 128(%rsp)
.Ltmp6:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.30(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.29(%rip), %rcx
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.2(%rip), %r8
	leaq	128(%rsp), %rdx
	movl	$43, %esi
	callq	*_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp7:
	jmp	.LBB5_155
.LBB5_127:
	movq	%rbx, %rdi
	callq	*_RNvMNtNtNtNtCs82cP7IqP7wY_3std3sys4sync5mutex5futexNtB2_5Mutex4wake@GOTPCREL(%rip)
	jmp	.LBB5_118
.LBB5_128:
	movb	%ah, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.10(%rip), %r8
	jmp	.LBB5_125
.LBB5_129:
	movb	%ah, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.11(%rip), %r8
	jmp	.LBB5_125
.LBB5_130:
	movb	%ah, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.12(%rip), %r8
	jmp	.LBB5_125
.LBB5_131:
	movb	%bh, 128(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.13(%rip), %r8
	jmp	.LBB5_125
.LBB5_132:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.14(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.15(%rip), %rdx
	jmp	.LBB5_154
.LBB5_133:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.27(%rip), %r9
	jmp	.LBB5_139
.LBB5_134:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.26(%rip), %r9
	jmp	.LBB5_139
.LBB5_135:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.14(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.21(%rip), %rdx
	jmp	.LBB5_154
.LBB5_136:
	callq	*_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count17is_zero_slow_path@GOTPCREL(%rip)
	testb	%al, %al
	jne	.LBB5_117
	movb	$1, 4(%rbx)
	jmp	.LBB5_117
.LBB5_138:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.25(%rip), %r9
.LBB5_139:
.Ltmp12:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.16(%rip), %rdx
	xorl	%edi, %edi
	movq	472(%rsp), %rsi
	xorl	%ecx, %ecx
	callq	*_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedllECs82cP7IqP7wY_3std@GOTPCREL(%rip)
.Ltmp13:
	jmp	.LBB5_155
.LBB5_140:
	movl	$44, %r15d
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.17(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.18(%rip), %rdx
	jmp	.LBB5_154
.LBB5_141:
	movq	%rax, 128(%rsp)
.Ltmp20:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.30(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.29(%rip), %rcx
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.20(%rip), %r8
	leaq	128(%rsp), %rdx
	movl	$43, %esi
	callq	*_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp21:
	jmp	.LBB5_155
.LBB5_142:
	movb	$1, %dl
	jmp	.LBB5_122
.LBB5_143:
	movb	$1, %dl
	jmp	.LBB5_124
.LBB5_146:
	movl	$4, %eax
	movq	%rax, 32(%rsp)
	movl	$1, %eax
	movq	%rax, 368(%rsp)
	jmp	.LBB5_149
.LBB5_147:
.Ltmp36:
	movl	$8, %edi
	movl	$64, %esi
	callq	*_RNvNtCs2MEDghdBxT2_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp37:
	jmp	.LBB5_155
.LBB5_148:
	movl	$8, %ebp
	movq	$0, 32(%rsp)
.LBB5_149:
	movq	368(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	%rbp, 8(%rsp)
.LBB5_150:
.Ltmp39:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.3(%rip), %rdx
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.28(%rip), %r9
	leaq	128(%rsp), %rsi
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	movq	24(%rsp), %r14
	movq	16(%rsp), %rbp
	callq	*_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip)
.Ltmp40:
	jmp	.LBB5_155
.LBB5_151:
	movq	$8, 96(%rsp)
	leaq	392(%rsp), %rax
	movq	%rax, 376(%rsp)
	jmp	.LBB5_120
.LBB5_152:
	movl	$59, %r15d
.LBB5_153:
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.6(%rip), %rdi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.7(%rip), %rdx
.LBB5_154:
.Ltmp26:
	movq	%r15, %rsi
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip)
.Ltmp27:
.LBB5_155:
	ud2
.LBB5_156:
	xorl	%edx, %edx
	jmp	.LBB5_122
.LBB5_157:
	xorl	%edx, %edx
	jmp	.LBB5_124
.LBB5_158:
.Ltmp38:
	movq	%rax, %rbx
	jmp	.LBB5_173
.LBB5_159:
.Ltmp30:
	jmp	.LBB5_168
.LBB5_160:
.Ltmp5:
	movq	%rax, %rbx
	movq	128(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB5_177
	movq	136(%rsp), %rdi
	movl	$1, %edx
	jmp	.LBB5_176
.LBB5_162:
.Ltmp22:
	movq	%rax, %rbx
.Ltmp23:
	leaq	128(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3
.Ltmp24:
	movq	24(%rsp), %r14
	movq	16(%rsp), %rbp
	jmp	.LBB5_169
.LBB5_164:
.Ltmp25:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB5_165:
.Ltmp8:
	movq	%rax, %rbx
.Ltmp9:
	leaq	128(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3
.Ltmp10:
	jmp	.LBB5_177
.LBB5_166:
.Ltmp11:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB5_167:
.Ltmp41:
.LBB5_168:
	movq	%rax, %rbx
.LBB5_169:
	movq	32(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB5_174
	shlq	$4, %rsi
	movl	$8, %edx
	movq	8(%rsp), %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB5_174
.LBB5_171:
.Ltmp35:
	movq	%rax, %rbx
	testq	%r15, %r15
	je	.LBB5_173
	shlq	$4, %r15
	movl	$8, %edx
	movq	%rbp, %rdi
	movq	%r15, %rsi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB5_173:
	movq	24(%rsp), %r14
	movq	16(%rsp), %rbp
.LBB5_174:
	testq	%rbp, %rbp
	je	.LBB5_177
	movl	$1, %edx
	movq	%r14, %rdi
	movq	%rbp, %rsi
.LBB5_176:
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB5_177:
	movq	64(%rsp), %r14
	cmpb	$0, 72(%rsp)
	jne	.LBB5_179
	movq	_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count18GLOBAL_PANIC_COUNT@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	shlq	%rax
	testq	%rax, %rax
	jne	.LBB5_182
.LBB5_179:
	xorl	%eax, %eax
	xchgl	%eax, (%r14)
	cmpl	$2, %eax
	je	.LBB5_181
.LBB5_180:
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB5_181:
.Ltmp44:
	movq	%r14, %rdi
	callq	*_RNvMNtNtNtNtCs82cP7IqP7wY_3std3sys4sync5mutex5futexNtB2_5Mutex4wake@GOTPCREL(%rip)
.Ltmp45:
	jmp	.LBB5_180
.LBB5_182:
.Ltmp42:
	callq	*_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count17is_zero_slow_path@GOTPCREL(%rip)
.Ltmp43:
	testb	%al, %al
	jne	.LBB5_179
	movb	$1, 4(%r14)
	jmp	.LBB5_179
.LBB5_185:
.Ltmp46:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.Lfunc_end5:
	.size	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main, .Lfunc_end5-_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main
	.cfi_endproc
	.section	.gcc_except_table._RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main,"a",@progbits
	.p2align	2, 0x0
GCC_except_table5:
.Lexception1:
	.byte	255
	.byte	155
	.uleb128 .Lttbase0-.Lttbaseref0
.Lttbaseref0:
	.byte	1
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Lfunc_begin1-.Lfunc_begin1
	.uleb128 .Ltmp3-.Lfunc_begin1
	.byte	0
	.byte	0
	.uleb128 .Ltmp3-.Lfunc_begin1
	.uleb128 .Ltmp4-.Ltmp3
	.uleb128 .Ltmp5-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp14-.Lfunc_begin1
	.uleb128 .Ltmp29-.Ltmp14
	.uleb128 .Ltmp30-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp33-.Lfunc_begin1
	.uleb128 .Ltmp34-.Ltmp33
	.uleb128 .Ltmp35-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp31-.Lfunc_begin1
	.uleb128 .Ltmp32-.Ltmp31
	.uleb128 .Ltmp41-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp6-.Lfunc_begin1
	.uleb128 .Ltmp7-.Ltmp6
	.uleb128 .Ltmp8-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp7-.Lfunc_begin1
	.uleb128 .Ltmp12-.Ltmp7
	.byte	0
	.byte	0
	.uleb128 .Ltmp12-.Lfunc_begin1
	.uleb128 .Ltmp13-.Ltmp12
	.uleb128 .Ltmp41-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp20-.Lfunc_begin1
	.uleb128 .Ltmp21-.Ltmp20
	.uleb128 .Ltmp22-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp36-.Lfunc_begin1
	.uleb128 .Ltmp37-.Ltmp36
	.uleb128 .Ltmp38-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp39-.Lfunc_begin1
	.uleb128 .Ltmp27-.Ltmp39
	.uleb128 .Ltmp41-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp23-.Lfunc_begin1
	.uleb128 .Ltmp24-.Ltmp23
	.uleb128 .Ltmp25-.Lfunc_begin1
	.byte	1
	.uleb128 .Ltmp9-.Lfunc_begin1
	.uleb128 .Ltmp10-.Ltmp9
	.uleb128 .Ltmp11-.Lfunc_begin1
	.byte	1
	.uleb128 .Ltmp10-.Lfunc_begin1
	.uleb128 .Ltmp44-.Ltmp10
	.byte	0
	.byte	0
	.uleb128 .Ltmp44-.Lfunc_begin1
	.uleb128 .Ltmp43-.Ltmp44
	.uleb128 .Ltmp46-.Lfunc_begin1
	.byte	1
.Lcst_end1:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase0:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline,"ax",@progbits
	.p2align	4
	.type	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline,@function
_RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline:
	.cfi_startproc
	divsd	%xmm1, %xmm0
	movq	%xmm0, %rax
	movabsq	$9223372036854775807, %rcx
	andq	%rax, %rcx
	movabsq	$9218868437227405312, %rdx
	xorl	%eax, %eax
	cmpq	%rdx, %rcx
	setl	%al
	retq
.Lfunc_end6:
	.size	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline, .Lfunc_end6-_RNvCs5xnVew21iJH_22cayley_zero_guard_opt38baseline
	.cfi_endproc

	.section	.text._RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate,"ax",@progbits
	.p2align	4
	.type	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate,@function
_RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate:
	.cfi_startproc
	xorpd	%xmm2, %xmm2
	ucomisd	%xmm2, %xmm1
	jne	.LBB7_2
	jp	.LBB7_2
	xorl	%eax, %eax
	retq
.LBB7_2:
	divsd	%xmm1, %xmm0
	movq	%xmm0, %rax
	movabsq	$9223372036854775807, %rcx
	andq	%rax, %rcx
	movabsq	$9218868437227405312, %rdx
	xorl	%eax, %eax
	cmpq	%rdx, %rcx
	setl	%al
	retq
.Lfunc_end7:
	.size	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate, .Lfunc_end7-_RNvCs5xnVew21iJH_22cayley_zero_guard_opt39candidate
	.cfi_endproc

	.section	.text._RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix,"ax",@progbits
	.p2align	4
	.type	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix,@function
_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix:
	.cfi_startproc
	movl	$1, %eax
	cmpq	$1, %rsi
	je	.LBB8_3
	testq	%rsi, %rsi
	jne	.LBB8_6
.LBB8_2:
	orq	%rsi, %rax
	retq
.LBB8_3:
	movzbl	(%rdi), %ecx
	cmpl	$43, %ecx
	je	.LBB8_37
	cmpl	$45, %ecx
	jne	.LBB8_7
.LBB8_37:
	movl	$256, %esi
	orq	%rsi, %rax
	retq
.LBB8_6:
	movzbl	(%rdi), %ecx
.LBB8_7:
	cmpb	$45, %cl
	je	.LBB8_26
	movzbl	%cl, %ecx
	cmpl	$43, %ecx
	jne	.LBB8_10
	incq	%rdi
	decq	%rsi
.LBB8_10:
	movq	%rsi, %rdx
	cmpq	$8, %rsi
	jae	.LBB8_32
	testq	%rdx, %rdx
	je	.LBB8_44
	movzbl	(%rdi), %ecx
	addl	$-48, %ecx
	movl	$256, %esi
	cmpl	$9, %ecx
	ja	.LBB8_2
	cmpq	$1, %rdx
	je	.LBB8_31
	movzbl	1(%rdi), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %ecx
	leal	(%r8,%rcx,2), %ecx
	cmpq	$2, %rdx
	je	.LBB8_31
	movzbl	2(%rdi), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %ecx
	leal	(%r8,%rcx,2), %ecx
	cmpq	$3, %rdx
	je	.LBB8_31
	movzbl	3(%rdi), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %ecx
	leal	(%r8,%rcx,2), %ecx
	cmpq	$4, %rdx
	je	.LBB8_31
	movzbl	4(%rdi), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %ecx
	leal	(%r8,%rcx,2), %ecx
	cmpq	$5, %rdx
	je	.LBB8_31
	movzbl	5(%rdi), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %ecx
	leal	(%r8,%rcx,2), %ecx
	cmpq	$6, %rdx
	je	.LBB8_31
	movzbl	6(%rdi), %edx
	addl	$-48, %edx
	cmpl	$9, %edx
	ja	.LBB8_2
	leal	(%rcx,%rcx,4), %eax
	leal	(%rdx,%rax,2), %ecx
	shlq	$32, %rcx
	xorl	%eax, %eax
	orq	%rcx, %rax
	retq
.LBB8_26:
	cmpq	$9, %rsi
	jae	.LBB8_39
	movq	%rsi, %rax
	xorl	%ecx, %ecx
	decq	%rax
	je	.LBB8_31
	movl	$1, %eax
	movl	$1, %edx
	.p2align	4
.LBB8_29:
	movzbl	(%rdi,%rdx), %r8d
	addl	$-48, %r8d
	cmpl	$9, %r8d
	ja	.LBB8_37
	addl	%ecx, %ecx
	leal	(%rcx,%rcx,4), %ecx
	subl	%r8d, %ecx
	incq	%rdx
	cmpq	%rdx, %rsi
	jne	.LBB8_29
	jmp	.LBB8_31
.LBB8_32:
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	.p2align	4
.LBB8_33:
	imull	$10, %ecx, %ecx
	movzbl	(%rdi,%rsi), %r8d
	jo	.LBB8_47
	addl	$-48, %r8d
	cmpl	$10, %r8d
	jae	.LBB8_37
	addl	%r8d, %ecx
	jo	.LBB8_48
	incq	%rsi
	cmpq	%rsi, %rdx
	jne	.LBB8_33
	jmp	.LBB8_31
.LBB8_39:
	xorl	%ecx, %ecx
	movl	$1, %edx
	.p2align	4
.LBB8_40:
	imull	$10, %ecx, %ecx
	movzbl	(%rdi,%rdx), %r8d
	jo	.LBB8_49
	addl	$-48, %r8d
	cmpl	$10, %r8d
	jae	.LBB8_37
	subl	%r8d, %ecx
	jo	.LBB8_50
	incq	%rdx
	cmpq	%rdx, %rsi
	jne	.LBB8_40
.LBB8_31:
	shlq	$32, %rcx
	xorl	%eax, %eax
	orq	%rcx, %rax
	retq
.LBB8_44:
	xorl	%ecx, %ecx
	shlq	$32, %rcx
	xorl	%eax, %eax
	orq	%rcx, %rax
	retq
.LBB8_47:
	addb	$-48, %r8b
	xorl	%esi, %esi
	cmpb	$10, %r8b
	setb	%sil
	shll	$8, %esi
	addq	$256, %rsi
	orq	%rsi, %rax
	retq
.LBB8_48:
	movl	$512, %esi
	orq	%rsi, %rax
	retq
.LBB8_49:
	addb	$-48, %r8b
	xorl	%esi, %esi
	cmpb	$10, %r8b
	setb	%sil
	shll	$9, %esi
	orq	$256, %rsi
	movl	$1, %eax
	orq	%rsi, %rax
	retq
.LBB8_50:
	movl	$768, %esi
	orq	%rsi, %rax
	retq
.Lfunc_end8:
	.size	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix, .Lfunc_end8-_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radix
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	movq	%rsi, %rax
	movq	(%rdi), %rcx
	movzbl	(%rcx), %ecx
	leaq	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3(%rip), %rdx
	movq	(%rdx,%rcx,8), %rdx
	leaq	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel(%rip), %rdi
	movslq	(%rdi,%rcx,4), %rsi
	addq	%rdi, %rsi
	movq	%rax, %rdi
	jmpq	*_RNvMsa_NtCs6nm8tU1dKu4_4core3fmtNtB5_9Formatter9write_str@GOTPCREL(%rip)
.Lfunc_end9:
	.size	_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end9-_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,"ax",@progbits
	.p2align	4
	.type	_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,@function
_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3:
	.cfi_startproc
	movq	%rsi, %rdx
	movq	(%rdi), %rax
	movq	8(%rdi), %rsi
	movq	%rax, %rdi
	jmpq	*_RNvXsi_NtCs6nm8tU1dKu4_4core3fmteNtB5_7Display3fmt@GOTPCREL(%rip)
.Lfunc_end10:
	.size	_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3, .Lfunc_end10-_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3
	.cfi_endproc

	.section	.text._RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt,@function
_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, %rax
	movq	%rdi, 16(%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.32(%rip), %rcx
	movq	%rcx, (%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.33(%rip), %rsi
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.34(%rip), %rcx
	leaq	16(%rsp), %r9
	movl	$13, %edx
	movl	$4, %r8d
	movq	%rax, %rdi
	callq	*_RNvMsa_NtCs6nm8tU1dKu4_4core3fmtNtB5_9Formatter26debug_struct_field1_finish@GOTPCREL(%rip)
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end11:
	.size	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt, .Lfunc_end11-_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt
	.cfi_endproc

	.section	.text._RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next,"ax",@progbits
	.p2align	4
	.type	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next,@function
_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movzbl	57(%rdi), %ebp
	movq	(%rdi), %r12
	movq	8(%rdi), %rsi
	movq	16(%rdi), %rax
	movq	%rax, -8(%rsp)
	movq	40(%rdi), %r8
	movzbl	56(%rdi), %r9d
	movq	32(%rdi), %r14
	movq	48(%rdi), %r15
	xorl	%eax, %eax
	movq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space14WHITESPACE_MAP@GOTPCREL(%rip), %r10
	movabsq	$4294983168, %r11
	jmp	.LBB12_3
	.p2align	4
.LBB12_1:
	movq	%r14, 32(%rdi)
	movq	%r15, 48(%rdi)
	movq	%r15, (%rdi)
	xorl	%ebp, %ebp
	movq	%r15, %r12
.LBB12_2:
	subq	%rbx, %rdx
	jne	.LBB12_30
.LBB12_3:
	testb	$1, %bpl
	jne	.LBB12_31
	movq	%r12, %rbx
	cmpq	%r8, %r14
	jne	.LBB12_10
.LBB12_5:
	movb	$1, 57(%rdi)
	movb	$1, %bpl
	movq	%rbx, %r12
	movq	%rsi, %rdx
	testb	%r9b, %r9b
	jne	.LBB12_2
	cmpq	%rbx, %rsi
	jne	.LBB12_2
	jmp	.LBB12_31
.LBB12_7:
	movzbl	%bpl, %ecx
	movzbl	(%r10,%rcx), %ecx
	shrb	%cl
.LBB12_8:
	testb	$1, %cl
	jne	.LBB12_1
.LBB12_9:
	cmpq	%r8, %r14
	je	.LBB12_28
.LBB12_10:
	movq	%r14, %r12
	movq	%r15, %rdx
	movzbl	(%r14), %ebp
	testb	%bpl, %bpl
	js	.LBB12_12
	leaq	1(%r12), %r14
	jmp	.LBB12_17
	.p2align	4
.LBB12_12:
	movl	%ebp, %r15d
	andl	$31, %r15d
	movzbl	1(%r12), %ecx
	andl	$63, %ecx
	cmpb	$-33, %bpl
	jbe	.LBB12_15
	movzbl	2(%r12), %r13d
	shll	$6, %ecx
	andl	$63, %r13d
	orl	%ecx, %r13d
	cmpb	$-16, %bpl
	jb	.LBB12_16
	leaq	4(%r12), %r14
	movzbl	3(%r12), %ebp
	andl	$7, %r15d
	shll	$18, %r15d
	shll	$6, %r13d
	andl	$63, %ebp
	orl	%r13d, %ebp
	orl	%r15d, %ebp
	jmp	.LBB12_17
.LBB12_15:
	leaq	2(%r12), %r14
	shll	$6, %r15d
	orl	%ecx, %r15d
	movl	%r15d, %ebp
	jmp	.LBB12_17
.LBB12_16:
	leaq	3(%r12), %r14
	shll	$12, %r15d
	orl	%r15d, %r13d
	movl	%r13d, %ebp
	.p2align	4
.LBB12_17:
	movq	%r14, %r15
	subq	%r12, %r15
	addq	%rdx, %r15
	cmpl	$32, %ebp
	ja	.LBB12_19
	movl	%ebp, %ecx
	btq	%rcx, %r11
	jb	.LBB12_1
.LBB12_19:
	cmpl	$133, %ebp
	jb	.LBB12_9
	movl	%ebp, %ecx
	shrl	$8, %ecx
	cmpl	$31, %ecx
	jg	.LBB12_24
	testl	%ecx, %ecx
	je	.LBB12_27
	cmpl	$22, %ecx
	jne	.LBB12_9
	cmpl	$5760, %ebp
	sete	%cl
	jmp	.LBB12_8
	.p2align	4
.LBB12_24:
	cmpl	$32, %ecx
	je	.LBB12_7
	cmpl	$48, %ecx
	jne	.LBB12_9
	cmpl	$12288, %ebp
	sete	%cl
	jmp	.LBB12_8
.LBB12_27:
	movzbl	%bpl, %ecx
	movzbl	(%r10,%rcx), %ecx
	jmp	.LBB12_8
.LBB12_28:
	movq	%r14, 32(%rdi)
	movq	%r15, 48(%rdi)
	jmp	.LBB12_5
.LBB12_31:
	jmp	.LBB12_32
.LBB12_30:
	movq	-8(%rsp), %rax
	addq	%rbx, %rax
.LBB12_32:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end12:
	.size	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next, .Lfunc_end12-_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4next
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCs5xnVew21iJH_22cayley_zero_guard_opt34main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.07c3a47326832875799592c5a7803ce6.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs82cP7IqP7wY_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end13:
	.size	main, .Lfunc_end13-main
	.cfi_endproc

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.0,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs5xnVew21iJH_22cayley_zero_guard_opt3
	.quad	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3
	.quad	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs5xnVew21iJH_22cayley_zero_guard_opt3
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.0, 48

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.1,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.07c3a47326832875799592c5a7803ce6.1:
	.asciz	"/shared/external/madloop_tirust/madgraph7_madloop_tirust/docs/benchmarkfolder/experiments/cayley-zero-denominator-guard-proposal-1/source/fixture.rs"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.1, 149

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.2,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.2,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.2:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\026\000\000\000\031\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.2, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.3,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.3:
	.asciz	"\b\000\000\000\000\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.3, 8

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.4,@object
.Lanon.07c3a47326832875799592c5a7803ce6.4:
	.ascii	"baseline"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.4, 8

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.5,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.5,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.5:
	.ascii	"candidate"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.5, 9

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.6,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.6,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.6:
	.ascii	"assertion failed: mode == \"baseline\" || mode == \"candidate\""
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.6, 59

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.7,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.7,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.7:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\033\000\000\000\t\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.7, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.8,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.8:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\034\000\000\0005\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.8, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.9,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.9:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\035\000\000\0005\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.9, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.10,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.10:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\036\000\000\000+\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.10, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.11,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.11,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.11:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\037\000\000\000/\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.11, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.12,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.12:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000 \000\000\000,\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.12, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.13,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.13,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.13:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000!\000\000\000,\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.13, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.14,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.14,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.14:
	.ascii	"assertion failed: fedisableexcept(ALL) >= 0"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.14, 43

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.15,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.15:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000#\000\000\000\r\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.15, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.16,@object
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.16:
	.zero	4
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.16, 4

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.17,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.17,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.17:
	.ascii	"assertion failed: feenableexcept(traps) >= 0"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.17, 44

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.18,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.18,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.18:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000'\000\000\000\035\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.18, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.19,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.19,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.19:
	.asciz	"\006ENTER \300\001 \300\001 \303 \000\000i\020\000\001 \303 \000\000i\020\000\001 \300\001 \300\001 \300\001\n"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.19, 41

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.20,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.20:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000.\000\000\000\"\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.20, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.21,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.21:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\0006\000\000\000\022\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.21, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.22,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.07c3a47326832875799592c5a7803ce6.22:
	.ascii	"none"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.22, 4

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.23,@object
.Lanon.07c3a47326832875799592c5a7803ce6.23:
	.ascii	"some"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.23, 4

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.24,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.24,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.24:
	.asciz	"\004ROW \300\001 \300\001 \303 \000\000i\020\000\001 \303 \000\000i\020\000\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \303 \000\000i\020\000\001\n"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.24, 69

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.25,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.25,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.25:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000&\000\000\000\034\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.25, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.26,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.26,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.26:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000%\000\000\000\r\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.26, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.27,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.27,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.27:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000$\000\000\000\r\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.27, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.28,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.28,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.28:
	.quad	.Lanon.07c3a47326832875799592c5a7803ce6.1
	.asciz	"\224\000\000\000\000\000\000\000\030\000\000\000\t\000\000"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.28, 24

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.29,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.29,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.29:
	.quad	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs5xnVew21iJH_22cayley_zero_guard_opt3
	.asciz	"\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXNtNtCs82cP7IqP7wY_3std2io5errorNtB2_5ErrorNtNtCs6nm8tU1dKu4_4core3fmt5Debug3fmt
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.29, 32

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.30,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.30,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.30:
	.ascii	"called `Result::unwrap()` on an `Err` value"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.30, 43

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.31,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.31,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.31:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.31, 32

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.32,@object
	.section	.data.rel.ro..Lanon.07c3a47326832875799592c5a7803ce6.32,"aw",@progbits
	.p2align	3, 0x0
.Lanon.07c3a47326832875799592c5a7803ce6.32:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.32, 32

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.33,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.33,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.33:
	.ascii	"ParseIntError"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.33, 13

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.34,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.07c3a47326832875799592c5a7803ce6.34:
	.ascii	"kind"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.34, 4

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.35,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.35,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.35:
	.ascii	"Empty"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.35, 5

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.36,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.36,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.36:
	.ascii	"InvalidDigit"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.36, 12

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.37,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.37,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.37:
	.ascii	"PosOverflow"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.37, 11

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.38,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.38,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.38:
	.ascii	"NegOverflow"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.38, 11

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.39,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.07c3a47326832875799592c5a7803ce6.39:
	.ascii	"Zero"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.39, 4

	.type	.Lanon.07c3a47326832875799592c5a7803ce6.40,@object
	.section	.rodata..Lanon.07c3a47326832875799592c5a7803ce6.40,"a",@progbits
.Lanon.07c3a47326832875799592c5a7803ce6.40:
	.ascii	"NotAPowerOfTwo"
	.size	.Lanon.07c3a47326832875799592c5a7803ce6.40, 14

	.type	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,@object
	.section	.rodata..Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3,"a",@progbits
	.p2align	3, 0x0
.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3:
	.quad	5
	.quad	12
	.quad	11
	.quad	11
	.quad	4
	.quad	14
	.size	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3, 48

	.type	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel,@object
	.section	.rodata..Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel,"a",@progbits
	.p2align	2, 0x0
.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel:
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.35-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.36-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.37-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.38-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.39-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.long	.Lanon.07c3a47326832875799592c5a7803ce6.40-.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel
	.size	.Lswitch.table._RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs5xnVew21iJH_22cayley_zero_guard_opt3.40.rel, 24

	.hidden	DW.ref.rust_eh_personality
	.weak	DW.ref.rust_eh_personality
	.section	.data.DW.ref.rust_eh_personality,"awG",@progbits,DW.ref.rust_eh_personality,comdat
	.p2align	3, 0x0
	.type	DW.ref.rust_eh_personality,@object
	.size	DW.ref.rust_eh_personality, 8
DW.ref.rust_eh_personality:
	.quad	rust_eh_personality
	.ident	"rustc version 1.97.1 (8bab26f4f 2026-07-14) (built from a source tarball)"
	.section	".note.GNU-stack","",@progbits
