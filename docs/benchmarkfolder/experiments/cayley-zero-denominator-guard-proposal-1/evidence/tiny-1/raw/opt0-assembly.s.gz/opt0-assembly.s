	.file	"cayley_zero_guard_opt0.2fc0f7bdc53404f7-cgu.0"
	.section	.text._RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	callq	_RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end0-_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movsd	%xmm0, -24(%rsp)
	movb	%dil, %al
	testb	$1, %al
	jne	.LBB1_2
	movq	$0, -16(%rsp)
	jmp	.LBB1_3
.LBB1_2:
	movsd	-24(%rsp), %xmm0
	movsd	%xmm0, -8(%rsp)
	movq	$1, -16(%rsp)
.LBB1_3:
	movq	-16(%rsp), %rax
	movsd	-8(%rsp), %xmm0
	retq
.Lfunc_end1:
	.size	_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end1-_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movq	%rsi, -16(%rsp)
	movq	_RNvXs1i_NtCs6nm8tU1dKu4_4core3fmtReNtB6_7Display3fmtCsbhnijhkoh2c_14rustc_demangle@GOTPCREL(%rip), %rcx
	movq	%rcx, -8(%rsp)
	movq	-16(%rsp), %rcx
	movq	%rcx, (%rdi)
	movq	-8(%rsp), %rcx
	movq	%rcx, 8(%rdi)
	retq
.Lfunc_end2:
	.size	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end2-_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movq	%rsi, -16(%rsp)
	movq	_RNvXs9_NtNtNtCs6nm8tU1dKu4_4core3fmt3num3implNtB9_7Display3fmt@GOTPCREL(%rip), %rcx
	movq	%rcx, -8(%rsp)
	movq	-16(%rsp), %rcx
	movq	%rcx, (%rdi)
	movq	-8(%rsp), %rcx
	movq	%rcx, 8(%rdi)
	retq
.Lfunc_end3:
	.size	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end3-_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movq	%rsi, -16(%rsp)
	movq	_RNvXsC_NtNtCs6nm8tU1dKu4_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip), %rcx
	movq	%rcx, -8(%rsp)
	movq	-16(%rsp), %rcx
	movq	%rcx, (%rdi)
	movq	-8(%rsp), %rcx
	movq	%rcx, 8(%rdi)
	retq
.Lfunc_end4:
	.size	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end4-_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rsi, %rdx
	movq	%rdi, %rax
	retq
.Lfunc_end5:
	.size	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end5-_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rsi, %rdx
	movq	%rdi, %rax
	retq
.Lfunc_end6:
	.size	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end6-_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception0
	subq	$152, %rsp
	.cfi_def_cfa_offset 160
	movq	%rdi, 56(%rsp)
	movq	%rsi, 64(%rsp)
.LBB7_1:
.Ltmp0:
	movq	64(%rsp), %rdi
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp1:
	movq	%rdx, 40(%rsp)
	movq	%rax, 48(%rsp)
	jmp	.LBB7_4
.LBB7_2:
	movq	128(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB7_3:
.Ltmp2:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 128(%rsp)
	movl	%eax, 136(%rsp)
	jmp	.LBB7_2
.LBB7_4:
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movq	72(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB7_6
	movq	56(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 16(%rsp)
	movq	80(%rsp), %rcx
	movq	%rcx, 24(%rsp)
	movq	16(%rax), %rax
	movq	%rax, 32(%rsp)
	jmp	.LBB7_7
.LBB7_6:
	addq	$152, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB7_7:
	.cfi_def_cfa_offset 160
	movq	56(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 88(%rsp)
	movq	32(%rsp), %rax
	cmpq	88(%rsp), %rax
	je	.LBB7_10
	jmp	.LBB7_11
.LBB7_10:
.Ltmp3:
	movq	64(%rsp), %rsi
	leaq	96(%rsp), %rdi
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp4:
	jmp	.LBB7_14
.LBB7_11:
	movq	32(%rsp), %rax
	movq	24(%rsp), %rdx
	movq	16(%rsp), %rsi
	movq	56(%rsp), %rdi
	movq	%rax, %rcx
	shlq	$4, %rcx
	addq	8(%rdi), %rcx
	movq	%rsi, (%rcx)
	movq	%rdx, 8(%rcx)
	addq	$1, %rax
	movq	%rax, 8(%rsp)
	jmp	.LBB7_16
.LBB7_12:
	jmp	.LBB7_2
.LBB7_13:
.Ltmp7:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 128(%rsp)
	movl	%eax, 136(%rsp)
	jmp	.LBB7_12
.LBB7_14:
	movq	56(%rsp), %rdi
	movq	96(%rsp), %rax
	incq	%rax
	movq	$-1, %rcx
	cmoveq	%rcx, %rax
	movq	%rax, 144(%rsp)
	movq	144(%rsp), %rsi
.Ltmp5:
	callq	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp6:
	jmp	.LBB7_15
.LBB7_15:
	jmp	.LBB7_11
.LBB7_16:
	jmp	.LBB7_17
.LBB7_17:
	movq	56(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 120(%rsp)
	movq	8(%rsp), %rdi
	movq	120(%rsp), %rsi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.1(%rip), %rdx
	callq	_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	56(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	%rcx, 16(%rax)
	jmp	.LBB7_1
.Lfunc_end7:
	.size	_RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end7-_RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table7:
.Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp0-.Lfunc_begin0
	.uleb128 .Ltmp1-.Ltmp0
	.uleb128 .Ltmp2-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp1-.Lfunc_begin0
	.uleb128 .Ltmp3-.Ltmp1
	.byte	0
	.byte	0
	.uleb128 .Ltmp3-.Lfunc_begin0
	.uleb128 .Ltmp6-.Ltmp3
	.uleb128 .Ltmp7-.Lfunc_begin0
	.byte	0
.Lcst_end0:
	.p2align	2, 0x0

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtBX_4SyncEL_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtBX_4SyncEL_ECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtBX_4SyncEL_ECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, 8(%rsp)
	movq	(%rsi), %rax
	movq	%rax, 16(%rsp)
	cmpq	$0, %rax
	je	.LBB8_2
	movq	16(%rsp), %rax
	movq	8(%rsp), %rdi
	callq	*%rax
.LBB8_2:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end8:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtBX_4SyncEL_ECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end8-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtBX_4SyncEL_ECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception1
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
.Ltmp8:
	callq	_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp9:
	jmp	.LBB9_3
.LBB9_1:
.Ltmp11:
	movq	(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp12:
	jmp	.LBB9_5
.LBB9_2:
.Ltmp10:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 8(%rsp)
	movl	%eax, 16(%rsp)
	jmp	.LBB9_1
.LBB9_3:
	movq	(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB9_4:
	.cfi_def_cfa_offset 32
.Ltmp13:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB9_5:
	movq	8(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end9:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end9-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table9:
.Lexception1:
	.byte	255
	.byte	155
	.uleb128 .Lttbase0-.Lttbaseref0
.Lttbaseref0:
	.byte	1
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Ltmp8-.Lfunc_begin1
	.uleb128 .Ltmp9-.Ltmp8
	.uleb128 .Ltmp10-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp11-.Lfunc_begin1
	.uleb128 .Ltmp12-.Ltmp11
	.uleb128 .Ltmp13-.Lfunc_begin1
	.byte	1
	.uleb128 .Ltmp12-.Lfunc_begin1
	.uleb128 .Lfunc_end9-.Ltmp12
	.byte	0
	.byte	0
.Lcst_end1:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase0:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception2
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
.Ltmp14:
	movq	_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VechENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCshr3nYqPH3YZ_5gimli@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp15:
	jmp	.LBB10_3
.LBB10_1:
.Ltmp17:
	movq	(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp18:
	jmp	.LBB10_5
.LBB10_2:
.Ltmp16:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 8(%rsp)
	movl	%eax, 16(%rsp)
	jmp	.LBB10_1
.LBB10_3:
	movq	(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB10_4:
	.cfi_def_cfa_offset 32
.Ltmp19:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB10_5:
	movq	8(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end10:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end10-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table10:
.Lexception2:
	.byte	255
	.byte	155
	.uleb128 .Lttbase1-.Lttbaseref1
.Lttbaseref1:
	.byte	1
	.uleb128 .Lcst_end2-.Lcst_begin2
.Lcst_begin2:
	.uleb128 .Ltmp14-.Lfunc_begin2
	.uleb128 .Ltmp15-.Ltmp14
	.uleb128 .Ltmp16-.Lfunc_begin2
	.byte	0
	.uleb128 .Ltmp17-.Lfunc_begin2
	.uleb128 .Ltmp18-.Ltmp17
	.uleb128 .Ltmp19-.Lfunc_begin2
	.byte	1
	.uleb128 .Ltmp18-.Lfunc_begin2
	.uleb128 .Lfunc_end10-.Ltmp18
	.byte	0
	.byte	0
.Lcst_end2:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase1:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception3
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, (%rsp)
	movq	(%rdi), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rdi), %rax
	movq	(%rax), %rax
	movq	%rax, 16(%rsp)
	cmpq	$0, %rax
	je	.LBB11_2
.Ltmp20:
	movq	16(%rsp), %rax
	movq	8(%rsp), %rdi
	callq	*%rax
.Ltmp21:
	jmp	.LBB11_2
.LBB11_2:
	movq	(%rsp), %rdi
	callq	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB11_3:
	.cfi_def_cfa_offset 48
.Ltmp23:
	movq	(%rsp), %rdi
	callq	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp24:
	jmp	.LBB11_6
.LBB11_4:
.Ltmp22:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 24(%rsp)
	movl	%eax, 32(%rsp)
	jmp	.LBB11_3
.LBB11_5:
.Ltmp25:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB11_6:
	movq	24(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end11:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end11-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table11:
.Lexception3:
	.byte	255
	.byte	155
	.uleb128 .Lttbase2-.Lttbaseref2
.Lttbaseref2:
	.byte	1
	.uleb128 .Lcst_end3-.Lcst_begin3
.Lcst_begin3:
	.uleb128 .Ltmp20-.Lfunc_begin3
	.uleb128 .Ltmp21-.Ltmp20
	.uleb128 .Ltmp22-.Lfunc_begin3
	.byte	0
	.uleb128 .Ltmp21-.Lfunc_begin3
	.uleb128 .Ltmp23-.Ltmp21
	.byte	0
	.byte	0
	.uleb128 .Ltmp23-.Lfunc_begin3
	.uleb128 .Ltmp24-.Ltmp23
	.uleb128 .Ltmp25-.Lfunc_begin3
	.byte	1
	.uleb128 .Ltmp24-.Lfunc_begin3
	.uleb128 .Lfunc_end11-.Ltmp24
	.byte	0
	.byte	0
.Lcst_end3:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase2:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception4
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
	movq	(%rdi), %rdi
.Ltmp26:
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp27:
	jmp	.LBB12_3
.LBB12_1:
.Ltmp29:
	movq	(%rsp), %rdi
	callq	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp30:
	jmp	.LBB12_5
.LBB12_2:
.Ltmp28:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 8(%rsp)
	movl	%eax, 16(%rsp)
	jmp	.LBB12_1
.LBB12_3:
	movq	(%rsp), %rdi
	callq	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB12_4:
	.cfi_def_cfa_offset 32
.Ltmp31:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB12_5:
	movq	8(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end12:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end12-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table12:
.Lexception4:
	.byte	255
	.byte	155
	.uleb128 .Lttbase3-.Lttbaseref3
.Lttbaseref3:
	.byte	1
	.uleb128 .Lcst_end4-.Lcst_begin4
.Lcst_begin4:
	.uleb128 .Ltmp26-.Lfunc_begin4
	.uleb128 .Ltmp27-.Ltmp26
	.uleb128 .Ltmp28-.Lfunc_begin4
	.byte	0
	.uleb128 .Ltmp29-.Lfunc_begin4
	.uleb128 .Ltmp30-.Ltmp29
	.uleb128 .Ltmp31-.Lfunc_begin4
	.byte	1
	.uleb128 .Ltmp30-.Lfunc_begin4
	.uleb128 .Lfunc_end12-.Ltmp30
	.byte	0
	.byte	0
.Lcst_end4:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase3:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end13:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end13-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVechENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCshr3nYqPH3YZ_5gimli@GOTPCREL(%rip)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end14:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end14-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc7raw_vec6RawVechEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end15:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end15-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, (%rsp)
	movb	(%rdi), %al
	subb	$3, %al
	jb	.LBB16_2
	jmp	.LBB16_1
.LBB16_1:
	movq	(%rsp), %rdi
	addq	$8, %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.LBB16_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end16:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end16-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end17:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end17-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VechEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end18:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end18-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end19:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end19-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SendNtB1w_4SyncEL_EECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end20:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end20-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error6CustomECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtNtCs82cP7IqP7wY_3std4sync6poison5mutex10MutexGuardINtNtNtNtBK_2io8buffered9bufreader9BufReaderNtNtB1D_5stdio8StdinRawEEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end21:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end21-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end22:
	.size	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end22-_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked4ReprECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, -16(%rsp)
	movsd	%xmm0, -8(%rsp)
	leaq	-16(%rsp), %rax
	#APP
	#NO_APP
	movq	-16(%rsp), %rax
	movsd	-8(%rsp), %xmm0
	retq
.Lfunc_end23:
	.size	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end23-_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movsd	%xmm0, -8(%rsp)
	leaq	-8(%rsp), %rax
	#APP
	#NO_APP
	movsd	-8(%rsp), %xmm0
	retq
.Lfunc_end24:
	.size	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end24-_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.hidden	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.globl	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.p2align	4
	.type	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %eax
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	movq	%rsp, %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.2(%rip), %rsi
	movzbl	%al, %r8d
	callq	*_RNvNtCs82cP7IqP7wY_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end25:
	.size	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end25-_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 24(%rsp)
	callq	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 48(%rsp)
	movq	48(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB26_2
	movq	48(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	40(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 23(%rsp)
	cmpb	$-128, %al
	jb	.LBB26_5
	jmp	.LBB26_4
.LBB26_2:
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3(%rip), %ecx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3+4(%rip), %eax
	movl	%ecx, 32(%rsp)
	movl	%eax, 36(%rsp)
.LBB26_3:
	jmp	.LBB26_17
.LBB26_4:
	movq	24(%rsp), %rdi
	movb	23(%rsp), %al
	andb	$31, %al
	movzbl	%al, %eax
	movl	%eax, 16(%rsp)
	callq	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 56(%rsp)
	movq	56(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	jne	.LBB26_6
	jmp	.LBB26_7
.LBB26_5:
	movb	23(%rsp), %al
	movzbl	%al, %eax
	movl	%eax, 36(%rsp)
	movl	$1, 32(%rsp)
	jmp	.LBB26_3
.LBB26_6:
	movb	23(%rsp), %al
	movl	16(%rsp), %ecx
	movq	56(%rsp), %rdx
	movb	(%rdx), %dl
	movb	%dl, 15(%rsp)
	shll	$6, %ecx
	andb	$63, %dl
	movzbl	%dl, %edx
	orl	%edx, %ecx
	movl	%ecx, 68(%rsp)
	cmpb	$-32, %al
	jae	.LBB26_10
	jmp	.LBB26_9
.LBB26_7:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.5(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
.LBB26_8:
	ud2
.LBB26_9:
	movl	68(%rsp), %eax
	movl	%eax, 36(%rsp)
	movl	$1, 32(%rsp)
	jmp	.LBB26_17
.LBB26_10:
	movq	24(%rsp), %rdi
	callq	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 72(%rsp)
	movq	72(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB26_12
	movb	23(%rsp), %al
	movl	16(%rsp), %ecx
	movb	15(%rsp), %dl
	movq	72(%rsp), %rsi
	movb	(%rsi), %sil
	andb	$63, %dl
	movzbl	%dl, %edx
	shll	$6, %edx
	andb	$63, %sil
	movzbl	%sil, %esi
	orl	%esi, %edx
	movl	%edx, 8(%rsp)
	shll	$12, %ecx
	orl	%edx, %ecx
	movl	%ecx, 68(%rsp)
	cmpb	$-16, %al
	jae	.LBB26_14
	jmp	.LBB26_13
.LBB26_12:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.6(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB26_8
.LBB26_13:
	jmp	.LBB26_9
.LBB26_14:
	movq	24(%rsp), %rdi
	callq	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 80(%rsp)
	movq	80(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB26_16
	movl	8(%rsp), %ecx
	movl	16(%rsp), %eax
	movq	80(%rsp), %rdx
	movb	(%rdx), %dl
	andl	$7, %eax
	shll	$18, %eax
	shll	$6, %ecx
	andb	$63, %dl
	movzbl	%dl, %edx
	orl	%edx, %ecx
	orl	%ecx, %eax
	movl	%eax, 68(%rsp)
	jmp	.LBB26_13
.LBB26_16:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.7(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB26_8
.LBB26_17:
	movl	32(%rsp), %eax
	movl	36(%rsp), %edx
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end26:
	.size	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end26-_RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, 8(%rsp)
	callq	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB27_2
	movq	32(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	24(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 7(%rsp)
	cmpb	$-128, %al
	jb	.LBB27_5
	jmp	.LBB27_4
.LBB27_2:
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3(%rip), %ecx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3+4(%rip), %eax
	movl	%ecx, 16(%rsp)
	movl	%eax, 20(%rsp)
.LBB27_3:
	jmp	.LBB27_19
.LBB27_4:
	movq	8(%rsp), %rdi
	callq	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 40(%rsp)
	movq	40(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	jne	.LBB27_6
	jmp	.LBB27_7
.LBB27_5:
	movb	7(%rsp), %al
	movzbl	%al, %eax
	movl	%eax, 20(%rsp)
	movl	$1, 16(%rsp)
	jmp	.LBB27_3
.LBB27_6:
	movq	40(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 6(%rsp)
	movb	%al, %cl
	andb	$31, %cl
	movzbl	%cl, %ecx
	movl	%ecx, 68(%rsp)
	cmpb	$-64, %al
	jl	.LBB27_10
	jmp	.LBB27_9
.LBB27_7:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.8(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
.LBB27_8:
	ud2
.LBB27_9:
	jmp	.LBB27_11
.LBB27_10:
	movq	8(%rsp), %rdi
	callq	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 48(%rsp)
	movq	48(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	jne	.LBB27_12
	jmp	.LBB27_13
.LBB27_11:
	movb	7(%rsp), %cl
	movl	68(%rsp), %eax
	shll	$6, %eax
	andb	$63, %cl
	movzbl	%cl, %ecx
	orl	%ecx, %eax
	movl	%eax, 68(%rsp)
	movl	68(%rsp), %eax
	movl	%eax, 20(%rsp)
	movl	$1, 16(%rsp)
	jmp	.LBB27_19
.LBB27_12:
	movq	48(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 5(%rsp)
	movb	%al, %cl
	andb	$15, %cl
	movzbl	%cl, %ecx
	movl	%ecx, 68(%rsp)
	cmpb	$-64, %al
	jl	.LBB27_15
	jmp	.LBB27_14
.LBB27_13:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.9(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB27_8
.LBB27_14:
	jmp	.LBB27_16
.LBB27_15:
	movq	8(%rsp), %rdi
	callq	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 56(%rsp)
	movq	56(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	jne	.LBB27_17
	jmp	.LBB27_18
.LBB27_16:
	movb	6(%rsp), %cl
	movl	68(%rsp), %eax
	shll	$6, %eax
	andb	$63, %cl
	movzbl	%cl, %ecx
	orl	%ecx, %eax
	movl	%eax, 68(%rsp)
	jmp	.LBB27_11
.LBB27_17:
	movb	5(%rsp), %cl
	movq	56(%rsp), %rax
	movb	(%rax), %al
	andb	$7, %al
	movzbl	%al, %eax
	movl	%eax, 68(%rsp)
	movl	68(%rsp), %eax
	shll	$6, %eax
	andb	$63, %cl
	movzbl	%cl, %ecx
	orl	%ecx, %eax
	movl	%eax, 68(%rsp)
	jmp	.LBB27_16
.LBB27_18:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.10(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB27_8
.LBB27_19:
	movl	16(%rsp), %eax
	movl	20(%rsp), %edx
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end27:
	.size	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end27-_RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
	movb	%sil, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rcx
	leaq	.LJTI28_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rcx, %rax
	jmpq	*%rax
	.cfi_def_cfa_offset 8
	ud2
.LBB28_2:
	.cfi_def_cfa_offset 32
	movq	(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 16(%rsp)
	jmp	.LBB28_7
.LBB28_3:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.11(%rip), %rdi
	movl	$81, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.13(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB28_4:
	movq	(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 16(%rsp)
	jmp	.LBB28_7
.LBB28_5:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.14(%rip), %rdi
	movl	$99, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.15(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB28_6:
	movq	(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 16(%rsp)
.LBB28_7:
	movq	16(%rsp), %rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end28:
	.size	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end28-_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.rodata._RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
.LJTI28_0:
	.long	.LBB28_2-.LJTI28_0
	.long	.LBB28_3-.LJTI28_0
	.long	.LBB28_4-.LJTI28_0
	.long	.LBB28_5-.LJTI28_0
	.long	.LBB28_6-.LJTI28_0

	.section	.text._RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
	movb	%dl, %al
	movb	%sil, %cl
	movb	%cl, 15(%rsp)
	movzbl	%al, %eax
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %rcx
	leaq	.LJTI29_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rcx, %rax
	jmpq	*%rax
	.cfi_def_cfa_offset 8
	ud2
.LBB29_2:
	.cfi_def_cfa_offset 32
	movq	(%rsp), %rax
	movb	15(%rsp), %cl
	movb	%cl, (%rax)
	jmp	.LBB29_7
.LBB29_3:
	movq	(%rsp), %rax
	movb	15(%rsp), %cl
	movb	%cl, (%rax)
	jmp	.LBB29_7
.LBB29_4:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.16(%rip), %rdi
	movl	$85, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.17(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB29_5:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.18(%rip), %rdi
	movl	$101, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.19(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB29_6:
	movq	(%rsp), %rcx
	movb	15(%rsp), %al
	xchgb	%al, (%rcx)
.LBB29_7:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end29:
	.size	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end29-_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.rodata._RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
.LJTI29_0:
	.long	.LBB29_2-.LJTI29_0
	.long	.LBB29_3-.LJTI29_0
	.long	.LBB29_4-.LJTI29_0
	.long	.LBB29_5-.LJTI29_0
	.long	.LBB29_6-.LJTI29_0

	.section	.text._RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end30:
	.size	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end30-_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception5
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, 16(%rsp)
	movq	%rdi, 24(%rsp)
	movq	%rdi, 32(%rsp)
	movb	$1, 63(%rsp)
	movq	%rsi, %rax
	movq	%rax, 40(%rsp)
	movl	%esi, %eax
	andl	$3, %eax
	movq	%rax, 48(%rsp)
	subq	$3, %rax
	ja	.LBB31_1
	movq	48(%rsp), %rcx
	leaq	.LJTI31_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rcx, %rax
	jmpq	*%rax
.LBB31_1:
.Ltmp36:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.22(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.23(%rip), %rdx
	movq	_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip), %rax
	movl	$40, %esi
	callq	*%rax
.Ltmp37:
	jmp	.LBB31_15
.LBB31_2:
	movq	24(%rsp), %rax
	movq	40(%rsp), %rcx
	sarq	$32, %rcx
	movl	%ecx, 4(%rax)
	movb	$0, (%rax)
	jmp	.LBB31_6
.LBB31_3:
	movq	40(%rsp), %rax
	shrq	$32, %rax
	movl	%eax, %edi
.Ltmp34:
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp35:
	movb	%al, 15(%rsp)
	jmp	.LBB31_9
.LBB31_4:
	movq	24(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movb	$2, (%rax)
	jmp	.LBB31_6
.LBB31_5:
	movq	16(%rsp), %rax
	decq	%rax
	movq	%rax, 80(%rsp)
	movq	80(%rsp), %rdi
	movb	$0, 63(%rsp)
.Ltmp32:
	callq	_RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp33:
	movq	%rax, (%rsp)
	jmp	.LBB31_14
.LBB31_6:
	jmp	.LBB31_13
.LBB31_7:
	testb	$1, 63(%rsp)
	jne	.LBB31_17
	jmp	.LBB31_16
.LBB31_8:
.Ltmp38:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 64(%rsp)
	movl	%eax, 72(%rsp)
	jmp	.LBB31_7
.LBB31_9:
	movb	15(%rsp), %al
	movb	%al, 62(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpb	$-1, 62(%rsp)
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB31_11
	movq	24(%rsp), %rax
	movb	62(%rsp), %cl
	movb	%cl, 1(%rax)
	movb	$1, (%rax)
	jmp	.LBB31_6
.LBB31_11:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.21(%rip), %rdi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	ud2
.LBB31_13:
	movq	32(%rsp), %rax
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB31_14:
	.cfi_def_cfa_offset 96
	movq	24(%rsp), %rax
	movq	(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movb	$3, (%rax)
	jmp	.LBB31_13
.LBB31_15:
	ud2
.LBB31_16:
	movq	64(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB31_17:
	jmp	.LBB31_16
.Lfunc_end31:
	.size	_RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end31-_RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.rodata._RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
.LJTI31_0:
	.long	.LBB31_4-.LJTI31_0
	.long	.LBB31_5-.LJTI31_0
	.long	.LBB31_2-.LJTI31_0
	.long	.LBB31_3-.LJTI31_0
	.section	.gcc_except_table._RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table31:
.Lexception5:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end5-.Lcst_begin5
.Lcst_begin5:
	.uleb128 .Ltmp36-.Lfunc_begin5
	.uleb128 .Ltmp33-.Ltmp36
	.uleb128 .Ltmp38-.Lfunc_begin5
	.byte	0
	.uleb128 .Ltmp33-.Lfunc_begin5
	.uleb128 .Lfunc_end31-.Ltmp33
	.byte	0
	.byte	0
.Lcst_end5:
	.p2align	2, 0x0

	.section	.text._RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 8(%rsp)
	movq	%rdi, 16(%rsp)
	leaq	24(%rsp), %rdi
	callq	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	8(%rsp), %rdi
	leaq	24(%rsp), %rsi
	callq	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	16(%rsp), %rax
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end32:
	.size	_RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end32-_RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	callq	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 24(%rsp)
	movq	%rdx, 32(%rsp)
	movq	24(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB33_2
	movq	24(%rsp), %rcx
	movq	32(%rsp), %rax
	movq	%rcx, 8(%rsp)
	movq	%rax, 16(%rsp)
	jmp	.LBB33_3
.LBB33_2:
	movq	$0, 8(%rsp)
.LBB33_3:
	movq	24(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB33_5
.LBB33_4:
	movq	8(%rsp), %rax
	movq	16(%rsp), %rdx
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB33_5:
	.cfi_def_cfa_offset 48
	jmp	.LBB33_4
.Lfunc_end33:
	.size	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end33-_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception6
	subq	$168, %rsp
	.cfi_def_cfa_offset 176
	movq	%rdi, 80(%rsp)
	movq	%rsi, 88(%rsp)
	movb	$1, 151(%rsp)
.LBB34_1:
.Ltmp39:
	movq	80(%rsp), %rdi
	callq	_RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp40:
	movq	%rdx, 64(%rsp)
	movq	%rax, 72(%rsp)
	jmp	.LBB34_4
.LBB34_2:
	testb	$1, 151(%rsp)
	jne	.LBB34_15
	jmp	.LBB34_14
.LBB34_3:
.Ltmp49:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 152(%rsp)
	movl	%eax, 160(%rsp)
	jmp	.LBB34_2
.LBB34_4:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rax, 120(%rsp)
	movq	112(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB34_6
	movq	112(%rsp), %rsi
	movq	120(%rsp), %rdx
	movb	$0, 151(%rsp)
.Ltmp43:
	leaq	88(%rsp), %rdi
	callq	_RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp44:
	movq	%rdx, 48(%rsp)
	movq	%rax, 56(%rsp)
	jmp	.LBB34_7
.LBB34_6:
	movb	$0, 151(%rsp)
.Ltmp41:
	callq	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp42:
	movq	%rdx, 32(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.LBB34_13
.LBB34_7:
.Ltmp45:
	movq	48(%rsp), %rsi
	movq	56(%rsp), %rdi
	callq	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp46:
	movq	%rdx, 16(%rsp)
	movq	%rax, 24(%rsp)
	jmp	.LBB34_8
.LBB34_8:
	movq	16(%rsp), %rax
	movq	24(%rsp), %rcx
	movq	%rcx, 128(%rsp)
	movq	%rax, 136(%rsp)
	movq	128(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB34_10
	movq	128(%rsp), %rdi
	movq	136(%rsp), %rsi
.Ltmp47:
	callq	_RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp48:
	movq	%rdx, (%rsp)
	movq	%rax, 8(%rsp)
	jmp	.LBB34_11
.LBB34_10:
	movb	$1, 151(%rsp)
	jmp	.LBB34_1
.LBB34_11:
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	%rcx, 96(%rsp)
	movq	%rax, 104(%rsp)
.LBB34_12:
	movq	96(%rsp), %rax
	movq	104(%rsp), %rdx
	addq	$168, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB34_13:
	.cfi_def_cfa_offset 176
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 96(%rsp)
	movq	%rax, 104(%rsp)
	jmp	.LBB34_12
.LBB34_14:
	movq	152(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB34_15:
	jmp	.LBB34_14
.Lfunc_end34:
	.size	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end34-_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB12_4find5checkReQNtB8_10IsNotEmptyE0INtNtNtBa_3ops12control_flow11ControlFlowB2d_EECs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table34:
.Lexception6:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end6-.Lcst_begin6
.Lcst_begin6:
	.uleb128 .Ltmp39-.Lfunc_begin6
	.uleb128 .Ltmp48-.Ltmp39
	.uleb128 .Ltmp49-.Lfunc_begin6
	.byte	0
	.uleb128 .Ltmp48-.Lfunc_begin6
	.uleb128 .Lfunc_end34-.Ltmp48
	.byte	0
	.byte	0
.Lcst_end6:
	.p2align	2, 0x0

	.section	.text._RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movq	%rax, (%rsp)
	callq	_RINvXse_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReEINtNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collect12FromIteratorBG_E9from_iterNtNtNtBS_3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end35:
	.size	_RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end35-_RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs82cP7IqP7wY_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	callq	_RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movzbl	%al, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end36:
	.size	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end36-_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception7
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rsi, 8(%rsp)
	movq	%rdx, 16(%rsp)
.Ltmp50:
	leaq	8(%rsp), %rsi
	callq	_RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp51:
	movb	%al, 7(%rsp)
	jmp	.LBB37_3
.LBB37_1:
	movq	40(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB37_2:
.Ltmp52:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 40(%rsp)
	movl	%eax, 48(%rsp)
	jmp	.LBB37_1
.LBB37_3:
	movb	7(%rsp), %al
	testb	$1, %al
	jne	.LBB37_5
	jmp	.LBB37_4
.LBB37_4:
	movq	$0, 24(%rsp)
	jmp	.LBB37_6
.LBB37_5:
	movq	8(%rsp), %rcx
	movq	16(%rsp), %rax
	movq	%rcx, 24(%rsp)
	movq	%rax, 32(%rsp)
.LBB37_6:
	movq	24(%rsp), %rax
	movq	32(%rsp), %rdx
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end37:
	.size	_RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end37-_RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNCINvNvNtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4find5checkReQNtNtBe_3str10IsNotEmptyE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table37:
.Lexception7:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end7-.Lcst_begin7
.Lcst_begin7:
	.uleb128 .Ltmp50-.Lfunc_begin7
	.uleb128 .Ltmp51-.Ltmp50
	.uleb128 .Ltmp52-.Lfunc_begin7
	.byte	0
	.uleb128 .Ltmp51-.Lfunc_begin7
	.uleb128 .Lfunc_end37-.Ltmp51
	.byte	0
	.byte	0
.Lcst_end7:
	.p2align	2, 0x0

	.section	.text._RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_,"ax",@progbits
	.p2align	4
	.type	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_,@function
_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_:
	.cfi_startproc
	movsd	(%rsi), %xmm0
	retq
.Lfunc_end38:
	.size	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_, .Lfunc_end38-_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_
	.cfi_endproc

	.section	.text._RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_,"ax",@progbits
	.p2align	4
	.type	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_,@function
_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_:
	.cfi_startproc
	movsd	(%rsi), %xmm0
	retq
.Lfunc_end39:
	.size	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_, .Lfunc_end39-_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_
	.cfi_endproc

	.section	.text._RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, (%rsp)
	jmp	.LBB40_1
.LBB40_1:
	movq	(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.25(%rip), %rsi
	callq	_RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end40:
	.size	_RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end40-_RNCNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB7_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end41:
	.size	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end41-_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main,"ax",@progbits
	.hidden	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main
	.globl	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main
	.p2align	4
	.type	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main,@function
_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main:
.Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception8
	subq	$2152, %rsp
	.cfi_def_cfa_offset 2160
	callq	*_RNvNtNtCs82cP7IqP7wY_3std2io5stdio5stdin@GOTPCREL(%rip)
	movq	%rax, 448(%rsp)
	leaq	448(%rsp), %rdi
	callq	*_RNvMs1_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_5Stdin4lock@GOTPCREL(%rip)
	movq	%rax, %rdi
	movzbl	%dl, %esi
	andl	$1, %esi
	callq	_RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, %rdi
	movzbl	%dl, %esi
	andl	$1, %esi
	callq	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 456(%rsp)
	andb	$1, %dl
	movb	%dl, 464(%rsp)
.LBB42_1:
.Ltmp53:
	leaq	472(%rsp), %rdi
	leaq	456(%rsp), %rsi
	callq	_RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp54:
	jmp	.LBB42_5
.LBB42_2:
.Ltmp226:
	leaq	456(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp227:
	jmp	.LBB42_150
.LBB42_3:
.Ltmp191:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 432(%rsp)
	movl	%eax, 444(%rsp)
	jmp	.LBB42_4
.LBB42_4:
	movq	432(%rsp), %rcx
	movl	444(%rsp), %eax
	movq	%rcx, 1784(%rsp)
	movl	%eax, 1792(%rsp)
	jmp	.LBB42_2
.LBB42_5:
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$-2, 472(%rsp)
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB42_13
	movq	472(%rsp), %rax
	movq	%rax, 496(%rsp)
	movq	480(%rsp), %rax
	movq	%rax, 504(%rsp)
	movq	488(%rsp), %rax
	movq	%rax, 512(%rsp)
	movq	496(%rsp), %rax
	movq	%rax, 1800(%rsp)
	movq	504(%rsp), %rax
	movq	%rax, 1808(%rsp)
	movq	512(%rsp), %rax
	movq	%rax, 1816(%rsp)
	xorl	%eax, %eax
	movl	$1, %ecx
	cmpq	$-1, 1800(%rsp)
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB42_12
	movq	1808(%rsp), %rax
	movq	%rax, 1888(%rsp)
.Ltmp220:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.66(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.27(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	1888(%rsp), %rdx
	callq	*%rax
.Ltmp221:
	jmp	.LBB42_9
.LBB42_8:
.Ltmp222:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 1896(%rsp)
	movl	%eax, 1904(%rsp)
.Ltmp223:
	leaq	1888(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp224:
	jmp	.LBB42_11
.LBB42_9:
	ud2
.LBB42_10:
.Ltmp225:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB42_11:
	movq	1896(%rsp), %rcx
	movl	1904(%rsp), %eax
	movq	%rcx, 432(%rsp)
	movl	%eax, 444(%rsp)
	jmp	.LBB42_4
.LBB42_12:
	movq	1800(%rsp), %rax
	movq	%rax, 520(%rsp)
	movq	1808(%rsp), %rax
	movq	%rax, 528(%rsp)
	movq	1816(%rsp), %rax
	movq	%rax, 536(%rsp)
	jmp	.LBB42_14
.LBB42_13:
	leaq	456(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBE_5stdio9StdinLockEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$2152, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB42_14:
	.cfi_def_cfa_offset 2160
.Ltmp55:
	leaq	520(%rsp), %rdi
	callq	_RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp56:
	movq	%rdx, 416(%rsp)
	movq	%rax, 424(%rsp)
	jmp	.LBB42_17
.LBB42_15:
.Ltmp218:
	leaq	520(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp219:
	jmp	.LBB42_2
.LBB42_16:
.Ltmp188:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 1784(%rsp)
	movl	%eax, 1792(%rsp)
	jmp	.LBB42_15
.LBB42_17:
.Ltmp57:
	movq	416(%rsp), %rdx
	movq	424(%rsp), %rsi
	leaq	568(%rsp), %rdi
	callq	_RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp58:
	jmp	.LBB42_18
.LBB42_18:
.Ltmp59:
	leaq	544(%rsp), %rdi
	leaq	568(%rsp), %rsi
	callq	_RINvYNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp60:
	jmp	.LBB42_19
.LBB42_19:
.Ltmp61:
	leaq	544(%rsp), %rdi
	callq	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp62:
	movq	%rax, 408(%rsp)
	jmp	.LBB42_29
.LBB42_20:
.Ltmp216:
	leaq	544(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp217:
	jmp	.LBB42_15
.LBB42_21:
.Ltmp185:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 392(%rsp)
	movl	%eax, 404(%rsp)
	jmp	.LBB42_22
.LBB42_22:
	movq	392(%rsp), %rcx
	movl	404(%rsp), %eax
	movq	%rcx, 376(%rsp)
	movl	%eax, 388(%rsp)
	jmp	.LBB42_23
.LBB42_23:
	movq	376(%rsp), %rcx
	movl	388(%rsp), %eax
	movq	%rcx, 360(%rsp)
	movl	%eax, 372(%rsp)
	jmp	.LBB42_24
.LBB42_24:
	movq	360(%rsp), %rcx
	movl	372(%rsp), %eax
	movq	%rcx, 344(%rsp)
	movl	%eax, 356(%rsp)
	jmp	.LBB42_25
.LBB42_25:
	movq	344(%rsp), %rcx
	movl	356(%rsp), %eax
	movq	%rcx, 328(%rsp)
	movl	%eax, 340(%rsp)
	jmp	.LBB42_26
.LBB42_26:
	movq	328(%rsp), %rcx
	movl	340(%rsp), %eax
	movq	%rcx, 312(%rsp)
	movl	%eax, 324(%rsp)
	jmp	.LBB42_27
.LBB42_27:
	movq	312(%rsp), %rcx
	movl	324(%rsp), %eax
	movq	%rcx, 296(%rsp)
	movl	%eax, 308(%rsp)
	jmp	.LBB42_28
.LBB42_28:
	movq	296(%rsp), %rcx
	movl	308(%rsp), %eax
	movq	%rcx, 1784(%rsp)
	movl	%eax, 1792(%rsp)
	jmp	.LBB42_20
.LBB42_29:
	movq	408(%rsp), %rax
	movq	%rax, 632(%rsp)
	movq	632(%rsp), %rax
	cmpq	.Lanon.f31448597b1a273a87802a75e10efe0f.28(%rip), %rax
	je	.LBB42_31
.Ltmp63:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.28(%rip), %rdx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.29(%rip), %r9
	movq	_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip), %rax
	xorl	%edi, %edi
	movl	%edi, %ecx
	leaq	632(%rsp), %rsi
	callq	*%rax
.Ltmp64:
	jmp	.LBB42_32
.LBB42_31:
.Ltmp65:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.30(%rip), %rdx
	xorl	%eax, %eax
	movl	%eax, %esi
	leaq	544(%rsp), %rdi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp66:
	movq	%rax, 288(%rsp)
	jmp	.LBB42_33
.LBB42_32:
	ud2
.LBB42_33:
	movq	288(%rsp), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, 640(%rsp)
	movq	%rax, 648(%rsp)
.Ltmp67:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.31(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$1, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp68:
	movq	%rax, 280(%rsp)
	jmp	.LBB42_34
.LBB42_34:
	movq	280(%rsp), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, 656(%rsp)
	movq	%rax, 664(%rsp)
.Ltmp69:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.33(%rip), %rsi
	leaq	656(%rsp), %rdi
	callq	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp70:
	movb	%al, 279(%rsp)
	jmp	.LBB42_35
.LBB42_35:
	movb	279(%rsp), %al
	testb	$1, %al
	jne	.LBB42_37
	jmp	.LBB42_36
.LBB42_36:
.Ltmp71:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.35(%rip), %rsi
	leaq	656(%rsp), %rdi
	callq	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp72:
	movb	%al, 278(%rsp)
	jmp	.LBB42_38
.LBB42_37:
.Ltmp75:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.38(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$2, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp76:
	movq	%rax, 264(%rsp)
	jmp	.LBB42_40
.LBB42_38:
	movb	278(%rsp), %al
	testb	$1, %al
	jne	.LBB42_37
	jmp	.LBB42_39
.LBB42_39:
.Ltmp73:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.36(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.37(%rip), %rdx
	movq	_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip), %rax
	movl	$59, %esi
	callq	*%rax
.Ltmp74:
	jmp	.LBB42_32
.LBB42_40:
	movq	264(%rsp), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rdx
.Ltmp77:
	leaq	680(%rsp), %rdi
	movl	$16, %ecx
	callq	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp78:
	jmp	.LBB42_41
.LBB42_41:
	movb	680(%rsp), %al
	testb	$1, %al
	jne	.LBB42_42
	jmp	.LBB42_45
.LBB42_42:
	movb	681(%rsp), %al
	movb	%al, 2135(%rsp)
.Ltmp213:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.39(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	2135(%rsp), %rdx
	callq	*%rax
.Ltmp214:
	jmp	.LBB42_44
.LBB42_43:
.Ltmp215:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 2136(%rsp)
	movl	%eax, 2144(%rsp)
	movq	2136(%rsp), %rcx
	movl	2144(%rsp), %eax
	movq	%rcx, 392(%rsp)
	movl	%eax, 404(%rsp)
	jmp	.LBB42_22
.LBB42_44:
	ud2
.LBB42_45:
	movq	688(%rsp), %rax
	movq	%rax, 256(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 672(%rsp)
.Ltmp79:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.40(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$3, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp80:
	movq	%rax, 248(%rsp)
	jmp	.LBB42_47
.LBB42_47:
	movq	248(%rsp), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rdx
.Ltmp81:
	leaq	704(%rsp), %rdi
	movl	$16, %ecx
	callq	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp82:
	jmp	.LBB42_48
.LBB42_48:
	movb	704(%rsp), %al
	testb	$1, %al
	jne	.LBB42_49
	jmp	.LBB42_52
.LBB42_49:
	movb	705(%rsp), %al
	movb	%al, 2111(%rsp)
.Ltmp210:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.41(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	2111(%rsp), %rdx
	callq	*%rax
.Ltmp211:
	jmp	.LBB42_51
.LBB42_50:
.Ltmp212:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 2112(%rsp)
	movl	%eax, 2120(%rsp)
	movq	2112(%rsp), %rcx
	movl	2120(%rsp), %eax
	movq	%rcx, 376(%rsp)
	movl	%eax, 388(%rsp)
	jmp	.LBB42_23
.LBB42_51:
	ud2
.LBB42_52:
	movq	712(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	240(%rsp), %rax
	movq	%rax, 696(%rsp)
.Ltmp83:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.42(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$4, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp84:
	movq	%rax, 232(%rsp)
	jmp	.LBB42_54
.LBB42_54:
	movq	232(%rsp), %rax
	movq	(%rax), %rdi
	movq	8(%rax), %rsi
.Ltmp85:
	callq	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp86:
	movq	%rax, 224(%rsp)
	jmp	.LBB42_55
.LBB42_55:
	movq	224(%rsp), %rax
	movq	%rax, 1824(%rsp)
	movq	1824(%rsp), %rax
	movq	%rax, 728(%rsp)
	movq	728(%rsp), %rax
	movq	%rax, 1832(%rsp)
	movq	1832(%rsp), %rax
	movq	%rax, 2040(%rsp)
	movq	2040(%rsp), %rax
	movq	%rax, 2032(%rsp)
	movb	2032(%rsp), %al
	testb	$1, %al
	jne	.LBB42_56
	jmp	.LBB42_59
.LBB42_56:
	movb	2033(%rsp), %al
	movb	%al, 2055(%rsp)
.Ltmp207:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.43(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	2055(%rsp), %rdx
	callq	*%rax
.Ltmp208:
	jmp	.LBB42_58
.LBB42_57:
.Ltmp209:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 2056(%rsp)
	movl	%eax, 2064(%rsp)
	movq	2056(%rsp), %rcx
	movl	2064(%rsp), %eax
	movq	%rcx, 344(%rsp)
	movl	%eax, 356(%rsp)
	jmp	.LBB42_25
.LBB42_58:
	ud2
.LBB42_59:
	movl	2036(%rsp), %eax
	movl	%eax, 220(%rsp)
	movl	220(%rsp), %eax
	movl	%eax, 724(%rsp)
.Ltmp87:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.44(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$5, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp88:
	movq	%rax, 208(%rsp)
	jmp	.LBB42_61
.LBB42_61:
	movq	208(%rsp), %rax
	movq	(%rax), %rdi
	movq	8(%rax), %rsi
.Ltmp89:
	callq	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp90:
	movq	%rax, 200(%rsp)
	jmp	.LBB42_62
.LBB42_62:
	movq	200(%rsp), %rax
	movq	%rax, 1840(%rsp)
	movq	1840(%rsp), %rax
	movq	%rax, 740(%rsp)
	movq	740(%rsp), %rax
	movq	%rax, 1848(%rsp)
	movq	1848(%rsp), %rax
	movq	%rax, 2000(%rsp)
	movq	2000(%rsp), %rax
	movq	%rax, 1992(%rsp)
	movb	1992(%rsp), %al
	testb	$1, %al
	jne	.LBB42_63
	jmp	.LBB42_66
.LBB42_63:
	movb	1993(%rsp), %al
	movb	%al, 2015(%rsp)
.Ltmp204:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.45(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	2015(%rsp), %rdx
	callq	*%rax
.Ltmp205:
	jmp	.LBB42_65
.LBB42_64:
.Ltmp206:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 2016(%rsp)
	movl	%eax, 2024(%rsp)
	movq	2016(%rsp), %rcx
	movl	2024(%rsp), %eax
	movq	%rcx, 328(%rsp)
	movl	%eax, 340(%rsp)
	jmp	.LBB42_26
.LBB42_65:
	ud2
.LBB42_66:
	movl	1996(%rsp), %eax
	movl	%eax, 196(%rsp)
	movl	196(%rsp), %eax
	movl	%eax, 736(%rsp)
.Ltmp91:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.46(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$6, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp92:
	movq	%rax, 184(%rsp)
	jmp	.LBB42_68
.LBB42_68:
	movq	184(%rsp), %rax
	movq	(%rax), %rdi
	movq	8(%rax), %rsi
.Ltmp93:
	callq	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp94:
	movq	%rax, 176(%rsp)
	jmp	.LBB42_69
.LBB42_69:
	movq	176(%rsp), %rax
	movq	%rax, 1856(%rsp)
	movq	1856(%rsp), %rax
	movq	%rax, 752(%rsp)
	movq	752(%rsp), %rax
	movq	%rax, 1864(%rsp)
	movq	1864(%rsp), %rax
	movq	%rax, 1960(%rsp)
	movq	1960(%rsp), %rax
	movq	%rax, 1952(%rsp)
	movb	1952(%rsp), %al
	testb	$1, %al
	jne	.LBB42_70
	jmp	.LBB42_73
.LBB42_70:
	movb	1953(%rsp), %al
	movb	%al, 1975(%rsp)
.Ltmp201:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.47(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	1975(%rsp), %rdx
	callq	*%rax
.Ltmp202:
	jmp	.LBB42_72
.LBB42_71:
.Ltmp203:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 1976(%rsp)
	movl	%eax, 1984(%rsp)
	movq	1976(%rsp), %rcx
	movl	1984(%rsp), %eax
	movq	%rcx, 312(%rsp)
	movl	%eax, 324(%rsp)
	jmp	.LBB42_27
.LBB42_72:
	ud2
.LBB42_73:
	movl	1956(%rsp), %eax
	movl	%eax, 172(%rsp)
	movl	172(%rsp), %eax
	movl	%eax, 748(%rsp)
.Ltmp95:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.48(%rip), %rdx
	leaq	544(%rsp), %rdi
	movl	$7, %esi
	callq	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp96:
	movq	%rax, 160(%rsp)
	jmp	.LBB42_75
.LBB42_75:
	movq	160(%rsp), %rax
	movq	(%rax), %rdi
	movq	8(%rax), %rsi
.Ltmp97:
	callq	_RINvMNtCs6nm8tU1dKu4_4core3stre5parselECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp98:
	movq	%rax, 152(%rsp)
	jmp	.LBB42_76
.LBB42_76:
	movq	152(%rsp), %rax
	movq	%rax, 1872(%rsp)
	movq	1872(%rsp), %rax
	movq	%rax, 760(%rsp)
	movq	760(%rsp), %rax
	movq	%rax, 1880(%rsp)
	movq	1880(%rsp), %rax
	movq	%rax, 1920(%rsp)
	movq	1920(%rsp), %rax
	movq	%rax, 1912(%rsp)
	movb	1912(%rsp), %al
	testb	$1, %al
	jne	.LBB42_77
	jmp	.LBB42_80
.LBB42_77:
	movb	1913(%rsp), %al
	movb	%al, 1935(%rsp)
.Ltmp198:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.68(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.49(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	1935(%rsp), %rdx
	callq	*%rax
.Ltmp199:
	jmp	.LBB42_79
.LBB42_78:
.Ltmp200:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 1936(%rsp)
	movl	%eax, 1944(%rsp)
	movq	1936(%rsp), %rcx
	movl	1944(%rsp), %eax
	movq	%rcx, 296(%rsp)
	movl	%eax, 308(%rsp)
	jmp	.LBB42_28
.LBB42_79:
	ud2
.LBB42_80:
	movl	1916(%rsp), %eax
	movl	%eax, 148(%rsp)
	movl	$61, %edi
	callq	*fedisableexcept@GOTPCREL(%rip)
	cmpl	$0, %eax
	jge	.LBB42_83
.Ltmp99:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.50(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.51(%rip), %rdx
	movq	_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip), %rax
	movl	$43, %esi
	callq	*%rax
.Ltmp100:
	jmp	.LBB42_32
.LBB42_83:
	movl	$61, %edi
	callq	*feclearexcept@GOTPCREL(%rip)
	movl	%eax, 768(%rsp)
	movl	768(%rsp), %eax
	cmpl	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %eax
	je	.LBB42_85
.Ltmp101:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %rdx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.53(%rip), %r9
	movq	_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedllECs82cP7IqP7wY_3std@GOTPCREL(%rip), %rax
	xorl	%edi, %edi
	movl	%edi, %ecx
	leaq	768(%rsp), %rsi
	callq	*%rax
.Ltmp102:
	jmp	.LBB42_32
.LBB42_85:
	movl	736(%rsp), %edi
	callq	*fesetround@GOTPCREL(%rip)
	movl	%eax, 772(%rsp)
	movl	772(%rsp), %eax
	cmpl	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %eax
	je	.LBB42_87
.Ltmp103:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %rdx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.54(%rip), %r9
	movq	_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedllECs82cP7IqP7wY_3std@GOTPCREL(%rip), %rax
	xorl	%edi, %edi
	movl	%edi, %ecx
	leaq	772(%rsp), %rsi
	callq	*%rax
.Ltmp104:
	jmp	.LBB42_32
.LBB42_87:
	cmpl	$0, 724(%rsp)
	jne	.LBB42_89
.LBB42_88:
	cmpl	$0, 748(%rsp)
	jne	.LBB42_92
	jmp	.LBB42_91
.LBB42_89:
	movl	724(%rsp), %edi
	callq	*feraiseexcept@GOTPCREL(%rip)
	movl	%eax, 776(%rsp)
	movl	776(%rsp), %eax
	cmpl	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %eax
	je	.LBB42_88
.Ltmp105:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.52(%rip), %rdx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.55(%rip), %r9
	movq	_RINvNtCs6nm8tU1dKu4_4core9panicking13assert_failedllECs82cP7IqP7wY_3std@GOTPCREL(%rip), %rax
	xorl	%edi, %edi
	movl	%edi, %ecx
	leaq	776(%rsp), %rsi
	callq	*%rax
.Ltmp106:
	jmp	.LBB42_32
.LBB42_91:
	movl	$61, %edi
	callq	*fetestexcept@GOTPCREL(%rip)
	movl	%eax, 780(%rsp)
	callq	*fegetround@GOTPCREL(%rip)
	movl	%eax, 784(%rsp)
	callq	*fegetexcept@GOTPCREL(%rip)
	movl	%eax, %ecx
	movl	148(%rsp), %eax
	movl	%ecx, 788(%rsp)
	cmpl	$0, %eax
	jne	.LBB42_95
	jmp	.LBB42_94
.LBB42_92:
	movl	748(%rsp), %edi
	callq	*feenableexcept@GOTPCREL(%rip)
	cmpl	$0, %eax
	jge	.LBB42_91
.Ltmp107:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.56(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.57(%rip), %rdx
	movq	_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip), %rax
	movl	$44, %esi
	callq	*%rax
.Ltmp108:
	jmp	.LBB42_32
.LBB42_94:
	movq	672(%rsp), %rdi
.Ltmp131:
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp132:
	movsd	%xmm0, 136(%rsp)
	jmp	.LBB42_114
.LBB42_95:
	leaq	640(%rsp), %rax
	movq	%rax, 792(%rsp)
	leaq	656(%rsp), %rax
	movq	%rax, 800(%rsp)
	leaq	672(%rsp), %rax
	movq	%rax, 808(%rsp)
	leaq	696(%rsp), %rax
	movq	%rax, 816(%rsp)
	leaq	780(%rsp), %rax
	movq	%rax, 824(%rsp)
	leaq	784(%rsp), %rax
	movq	%rax, 832(%rsp)
	leaq	788(%rsp), %rax
	movq	%rax, 840(%rsp)
	movq	792(%rsp), %rsi
.Ltmp109:
	leaq	960(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp110:
	jmp	.LBB42_96
.LBB42_96:
	movq	800(%rsp), %rsi
.Ltmp111:
	leaq	976(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp112:
	jmp	.LBB42_97
.LBB42_97:
	movq	808(%rsp), %rsi
.Ltmp113:
	leaq	992(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp114:
	jmp	.LBB42_98
.LBB42_98:
	movq	816(%rsp), %rsi
.Ltmp115:
	leaq	1008(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp116:
	jmp	.LBB42_99
.LBB42_99:
	movq	824(%rsp), %rsi
.Ltmp117:
	leaq	1024(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp118:
	jmp	.LBB42_100
.LBB42_100:
	movq	832(%rsp), %rsi
.Ltmp119:
	leaq	1040(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp120:
	jmp	.LBB42_101
.LBB42_101:
	movq	840(%rsp), %rsi
.Ltmp121:
	leaq	1056(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp122:
	jmp	.LBB42_102
.LBB42_102:
	movups	960(%rsp), %xmm0
	movaps	%xmm0, 848(%rsp)
	movups	976(%rsp), %xmm0
	movups	%xmm0, 864(%rsp)
	movups	992(%rsp), %xmm0
	movups	%xmm0, 880(%rsp)
	movups	1008(%rsp), %xmm0
	movups	%xmm0, 896(%rsp)
	movups	1024(%rsp), %xmm0
	movups	%xmm0, 912(%rsp)
	movups	1040(%rsp), %xmm0
	movups	%xmm0, 928(%rsp)
	movups	1056(%rsp), %xmm0
	movups	%xmm0, 944(%rsp)
.Ltmp123:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.58(%rip), %rdi
	leaq	848(%rsp), %rsi
	callq	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj29_Kj7_ECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp124:
	movq	%rdx, 120(%rsp)
	movq	%rax, 128(%rsp)
	jmp	.LBB42_103
.LBB42_103:
.Ltmp125:
	movq	120(%rsp), %rsi
	movq	128(%rsp), %rdi
	movq	_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6__print@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp126:
	jmp	.LBB42_104
.LBB42_104:
.Ltmp127:
	movq	_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6stdout@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp128:
	movq	%rax, 112(%rsp)
	jmp	.LBB42_105
.LBB42_105:
	movq	112(%rsp), %rax
	movq	%rax, 1072(%rsp)
.Ltmp129:
	movq	_RNvXse_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_6StdoutNtB7_5Write5flush@GOTPCREL(%rip), %rax
	leaq	1072(%rsp), %rdi
	callq	*%rax
.Ltmp130:
	movq	%rax, 104(%rsp)
	jmp	.LBB42_106
.LBB42_106:
	movq	104(%rsp), %rax
	movq	%rax, 2072(%rsp)
	movq	2072(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB42_112
	movq	2072(%rsp), %rax
	movq	%rax, 2080(%rsp)
.Ltmp192:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.67(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.66(%rip), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.59(%rip), %r8
	movq	_RNvNtCs6nm8tU1dKu4_4core6result13unwrap_failed@GOTPCREL(%rip), %rax
	movl	$43, %esi
	leaq	2080(%rsp), %rdx
	callq	*%rax
.Ltmp193:
	jmp	.LBB42_109
.LBB42_108:
.Ltmp194:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 2088(%rsp)
	movl	%eax, 2096(%rsp)
.Ltmp195:
	leaq	2080(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp196:
	jmp	.LBB42_111
.LBB42_109:
	ud2
.LBB42_110:
.Ltmp197:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB42_111:
	movq	2088(%rsp), %rcx
	movl	2096(%rsp), %eax
	movq	%rcx, 360(%rsp)
	movl	%eax, 372(%rsp)
	jmp	.LBB42_24
.LBB42_112:
	jmp	.LBB42_113
.LBB42_113:
	jmp	.LBB42_94
.LBB42_114:
.Ltmp133:
	movsd	136(%rsp), %xmm0
	callq	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp134:
	movsd	%xmm0, 96(%rsp)
	jmp	.LBB42_115
.LBB42_115:
	movq	696(%rsp), %rdi
.Ltmp135:
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp136:
	movsd	%xmm0, 88(%rsp)
	jmp	.LBB42_116
.LBB42_116:
.Ltmp137:
	movsd	88(%rsp), %xmm0
	callq	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxdECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp138:
	movsd	%xmm0, 80(%rsp)
	jmp	.LBB42_117
.LBB42_117:
.Ltmp139:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.33(%rip), %rsi
	leaq	656(%rsp), %rdi
	callq	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp140:
	movb	%al, 79(%rsp)
	jmp	.LBB42_118
.LBB42_118:
	movb	79(%rsp), %al
	testb	$1, %al
	jne	.LBB42_120
	jmp	.LBB42_119
.LBB42_119:
.Ltmp141:
	movsd	80(%rsp), %xmm1
	movsd	96(%rsp), %xmm0
	callq	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate
.Ltmp142:
	movsd	%xmm0, 56(%rsp)
	movq	%rax, 64(%rsp)
	jmp	.LBB42_121
.LBB42_120:
.Ltmp143:
	movsd	80(%rsp), %xmm1
	movsd	96(%rsp), %xmm0
	callq	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline
.Ltmp144:
	movsd	%xmm0, 40(%rsp)
	movq	%rax, 48(%rsp)
	jmp	.LBB42_123
.LBB42_121:
	movsd	56(%rsp), %xmm0
	movq	64(%rsp), %rax
	movq	%rax, 1096(%rsp)
	movsd	%xmm0, 1104(%rsp)
.LBB42_122:
	movq	1096(%rsp), %rdi
	movsd	1104(%rsp), %xmm0
.Ltmp145:
	callq	_RINvNtCs6nm8tU1dKu4_4core4hint9black_boxINtNtB4_6option6OptiondEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp146:
	movsd	%xmm0, 24(%rsp)
	movq	%rax, 32(%rsp)
	jmp	.LBB42_124
.LBB42_123:
	movsd	40(%rsp), %xmm0
	movq	48(%rsp), %rax
	movq	%rax, 1096(%rsp)
	movsd	%xmm0, 1104(%rsp)
	jmp	.LBB42_122
.LBB42_124:
	movsd	24(%rsp), %xmm0
	movq	32(%rsp), %rax
	movq	%rax, 1080(%rsp)
	movsd	%xmm0, 1088(%rsp)
	movl	$61, %edi
	callq	*fetestexcept@GOTPCREL(%rip)
	movl	%eax, 1116(%rsp)
	callq	*fegetround@GOTPCREL(%rip)
	movl	%eax, 1120(%rsp)
	callq	*fegetexcept@GOTPCREL(%rip)
	movl	%eax, 1124(%rsp)
	movl	$61, %edi
	callq	*fedisableexcept@GOTPCREL(%rip)
	cmpl	$0, %eax
	jge	.LBB42_126
.Ltmp147:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.50(%rip), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.60(%rip), %rdx
	movq	_RNvNtCs6nm8tU1dKu4_4core9panicking5panic@GOTPCREL(%rip), %rax
	movl	$43, %esi
	callq	*%rax
.Ltmp148:
	jmp	.LBB42_32
.LBB42_126:
	testq	$1, 1080(%rsp)
	je	.LBB42_128
	movsd	1088(%rsp), %xmm0
.Ltmp149:
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp150:
	movq	%rax, 16(%rsp)
	jmp	.LBB42_130
.LBB42_128:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.61(%rip), %rax
	movq	%rax, 1152(%rsp)
	movq	$4, 1160(%rsp)
	movq	$0, 1168(%rsp)
.LBB42_129:
	movq	1152(%rsp), %rcx
	movq	1160(%rsp), %rax
	movq	%rcx, 1128(%rsp)
	movq	%rax, 1136(%rsp)
	movq	1168(%rsp), %rax
	movq	%rax, 1144(%rsp)
	leaq	640(%rsp), %rax
	movq	%rax, 1176(%rsp)
	leaq	656(%rsp), %rax
	movq	%rax, 1184(%rsp)
	leaq	672(%rsp), %rax
	movq	%rax, 1192(%rsp)
	leaq	696(%rsp), %rax
	movq	%rax, 1200(%rsp)
	leaq	724(%rsp), %rax
	movq	%rax, 1208(%rsp)
	leaq	736(%rsp), %rax
	movq	%rax, 1216(%rsp)
	leaq	748(%rsp), %rax
	movq	%rax, 1224(%rsp)
	leaq	780(%rsp), %rax
	movq	%rax, 1232(%rsp)
	leaq	1116(%rsp), %rax
	movq	%rax, 1240(%rsp)
	leaq	784(%rsp), %rax
	movq	%rax, 1248(%rsp)
	leaq	1120(%rsp), %rax
	movq	%rax, 1256(%rsp)
	leaq	788(%rsp), %rax
	movq	%rax, 1264(%rsp)
	leaq	1124(%rsp), %rax
	movq	%rax, 1272(%rsp)
	leaq	1128(%rsp), %rax
	movq	%rax, 1280(%rsp)
	leaq	1144(%rsp), %rax
	movq	%rax, 1288(%rsp)
	movq	1176(%rsp), %rsi
.Ltmp151:
	leaq	1544(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp152:
	jmp	.LBB42_131
.LBB42_130:
	movq	16(%rsp), %rax
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.62(%rip), %rcx
	movq	%rcx, 1152(%rsp)
	movq	$4, 1160(%rsp)
	movq	%rax, 1168(%rsp)
	jmp	.LBB42_129
.LBB42_131:
	movq	1184(%rsp), %rsi
.Ltmp153:
	leaq	1560(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp154:
	jmp	.LBB42_132
.LBB42_132:
	movq	1192(%rsp), %rsi
.Ltmp155:
	leaq	1576(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp156:
	jmp	.LBB42_133
.LBB42_133:
	movq	1200(%rsp), %rsi
.Ltmp157:
	leaq	1592(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp158:
	jmp	.LBB42_134
.LBB42_134:
	movq	1208(%rsp), %rsi
.Ltmp159:
	leaq	1608(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp160:
	jmp	.LBB42_135
.LBB42_135:
	movq	1216(%rsp), %rsi
.Ltmp161:
	leaq	1624(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp162:
	jmp	.LBB42_136
.LBB42_136:
	movq	1224(%rsp), %rsi
.Ltmp163:
	leaq	1640(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp164:
	jmp	.LBB42_137
.LBB42_137:
	movq	1232(%rsp), %rsi
.Ltmp165:
	leaq	1656(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp166:
	jmp	.LBB42_138
.LBB42_138:
	movq	1240(%rsp), %rsi
.Ltmp167:
	leaq	1672(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp168:
	jmp	.LBB42_139
.LBB42_139:
	movq	1248(%rsp), %rsi
.Ltmp169:
	leaq	1688(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp170:
	jmp	.LBB42_140
.LBB42_140:
	movq	1256(%rsp), %rsi
.Ltmp171:
	leaq	1704(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp172:
	jmp	.LBB42_141
.LBB42_141:
	movq	1264(%rsp), %rsi
.Ltmp173:
	leaq	1720(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp174:
	jmp	.LBB42_142
.LBB42_142:
	movq	1272(%rsp), %rsi
.Ltmp175:
	leaq	1736(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displaylECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp176:
	jmp	.LBB42_143
.LBB42_143:
	movq	1280(%rsp), %rsi
.Ltmp177:
	leaq	1752(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument11new_displayReECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp178:
	jmp	.LBB42_144
.LBB42_144:
	movq	1288(%rsp), %rsi
.Ltmp179:
	leaq	1768(%rsp), %rdi
	callq	_RINvMNtNtCs6nm8tU1dKu4_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp180:
	jmp	.LBB42_145
.LBB42_145:
	movups	1544(%rsp), %xmm0
	movaps	%xmm0, 1296(%rsp)
	movups	1560(%rsp), %xmm0
	movups	%xmm0, 1312(%rsp)
	movups	1576(%rsp), %xmm0
	movups	%xmm0, 1328(%rsp)
	movups	1592(%rsp), %xmm0
	movups	%xmm0, 1344(%rsp)
	movups	1608(%rsp), %xmm0
	movups	%xmm0, 1360(%rsp)
	movups	1624(%rsp), %xmm0
	movups	%xmm0, 1376(%rsp)
	movups	1640(%rsp), %xmm0
	movups	%xmm0, 1392(%rsp)
	movups	1656(%rsp), %xmm0
	movups	%xmm0, 1408(%rsp)
	movups	1672(%rsp), %xmm0
	movups	%xmm0, 1424(%rsp)
	movups	1688(%rsp), %xmm0
	movups	%xmm0, 1440(%rsp)
	movups	1704(%rsp), %xmm0
	movups	%xmm0, 1456(%rsp)
	movups	1720(%rsp), %xmm0
	movups	%xmm0, 1472(%rsp)
	movups	1736(%rsp), %xmm0
	movups	%xmm0, 1488(%rsp)
	movups	1752(%rsp), %xmm0
	movups	%xmm0, 1504(%rsp)
	movups	1768(%rsp), %xmm0
	movups	%xmm0, 1520(%rsp)
.Ltmp181:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.63(%rip), %rdi
	leaq	1296(%rsp), %rsi
	callq	_RINvMs2_NtCs6nm8tU1dKu4_4core3fmtNtB6_9Arguments3newKj45_Kjf_ECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp182:
	movq	%rdx, (%rsp)
	movq	%rax, 8(%rsp)
	jmp	.LBB42_146
.LBB42_146:
.Ltmp183:
	movq	(%rsp), %rsi
	movq	8(%rsp), %rdi
	movq	_RNvNtNtCs82cP7IqP7wY_3std2io5stdio6__print@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp184:
	jmp	.LBB42_147
.LBB42_147:
.Ltmp186:
	leaq	544(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp187:
	jmp	.LBB42_148
.LBB42_148:
.Ltmp189:
	leaq	520(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp190:
	jmp	.LBB42_1
.LBB42_149:
.Ltmp228:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB42_150:
	movq	1784(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end42:
	.size	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main, .Lfunc_end42-_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main
	.cfi_endproc
	.section	.gcc_except_table._RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main,"a",@progbits
	.p2align	2, 0x0
GCC_except_table42:
.Lexception8:
	.byte	255
	.byte	155
	.uleb128 .Lttbase4-.Lttbaseref4
.Lttbaseref4:
	.byte	1
	.uleb128 .Lcst_end8-.Lcst_begin8
.Lcst_begin8:
	.uleb128 .Lfunc_begin8-.Lfunc_begin8
	.uleb128 .Ltmp53-.Lfunc_begin8
	.byte	0
	.byte	0
	.uleb128 .Ltmp53-.Lfunc_begin8
	.uleb128 .Ltmp54-.Ltmp53
	.uleb128 .Ltmp191-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp226-.Lfunc_begin8
	.uleb128 .Ltmp227-.Ltmp226
	.uleb128 .Ltmp228-.Lfunc_begin8
	.byte	1
	.uleb128 .Ltmp220-.Lfunc_begin8
	.uleb128 .Ltmp221-.Ltmp220
	.uleb128 .Ltmp222-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp223-.Lfunc_begin8
	.uleb128 .Ltmp224-.Ltmp223
	.uleb128 .Ltmp225-.Lfunc_begin8
	.byte	5
	.uleb128 .Ltmp224-.Lfunc_begin8
	.uleb128 .Ltmp55-.Ltmp224
	.byte	0
	.byte	0
	.uleb128 .Ltmp55-.Lfunc_begin8
	.uleb128 .Ltmp56-.Ltmp55
	.uleb128 .Ltmp188-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp218-.Lfunc_begin8
	.uleb128 .Ltmp219-.Ltmp218
	.uleb128 .Ltmp228-.Lfunc_begin8
	.byte	1
	.uleb128 .Ltmp57-.Lfunc_begin8
	.uleb128 .Ltmp60-.Ltmp57
	.uleb128 .Ltmp188-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp61-.Lfunc_begin8
	.uleb128 .Ltmp62-.Ltmp61
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp216-.Lfunc_begin8
	.uleb128 .Ltmp217-.Ltmp216
	.uleb128 .Ltmp228-.Lfunc_begin8
	.byte	1
	.uleb128 .Ltmp63-.Lfunc_begin8
	.uleb128 .Ltmp78-.Ltmp63
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp213-.Lfunc_begin8
	.uleb128 .Ltmp214-.Ltmp213
	.uleb128 .Ltmp215-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp79-.Lfunc_begin8
	.uleb128 .Ltmp82-.Ltmp79
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp210-.Lfunc_begin8
	.uleb128 .Ltmp211-.Ltmp210
	.uleb128 .Ltmp212-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp83-.Lfunc_begin8
	.uleb128 .Ltmp86-.Ltmp83
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp207-.Lfunc_begin8
	.uleb128 .Ltmp208-.Ltmp207
	.uleb128 .Ltmp209-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp87-.Lfunc_begin8
	.uleb128 .Ltmp90-.Ltmp87
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp204-.Lfunc_begin8
	.uleb128 .Ltmp205-.Ltmp204
	.uleb128 .Ltmp206-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp91-.Lfunc_begin8
	.uleb128 .Ltmp94-.Ltmp91
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp201-.Lfunc_begin8
	.uleb128 .Ltmp202-.Ltmp201
	.uleb128 .Ltmp203-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp95-.Lfunc_begin8
	.uleb128 .Ltmp98-.Ltmp95
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp198-.Lfunc_begin8
	.uleb128 .Ltmp199-.Ltmp198
	.uleb128 .Ltmp200-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp99-.Lfunc_begin8
	.uleb128 .Ltmp130-.Ltmp99
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp192-.Lfunc_begin8
	.uleb128 .Ltmp193-.Ltmp192
	.uleb128 .Ltmp194-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp195-.Lfunc_begin8
	.uleb128 .Ltmp196-.Ltmp195
	.uleb128 .Ltmp197-.Lfunc_begin8
	.byte	5
	.uleb128 .Ltmp133-.Lfunc_begin8
	.uleb128 .Ltmp184-.Ltmp133
	.uleb128 .Ltmp185-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp186-.Lfunc_begin8
	.uleb128 .Ltmp187-.Ltmp186
	.uleb128 .Ltmp188-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp189-.Lfunc_begin8
	.uleb128 .Ltmp190-.Ltmp189
	.uleb128 .Ltmp191-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp190-.Lfunc_begin8
	.uleb128 .Lfunc_end42-.Ltmp190
	.byte	0
	.byte	0
.Lcst_end8:
	.byte	127
	.byte	0
	.byte	0
	.byte	0
	.byte	127
	.byte	125
	.p2align	2, 0x0
.Lttbase4:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline,"ax",@progbits
	.p2align	4
	.type	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline,@function
_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movsd	%xmm0, 8(%rsp)
	movsd	%xmm1, 24(%rsp)
	leaq	39(%rsp), %rdi
	leaq	24(%rsp), %rsi
	callq	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline0B3_
	movaps	%xmm0, %xmm1
	movsd	8(%rsp), %xmm0
	divsd	%xmm1, %xmm0
	movsd	%xmm0, 16(%rsp)
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movsd	16(%rsp), %xmm0
	movzbl	%al, %edi
	callq	_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end43:
	.size	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline, .Lfunc_end43-_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt08baseline
	.cfi_endproc

	.section	.text._RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate,"ax",@progbits
	.p2align	4
	.type	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate,@function
_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movsd	%xmm0, 8(%rsp)
	movsd	%xmm1, 40(%rsp)
	leaq	55(%rsp), %rdi
	leaq	40(%rsp), %rsi
	callq	_RNCNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate0B3_
	movsd	%xmm0, 16(%rsp)
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movabsq	$9223372036854775807, %rcx
	andq	%rcx, %rax
	cmpq	$0, %rax
	je	.LBB44_2
	movsd	16(%rsp), %xmm1
	movsd	8(%rsp), %xmm0
	divsd	%xmm1, %xmm0
	movsd	%xmm0, (%rsp)
	callq	_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movsd	(%rsp), %xmm0
	movzbl	%al, %edi
	andl	$1, %edi
	callq	_RINvMNtCs6nm8tU1dKu4_4core4boolb9then_somedECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 24(%rsp)
	movsd	%xmm0, 32(%rsp)
	jmp	.LBB44_3
.LBB44_2:
	movq	$0, 24(%rsp)
.LBB44_3:
	movq	24(%rsp), %rax
	movsd	32(%rsp), %xmm0
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end44:
	.size	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate, .Lfunc_end44-_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt09candidate
	.cfi_endproc

	.section	.text._RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 32(%rsp)
	movq	8(%rdi), %rcx
	movq	%rcx, %rax
	addq	16(%rdi), %rax
	movq	%rcx, 56(%rsp)
	movq	%rax, 64(%rsp)
	leaq	56(%rsp), %rdi
	callq	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 80(%rsp)
	movl	%edx, 84(%rsp)
	movl	80(%rsp), %eax
	testq	$1, %rax
	je	.LBB45_2
	movl	84(%rsp), %eax
	movl	%eax, 28(%rsp)
	jmp	.LBB45_4
.LBB45_2:
	movl	$-1, 52(%rsp)
	movl	$-1, 44(%rsp)
.LBB45_3:
	movl	44(%rsp), %eax
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB45_4:
	.cfi_def_cfa_offset 96
	movl	28(%rsp), %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.65(%rip), %rsi
	callq	_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	32(%rsp), %rcx
	movl	28(%rsp), %eax
	movl	%eax, 52(%rsp)
	movl	52(%rsp), %eax
	movl	%eax, 48(%rsp)
	movl	48(%rsp), %eax
	movl	%eax, 12(%rsp)
	movq	16(%rcx), %rcx
	movq	%rcx, 16(%rsp)
	cmpl	$128, %eax
	jb	.LBB45_7
	movl	12(%rsp), %eax
	cmpl	$2048, %eax
	jb	.LBB45_9
	jmp	.LBB45_8
.LBB45_7:
	movq	$1, 72(%rsp)
	jmp	.LBB45_12
.LBB45_8:
	movl	12(%rsp), %eax
	cmpl	$65536, %eax
	jb	.LBB45_11
	jmp	.LBB45_10
.LBB45_9:
	movq	$2, 72(%rsp)
	jmp	.LBB45_12
.LBB45_10:
	movq	$4, 72(%rsp)
	jmp	.LBB45_12
.LBB45_11:
	movq	$3, 72(%rsp)
.LBB45_12:
	movq	16(%rsp), %rax
	subq	72(%rsp), %rax
	movq	%rax, (%rsp)
	movq	(%rsp), %rdi
	movq	32(%rsp), %rax
	movq	(%rax), %rsi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.1(%rip), %rdx
	callq	_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	12(%rsp), %eax
	movq	32(%rsp), %rcx
	movq	(%rsp), %rdx
	movq	%rdx, 16(%rcx)
	movl	%eax, 44(%rsp)
	jmp	.LBB45_3
.Lfunc_end45:
	.size	_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end45-_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%xmm0, %rax
	retq
.Lfunc_end46:
	.size	_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end46-_RNvMNtCs6nm8tU1dKu4_4core3f64d7to_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %xmm0
	retq
.Lfunc_end47:
	.size	_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end47-_RNvMNtCs6nm8tU1dKu4_4core3f64d9from_bitsCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI48_0:
	.quad	0x7ff0000000000000
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI48_1:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text._RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movaps	.LCPI48_1(%rip), %xmm1
	pand	%xmm1, %xmm0
	movsd	%xmm0, -8(%rsp)
	movsd	.LCPI48_0(%rip), %xmm0
	ucomisd	-8(%rsp), %xmm0
	seta	%al
	andb	$1, %al
	retq
.Lfunc_end48:
	.size	_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end48-_RNvMNtCs6nm8tU1dKu4_4core3f64d9is_finiteCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$296, %rsp
	.cfi_def_cfa_offset 304
	movq	%rdx, (%rsp)
	movq	%rdi, 8(%rsp)
	movq	%rdi, 16(%rsp)
	leaq	256(%rsp), %rdi
	callq	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0
	leaq	216(%rsp), %rdi
	leaq	256(%rsp), %rsi
	movl	$40, %edx
	callq	memcpy@PLT
	movq	(%rsp), %rdx
	movq	$0, 152(%rsp)
	movq	%rdx, 160(%rsp)
	leaq	152(%rsp), %rdi
	addq	$16, %rdi
	leaq	216(%rsp), %rsi
	movl	$40, %edx
	callq	memcpy@PLT
	movb	$1, 208(%rsp)
	movb	$0, 209(%rsp)
	leaq	88(%rsp), %rdi
	leaq	152(%rsp), %rsi
	movl	$64, %edx
	callq	memcpy@PLT
	leaq	24(%rsp), %rdi
	leaq	88(%rsp), %rsi
	movl	$64, %edx
	callq	memcpy@PLT
	movq	8(%rsp), %rdi
	leaq	24(%rsp), %rsi
	movl	$64, %edx
	callq	memcpy@PLT
	movq	16(%rsp), %rax
	addq	$296, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end49:
	.size	_RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end49-_RNvMNtCs6nm8tU1dKu4_4core3stre16split_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movq	%rax, %rdx
	addq	%rsi, %rdx
	retq
.Lfunc_end50:
	.size	_RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end50-_RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movl	%edi, -8(%rsp)
	cmpl	$0, %edi
	jne	.LBB51_2
	movb	$0, -1(%rsp)
	jmp	.LBB51_3
.LBB51_2:
	movl	-8(%rsp), %eax
	cmpl	$1, %eax
	je	.LBB51_4
	jmp	.LBB51_5
.LBB51_3:
	movb	-1(%rsp), %al
	retq
.LBB51_4:
	movb	$1, -1(%rsp)
	jmp	.LBB51_3
.LBB51_5:
	movl	-8(%rsp), %eax
	cmpl	$2, %eax
	jne	.LBB51_7
	movb	$2, -1(%rsp)
	jmp	.LBB51_3
.LBB51_7:
	movl	-8(%rsp), %eax
	cmpl	$3, %eax
	jne	.LBB51_9
	movb	$3, -1(%rsp)
	jmp	.LBB51_3
.LBB51_9:
	movl	-8(%rsp), %eax
	cmpl	$4, %eax
	jne	.LBB51_11
	movb	$4, -1(%rsp)
	jmp	.LBB51_3
.LBB51_11:
	movl	-8(%rsp), %eax
	cmpl	$5, %eax
	jne	.LBB51_13
	movb	$5, -1(%rsp)
	jmp	.LBB51_3
.LBB51_13:
	movl	-8(%rsp), %eax
	cmpl	$6, %eax
	jne	.LBB51_15
	movb	$6, -1(%rsp)
	jmp	.LBB51_3
.LBB51_15:
	movl	-8(%rsp), %eax
	cmpl	$7, %eax
	jne	.LBB51_17
	movb	$7, -1(%rsp)
	jmp	.LBB51_3
.LBB51_17:
	movl	-8(%rsp), %eax
	cmpl	$8, %eax
	jne	.LBB51_19
	movb	$8, -1(%rsp)
	jmp	.LBB51_3
.LBB51_19:
	movl	-8(%rsp), %eax
	cmpl	$9, %eax
	jne	.LBB51_21
	movb	$9, -1(%rsp)
	jmp	.LBB51_3
.LBB51_21:
	movl	-8(%rsp), %eax
	cmpl	$10, %eax
	jne	.LBB51_23
	movb	$10, -1(%rsp)
	jmp	.LBB51_3
.LBB51_23:
	movl	-8(%rsp), %eax
	cmpl	$11, %eax
	jne	.LBB51_25
	movb	$11, -1(%rsp)
	jmp	.LBB51_3
.LBB51_25:
	movl	-8(%rsp), %eax
	cmpl	$12, %eax
	jne	.LBB51_27
	movb	$12, -1(%rsp)
	jmp	.LBB51_3
.LBB51_27:
	movl	-8(%rsp), %eax
	cmpl	$13, %eax
	jne	.LBB51_29
	movb	$13, -1(%rsp)
	jmp	.LBB51_3
.LBB51_29:
	movl	-8(%rsp), %eax
	cmpl	$14, %eax
	jne	.LBB51_31
	movb	$14, -1(%rsp)
	jmp	.LBB51_3
.LBB51_31:
	movl	-8(%rsp), %eax
	cmpl	$15, %eax
	jne	.LBB51_33
	movb	$15, -1(%rsp)
	jmp	.LBB51_3
.LBB51_33:
	movl	-8(%rsp), %eax
	cmpl	$16, %eax
	jne	.LBB51_35
	movb	$16, -1(%rsp)
	jmp	.LBB51_3
.LBB51_35:
	movl	-8(%rsp), %eax
	cmpl	$17, %eax
	jne	.LBB51_37
	movb	$17, -1(%rsp)
	jmp	.LBB51_3
.LBB51_37:
	movl	-8(%rsp), %eax
	cmpl	$18, %eax
	jne	.LBB51_39
	movb	$18, -1(%rsp)
	jmp	.LBB51_3
.LBB51_39:
	movl	-8(%rsp), %eax
	cmpl	$19, %eax
	jne	.LBB51_41
	movb	$19, -1(%rsp)
	jmp	.LBB51_3
.LBB51_41:
	movl	-8(%rsp), %eax
	cmpl	$20, %eax
	jne	.LBB51_43
	movb	$20, -1(%rsp)
	jmp	.LBB51_3
.LBB51_43:
	movl	-8(%rsp), %eax
	cmpl	$21, %eax
	jne	.LBB51_45
	movb	$21, -1(%rsp)
	jmp	.LBB51_3
.LBB51_45:
	movl	-8(%rsp), %eax
	cmpl	$22, %eax
	jne	.LBB51_47
	movb	$22, -1(%rsp)
	jmp	.LBB51_3
.LBB51_47:
	movl	-8(%rsp), %eax
	cmpl	$23, %eax
	jne	.LBB51_49
	movb	$23, -1(%rsp)
	jmp	.LBB51_3
.LBB51_49:
	movl	-8(%rsp), %eax
	cmpl	$24, %eax
	jne	.LBB51_51
	movb	$24, -1(%rsp)
	jmp	.LBB51_3
.LBB51_51:
	movl	-8(%rsp), %eax
	cmpl	$25, %eax
	jne	.LBB51_53
	movb	$25, -1(%rsp)
	jmp	.LBB51_3
.LBB51_53:
	movl	-8(%rsp), %eax
	cmpl	$26, %eax
	jne	.LBB51_55
	movb	$26, -1(%rsp)
	jmp	.LBB51_3
.LBB51_55:
	movl	-8(%rsp), %eax
	cmpl	$27, %eax
	jne	.LBB51_57
	movb	$27, -1(%rsp)
	jmp	.LBB51_3
.LBB51_57:
	movl	-8(%rsp), %eax
	cmpl	$28, %eax
	jne	.LBB51_59
	movb	$28, -1(%rsp)
	jmp	.LBB51_3
.LBB51_59:
	movl	-8(%rsp), %eax
	cmpl	$29, %eax
	jne	.LBB51_61
	movb	$29, -1(%rsp)
	jmp	.LBB51_3
.LBB51_61:
	movl	-8(%rsp), %eax
	cmpl	$30, %eax
	jne	.LBB51_63
	movb	$30, -1(%rsp)
	jmp	.LBB51_3
.LBB51_63:
	movl	-8(%rsp), %eax
	cmpl	$31, %eax
	jne	.LBB51_65
	movb	$31, -1(%rsp)
	jmp	.LBB51_3
.LBB51_65:
	movl	-8(%rsp), %eax
	cmpl	$32, %eax
	jne	.LBB51_67
	movb	$32, -1(%rsp)
	jmp	.LBB51_3
.LBB51_67:
	movl	-8(%rsp), %eax
	cmpl	$33, %eax
	jne	.LBB51_69
	movb	$33, -1(%rsp)
	jmp	.LBB51_3
.LBB51_69:
	movl	-8(%rsp), %eax
	cmpl	$34, %eax
	jne	.LBB51_71
	movb	$34, -1(%rsp)
	jmp	.LBB51_3
.LBB51_71:
	movl	-8(%rsp), %eax
	cmpl	$35, %eax
	jne	.LBB51_73
	movb	$35, -1(%rsp)
	jmp	.LBB51_3
.LBB51_73:
	movl	-8(%rsp), %eax
	cmpl	$40, %eax
	jne	.LBB51_75
	movb	$40, -1(%rsp)
	jmp	.LBB51_3
.LBB51_75:
	movl	-8(%rsp), %eax
	cmpl	$37, %eax
	jne	.LBB51_77
	movb	$37, -1(%rsp)
	jmp	.LBB51_3
.LBB51_77:
	movl	-8(%rsp), %eax
	cmpl	$36, %eax
	jne	.LBB51_79
	movb	$36, -1(%rsp)
	jmp	.LBB51_3
.LBB51_79:
	movl	-8(%rsp), %eax
	cmpl	$38, %eax
	jne	.LBB51_81
	movb	$38, -1(%rsp)
	jmp	.LBB51_3
.LBB51_81:
	movl	-8(%rsp), %eax
	cmpl	$39, %eax
	jne	.LBB51_83
	movb	$39, -1(%rsp)
	jmp	.LBB51_3
.LBB51_83:
	movl	-8(%rsp), %eax
	cmpl	$41, %eax
	jne	.LBB51_85
	movb	$41, -1(%rsp)
	jmp	.LBB51_3
.LBB51_85:
	movb	$-1, -1(%rsp)
	jmp	.LBB51_3
.Lfunc_end51:
	.size	_RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end51-_RNvMNtNtCs6nm8tU1dKu4_4core2io5errorNtB2_9ErrorKind9from_primCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, %rcx
	movq	%rdi, (%rsp)
	movq	%rcx, 8(%rsp)
	movq	%rcx, %rax
	shrq	%rax
	movabsq	$6148914691236517205, %rdx
	andq	%rdx, %rax
	subq	%rax, %rcx
	movabsq	$3689348814741910323, %rdx
	movq	%rcx, %rax
	andq	%rdx, %rax
	shrq	$2, %rcx
	andq	%rdx, %rcx
	addq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$4, %rcx
	addq	%rcx, %rax
	movabsq	$1085102592571150095, %rcx
	andq	%rcx, %rax
	movabsq	$72340172838076673, %rcx
	imulq	%rcx, %rax
	shrq	$56, %rax
	movl	%eax, 20(%rsp)
	cmpl	$1, 20(%rsp)
	jne	.LBB52_2
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	subq	$1, %rcx
	andq	%rcx, %rax
	cmpq	$0, %rax
	sete	%al
	andb	$1, %al
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB52_2:
	.cfi_def_cfa_offset 32
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.69(%rip), %rdi
	movl	$85, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.71(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.Lfunc_end52:
	.size	_RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end52-_RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%edi, (%rsp)
	cmpl	$32, %edi
	jne	.LBB53_2
.LBB53_1:
	movb	$1, 7(%rsp)
	jmp	.LBB53_8
.LBB53_2:
	movl	(%rsp), %ecx
	movl	$9, %eax
	cmpl	%ecx, %eax
	jbe	.LBB53_4
.LBB53_3:
	movl	(%rsp), %ecx
	xorl	%eax, %eax
	cmpl	%ecx, %eax
	jbe	.LBB53_6
	jmp	.LBB53_5
.LBB53_4:
	movl	(%rsp), %eax
	cmpl	$13, %eax
	jbe	.LBB53_1
	jmp	.LBB53_3
.LBB53_5:
	movl	(%rsp), %edi
	callq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0
	andb	$1, %al
	movb	%al, 7(%rsp)
	jmp	.LBB53_8
.LBB53_6:
	movl	(%rsp), %eax
	cmpl	$132, %eax
	ja	.LBB53_5
	movb	$0, 7(%rsp)
.LBB53_8:
	movb	7(%rsp), %al
	andb	$1, %al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end53:
	.size	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end53-_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movl	%edi, 4(%rsp)
	movl	%esi, 8(%rsp)
	cmpl	$2, %esi
	jae	.LBB54_2
.LBB54_1:
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.72(%rip), %rdi
	movl	$143, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.73(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB54_2:
	movl	8(%rsp), %eax
	cmpl	$36, %eax
	ja	.LBB54_1
	movl	4(%rsp), %eax
	cmpl	$57, %eax
	ja	.LBB54_5
.LBB54_4:
	movl	4(%rsp), %eax
	subl	$48, %eax
	movl	%eax, 20(%rsp)
	jmp	.LBB54_7
.LBB54_5:
	movl	8(%rsp), %eax
	cmpl	$10, %eax
	jbe	.LBB54_4
	movl	4(%rsp), %eax
	subl	$65, %eax
	andl	$-33, %eax
	addl	$10, %eax
	movl	%eax, 20(%rsp)
.LBB54_7:
	movl	8(%rsp), %eax
	cmpl	%eax, 20(%rsp)
	jb	.LBB54_9
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3(%rip), %ecx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3+4(%rip), %eax
	movl	%ecx, 12(%rsp)
	movl	%eax, 16(%rsp)
	jmp	.LBB54_10
.LBB54_9:
	movl	20(%rsp), %eax
	movl	%eax, 16(%rsp)
	movl	$1, 12(%rsp)
.LBB54_10:
	movl	12(%rsp), %eax
	movl	16(%rsp), %edx
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end54:
	.size	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end54-_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, (%rsp)
	testb	$1, (%rsi)
	jne	.LBB55_2
	movq	_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count18GLOBAL_PANIC_COUNT@GOTPCREL(%rip), %rdi
	xorl	%esi, %esi
	callq	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic11atomic_loadjECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movabsq	$9223372036854775807, %rcx
	andq	%rcx, %rax
	cmpq	$0, %rax
	je	.LBB55_3
	jmp	.LBB55_4
.LBB55_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB55_3:
	.cfi_def_cfa_offset 16
	jmp	.LBB55_2
.LBB55_4:
	callq	*_RNvNtNtCs82cP7IqP7wY_3std9panicking11panic_count17is_zero_slow_path@GOTPCREL(%rip)
	xorb	$-1, %al
	testb	$1, %al
	jne	.LBB55_5
	jmp	.LBB55_2
.LBB55_5:
	movq	(%rsp), %rdi
	movl	$1, %esi
	xorl	%edx, %edx
	callq	_RINvNtNtCs6nm8tU1dKu4_4core4sync6atomic12atomic_storehECs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB55_2
.Lfunc_end55:
	.size	_RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end55-_RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdx, %r8
	movq	%rsi, %rcx
	movq	%rdi, %rsi
	movq	%rsi, 24(%rsp)
	movq	%r8, 32(%rsp)
	leaq	40(%rsp), %rdi
	xorl	%edx, %edx
	callq	*_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCshr3nYqPH3YZ_5gimli@GOTPCREL(%rip)
	testq	$1, 40(%rsp)
	je	.LBB56_2
	movq	48(%rsp), %rdi
	movq	56(%rsp), %rsi
	callq	*_RNvNtCs2MEDghdBxT2_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB56_2:
	movq	32(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	movq	56(%rsp), %rcx
	movq	%rcx, 16(%rsp)
	cmpq	$0, %rax
	jne	.LBB56_4
	movq	$-1, 64(%rsp)
	jmp	.LBB56_5
.LBB56_4:
	movq	8(%rsp), %rax
	movq	%rax, 64(%rsp)
.LBB56_5:
	movq	24(%rsp), %rax
	movq	64(%rsp), %rcx
	subq	$0, %rcx
	cmpq	%rcx, %rax
	seta	%al
	xorb	$-1, %al
	movb	%al, 7(%rsp)
	movb	7(%rsp), %al
	movzbl	%al, %edi
	andl	$1, %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.75(%rip), %rsi
	callq	_RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	16(%rsp), %rdx
	movq	8(%rsp), %rax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end56:
	.size	_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end56-_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movq	%rax, (%rsp)
	callq	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end57:
	.size	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end57-_RNvMsD_NtCs6nm8tU1dKu4_4core3numy14from_str_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$216, %rsp
	.cfi_def_cfa_offset 224
	movl	%ecx, 84(%rsp)
	movq	%rdi, 88(%rsp)
	movq	%rdi, 96(%rsp)
	movq	%rsi, 104(%rsp)
	movq	%rdx, 112(%rsp)
	movl	$2, %eax
	cmpl	%ecx, %eax
	ja	.LBB58_2
	movl	84(%rsp), %eax
	cmpl	$36, %eax
	jbe	.LBB58_3
.LBB58_2:
	movl	84(%rsp), %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.78(%rip), %rsi
	callq	*_RNvNtCs6nm8tU1dKu4_4core3num22from_ascii_radix_panic@GOTPCREL(%rip)
.LBB58_3:
	movq	112(%rsp), %rax
	movq	%rax, 72(%rsp)
	cmpq	$0, %rax
	jne	.LBB58_5
	movq	88(%rsp), %rax
	movb	$0, 1(%rax)
	movb	$1, (%rax)
	jmp	.LBB58_6
.LBB58_5:
	movq	72(%rsp), %rax
	cmpq	$1, %rax
	je	.LBB58_7
	jmp	.LBB58_8
.LBB58_6:
	movq	96(%rsp), %rax
	addq	$216, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB58_7:
	.cfi_def_cfa_offset 224
	movq	104(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 71(%rsp)
	subb	$43, %al
	je	.LBB58_9
	jmp	.LBB58_36
.LBB58_36:
	movb	71(%rsp), %al
	subb	$45, %al
	je	.LBB58_9
	jmp	.LBB58_8
.LBB58_8:
	movq	72(%rsp), %rax
	cmpq	$1, %rax
	jae	.LBB58_12
	jmp	.LBB58_11
.LBB58_9:
	movq	88(%rsp), %rax
	movb	$1, 1(%rax)
	movb	$1, (%rax)
.LBB58_10:
	jmp	.LBB58_6
.LBB58_11:
	movb	$1, 215(%rsp)
	jmp	.LBB58_15
.LBB58_12:
	movq	104(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 70(%rsp)
	subb	$43, %al
	je	.LBB58_13
	jmp	.LBB58_37
.LBB58_37:
	movb	70(%rsp), %al
	subb	$45, %al
	je	.LBB58_14
	jmp	.LBB58_11
.LBB58_13:
	movq	104(%rsp), %rcx
	movq	112(%rsp), %rax
	addq	$1, %rcx
	subq	$1, %rax
	movb	$1, 215(%rsp)
	movq	%rcx, 104(%rsp)
	movq	%rax, 112(%rsp)
	jmp	.LBB58_15
.LBB58_14:
	jmp	.LBB58_11
.LBB58_15:
	movl	84(%rsp), %eax
	movq	$0, 184(%rsp)
	movq	112(%rsp), %rcx
	movq	%rcx, 56(%rsp)
	cmpl	$16, %eax
	jbe	.LBB58_17
	jmp	.LBB58_18
.LBB58_17:
	movq	56(%rsp), %rax
	cmpq	$16, %rax
	jbe	.LBB58_19
.LBB58_18:
	jmp	.LBB58_20
.LBB58_19:
	jmp	.LBB58_32
.LBB58_20:
	cmpq	$1, 112(%rsp)
	jae	.LBB58_22
.LBB58_21:
	movq	88(%rsp), %rax
	movq	184(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movb	$0, (%rax)
	jmp	.LBB58_6
.LBB58_22:
	movl	84(%rsp), %eax
	movq	104(%rsp), %rcx
	movq	%rcx, 24(%rsp)
	movq	104(%rsp), %rdx
	movq	112(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 32(%rsp)
	subq	$1, %rcx
	movq	%rcx, 40(%rsp)
	movl	%eax, %eax
	movl	%eax, %ecx
	movq	184(%rsp), %rax
	mulq	%rcx
	movq	%rax, 48(%rsp)
	seto	%al
	jo	.LBB58_24
	movl	84(%rsp), %esi
	movq	24(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 136(%rsp)
	movq	$1, 128(%rsp)
	movb	(%rax), %al
	movb	%al, 167(%rsp)
	movzbl	167(%rsp), %eax
	movl	%eax, 160(%rsp)
	movl	160(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 152(%rsp)
	movl	%edx, 156(%rsp)
	movl	152(%rsp), %eax
	movq	%rax, 168(%rsp)
	testq	$1, 168(%rsp)
	jne	.LBB58_25
	jmp	.LBB58_26
.LBB58_24:
	movl	84(%rsp), %esi
	movq	24(%rsp), %rax
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76(%rip), %rdx
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76+8(%rip), %rcx
	movq	%rdx, 128(%rsp)
	movq	%rcx, 136(%rsp)
	movb	(%rax), %al
	movb	%al, 167(%rsp)
	movzbl	167(%rsp), %eax
	movl	%eax, 160(%rsp)
	movl	160(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 152(%rsp)
	movl	%edx, 156(%rsp)
	movl	152(%rsp), %eax
	movq	%rax, 168(%rsp)
	testq	$1, 168(%rsp)
	jne	.LBB58_30
	jmp	.LBB58_26
.LBB58_25:
	movl	156(%rsp), %eax
	movl	%eax, 180(%rsp)
	movl	180(%rsp), %eax
	movq	%rax, 144(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 184(%rsp)
	movq	184(%rsp), %rcx
	movq	%rcx, %rax
	addq	144(%rsp), %rax
	cmpq	%rcx, %rax
	jb	.LBB58_28
	jmp	.LBB58_27
.LBB58_26:
	movq	88(%rsp), %rax
	movb	$1, 1(%rax)
	movb	$1, (%rax)
	jmp	.LBB58_29
.LBB58_27:
	movq	40(%rsp), %rax
	movq	32(%rsp), %rcx
	movq	184(%rsp), %rdx
	addq	144(%rsp), %rdx
	movq	%rdx, 200(%rsp)
	movq	$1, 192(%rsp)
	movq	200(%rsp), %rdx
	movq	%rdx, 184(%rsp)
	movq	%rcx, 104(%rsp)
	movq	%rax, 112(%rsp)
	jmp	.LBB58_20
.LBB58_28:
	movq	88(%rsp), %rax
	movb	$2, 1(%rax)
	movb	$1, (%rax)
.LBB58_29:
	jmp	.LBB58_31
.LBB58_30:
	movq	88(%rsp), %rax
	movl	156(%rsp), %ecx
	movl	%ecx, 180(%rsp)
	movl	180(%rsp), %ecx
	movq	%rcx, 144(%rsp)
	movb	$2, 1(%rax)
	movb	$1, (%rax)
	jmp	.LBB58_29
.LBB58_31:
	jmp	.LBB58_10
.LBB58_32:
	cmpq	$1, 112(%rsp)
	jb	.LBB58_21
	movl	84(%rsp), %esi
	movq	104(%rsp), %rax
	movq	104(%rsp), %rdx
	movq	112(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 8(%rsp)
	subq	$1, %rcx
	movq	%rcx, 16(%rsp)
	movq	184(%rsp), %rcx
	movl	%esi, %edx
	imulq	%rdx, %rcx
	movq	%rcx, 184(%rsp)
	movzbl	(%rax), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 120(%rsp)
	movl	%edx, 124(%rsp)
	movl	120(%rsp), %eax
	testq	$1, %rax
	je	.LBB58_35
	movq	16(%rsp), %rax
	movq	8(%rsp), %rcx
	movl	124(%rsp), %esi
	movq	184(%rsp), %rdx
	movl	%esi, %esi
	addq	%rsi, %rdx
	movq	%rdx, 184(%rsp)
	movq	%rcx, 104(%rsp)
	movq	%rax, 112(%rsp)
	jmp	.LBB58_32
.LBB58_35:
	movq	88(%rsp), %rax
	movb	$1, 1(%rax)
	movb	$1, (%rax)
	jmp	.LBB58_31
.Lfunc_end58:
	.size	_RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end58-_RNvMsD_NtCs6nm8tU1dKu4_4core3numy16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	16(%rdi), %rax
	retq
.Lfunc_end59:
	.size	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end59-_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE3lenCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, 8(%rsp)
	movq	%rsi, 16(%rsp)
	movq	16(%rdi), %rax
	movq	%rax, 24(%rsp)
	movq	8(%rsp), %rax
	movq	(%rax), %rax
	movq	%rax, 32(%rsp)
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
	movq	32(%rsp), %rcx
	subq	%rdx, %rcx
	cmpq	%rcx, %rax
	ja	.LBB60_4
.LBB60_3:
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB60_4:
	.cfi_def_cfa_offset 48
	movq	16(%rsp), %rdx
	movq	24(%rsp), %rsi
	movq	8(%rsp), %rdi
	movl	$8, %ecx
	movl	$16, %r8d
	callq	*_RINvNvMs2_NtCs2MEDghdBxT2_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsdiG5z4n837b_9addr2line@GOTPCREL(%rip)
	jmp	.LBB60_3
.Lfunc_end60:
	.size	_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end60-_RNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB4_3VecReE7reserveCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 40(%rsp)
	testb	$1, 57(%rdi)
	jne	.LBB61_2
	movq	40(%rsp), %rdi
	addq	$16, %rdi
	callq	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	40(%rsp), %rsi
	movq	%rax, 24(%rsp)
	movq	%rdx, 32(%rsp)
	addq	$16, %rsi
	leaq	64(%rsp), %rdi
	callq	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0
	testq	$1, 64(%rsp)
	jne	.LBB61_3
	jmp	.LBB61_4
.LBB61_2:
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76(%rip), %rcx
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76+8(%rip), %rax
	movq	%rcx, 48(%rsp)
	movq	%rax, 56(%rsp)
	jmp	.LBB61_8
.LBB61_3:
	movq	40(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, (%rsp)
	movq	80(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	movq	(%rax), %rax
	movq	%rax, 16(%rsp)
	jmp	.LBB61_6
.LBB61_4:
	movq	40(%rsp), %rdi
	callq	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
.LBB61_5:
	jmp	.LBB61_8
.LBB61_6:
	movq	32(%rsp), %rdx
	movq	(%rsp), %rsi
	movq	16(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.80(%rip), %rcx
	callq	_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	40(%rsp), %rdx
	movq	8(%rsp), %rsi
	movq	16(%rsp), %rdi
	movq	24(%rsp), %rcx
	movq	(%rsp), %rax
	subq	%rdi, %rax
	addq	%rdi, %rcx
	movq	%rsi, (%rdx)
	movq	%rcx, 48(%rsp)
	movq	%rax, 56(%rsp)
	jmp	.LBB61_5
.LBB61_8:
	movq	48(%rsp), %rax
	movq	56(%rsp), %rdx
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end61:
	.size	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end61-_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, 32(%rsp)
	testb	$1, 57(%rdi)
	jne	.LBB62_2
	movq	32(%rsp), %rax
	movb	$1, 57(%rax)
	testb	$1, 56(%rax)
	jne	.LBB62_4
	jmp	.LBB62_3
.LBB62_2:
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76(%rip), %rcx
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76+8(%rip), %rax
	movq	%rcx, 40(%rsp)
	movq	%rax, 48(%rsp)
	jmp	.LBB62_9
.LBB62_3:
	movq	32(%rsp), %rcx
	movq	8(%rcx), %rax
	subq	(%rcx), %rax
	cmpq	$0, %rax
	ja	.LBB62_6
	jmp	.LBB62_5
.LBB62_4:
	movq	32(%rsp), %rdi
	addq	$16, %rdi
	callq	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, %rcx
	movq	32(%rsp), %rax
	movq	%rcx, (%rsp)
	movq	%rdx, 8(%rsp)
	movq	(%rax), %rcx
	movq	%rcx, 16(%rsp)
	movq	8(%rax), %rax
	movq	%rax, 24(%rsp)
	jmp	.LBB62_7
.LBB62_5:
	jmp	.LBB62_2
.LBB62_6:
	jmp	.LBB62_4
.LBB62_7:
	movq	8(%rsp), %rdx
	movq	24(%rsp), %rsi
	movq	16(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.80(%rip), %rcx
	callq	_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	16(%rsp), %rdx
	movq	(%rsp), %rcx
	movq	24(%rsp), %rax
	subq	%rdx, %rax
	addq	%rdx, %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 48(%rsp)
.LBB62_9:
	movq	40(%rsp), %rax
	movq	48(%rsp), %rdx
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end62:
	.size	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end62-_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE7get_endCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$328, %rsp
	.cfi_def_cfa_offset 336
	movl	%edx, 132(%rsp)
	movq	%rdi, 136(%rsp)
	movq	%rsi, 144(%rsp)
	movl	$2, %eax
	cmpl	%edx, %eax
	ja	.LBB63_2
	movl	132(%rsp), %eax
	cmpl	$36, %eax
	jbe	.LBB63_3
.LBB63_2:
	movl	132(%rsp), %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.81(%rip), %rsi
	callq	*_RNvNtCs6nm8tU1dKu4_4core3num22from_ascii_radix_panic@GOTPCREL(%rip)
.LBB63_3:
	movq	144(%rsp), %rax
	movq	%rax, 120(%rsp)
	cmpq	$0, %rax
	jne	.LBB63_5
	movb	$0, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_6
.LBB63_5:
	movq	120(%rsp), %rax
	cmpq	$1, %rax
	je	.LBB63_7
	jmp	.LBB63_8
.LBB63_6:
	movq	152(%rsp), %rax
	addq	$328, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB63_7:
	.cfi_def_cfa_offset 336
	movq	136(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 119(%rsp)
	subb	$43, %al
	je	.LBB63_9
	jmp	.LBB63_54
.LBB63_54:
	movb	119(%rsp), %al
	subb	$45, %al
	je	.LBB63_9
	jmp	.LBB63_8
.LBB63_8:
	movq	120(%rsp), %rax
	cmpq	$1, %rax
	jae	.LBB63_12
	jmp	.LBB63_11
.LBB63_9:
	movb	$1, 153(%rsp)
	movb	$1, 152(%rsp)
.LBB63_10:
	jmp	.LBB63_6
.LBB63_11:
	movb	$1, 327(%rsp)
	jmp	.LBB63_15
.LBB63_12:
	movq	136(%rsp), %rax
	movb	(%rax), %al
	movb	%al, 118(%rsp)
	subb	$43, %al
	je	.LBB63_13
	jmp	.LBB63_55
.LBB63_55:
	movb	118(%rsp), %al
	subb	$45, %al
	je	.LBB63_14
	jmp	.LBB63_11
.LBB63_13:
	movq	136(%rsp), %rcx
	movq	144(%rsp), %rax
	addq	$1, %rcx
	subq	$1, %rax
	movb	$1, 327(%rsp)
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	jmp	.LBB63_15
.LBB63_14:
	movl	132(%rsp), %eax
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	addq	$1, %rdx
	subq	$1, %rcx
	movb	$0, 327(%rsp)
	movq	%rdx, 136(%rsp)
	movq	%rcx, 144(%rsp)
	movl	$0, 296(%rsp)
	movl	%eax, 164(%rsp)
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	movq	%rdx, 168(%rsp)
	movq	%rcx, 176(%rsp)
	cmpl	$16, %eax
	setbe	%al
	andb	$1, %al
	movb	%al, 311(%rsp)
	testb	$1, 311(%rsp)
	jne	.LBB63_17
	jmp	.LBB63_16
.LBB63_15:
	movl	132(%rsp), %eax
	movl	$0, 296(%rsp)
	movl	%eax, 164(%rsp)
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	movq	%rdx, 168(%rsp)
	movq	%rcx, 176(%rsp)
	cmpl	$16, %eax
	setbe	%al
	andb	$1, %al
	movb	%al, 311(%rsp)
	testb	$1, 311(%rsp)
	jne	.LBB63_37
	jmp	.LBB63_36
.LBB63_16:
	jmp	.LBB63_18
.LBB63_17:
	movq	176(%rsp), %rax
	movq	%rax, 312(%rsp)
	cmpq	$7, 312(%rsp)
	setbe	%al
	andb	$1, %al
	movb	%al, 163(%rsp)
	testb	$1, 163(%rsp)
	jne	.LBB63_19
.LBB63_18:
	jmp	.LBB63_20
.LBB63_19:
	jmp	.LBB63_32
.LBB63_20:
	cmpq	$1, 144(%rsp)
	jae	.LBB63_22
.LBB63_21:
	movl	296(%rsp), %eax
	movl	%eax, 156(%rsp)
	movb	$0, 152(%rsp)
	jmp	.LBB63_6
.LBB63_22:
	movl	132(%rsp), %eax
	movq	136(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 96(%rsp)
	subq	$1, %rcx
	movq	%rcx, 104(%rsp)
	imull	296(%rsp), %eax
	movl	%eax, 112(%rsp)
	seto	%al
	jo	.LBB63_24
	movl	132(%rsp), %esi
	movq	88(%rsp), %rax
	movl	112(%rsp), %ecx
	movl	%ecx, 256(%rsp)
	movl	$1, 252(%rsp)
	movb	(%rax), %al
	movb	%al, 279(%rsp)
	movzbl	279(%rsp), %eax
	movl	%eax, 272(%rsp)
	movl	272(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 264(%rsp)
	movl	%edx, 268(%rsp)
	movl	264(%rsp), %eax
	movq	%rax, 280(%rsp)
	testq	$1, 280(%rsp)
	jne	.LBB63_25
	jmp	.LBB63_26
.LBB63_24:
	movl	132(%rsp), %esi
	movq	88(%rsp), %rax
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3(%rip), %edx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3+4(%rip), %ecx
	movl	%edx, 252(%rsp)
	movl	%ecx, 256(%rsp)
	movb	(%rax), %al
	movb	%al, 279(%rsp)
	movzbl	279(%rsp), %eax
	movl	%eax, 272(%rsp)
	movl	272(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 264(%rsp)
	movl	%edx, 268(%rsp)
	movl	264(%rsp), %eax
	movq	%rax, 280(%rsp)
	testq	$1, 280(%rsp)
	jne	.LBB63_30
	jmp	.LBB63_26
.LBB63_25:
	movl	268(%rsp), %eax
	movl	%eax, 292(%rsp)
	movl	292(%rsp), %eax
	movl	%eax, 260(%rsp)
	movl	256(%rsp), %eax
	movl	%eax, 296(%rsp)
	movl	296(%rsp), %eax
	subl	260(%rsp), %eax
	movl	%eax, 84(%rsp)
	seto	%al
	jo	.LBB63_28
	jmp	.LBB63_27
.LBB63_26:
	movb	$1, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_29
.LBB63_27:
	movq	104(%rsp), %rax
	movq	96(%rsp), %rcx
	movl	84(%rsp), %edx
	movl	%edx, 304(%rsp)
	movl	$1, 300(%rsp)
	movl	304(%rsp), %edx
	movl	%edx, 296(%rsp)
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	jmp	.LBB63_20
.LBB63_28:
	movb	$3, 153(%rsp)
	movb	$1, 152(%rsp)
.LBB63_29:
	jmp	.LBB63_31
.LBB63_30:
	movl	268(%rsp), %eax
	movl	%eax, 292(%rsp)
	movl	292(%rsp), %eax
	movl	%eax, 260(%rsp)
	movb	$3, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_29
.LBB63_31:
	jmp	.LBB63_10
.LBB63_32:
	cmpq	$1, 144(%rsp)
	jb	.LBB63_21
	movl	132(%rsp), %esi
	movq	136(%rsp), %rax
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 64(%rsp)
	subq	$1, %rcx
	movq	%rcx, 72(%rsp)
	movl	%esi, %ecx
	imull	296(%rsp), %ecx
	movl	%ecx, 296(%rsp)
	movzbl	(%rax), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 196(%rsp)
	movl	%edx, 200(%rsp)
	movl	196(%rsp), %eax
	testq	$1, %rax
	je	.LBB63_35
	movq	72(%rsp), %rax
	movq	64(%rsp), %rcx
	movl	200(%rsp), %esi
	movl	296(%rsp), %edx
	subl	%esi, %edx
	movl	%edx, 296(%rsp)
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	jmp	.LBB63_32
.LBB63_35:
	movb	$1, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_31
.LBB63_36:
	jmp	.LBB63_38
.LBB63_37:
	movq	176(%rsp), %rax
	movq	%rax, 312(%rsp)
	cmpq	$7, 312(%rsp)
	setbe	%al
	andb	$1, %al
	movb	%al, 163(%rsp)
	testb	$1, 163(%rsp)
	jne	.LBB63_39
.LBB63_38:
	jmp	.LBB63_40
.LBB63_39:
	jmp	.LBB63_50
.LBB63_40:
	cmpq	$1, 144(%rsp)
	jb	.LBB63_21
	movl	132(%rsp), %eax
	movq	136(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 40(%rsp)
	subq	$1, %rcx
	movq	%rcx, 48(%rsp)
	imull	296(%rsp), %eax
	movl	%eax, 60(%rsp)
	seto	%al
	jo	.LBB63_43
	movl	132(%rsp), %esi
	movq	32(%rsp), %rax
	movl	60(%rsp), %ecx
	movl	%ecx, 208(%rsp)
	movl	$1, 204(%rsp)
	movb	(%rax), %al
	movb	%al, 231(%rsp)
	movzbl	231(%rsp), %eax
	movl	%eax, 224(%rsp)
	movl	224(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 216(%rsp)
	movl	%edx, 220(%rsp)
	movl	216(%rsp), %eax
	movq	%rax, 232(%rsp)
	testq	$1, 232(%rsp)
	jne	.LBB63_44
	jmp	.LBB63_45
.LBB63_43:
	movl	132(%rsp), %esi
	movq	32(%rsp), %rax
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3(%rip), %edx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.3+4(%rip), %ecx
	movl	%edx, 204(%rsp)
	movl	%ecx, 208(%rsp)
	movb	(%rax), %al
	movb	%al, 231(%rsp)
	movzbl	231(%rsp), %eax
	movl	%eax, 224(%rsp)
	movl	224(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 216(%rsp)
	movl	%edx, 220(%rsp)
	movl	216(%rsp), %eax
	movq	%rax, 232(%rsp)
	testq	$1, 232(%rsp)
	jne	.LBB63_49
	jmp	.LBB63_45
.LBB63_44:
	movl	220(%rsp), %eax
	movl	%eax, 240(%rsp)
	movl	240(%rsp), %eax
	movl	%eax, 212(%rsp)
	movl	208(%rsp), %eax
	movl	%eax, 296(%rsp)
	movl	296(%rsp), %eax
	addl	212(%rsp), %eax
	movl	%eax, 28(%rsp)
	seto	%al
	jo	.LBB63_47
	jmp	.LBB63_46
.LBB63_45:
	movb	$1, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_48
.LBB63_46:
	movq	48(%rsp), %rax
	movq	40(%rsp), %rcx
	movl	28(%rsp), %edx
	movl	%edx, 248(%rsp)
	movl	$1, 244(%rsp)
	movl	248(%rsp), %edx
	movl	%edx, 296(%rsp)
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	jmp	.LBB63_40
.LBB63_47:
	movb	$2, 153(%rsp)
	movb	$1, 152(%rsp)
.LBB63_48:
	jmp	.LBB63_31
.LBB63_49:
	movl	220(%rsp), %eax
	movl	%eax, 240(%rsp)
	movl	240(%rsp), %eax
	movl	%eax, 212(%rsp)
	movb	$2, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_48
.LBB63_50:
	cmpq	$1, 144(%rsp)
	jb	.LBB63_21
	movl	132(%rsp), %esi
	movq	136(%rsp), %rax
	movq	136(%rsp), %rdx
	movq	144(%rsp), %rcx
	addq	$1, %rdx
	movq	%rdx, 8(%rsp)
	subq	$1, %rcx
	movq	%rcx, 16(%rsp)
	movl	%esi, %ecx
	imull	296(%rsp), %ecx
	movl	%ecx, 296(%rsp)
	movzbl	(%rax), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc8to_digitCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 188(%rsp)
	movl	%edx, 192(%rsp)
	movl	188(%rsp), %eax
	testq	$1, %rax
	je	.LBB63_53
	movq	16(%rsp), %rax
	movq	8(%rsp), %rcx
	movl	192(%rsp), %edx
	addl	296(%rsp), %edx
	movl	%edx, 296(%rsp)
	movq	%rcx, 136(%rsp)
	movq	%rax, 144(%rsp)
	jmp	.LBB63_50
.LBB63_53:
	movb	$1, 153(%rsp)
	movb	$1, 152(%rsp)
	jmp	.LBB63_31
.Lfunc_end63:
	.size	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end63-_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNtCs6nm8tU1dKu4_4core10intrinsics9cold_pathCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs6nm8tU1dKu4_4core10intrinsics9cold_pathCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNtCs6nm8tU1dKu4_4core10intrinsics9cold_pathCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	retq
.Lfunc_end64:
	.size	_RNvNtCs6nm8tU1dKu4_4core10intrinsics9cold_pathCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end64-_RNvNtCs6nm8tU1dKu4_4core10intrinsics9cold_pathCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movl	%edi, 12(%rsp)
	movq	%rsi, 16(%rsp)
	movq	%rdx, 24(%rsp)
	cmpl	$128, %edi
	jb	.LBB65_2
	movl	12(%rsp), %eax
	cmpl	$2048, %eax
	jb	.LBB65_4
	jmp	.LBB65_3
.LBB65_2:
	movq	$1, 32(%rsp)
	jmp	.LBB65_7
.LBB65_3:
	movl	12(%rsp), %eax
	cmpl	$65536, %eax
	jb	.LBB65_6
	jmp	.LBB65_5
.LBB65_4:
	movq	$2, 32(%rsp)
	jmp	.LBB65_7
.LBB65_5:
	movq	$4, 32(%rsp)
	jmp	.LBB65_7
.LBB65_6:
	movq	$3, 32(%rsp)
.LBB65_7:
	movq	24(%rsp), %rax
	cmpq	32(%rsp), %rax
	jb	.LBB65_9
	movq	16(%rsp), %rsi
	movl	12(%rsp), %edi
	callq	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB65_10
.LBB65_9:
	movq	24(%rsp), %rdx
	movl	12(%rsp), %edi
	movq	32(%rsp), %rsi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.83(%rip), %rcx
	callq	_RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0
.LBB65_10:
	movq	16(%rsp), %rdi
	movq	32(%rsp), %rcx
	movl	$1, %edx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.82(%rip), %r8
	movq	%rdx, %rsi
	callq	_RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	16(%rsp), %rax
	movq	32(%rsp), %rdx
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end65:
	.size	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end65-_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movl	%edi, -20(%rsp)
	movq	%rsi, -16(%rsp)
	cmpl	$128, %edi
	jb	.LBB66_2
	movl	-20(%rsp), %eax
	cmpl	$2048, %eax
	jb	.LBB66_4
	jmp	.LBB66_3
.LBB66_2:
	movq	-16(%rsp), %rax
	movl	-20(%rsp), %ecx
	movq	$1, -8(%rsp)
	movb	%cl, (%rax)
	jmp	.LBB66_13
.LBB66_3:
	movl	-20(%rsp), %eax
	cmpl	$65536, %eax
	jb	.LBB66_6
	jmp	.LBB66_5
.LBB66_4:
	movq	$2, -8(%rsp)
	jmp	.LBB66_7
.LBB66_5:
	movq	$4, -8(%rsp)
	jmp	.LBB66_7
.LBB66_6:
	movq	$3, -8(%rsp)
.LBB66_7:
	movl	-20(%rsp), %eax
	movl	%eax, %ecx
	andl	$63, %ecx
	orb	$-128, %cl
	movb	%cl, -24(%rsp)
	movl	%eax, %ecx
	shrl	$6, %ecx
	andl	$63, %ecx
	orb	$-128, %cl
	movb	%cl, -23(%rsp)
	movl	%eax, %ecx
	shrl	$12, %ecx
	andl	$63, %ecx
	orb	$-128, %cl
	movb	%cl, -22(%rsp)
	shrl	$18, %eax
	andl	$63, %eax
	orb	$-16, %al
	movb	%al, -21(%rsp)
	cmpq	$2, -8(%rsp)
	jne	.LBB66_9
	movq	-16(%rsp), %rax
	movb	-24(%rsp), %cl
	movb	-23(%rsp), %dl
	orb	$-64, %dl
	movb	%dl, (%rax)
	movb	%cl, 1(%rax)
	jmp	.LBB66_10
.LBB66_9:
	cmpq	$3, -8(%rsp)
	je	.LBB66_11
	jmp	.LBB66_12
.LBB66_10:
	jmp	.LBB66_13
.LBB66_11:
	movq	-16(%rsp), %rax
	movb	-24(%rsp), %cl
	movb	-23(%rsp), %dl
	movb	-22(%rsp), %sil
	orb	$-32, %sil
	movb	%sil, (%rax)
	movb	%dl, 1(%rax)
	movb	%cl, 2(%rax)
	jmp	.LBB66_10
.LBB66_12:
	movq	-16(%rsp), %rax
	movb	-24(%rsp), %cl
	movb	-23(%rsp), %dl
	movb	-22(%rsp), %sil
	movb	-21(%rsp), %dil
	movb	%dil, (%rax)
	movb	%sil, 1(%rax)
	movb	%dl, 2(%rax)
	movb	%cl, 3(%rax)
	jmp	.LBB66_14
.LBB66_13:
	jmp	.LBB66_14
.LBB66_14:
	retq
.Lfunc_end66:
	.size	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end66-_RNvNtNtCs6nm8tU1dKu4_4core4char7methods25encode_utf8_raw_uncheckedCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movl	%edi, 28(%rsp)
	shrl	$8, %edi
	movl	%edi, 32(%rsp)
	testl	%edi, %edi
	je	.LBB67_2
	jmp	.LBB67_11
.LBB67_11:
	movl	32(%rsp), %eax
	subl	$22, %eax
	je	.LBB67_3
	jmp	.LBB67_12
.LBB67_12:
	movl	32(%rsp), %eax
	subl	$32, %eax
	je	.LBB67_4
	jmp	.LBB67_13
.LBB67_13:
	movl	32(%rsp), %eax
	subl	$48, %eax
	je	.LBB67_5
	jmp	.LBB67_1
.LBB67_1:
	movb	$0, 39(%rsp)
	jmp	.LBB67_8
.LBB67_2:
	movl	28(%rsp), %eax
	movl	%eax, %eax
	andq	$255, %rax
	movq	%rax, 16(%rsp)
	cmpq	$256, %rax
	jb	.LBB67_6
	jmp	.LBB67_7
.LBB67_3:
	movl	28(%rsp), %eax
	cmpl	$5760, %eax
	sete	%al
	andb	$1, %al
	movb	%al, 39(%rsp)
	jmp	.LBB67_8
.LBB67_4:
	movl	28(%rsp), %eax
	movl	%eax, %eax
	andq	$255, %rax
	movq	%rax, 8(%rsp)
	cmpq	$256, %rax
	jb	.LBB67_9
	jmp	.LBB67_10
.LBB67_5:
	movl	28(%rsp), %eax
	cmpl	$12288, %eax
	sete	%al
	andb	$1, %al
	movb	%al, 39(%rsp)
	jmp	.LBB67_8
.LBB67_6:
	movq	16(%rsp), %rcx
	movq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space14WHITESPACE_MAP@GOTPCREL(%rip), %rax
	movb	(%rax,%rcx), %al
	andb	$1, %al
	cmpb	$0, %al
	setne	%al
	andb	$1, %al
	movb	%al, 39(%rsp)
	jmp	.LBB67_8
.LBB67_7:
	movq	16(%rsp), %rdi
	movl	$256, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.85(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB67_8:
	movb	39(%rsp), %al
	andb	$1, %al
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB67_9:
	.cfi_def_cfa_offset 48
	movq	8(%rsp), %rcx
	movq	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space14WHITESPACE_MAP@GOTPCREL(%rip), %rax
	movb	(%rax,%rcx), %al
	andb	$2, %al
	cmpb	$0, %al
	setne	%al
	andb	$1, %al
	movb	%al, 39(%rsp)
	jmp	.LBB67_8
.LBB67_10:
	movq	8(%rsp), %rdi
	movl	$256, %esi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.86(%rip), %rdx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end67:
	.size	_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end67-_RNvNtNtNtCs6nm8tU1dKu4_4core7unicode12unicode_data11white_space6lookupCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rcx
	movq	%rsi, 8(%rsp)
	movq	%rcx, %rax
	shrq	%rax
	movabsq	$6148914691236517205, %rdx
	andq	%rdx, %rax
	subq	%rax, %rcx
	movabsq	$3689348814741910323, %rdx
	movq	%rcx, %rax
	andq	%rdx, %rax
	shrq	$2, %rcx
	andq	%rdx, %rcx
	addq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$4, %rcx
	addq	%rcx, %rax
	movabsq	$1085102592571150095, %rcx
	andq	%rcx, %rax
	movabsq	$72340172838076673, %rcx
	imulq	%rcx, %rax
	shrq	$56, %rax
	movl	%eax, 20(%rsp)
	cmpl	$1, 20(%rsp)
	jne	.LBB68_2
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB68_2:
	.cfi_def_cfa_offset 32
	movq	8(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.87(%rip), %rdi
	movl	$397, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.Lfunc_end68:
	.size	_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end68-_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdx, (%rsp)
	cmpq	%rsi, %rdi
	jae	.LBB69_2
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.88(%rip), %rdi
	movl	$403, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB69_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end69:
	.size	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end69-_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdx, (%rsp)
	movabsq	$-9223372036854775808, %rax
	subq	%rsi, %rax
	cmpq	%rax, %rdi
	jbe	.LBB70_2
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.89(%rip), %rdi
	movl	$519, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB70_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end70:
	.size	_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end70-_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, (%rsp)
	cmpq	$0, %rdi
	jne	.LBB71_2
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.90(%rip), %rdi
	movl	$421, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB71_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end71:
	.size	_RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end71-_RNvNvMs1_NtNtCs6nm8tU1dKu4_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, (%rsp)
	movabsq	$-9223372036854775808, %rax
	cmpq	%rax, %rdi
	jne	.LBB72_2
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.91(%rip), %rdi
	movl	$373, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB72_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end72:
	.size	_RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end72-_RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdx, (%rsp)
	cmpq	%rsi, %rdi
	jbe	.LBB73_2
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.92(%rip), %rdi
	movl	$397, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB73_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end73:
	.size	_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end73-_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, (%rsp)
	movb	%dil, %al
	testb	$1, %al
	jne	.LBB74_2
	jmp	.LBB74_1
.LBB74_1:
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.93(%rip), %rdi
	movl	$443, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB74_2:
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end74:
	.size	_RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end74-_RNvNvNtCs6nm8tU1dKu4_4core4hint16assert_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.94(%rip), %rdi
	movl	$399, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.Lfunc_end75:
	.size	_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end75-_RNvNvNtCs6nm8tU1dKu4_4core4hint21unreachable_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%edi, %eax
	movq	%rsi, (%rsp)
	xorl	$55296, %eax
	subl	$2048, %eax
	cmpl	$1112064, %eax
	jae	.LBB76_2
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB76_2:
	.cfi_def_cfa_offset 16
	movq	(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.95(%rip), %rdi
	movl	$349, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.Lfunc_end76:
	.size	_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end76-_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin9:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception9
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdx, (%rsp)
	movq	%rsi, %rax
	movq	(%rsp), %rsi
	movq	%rdi, 8(%rsp)
	movq	%rax, 16(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%r8, 32(%rsp)
.Ltmp229:
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPu13is_aligned_toCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp230:
	movb	%al, 47(%rsp)
	jmp	.LBB77_2
.LBB77_1:
.Ltmp231:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking19panic_cannot_unwind@GOTPCREL(%rip)
.LBB77_2:
	movb	47(%rsp), %al
	testb	$1, %al
	jne	.LBB77_4
	jmp	.LBB77_3
.LBB77_3:
	jmp	.LBB77_5
.LBB77_4:
	movq	8(%rsp), %rax
	cmpq	$0, %rax
	sete	%al
	xorb	$-1, %al
	testb	$1, %al
	jne	.LBB77_6
.LBB77_5:
	jmp	.LBB77_7
.LBB77_6:
	movq	16(%rsp), %rax
	cmpq	$0, %rax
	je	.LBB77_8
	jmp	.LBB77_9
.LBB77_7:
	movq	32(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.96(%rip), %rdi
	movl	$567, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB77_8:
	movq	$-1, 48(%rsp)
	jmp	.LBB77_10
.LBB77_9:
	movq	16(%rsp), %rcx
	movabsq	$9223372036854775807, %rax
	xorl	%edx, %edx
	divq	%rcx
	movq	%rax, 48(%rsp)
.LBB77_10:
	movq	24(%rsp), %rax
	cmpq	48(%rsp), %rax
	jbe	.LBB77_12
	jmp	.LBB77_7
.LBB77_12:
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end77:
	.size	_RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end77-_RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNvNvNtNtCs6nm8tU1dKu4_4core5slice3raw18from_raw_parts_mut18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table77:
.Lexception9:
	.byte	255
	.byte	155
	.uleb128 .Lttbase5-.Lttbaseref5
.Lttbaseref5:
	.byte	1
	.uleb128 .Lcst_end9-.Lcst_begin9
.Lcst_begin9:
	.uleb128 .Ltmp229-.Lfunc_begin9
	.uleb128 .Ltmp230-.Ltmp229
	.uleb128 .Ltmp231-.Lfunc_begin9
	.byte	1
.Lcst_end9:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase5:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$184, %rsp
	.cfi_def_cfa_offset 192
	movq	%rcx, 8(%rsp)
	movq	%rdx, %rax
	movq	8(%rsp), %rdx
	movl	%edi, 20(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%rax, 32(%rsp)
	leaq	24(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	_RNvXsi_NtNtNtCs6nm8tU1dKu4_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 144(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 96(%rsp)
	leaq	20(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	_RNvXsw_NtNtCs6nm8tU1dKu4_4core3fmt3nummNtB7_8UpperHex3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 160(%rsp)
	movq	152(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 112(%rsp)
	leaq	32(%rsp), %rax
	movq	%rax, 168(%rsp)
	movq	_RNvXsi_NtNtNtCs6nm8tU1dKu4_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 176(%rsp)
	movq	168(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	176(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	88(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	120(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	128(%rsp), %rax
	movq	%rax, 80(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.97(%rip), %rdi
	leaq	40(%rsp), %rsi
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking9panic_fmt@GOTPCREL(%rip)
.Lfunc_end78:
	.size	_RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end78-_RNvNvNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_raw8do_panic7runtimeCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, (%rsp)
	movq	%rdx, 8(%rsp)
	movq	%rcx, 16(%rsp)
	cmpq	%rdi, %rsi
	jae	.LBB79_2
.LBB79_1:
	movq	16(%rsp), %rcx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.98(%rip), %rdi
	movl	$439, %esi
	xorl	%edx, %edx
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_nounwind_fmt@GOTPCREL(%rip)
.LBB79_2:
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	cmpq	%rcx, %rax
	ja	.LBB79_1
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end79:
	.size	_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end79-_RNvNvXs5_NtNtCs6nm8tU1dKu4_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RINvMsj_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecReE16extend_desugaredNtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end80:
	.size	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end80-_RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movq	%rax, (%rsp)
	callq	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end81:
	.size	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end81-_RNvXNtNtCs2MEDghdBxT2_5alloc3vec14spec_from_iterINtB4_3VecReEINtB2_12SpecFromIterBU_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin10:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception10
	subq	$280, %rsp
	.cfi_def_cfa_offset 288
	movq	%rsi, 40(%rsp)
	movq	%rdi, %rax
	movq	40(%rsp), %rdi
	movq	%rax, 48(%rsp)
	movq	%rax, 56(%rsp)
	movb	$1, 247(%rsp)
.Ltmp232:
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp233:
	movq	%rdx, 64(%rsp)
	movq	%rax, 72(%rsp)
	jmp	.LBB82_3
.LBB82_1:
	testb	$1, 247(%rsp)
	jne	.LBB82_21
	jmp	.LBB82_20
.LBB82_2:
.Ltmp234:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 256(%rsp)
	movl	%eax, 264(%rsp)
	jmp	.LBB82_1
.LBB82_3:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rax, 120(%rsp)
	movq	112(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB82_5
	movq	40(%rsp), %rsi
	movq	112(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	120(%rsp), %rax
	movq	%rax, 32(%rsp)
.Ltmp235:
	leaq	128(%rsp), %rdi
	callq	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp236:
	jmp	.LBB82_9
.LBB82_5:
	movq	48(%rsp), %rax
	movq	$0, (%rax)
	movl	$8, %ecx
	movq	%rcx, 8(%rax)
	movq	$0, 16(%rax)
.LBB82_6:
	movq	56(%rsp), %rax
	addq	$280, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB82_7:
	.cfi_def_cfa_offset 288
	jmp	.LBB82_1
.LBB82_8:
.Ltmp241:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 256(%rsp)
	movl	%eax, 264(%rsp)
	jmp	.LBB82_7
.LBB82_9:
	movq	128(%rsp), %rax
	incq	%rax
	movq	$-1, %rcx
	cmoveq	%rcx, %rax
	movq	%rax, 272(%rsp)
	movq	272(%rsp), %rsi
.Ltmp237:
	movl	$4, %edi
	callq	_RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp238:
	movq	%rax, 16(%rsp)
	jmp	.LBB82_10
.LBB82_10:
.Ltmp239:
	movq	16(%rsp), %rdi
	movl	$8, %esi
	movl	$16, %edx
	callq	_RNvMs4_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp240:
	movq	%rdx, (%rsp)
	movq	%rax, 8(%rsp)
	jmp	.LBB82_11
.LBB82_11:
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movq	(%rsp), %rax
	movq	8(%rsp), %rsi
	movq	%rsi, 152(%rsp)
	movq	%rax, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	160(%rsp), %rax
	movq	%rdx, (%rax)
	movq	%rcx, 8(%rax)
	jmp	.LBB82_13
.LBB82_13:
	movq	152(%rsp), %rax
	movq	%rax, 248(%rsp)
	movq	248(%rsp), %rsi
	movl	$1, %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.1(%rip), %rdx
	callq	_RNvNvMs_NtCs2MEDghdBxT2_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	40(%rsp), %rax
	movq	$1, 168(%rsp)
	movq	168(%rsp), %rcx
	movq	%rcx, 96(%rsp)
	movups	152(%rsp), %xmm0
	movaps	%xmm0, 80(%rsp)
	movb	$0, 247(%rsp)
	movups	(%rax), %xmm0
	movups	16(%rax), %xmm1
	movups	32(%rax), %xmm2
	movups	48(%rax), %xmm3
	movaps	%xmm3, 224(%rsp)
	movaps	%xmm2, 208(%rsp)
	movaps	%xmm1, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
.Ltmp242:
	leaq	80(%rsp), %rdi
	leaq	176(%rsp), %rsi
	callq	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec11spec_extendINtB4_3VecReEINtB2_10SpecExtendBR_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE11spec_extendCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp243:
	jmp	.LBB82_18
.LBB82_16:
.Ltmp245:
	leaq	80(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtCs2MEDghdBxT2_5alloc3vec3VecReEECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp246:
	jmp	.LBB82_1
.LBB82_17:
.Ltmp244:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 256(%rsp)
	movl	%eax, 264(%rsp)
	jmp	.LBB82_16
.LBB82_18:
	movq	48(%rsp), %rax
	movq	80(%rsp), %rcx
	movq	%rcx, (%rax)
	movq	88(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movq	96(%rsp), %rcx
	movq	%rcx, 16(%rax)
	jmp	.LBB82_6
.LBB82_19:
.Ltmp247:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB82_20:
	movq	256(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB82_21:
	jmp	.LBB82_20
.Lfunc_end82:
	.size	_RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end82-_RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNvXNtNtCs2MEDghdBxT2_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB11_NtNtNtCs6nm8tU1dKu4_4core3str4iter15SplitWhitespaceE9from_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table82:
.Lexception10:
	.byte	255
	.byte	155
	.uleb128 .Lttbase6-.Lttbaseref6
.Lttbaseref6:
	.byte	1
	.uleb128 .Lcst_end10-.Lcst_begin10
.Lcst_begin10:
	.uleb128 .Ltmp232-.Lfunc_begin10
	.uleb128 .Ltmp233-.Ltmp232
	.uleb128 .Ltmp234-.Lfunc_begin10
	.byte	0
	.uleb128 .Ltmp235-.Lfunc_begin10
	.uleb128 .Ltmp240-.Ltmp235
	.uleb128 .Ltmp241-.Lfunc_begin10
	.byte	0
	.uleb128 .Ltmp242-.Lfunc_begin10
	.uleb128 .Ltmp243-.Ltmp242
	.uleb128 .Ltmp244-.Lfunc_begin10
	.byte	0
	.uleb128 .Ltmp245-.Lfunc_begin10
	.uleb128 .Ltmp246-.Ltmp245
	.uleb128 .Ltmp247-.Lfunc_begin10
	.byte	1
	.uleb128 .Ltmp246-.Lfunc_begin10
	.uleb128 .Lfunc_end82-.Ltmp246
	.byte	0
	.byte	0
.Lcst_end10:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase6:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	xorl	%eax, %eax
	retq
.Lfunc_end83:
	.size	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end83-_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try11from_outputCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, -32(%rsp)
	movq	%rsi, -24(%rsp)
	movq	-32(%rsp), %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpq	$0, %rdx
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB84_2
	movq	-32(%rsp), %rcx
	movq	-24(%rsp), %rax
	movq	%rcx, -16(%rsp)
	movq	%rax, -8(%rsp)
	jmp	.LBB84_3
.LBB84_2:
	movq	$0, -16(%rsp)
.LBB84_3:
	movq	-16(%rsp), %rax
	movq	-8(%rsp), %rdx
	retq
.Lfunc_end84:
	.size	_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end84-_RNvXNtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB2_11ControlFlowReENtNtB4_9try_trait3Try6branchCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movb	%sil, %dl
	retq
.Lfunc_end85:
	.size	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end85-_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectINtNtCs82cP7IqP7wY_3std2io5LinesNtNtBO_5stdio9StdinLockENtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movq	%rax, (%rsp)
	movl	$64, %edx
	callq	memcpy@PLT
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end86:
	.size	_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end86-_RNvXNtNtNtCs6nm8tU1dKu4_4core4iter6traits7collectNtNtNtB8_3str4iter15SplitWhitespaceNtB2_12IntoIterator9into_iterCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, 8(%rsp)
	movq	%rsi, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%rcx, 32(%rsp)
	cmpq	%rdx, %rdi
	jae	.LBB87_2
	movq	16(%rsp), %rax
	movq	8(%rsp), %rcx
	shlq	$4, %rcx
	addq	%rcx, %rax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB87_2:
	.cfi_def_cfa_offset 48
	movq	32(%rsp), %rdx
	movq	24(%rsp), %rsi
	movq	8(%rsp), %rdi
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end87:
	.size	_RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end87-_RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	$8, %esi
	movl	$16, %edx
	callq	*_RNvMs2_NtCs2MEDghdBxT2_5alloc7raw_vecNtB5_11RawVecInner10deallocateCshr3nYqPH3YZ_5gimli@GOTPCREL(%rip)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end88:
	.size	_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end88-_RNvXs1_NtCs2MEDghdBxT2_5alloc7raw_vecINtB5_6RawVecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, (%rsp)
	movq	(%rdi), %rdi
	movq	(%rsp), %rsi
	callq	_RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
	andb	$1, %al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end89:
	.size	_RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end89-_RNvXs1_NtNtNtCs6nm8tU1dKu4_4core3ops8function5implsQNtNtBb_3str10IsNotEmptyINtB7_5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rdi), %rsi
	leaq	8(%rsp), %rdi
	callq	_RINvNtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpacked11decode_reprINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtB4_6CustomENCNvXs1_B2_NtB2_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4drop0ECs46bV0WIEyDX_22cayley_zero_guard_opt0
	leaq	8(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueINtNtNtCs82cP7IqP7wY_3std2io5error9ErrorDataINtNtCs2MEDghdBxT2_5alloc5boxed3BoxNtBE_6CustomEEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end90:
	.size	_RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end90-_RNvXs1_NtNtNtCs82cP7IqP7wY_3std2io5error14repr_bitpackedNtB5_4ReprNtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, -32(%rsp)
	movq	(%rdi), %rax
	movq	%rax, -24(%rsp)
	movq	8(%rdi), %rax
	movq	%rax, -16(%rsp)
	movq	-24(%rsp), %rax
	movq	-16(%rsp), %rcx
	cmpq	%rcx, %rax
	je	.LBB91_3
	movq	-32(%rsp), %rax
	movq	-24(%rsp), %rcx
	addq	$1, %rcx
	movq	%rcx, (%rax)
	jmp	.LBB91_4
.LBB91_3:
	movq	$0, -8(%rsp)
	jmp	.LBB91_6
.LBB91_4:
	movq	-24(%rsp), %rax
	movq	%rax, -8(%rsp)
.LBB91_5:
	movq	-8(%rsp), %rax
	retq
.LBB91_6:
	jmp	.LBB91_5
.Lfunc_end91:
	.size	_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end91-_RNvXs2J_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, 16(%rsp)
	movq	16(%rsp), %rax
	movq	8(%rax), %rcx
	cmpq	%rcx, (%rax)
	sete	%al
	andb	$1, %al
	movb	%al, 39(%rsp)
	testb	$1, 39(%rsp)
	jne	.LBB92_4
	jmp	.LBB92_5
.LBB92_4:
	movq	$0, 24(%rsp)
	jmp	.LBB92_11
.LBB92_5:
	movq	16(%rsp), %rax
	movq	%rax, %rcx
	addq	$8, %rcx
	movq	%rcx, 8(%rsp)
	movq	8(%rax), %rax
	movq	%rax, 48(%rsp)
	jmp	.LBB92_7
.LBB92_7:
	movl	$1, %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.102(%rip), %rsi
	callq	_RNvNvMs3_NtCs6nm8tU1dKu4_4core3numi13unchecked_neg18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	48(%rsp), %rax
	addq	$-1, %rax
	movq	%rax, 48(%rsp)
	movq	8(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, (%rax)
	movq	(%rax), %rax
	movq	%rax, 40(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 24(%rsp)
.LBB92_11:
	movq	24(%rsp), %rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end92:
	.size	_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end92-_RNvXs2K_NtNtCs6nm8tU1dKu4_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$120, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %rax
	movq	%rax, 56(%rsp)
	movq	8(%rax), %rdi
	movq	%rdi, 40(%rsp)
	movq	(%rax), %rsi
	movq	%rsi, 48(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.100(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	56(%rsp), %rdi
	subq	%rcx, %rax
	movq	%rax, 112(%rsp)
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	callq	_RINvNtNtCs6nm8tU1dKu4_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs46bV0WIEyDX_22cayley_zero_guard_opt0
	movl	%eax, 96(%rsp)
	movl	%edx, 100(%rsp)
	movl	96(%rsp), %eax
	testq	$1, %rax
	je	.LBB93_2
	movl	100(%rsp), %eax
	movl	%eax, 36(%rsp)
	jmp	.LBB93_4
.LBB93_2:
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.103(%rip), %rcx
	movl	.Lanon.f31448597b1a273a87802a75e10efe0f.103+8(%rip), %eax
	movq	%rcx, 72(%rsp)
	movl	%eax, 80(%rsp)
.LBB93_3:
	movq	72(%rsp), %rax
	movl	80(%rsp), %edx
	addq	$120, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB93_4:
	.cfi_def_cfa_offset 128
	movl	36(%rsp), %edi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.65(%rip), %rsi
	callq	_RNvNvNtNtCs6nm8tU1dKu4_4core4char7convert18from_u32_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	56(%rsp), %rax
	movl	36(%rsp), %ecx
	movl	%ecx, 92(%rsp)
	movl	92(%rsp), %ecx
	movl	%ecx, 32(%rsp)
	movq	16(%rax), %rcx
	movq	%rcx, 24(%rsp)
	movq	8(%rax), %rdi
	movq	%rdi, 8(%rsp)
	movq	(%rax), %rsi
	movq	%rsi, 16(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.100(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	8(%rsp), %rdi
	movq	16(%rsp), %r8
	movq	64(%rsp), %rsi
	movq	56(%rsp), %rdx
	movq	24(%rsp), %rcx
	movl	32(%rsp), %eax
	subq	%r8, %rdi
	movq	%rdi, 104(%rsp)
	subq	104(%rsp), %rsi
	addq	16(%rdx), %rsi
	movq	%rsi, 16(%rdx)
	movq	%rcx, 72(%rsp)
	movl	%eax, 80(%rsp)
	jmp	.LBB93_3
.Lfunc_end93:
	.size	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end93-_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
	andb	$1, %al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end94:
	.size	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end94-_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rax
	movq	%rdi, %rcx
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movq	(%rax), %rdx
	movq	8(%rax), %rcx
	callq	_RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
	andb	$1, %al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end95:
	.size	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end95-_RNvXs7_NtNtCs6nm8tU1dKu4_4core3cmp5implsReNtB7_9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin11:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception11
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdx, (%rsp)
	movq	%rsi, %rax
	movq	(%rsp), %rsi
	movq	%rax, 8(%rsp)
	movq	%rdi, %rax
	movq	8(%rsp), %rdi
	movq	%rax, 16(%rsp)
	movq	%rax, 24(%rsp)
.Ltmp248:
	callq	_RNvMNtCs6nm8tU1dKu4_4core3stre5charsCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp249:
	movq	%rdx, 32(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.LBB96_3
.LBB96_1:
	movq	72(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB96_2:
.Ltmp250:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 72(%rsp)
	movl	%eax, 80(%rsp)
	jmp	.LBB96_1
.LBB96_3:
	movq	24(%rsp), %rax
	movq	16(%rsp), %rcx
	movq	(%rsp), %rdx
	movq	8(%rsp), %rsi
	movq	32(%rsp), %rdi
	movq	40(%rsp), %r8
	movq	$0, 64(%rsp)
	movq	%r8, 48(%rsp)
	movq	%rdi, 56(%rsp)
	movq	%rsi, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	48(%rsp), %rdx
	movq	%rdx, 16(%rcx)
	movq	56(%rsp), %rdx
	movq	%rdx, 24(%rcx)
	movq	64(%rsp), %rdx
	movq	%rdx, 32(%rcx)
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end96:
	.size	_RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end96-_RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNvXs7_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_18MultiCharEqPatternNtB7_12IsWhitespaceENtB5_7Pattern13into_searcherCs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table96:
.Lexception11:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end11-.Lcst_begin11
.Lcst_begin11:
	.uleb128 .Ltmp248-.Lfunc_begin11
	.uleb128 .Ltmp249-.Ltmp248
	.uleb128 .Ltmp250-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp249-.Lfunc_begin11
	.uleb128 .Lfunc_end96-.Ltmp249
	.byte	0
	.byte	0
.Lcst_end11:
	.p2align	2, 0x0

	.section	.text._RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, 8(%rsp)
	movq	(%rdi), %rax
	movq	%rax, 16(%rsp)
	movq	8(%rdi), %rax
	movq	8(%rax), %rcx
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rcx
	movq	%rcx, 24(%rsp)
	movq	16(%rax), %rax
	movq	%rax, 48(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.105(%rip), %rsi
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB97_3
.LBB97_3:
	movq	32(%rsp), %rsi
	movq	24(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.107(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	24(%rsp), %rax
	cmpq	$0, %rax
	jne	.LBB97_6
.LBB97_5:
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB97_6:
	.cfi_def_cfa_offset 64
	movq	24(%rsp), %rcx
	movq	32(%rsp), %rdx
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	addq	$16, %rdi
	callq	_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB97_5
.Lfunc_end97:
	.size	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end97-_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxDNtNtCs6nm8tU1dKu4_4core5error5ErrorNtNtBM_6marker4SendNtB1j_4SyncEL_ENtNtNtBM_3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, 8(%rsp)
	movq	(%rdi), %rax
	movq	%rax, 16(%rsp)
	movq	$24, 40(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	$8, 48(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.105(%rip), %rsi
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB98_3
.LBB98_3:
	movq	32(%rsp), %rsi
	movq	24(%rsp), %rdi
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.107(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	24(%rsp), %rax
	cmpq	$0, %rax
	jne	.LBB98_6
.LBB98_5:
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB98_6:
	.cfi_def_cfa_offset 64
	movq	24(%rsp), %rcx
	movq	32(%rsp), %rdx
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	addq	$8, %rdi
	callq	_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB98_5
.Lfunc_end98:
	.size	_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end98-_RNvXs8_NtCs2MEDghdBxT2_5alloc5boxedINtB5_3BoxNtNtNtCs82cP7IqP7wY_3std2io5error6CustomENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$136, %rsp
	.cfi_def_cfa_offset 144
	movq	%rsi, 48(%rsp)
	movq	%rdi, 56(%rsp)
	movq	%rdi, 64(%rsp)
	movq	%rsi, %rax
	addq	$16, %rax
	movq	%rax, 88(%rsp)
	movq	24(%rsi), %rdi
	movq	%rdi, 72(%rsp)
	movq	16(%rsi), %rsi
	movq	%rsi, 80(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.100(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	72(%rsp), %rax
	movq	80(%rsp), %rcx
	movq	88(%rsp), %rdi
	subq	%rcx, %rax
	movq	%rax, 128(%rsp)
	movq	128(%rsp), %rax
	movq	%rax, 96(%rsp)
	callq	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 104(%rsp)
	movl	%edx, 112(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	cmpl	$-1, 112(%rsp)
	cmoveq	%rcx, %rax
	testq	$1, %rax
	je	.LBB99_2
	movq	88(%rsp), %rax
	movq	104(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	movl	112(%rsp), %ecx
	movl	%ecx, 36(%rsp)
	movq	8(%rax), %rdi
	movq	%rdi, 16(%rsp)
	movq	(%rax), %rsi
	movq	%rsi, 24(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.100(%rip), %rdx
	callq	_RNvNvMNtNtCs6nm8tU1dKu4_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rdx
	movq	96(%rsp), %rax
	movq	48(%rsp), %rdi
	movl	36(%rsp), %esi
	subq	%rdx, %rcx
	movq	%rcx, 120(%rsp)
	subq	120(%rsp), %rax
	movq	%rax, 40(%rsp)
	addq	$40, %rdi
	callq	_RNvXs3_NtNtCs6nm8tU1dKu4_4core3str7patternNtB7_12IsWhitespaceNtB5_11MultiCharEq7matchesCs46bV0WIEyDX_22cayley_zero_guard_opt0
	testb	$1, %al
	jne	.LBB99_4
	jmp	.LBB99_3
.LBB99_2:
	movq	56(%rsp), %rax
	movq	$2, (%rax)
	jmp	.LBB99_6
.LBB99_3:
	movq	56(%rsp), %rax
	movq	8(%rsp), %rdx
	movq	40(%rsp), %rsi
	movq	%rdx, %rcx
	addq	%rsi, %rcx
	movq	%rdx, 8(%rax)
	movq	%rcx, 16(%rax)
	movq	$1, (%rax)
	jmp	.LBB99_5
.LBB99_4:
	movq	56(%rsp), %rax
	movq	8(%rsp), %rdx
	movq	40(%rsp), %rsi
	movq	%rdx, %rcx
	addq	%rsi, %rcx
	movq	%rdx, 8(%rax)
	movq	%rcx, 16(%rax)
	movq	$0, (%rax)
.LBB99_5:
	jmp	.LBB99_6
.LBB99_6:
	movq	64(%rsp), %rax
	addq	$136, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end99:
	.size	_RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end99-_RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMsf_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_13SplitInternalNtB7_12IsWhitespaceE4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end100:
	.size	_RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end100-_RNvXsX_NtNtCs6nm8tU1dKu4_4core3str4iterINtB5_5SplitNtB7_12IsWhitespaceENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	xorl	%eax, %eax
	retq
.Lfunc_end101:
	.size	_RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end101-_RNvXsZ_NtCs82cP7IqP7wY_3std7processuNtB5_11Termination6reportCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, (%rsp)
	movq	%rdx, 8(%rsp)
	movq	%rcx, 16(%rsp)
	cmpq	$0, %rcx
	jne	.LBB102_2
.LBB102_1:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB102_2:
	.cfi_def_cfa_offset 32
	movq	8(%rsp), %rdx
	movq	16(%rsp), %rsi
	movq	(%rsp), %rdi
	callq	*_RNvCsjJ6pmSBbkgH_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB102_1
.Lfunc_end102:
	.size	_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end102-_RNvXs_NtCs2MEDghdBxT2_5alloc5allocNtB4_6GlobalNtNtCs6nm8tU1dKu4_4core5alloc9Allocator10deallocateCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rsi, %rdx
	movq	%rdi, %rax
	retq
.Lfunc_end103:
	.size	_RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end103-_RNvXs_NtNtCs6nm8tU1dKu4_4core3ops12control_flowINtB4_11ControlFlowReEINtNtB6_9try_trait12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, 8(%rsp)
	movq	%rsi, 16(%rsp)
	movq	%rdx, 24(%rsp)
	cmpq	%rcx, %rsi
	je	.LBB104_2
	movb	$0, 35(%rsp)
	jmp	.LBB104_3
.LBB104_2:
	movq	16(%rsp), %rdx
	movq	24(%rsp), %rsi
	movq	8(%rsp), %rdi
	movq	memcmp@GOTPCREL(%rip), %rax
	callq	*%rax
	movl	%eax, 36(%rsp)
	cmpl	$0, 36(%rsp)
	sete	%al
	andb	$1, %al
	movb	%al, 35(%rsp)
.LBB104_3:
	movb	35(%rsp), %al
	andb	$1, %al
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end104:
	.size	_RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end104-_RNvXs_NtNtCs6nm8tU1dKu4_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdx, %rcx
	movq	%rsi, (%rsp)
	movq	%rdi, %rax
	movq	(%rsp), %rdi
	movq	8(%rax), %rsi
	movq	16(%rax), %rdx
	callq	_RNvXs0_NtNtCs6nm8tU1dKu4_4core5slice5indexjINtB5_10SliceIndexSReE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end105:
	.size	_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end105-_RNvXsc_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReEINtNtNtCs6nm8tU1dKu4_4core3ops5index5IndexjE5indexCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rsi
	movq	%rsi, (%rsp)
	movq	(%rsi), %rdi
	addq	$4, %rdi
	addq	$8, %rsi
	callq	_RNvMNtNtCs82cP7IqP7wY_3std4sync6poisonNtB2_4Flag4doneCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rdi
	movq	(%rdi), %rcx
	movq	%rcx, 8(%rsp)
	xorl	%eax, %eax
	xchgl	%eax, (%rcx)
	movl	%eax, 20(%rsp)
	cmpl	$2, 20(%rsp)
	jne	.LBB106_2
	movq	8(%rsp), %rdi
	callq	*_RNvMNtNtNtNtCs82cP7IqP7wY_3std3sys4sync5mutex5futexNtB2_5Mutex4wake@GOTPCREL(%rip)
	jmp	.LBB106_3
.LBB106_2:
	jmp	.LBB106_3
.LBB106_3:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end106:
	.size	_RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end106-_RNvXsc_NtNtNtCs82cP7IqP7wY_3std4sync6poison5mutexINtB5_10MutexGuardINtNtNtNtBb_2io8buffered9bufreader9BufReaderNtNtB1a_5stdio8StdinRawEENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, 8(%rsp)
	movq	%rdi, %rax
	movq	8(%rsp), %rdi
	movq	%rax, 16(%rsp)
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.109(%rip), %rsi
	movl	$13, %edx
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.110(%rip), %rcx
	movl	$4, %r8d
	leaq	16(%rsp), %r9
	leaq	.Lanon.f31448597b1a273a87802a75e10efe0f.108(%rip), %rax
	movq	%rax, (%rsp)
	callq	*_RNvMsa_NtCs6nm8tU1dKu4_4core3fmtNtB5_9Formatter26debug_struct_field1_finish@GOTPCREL(%rip)
	andb	$1, %al
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end107:
	.size	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end107-_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%esi, 4(%rsp)
	movl	4(%rsp), %edi
	callq	_RNvMNtNtCs6nm8tU1dKu4_4core4char7methodsc13is_whitespaceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	andb	$1, %al
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end108:
	.size	_RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end108-_RNvXsg_NtCs6nm8tU1dKu4_4core3strNtB5_12IsWhitespaceINtNtNtB7_3ops8function5FnMutTcEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rsi, -8(%rsp)
	movq	-8(%rsp), %rax
	cmpq	$0, 8(%rax)
	sete	%al
	xorb	$-1, %al
	andb	$1, %al
	retq
.Lfunc_end109:
	.size	_RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end109-_RNvXsm_NtCs6nm8tU1dKu4_4core3strNtB5_10IsNotEmptyINtNtNtB7_3ops8function5FnMutTRReEE8call_mutCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	retq
.Lfunc_end110:
	.size	_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end110-_RNvXso_NtCs2MEDghdBxT2_5alloc3vecINtB5_3VecReENtNtNtCs6nm8tU1dKu4_4core3ops4drop4Drop4dropCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movl	$10, %edx
	callq	_RNvMsp_NtCs6nm8tU1dKu4_4core3numl16from_ascii_radixCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end111:
	.size	_RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end111-_RNvXso_NtCs6nm8tU1dKu4_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin12:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception12
	subq	$296, %rsp
	.cfi_def_cfa_offset 304
	movq	%rsi, 88(%rsp)
	movq	%rdi, %rax
	movq	88(%rsp), %rdi
	movq	%rax, 96(%rsp)
	movq	%rax, 104(%rsp)
	movq	$0, 248(%rsp)
	movq	$1, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	264(%rsp), %rax
	movq	%rax, 144(%rsp)
	movups	248(%rsp), %xmm0
	movaps	%xmm0, 128(%rsp)
.Ltmp251:
	movq	_RNvXs8_NtNtCs82cP7IqP7wY_3std2io5stdioNtB5_9StdinLockNtB7_7BufRead9read_line@GOTPCREL(%rip), %rax
	leaq	128(%rsp), %rsi
	callq	*%rax
.Ltmp252:
	movq	%rdx, 112(%rsp)
	movq	%rax, 120(%rsp)
	jmp	.LBB112_3
.LBB112_1:
	jmp	.LBB112_22
.LBB112_2:
.Ltmp265:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 280(%rsp)
	movl	%eax, 288(%rsp)
	jmp	.LBB112_1
.LBB112_3:
	movq	112(%rsp), %rax
	movq	120(%rsp), %rcx
	movq	%rcx, 160(%rsp)
	movq	%rax, 168(%rsp)
	testq	$1, 160(%rsp)
	je	.LBB112_5
	movq	96(%rsp), %rax
	movq	168(%rsp), %rcx
	movq	%rcx, 232(%rsp)
	movq	$-1, 224(%rsp)
	movq	224(%rsp), %rcx
	movq	%rcx, (%rax)
	movq	232(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movq	240(%rsp), %rcx
	movq	%rcx, 16(%rax)
	jmp	.LBB112_8
.LBB112_5:
	cmpq	$0, 168(%rsp)
	jne	.LBB112_7
	movq	96(%rsp), %rax
	movq	$-2, (%rax)
	jmp	.LBB112_8
.LBB112_7:
	movq	136(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 64(%rsp)
	movl	$0, 272(%rsp)
.Ltmp253:
	movl	$10, %edi
	leaq	272(%rsp), %rsi
	movl	$4, %edx
	callq	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp254:
	movq	%rdx, 72(%rsp)
	movq	%rax, 80(%rsp)
	jmp	.LBB112_9
.LBB112_8:
	leaq	128(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0
	jmp	.LBB112_21
.LBB112_9:
.Ltmp255:
	movq	72(%rsp), %rcx
	movq	80(%rsp), %rdx
	movq	64(%rsp), %rsi
	movq	56(%rsp), %rdi
	movq	_RNvMNtCs6nm8tU1dKu4_4core5sliceSh9ends_withCsdiG5z4n837b_9addr2line@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp256:
	movb	%al, 55(%rsp)
	jmp	.LBB112_10
.LBB112_10:
	movb	55(%rsp), %al
	testb	$1, %al
	jne	.LBB112_12
	jmp	.LBB112_11
.LBB112_11:
	jmp	.LBB112_13
.LBB112_12:
.Ltmp257:
	leaq	128(%rsp), %rdi
	callq	_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp258:
	jmp	.LBB112_14
.LBB112_13:
	movq	96(%rsp), %rax
	movq	128(%rsp), %rcx
	movq	%rcx, 200(%rsp)
	movq	136(%rsp), %rcx
	movq	%rcx, 208(%rsp)
	movq	144(%rsp), %rcx
	movq	%rcx, 216(%rsp)
	movq	200(%rsp), %rcx
	movq	%rcx, 176(%rsp)
	movq	208(%rsp), %rcx
	movq	%rcx, 184(%rsp)
	movq	216(%rsp), %rcx
	movq	%rcx, 192(%rsp)
	movq	176(%rsp), %rcx
	movq	%rcx, (%rax)
	movq	184(%rsp), %rcx
	movq	%rcx, 8(%rax)
	movq	192(%rsp), %rcx
	movq	%rcx, 16(%rax)
	jmp	.LBB112_21
.LBB112_14:
	movq	136(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 24(%rsp)
	movl	$0, 276(%rsp)
.Ltmp259:
	movl	$13, %edi
	leaq	276(%rsp), %rsi
	movl	$4, %edx
	callq	_RNvNtNtCs6nm8tU1dKu4_4core4char7methods15encode_utf8_rawCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp260:
	movq	%rdx, 32(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.LBB112_15
.LBB112_15:
.Ltmp261:
	movq	32(%rsp), %rcx
	movq	40(%rsp), %rdx
	movq	24(%rsp), %rsi
	movq	16(%rsp), %rdi
	movq	_RNvMNtCs6nm8tU1dKu4_4core5sliceSh9ends_withCsdiG5z4n837b_9addr2line@GOTPCREL(%rip), %rax
	callq	*%rax
.Ltmp262:
	movb	%al, 15(%rsp)
	jmp	.LBB112_16
.LBB112_16:
	movb	15(%rsp), %al
	testb	$1, %al
	jne	.LBB112_18
	jmp	.LBB112_17
.LBB112_17:
	jmp	.LBB112_19
.LBB112_18:
.Ltmp263:
	leaq	128(%rsp), %rdi
	callq	_RNvMNtCs2MEDghdBxT2_5alloc6stringNtB2_6String3popCs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp264:
	jmp	.LBB112_20
.LBB112_19:
	jmp	.LBB112_13
.LBB112_20:
	jmp	.LBB112_19
.LBB112_21:
	movq	104(%rsp), %rax
	addq	$296, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB112_22:
	.cfi_def_cfa_offset 304
.Ltmp266:
	leaq	128(%rsp), %rdi
	callq	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtCs2MEDghdBxT2_5alloc6string6StringECs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp267:
	jmp	.LBB112_24
.LBB112_23:
.Ltmp268:
	callq	*_RNvNtCs6nm8tU1dKu4_4core9panicking16panic_in_cleanup@GOTPCREL(%rip)
.LBB112_24:
	movq	280(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end112:
	.size	_RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end112-_RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNvXso_NtCs82cP7IqP7wY_3std2ioINtB5_5LinesNtNtB5_5stdio9StdinLockENtNtNtNtCs6nm8tU1dKu4_4core4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table112:
.Lexception12:
	.byte	255
	.byte	155
	.uleb128 .Lttbase7-.Lttbaseref7
.Lttbaseref7:
	.byte	1
	.uleb128 .Lcst_end12-.Lcst_begin12
.Lcst_begin12:
	.uleb128 .Ltmp251-.Lfunc_begin12
	.uleb128 .Ltmp254-.Ltmp251
	.uleb128 .Ltmp265-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp254-.Lfunc_begin12
	.uleb128 .Ltmp255-.Ltmp254
	.byte	0
	.byte	0
	.uleb128 .Ltmp255-.Lfunc_begin12
	.uleb128 .Ltmp264-.Ltmp255
	.uleb128 .Ltmp265-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp266-.Lfunc_begin12
	.uleb128 .Ltmp267-.Ltmp266
	.uleb128 .Ltmp268-.Lfunc_begin12
	.byte	1
	.uleb128 .Ltmp267-.Lfunc_begin12
	.uleb128 .Lfunc_end112-.Ltmp267
	.byte	0
	.byte	0
.Lcst_end12:
	.byte	127
	.byte	0
	.p2align	2, 0x0
.Lttbase7:
	.byte	0
	.p2align	2, 0x0

	.section	.text._RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movq	%rax, (%rsp)
	callq	_RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	(%rsp), %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end113:
	.size	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end113-_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	(%rdi), %rax
	movq	8(%rdi), %rdx
	retq
.Lfunc_end114:
	.size	_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end114-_RNvXso_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_21CharPredicateSearcherNtB7_12IsWhitespaceENtB5_8Searcher8haystackCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	8(%rdi), %rax
	movq	16(%rdi), %rdx
	retq
.Lfunc_end115:
	.size	_RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end115-_RNvXsx_NtCs2MEDghdBxT2_5alloc6stringNtB5_6StringNtNtNtCs6nm8tU1dKu4_4core3ops5deref5Deref5derefCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rsi
	addq	$64, %rsi
	callq	_RINvYINtNtNtCs6nm8tU1dKu4_4core3str4iter5SplitNtB8_12IsWhitespaceENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNtB8_10IsNotEmptyECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end116:
	.size	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end116-_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movq	$0, (%rdi)
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76(%rip), %rdx
	movq	.Lanon.f31448597b1a273a87802a75e10efe0f.76+8(%rip), %rcx
	movq	%rdx, 8(%rdi)
	movq	%rcx, 16(%rdi)
	retq
.Lfunc_end117:
	.size	_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end117-_RNvXsz_NtNtCs6nm8tU1dKu4_4core3str4iterNtB5_15SplitWhitespaceNtNtNtNtB9_4iter6traits8iterator8Iterator9size_hintCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end118:
	.size	_RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end118-_RNvYFEuINtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rsi, 8(%rsp)
	movq	%rdi, 16(%rsp)
	movq	%rdi, 24(%rsp)
.LBB119_1:
	movq	8(%rsp), %rsi
	leaq	32(%rsp), %rdi
	callq	_RNvXs8_NtNtCs6nm8tU1dKu4_4core3str7patternINtB5_19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher4nextCs46bV0WIEyDX_22cayley_zero_guard_opt0
	movq	32(%rsp), %rax
	movq	%rax, (%rsp)
	testq	%rax, %rax
	je	.LBB119_3
	jmp	.LBB119_7
.LBB119_7:
	movq	(%rsp), %rax
	subq	$1, %rax
	je	.LBB119_5
	jmp	.LBB119_8
.LBB119_8:
	jmp	.LBB119_4
	.cfi_def_cfa_offset 8
	ud2
.LBB119_3:
	.cfi_def_cfa_offset 64
	movq	16(%rsp), %rax
	movq	40(%rsp), %rdx
	movq	48(%rsp), %rcx
	movq	%rdx, 8(%rax)
	movq	%rcx, 16(%rax)
	movq	$1, (%rax)
	jmp	.LBB119_6
.LBB119_4:
	movq	16(%rsp), %rax
	movq	$0, (%rax)
	jmp	.LBB119_6
.LBB119_5:
	jmp	.LBB119_1
.LBB119_6:
	movq	24(%rsp), %rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end119:
	.size	_RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end119-_RNvYINtNtNtCs6nm8tU1dKu4_4core3str7pattern19MultiCharEqSearcherNtB7_12IsWhitespaceENtB5_8Searcher10next_matchCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0:
.Lfunc_begin13:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception13
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, 8(%rsp)
.Ltmp269:
	leaq	8(%rsp), %rdi
	callq	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
.Ltmp270:
	movl	%eax, 4(%rsp)
	jmp	.LBB120_3
.LBB120_1:
	movq	24(%rsp), %rdi
	callq	_Unwind_Resume@PLT
.LBB120_2:
.Ltmp271:
	movq	%rax, %rcx
	movl	%edx, %eax
	movq	%rcx, 24(%rsp)
	movl	%eax, 32(%rsp)
	jmp	.LBB120_1
.LBB120_3:
	movl	4(%rsp), %eax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end120:
	.size	_RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end120-_RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc
	.section	.gcc_except_table._RNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_onceCs46bV0WIEyDX_22cayley_zero_guard_opt0,"a",@progbits
	.p2align	2, 0x0
GCC_except_table120:
.Lexception13:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end13-.Lcst_begin13
.Lcst_begin13:
	.uleb128 .Ltmp269-.Lfunc_begin13
	.uleb128 .Ltmp270-.Ltmp269
	.uleb128 .Ltmp271-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp270-.Lfunc_begin13
	.uleb128 .Lfunc_end120-.Ltmp270
	.byte	0
	.byte	0
.Lcst_end13:
	.p2align	2, 0x0

	.section	.text._RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, %rax
	movb	%sil, %dl
	retq
.Lfunc_end121:
	.size	_RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end121-_RNvYNtNtNtCs82cP7IqP7wY_3std2io5stdio9StdinLockNtB6_7BufRead5linesCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text._RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0,"ax",@progbits
	.p2align	4
	.type	_RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0,@function
_RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0:
	.cfi_startproc
	movq	%rdi, -48(%rsp)
	movq	%rsi, -40(%rsp)
	movb	$1, -17(%rsp)
	movq	-40(%rsp), %rax
	cmpq	-48(%rsp), %rax
	setb	%al
	movb	%al, -49(%rsp)
	movb	-49(%rsp), %al
	testb	$1, %al
	jne	.LBB122_3
	jmp	.LBB122_2
.LBB122_2:
	movq	-40(%rsp), %rax
	movq	%rax, -32(%rsp)
	jmp	.LBB122_4
.LBB122_3:
	movb	$0, -17(%rsp)
	movq	-48(%rsp), %rax
	movq	%rax, -32(%rsp)
.LBB122_4:
	movq	-32(%rsp), %rax
	retq
.Lfunc_end122:
	.size	_RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0, .Lfunc_end122-_RNvYjNtNtCs6nm8tU1dKu4_4core3cmp3Ord3maxCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rdx
	movslq	%edi, %rsi
	leaq	_RNvCs46bV0WIEyDX_22cayley_zero_guard_opt04main(%rip), %rdi
	xorl	%ecx, %ecx
	callq	_RINvNtCs82cP7IqP7wY_3std2rt10lang_startuECs46bV0WIEyDX_22cayley_zero_guard_opt0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end123:
	.size	main, .Lfunc_end123-main
	.cfi_endproc

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.0,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.0:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/alloc/src/vec/mod.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.0, 77

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.1,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.1,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.1:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.0
	.asciz	"L\000\000\000\000\000\000\000\247\b\000\000\t\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.1, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.2,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.2,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0INtNtNtCs6nm8tU1dKu4_4core3ops8function6FnOnceuE9call_once6vtableCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.quad	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
	.quad	_RNCINvNtCs82cP7IqP7wY_3std2rt10lang_startuE0Cs46bV0WIEyDX_22cayley_zero_guard_opt0
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.2, 48

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.3,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	2, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.3:
	.zero	4
	.zero	4
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.3, 8

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.4,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.4:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/str/validations.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.4, 84

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.5,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.5,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.5:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\0000\000\000\000$\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.5, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.6,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.6:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\0007\000\000\000(\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.6, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.7,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.7,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.7:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\000?\000\000\000,\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.7, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.8,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.8:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\000]\000\000\000)\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.8, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.9,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.9:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\000b\000\000\000-\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.9, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.10,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.10:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.4
	.asciz	"S\000\000\000\000\000\000\000g\000\000\0001\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.10, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.11,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.11,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.11:
	.ascii	"there is no such thing as a release load"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.11, 40

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.12,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.12:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/sync/atomic.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.12, 80

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.13,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.13,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.13:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.12
	.asciz	"O\000\000\000\000\000\000\000C\017\000\000\030\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.13, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.14,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.14,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.14:
	.ascii	"there is no such thing as an acquire-release load"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.14, 49

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.15,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.15:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.12
	.asciz	"O\000\000\000\000\000\000\000D\017\000\000\027\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.15, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.16,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.16,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.16:
	.ascii	"there is no such thing as an acquire store"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.16, 42

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.17,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.17,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.17:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.12
	.asciz	"O\000\000\000\000\000\000\0004\017\000\000\030\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.17, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.18,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.18,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.18:
	.ascii	"there is no such thing as an acquire-release store"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.18, 50

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.19,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.19,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.19:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.12
	.asciz	"O\000\000\000\000\000\000\0005\017\000\000\027\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.19, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.20,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.20:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/io/error/repr_bitpacked.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.20, 91

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.21,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.21:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.20
	.asciz	"Z\000\000\000\000\000\000\000\b\001\000\000\032\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.21, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.22,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.22,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.22:
	.ascii	"internal error: entered unreachable code"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.22, 40

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.23,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.23,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.23:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.20
	.asciz	"Z\000\000\000\000\000\000\000\031\001\000\000\r\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.23, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.24,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.24:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/unique.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.24, 79

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.25,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.25,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.25:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.24
	.asciz	"N\000\000\000\000\000\000\000X\000\000\000$\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.25, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.26,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.26:
	.asciz	"/shared/external/madloop_tirust/madgraph7_madloop_tirust/docs/benchmarkfolder/experiments/cayley-zero-denominator-guard-proposal-1/source/fixture.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.26, 149

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.27,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.27,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.27:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\026\000\000\000\031\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.27, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.28,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.28:
	.asciz	"\b\000\000\000\000\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.28, 8

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.29,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.29,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.29:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\030\000\000\000\t\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.29, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.30,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.30,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.30:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\031\000\000\000\030\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.30, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.31,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.31,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.31:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\032\000\000\000\032\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.31, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.32,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.f31448597b1a273a87802a75e10efe0f.32:
	.ascii	"baseline"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.32, 8

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.33,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.33,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.33:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.32
	.asciz	"\b\000\000\000\000\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.33, 16

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.34,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.34,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.34:
	.ascii	"candidate"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.34, 9

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.35,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.35,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.35:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.34
	.asciz	"\t\000\000\000\000\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.35, 16

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.36,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.36,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.36:
	.ascii	"assertion failed: mode == \"baseline\" || mode == \"candidate\""
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.36, 59

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.37,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.37,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.37:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\033\000\000\000\t\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.37, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.38,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.38,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.38:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\034\000\000\000,\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.38, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.39,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.39,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.39:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\034\000\000\0005\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.39, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.40,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.40,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.40:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\035\000\000\000,\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.40, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.41,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.41,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.41:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\035\000\000\0005\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.41, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.42,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.42,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.42:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\036\000\000\000\037\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.42, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.43,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.43,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.43:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\036\000\000\000+\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.43, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.44,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.44,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.44:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\037\000\000\000#\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.44, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.45,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.45,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.45:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000\037\000\000\000/\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.45, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.46,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.46,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.46:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000 \000\000\000 \000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.46, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.47,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.47,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.47:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000 \000\000\000,\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.47, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.48,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.48,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.48:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000!\000\000\000 \000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.48, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.49,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.49,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.49:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000!\000\000\000,\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.49, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.50,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.50,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.50:
	.ascii	"assertion failed: fedisableexcept(ALL) >= 0"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.50, 43

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.51,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.51,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.51:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000#\000\000\000\r\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.51, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.52,@object
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.52:
	.zero	4
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.52, 4

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.53,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.53,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.53:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000$\000\000\000\r\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.53, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.54,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.54,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.54:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000%\000\000\000\r\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.54, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.55,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.55,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.55:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000&\000\000\000\034\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.55, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.56,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.56,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.56:
	.ascii	"assertion failed: feenableexcept(traps) >= 0"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.56, 44

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.57,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.57,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.57:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000'\000\000\000\035\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.57, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.58,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.58,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.58:
	.asciz	"\006ENTER \300\001 \300\001 \303 \000\000i\020\000\001 \303 \000\000i\020\000\001 \300\001 \300\001 \300\001\n"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.58, 41

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.59,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.59,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.59:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\000.\000\000\000\"\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.59, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.60,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.60,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.60:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.26
	.asciz	"\224\000\000\000\000\000\000\0006\000\000\000\022\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.60, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.61,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.f31448597b1a273a87802a75e10efe0f.61:
	.ascii	"none"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.61, 4

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.62,@object
.Lanon.f31448597b1a273a87802a75e10efe0f.62:
	.ascii	"some"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.62, 4

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.63,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.63,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.63:
	.asciz	"\004ROW \300\001 \300\001 \303 \000\000i\020\000\001 \303 \000\000i\020\000\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \300\001 \303 \000\000i\020\000\001\n"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.63, 69

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.64,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.64:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/char/methods.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.64, 81

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.65,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.65,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.65:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.64
	.asciz	"P\000\000\000\000\000\000\000\357\000\000\000\022\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.65, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.66,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.66,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.66:
	.quad	_RINvNtCs6nm8tU1dKu4_4core3ptr9drop_glueNtNtNtCs82cP7IqP7wY_3std2io5error5ErrorECs46bV0WIEyDX_22cayley_zero_guard_opt0
	.asciz	"\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXNtNtCs82cP7IqP7wY_3std2io5errorNtB2_5ErrorNtNtCs6nm8tU1dKu4_4core3fmt5Debug3fmt
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.66, 32

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.67,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.67,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.67:
	.ascii	"called `Result::unwrap()` on an `Err` value"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.67, 43

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.68,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.68,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.68:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	_RNvXsd_NtNtCs6nm8tU1dKu4_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs46bV0WIEyDX_22cayley_zero_guard_opt0
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.68, 32

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.69,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.69,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.69:
	.ascii	"is_aligned_to: align is not a power-of-two"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.69, 42

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.70,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.70:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/const_ptr.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.70, 82

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.71,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.71,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.71:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.70
	.asciz	"Q\000\000\000\000\000\000\000^\005\000\000\r\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.71, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.72,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.72,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.72:
	.ascii	"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.72, 71

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.73,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.73,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.73:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.64
	.asciz	"P\000\000\000\000\000\000\000\223\001\000\000\t\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.73, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.74,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.74:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/alloc/src/raw_vec/mod.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.74, 81

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.75,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.75,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.75:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.74
	.asciz	"P\000\000\000\000\000\000\000\266\001\000\000\025\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.75, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.76,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.76:
	.zero	8
	.zero	8
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.76, 16

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.77,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.77:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/num/mod.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.77, 76

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.78,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.78,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.78:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.77
	.asciz	"K\000\000\000\000\000\000\000:\007\000\000\001\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.78, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.79,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.79:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/str/mod.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.79, 76

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.80,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.80,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.80:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.79
	.asciz	"K\000\000\000\000\000\000\000\260\002\000\000\026\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.80, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.81,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.81,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.81:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.77
	.asciz	"K\000\000\000\000\000\000\0009\007\000\000\001\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.81, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.82,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.82,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.82:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.64
	.asciz	"P\000\000\000\000\000\000\000\260\b\000\000\016\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.82, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.83,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.83,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.83:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.64
	.asciz	"P\000\000\000\000\000\000\000\243\b\000\000\t\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.83, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.84,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.84:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/unicode/unicode_data.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.84, 89

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.85,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.85,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.85:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.84
	.asciz	"X\000\000\000\000\000\000\000\333\002\000\000\022\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.85, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.86,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.86,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.86:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.84
	.asciz	"X\000\000\000\000\000\000\000\335\002\000\000\023\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.86, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.87,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.87,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.87:
	.ascii	"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.87, 198

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.88,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.88,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.88:
	.ascii	"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.88, 201

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.89,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.89,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.89:
	.ascii	"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.89, 259

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.90,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.90,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.90:
	.ascii	"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.90, 210

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.91,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.91,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.91:
	.ascii	"unsafe precondition(s) violated: isize::unchecked_neg cannot overflow\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.91, 186

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.92,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.92,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.92:
	.ascii	"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.92, 198

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.93,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.93,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.93:
	.ascii	"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.93, 221

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.94,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.94,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.94:
	.ascii	"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.94, 199

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.95,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.95,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.95:
	.ascii	"unsafe precondition(s) violated: invalid value for `char`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.95, 174

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.96,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.96,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.96:
	.ascii	"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.96, 283

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.97,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.97,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.97:
	.asciz	"\022encode_utf8: need \300\023 bytes to encode U+\303 \000\000i\004\000\025 but buffer has just \300"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.97, 71

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.98,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.98,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.98:
	.ascii	"unsafe precondition(s) violated: str::get_unchecked requires that the range is within the string slice\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.98, 219

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.99,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.99:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/non_null.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.99, 81

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.100,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.100,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.100:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.99
	.asciz	"P\000\000\000\000\000\000\000\266\003\000\000 \000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.100, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.101,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.101,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.101:
	.ascii	"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.101, 73

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.102,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.102,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.102:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.99
	.asciz	"P\000\000\000\000\000\000\000\340\002\000\0003\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.102, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.103,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.103:
	.zero	8
	.zero	4,255
	.zero	4
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.103, 16

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.104,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.104:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/mem/alignment.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.104, 82

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.105,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.105,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.105:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.104
	.asciz	"Q\000\000\000\000\000\000\000\177\000\000\000\022\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.105, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.106,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f31448597b1a273a87802a75e10efe0f.106:
	.asciz	"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/alloc/layout.rs"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.106, 81

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.107,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.107,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.107:
	.quad	.Lanon.f31448597b1a273a87802a75e10efe0f.106
	.asciz	"P\000\000\000\000\000\000\000\001\001\000\000\022\000\000"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.107, 24

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.108,@object
	.section	.data.rel.ro..Lanon.f31448597b1a273a87802a75e10efe0f.108,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f31448597b1a273a87802a75e10efe0f.108:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs6nm8tU1dKu4_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCsbhnijhkoh2c_14rustc_demangle
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.108, 32

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.109,@object
	.section	.rodata..Lanon.f31448597b1a273a87802a75e10efe0f.109,"a",@progbits
.Lanon.f31448597b1a273a87802a75e10efe0f.109:
	.ascii	"ParseIntError"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.109, 13

	.type	.Lanon.f31448597b1a273a87802a75e10efe0f.110,@object
	.section	.rodata.cst4,"aM",@progbits,4
.Lanon.f31448597b1a273a87802a75e10efe0f.110:
	.ascii	"kind"
	.size	.Lanon.f31448597b1a273a87802a75e10efe0f.110, 4

	.hidden	DW.ref.rust_eh_personality
	.weak	DW.ref.rust_eh_personality
	.section	.data.DW.ref.rust_eh_personality,"awG",@progbits,DW.ref.rust_eh_personality,comdat
	.p2align	3, 0x0
	.type	DW.ref.rust_eh_personality,@object
	.size	DW.ref.rust_eh_personality, 8
DW.ref.rust_eh_personality:
	.quad	rust_eh_personality
	.ident	"rustc version 1.97.1 (8bab26f4f 2026-07-14) (built from a source tarball)"
	.section	".note.GNU-stack","",@progbits
