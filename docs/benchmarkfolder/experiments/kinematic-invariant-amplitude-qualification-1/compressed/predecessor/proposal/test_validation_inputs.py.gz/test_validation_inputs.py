"""Prospective input equality/scope tests. No controller/native invocation."""
import json
from collections import Counter
import unittest
import prepare_validation as V
from derive_candidate import HERE,DERIVED,subroutine
from source_evidence import environment_audit

class Inputs(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.outputs=V.outputs()
        cls.plan=json.loads(cls.outputs['validation-plan.json'])

    def test_exact_derivation(self):
        for name,raw in self.outputs.items():
            self.assertEqual(raw,(HERE/name).read_bytes(),name)

    def test_only_reducer_id_changes_between_literal_cards(self):
        for mode in [1,4]:
            original=(V.SOURCE/'inputs'/f'cms-mode{mode}-MadLoopParams.dat').read_bytes()
            tirust=self.outputs[f'inputs/cms-backend9-mode{mode}-MadLoopParams.dat']
            cuttools=self.outputs[f'inputs/cms-backend1-mode{mode}-MadLoopParams.dat']
            self.assertEqual(original,tirust)
            self.assertEqual(tirust,cuttools.replace(b'#MLReductionLib\n1\n',b'#MLReductionLib\n9\n'))

    def test_fixed_bounded_matrix_and_preserved_bootstrap(self):
        requests=self.plan['requests']
        self.assertEqual(len(requests),24)
        self.assertEqual(Counter(x['stage'] for x in requests),{'ordinary':8,'stress':16})
        self.assertEqual(len({(x['variant'],x['backend'],x['requested_mode'],x['point']) for x in requests}),24)
        self.assertEqual({x['bootstrap_calls'] for x in requests},{1})
        self.assertEqual({x['measurement_calls'] for x in requests},{1})
        self.assertEqual(sum(x['outer_entries_max'] for x in requests),48)
        self.assertFalse(self.plan['native_admitted'])
        self.assertTrue(self.plan['controller_implemented'])

    def test_unchanged_value_and_failure_flag_observation(self):
        driver=self.outputs['driver-amplitude.f'].decode()
        original=(DERIVED/'cms/driver-unmodified.f').read_text()
        for name in ['KTRACE_DRIVER_STATE','KTRACE_DRIVER_VALUES','KTRACE_READ_POINT']:
            self.assertEqual(subroutine(driver,name),subroutine(original,name))
        self.assertEqual(driver.count('CALL ML5_0_SLOOPMATRIX_THRES('),2)
        self.assertIn('CALL ML5_0_FORCE_STABILITY_CHECK(.FALSE.)',driver)
        self.assertIn('MLReductionLib(1).NE.BACKEND',driver)
        self.assertIn('IF(.NOT.UseQPIntegrandForCutTools) STOP 24',driver)
        self.assertNotIn('COMMON/',subroutine(driver,'KTRACE_DRIVER_CARD'))

    def test_environment_source_receipt_reproduces(self):
        data=environment_audit()
        self.assertEqual(data,json.loads((HERE/'environment-source-audit.json').read_text()))
        self.assertEqual(data['binding_files'],269)
        self.assertEqual(data['hits'],[])
        self.assertFalse(data['runtime_control_preservation_qualified'])

if __name__=='__main__':
    unittest.main(verbosity=2)
