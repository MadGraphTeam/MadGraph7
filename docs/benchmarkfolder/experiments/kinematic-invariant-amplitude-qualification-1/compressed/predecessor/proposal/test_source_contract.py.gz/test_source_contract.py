"""Source checks, not Fortran execution or amplitude qualification."""
from pathlib import Path
import re
import unittest
from unittest import mock
import ast
import derive_candidate as D


def statements(text):
    result=[]
    for line in text.splitlines():
        if not line.strip() or line[0] in 'Cc*!':
            continue
        if line[5:6].strip():
            assert result
            result[-1]+=line[6:].strip()
        else:
            result.append(line[6:].strip())
    return result


class SourceContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original,cls.candidate=D.derive()

    def test_source_reproduction_and_no_native_actions(self):
        for name,body in self.candidate.items():
            self.assertEqual(body,(D.HERE/'candidate'/name).read_text())
        self.assertNotRegex(Path(D.__file__).read_text(),r'\b(subprocess|ctypes|os\.system|Popen)\b')

    def test_source_pins_fail_before_parse_and_survive_optimized_python(self):
        tree=ast.parse(Path(D.__file__).read_text())
        self.assertFalse(any(isinstance(node,ast.Assert) for node in ast.walk(tree)))
        with mock.patch.object(D,'pin',return_value={'sha256':'wrong'}), \
             mock.patch.object(D.json,'loads') as parse:
            with self.assertRaisesRegex(ValueError,'sealed index mismatch'):
                D.load_seal(Path('not-read'),'expected')
            parse.assert_not_called()
        with self.assertRaisesRegex(ValueError,'source anchor count'):
            D.once('anchor anchor','anchor','replacement')

    def test_all_26_explicit_calls_keep_original_mass_order_and_group(self):
        before=[x for x in statements(self.original['loop_CT_calls_1.f'])
                if re.match(r'CALL ML5_0_LOOP_(?:1_2|2|3|4)\(',x)]
        after=[x for x in statements(self.candidate['loop_CT_calls_1.f'])
               if re.match(r'CALL ML5_0_LOOP_(?:1_2|2|3|4)\(',x)]
        self.assertEqual(len(before),26)
        self.assertEqual([x.replace(',PC_ENV,PC_PRODUCER_OK)',')') for x in after],before)
        self.assertEqual(sorted(int(re.search(r'I_SO,(\d+)\)',x).group(1)) for x in before),list(range(1,27)))

    def test_compatibility_diagnostics_explicit_unknown_no_common(self):
        for prefix in ['ML5_0_','ML5_0_MP_']:
            body=D.subroutine(self.candidate['TIRUST_interface.f'],prefix+'TIRUST_TENSOR_DIAGNOSTIC')
            self.assertNotIn('COMMON',body)
            self.assertIn('PC_CLASS=0',body)
            self.assertIn('PC_HAVE=.FALSE.',body)
            self.assertIn('PC_HAVE,0_PC_IK)',body)

    def test_tokens_precede_actual_producers_and_reset_each_entry(self):
        body=D.subroutine(self.candidate['loop_matrix.f'],'ML5_0_SLOOPMATRIX_RETRY_IMPL')
        self.assertNotIn('SAVE PC_',body)
        self.assertLess(body.index('PC_ENV_DP=0_PC_IK'),body.index('PC_ENV_DP=PC_CAPTURE_ENV()'))
        self.assertLess(body.index('PC_ENV_QP=0_PC_IK'),body.index('PC_ENV_QP=PC_CAPTURE_ENV()'))
        self.assertIn('PC_ENV_DP=PC_CAPTURE_ENV()\n          CALL ML5_0_HELAS_CALLS_AMPB_1',body)
        self.assertIn('PC_ENV_QP=PC_CAPTURE_ENV()\n          CALL ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS',body)
        self.assertIn('PC_CALL_PRODUCER=PC_QP_PRODUCER',body)
        for suffix in ['3','4','2','1_2']:
            call=D.subroutine(self.candidate['CT_interface.f'],'ML5_0_LOOP_'+suffix)
            self.assertNotIn('PC_ENV=PC_CAPTURE_ENV()',call)
            self.assertIn('PC_ROUTE_OK=PC_PRODUCER_OK.AND.PC_ROUTE_MATCHES',call)

    def test_qp_producer_flag_is_actual_not_ctmode_inference(self):
        body=self.candidate['mp_compute_loop_coefs.f']
        self.assertIn('PC_QP_PRODUCER=COMPUTE_INTEGRAND_IN_QP',body)
        original=self.original['mp_compute_loop_coefs.f']
        # Private declaration/reporting only; all original numerical producer body survives.
        normalized=body[body.index('      SUBROUTINE ML5_0_PRIVATE_MP_'):]
        normalized=normalized.replace('      SUBROUTINE ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(PS,ANSDP,\n     $ PC_QP_PRODUCER)',
                                      '      SUBROUTINE ML5_0_MP_COMPUTE_LOOP_COEFS(PS,ANSDP)')
        normalized=normalized.replace('      LOGICAL PC_QP_PRODUCER\n','')
        normalized=normalized.replace('      PC_QP_PRODUCER=COMPUTE_INTEGRAND_IN_QP\n','')
        self.assertEqual(normalized,original)

    def test_corner_arithmetic_and_other_backends_unchanged(self):
        for suffix in ['3','4','2','1_2']:
            before=D.subroutine(self.original['CT_interface.f'],'ML5_0_LOOP_'+suffix)
            after=D.subroutine(self.candidate['CT_interface.f'],'ML5_0_LOOP_'+suffix)
            for start,end in [('        WE(1)=W1','C       Determine whether'),
                              ('        IF(MLREDUCTIONLIB(I_LIB).EQ.1)THEN',
                               '        ELSEIF(MLREDUCTIONLIB(I_LIB).EQ.9')]:
                self.assertEqual(before[before.index(start):before.index(end)],
                                 after[after.index(start):after.index(end)])
        self.assertTrue(self.candidate['TIR_interface.f'].startswith(self.original['TIR_interface.f']))
        for prefix in ['ML5_0_', 'ML5_0_MP_']:
            self.assertEqual(D.subroutine(self.candidate['CT_interface.f'],prefix+'BUILD_KINEMATIC_MATRIX'),
                             D.subroutine(self.original['CT_interface.f'],prefix+'BUILD_KINEMATIC_MATRIX'))
        self.assertEqual(D.subroutine(self.candidate['TIRUST_interface.f'],'ML5_0_MP_TIRUST_LOOP'),
                         D.subroutine(self.original['TIRUST_interface.f'],'ML5_0_MP_TIRUST_LOOP'))

    def test_projection_order_and_direct_only_in_zero_assignment_branch(self):
        for prefix in ['ML5_0_','ML5_0_MP_']:
            body=D.subroutine(self.candidate['CT_interface.f'],prefix+'PRIVATE_KINEMATIC_MATRIX')
            sequence=['S_MAT(I,J)=DIFFSQ-M2L(I)-M2L(J)',
                      'S_MAT(I,J)=-M2L(J)','S_MAT(I,J)=-M2L(I)',
                      'IF(ABS(DIFFSQ/REF_NORMALIZATION).LT.OSTHRES)THEN',
                      'PC_USE(I,J)=PC_CERTIFY','PC_DIRECT(I,J)=REAL(DIFFSQ',
                      '                  S_MAT(I,J)=-(M2L(I)+M2L(J))']
            locations=[body.index(x) for x in sequence]
            self.assertEqual(locations,sorted(locations))
            self.assertEqual(body.count('PC_MASS_SNAP=.TRUE.'),2)
            self.assertEqual(body.count('PC_USE(I,J)='),1)
            self.assertIn('PC_CLASS(I,J).EQ.2.AND.PC_HAVE(I,J)',body)
            self.assertIn('PC_USE=.FALSE.',body)
            # Protected/unknown path retains literal original complex arithmetic.
            old=D.subroutine(self.original['CT_interface.f'],prefix+'BUILD_KINEMATIC_MATRIX')
            raw=old[old.index('            DIFFSQ ='):old.index('C           Default value')]
            self.assertIn(raw.rstrip(),body)

    def test_direct_output_bypasses_mass_roundtrip_before_symmetrization(self):
        for prefix in ['ML5_0_','ML5_0_MP_']:
            body=D.subroutine(self.candidate['TIRUST_interface.f'],prefix+'PRIVATE_TIRUST_DIAGNOSTIC')
            self.assertIn('IF(PC_USE(I,J)) THEN\n            INVARIANTS(I,J)=PC_DIRECT(I,J)\n          ELSE',body)
            self.assertIn('INVARIANTS(I,J)=REAL(S_MAT(I,J)+MASSES(I)+MASSES(J)',body)
            self.assertLess(body.index('INVARIANTS(I,J)=PC_DIRECT'),body.index('TIRUST_INVARIANT_BITS=TRANSFER'))
            self.assertLess(body.index('SWITCH_ORDER('),body.index('PC_SHIFTS='))
            self.assertNotIn('COMMON/ML5_0_LOOP/',body)

    def test_no_new_fixed_form_truncation(self):
        for name,body in self.candidate.items():
            old=set(self.original[name].splitlines())
            bad=[(n,line) for n,line in enumerate(body.splitlines(),1)
                 if len(line)>72 and line[:1] not in 'Cc*!' and line not in old]
            self.assertEqual(bad,[],name)

    def test_support_plumbing_no_fp_arithmetic_or_state_setters(self):
        body=(D.HERE/'amplitude_support.f90').read_text().lower()
        self.assertNotRegex(body,r'\b(ieee_set|feset|set_kinematic|sqrt|abs|log|exponent)\w*\s*\(')
        self.assertIn('maskr(64,pc_ik)',body)
        self.assertEqual(body.count('if(.not.pc_env_valid(env)) return'),2)
        self.assertIn('if(ishft(token,-64)/=0_pc_ik) return',body)
        self.assertNotIn('save',body)
        self.assertNotIn('common',body)


if __name__=='__main__':
    unittest.main(verbosity=2)
