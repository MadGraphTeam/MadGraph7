"""Freeze reviewed source dependencies only; no native commands."""
import json
from pathlib import Path
from derive_candidate import HERE,ROOT,GENERAL,GENERAL_SHA,DERIVED,DERIVED_SHA,load_seal,pin,require

FACTORY=ROOT/'.tirust-build/kinematic-invariant-caller-metadata-1'
FACTORY_SHA='aba903450f49e0e18ba3fff40dbf6074e1cd67e9af1c67cd83bbd6fd583c1047'
SOURCE=ROOT/'.tirust-build/kinematic-provenance-current-executor-1/source'
SOURCE_SHA='7ea709b48d8de462b754fabfb47dcbd5d21d7847458382f5844190028e8c1bed'
GUARD=SOURCE.parent/'build-admission-1'
GUARD_SHA='c30fefa33c13dc04cbeed5b12a6a44284d1fc4858c12aa569382ea8a8f8bf813'


def prepare():
    seals={str((p/'index.json').relative_to(ROOT)):s for p,s in
           [(GENERAL,GENERAL_SHA),(DERIVED,DERIVED_SHA),(FACTORY,FACTORY_SHA),(SOURCE,SOURCE_SHA),(GUARD,GUARD_SHA)]}
    for path,checksum in seals.items():load_seal(ROOT/path,checksum)
    deps=HERE/'dependencies';deps.mkdir(exist_ok=True)
    sources={'certificate.f90':GENERAL/'certificate.f90',
             **{name:FACTORY/name for name in ['caller_bounds.f90','cms_bounds_data.inc','environment_token.c']}}
    support={};copied={}
    for name,source in sources.items():
        target=deps/name;target.write_bytes(source.read_bytes())
        require(pin(target)==pin(source),'Dependency copy differs')
        support[name]={'path':str(target.relative_to(ROOT)),**pin(target)}
        copied[str(target.relative_to(ROOT))]={'path':str(source.relative_to(ROOT)),**pin(source)}
    source=HERE/'amplitude_support.f90'
    support[source.name]={'path':str(source.relative_to(ROOT)),**pin(source)}
    native=(SOURCE/'native_job.py').read_text()
    old="str(request['point']),str(int(request['trace_enabled']))]"
    require(native.count(old)==1,'Native worker argument source changed')
    native=native.replace(old,"str(request['point']),str(request['backend'])]")
    (HERE/'native_job.py').write_text(native)
    (HERE/'limit_exec.py').write_bytes((SOURCE/'limit_exec.py').read_bytes())
    donor=SOURCE.parent/'results/builds/cms-unmodified/build.json'
    compiler=Path('/nix/store/788mx070y81zjlg5ipcl0cra3afviw9k-gcc-wrapper-15.2.0/bin/gcc')
    toolchain={str(compiler):pin(compiler)}
    for path in sorted((compiler.parent.parent/'nix-support').iterdir()):
        if path.is_file():toolchain[str(path)]=pin(path)
    real=Path((compiler.parent.parent/'nix-support/orig-cc').read_text().strip())
    for path in [real/'bin/gcc',real/'libexec/gcc/x86_64-unknown-linux-gnu/15.2.0/cc1']:
        toolchain[str(path)]=pin(path)
    cbase=Path('/nix/store/15h9askp4k1lx44d9871wid23j2a8ijp-glibc-2.42-61-dev/include')
    header_names=[*(f'bits/{name}.h' for name in
        ['libc-header-start','long-double','stdint-intn','stdint-least','stdint-uintn',
         'time64','timesize','types','typesizes','wchar','wordsize']),
        'features-time64.h','features.h','gnu/stubs-64.h','gnu/stubs.h',
        'stdc-predef.h','stdint.h','sys/cdefs.h']
    headers={str(cbase/name):pin(cbase/name) for name in header_names}
    path=real/'lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/stdint.h'
    headers[str(path)]=pin(path)
    private=SOURCE.parent/'work/mg-current';extra={}
    for name in ['vendor/IREGI/src/libiregi.a','vendor/CutTools/includects/libcts.a','vendor/CutTools/includects/mpmodule.mod']:
        path=private/name;extra[str(path.resolve())]=pin(path)
    evidence=[donor,SOURCE/'stages_native.py',SOURCE/'native_job.py',SOURCE/'limit_exec.py',
              ROOT/'tools/tirust_benchmark.py',ROOT/'tests/parallel_tests/loop_me_comparator.py',SOURCE/'parity.py',
              ROOT/'.tirust-build/spacelike-kernel-native-qualification-1/summary.json',
              ROOT/'.tirust-build/caller-bound-native-qualification-1/build/result.json',
              ROOT/'.tirust-build/caller-bound-native-qualification-1/run/result.json']
    original_guard=json.loads((GUARD/'bindings.json').read_bytes())
    data={'schema':'private-cms-amplitude-proposal-bindings-v1','indices':seals,
          'files':{str(p.relative_to(ROOT)):pin(p) for p in evidence},
          'copied_dependencies':copied,'support_sources':support,
          'donor_build':{'path':str(donor.relative_to(ROOT)),**pin(donor)},
          'current_stages':{'path':str((SOURCE/'stages_native.py').relative_to(ROOT)),**pin(SOURCE/'stages_native.py')},
          'c_compiler':{'path':str(compiler),**pin(compiler)},'c_toolchain':toolchain,'c_headers':headers,
          'external_private_files':extra,
          'fixed_supplemental_providers':original_guard['supplemental_providers']}
    (HERE/'bindings.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    return data

if __name__=='__main__':
    data=prepare()
    print(json.dumps({'sealed_dependencies':len(data['indices']),
        'c_toolchain_files':len(data['c_toolchain']),'c_header_files':len(data['c_headers']),
        'native_executions':0},sort_keys=True))
