# Private CMS full-amplitude source candidate

This is an uncompiled private candidate for the current CMS export. It changes
no production template, reference checkout, model, physical card, installed
library, threshold, or rescue setting. It is not an accuracy result or a
production fix. All 26 generated routes and symbolic modes 1/2/4/5 are covered;
there is no point, momentum-bit, group-3, or event allowlist.

`derive_candidate.py` authenticates derived index25c21147 and general
mathematical proposal1665eff3 before reading their data, then authenticates all
269 original generated sources. It produces six complete candidate Fortran
files plus exact original-to-candidate patches and `source-proof.json`.
Provenance and replacement guards use explicit exceptions and remain active
under optimized Python. `amplitude_support.f90` is the thin kind/bit and
certificate adapter. The separately sealed caller-metadata dependency supplies
source-derived bounds, structural tables, and the tiny read-only x86_64
MXCSR/x87 probe. The mathematical certificate is copied byte-for-byte from
1665eff3; it has no floating-point arithmetic.

## Caller contract and source changes

The exact reference external vectors are the current external W/MP_W momentum
components after the existing repair and external wavefunction construction.
This does not assert accuracy relative to an unknown continuum phase-space
point. Unsigned occurrence counts preserve construction error even when signed
routing coefficients cancel. The actual first chord remains the computed
conservation residual. Modes2/5 use the independently derived reversed prefix
expressions; they never substitute a literal zero for the first chord.

`SLOOPMATRIX_RETRY_IMPL` keeps separate automatic DP and QP environment tokens,
initialized invalid on every entry. It captures a token before the actual
HELAS/MP producer. The private MP producer reports its existing
`COMPUTE_INTEGRAND_IN_QP` decision without changing that decision or numerical
body. A widened-DP QP producer is unknown/ineligible in this prototype. The
entry token and producer flag pass explicitly through the private
`LOOP_CT_CALLS_1` and all four `LOOP_N` forms. Their actual `LOOPNUM`, `WE`, and
`PAIRING` must agree with the pinned source route. No COMMON amplitude ID is
consulted to construct provenance. Fresh external complex words, route class,
chord bounds and eligibility are automatic locals passed explicitly.

The private TIRust diagnostics preserve original reversal, closure/prefix
sums, conservation guards, masses, scale, coefficient mapping, options and
symmetrization. After the actual shifts exist, the factory derives final
subtraction error bounds from their integer words. Environment controls must
still match the entry token. The probe performs `stmxcsr` and `fnstcw` only;
it never loads controls, clears flags or changes rounding. Non-nearest modes,
FTZ/DAZ, unsupported x87 precision, unknown platforms, nonfinite inputs,
nonreal leaves, route mismatch or missing provenance yield legacy fallback.
Source inspection of the pinned momentum-producing path and its callees finds
no rounding/underflow control setters; this static observation must still be
paired with the actual linked runtime and before/after controls in native
qualification. It does not assume the bridge or an arbitrary library preserves
the environment merely because compiler flags look suitable.

The original public DP/MP `BUILD_KINEMATIC_MATRIX` bodies remain byte-for-byte
unchanged. Ninja/NinjaRS and other legacy consumers keep those original
helpers. The new private helpers annotate backend9 only; this experiment makes
no claim that backend6/8 have adopted the changed invariant rule. Public TIRust
tensor diagnostic signatures remain compatible and supply unknown/no-bounds
metadata. Public tensor calls cannot inherit a previous amplitude route.

The private helper preserves the original default, mass-i, mass-j, zero branch
order and S representation. Either mass snap is latched. Only a supported
COMPOSITE off-diagonal pair with bounds, valid environment, no mass snap and a
strict integer spacelike certificate can veto the existing zero assignment.
The certificate is attempted only inside the original innermost zero branch;
ordinary composite rows that never reach it retain the original reconstruction.
Protected and unknown rows use the original complex subtraction/power syntax.
For eligible rows the same complex differences are captured before their
existing square/subtract operations. This storage/lowering change requires
native compiler and IEEE-flag parity; source inspection alone cannot prove it.

Only a successful zero veto sets `USE_DIRECT`; then the native TIRust invariant
is the captured raw real DIFFSQ. Every other row uses the original
`REAL(S_MAT+M_i+M_j)`, avoiding an unsolicited all-row rounding change. The
original S arithmetic remains available to its consumers. Direct output is
necessary because subtracting and readding large complex masses can erase the
small transfer. QP numerator contraction remains QP. The private QP contraction
receives the current group and split order explicitly. Original contraction,
normalization, failure flags and library calls are otherwise preserved.

## What has and has not been tested

The49 pure source, input, comparator and mocked-controller tests include checks of hash-before-parse failure, guards under Python
optimization, exact patch reproduction, all26 actual calls/mass order, unknown
public entrypoints, token placement, actual QP producer reporting, unchanged
legacy helpers/other-backend dispatch, direct-only zero veto, symmetry order,
bit-kind handling and fixed-form line bounds. These are source contract tests,
not a compiler or reducer test.

Independent source review checked120 internal call arities and59 definitions,
all26 modified route calls, and absence of other bound-source callers to the
modified LOOP_N signatures. It found and closed the assert-only source guard
issue. The caller metadata dependency has its own audit/tests and is pinned
separately; it is not qualified by these source tests.

Root separately compiled the unchanged integer certificate kernel with GNU
Fortran15.2.0 on4287 synthetic DP/QP bit cases. That test reported1572 accepted
cases, zero exact-enclosure false positives, zero coarse-reference mismatches,
and no IEEE sticky-flag changes across all32 flag combinations. Its summary is
pinned as narrow supporting evidence. That kernel test did not compile this
amplitude candidate and made no tensor calls. Root separately qualified the
unchanged caller factory and C probe on174 synthetic cases (all104 route/mode
combinations plus70 controls) and11 environment controls: zero reference
mismatches or observed IEEE-flag changes, with entry/final token
`4B4500001F80033F` unchanged. The build/run receipts are pinned. This establishes
standalone factory/probe readiness, not the full amplitude entry/use contract.

## Proposed separately reviewed build and run stages

`prepare_validation.py` authenticates source7ea709b4 and derived25c, then
materializes literal parameter cards, saved points, an inherited one-point
Fortran driver, and `validation-plan.json`. This preparation is pure. The dormant controller reuses the closed ownership, build/link, and worker
helpers. No native stage is admitted by source preparation or file-only
preflight. The driver uses the same bootstrap and measurement arithmetic,
now verifies explicit backend1 or9, and requires both QP-integrand switches.
It preserves exact Born/finite/single/double/accuracy words, all split orders,
fixed return codes, actual modes and the existing software failure flags.

1. After source/bound-factory review, create two private clones from the frozen
   CMS export: original and candidate. Use the same prepared driver in both.
   Retain the original model/DHELAS archives and installed reducer libraries.
   Reuse frozen original process objects except the common driver; in the
   candidate rebuild only the six changed objects and four support objects.
   Compile `certificate.f90`, `caller_bounds.f90` with `cms_bounds_data.inc`,
   the C token probe, then `amplitude_support.f90`; make the six changed
   candidate objects depend on these module files. Preserve the donor's
   compiler and flags (no fast math/reassociation change). Link only after
   freezing every object/archive/wrapper/system-provider input. Check actual
   PT_INTERP and its bytes before any `--list`; reconcile every provider with
   the prelink closure and fixed admitted supplements. Compare the two runtime
   provider sets. The proposed cap is3000s with60s cleanup reserve, existing
   shared mutex, two jobs and nonexclusive CPUs12–13. No Fortran main or tensor
   calls belong to this build stage. Any syntax or link failure is retained;
   a corrected source needs a new seal before another build.
2. After the closed build is independently reviewed, run exactly8 fresh
   ordinary workers: point1 × modes1/4 × explicit backends1/9 ×
   original/candidate. Each has exactly one ordinary bootstrap and one
   measurement, for16 outer entries maximum. Retain READY/DONE maps, actual
   library/precision evidence, terminal commands, protected-source checks and
   process/lock cleanup. The proposed ordinary cap is2400s including60s
   cleanup reserve, nonexclusive CPU12 and no automatic retry.
3. Only after ordinary closure/review, run exactly16 fresh stress workers:
   points20/21 × modes1/4 × backends1/9 × original/candidate,32 outer entries
   maximum. Proposed cap4800s including60s cleanup reserve; same worker policy.
   Total initial fixed-mode scope is24 workers/48 outer entries. All cards use
   LoopPoleMode0, finite enabled, TIRust cache0, CTModeInit1, unchanged
   CheckCycle3 and FORCE_STABILITY_CHECK(false). No extra bootstrap/readiness
   workaround, threshold or mass policy change is allowed. Post-call INIT
   values are restored observations, not an effective readiness gate.

First require exact original/candidate CutTools control parity, all output
columns and actual requested modes, finite values, no W03/incomplete-sum
warning and no DP/QP failed-contribution flag. A failed row remains retained
and excluded from coefficient/accuracy interpretation. Compare eligible
backend9 values with the same-source/backend1 control using the existing
MadLoop regression convention (3e-6 acceptance,1e-8 ordinary target), retaining
Born and each Laurent coefficient separately. Fixed110/120 returns are
unchecked diagnostic returns; they do not prove host stability. Reduction
success alone does not establish accuracy. A remaining stress failure is an
open diagnostic result, not permission to relax the gate or edit a fixture.

Normal MadLoop stability/rescue policy is a separate, subsequently bounded
stage after these fixed-mode diagnostics; it must use original host policy and
retain actual precision/backend usage. Modes2/5, further models/processes,
full-suite performance, and general exporter integration remain unqualified.
Any future decision trace must be source-reviewed and byte-bounded, cover all
applicable source routes rather than a point/group allowlist, and record
inputs/status without treating failed tensor buffers as results. Precise
performance acceptance remains Hua-Sheng's local-machine TODO.

The dormant `run.py` requires `--reviewed-source-index` even for file-only
preflight. It accepts exactly one of `build`, `ordinary`, or `stress` with an
explicit `--execute`. Ordinary additionally requires the closed-build SHA256;
stress requires both closed-build and closed-ordinary SHA256. There is no
automatic stage continuation or retry. Worker limits are the inherited8GiB
address space,64MiB file cap,32MiB stdout cap,180s bootstrap/300s measurement
timeouts and600s owned-command cap. Every loader query, command/log, maps,
worker output and protected before/after receipt is retained in an append-only
stage closure.

The tiny C probe also receives an explicit21-file compiler/wrapper binding and
a19-header allowlist. The prospective build first runs one owned dependency
query, rejects any header outside that list, and hashes inputs before/after
compilation. It keeps the factory's sealed C source unchanged.

Commands after separate review (replace each SHA with the reviewed exact seal):

```sh
source tools/tirust_env.sh
python3 -B .tirust-build/kinematic-invariant-amplitude-proposal-1/run.py build \
  --reviewed-source-index SOURCE_SHA                 # file-only preflight
# Only after explicit build admission:
python3 -B .tirust-build/kinematic-invariant-amplitude-proposal-1/run.py build \
  --reviewed-source-index SOURCE_SHA --execute
# Only after closed build and separate ordinary admission:
python3 -B .tirust-build/kinematic-invariant-amplitude-proposal-1/run.py ordinary \
  --reviewed-source-index SOURCE_SHA --reviewed-build-sha256 BUILD_SHA --execute
# Only after closed ordinary and separate stress admission:
python3 -B .tirust-build/kinematic-invariant-amplitude-proposal-1/run.py stress \
  --reviewed-source-index SOURCE_SHA --reviewed-build-sha256 BUILD_SHA \
  --reviewed-ordinary-sha256 ORDINARY_SHA --execute
```

The pure output comparator preserves the existing LoopMEComparator criterion:
`abs(a-b)/abs(a+b)<3e-6`, with its existing small-pole-to-finite exception. It
also reports `abs(a-b)/max(abs(a),abs(b))` as a separate diagnostic residual;
it does not silently substitute that metric for the regression gate.
`candidate_gate_passed` can record a valid candidate/control comparison while
the strict stage remains failed because original TIRust stress contributions
failed. Such original failures remain explicitly recorded and never decoded
as valid coefficients.
