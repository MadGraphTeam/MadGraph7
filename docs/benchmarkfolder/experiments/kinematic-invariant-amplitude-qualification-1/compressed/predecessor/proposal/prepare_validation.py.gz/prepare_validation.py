"""Pure prospective input/driver preparation. Never executes native stages."""
import difflib
import json
from pathlib import Path
from derive_candidate import HERE,ROOT,DERIVED,DERIVED_SHA,load_seal,once,pin,require

SOURCE=ROOT/'.tirust-build/kinematic-provenance-current-executor-1/source'
SOURCE_SHA='7ea709b48d8de462b754fabfb47dcbd5d21d7847458382f5844190028e8c1bed'


def outputs():
    load_seal(SOURCE/'index.json',SOURCE_SHA)
    load_seal(DERIVED/'index.json',DERIVED_SHA)
    records={}
    result={}
    for name in ['cms-param_card.dat','cms-point1.dat','cms-point20.dat','cms-point21.dat']:
        path=SOURCE/'inputs'/name
        records[str(path.relative_to(ROOT))]=pin(path)
        result['inputs/'+name]=path.read_bytes()
    for mode in [1,4]:
        path=SOURCE/'inputs'/f'cms-mode{mode}-MadLoopParams.dat'
        records[str(path.relative_to(ROOT))]=pin(path)
        raw=path.read_text()
        for backend in [1,9]:
            text=raw if backend==9 else once(raw,'#MLReductionLib\n9\n','#MLReductionLib\n1\n')
            result[f'inputs/cms-backend{backend}-mode{mode}-MadLoopParams.dat']=text.encode()
    path=DERIVED/'cms/driver-unmodified.f'
    records[str(path.relative_to(ROOT))]=pin(path)
    original=path.read_text()
    driver=original.replace('TRACE_ON','BACKEND')
    driver=once(driver,'C     Args: bootstrap measurement mode point trace-enabled fifo.',
                'C     Args: bootstrap measurement mode point backend(1/9) fifo.')
    driver=once(driver,"IF(TRIM(ARG).NE.'0'.AND.TRIM(ARG).NE.'1') STOP 21",
                "IF(TRIM(ARG).NE.'1'.AND.TRIM(ARG).NE.'9') STOP 21")
    driver=driver.replace('KTRACE_DRIVER_CARD(MODE)','KTRACE_DRIVER_CARD(MODE,BACKEND)')
    driver=once(driver,'      INTEGER MODE\n','      INTEGER MODE,BACKEND\n')
    driver=once(driver,'MLReductionLib(1).NE.9.OR.MLReductionLib(2).NE.0)',
                'MLReductionLib(1).NE.BACKEND.OR.MLReductionLib(2).NE.0)')
    driver=once(driver,'      IF(.NOT.UseQPIntegrandForTIRust) STOP 24',
                '      IF(.NOT.UseQPIntegrandForTIRust) STOP 24\n'
                '      IF(.NOT.UseQPIntegrandForCutTools) STOP 24')
    driver=once(driver,'      CALL KTRACE_DRIVER_CONTROL(BACKEND.EQ.1,76,POINT_ID)',
                '      CALL KTRACE_DRIVER_CONTROL(.FALSE.,76,POINT_ID)')
    result['driver-amplitude.f']=driver.encode()
    result['driver-amplitude.f.patch']=''.join(difflib.unified_diff(
        original.splitlines(True),driver.splitlines(True),
        fromfile='derived25c/driver-unmodified.f',tofile='proposal/driver-amplitude.f')).encode()
    requests=[]
    for point in [1,20,21]:
        for mode in [1,4]:
            for backend in [1,9]:
                for variant in ['original','candidate']:
                    requests.append({'id':f'cms-p{point}-mode{mode}-lib{backend}-{variant}',
                        'stage':'ordinary' if point==1 else 'stress','variant':variant,
                        'backend':backend,'requested_mode':mode,'point':point,
                        'bootstrap':'inputs/cms-point1.dat',
                        'measurement':f'inputs/cms-point{point}.dat',
                        'card':f'inputs/cms-backend{backend}-mode{mode}-MadLoopParams.dat',
                        'physical_card':'inputs/cms-param_card.dat',
                        'expected_fixed_unchecked_return':{1:110,4:120}[mode],
                        'outer_entries_max':2,'bootstrap_calls':1,'measurement_calls':1})
    plan={'schema':'private-cms-amplitude-prospective-validation-v1',
        'native_admitted':False,'native_executed':False,'controller_implemented':True,
        'build':{'separate_review_before_execution':True,'variants':['original','candidate'],
                 'executables':2,'seconds_total':3000,'cleanup_reserve_seconds':60,
                 'nonexclusive_cpus':[12,13],'shared_mutex':True,'jobs':2,
                 'library_rebuilds':False,'native_main_calls':0,
                 'loader_queries_allowed_only_after_bound_PT_INTERP':True},
        'ordinary':{'separate_review_before_execution':True,'fresh_workers':8,'outer_entries_max':16,
                    'seconds_total':2400,'cleanup_reserve_seconds':60,'cpu':12},
        'stress':{'separate_review_after_closed_ordinary':True,'fresh_workers':16,'outer_entries_max':32,
                  'seconds_total':4800,'cleanup_reserve_seconds':60,'cpu':12},
        'total_fresh_workers':24,'total_outer_entries_max':48,
        'worker_address_space_max_bytes':8589934592,'worker_file_max_bytes':67108864,
        'worker_stdout_max_bytes':33554432,'worker_bootstrap_timeout_seconds':180,
        'worker_measurement_timeout_seconds':300,'owned_worker_command_cap_seconds':600,
        'modes_2_5_native_qualified':False,'normal_host_stability_separate_future_stage':True,
        'no_autoretry_or_extra_bootstrap':True,'performance_measurement':False,
        'requests':requests,'source_inputs':records}
    result['validation-plan.json']=(json.dumps(plan,indent=2,sort_keys=True)+'\n').encode()
    return result


if __name__=='__main__':
    for name,raw in outputs().items():
        path=HERE/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    print('Prepared prospective driver, literal cards and24 requests; no controller/native execution.')
