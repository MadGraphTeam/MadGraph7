"""Dormant two-ELF CMS build using the sealed trace executor's link machinery.

The admitting controller supplies PC_HERE, PC_BINDINGS, PC_SAVE and PC_RUNTIME
on its authenticated old-run module.  Importing this file executes no commands.
PC_RUNTIME must establish the declared PT_INTERP and bound provider bytes before
the inherited loader query.  There is no main-program execution in this stage.
"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import shlex


CHANGED = ('CT_interface.f', 'TIRUST_interface.f', 'TIR_interface.f',
           'loop_matrix.f', 'loop_CT_calls_1.f', 'mp_compute_loop_coefs.f')
SUPPORT = ('certificate.f90', 'caller_bounds.f90', 'cms_bounds_data.inc',
           'environment_token.c', 'amplitude_support.f90')
SUPPORT_OBJECTS = ('certificate.o', 'caller_bounds.o', 'amplitude_support.o',
                   'environment_token.o')
SUBPROCESS = 'P0_epem_mupmum'
C_COMPILER = '/nix/store/788mx070y81zjlg5ipcl0cra3afviw9k-gcc-wrapper-15.2.0/bin/gcc'
STAGES_SHA = '36df905968a0973b38623a4d73c0cbd75e376222f30893f5ad72a3f6322e2260'
DONOR_SHA = 'f2fa4bca41563cfbe40c441ce20c473aed5a7aa3b372407637412e6ebeb7bc53'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def record(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def verify(path, pin):
    require(record(path) == {k: pin[k] for k in ('bytes', 'sha256')},
            'Pinned file differs: ' + str(path))


def bound_path(r, item):
    path = Path(item['path'])
    return path if path.is_absolute() else Path(r.ROOT) / path


def write_private(output, path, raw):
    """Replace only a literal file in the new tree, never a donor link target."""
    output, path = Path(output), Path(path)
    require(path.is_relative_to(output), 'Write outside private output')
    require(path.parent.resolve().is_relative_to(output.resolve()),
            'Write through an external directory link')
    if path.is_symlink():
        require(path.resolve().is_relative_to(output.resolve()),
                'Refuse replacement of an external source/card link')
        path.unlink()
    if path.exists():
        require(path.is_file(), 'Expected private regular file')
        path.unlink()
    with path.open('xb') as stream:
        stream.write(raw)


def literal_cards(r, output):
    for name, source in (('param_card.dat', 'cms-param_card.dat'),
                         ('MadLoopParams.dat', 'cms-backend9-mode1-MadLoopParams.dat')):
        raw = (Path(r.PC_HERE) / 'inputs' / source).read_bytes()
        paths = {output / 'Cards' / name}
        paths.update((output / 'SubProcesses').rglob(name))
        for path in sorted(paths):
            write_private(output, path, raw)


def clone(r, source, output):
    # The old clone's WORK now points at this executor.  Admit exactly the old
    # generated private prerequisite files, not their enclosing directories.
    extra = r.PC_BINDINGS['external_private_files']
    expected = {
        str(Path(r.ROOT) / '.tirust-build/kinematic-provenance-current-executor-1/work/mg-current' / name)
        for name in ('vendor/IREGI/src/libiregi.a',
                     'vendor/CutTools/includects/libcts.a',
                     'vendor/CutTools/includects/mpmodule.mod')}
    require(set(extra) == expected, 'Private dependency allowance differs')
    for path, pin in extra.items():
        verify(path, pin)
    admitted = r.dependency_snapshot()
    require(all(admitted.get(path) == pin for path, pin in extra.items()),
            'Controller did not admit the exact private prerequisite files')
    return r.private_clone(source, output, keep_objects=True)


def make_addition(candidate):
    targets = [Path(name).with_suffix('.o').name for name in CHANGED]
    if not candidate:
        return '\n.PHONY: pc-objects\npc-objects: check_sa.o\n'
    objects = ' '.join(SUPPORT_OBJECTS)
    return '''
# Private source-only proposal: module order, unchanged numerical FC/FFLAGS.
PROCESS += {objects}
.PHONY: pc-objects
pc-objects: {targets} {objects}
check: {objects}
certificate.o: certificate.f90
\t$(FC) $(FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)
caller_bounds.o: caller_bounds.f90 cms_bounds_data.inc
\t$(FC) $(FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)
amplitude_support.o: amplitude_support.f90 certificate.o caller_bounds.o
\t$(FC) $(FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)
environment_token.o: environment_token.c
\t{cc} -fPIC -O2 -c $< -o $@
{targets}: amplitude_support.o
'''.format(objects=objects, targets=' '.join(targets), cc=C_COMPILER)


def object_inventory(output):
    return {str(path.relative_to(output)): record(path)
            for path in sorted(Path(output).rglob('*.o')) if path.is_file()}


def library_inventory(output):
    """Pin reused export archives/shared libraries, including external aliases."""
    return {str(path.relative_to(output)): record(path)
            for path in sorted((Path(output) / 'lib').rglob('*'))
            if path.is_file() and (path.suffix == '.a' or '.so' in path.name)}


def preserved_objects(before, after, changed):
    require(set(before) <= set(after), 'A reused object disappeared')
    changed_paths = {str(Path('SubProcesses') / SUBPROCESS / name) for name in changed}
    for path, pin in before.items():
        if path not in changed_paths:
            require(after[path] == pin, 'Unchanged object differs: ' + path)


def verify_c_toolchain(r):
    require(r.PC_BINDINGS['c_toolchain'].get(C_COMPILER) ==
            {k: r.PC_BINDINGS['c_compiler'][k] for k in ('bytes', 'sha256')},
            'C compiler omitted from toolchain closure')
    for path, pin in r.PC_BINDINGS['c_toolchain'].items():
        verify(path, pin)
    require(len(r.PC_BINDINGS['c_headers']) == 19, 'C header admission set differs')
    for path, pin in r.PC_BINDINGS['c_headers'].items():
        verify(path, pin)


def parse_c_dependencies(raw, directory, headers):
    """Parse only this probe's ordinary GCC -M output; never admit new headers."""
    require(len(raw) <= 65536, 'C dependency output exceeds bound')
    joined = raw.replace('\\\n', ' ')
    require(joined.count(':') == 1 and joined.startswith('pc-environment-token:'),
            'Unexpected C dependency target/format')
    names = shlex.split(joined.split(':', 1)[1])
    source = str(directory / 'environment_token.c')
    paths = [str(directory / name) if not Path(name).is_absolute() else name
             for name in names]
    require(len(paths) == len(set(paths)) and source in paths,
            'Missing/repeated probe dependency')
    require(set(paths) <= set(headers) | {source} and len(paths) > 1,
            'Unadmitted C header dependency')
    return paths


def capture_c_dependencies(r, directory, label, destination):
    argv = [C_COMPILER, '-fPIC', '-O2', '-M', '-MT',
            'pc-environment-token', 'environment_token.c']
    result = {'argv': argv, 'cwd': str(directory), 'passed': False}
    failure = None
    try:
        verify_c_toolchain(r)
        raw = r.command(argv, label, directory, 30)
        result['raw'] = raw
        paths = parse_c_dependencies(raw, directory, r.PC_BINDINGS['c_headers'])
        verify_c_toolchain(r)
        result['actual_dependencies'] = {path: record(path) for path in paths}
        result['passed'] = True
        return result
    except BaseException as exc:
        failure = repr(exc)
        raise
    finally:
        result['failure'] = failure
        r.PC_SAVE(destination, result)


def link_one(r, stages, output, variant, donor, compiled_targets):
    """Retain link_variant's flags/prelink/LOAD checks; narrow only build targets."""
    directory = output / 'SubProcesses' / SUBPROCESS
    label = 'cms-' + variant
    result_dir = Path(r.RESULTS) / 'builds' / variant
    before_objects = object_inventory(output)
    libraries = library_inventory(output)
    source_before = r.source_inventory(output)
    before_modules = {str(p.relative_to(output)): record(p)
                      for p in output.rglob('*.mod') if p.is_file()}
    changed = set(compiled_targets)
    for name in changed:
        path = directory / name
        require(not path.is_symlink(), 'Object output is a symlink')
        path.unlink(missing_ok=True)
    frozen = [str(directory / Path(name).name) for name in before_objects
              if Path(name).parent == Path('SubProcesses') / SUBPROCESS
              and Path(name).name not in changed]
    # Make uses both local object names and absolute library names.  Declare
    # each spelling old; a link must never rebuild copied archives or objects.
    frozen += [Path(name).name for name in frozen]
    frozen += [str(output / name) for name in libraries]
    frozen += [name for name in donor['prelink_bound']
               if Path(name).suffix == '.a' or '.so' in Path(name).name]
    frozen += ['libcollier.so']
    freeze_compile = ['--old-file=' + name for name in sorted(set(frozen))]
    freeze_link = freeze_compile + ['--old-file=' + name for name in sorted(changed)]
    commands = []
    compile_seen = link_seen = runtime_seen = False
    c_dependencies = None
    old_save, old_results = stages.save, stages.RESULTS
    proxy = SimpleNamespace(**vars(r))
    proxy.L = SimpleNamespace(**vars(r.L))

    def save(path, data):
        path = Path(path)
        expected = Path(r.RESULTS) / 'builds' / label
        require(path.parent == expected, 'Unexpected inherited build receipt path')
        target = result_dir / path.name
        if path.name == 'build.json':
            target = result_dir / 'link-variant-receipt.json'
            data = dict(data, unmodified_numerical_arithmetic=(variant == 'original'))
        r.PC_SAVE(target, data)

    def command(argv, command_label, cwd=directory, seconds=600):
        nonlocal compile_seen, link_seen, c_dependencies
        args = [str(x) for x in argv]
        if command_label == 'compile-' + label:
            require(not compile_seen and args ==
                    ['make', '-B', '-j2', '-f', 'ktrace.mk', 'trace-objects'],
                    'Unexpected/repeated inherited compile command')
            compile_seen = True
            if variant == 'candidate':
                c_dependencies = capture_c_dependencies(
                    r, directory, 'c-dependencies-' + label,
                    result_dir / 'c-dependencies.json')
                commands.append({'label': 'c-dependencies-' + label,
                                 'argv': c_dependencies['argv'], 'cwd': str(directory)})
            args = ['make', '--no-print-directory', '-j2', *freeze_compile, 'pc-objects']
        elif command_label == 'link-' + label:
            require(not link_seen and args[:3] == ['make', '-j2', 'check'],
                    'Unexpected/repeated inherited link command')
            link_seen = True
            args = ['make', '-j2', *freeze_link, *args[2:]]
        commands.append({'label': command_label, 'argv': args, 'cwd': str(cwd)})
        return r.command(args, command_label, cwd, seconds)

    def runtime(executable, deadline=None):
        nonlocal runtime_seen
        require(not runtime_seen and Path(executable) == directory / 'check',
                'Unexpected/repeated build loader query')
        runtime_seen = True
        prelink = json.loads((result_dir / 'prelink.json').read_bytes())
        require(prelink['completed_before_link'], 'Missing prelink admission')
        return r.PC_RUNTIME(Path(executable), prelink['bound'], variant,
                            closed=donor['runtime'])

    proxy.command = command
    proxy.L.runtime = runtime
    failure = None
    receipt = None
    try:
        stages.save, stages.RESULTS = save, Path(r.RESULTS)
        receipt = stages.link_variant(proxy, 'cms', variant, output, changed_only=False)
        require(compile_seen and link_seen and runtime_seen, 'Incomplete build sequence')
        after_objects = object_inventory(output)
        preserved_objects(before_objects, after_objects, changed)
        require(library_inventory(output) == libraries, 'Reused archive/library changed')
        r.exact_inventory(output, source_before)
        require(receipt['runtime']['files'] == donor['runtime']['files'],
                'Build providers differ from closed original CMS')
        require(all((directory / name).is_file() for name in compiled_targets),
                'Missing explicitly compiled object')
        if variant == 'candidate':
            verify_c_toolchain(r)
            require(c_dependencies is not None and c_dependencies['passed'],
                    'C compilation lacked its dependency admission')
            for path, pin in c_dependencies['actual_dependencies'].items():
                verify(path, pin)
        changed_paths = {str(Path('SubProcesses') / SUBPROCESS / name) for name in changed}
        receipt.update(unmodified_numerical_arithmetic=(variant == 'original'),
                       compiled_targets=list(compiled_targets),
                       preserved_object_hashes={name: pin for name, pin in before_objects.items()
                                                if name not in changed_paths},
                       all_objects_after=after_objects, reused_libraries=libraries,
                       module_inputs=before_modules,
                       modules_after={str(p.relative_to(output)): record(p)
                                      for p in output.rglob('*.mod') if p.is_file()},
                       c_dependencies=c_dependencies,
                       build_commands=commands, fortran_main_calls=0,
                       tensor_evaluations=0, library_rebuilds=False,
                       independent_accuracy_qualified=False, performance_measurement=False)
        r.PC_SAVE(result_dir / 'build.json', receipt)
        return receipt
    except BaseException as exc:
        failure = repr(exc)
        raise
    finally:
        stages.save, stages.RESULTS = old_save, old_results
        r.PC_SAVE(result_dir / 'attempt.json', {
            'failure': failure, 'compile_seen': compile_seen, 'link_seen': link_seen,
            'runtime_seen': runtime_seen, 'sources_before': source_before,
            'objects_before': before_objects, 'reused_libraries_before': libraries,
            'commands': commands, 'c_dependencies': c_dependencies,
            'fortran_main_calls': 0, 'tensor_evaluations': 0})


def build(r):
    bindings = r.PC_BINDINGS
    require(callable(r.PC_RUNTIME) and callable(r.PC_SAVE), 'Controller guard/save missing')
    require(bindings['c_compiler']['path'] == C_COMPILER, 'Unreviewed C compiler')
    verify_c_toolchain(r)
    donor_path = bound_path(r, bindings['donor_build'])
    verify(donor_path, bindings['donor_build'])
    require(bindings['donor_build']['sha256'] == DONOR_SHA, 'Unreviewed CMS build')
    donor = json.loads(donor_path.read_bytes())
    donor_output = Path(donor['output'])
    r.exact_inventory(donor_output, donor['sources'])
    r.L.q.verify_hashes(donor['prelink_bound'])
    for name, digest in donor['objects'].items():
        require(record(donor_output / name)['sha256'] == digest, 'Closed process object differs')
    donor_libraries = library_inventory(donor_output)
    for name in ('libmodel.a', 'libdhelas.a'):
        path = donor_output / 'lib' / name
        require(donor_libraries['lib/' + name]['sha256'] ==
                donor['prelink_bound'].get(str(path.resolve())),
                'Internal archive missing from closed prelink pins: ' + name)
    stages_path = bound_path(r, bindings['current_stages'])
    verify(stages_path, bindings['current_stages'])
    require(bindings['current_stages']['sha256'] == STAGES_SHA, 'Unreviewed native-stage helper')
    stages = r.load('pc_amplitude_retained_stages', stages_path)
    require(set(bindings['support_sources']) == set(SUPPORT), 'Support source set differs')
    for item in bindings['support_sources'].values():
        verify(bound_path(r, item), item)
    dependencies = r.dependency_snapshot()
    root = Path(r.WORK) / 'builds' / 'cms'
    require(not root.exists(), 'Fresh two-variant build required; no retries')
    root.mkdir(parents=True)
    proof = json.loads((Path(r.PC_HERE) / 'source-proof.json').read_bytes())
    result = {}
    for variant in ('original', 'candidate'):
        output = clone(r, donor_output if variant == 'original' else root / 'original', root / variant)
        require(library_inventory(output) == donor_libraries,
                'Cloned libraries differ from closed donor')
        directory = output / 'SubProcesses' / SUBPROCESS
        literal_cards(r, output)
        write_private(output, directory / 'check_sa.f', (Path(r.PC_HERE) / 'driver-amplitude.f').read_bytes())
        if variant == 'candidate':
            for name in CHANGED:
                source = Path(r.PC_HERE) / 'candidate' / name
                verify(source, proof['candidate'][name])
                write_private(output, directory / name, source.read_bytes())
            for name, item in bindings['support_sources'].items():
                source = bound_path(r, item)
                verify(source, item)
                write_private(output, directory / name, source.read_bytes())
        # Start from the original, pinned makefile for each variant.  Never
        # append the original variant's overlay a second time to its clone.
        make = (donor_output / 'SubProcesses' / SUBPROCESS / 'makefile').read_bytes()
        write_private(output, directory / 'makefile', make + make_addition(variant == 'candidate').encode())
        targets = (('check_sa.o',) if variant == 'original' else
                   tuple(Path(name).with_suffix('.o').name for name in CHANGED) + SUPPORT_OBJECTS)
        result[variant] = link_one(r, stages, output, variant, donor, targets)
        if variant == 'original':
            preserved_objects({name: {'sha256': digest} for name, digest in donor['objects'].items()},
                              {name: {'sha256': pin['sha256']} for name, pin in result[variant]['all_objects_after'].items()},
                              {'check_sa.o'})
        else:
            preserved_objects(result['original']['all_objects_after'],
                              result['candidate']['all_objects_after'], set(targets))
    require(result['original']['runtime']['files'] == result['candidate']['runtime']['files'],
            'Original/candidate shared providers differ')
    require(dependencies == r.dependency_snapshot(), 'Installed dependency changed during build')
    r.PC_SAVE(Path(r.RESULTS) / 'build-summary.json', {
        'variants': {name: {'receipt': record(Path(r.RESULTS) / 'builds' / name / 'build.json'),
                            'executable': item['executable'], 'executable_pin': item['executable_pin']}
                     for name, item in result.items()},
        'donor_build': record(donor_path), 'retained_link_helper': record(stages_path),
        'c_compiler': bindings['c_compiler'], 'c_toolchain': bindings['c_toolchain'],
        'executables': 2, 'loader_queries': 2,
        'native_main_calls': 0, 'tensor_evaluations': 0, 'library_rebuilds': False,
        'independent_accuracy_qualified': False, 'performance_measurement': False})
    return result
