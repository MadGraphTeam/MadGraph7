"""Private, pure source transform. Never builds, loads, evaluates or patches donors."""
from pathlib import Path
import difflib
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DERIVED = ROOT/'.tirust-build/kinematic-provenance-current-executor-1/results/derived'
GENERAL = ROOT/'.tirust-build/kinematic-invariant-general-proposal-1'
DERIVED_SHA = '25c2114756ed3eb968c311945a27d175c5c5a0af54d4ae21158abc8ed42a4184'
GENERAL_SHA = '1665eff3188c947f35673b958cd0f02525fd031dc814b708dfdda69160b57964'
SUB = ROOT/'.tirust-build/kinematic-provenance-current-executor-1/work/exports/cms/SubProcesses/P0_epem_mupmum'


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def pin(path):
    raw = path.read_bytes()
    return {'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}


def load_seal(path, sha):
    require(pin(path)['sha256'] == sha, ('sealed index mismatch', str(path)))
    data = json.loads(path.read_bytes())
    for name, expected in data['files'].items():
        require(not name.startswith('/') and '..' not in Path(name).parts, name)
        require(pin(path.parent/name) == expected, ('sealed payload mismatch', name))
    return data


def donor_sources():
    load_seal(DERIVED/'index.json', DERIVED_SHA)
    load_seal(GENERAL/'index.json', GENERAL_SHA)
    binding = json.loads((DERIVED/'cms-source-bindings.json').read_bytes())
    for name, expected in binding['files'].items():
        require(pin(ROOT/name) == expected, ('source binding mismatch', name))
    names = ['CT_interface.f', 'TIRUST_interface.f', 'TIR_interface.f',
             'loop_matrix.f', 'loop_CT_calls_1.f', 'mp_compute_loop_coefs.f']
    result = {}
    for name in names:
        path = SUB/name
        require(str(path.relative_to(ROOT)) in binding['files'], str(path))
        result[name] = path.read_text()
    return result


def once(text, before, after):
    require(text.count(before) == 1, ('source anchor count', text.count(before), before))
    return text.replace(before, after)


def subroutine(text, name):
    start = text.index('      SUBROUTINE '+name+'(')
    match = re.search(r'^      END\s*$', text[start:], re.M)
    require(match is not None, ('missing subroutine end', name))
    return text[start:start+match.end()]


def replace_subroutine(text, name, replacement):
    return once(text, subroutine(text, name), replacement)


# All new explicit-shape arguments. No optional ABI or saved metadata context.
CONTRACT_ARGS = ',PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV'
CONTRACT_DECL = '''      INTEGER PC_CHORD(0:3,NLOOPLINE)
      INTEGER PC_CLASS(NLOOPLINE,NLOOPLINE)
      LOGICAL PC_HAVE(NLOOPLINE)
      INTEGER(PC_IK) PC_ENV
'''
CONTRACT_USE = '''      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,
     $ PC_ENV_VALID,PC_DIFFERENCE_BOUNDS,PC_DP_BITS,PC_QP_BITS
'''


def masked_helper(original, qp):
    prefix = 'ML5_0_MP_' if qp else 'ML5_0_'
    name = prefix+'BUILD_KINEMATIC_MATRIX'
    core = prefix+'PRIVATE_KINEMATIC_MATRIX'
    body = subroutine(original, name)
    body = once(body, '      SUBROUTINE '+name+'(NLOOPLINE,P_LOOP,M2L\n     $ ,S_MAT)',
        '      SUBROUTINE '+core+'(NLOOPLINE,P_LOOP,M2L,\n'
        '     $ PC_CLASS,PC_QERROR,PC_HAVE,PC_ENV,S_MAT,PC_DIRECT,PC_USE)\n'
        '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,\n'
        '     $ PC_CERTIFY_DP,PC_CERTIFY_QP,PC_ENV_VALID')
    real = 'REAL*16' if qp else 'REAL*8'
    cmplx = 'COMPLEX*32' if qp else 'COMPLEX*16'
    body = once(body, '      INTEGER I,J,K\n',
        '      INTEGER I,J,K\n'
        '      INTEGER PC_CLASS(NLOOPLINE,NLOOPLINE)\n'
        '      INTEGER PC_QERROR(0:3,NLOOPLINE,NLOOPLINE)\n'
        '      LOGICAL PC_HAVE(NLOOPLINE,NLOOPLINE)\n'
        '      INTEGER(PC_IK) PC_ENV\n'
        '      LOGICAL PC_USE(NLOOPLINE,NLOOPLINE),PC_MASS_SNAP\n'
        f'      {real} PC_DIRECT(NLOOPLINE,NLOOPLINE)\n'
        f'      {cmplx} PC_Q(0:3)\n')
    body = once(body, '      DO I=1,NLOOPLINE\n',
        '      PC_USE=.FALSE.\n      PC_DIRECT=0\n'
        '      DO I=1,NLOOPLINE\n')
    if qp:
        old = '''            DIFFSQ = (CMPLX(P_LOOP(I,0),0.0E0_16,KIND=16)
     $       -CMPLX(P_LOOP(J,0),0.0E0_16,KIND=16))**2
            DO K=1,3
              DIFFSQ = DIFFSQ - (CMPLX(P_LOOP(I,K),0.0E0_16,KIND=16)
     $         -CMPLX(P_LOOP(J,K),0.0E0_16,KIND=16))**2
            ENDDO'''
        new = '''            PC_Q(0) = (CMPLX(P_LOOP(I,0),0.0E0_16,KIND=16)
     $       -CMPLX(P_LOOP(J,0),0.0E0_16,KIND=16))
            DIFFSQ = PC_Q(0)**2
            DO K=1,3
              PC_Q(K) = (CMPLX(P_LOOP(I,K),0.0E0_16,KIND=16)
     $         -CMPLX(P_LOOP(J,K),0.0E0_16,KIND=16))
              DIFFSQ = DIFFSQ - PC_Q(K)**2
            ENDDO'''
    else:
        old = '''            DIFFSQ = (DCMPLX(P_LOOP(I,0),0.0D0)-DCMPLX(P_LOOP(J,0)
     $       ,0.0D0))**2
            DO K=1,3
              DIFFSQ = DIFFSQ - (DCMPLX(P_LOOP(I,K),0.0D0)
     $         -DCMPLX(P_LOOP(J,K),0.0D0))**2
            ENDDO'''
        new = '''            PC_Q(0) = (DCMPLX(P_LOOP(I,0),0.0D0)-DCMPLX(P_LOOP(J,0)
     $       ,0.0D0))
            DIFFSQ = PC_Q(0)**2
            DO K=1,3
              PC_Q(K) = (DCMPLX(P_LOOP(I,K),0.0D0)
     $         -DCMPLX(P_LOOP(J,K),0.0D0))
              DIFFSQ = DIFFSQ - PC_Q(K)**2
            ENDDO'''
    new = ('            PC_Q=0\n'
           '            IF(PC_CLASS(I,J).EQ.2.AND.PC_HAVE(I,J)\n'
           '     $       .AND.PC_ENV_VALID(PC_ENV)) THEN\n'+new+
           '\n            ELSE\n'+old+'\n            ENDIF')
    body = once(body, old, new)
    body = once(body, '            S_MAT(I,J)=DIFFSQ-M2L(I)-M2L(J)',
        '            S_MAT(I,J)=DIFFSQ-M2L(I)-M2L(J)\n'
        '            PC_MASS_SNAP=.FALSE.')
    for target in ['J', 'I']:
        body = once(body, f'                S_MAT(I,J)=-M2L({target})',
            f'                S_MAT(I,J)=-M2L({target})\n'
            '                PC_MASS_SNAP=.TRUE.')
    cert = 'PC_CERTIFY_QP' if qp else 'PC_CERTIFY_DP'
    body = once(body, '                S_MAT(I,J)=-(M2L(I)+M2L(J))',
        f'                PC_USE(I,J)={cert}(PC_Q,DIFFSQ,\n'
        '     $           PC_QERROR(:,I,J),PC_CLASS(I,J),PC_MASS_SNAP,\n'
        '     $           PC_HAVE(I,J),PC_ENV)\n'
        '                IF(PC_USE(I,J)) THEN\n'
        '                  PC_DIRECT(I,J)=REAL(DIFFSQ,KIND='
          +('16' if qp else '8')+')\n'
        '                ELSE\n'
        '                  S_MAT(I,J)=-(M2L(I)+M2L(J))\n'
        '                ENDIF')
    return body


def tensor_core(original, qp):
    prefix = 'ML5_0_MP_' if qp else 'ML5_0_'
    name = prefix+'TIRUST_TENSOR_DIAGNOSTIC'
    core = prefix+'PRIVATE_TIRUST_DIAGNOSTIC'
    body = subroutine(original, name)
    body = once(body, name, core)
    # Both wrapped generated headers end with this exact tail.
    body = once(body, ',PL,M2L,TIRCOEFS,STABLE)',
        ',PL,M2L,TIRCOEFS,STABLE,\n     $ PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)')
    body = once(body, '      USE MTIRUST\n', '      USE MTIRUST\n'+CONTRACT_USE)
    real = 'REAL*16' if qp else 'REAL*8'
    body = once(body, '      LOGICAL STABLE,CACHE_ENABLED,CHECK_PASS\n',
        '      LOGICAL STABLE,CACHE_ENABLED,CHECK_PASS\n'+CONTRACT_DECL+
        '      INTEGER PC_QERROR(0:3,NLOOPLINE,NLOOPLINE)\n'
        '      INTEGER(PC_IK) PC_SHIFTS(0:3,NLOOPLINE)\n'
        '      LOGICAL PC_PAIR(NLOOPLINE,NLOOPLINE)\n'
        '      LOGICAL PC_USE(NLOOPLINE,NLOOPLINE)\n'
        f'      {real} PC_DIRECT(NLOOPLINE,NLOOPLINE)\n')
    call = (f'      CALL {prefix}BUILD_KINEMATIC_MATRIX(NLOOPLINE,P_S_MAT,MASSES'
            + ('\n     $ ,S_MAT)' if qp else ',S_MAT)'))
    convert = 'PC_QP_BITS' if qp else 'PC_DP_BITS'
    width = 128 if qp else 64
    new = f'''      PC_SHIFTS={convert}(SHIFTS)
      CALL PC_DIFFERENCE_BOUNDS(NLOOPLINE,{width},PC_SHIFTS,
     $ PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV_VALID(PC_ENV),PC_QERROR,
     $ PC_PAIR)
      CALL {prefix}PRIVATE_KINEMATIC_MATRIX(NLOOPLINE,P_S_MAT,
     $ MASSES,PC_CLASS,PC_QERROR,PC_PAIR,PC_ENV,S_MAT,PC_DIRECT,PC_USE)'''
    body = once(body, call, new)
    legacy = ('          INVARIANTS(I,J)=REAL(S_MAT(I,J)+MASSES(I)+MASSES(J)\n'
              '     $     ,KIND='+('KI_QTIR' if qp else 'KI_TIR')+')')
    body = once(body, legacy,
        '          IF(PC_USE(I,J)) THEN\n'
        '            INVARIANTS(I,J)=PC_DIRECT(I,J)\n'
        '          ELSE\n'+legacy+'\n          ENDIF')
    cmplx = 'COMPLEX*32' if qp else 'COMPLEX*16'
    wrapper = f'''      SUBROUTINE {name}(CTMODE,NLOOPLINE,
     $ RANK,PL,M2L,TIRCOEFS,STABLE)
      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK
      IMPLICIT NONE
      INCLUDE 'loop_max_coefs.inc'
      INTEGER CTMODE,NLOOPLINE,RANK
      {real} PL(0:3,NLOOPLINE)
      COMPLEX*16 M2L(NLOOPLINE)
      {cmplx} TIRCOEFS(0:LOOPMAXCOEFS-1,3)
      LOGICAL STABLE,PC_HAVE(NLOOPLINE)
      INTEGER PC_CLASS(NLOOPLINE,NLOOPLINE),PC_CHORD(0:3,NLOOPLINE)
      PC_CLASS=0
      PC_CHORD=0
      PC_HAVE=.FALSE.
      CALL {core}(CTMODE,NLOOPLINE,RANK,
     $ PL,M2L,TIRCOEFS,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,0_PC_IK)
      END'''
    return wrapper+'\n\n'+body


def dp_contraction(original):
    body = subroutine(original, 'ML5_0_TIRLOOP')
    body = once(body, 'ML5_0_TIRLOOP(', 'ML5_0_PRIVATE_TIRLOOP(')
    body = once(body,
        '      SUBROUTINE ML5_0_PRIVATE_TIRLOOP(I_SQSO,I_LOOPGROUP,I_LIB,NLOOPLINE,PL\n'
        '     $ ,M2L,RANK,RES,STABLE)',
        '      SUBROUTINE ML5_0_PRIVATE_TIRLOOP(I_SQSO,I_LOOPGROUP,\n'
        '     $ I_LIB,NLOOPLINE,PL\n     $ ,M2L,RANK,RES,STABLE)')
    body = once(body, '     $ ,M2L,RANK,RES,STABLE)',
        '     $ ,M2L,RANK,RES,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)')
    body = once(body, '      USE, INTRINSIC :: IEEE_ARITHMETIC',
        '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK\n'
        '      USE, INTRINSIC :: IEEE_ARITHMETIC')
    body = once(body, '      LOGICAL STABLE\n', '      LOGICAL STABLE\n'+CONTRACT_DECL)
    body = once(body, '''        CALL ML5_0_TIRUSTLOOP(CTMODE,NLOOPLINE,RANK,PL,M2L,TIRCOEFS
     $   ,STABLE)''', '''        CALL ML5_0_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,
     $   RANK,PL,M2L,TIRCOEFS,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)''')
    return body


def qp_contraction(original):
    body = subroutine(original, 'ML5_0_MP_TIRUST_LOOP')
    body = once(body, '      SUBROUTINE ML5_0_MP_TIRUST_LOOP(NLOOPLINE,PL,M2L,RANK,RES,STABLE)',
        '      SUBROUTINE ML5_0_PRIVATE_MP_TIRUST_LOOP(NLOOPLINE,PL,\n'
        '     $ M2L,RANK,RES,STABLE,ID,SQSOINDEX,PC_CHORD,PC_CLASS,\n'
        '     $ PC_HAVE,PC_ENV)\n'
        '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK')
    body = once(body, '      INTEGER NLOOPLINE,RANK,CTMODE,I,J\n',
        '      INTEGER NLOOPLINE,RANK,CTMODE,I,J\n'+CONTRACT_DECL)
    body = once(body, '      COMMON/ML5_0_LOOP/ID,SQSOINDEX,R\n', '')
    body = once(body, '''      CALL ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC(CTMODE,NLOOPLINE,RANK,PL
     $ ,M2L,COEFS,STABLE)''', '''      CALL ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,
     $ RANK,PL,M2L,COEFS,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)''')
    return body


def amplitude_wrappers(original):
    text = original
    for suffix in ['3','4','2','1_2']:
        name = 'ML5_0_LOOP_'+suffix
        body = subroutine(text, name)
        header, tail = body.split('      USE ALOHA_OBJECT\n', 1)
        header = once(header, 'LOOPNUM)',
                      'LOOPNUM,PC_ENV,PC_PRODUCER_OK)')
        body = header+'      USE ALOHA_OBJECT\n'+tail
        body = once(body, '      USE ALOHA_OBJECT\n',
            '      USE ALOHA_OBJECT\n'
            '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,\n'
            '     $ PC_CAPTURE_ENV,PC_ENV_VALID,PC_BUILD_CHORD,\n'
            '     $ PC_ROUTE_MATCHES,PC_DP_BITS,PC_QP_BITS\n')
        body = once(body, '      LOGICAL COMPLEX_MASS,DOING_QP\n',
            '      LOGICAL COMPLEX_MASS,DOING_QP\n'+CONTRACT_DECL+
            '      INTEGER(PC_IK) PC_EXTERNAL(2,0:3,4)\n'
            '      LOGICAL PC_ROUTE_OK,PC_PRODUCER_OK\n')
        start = body.index('        ELSEIF(MLREDUCTIONLIB(I_LIB).EQ.9.AND.DOING_QP) THEN')
        end = body.index('        ELSE\nC         Tensor Integral Reduction',start)
        replacement = '''        ELSEIF(MLREDUCTIONLIB(I_LIB).EQ.9) THEN
          PC_ROUTE_OK=PC_PRODUCER_OK.AND.PC_ROUTE_MATCHES(LOOPNUM,
     $     NLOOPLINE,SIZE(WE),WE,PAIRING)
          IF(DOING_QP) THEN
            DO J=1,4
              DO I=0,3
                PC_EXTERNAL(1,I,J)=PC_QP_BITS(REAL(MP_W(J)%P(I),
     $           KIND=16))
                PC_EXTERNAL(2,I,J)=PC_QP_BITS(AIMAG(MP_W(J)%P(I)))
              ENDDO
            ENDDO
            CALL PC_BUILD_CHORD(LOOPNUM,CTMODE,128,NLOOPLINE,
     $       PC_EXTERNAL,PC_ROUTE_OK.AND.PC_ENV_VALID(PC_ENV),
     $       PC_CHORD,PC_CLASS,PC_HAVE)
            CALL ML5_0_PRIVATE_MP_TIRUST_LOOP(NLOOPLINE,MP_PL,M2L,
     $       RANK,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),
     $       S(SQUAREDSOINDEX,LOOPNUM),LOOPNUM,SQUAREDSOINDEX,
     $       PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)
          ELSE
            DO J=1,4
              DO I=0,3
                PC_EXTERNAL(1,I,J)=PC_DP_BITS(DBLE(W(J)%P(I)))
                PC_EXTERNAL(2,I,J)=PC_DP_BITS(AIMAG(W(J)%P(I)))
              ENDDO
            ENDDO
            CALL PC_BUILD_CHORD(LOOPNUM,CTMODE,64,NLOOPLINE,
     $       PC_EXTERNAL,PC_ROUTE_OK.AND.PC_ENV_VALID(PC_ENV),
     $       PC_CHORD,PC_CLASS,PC_HAVE)
            CALL ML5_0_PRIVATE_TIRLOOP(SQUAREDSOINDEX,LOOPNUM,I_LIB,
     $       NLOOPLINE,PL,M2L,RANK,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),
     $       S(SQUAREDSOINDEX,LOOPNUM),PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)
          ENDIF
'''
        body = body[:start]+replacement+body[end:]
        text = replace_subroutine(text, name, body)
    return text


def caller_chain(original):
    # Entry tokens are automatic locals, captured before actual W construction.
    matrix = original['loop_matrix.f']
    name = 'ML5_0_SLOOPMATRIX_RETRY_IMPL'
    body = subroutine(matrix, name)
    body = once(body, '      USE ALOHA_OBJECT\n',
        '      USE ALOHA_OBJECT\n'
        '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,\n'
        '     $ PC_CAPTURE_ENV\n')
    body = once(body, '      IMPLICIT NONE\n',
        '      IMPLICIT NONE\n'
        '      INTEGER(PC_IK) PC_ENV_DP,PC_ENV_QP,PC_ENV_CALL\n'
        '      LOGICAL PC_QP_PRODUCER,PC_CALL_PRODUCER\n')
    marker = 'C     BEGIN CODE\nC     ----------\n'
    body = once(body, marker, marker+
        '      PC_ENV_DP=0_PC_IK\n      PC_ENV_QP=0_PC_IK\n'
        '      PC_QP_PRODUCER=.FALSE.\n')
    body = once(body, '          CALL ML5_0_MP_COMPUTE_LOOP_COEFS(MP_P,BUFFR_BIS)',
        '          PC_ENV_QP=PC_CAPTURE_ENV()\n'
        '          CALL ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(MP_P,\n'
        '     $     BUFFR_BIS,PC_QP_PRODUCER)')
    body = once(body, '          CALL ML5_0_HELAS_CALLS_AMPB_1(P,NHEL,H,IC)',
        '          PC_ENV_DP=PC_CAPTURE_ENV()\n'
        '          CALL ML5_0_HELAS_CALLS_AMPB_1(P,NHEL,H,IC)')
    body = once(body, '        CALL ML5_0_LOOP_CT_CALLS_1(P,NHEL,H,IC)',
        '        IF(CTMODE.GE.4) THEN\n'
        '          PC_ENV_CALL=PC_ENV_QP\n'
        '          PC_CALL_PRODUCER=PC_QP_PRODUCER\n'
        '        ELSE\n'
        '          PC_ENV_CALL=PC_ENV_DP\n'
        '          PC_CALL_PRODUCER=.TRUE.\n'
        '        ENDIF\n'
        '        CALL ML5_0_PRIVATE_LOOP_CT_CALLS_1(P,NHEL,H,IC,\n'
        '     $   PC_ENV_CALL,PC_CALL_PRODUCER)')
    matrix = replace_subroutine(matrix, name, body)

    calls = original['loop_CT_calls_1.f']
    private = once(calls, '      SUBROUTINE ML5_0_LOOP_CT_CALLS_1(P,NHEL,H,IC)',
        '      SUBROUTINE ML5_0_PRIVATE_LOOP_CT_CALLS_1(P,NHEL,H,IC,\n'
        '     $ PC_ENV,PC_PRODUCER_OK)')
    private = once(private, '      USE ALOHA_OBJECT\n',
        '      USE ALOHA_OBJECT\n'
        '      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK\n')
    private = once(private, '      INTEGER H\n',
        '      INTEGER H\n      INTEGER(PC_IK) PC_ENV\n'
        '      LOGICAL PC_PRODUCER_OK\n')
    pattern = r'(      CALL ML5_0_LOOP_(?:1_2|2|3|4)\([\s\S]*?I_SO,\d+)(\))'
    private,count = re.subn(pattern, r'\1,\n     $ PC_ENV,PC_PRODUCER_OK\2', private)
    require(count == 26, ('CMS route count', count))
    public = '''      SUBROUTINE ML5_0_LOOP_CT_CALLS_1(P,NHEL,H,IC)
      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK
      IMPLICIT NONE
      REAL*8 P(0:3,4)
      INTEGER NHEL(4),IC(4),H
      CALL ML5_0_PRIVATE_LOOP_CT_CALLS_1(P,NHEL,H,IC,
     $ 0_PC_IK,.FALSE.)
      END
'''
    calls = public+'\n'+private

    mp = original['mp_compute_loop_coefs.f']
    private = once(mp, '      SUBROUTINE ML5_0_MP_COMPUTE_LOOP_COEFS(PS,ANSDP)',
        '      SUBROUTINE ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(PS,ANSDP,\n'
        '     $ PC_QP_PRODUCER)')
    private = once(private, '      IMPLICIT NONE\n',
        '      IMPLICIT NONE\n      LOGICAL PC_QP_PRODUCER\n')
    private = once(private, '     $ .EQ.9.AND.USEQPINTEGRANDFORTIRUST))',
        '     $ .EQ.9.AND.USEQPINTEGRANDFORTIRUST))\n'
        '      PC_QP_PRODUCER=COMPUTE_INTEGRAND_IN_QP')
    public = '''      SUBROUTINE ML5_0_MP_COMPUTE_LOOP_COEFS(PS,ANSDP)
      IMPLICIT NONE
      REAL*16 PS(0:3,4)
      REAL*8 ANSDP(3,0:1)
      LOGICAL PC_QP_PRODUCER
      CALL ML5_0_PRIVATE_MP_COMPUTE_LOOP_COEFS(PS,ANSDP,
     $ PC_QP_PRODUCER)
      END
'''
    mp = public+'\n'+private
    return {'loop_matrix.f':matrix, 'loop_CT_calls_1.f':calls,
            'mp_compute_loop_coefs.f':mp}


def derive():
    original = donor_sources()
    ct = original['CT_interface.f']
    for qp in [False,True]:
        name = ('ML5_0_MP_' if qp else 'ML5_0_')+'PRIVATE_KINEMATIC_MATRIX'
        # Existing reducer helper bodies stay byte-for-byte unchanged.
        ct += '\n\n'+subroutine(masked_helper(original['CT_interface.f'],qp),name)+'\n'
    ct = amplitude_wrappers(ct)
    tirust = original['TIRUST_interface.f']
    for qp in [False,True]:
        name = ('ML5_0_MP_' if qp else 'ML5_0_')+'TIRUST_TENSOR_DIAGNOSTIC'
        tirust = replace_subroutine(tirust,name,tensor_core(original['TIRUST_interface.f'],qp))
    tirust += '\n\n'+qp_contraction(original['TIRUST_interface.f'])+'\n'
    tir = original['TIR_interface.f']+'\n\n'+dp_contraction(original['TIR_interface.f'])+'\n'
    candidate = {'CT_interface.f':ct,'TIRUST_interface.f':tirust,'TIR_interface.f':tir}
    candidate.update(caller_chain(original))
    return original,candidate


def materialize():
    original,candidate = derive()
    out = HERE/'candidate'
    out.mkdir(exist_ok=True)
    proofs = {'schema':'private-cms-amplitude-source-transform-v1',
              'source_index':DERIVED_SHA, 'mathematical_index':GENERAL_SHA,
              'donors':{},'candidate':{},'native_executions':0,'Fortran_compiled':False,
              'public_diagnostic_reads_common_route':False}
    for name,body in candidate.items():
        (out/name).write_text(body)
        patch = ''.join(difflib.unified_diff(original[name].splitlines(True),body.splitlines(True),
            fromfile='original/'+name,tofile='candidate/'+name))
        (HERE/(name+'.patch')).write_text(patch)
        proofs['donors'][str((SUB/name).relative_to(ROOT))] = pin(SUB/name)
        proofs['candidate'][name] = pin(out/name)
    (HERE/'source-proof.json').write_text(json.dumps(proofs,indent=2,sort_keys=True)+'\n')
    return proofs


if __name__ == '__main__':
    print(json.dumps(materialize(),sort_keys=True))
