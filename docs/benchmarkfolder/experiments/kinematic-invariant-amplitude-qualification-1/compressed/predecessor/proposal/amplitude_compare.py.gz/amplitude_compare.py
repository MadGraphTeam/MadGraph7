"""Pure retained-output gate; unchecked fixed-mode agreement is not host stability.

No compiler, loader, process launch, amplitude call, or failed-buffer arithmetic.
The controller authenticates closed worker evidence before calling this module.
This module additionally verifies every worker-retained output/map hash itself.
"""
from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE_PINS={
    'tools/tirust_benchmark.py': {'bytes':96661,'sha256':'bc405b44d8d794cc4396ef3da3d48af238ac4dfb619c58901d7bab910a7e1370'},
    'tests/parallel_tests/loop_me_comparator.py': {'bytes':74750,'sha256':'b6da773dadbe1e202639a865cbe3f29f65af8147a250a8bb05e756d537548354'},
    '.tirust-build/kinematic-provenance-current-executor-1/source/parity.py':
        {'bytes':8270,'sha256':'a9c91ea520280e8094e404ac88aa44fa0adebf39dd042905cc9a97080c41ff40'},
}
OUTPUTS=('bootstrap-values.dat','driver-state.dat','driver-bits.dat','qualification.dat',
         'dimensions.dat','values.dat','timed_status.dat','timing.dat','trace.dat')
EQUAL_FILES=('bootstrap-values.dat','driver-state.dat','driver-bits.dat','qualification.dat',
             'dimensions.dat','values.dat','timed_status.dat')
COLUMNS=('Born','finite','single_pole','double_pole')
TOL=F(3,1000000)
TARGET=F(1,100000000)
DECIMAL_TOKEN=re.compile(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?\Z')


def require(condition,message):
    if not condition:
        raise ValueError(message)


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def verify_sources():
    for name,expected in SOURCE_PINS.items():
        require(pin((ROOT/name).read_bytes())==expected,'Comparison source changed: '+name)
    return SOURCE_PINS


def decode64(word):
    """Exactly decode a finite IEEE-binary64 word, including subnormals."""
    require(re.fullmatch(r'[0-9A-F]{16}',word) is not None,'Malformed binary64 word')
    bits=int(word,16); exponent=(bits>>52)&2047; fraction=bits&((1<<52)-1)
    require(exponent!=2047,'Nonfinite binary64 coefficient')
    significand=fraction if exponent==0 else (1<<52)|fraction
    power=-1074 if exponent==0 else exponent-1075
    value=F(significand*(1<<power)) if power>=0 else F(significand,1<<(-power))
    return -value if bits>>63 else value


def wire(value):
    if value is None:
        return None
    with localcontext() as context:
        context.prec=26
        decimal=format(Decimal(value.numerator)/Decimal(value.denominator),'.17E')
    return {'numerator':str(value.numerator),'denominator':str(value.denominator),'decimal':decimal}


def _states(raw,point,mode,observation=None):
    rows=[]
    expected=[(0,1,1,'B'),(0,1,1,'A'),(1,2,point,'B'),(1,2,point,'A')]
    for line in raw.splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        fields=line.split()
        require(len(fields)==16 and fields[0]=='STATE','Driver state schema differs')
        require(fields[1] in ('A','B'),'State phase is unknown')
        values=list(map(int,fields[2:12]));bits=fields[12:]
        require(all(re.fullmatch('[0-9A-F]{8}',x) for x in bits),'Malformed logical words')
        require(all(x in (0,1) for x in values[6:]),'Logical values are not0/1')
        require([int(x,16) for x in bits]==values[6:],'Logical words disagree with flags')
        rows.append({'stage':fields[1],'phase':values[0],'call':values[1],'point':values[2],
                     'requested_mode':values[3],'code':values[4],'actual_mode':values[5],
                     'checkphase':values[6],'helicity_checked':values[7],
                     'fpe_dp':values[8],'fpe_qp':values[9],'logical_words':bits})
    if observation is not None:
        observation['states']=rows
        observation['outer_entries_observed']=sum(x['stage']=='A' for x in rows)
    require([(x['phase'],x['call'],x['point'],x['stage']) for x in rows]==expected,
            'Missing, repeated or extra outer entries')
    for row in rows:
        require(row['requested_mode']==mode,'Requested driver mode differs')
        if row['stage']=='A':
            require(row['code']=={1:110,4:120}[mode] and row['actual_mode']==mode,
                    'Actual mode or fixed unchecked return differs')
        else:
            require(row['code']==-987654321 and row['actual_mode']==-999,
                    'Pre-entry sentinel differs')
    return rows


def _coverage(raw,point,mode,observation=None):
    code={1:110,4:120}[mode]
    rows=[]
    for line in raw.splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        fields=line.split()
        require(len(fields)==10,'Raw answer-bit row shape differs')
        head=list(map(int,fields[:5]));words=fields[5:]
        require(all(re.fullmatch('[0-9A-F]{16}',x) for x in words),'Raw answer-bit schema differs')
        rows.append({'phase':head[0],'call':head[1],'point':head[2],'order':head[3],
                     'code':head[4],'words':words})
    if observation is not None:
        observation['raw_rows']=rows
    require([(x['phase'],x['call'],x['point'],x['order'],x['code']) for x in rows]==
            [(0,1,1,0,code),(0,1,1,1,code),(1,2,point,0,code),(1,2,point,1,code)],
            'Missing, duplicate or unexpected coefficient columns/status')
    return rows


def _decimal_shape(raw,heads,width):
    rows=[x.split() for x in raw.splitlines() if x.strip() and not x.startswith('#')]
    require(len(rows)==len(heads),'Decimal coefficient row count differs')
    require(all(len(row)==width+5 for row in rows),'Decimal coefficient columns differ')
    require([tuple(map(int,row[:width])) for row in rows]==heads,'Decimal status/order coverage differs')
    require(all(DECIMAL_TOKEN.fullmatch(value) for row in rows for value in row[width:]),
            'Nonfinite or malformed decimal coefficient text')


def inspect_worker(directory,request):
    """Classify retained worker evidence; decode no failed-row coefficients."""
    directory=Path(directory)
    result={'id':request['id'],'request':request,'eligible':False,'failures':[],
            'source_evidence':{},'states':[],'raw_rows':[],
            'outer_entries_observed':0,'ready_done_maps':0,'native_pid':None,
            'protocol_complete':False}
    raw={};native=None
    try:
        native_raw=(directory/'result.json').read_bytes()
        result['source_evidence']['result.json']=pin(native_raw)
        native=json.loads(native_raw)
        require(native['request']==request,'Worker request differs from admitted request')
        result['native_pid']=native.get('native_pid')
        require(type(result['native_pid']) is int and result['native_pid']>0,'Missing native worker PID')
        require(native['orchestration_complete'] is True and native['runtime_map_verified'] is True and
                native['trace_complete'] is True and native['native_returncode']==0 and
                not native['stdout_overflow'] and not native['collection_errors'] and
                native['failure'] is None and native['cleanup_failure'] is None,
                'Incomplete worker/runtime/cleanup evidence')
        closes=native['close_receipts']
        require(closes and all(x['complete'] is True and x['worker_closed'] is True and
                              x['returncode']==0 and x['pid']==native['native_pid'] for x in closes),
                'Worker ownership/close receipts failed')
        protocol=native['protocol']
        require(len(protocol)==3 and protocol[0][:6]==['READY','1','1','1','1','1'] and
                len(protocol[0])==7 and DECIMAL_TOKEN.fullmatch(protocol[0][6]) and
                protocol[1]==['DONE','1','1'] and protocol[2]==['BYE'],
                'Protocol is not one bootstrap plus one measurement')
        maps=native['runtime_maps']
        require([x['boundary'] for x in maps]==['READY','DONE'],'Missing/duplicate runtime maps')
        require(maps[0]['elf'] and maps[0]['elf']==maps[1]['elf'],'READY/DONE ELF map sets differ')
        for capture in maps:
            name=capture['file']
            require(Path(name).name==name,'Unsafe retained map path')
            data=(directory/name).read_bytes()
            require(pin(data)['sha256']==capture['sha256'],'Retained map bytes changed')
            result['source_evidence'][name]=pin(data)
        result['ready_done_maps']=2
        result['protocol_complete']=True
        require(set(native['outputs'])==set(OUTPUTS),'Incomplete retained output set')
        for name in OUTPUTS:
            data=(directory/name).read_bytes()
            require(pin(data)==native['outputs'][name],'Retained output bytes changed: '+name)
            result['source_evidence'][name]=pin(data)
            raw[name]=data.decode('ascii')
        console_raw=(directory/'stdout.txt').read_bytes()
        result['source_evidence']['stdout.txt']=pin(console_raw)
        warnings=[line for line in console_raw.decode('utf-8',errors='replace').splitlines() if '##W03' in line]
        result['incomplete_contribution_warnings']=warnings
        require(not raw['trace.dat'],'Unexpected diagnostic trace output')
        require(raw['dimensions.dat'].split()==['1','1','1'],'Split-order dimensions differ')
        point=request['point'];mode=request['requested_mode'];code={1:110,4:120}[mode]
        states=_states(raw['driver-state.dat'],point,mode,result)
        result['states']=states
        result['outer_entries_observed']=sum(x['stage']=='A' for x in states)
        rows=_coverage(raw['driver-bits.dat'],point,mode,result)
        result['raw_rows']=rows
        require(raw['timed_status.dat'].split()==[str(code),'1'],'Timed status/count differs')
        _decimal_shape(raw['values.dat'],[(1,0,code),(1,1,code)],3)
        _decimal_shape(raw['bootstrap-values.dat'],[(1,1,0,code),(1,1,1,code)],4)
        if warnings:
            result['failures'].append('Incomplete-contribution warning W03')
        if any(x['fpe_dp'] or x['fpe_qp'] for x in states if x['stage']=='A'):
            result['failures'].append('Failed DP/QP contribution flag; interpretation blocked')
        nonfinite=[{'phase':x['phase'],'order':x['order'],'column':i}
                   for x in rows for i,word in enumerate(x['words'])
                   if (int(word,16)>>52)&2047==2047]
        if nonfinite:
            result['nonfinite_columns']=nonfinite
            result['failures'].append('Nonfinite coefficient/accuracy word; interpretation blocked')
        result['eligible']=not result['failures']
    except (KeyError,ValueError,TypeError,OSError,UnicodeError) as exc:
        result['failures'].append(str(exc))
    # Fractions are deliberately absent here. Failed outputs stay opaque words.
    return result


def compare_coefficients(reference,candidate):
    """Exact LoopMEComparator gate; both observations must already be eligible."""
    require(reference['eligible'] and candidate['eligible'],'Cannot interpret failed contribution values')
    arows=[x for x in reference['raw_rows'] if x['phase']==1]
    brows=[x for x in candidate['raw_rows'] if x['phase']==1]
    require([(x['point'],x['order']) for x in arows]==[(x['point'],x['order']) for x in brows],
            'Comparison points/orders differ')
    residuals=[];worst=F(0)
    for left,right in zip(arows,brows):
        a=[decode64(x) for x in left['words'][:4]]
        b=[decode64(x) for x in right['words'][:4]]
        finite=max(abs(a[1]),abs(b[1]),F(1,10**99))
        for column,(x,y) in enumerate(zip(a,b)):
            magnitude=max(abs(x),abs(y));difference=abs(x-y)
            symmetric=difference/abs(x+y) if x+y else F(0) if not magnitude else None
            relative=difference/magnitude if magnitude else F(0)
            pole=magnitude/finite if column>=2 else None
            def accepted(tolerance):
                return ((symmetric is not None and symmetric<tolerance) or
                        (pole is not None and pole<tolerance))
            worst=max(worst,relative)
            residuals.append({'point':left['point'],'order':left['order'],'column':column,
                'coefficient':COLUMNS[column],'reference_word':left['words'][column],
                'candidate_word':right['words'][column],'reference':wire(x),'candidate':wire(y),
                'relative_error':wire(relative),'symmetric_relative_error':wire(symmetric),
                'pole_to_finite':wire(pole),'passed':accepted(TOL),'ordinary_target_passed':accepted(TARGET)})
    return {'eligible':True,'passed':all(x['passed'] for x in residuals),
        'ordinary_target_passed':all(x['ordinary_target_passed'] for x in residuals),
        'maximum_relative_error':wire(worst),'residuals':residuals,
        'failures':[x for x in residuals if not x['passed']]}


def compare_stage(root,requests):
    """Read one closed stage. No failure is repaired, retried or ignored."""
    verify_sources();root=Path(root)
    require(requests and len({x['id'] for x in requests})==len(requests),'Empty/duplicate stage requests')
    require(len({x['stage'] for x in requests})==1,'Mixed stages')
    stage=requests[0]['stage'];require(stage in ('ordinary','stress'),'Unknown stage')
    groups={};observations={};failures=[];controls=[];comparisons=[]
    for request in requests:
        require(Path(request['id']).name==request['id'],'Unsafe worker ID')
        require(request['backend'] in (1,9) and request['variant'] in ('original','candidate') and
                request['requested_mode'] in (1,4),'Unknown variant/backend/mode')
        key=(request['point'],request['requested_mode'])
        members=groups.setdefault(key,{})
        pair=(request['variant'],request['backend'])
        require(pair not in members,'Duplicate group member');members[pair]=request['id']
        obs=inspect_worker(root/request['id'],request);observations[request['id']]=obs
        if not obs['eligible']:
            failures.append({'id':request['id'],'variant':request['variant'],'backend':request['backend'],
                             'point':request['point'],'mode':request['requested_mode'],
                             'failure':obs['failures']})
    required={('original',1),('candidate',1),('original',9),('candidate',9)}
    require(all(set(group)==required for group in groups.values()),'Incomplete original/candidate reducer controls')
    candidate_passed=True
    for (point,mode),group in sorted(groups.items()):
        first=observations[group['original',1]];second=observations[group['candidate',1]]
        differing=[name for name in EQUAL_FILES if first['source_evidence'].get(name)!=second['source_evidence'].get(name)]
        equal=not differing and all(name in first['source_evidence'] for name in EQUAL_FILES)
        control_ok=equal and first['eligible'] and second['eligible']
        controls.append({'point':point,'mode':mode,'exact_observation_parity':equal,
                         'both_valid':first['eligible'] and second['eligible'],'passed':control_ok,
                         'different_files':differing})
        if not control_ok:
            failures.append({'point':point,'mode':mode,'variant':'candidate','backend':1,
                             'failure':'CutTools original/candidate control gate failed'})
        candidate_passed=candidate_passed and control_ok
        for label,left_key,right_key,needed in (
            ('candidate9_vs_original1',('original',1),('candidate',9),True),
            ('candidate9_vs_candidate1',('candidate',1),('candidate',9),True),
            ('original9_vs_original1',('original',1),('original',9),False)):
            left=observations[group[left_key]];right=observations[group[right_key]]
            row={'label':label,'point':point,'mode':mode,'reference_id':left['id'],'candidate_id':right['id'],
                 'required_for_candidate_gate':needed,'eligible':left['eligible'] and right['eligible']}
            if row['eligible']:
                row.update(compare_coefficients(left,right))
                if not row['passed']:
                    failures.append({'point':point,'mode':mode,'comparison':label,'backend':9,
                                     'variant':'candidate' if needed else 'original',
                                     'failure':'Coefficient regression criterion failed'})
            else:
                row.update(passed=False,interpretation_blocked=True,
                           invalid_workers=[x['id'] for x in (left,right) if not x['eligible']])
            if needed:
                candidate_passed=candidate_passed and row['passed']
            comparisons.append(row)
    pids=[x['native_pid'] for x in observations.values() if x['native_pid'] is not None]
    if len(pids)!=len(set(pids)):
        failures.append({'failure':'Fresh-worker PID repeated'})
        candidate_passed=False
    return {'schema':'private-cms-fixed-amplitude-comparison-v1','stage':stage,
        'passed':not failures,'candidate_gate_passed':candidate_passed,
        'ordinary_target_passed':all(x.get('ordinary_target_passed',False) for x in comparisons
                                     if x['required_for_candidate_gate']),
        'criterion':'LoopMEComparator: abs(a-b)/abs(a+b)<tolerance, or pole magnitude/finite maximum<tolerance',
        'relative_error_metric':'abs(a-b)/max(abs(a),abs(b)); zero-zero is zero',
        'tolerance':'3e-6','ordinary_target_tolerance':'1e-8','source_pins':SOURCE_PINS,
        'workers_requested':len(requests),
        'workers_with_complete_protocol':sum(x['protocol_complete'] for x in observations.values()),
        'workers_eligible':sum(x['eligible'] for x in observations.values()),
        'outer_entries_observed':sum(x['outer_entries_observed'] for x in observations.values()),
        'ready_done_maps':sum(x['ready_done_maps'] for x in observations.values()),
        'observations':observations,'control_comparisons':controls,'comparisons':comparisons,'failures':failures,
        'original_failures':[x for x in failures if x.get('variant')=='original'],
        'candidate_failures':[x for x in failures if x.get('variant')=='candidate'],
        'fixed_returns_are_unchecked':True,'normal_host_stability_qualified':False,
        'independent_accuracy_qualified':False,'performance_measurement':False}
