"""Authenticate one closed-plan worker then reuse the retained native owner."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'.tirust-build/kinematic-provenance-current-executor-1/source'
OLD_SHA='7ea709b48d8de462b754fabfb47dcbd5d21d7847458382f5844190028e8c1bed'

def require(ok,message):
    if not ok:raise ValueError(message)

def pin(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def authenticate(path,checksum):
    require(pin(path)['sha256']==checksum,'Worker reviewed index changed')
    for name,expected in json.loads(Path(path).read_bytes())['files'].items():
        p=Path(name);require(not p.is_absolute() and '..' not in p.parts,'Unsafe worker index path')
        require(pin(Path(path).parent/p)==expected,'Worker source payload changed')

def execute(specpath,specsha,source_sha):
    authenticate(HERE/'index.json',source_sha)
    authenticate(OLD/'index.json',OLD_SHA)
    require(pin(specpath)['sha256']==specsha,'Worker specification changed')
    spec=json.loads(Path(specpath).read_bytes())
    require(spec['source_index_sha256']==source_sha,'Worker source index mismatch')
    plan=json.loads((HERE/'validation-plan.json').read_bytes())
    require(spec['request'] in plan['requests'],'Worker request outside sealed matrix')
    root=ROOT/'.tirust-build/kinematic-invariant-amplitude-executor-2'
    expected_cwd=root/'work/workers'/spec['request']['id']/'SubProcesses/P0_epem_mupmum'
    require(Path.cwd()==expected_cwd and Path(spec['cwd'])==expected_cwd,'Unexpected worker cwd')
    require(Path(spec['evidence'])==root/'results/runs'/spec['request']['id'],'Unexpected worker evidence')
    require(Path(specpath)==Path(spec['evidence'])/'specification.json','Unexpected specification location')
    require(Path(spec['executable'])==expected_cwd/'check','Unexpected worker executable')
    sys.path.insert(0,str(OLD))
    import admission
    admission.helpers()
    mod=admission.load('pc_native_job',HERE/'native_job.py')
    mod.HERE=HERE
    return mod.execute(specpath)

if __name__=='__main__':
    require(len(sys.argv)==4,'Explicit specification hash and source seal required')
    execute(Path(sys.argv[1]),sys.argv[2],sys.argv[3])
