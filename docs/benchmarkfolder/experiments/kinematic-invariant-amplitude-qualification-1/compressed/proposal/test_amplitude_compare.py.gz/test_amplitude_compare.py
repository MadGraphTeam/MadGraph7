"""Synthetic retained-file tests only; no native process or scientific fixture."""
import copy
from fractions import Fraction as F
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest import mock
import amplitude_compare as C


def word(x):
    return struct.pack('>d',x).hex().upper()


def request(point=1,mode=1,variant='original',backend=1):
    return {'id':f'cms-p{point}-mode{mode}-lib{backend}-{variant}',
            'point':point,'requested_mode':mode,'backend':backend,'variant':variant,
            'stage':'ordinary' if point==1 else 'stress'}


def make_worker(root,r,pid,coefs=(1.,2.,-3.,4.),final_flags=(0,0),warning=False):
    d=root/r['id'];d.mkdir()
    mode=r['requested_mode'];point=r['point'];code={1:110,4:120}[mode]
    states=[]
    for phase,call,point_id,stage in [(0,1,1,'B'),(0,1,1,'A'),(1,2,point,'B'),(1,2,point,'A')]:
        flags=(1,0,*(final_flags if phase==1 and stage=='A' else (0,0)))
        numbers=[phase,call,point_id,mode,code if stage=='A' else -987654321,mode if stage=='A' else -999,*flags]
        states.append('STATE '+stage+' '+' '.join(map(str,numbers))+' '+' '.join(f'{x:08X}' for x in flags))
    (d/'driver-state.dat').write_text('\n'.join(states)+'\n')
    rows=[]
    for phase,call,point_id,order in [(0,1,1,0),(0,1,1,1),(1,2,point,0),(1,2,point,1)]:
        values=(1.,2.,-3.,4.) if phase==0 else coefs
        rows.append(' '.join(map(str,[phase,call,point_id,order,code]))+' '+' '.join(word(x) for x in (*values,-1.)))
    (d/'driver-bits.dat').write_text('\n'.join(rows)+'\n')
    (d/'values.dat').write_text(''.join(f'1 {o} {code} '+' '.join(str(x) for x in (*coefs,-1.))+'\n' for o in [0,1]))
    (d/'bootstrap-values.dat').write_text(''.join(f'1 1 {o} {code} 1.0 2.0 -3.0 4.0 -1.0\n' for o in [0,1]))
    (d/'qualification.dat').write_text('NATIVE_QUALIFICATION_PENDING\nSTATUS_ALONE_IS_NOT_NUMERICAL_VALIDATION\n')
    (d/'dimensions.dat').write_text('1 1 1\n')
    (d/'timed_status.dat').write_text(f'{code} 1\n')
    (d/'timing.dat').write_text('0.1 0.1\n')
    (d/'trace.dat').write_text('')
    (d/'stdout.txt').write_text('##W03 failed contribution\n' if warning else '')
    maps=[]
    for index,boundary in enumerate(['READY','DONE']):
        name=f'maps-{index}.txt';raw=f'synthetic mapping at {boundary}\n'.encode();(d/name).write_bytes(raw)
        maps.append({'boundary':boundary,'file':name,'sha256':C.pin(raw)['sha256'],
                     'elf':{'/synthetic/executable':'0'*64},'data':{}})
    native={'request':r,'orchestration_complete':True,'runtime_map_verified':True,'trace_complete':True,
        'native_returncode':0,'native_pid':pid,'stdout_overflow':False,'collection_errors':[],
        'failure':None,'cleanup_failure':None,
        'close_receipts':[{'complete':True,'worker_closed':True,'returncode':0,'pid':pid}],
        'protocol':[['READY','1','1','1','1','1','1.0E-1'],['DONE','1','1'],['BYE']],
        'runtime_maps':maps,'outputs':{name:C.pin((d/name).read_bytes()) for name in C.OUTPUTS}}
    (d/'result.json').write_text(json.dumps(native))
    return d


def reseal(d):
    result=json.loads((d/'result.json').read_text())
    result['outputs']={name:C.pin((d/name).read_bytes()) for name in C.OUTPUTS}
    (d/'result.json').write_text(json.dumps(result))


class Compare(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup)

    def group(self,point=1,altered=None):
        altered=altered or {}
        requests=[]
        for index,(variant,backend) in enumerate([('original',1),('candidate',1),('original',9),('candidate',9)]):
            r=request(point=point,variant=variant,backend=backend)
            make_worker(self.root,r,100+index,**altered.get((variant,backend),{}))
            requests.append(r)
        return requests

    def test_valid_exact_group_has_all_columns_and_unchecked_limits(self):
        requests=self.group()
        report=C.compare_stage(self.root,requests)
        self.assertTrue(report['passed'])
        self.assertTrue(report['candidate_gate_passed'])
        self.assertEqual(report['outer_entries_observed'],8)
        self.assertEqual(report['ready_done_maps'],8)
        self.assertEqual(len(report['comparisons']),3)
        self.assertTrue(all(len(x['residuals'])==8 for x in report['comparisons']))
        self.assertFalse(report['independent_accuracy_qualified'])
        self.assertFalse(report['normal_host_stability_qualified'])
        self.assertTrue(report['fixed_returns_are_unchecked'])
        json.dumps(report,allow_nan=False)

    def test_nonfinite_raw_word_blocks_interpretation(self):
        r=request();d=make_worker(self.root,r,101)
        text=(d/'driver-bits.dat').read_text().splitlines()
        fields=text[2].split();fields[6]='7FF0000000000001';text[2]=' '.join(fields)
        (d/'driver-bits.dat').write_text('\n'.join(text)+'\n');reseal(d)
        with mock.patch.object(C,'decode64',side_effect=AssertionError('must not decode')):
            obs=C.inspect_worker(d,r)
        self.assertFalse(obs['eligible'])
        self.assertEqual(obs['nonfinite_columns'],[{'phase':1,'order':0,'column':1}])

    def test_failed_flags_with_equal_values_are_never_success(self):
        requests=self.group(altered={('original',9):{'final_flags':(1,0)},('candidate',9):{'final_flags':(1,0)}})
        report=C.compare_stage(self.root,requests)
        self.assertFalse(report['passed'])
        self.assertFalse(report['candidate_gate_passed'])
        self.assertEqual(len(report['original_failures']),1)
        self.assertEqual(len(report['candidate_failures']),1)
        self.assertTrue(all(not row['eligible'] for row in report['comparisons']))

    def test_baseline_failure_remains_while_candidate_gate_can_pass(self):
        requests=self.group(point=20,altered={('original',9):{'final_flags':(1,0)}})
        report=C.compare_stage(self.root,requests)
        self.assertFalse(report['passed'])
        self.assertTrue(report['candidate_gate_passed'])
        self.assertEqual(len(report['original_failures']),1)
        baseline=[x for x in report['comparisons'] if x['label']=='original9_vs_original1'][0]
        self.assertFalse(baseline['eligible'])
        self.assertNotIn('residuals',baseline)

    def test_w03_warning_blocks_finite_unflagged_values(self):
        r=request();d=make_worker(self.root,r,101,warning=True)
        obs=C.inspect_worker(d,r)
        self.assertFalse(obs['eligible'])
        self.assertIn('Incomplete-contribution warning W03',obs['failures'])

    def test_missing_split_order_is_rejected(self):
        r=request();d=make_worker(self.root,r,101)
        lines=(d/'driver-bits.dat').read_text().splitlines()
        (d/'driver-bits.dat').write_text('\n'.join(lines[:-1])+'\n');reseal(d)
        obs=C.inspect_worker(d,r)
        self.assertFalse(obs['eligible'])
        self.assertTrue(any('coefficient columns' in x for x in obs['failures']))

    def test_actual_wrong_mode_is_rejected(self):
        r=request();d=make_worker(self.root,r,101)
        lines=(d/'driver-state.dat').read_text().splitlines();fields=lines[-1].split();fields[7]='4';lines[-1]=' '.join(fields)
        (d/'driver-state.dat').write_text('\n'.join(lines)+'\n');reseal(d)
        obs=C.inspect_worker(d,r)
        self.assertFalse(obs['eligible'])
        self.assertTrue(any('Actual mode' in x for x in obs['failures']))
        self.assertEqual(obs['outer_entries_observed'],2)
        self.assertEqual(obs['states'][-1]['actual_mode'],4)

    def test_single_pole_mismatch_is_not_hidden_by_other_columns(self):
        requests=self.group(altered={('candidate',9):{'coefs':(1.,2.,-1.,4.)}})
        report=C.compare_stage(self.root,requests)
        self.assertFalse(report['passed']);self.assertFalse(report['candidate_gate_passed'])
        row=report['comparisons'][0]
        self.assertEqual({x['coefficient'] for x in row['failures']},{'single_pole'})
        self.assertEqual({x['order'] for x in row['failures']},{0,1})

    def test_cuttools_bit_parity_rejects_even_signed_zero_change(self):
        requests=self.group(altered={('original',1):{'coefs':(0.,2.,-3.,4.)},('candidate',1):{'coefs':(-0.,2.,-3.,4.)}})
        report=C.compare_stage(self.root,requests)
        self.assertFalse(report['control_comparisons'][0]['passed'])
        self.assertFalse(report['candidate_gate_passed'])

    def test_actual_symmetric_criterion_is_distinct_from_raw_relative(self):
        left=request(variant='original',backend=1);right=request(variant='candidate',backend=9)
        a=make_worker(self.root,left,101);b=make_worker(self.root,right,102,coefs=(1.+2.**-18,2.,-3.,4.))
        result=C.compare_coefficients(C.inspect_worker(a,left),C.inspect_worker(b,right))
        self.assertTrue(result['passed'])
        row=result['residuals'][0]
        relative=F(int(row['relative_error']['numerator']),int(row['relative_error']['denominator']))
        self.assertGreater(relative,C.TOL)
        self.assertFalse(row['ordinary_target_passed'])

    def test_pole_exception_and_undefined_opposite_nonzero_are_retained(self):
        left=request(variant='original',backend=1);right=request(variant='candidate',backend=9)
        a=make_worker(self.root,left,101,coefs=(1.,1e6,1.,0.))
        b=make_worker(self.root,right,102,coefs=(1.,1e6,-1.,0.))
        result=C.compare_coefficients(C.inspect_worker(a,left),C.inspect_worker(b,right))
        self.assertTrue(result['passed'])
        self.assertIsNone(result['residuals'][2]['symmetric_relative_error'])
        self.assertFalse(result['ordinary_target_passed'])
        # Opposite finite terms have no pole-size exception.
        d=self.root/right['id'];data=(d/'driver-bits.dat').read_text().replace(word(1e6),word(-1e6))
        (d/'driver-bits.dat').write_text(data);reseal(d)
        result=C.compare_coefficients(C.inspect_worker(a,left),C.inspect_worker(d,right))
        self.assertFalse(result['passed'])
        self.assertIsNone(result['residuals'][1]['symmetric_relative_error'])
        json.dumps(result,allow_nan=False)

    def test_min_subnormal_signed_zero_and_snan_decoding(self):
        self.assertEqual(C.decode64('0000000000000001'),F(1,1<<1074))
        self.assertEqual(C.decode64('8000000000000000'),F(0))
        self.assertEqual(C.decode64('BFF0000000000000'),F(-1))
        with self.assertRaisesRegex(ValueError,'Nonfinite'):
            C.decode64('7FF0000000000001')

    def test_changed_output_hash_rejected_before_value_interpretation(self):
        r=request();d=make_worker(self.root,r,101)
        (d/'driver-bits.dat').write_text('tampered\n')
        obs=C.inspect_worker(d,r)
        self.assertFalse(obs['eligible'])
        self.assertTrue(any('Retained output bytes changed' in x for x in obs['failures']))
        self.assertEqual(obs['raw_rows'],[])

    def test_duplicate_done_protocol_and_map_boundaries_rejected(self):
        r=request();d=make_worker(self.root,r,101)
        native=json.loads((d/'result.json').read_text());native['protocol'].insert(2,['DONE','1','1'])
        (d/'result.json').write_text(json.dumps(native))
        self.assertFalse(C.inspect_worker(d,r)['eligible'])
        native['protocol'].pop(2);native['runtime_maps'][1]['boundary']='READY'
        (d/'result.json').write_text(json.dumps(native))
        self.assertFalse(C.inspect_worker(d,r)['eligible'])

    def test_failed_observations_cannot_be_compared_directly(self):
        r=request();d=make_worker(self.root,r,101,final_flags=(0,1));obs=C.inspect_worker(d,r)
        with mock.patch.object(C,'decode64',side_effect=AssertionError('must not decode')):
            with self.assertRaisesRegex(ValueError,'Cannot interpret failed'):
                C.compare_coefficients(obs,obs)

if __name__=='__main__':
    unittest.main(verbosity=2)
