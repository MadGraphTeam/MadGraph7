# Source-only successor after a pre-build schema failure

The first admitted build of source286ecfe5 ended with `KeyError('size')` before
any owned command, compiler, header query, loader query or native evaluation.
Its terminal session70379, failed closure99cbb544 and terminal reviewb504c919
remain untouched under executor-1. Protected before/after bytes were identical,
no work directory was created, and the shared lock was free after termination.

Proposal-2 makes a single provenance-boundary repair: the immutable bindings
remain `{bytes, sha256}`, while the in-memory inherited prerequisite DATA
receives `{size: bytes, sha256}`. The actual inherited `check_file` and
`external_hashes` require `size`. The retained `dependency_snapshot` reads files
again and returns `{bytes, sha256}`, matching the existing exact comparison in
`build_stage.clone`. Neither side's byte count or digest check is removed.

The controller and worker-entry fixed output root both move to executor-2;
there is no attempt to reuse or overwrite executor-1. Support source paths point
to identical copies in proposal-2. `successor-change-proof.json` binds the old
failure and byte-identical numerical source, source-derived metadata, token
probe, driver, cards, saved points, build stage, comparator and worker owner.
There is no change to numerical operations, thresholds, flags, physics input,
model, precision or installed library.

The CLI file-only preflight now exercises the real setup-to-snapshot boundary
with compiler/loader entrypoints forbidden. The same check precedes native
stage admission. The added file-backed regression uses the real authenticated retained setup,
prerequisite checker and dependency snapshot, with native-command entrypoints
forbidden. It reproduces the raw-schema failure, checks the translated records,
and verifies the snapshot agrees with all three original bytes/hash records.
The successor must receive a new source seal and independent build admission;
no build retry follows source preparation automatically.

Deadline interpretation is unchanged from additive clarificationa476220b:
work after lock acquisition is bounded by2940/2340/4740 seconds for
build/ordinary/stress, with60 seconds reserved for owned cleanup. Initial
preflight, lock wait (inherited maximum3600s), protected postverification and
receipt serialization are outside that work deadline. There is no claim of a
single inclusive deadline for the whole Python invocation.
