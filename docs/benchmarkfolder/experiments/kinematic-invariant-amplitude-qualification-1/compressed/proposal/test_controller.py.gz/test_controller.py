"""Pure mocked admission tests: no compiler, loader or native worker."""
from contextlib import nullcontext
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import Mock,patch
import run as C

class Controller(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=C.HERE,prefix='.unit-')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.exe=self.root/'fake-exe';self.exe.write_bytes(b'not executed')
        self.loader=self.root/'fake-loader';self.loader.write_bytes(b'not loaded')
        self.result={'files':{'foreign':'checksum'},'loader':str(self.loader),'loader_sha256':'sha','loader_listing':'text'}
        self.native=Mock(return_value=self.result)
        L=NS(interpreter=Mock(return_value=self.loader),runtime=self.native,q=NS(verify_hashes=Mock()))
        G=NS(compiler_pins=Mock(return_value=self.loader),providers=Mock())
        self.patches=patch.multiple(C,RESULTS=self.root/'results',R=NS(L=L),G=G,
                                   B={'fixed_supplemental_providers':{}},TOOLCHAIN={},QUERIES=[])
        self.patches.start();self.addCleanup(self.patches.stop)

    def test_wrong_interpreter_fails_before_loader_and_retains_receipt(self):
        C.R.L.interpreter.return_value=self.root/'wrong'
        with self.assertRaisesRegex(ValueError,'PT_INTERP'):
            C.runtime(self.exe,{},'original')
        self.native.assert_not_called()
        receipt=C.read(C.RESULTS/'runtime/original.json')
        self.assertFalse(receipt['loader_query_started'])
        self.assertFalse(receipt['passed'])

    def test_unadmitted_provider_retained_and_no_retry(self):
        C.G.providers.side_effect=ValueError('unknown provider')
        with self.assertRaisesRegex(ValueError,'unknown provider'):
            C.runtime(self.exe,{},'original')
        receipt=C.read(C.RESULTS/'runtime/original.json')
        self.assertEqual(receipt['runtime'],self.result)
        with self.assertRaisesRegex(ValueError,'Repeated loader'):
            C.runtime(self.exe,{},'original')
        self.assertEqual(self.native.call_count,1)

    def test_closed_provider_hashes_checked_before_loader(self):
        C.R.L.q.verify_hashes.side_effect=lambda values: (_ for _ in ()).throw(ValueError('closed file changed')) if 'closed' in values else None
        with self.assertRaisesRegex(ValueError,'closed file changed'):
            C.runtime(self.exe,{},'worker',{'files':{'closed':'sha'},'loader':str(self.loader)})
        self.native.assert_not_called()

    def test_namespace_cpu_and_unique_owned_labels(self):
        old=Mock(return_value='retained')
        L=NS(command=old)
        R=NS(setup_owned_helpers=lambda:None,L=L,PREREQUISITES=NS(DATA={'external':{}}))
        with patch.multiple(C,R=R,B={'external_private_files':{}},COMMANDS=[]):
            self.assertIs(C.setup_owned('ordinary'),L)
            self.assertEqual(L.CURRENT_STAGE,'ordinary');self.assertEqual(L.STAGES,C.STAGES)
            self.assertEqual(L.CPU,12)
            self.assertEqual(L.command(['fake'],'one'),'retained')
            self.assertEqual(old.call_args.args[1],'ordinary-one')
            with self.assertRaisesRegex(ValueError,'Repeated owned command'):
                L.command(['fake'],'one')
            self.assertEqual(old.call_count,1)

    def test_missing_build_review_prevents_runtime(self):
        with self.assertRaisesRegex(ValueError,'Separate reviewed build'):
            C.reviewed_build(None)
        self.native.assert_not_called()

    def test_default_preflight_never_sets_up_native_owner(self):
        protected={};plan={'requests':[]}
        with patch.object(C,'verify_source',return_value=(None,None,None,plan,None,protected)), \
             patch.object(C,'preflight_dependencies',return_value={'files':150,'private_records':3,'native_commands':0}), \
             patch.object(C,'setup_owned') as owned, \
             patch.object(C.sys,'argv',['run.py','build','--reviewed-source-index','seal']):
            C.main()
            owned.assert_not_called()

    def test_card_write_rejects_external_symlink(self):
        output=self.root/'clone';(output/'Cards').mkdir(parents=True)
        outside=self.root/'outside';outside.write_text('protected')
        (output/'Cards/param_card.dat').symlink_to(outside)
        source=self.root/'source';source.write_text('literal')
        with patch.object(C,'HERE',self.root):
            with self.assertRaisesRegex(ValueError,'escapes private clone'):
                C.literal_cards(output,{'physical_card':'source','card':'source'})
        self.assertEqual(outside.read_text(),'protected')

    def test_actual_source_worker_derivative_is_one_backend_argument(self):
        original=(C.OLD/'source/native_job.py').read_text()
        changed=(C.HERE/'native_job.py').read_text()
        self.assertEqual(changed,original.replace("str(int(request['trace_enabled']))","str(request['backend'])"))
        self.assertEqual((C.HERE/'limit_exec.py').read_bytes(),(C.OLD/'source/limit_exec.py').read_bytes())

if __name__=='__main__':unittest.main(verbosity=2)
