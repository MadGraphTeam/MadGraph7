"""Pure mocks/static checks. No compiler, make, loader, or ELF is executed."""
from contextlib import ExitStack
import ast
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('pc_test_build_stage', HERE / 'build_stage.py')
B = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(B)


class BuildStageTests(unittest.TestCase):
    def test_import_is_dormant_and_no_assert_admission(self):
        tree = ast.parse((HERE / 'build_stage.py').read_text())
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))
        self.assertFalse(any(isinstance(node, ast.Call) for item in tree.body
                             if isinstance(item, ast.Expr) for node in ast.walk(item)))
        self.assertEqual(set(B.CHANGED), {'CT_interface.f', 'TIRUST_interface.f',
            'TIR_interface.f', 'loop_matrix.f', 'loop_CT_calls_1.f', 'mp_compute_loop_coefs.f'})

    def test_exact_module_order_and_existing_numerical_flags(self):
        self.assertEqual(B.make_addition(False), '\n.PHONY: pc-objects\npc-objects: check_sa.o\n')
        text = B.make_addition(True)
        self.assertIn('amplitude_support.o: amplitude_support.f90 certificate.o caller_bounds.o', text)
        self.assertIn('caller_bounds.o: caller_bounds.f90 cms_bounds_data.inc', text)
        self.assertEqual(text.count('$(FC) $(FFLAGS) -c $< -o $@ $(LOOP_INCLUDE)'), 3)
        self.assertIn(B.C_COMPILER + ' -fPIC -O2 -c $< -o $@', text)
        self.assertNotIn('make -C', text)

    def test_unchanged_object_with_same_basename_is_not_exempt(self):
        process = 'SubProcesses/' + B.SUBPROCESS + '/CT_interface.o'
        model = 'Source/MODEL/CT_interface.o'
        B.preserved_objects({process: 1, model: 2}, {process: 3, model: 2}, {'CT_interface.o'})
        with self.assertRaisesRegex(ValueError, 'Unchanged object differs'):
            B.preserved_objects({process: 1, model: 2}, {process: 3, model: 4}, {'CT_interface.o'})
        with self.assertRaisesRegex(ValueError, 'disappeared'):
            B.preserved_objects({process: 1}, {}, {'CT_interface.o'})

    def test_c_dependency_parser_rejects_new_headers(self):
        directory = Path('/private/P0')
        raw = 'pc-environment-token: environment_token.c \\\n /nix/stdint.h\n'
        self.assertEqual(B.parse_c_dependencies(raw, directory, {'/nix/stdint.h': {}}),
                         ['/private/P0/environment_token.c', '/nix/stdint.h'])
        for bad in ('different: environment_token.c /nix/stdint.h',
                    'pc-environment-token: environment_token.c /unbound/header.h',
                    'pc-environment-token: /nix/stdint.h',
                    'pc-environment-token: environment_token.c environment_token.c /nix/stdint.h'):
            with self.assertRaises(ValueError):
                B.parse_c_dependencies(bad, directory, {'/nix/stdint.h': {}})

    def test_c_dependency_failure_is_retained_before_compile(self):
        saved = {}
        r = SimpleNamespace(PC_BINDINGS={'c_headers': {'/nix/stdint.h': {}}},
                            command=lambda *args: 'pc-environment-token: environment_token.c /bad.h',
                            PC_SAVE=lambda path, data: saved.update({str(path): dict(data)}))
        with patch.object(B, 'verify_c_toolchain'):
            with self.assertRaisesRegex(ValueError, 'Unadmitted C header'):
                B.capture_c_dependencies(r, Path('/private/P0'), 'deps', Path('/result/deps.json'))
        result = saved['/result/deps.json']
        self.assertFalse(result['passed'])
        self.assertIn('/bad.h', result['raw'])
        self.assertIn('Unadmitted C header', result['failure'])

    def test_private_writes_reject_external_parent_and_link(self):
        output = Path('/private/export')
        target = output / 'source.f'
        with patch.object(Path, 'resolve', side_effect=[Path('/external'), output]), \
             patch.object(Path, 'open') as opened:
            with self.assertRaisesRegex(ValueError, 'external directory'):
                B.write_private(output, target, b'source')
            opened.assert_not_called()
        with patch.object(Path, 'resolve', side_effect=[output, output, Path('/external/source.f'), output]), \
             patch.object(Path, 'is_symlink', return_value=True), patch.object(Path, 'unlink') as unlinked:
            with self.assertRaisesRegex(ValueError, 'external source/card'):
                B.write_private(output, target, b'source')
            unlinked.assert_not_called()

    def exercise_link(self, variant='original', fail_runtime=False, mutate_library=False, repeat_runtime=False):
        output = Path('/private/work/builds/cms') / variant
        directory = output / 'SubProcesses' / B.SUBPROCESS
        results = Path('/private/results')
        prefix = 'SubProcesses/' + B.SUBPROCESS + '/'
        objects = {prefix + 'check_sa.o': {'sha256': 'driver'},
                   prefix + 'polynomial.o': {'sha256': 'poly'},
                   prefix + 'CT_interface.o': {'sha256': 'ct'}}
        library = {'lib/libmodel.a': {'sha256': 'model'}}
        runtime = {'files': {'/nix/provider.so': 'provider'}, 'loader': '/nix/loader'}
        donor = {'prelink_bound': {'/nix/libexternal.a': 'external'}, 'runtime': runtime}
        saved, commands, queries, c_queries = {}, [], [], []
        def save(path, data):
            key = str(path)
            self.assertNotIn(key, saved)
            saved[key] = json.loads(json.dumps(data))
        def old_runtime(exe):
            queries.append(str(exe))
            if fail_runtime:
                raise ValueError('injected loader failure')
            return runtime
        r = SimpleNamespace(RESULTS=results, source_inventory=lambda output: {'source': 'pin'},
            exact_inventory=lambda *args: None, PC_SAVE=save,
            L=SimpleNamespace(runtime=old_runtime),
            command=lambda args, label, cwd, seconds: commands.append((args, label, cwd, seconds)))
        def guarded_runtime(exe, bound, label, closed=None):
            self.assertEqual(bound, {'object': 'pin'})
            self.assertEqual(closed, donor['runtime'])
            return r.L.runtime(exe)
        r.PC_RUNTIME = guarded_runtime
        stages = SimpleNamespace(RESULTS=Path('/old/results'), save=lambda *args: None)
        old_save = stages.save
        def inherited(proxy, key, v, output, changed_only):
            self.assertIsNot(proxy.L, r.L)
            self.assertFalse(changed_only)
            label = key + '-' + v
            proxy.command(['make', '-B', '-j2', '-f', 'ktrace.mk', 'trace-objects'],
                          'compile-' + label, directory, 1500)
            stages.save(results / 'builds' / label / 'prelink.json',
                        {'bound': {'object': 'pin'}, 'completed_before_link': True})
            proxy.command(['make', '-j2', 'check', 'LDFLAGS=-Wl,-Map,ktrace.map'],
                          'link-' + label, directory, 300)
            actual = proxy.L.runtime(directory / 'check')
            if repeat_runtime:
                proxy.L.runtime(directory / 'check')
            receipt = {'runtime': actual, 'executable': str(directory / 'check'),
                       'executable_pin': {'bytes': 4, 'sha256': 'elf'}}
            stages.save(results / 'builds' / label / 'build.json', receipt)
            return receipt
        stages.link_variant = inherited
        def c_dependencies(r, directory, label, destination):
            c_queries.append(label)
            return {'passed': True, 'argv': ['C_DEPENDENCIES_ONLY'], 'actual_dependencies': {}}
        targets = ('check_sa.o',) if variant == 'original' else tuple(
            Path(name).with_suffix('.o').name for name in B.CHANGED) + B.SUPPORT_OBJECTS
        with ExitStack() as stack:
            stack.enter_context(patch.object(B, 'object_inventory', return_value=objects))
            stack.enter_context(patch.object(B, 'library_inventory', side_effect=[library,
                {'lib/libmodel.a': {'sha256': 'changed'}} if mutate_library else library]))
            stack.enter_context(patch.object(B, 'capture_c_dependencies', side_effect=c_dependencies))
            stack.enter_context(patch.object(B, 'verify_c_toolchain'))
            stack.enter_context(patch.object(Path, 'rglob', return_value=[]))
            stack.enter_context(patch.object(Path, 'is_symlink', return_value=False))
            stack.enter_context(patch.object(Path, 'is_file', return_value=True))
            stack.enter_context(patch.object(Path, 'unlink'))
            stack.enter_context(patch.object(Path, 'read_bytes',
                lambda path: json.dumps(saved[str(path)]).encode()))
            if fail_runtime or mutate_library or repeat_runtime:
                with self.assertRaises(ValueError):
                    B.link_one(r, stages, output, variant, donor, targets)
            else:
                result = B.link_one(r, stages, output, variant, donor, targets)
                self.assertEqual(result['compiled_targets'], list(targets))
                self.assertEqual(result['fortran_main_calls'], 0)
                self.assertFalse(result['library_rebuilds'])
        self.assertIs(r.L.runtime, old_runtime)
        self.assertIs(stages.save, old_save)
        self.assertEqual(stages.RESULTS, Path('/old/results'))
        self.assertEqual(len(queries), 1)
        self.assertEqual(len(c_queries), int(variant == 'candidate'))
        self.assertEqual(len(commands), 2)
        compile_args, _, _, _ = commands[0]
        self.assertEqual(compile_args[:3], ['make', '--no-print-directory', '-j2'])
        self.assertEqual(compile_args[-1], 'pc-objects')
        self.assertIn('--old-file=polynomial.o', compile_args)
        self.assertIn('--old-file=/nix/libexternal.a', compile_args)
        for target in targets:
            self.assertNotIn('--old-file=' + target, compile_args)
            self.assertIn('--old-file=' + target, commands[1][0])
        attempt = saved[str(results / 'builds' / variant / 'attempt.json')]
        self.assertEqual(attempt['failure'] is not None,
                         fail_runtime or mutate_library or repeat_runtime)
        return queries

    def test_two_variants_have_exactly_two_guarded_queries(self):
        queries = self.exercise_link('original') + self.exercise_link('candidate')
        self.assertEqual(len(queries), 2)

    def test_loader_failure_retains_attempt_and_restores_hooks(self):
        self.exercise_link(fail_runtime=True)

    def test_changed_library_fails_closed(self):
        self.exercise_link(mutate_library=True)

    def test_second_runtime_query_is_rejected(self):
        self.exercise_link(repeat_runtime=True)


if __name__ == '__main__':
    unittest.main()
