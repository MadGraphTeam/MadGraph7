"""File-backed schema regression using actual retained setup/checker functions.

Only Python imports, JSON parsing and file hashing are allowed. Process launch
and filesystem mutation are blocked; no compiler, loader, clone or build runs.
"""
from contextlib import ExitStack
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / '.tirust-build/kinematic-provenance-current-executor-1/source'
SOURCE_SHA = '7ea709b48d8de462b754fabfb47dcbd5d21d7847458382f5844190028e8c1bed'
CHECKER = 'docs/benchmarkfolder/experiments/current-cms-replay-supervisor-1/prerequisites.py'
CHECKER_SHA = '11fac77b292668ce32c0304c082bc59eb2128edbd669fd097e0d435c04b58b79'


def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class PrerequisiteSchema(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.launch_attempts = []

        def forbidden(*args, **kwargs):
            self.launch_attempts.append((args, kwargs))
            raise AssertionError('No process launch or filesystem mutation is allowed')

        self.stack.enter_context(patch.object(sys, 'dont_write_bytecode', True))
        for name in ('Popen', 'run', 'call', 'check_call', 'check_output'):
            self.stack.enter_context(patch.object(subprocess, name, side_effect=forbidden))
        for name in ('system', 'popen', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp',
                     'execv', 'execve', 'execvp', 'execvpe', 'execl', 'execle', 'execlp',
                     'execlpe', 'spawnv', 'spawnve', 'spawnvp', 'spawnvpe', 'spawnl',
                     'spawnle', 'spawnlp', 'spawnlpe', 'mkdir', 'makedirs', 'unlink',
                     'remove', 'rename', 'replace', 'symlink', 'link'):
            if hasattr(os, name):
                self.stack.enter_context(patch.object(os, name, side_effect=forbidden))
        original_open = Path.open

        def readonly_open(path, mode='r', *args, **kwargs):
            if any(character in mode for character in 'wax+'):
                return forbidden(path, mode)
            return original_open(path, mode, *args, **kwargs)

        self.stack.enter_context(patch.object(Path, 'open', readonly_open))

        # Authenticate the old source packet and every imported inherited helper
        # before executing any of their Python source. No mock replaces them.
        self.assertEqual(pin(SOURCE / 'index.json')['sha256'], SOURCE_SHA)
        index = json.loads((SOURCE / 'index.json').read_bytes())
        for name, expected in index['files'].items():
            path = Path(name)
            self.assertFalse(path.is_absolute() or '..' in path.parts)
            self.assertEqual(pin(SOURCE / path),
                             {key: expected[key] for key in ('bytes', 'sha256')})
        helper_bindings = json.loads((SOURCE / 'helper-bindings.json').read_bytes())
        for name, expected in helper_bindings['files'].items():
            self.assertEqual(pin(ROOT / name),
                             {key: expected[key] for key in ('bytes', 'sha256')})
        self.assertEqual(pin(ROOT / CHECKER)['sha256'], CHECKER_SHA)

        names = ('admission', 'trace_current', 'bypass_contract', 'ktrace_owned',
                 'ktrace_dependencies', 'pc_schema_actual_retained_run',
                 'pc_schema_successor_controller', 'pc_schema_actual_guard',
                 'ktrace_build_guard_controller')
        previous = {name: sys.modules.get(name) for name in names}

        def restore_modules():
            for name, value in previous.items():
                if value is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = value

        self.addCleanup(restore_modules)
        for name in names:
            sys.modules.pop(name, None)
        self.stack.enter_context(patch.object(sys, 'path', [str(SOURCE), *sys.path]))
        load('admission', SOURCE / 'admission.py')
        self.retained = load('pc_schema_actual_retained_run', SOURCE / 'run.py')
        self.controller = load('pc_schema_successor_controller', HERE / 'run.py')
        self.bindings = json.loads((HERE / 'bindings.json').read_bytes())
        self.original_bindings = copy.deepcopy(self.bindings)
        self.controller.R = self.retained
        self.controller.B = self.bindings
        self.original_dependencies = json.loads((SOURCE / 'dependencies.json').read_bytes())
        self.work_existed = self.controller.WORK.exists()
        self.results_existed = self.controller.RESULTS.exists()
        self.owner = self.controller.setup_owned('build')
        self.checker = self.retained.PREREQUISITES
        self.assertEqual(Path(self.checker.__file__).resolve(), (ROOT / CHECKER).resolve())
        self.assertEqual(pin(self.checker.__file__)['sha256'], CHECKER_SHA)

    def tearDown(self):
        self.assertEqual(self.launch_attempts, [])
        if hasattr(self, 'controller'):
            self.assertEqual(self.controller.WORK.exists(), self.work_existed)
            self.assertEqual(self.controller.RESULTS.exists(), self.results_existed)
            self.assertEqual(self.controller.COMMANDS, [])
            self.assertEqual(self.controller.QUERIES, [])
            self.assertEqual(self.bindings, self.original_bindings)

    def test_actual_setup_to_dependency_snapshot_returns_exact_three_bytes_pins(self):
        extra = self.bindings['external_private_files']
        self.assertEqual(len(extra), 3)
        self.assertIs(self.owner, self.retained.L)
        snapshot = self.retained.dependency_snapshot()
        for name, expected in extra.items():
            self.assertEqual(snapshot[name], expected)
            self.assertEqual(set(snapshot[name]), {'bytes', 'sha256'})
            self.assertEqual(self.checker.DATA['external'][name],
                             {'size': expected['bytes'], 'sha256': expected['sha256']})
        for name, expected in self.original_dependencies['external'].items():
            self.assertEqual(self.checker.DATA['external'][name], expected)

    def test_actual_checker_reproduces_raw_bytes_schema_failure(self):
        for name, expected in self.bindings['external_private_files'].items():
            with self.subTest(path=name), self.assertRaises(KeyError) as caught:
                self.checker.check_file(name, expected)
            self.assertEqual(caught.exception.args, ('size',))

    def test_actual_checker_rejects_wrong_size_after_adapter(self):
        for name, expected in self.bindings['external_private_files'].items():
            wrong = {'size': expected['bytes'] + 1, 'sha256': expected['sha256']}
            with self.subTest(path=name), self.assertRaisesRegex(RuntimeError, 'Prebuilt dependency changed'):
                self.checker.check_file(name, wrong)

    def test_actual_checker_rejects_wrong_hash_at_correct_size(self):
        name, expected = min(self.bindings['external_private_files'].items(), key=lambda item: item[1]['bytes'])
        wrong = {'size': expected['bytes'], 'sha256': '0' * 64}
        with self.assertRaisesRegex(RuntimeError, 'Prebuilt dependency changed'):
            self.checker.check_file(name, wrong)

    def test_real_cli_preflight_after_authenticated_guard_prepare(self):
        guard_directory = SOURCE.parent / 'build-admission-1'
        self.assertEqual(pin(guard_directory / 'index.json')['sha256'], self.controller.GUARD_SHA)
        guard_index = json.loads((guard_directory / 'index.json').read_bytes())
        for name, expected in guard_index['files'].items():
            path = Path(name)
            self.assertFalse(path.is_absolute() or '..' in path.parts)
            self.assertEqual(pin(guard_directory / path),
                             {key: expected[key] for key in ('bytes', 'sha256')})
        guard = load('pc_schema_actual_guard', guard_directory / 'guard.py')
        retained, toolchain, _ = guard.prepare(self.controller.GUARD_SHA)
        self.controller.R = retained
        self.controller.G = guard
        self.controller.TOOLCHAIN = toolchain
        result = self.controller.preflight_dependencies('build')
        self.assertEqual(result, {'files': 150, 'private_records': 3, 'native_commands': 0})
        snapshot = retained.dependency_snapshot()
        for name, expected in self.bindings['external_private_files'].items():
            self.assertEqual(snapshot[name], expected)
        preflight_owner = retained.L
        for call in (preflight_owner.command, preflight_owner.runtime):
            self.assertEqual(call.__name__, 'forbidden')
            self.assertEqual(Path(call.__code__.co_filename).resolve(), (HERE / 'run.py').resolve())
        # The later admitted stage must receive a newly initialized owner;
        # checking its identity does not invoke its command or loader methods.
        fresh_owner = self.controller.setup_owned('build')
        self.assertIsNot(fresh_owner, preflight_owner)
        self.assertIsNot(fresh_owner.command, preflight_owner.command)
        self.assertIsNot(fresh_owner.runtime, preflight_owner.runtime)


if __name__ == '__main__':
    unittest.main(verbosity=2)
