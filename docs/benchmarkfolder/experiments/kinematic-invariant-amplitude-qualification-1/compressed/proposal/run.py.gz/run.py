#!/usr/bin/env python3
"""Separately reviewed build/ordinary/stress gates; default is file-only."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'.tirust-build/kinematic-invariant-amplitude-executor-2'
WORK=BASE/'work'
RESULTS=BASE/'results'
OLD=ROOT/'.tirust-build/kinematic-provenance-current-executor-1'
GUARD=OLD/'build-admission-1'
GUARD_SHA='c30fefa33c13dc04cbeed5b12a6a44284d1fc4858c12aa569382ea8a8f8bf813'
STAGES=('build','ordinary','stress')
R=G=B=PLAN=TOOLCHAIN=None
COMMANDS=[]
QUERIES=[]

def require(ok,message):
    if not ok:raise ValueError(message)

def pin(path):
    raw=Path(path).read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def read(path):return json.loads(Path(path).read_bytes())

def save(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:
        json.dump(data,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')

def checked(path,expected):
    require(pin(path)=={k:expected[k] for k in ('bytes','sha256')},'Pinned bytes differ: '+str(path))

def authenticate(path,checksum):
    require(pin(path)['sha256']==checksum,'Reviewed index differs: '+str(path))
    data=read(path)
    for name,expected in data['files'].items():
        p=Path(name);require(not p.is_absolute() and '..' not in p.parts,'Unsafe index path')
        checked(Path(path).parent/p,expected)
    return data

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module

def verify_source(expected):
    authenticate(HERE/'index.json',expected)
    bindings=read(HERE/'bindings.json')
    for name,checksum in bindings['indices'].items():authenticate(ROOT/name,checksum)
    for name,value in bindings['files'].items():checked(ROOT/name,value)
    for category in ('c_toolchain','c_headers','external_private_files','fixed_supplemental_providers'):
        for name,value in bindings[category].items():checked(name,value)
    for name,value in bindings['copied_dependencies'].items():
        checked(ROOT/name,value);checked(ROOT/value['path'],value)
    for value in bindings['support_sources'].values():checked(ROOT/value['path'],value)
    guard=load('pc_original_build_guard',GUARD/'guard.py')
    controller,toolchain,protected=guard.prepare(GUARD_SHA)
    donor=read(ROOT/bindings['donor_build']['path'])
    controller.exact_inventory(Path(donor['output']),donor['sources'])
    for name,checksum in {**donor['prelink_bound'],**donor['runtime']['files']}.items():
        require(pin(name)['sha256']==checksum,'Closed donor input changed: '+name)
    checked(donor['executable'],donor['executable_pin'])
    plan=read(HERE/'validation-plan.json')
    require(len(plan['requests'])==24 and plan['total_outer_entries_max']==48,'Exact scope differs')
    for request in plan['requests']:
        require(request['backend'] in (1,9) and request['requested_mode'] in (1,4),'Unadmitted backend/mode')
        require(request['point'] in (1,20,21) and request['outer_entries_max']==2,'Unadmitted point/count')
    protected={**protected,'proposal_bindings':pin(HERE/'bindings.json'),
               'closed_cms_build':pin(ROOT/bindings['donor_build']['path']),
               'c_toolchain':bindings['c_toolchain'],'c_headers':bindings['c_headers'],
               'external_private_files':bindings['external_private_files']}
    return controller,guard,bindings,plan,toolchain,protected

def setup_owned(stage):
    R.WORK,R.RESULTS=WORK,RESULTS
    R.setup_owned_helpers();L=R.L
    L.STAGES=STAGES;L.CURRENT_STAGE=stage
    L.CPU='12,13' if stage=='build' else 12
    R.PREREQUISITES.DATA['external'].update({name:{'size':value['bytes'],
        'sha256':value['sha256']} for name,value in B['external_private_files'].items()})
    original=L.command
    def recorded(args,name,cwd=ROOT,timeout=600,cpu=True):
        label=stage+'-'+name
        require(label not in COMMANDS,'Repeated owned command; no retry')
        COMMANDS.append(label)
        return original(args,label,cwd,timeout,cpu)
    L.command=recorded
    R.PC_HERE=HERE;R.PC_BINDINGS=B;R.PC_SAVE=save;R.PC_RUNTIME=runtime
    return L

def preflight_dependencies(stage):
    """Exercise the real inherited schema boundary before native admission."""
    L=setup_owned(stage)
    def forbidden(*args,**kwargs):
        raise ValueError('Native command forbidden during file-only dependency preflight')
    L.command=forbidden;L.runtime=forbidden
    snapshot=R.dependency_snapshot()
    require(all(snapshot.get(name)==value for name,value in B['external_private_files'].items()),
            'Inherited snapshot does not preserve bytes/hash clone contract')
    return {'files':len(snapshot),'private_records':len(B['external_private_files']),
            'native_commands':0}

def runtime(executable,bound,label,closed=None):
    require(label not in QUERIES,'Repeated loader query; no retry')
    QUERIES.append(label)
    executable=Path(executable).resolve()
    receipt={'label':label,'executable':str(executable),'passed':False,'loader_query_started':False}
    failure=None
    try:
        receipt['executable_pin']=pin(executable)
        loader=G.compiler_pins(TOOLCHAIN)
        actual=R.L.interpreter(executable);receipt['actual_interpreter']=str(actual)
        require(actual==loader,'PT_INTERP differs before loader query')
        R.L.q.verify_hashes(bound)
        for name,value in B['fixed_supplemental_providers'].items():checked(name,value)
        if closed is not None:
            R.L.q.verify_hashes(closed['files'])
            require(str(actual)==closed['loader'],'Closed loader differs before --list')
        receipt['loader_query_started']=True
        result=R.L.runtime(executable);receipt['runtime']=result
        G.providers(result,bound,B['fixed_supplemental_providers'])
        if closed is not None:
            require(result['loader']==closed['loader'] and result['loader_sha256']==closed['loader_sha256'] and
                    result['files']==closed['files'],'Runtime differs from closed provider set')
        R.L.q.verify_hashes(bound)
        for name,value in B['fixed_supplemental_providers'].items():checked(name,value)
        G.compiler_pins(TOOLCHAIN);checked(executable,receipt['executable_pin'])
        receipt['passed']=True
        return result
    except BaseException as exc:
        failure=exc;raise
    finally:
        receipt['failure']=None if failure is None else repr(failure)
        save(RESULTS/'runtime'/(label+'.json'),receipt)

def reviewed_build(expected):
    require(expected,'Separate reviewed build closure required')
    path=RESULTS/'build-closure.json'
    require(pin(path)['sha256']==expected,'Reviewed closed build differs')
    closure=read(path);require(closure['passed'],'Closed build did not pass')
    require(closure['source_index_sha256']==pin(HERE/'index.json')['sha256'],
            'Closed build belongs to another source packet')
    for name,value in closure['payloads'].items():checked(RESULTS/name,value)
    builds={}
    for variant in ('original','candidate'):
        item=closure['builds'][variant];checked(RESULTS/item['path'],item)
        build=read(RESULTS/item['path']);checked(build['executable'],build['executable_pin'])
        R.exact_inventory(Path(build['output']),build['sources'])
        R.L.q.verify_hashes(build['prelink_bound']);R.L.q.verify_hashes(build['runtime']['files'])
        builds[variant]=build
    require(all(builds['original']['runtime'][key]==builds['candidate']['runtime'][key]
                for key in ('files','loader','loader_sha256')),'Closed variant providers differ')
    return builds

def reviewed_ordinary(expected,build_sha):
    require(expected,'Separate reviewed ordinary closure required')
    path=RESULTS/'ordinary-closure.json'
    require(pin(path)['sha256']==expected,'Reviewed ordinary closure differs')
    closure=read(path);require(closure['passed'],'Ordinary stage did not pass')
    require(closure['source_index_sha256']==pin(HERE/'index.json')['sha256'] and
            closure['reviewed_build_sha256']==build_sha,'Ordinary source/build binding differs')
    for name,value in closure['payloads'].items():checked(RESULTS/name,value)
    comparison=read(RESULTS/'ordinary-comparison.json')
    require(comparison['passed'],'Ordinary comparison did not pass')

def literal_cards(output,request):
    for name,source in [('param_card.dat',request['physical_card']),('MadLoopParams.dat',request['card'])]:
        raw=(HERE/source).read_bytes()
        paths={output/'Cards'/name,*((output/'SubProcesses').rglob(name))}
        for path in paths:
            require(path.resolve().is_relative_to(output.resolve()),'Card path escapes private clone')
            path.write_bytes(raw)

def run_matrix(stage,build_sha,ordinary_sha,source_sha):
    builds=reviewed_build(build_sha)
    if stage=='stress':reviewed_ordinary(ordinary_sha,build_sha)
    requests=[x for x in PLAN['requests'] if x['stage']==stage]
    require(len(requests)=={'ordinary':8,'stress':16}[stage],'Stage request count differs')
    completed=[];failure=None
    try:
        for request in requests:
            R.L.remaining(600)
            build=builds[request['variant']]
            R.exact_inventory(Path(build['output']),build['sources'])
            R.L.q.verify_hashes(build['prelink_bound'])
            checked(build['executable'],build['executable_pin'])
            output=R.private_clone(Path(build['output']),WORK/'workers'/request['id'],keep_objects=True)
            literal_cards(output,request)
            directory=output/'SubProcesses/P0_epem_mupmum'
            evidence=RESULTS/'runs'/request['id'];evidence.mkdir(parents=True,exist_ok=False)
            checked(directory/'check',build['executable_pin'])
            observed=runtime(directory/'check',build['prelink_bound'],request['id'],build['runtime'])
            expected={**observed['files'],str((directory/'check').resolve()):build['executable_pin']['sha256']}
            for key in ('bootstrap','measurement'):
                shutil.copyfile(HERE/request[key],directory/(key+'-input.dat'))
            specification={'request':request,'cwd':str(directory),'expected_runtime':expected,
                'bootstrap_file':str(directory/'bootstrap-input.dat'),'point_file':str(directory/'measurement-input.dat'),
                'bootstrap_pin':pin(directory/'bootstrap-input.dat'),'point_pin':pin(directory/'measurement-input.dat'),
                'executable':str(directory/'check'),'executable_pin':pin(directory/'check'),
                'evidence':str(evidence),'source_index_sha256':source_sha,
                'numerical_card':pin(output/'Cards/MadLoopParams.dat'),'physical_card':pin(output/'Cards/param_card.dat')}
            spec=evidence/'specification.json';save(spec,specification)
            R.command([sys.executable,'-B',HERE/'worker_entry.py',spec,pin(spec)['sha256'],source_sha],
                      'worker-'+request['id'],directory,600)
            result=read(evidence/'result.json')
            require(result['orchestration_complete'],'Incomplete worker retained')
            completed.append(request['id'])
        comparison=load('pc_amplitude_compare',HERE/'amplitude_compare.py').compare_stage(RESULTS/'runs',requests)
        save(RESULTS/(stage+'-comparison.json'),comparison)
        require(comparison['passed'],'Amplitude validity/parity/agreement gate failed; evidence retained')
    except BaseException as exc:
        failure=repr(exc);raise
    finally:
        save(RESULTS/(stage+'-requests.json'),{'requests':requests,'completed':completed,'failure':failure,
            'not_completed':[x for x in requests if x['id'] not in completed],
            'maximum_outer_entries':2*len(requests),'performance_measurement':False})

def closed_payloads(stage):
    paths={RESULTS/('stage-'+stage+'.json'),RESULTS/(stage+'-before.json'),RESULTS/(stage+'-after.json')}
    for label in COMMANDS:
        paths.update({RESULTS/'execution'/(label+'.json'),RESULTS/'execution'/(label+'.txt')})
    for label in QUERIES:paths.add(RESULTS/'runtime'/(label+'.json'))
    if stage=='build':
        paths.add(RESULTS/'build-summary.json')
        for variant in ('original','candidate'):
            folder=RESULTS/'builds'/variant
            if folder.is_dir():paths.update(p for p in folder.rglob('*') if p.is_file())
    else:
        paths.update({RESULTS/(stage+'-comparison.json'),RESULTS/(stage+'-requests.json')})
        for request in PLAN['requests']:
            if request['stage']!=stage:continue
            folder=RESULTS/'runs'/request['id']
            if folder.is_dir():paths.update(p for p in folder.rglob('*') if p.is_file())
    return {str(path.relative_to(RESULTS)):pin(path) for path in sorted(paths) if path.is_file()}

def main():
    global R,G,B,PLAN,TOOLCHAIN
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',nargs='?',choices=STAGES)
    parser.add_argument('--reviewed-source-index',required=True)
    parser.add_argument('--reviewed-build-sha256')
    parser.add_argument('--reviewed-ordinary-sha256')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args();require(Path.cwd()==ROOT,'Run from repository root')
    R,G,B,PLAN,TOOLCHAIN,before=verify_source(args.reviewed_source_index)
    dependency_preflight=preflight_dependencies(args.stage or 'build')
    if not args.execute:
        print(json.dumps({'passed':True,'native_commands':0,'stage':args.stage,'source_index':args.reviewed_source_index,
                          'workers':24,'outer_entries_max':48,'dependency_preflight':dependency_preflight},sort_keys=True));return
    require(args.stage,'One explicit stage required')
    if args.stage!='build':require(args.reviewed_build_sha256,'Separate build review required')
    if args.stage=='stress':require(args.reviewed_ordinary_sha256,'Separate ordinary review required')
    marker=RESULTS/('stage-'+args.stage+'.json')
    require(not marker.exists(),'Append-only stage; no retry')
    save(RESULTS/(args.stage+'-before.json'),before)
    L=setup_owned(args.stage);started=time.monotonic();failure=postfailure=None;lock=None;active=None
    saved_save=save
    with L.cleanup.SignalRequests() as signals:
        L.REQUESTS=R.BudgetRequests(signals)
        try:
            lock=R.acquire(signals);active=time.monotonic()
            cap=PLAN[args.stage]['seconds_total']
            with L.Deadline(cap-60):
                if args.stage=='build':
                    built=load('pc_build_stage',HERE/'build_stage.py').build(R)
                    require(set(built)=={'original','candidate'} and set(QUERIES)=={'original','candidate'},
                            'Build did not close exactly two reviewed ELFs/loader queries')
                else:
                    run_matrix(args.stage,args.reviewed_build_sha256,args.reviewed_ordinary_sha256,args.reviewed_source_index)
                    require(len(QUERIES)=={'ordinary':8,'stress':16}[args.stage],
                            'Runtime query count differs from admitted workers')
        except BaseException as exc:failure=exc
        finally:
            if lock is not None:lock.close()
            try:
                _,_,_,_,_,after=verify_source(args.reviewed_source_index)
                require(after==before,'Protected inputs changed')
                saved_save(RESULTS/(args.stage+'-after.json'),after)
            except BaseException as exc:postfailure=exc
            result={'stage':args.stage,'passed':failure is None and postfailure is None,
                'failure':None if failure is None else repr(failure),
                'postcheck_failure':None if postfailure is None else repr(postfailure),
                'source_index_sha256':args.reviewed_source_index,'reviewed_build_sha256':args.reviewed_build_sha256,
                'reviewed_ordinary_sha256':args.reviewed_ordinary_sha256,
                'owned_command_count':len(COMMANDS),'loader_query_count':len(QUERIES),
                'elapsed_seconds':time.monotonic()-started,
                'elapsed_after_lock':None if active is None else time.monotonic()-active,
                'host_stability_qualified':False,'performance_measurement':False}
            saved_save(marker,result)
            closure={**result,'payloads':closed_payloads(args.stage)}
            if args.stage=='build':
                closure['builds']={v:{'path':'builds/'+v+'/build.json',**pin(RESULTS/'builds'/v/'build.json')}
                                  for v in ('original','candidate') if (RESULTS/'builds'/v/'build.json').is_file()}
            saved_save(RESULTS/(args.stage+'-closure.json'),closure)
    if failure is not None:raise failure
    if postfailure is not None:raise postfailure

if __name__=='__main__':main()
