! Private source-only adapter. No floating-point arithmetic in certificate plumbing.
module ml_private_amplitude_support
  use, intrinsic :: iso_c_binding, only: c_int64_t
  use ml_private_spacelike_certificate, only: pc_ik=>ik, certified_spacelike
  use ml_private_cms_caller_bounds, only: &
    pc_build_chord=>build_chord_bounds, &
    pc_difference_bounds=>finish_difference_bounds, &
    pc_route_matches=>route_matches, &
    read_kinematic_environment_token, environment_ok, environment_unchanged
  implicit none
  private
  public :: pc_ik,pc_build_chord,pc_difference_bounds,pc_route_matches
  public :: pc_dp_bits,pc_qp_bits,pc_capture_env,pc_env_valid
  public :: pc_certify_dp,pc_certify_qp
  integer(pc_ik), parameter :: mask64=maskr(64,pc_ik)
  integer, parameter :: format_assert=1/merge(1,0, &
    storage_size(0.0_8)==64.and.digits(0.0_8)==53.and.radix(0.0_8)==2.and. &
    storage_size(0.0_16)==128.and.digits(0.0_16)==113.and.radix(0.0_16)==2.and. &
    bit_size(0_pc_ik)==128.and.bit_size(0_c_int64_t)==64)
contains
  elemental function pc_dp_bits(x) result(bits)
    real(kind=8), intent(in) :: x
    integer(pc_ik) :: bits
    integer(c_int64_t) :: word
    word=transfer(x,word)
    bits=iand(int(word,pc_ik),mask64)
  end function

  elemental function pc_qp_bits(x) result(bits)
    real(kind=16), intent(in) :: x
    integer(pc_ik) :: bits
    bits=transfer(x,bits)
  end function

  function pc_capture_env() result(token)
    integer(pc_ik) :: token
    integer(c_int64_t) :: small
    small=read_kinematic_environment_token()
    token=iand(int(small,pc_ik),mask64)
  end function

  logical function pc_env_valid(token) result(ok)
    integer(pc_ik), intent(in) :: token
    integer(c_int64_t) :: small
    ok=.false.
    ! No narrowing of an arbitrary malformed token. Low64 converted by TRANSFER.
    if(ishft(token,-64)/=0_pc_ik) return
    small=transfer(ibits(token,0,64),small)
    if(.not.environment_ok(small)) return
    ok=environment_unchanged(small)
  end function

  logical function pc_certify_dp(q,raw,error_exp,pair_class,mass_snap,have,env) result(ok)
    complex(kind=8), intent(in) :: q(0:3),raw
    integer, intent(in) :: error_exp(0:3),pair_class
    logical, intent(in) :: mass_snap,have
    integer(pc_ik), intent(in) :: env
    integer(pc_ik) :: qb(0:3),rb,imaginary(0:4)
    ok=.false.
    if(pair_class/=2.or.mass_snap.or..not.have) return
    if(.not.pc_env_valid(env)) return
    ! Preserve complex subtraction semantics; a nonzero imaginary part is unknown.
    imaginary(0:3)=pc_dp_bits(aimag(q))
    imaginary(4)=pc_dp_bits(aimag(raw))
    if(any(iand(imaginary,maskr(63,pc_ik))/=0_pc_ik)) return
    qb=pc_dp_bits(real(q,kind=8))
    rb=pc_dp_bits(real(raw,kind=8))
    ok=certified_spacelike(qb,rb,error_exp,64,pair_class,mass_snap,have,pc_env_valid(env))
  end function

  logical function pc_certify_qp(q,raw,error_exp,pair_class,mass_snap,have,env) result(ok)
    complex(kind=16), intent(in) :: q(0:3),raw
    integer, intent(in) :: error_exp(0:3),pair_class
    logical, intent(in) :: mass_snap,have
    integer(pc_ik), intent(in) :: env
    integer(pc_ik) :: qb(0:3),rb,imaginary(0:4)
    ok=.false.
    if(pair_class/=2.or.mass_snap.or..not.have) return
    if(.not.pc_env_valid(env)) return
    imaginary(0:3)=pc_qp_bits(aimag(q))
    imaginary(4)=pc_qp_bits(aimag(raw))
    if(any(iand(imaginary,maskr(127,pc_ik))/=0_pc_ik)) return
    qb=pc_qp_bits(real(q,kind=16))
    rb=pc_qp_bits(real(raw,kind=16))
    ok=certified_spacelike(qb,rb,error_exp,128,pair_class,mass_snap,have,pc_env_valid(env))
  end function
end module
