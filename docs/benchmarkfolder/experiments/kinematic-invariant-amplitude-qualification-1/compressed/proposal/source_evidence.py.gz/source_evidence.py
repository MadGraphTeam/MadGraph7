"""Read-only source evidence from the exact authenticated current CMS export."""
import json
import re
from pathlib import Path
import derive_candidate as D

CONTROL_SETTERS=r'\b(?:IEEE_SET_ROUNDING_MODE|IEEE_SET_UNDERFLOW_MODE|IEEE_SET_HALTING_MODE|FESETROUND|FESETENV|FEHOLDEXCEPT|FEUPDATEENV|FEENABLEEXCEPT|FEDISABLEEXCEPT|LDMXCSR|FLDCW)\b'


def environment_audit():
    D.donor_sources()  # Hash every bound source before text inspection.
    path=D.DERIVED/'cms-source-bindings.json'
    bindings=json.loads(path.read_bytes())['files']
    searched=[]
    hits=[]
    pattern=re.compile(CONTROL_SETTERS,re.I)
    for name in bindings:
        p=D.ROOT/name
        if p.suffix.lower() not in ('.f','.f90','.c','.inc'):
            continue
        searched.append(name)
        for number,line in enumerate(p.read_text().splitlines(),1):
            if pattern.search(line):
                hits.append({'path':name,'line':number,'text':line})
    return {'schema':'private-cms-source-environment-audit-v1',
        'source_binding':{'path':str(path.relative_to(D.ROOT)),**D.pin(path)},
        'binding_files':len(bindings),'searched_files':len(searched),
        'pattern':CONTROL_SETTERS,'hits':hits,
        'runtime_control_preservation_qualified':False,
        'scope':'No named control setter in authenticated generated Fortran/model/DHELAS sources; linked-runtime behavior requires native before/after tokens and qualification.'}


if __name__=='__main__':
    out=environment_audit()
    (D.HERE/'environment-source-audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,sort_keys=True))
