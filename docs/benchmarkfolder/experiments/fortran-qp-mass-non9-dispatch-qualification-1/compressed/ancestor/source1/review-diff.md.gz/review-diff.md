# Narrow review delta from the selected9 unit

| Existing selected9 unit | This successor |
|---|---|
| One rendered private LOOP_3; Ninja/NinjaRS omitted | Fourteen exact actual public/private bodies covering all seven n3 helper families; namespace replacement only |
| CHOOSE always records index2/backend9 | Actual chooser for196 helper calls; explicit controlled requested9/actual8 or1 for56 calls; two distinct real-chooser-only controls |
| CTLOOP/TIRLOOP stop; no Ninja/NinjaRS entries | Recording CTLOOP, DP/QP Ninja/NinjaRS and DP COLLIER generic TIR entries; both TIRust targets now fail |
| Genuine113-bit arguments and105-bit MB square | Existing evidence reused; new exact dyadic non9 inputs and finite MP overflow poison test unused-formal behavior |
| Two helper calls and36 records |126 paired cases/252 calls, seven families, precise storage/status/state oracle; synthetic text still does not attest execution |
| Parent physical BUILD includes recording unit | Separate unit-only BUILD/RUN, each180s plus60s cleanup; six compiles/one link;4GiB/256MiB/core0 |

No arithmetic inside an actual helper, chooser or retained pure detector is
edited. `prepare.py` derives those files and proves all public helpers equal
the original arm before the private namespace replacement. `cases.json` binds
each body's original hash and the exact valid rank/call mapping. The new
recording-only COLLIER detector is labelled in source and receipts; it does not
simulate a qualified initialization.

The unit-only controller imports the pinned closed supervisor, retaining its
source location for tool/runtime/support pins. It changes only its child entry,
work/report paths, two stage caps, resource limits, admission bindings and narrow
BUILD/RUN actions. The parent file is unchanged. Its physical campaign routines
are not called. The original same-process five-provider subset is required;
physical15-provider equivalence and per-run maps are not claimed.

No production exporter/template/Rust source or frozen prior packet is changed.
No native stage was executed during source preparation.
