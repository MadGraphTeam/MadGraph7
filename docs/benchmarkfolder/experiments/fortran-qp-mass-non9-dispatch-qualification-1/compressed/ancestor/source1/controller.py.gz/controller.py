#!/usr/bin/env python3
"""Dormant unit-only BUILD/RUN; reuse the closed selected9 supervisor unchanged."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PARENT=ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2'
WORK=ROOT/'.tirust-build/qp-mass-non9-qualification-work-1'
REPORT=ROOT/'.tirust-build/qp-mass-non9-qualification-execution-1'
EXPECTED_SOURCE=None
REVIEWED_BUILD=None


def require(value,message):
    if not value:raise ValueError(message)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module


def verify_source():
    require(Path.cwd()==ROOT,'Run from the required MadGraph repository')
    require(EXPECTED_SOURCE and digest(HERE/'source-index.json')==EXPECTED_SOURCE,'Exact reviewed source seal required')
    seal=read(HERE/'source-index.json')
    actual={str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual==set(seal['files'])|{'source-index.json'},'Source inventory changed')
    for name,row in seal['files'].items():
        path=HERE/name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and not path.is_symlink(),'Unsafe source path')
        require(digest(path)==row['sha256'] and path.stat().st_size==row['bytes'],'Source bytes changed:'+name)
    return True


def supervisor():
    row=read(HERE/'build-spec.json')['dependencies'][str((PARENT/'controller.py').relative_to(ROOT))]
    require(digest(PARENT/'controller.py')==row['sha256'],'Closed supervisor source changed')
    base=load('non9_closed_selected9_supervisor',PARENT/'controller.py')
    # Keep parent HERE for its exact pinned tool environment, loader support and
    # runtime subset policy. Only stage locations/admission and narrow actions
    # change. __file__ directs the owned supervisor child back to this wrapper.
    base.__file__=str(HERE/'controller.py')
    base.WORK=WORK;base.REPORT=REPORT
    base.CAPS={'build':180.,'run':180.};base.CLEANUP=60.
    base.LIMITS={'address_space_bytes':4*1024**3,'file_bytes':256*1024**2,'core_bytes':0}
    base.EXPECTED_SOURCE=EXPECTED_SOURCE;base.REVIEWED={'build':REVIEWED_BUILD}
    base.verify_source=verify_source
    base.protected=lambda:protected(base)
    return base


def protected(base):
    spec=read(HERE/'build-spec.json')
    for name,row in spec['dependencies'].items():
        path=ROOT/name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe dependency path')
        require(path.is_file() and digest(path)==row['sha256'] and path.stat().st_size==row['bytes'],
                'Pinned dependency changed:'+name)
    require(digest(ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/build/terminal.json')==
            '74fd12c5bb49d62a59eee94657e25cb9b27760beb90901f6b2ac07c3416a070a','Closed BUILD2 pin changed')
    prepared=load('non9_pure_preparation',HERE/'prepare.py').verify()
    tools=base.local('tool_environment').validate(read(PARENT/'toolchain-pins.json'),base.environment())
    return {'dependency_bindings':len(spec['dependencies']),'derivation':prepared,'tool_admission':tools,
            'compiler_calls':0,'native_calls':0}


def inventory(directory):
    return {str(p.relative_to(directory)):digest(p) for p in sorted(directory.rglob('*'))
            if p.is_file() and not (p.parent==directory and p.name in {'result.json','terminal.json','console.log'})}


def build(base):
    before=protected(base);spec=read(HERE/'build-spec.json')
    work=WORK/'build';work.mkdir(parents=True,exist_ok=False)
    logs=REPORT/'build/commands'
    def expand(argv):return [s.replace('{source}',str(HERE)).replace('{work}',str(work)) for s in argv]
    for row in spec['compile_commands']:base.command(expand(row['argv']),work,logs,row['label'])
    link=expand(spec['link_command'])
    loader=base.load('non9_closed_loader',ROOT/base.LOADER)
    pre=base.bind_runtime(loader.prelink(link,work,base.environment(),lambda a,n:base.command(a,work,logs,n)))
    base.dump(REPORT/'build/prelink.json',pre)
    base.command(link,work,logs,'link')
    loads=loader.requireactualmap((work/'unit-link.map').read_text(),work,pre,work/'unit_mass_check')
    runtime=base.unit_runtime(work,pre,logs,'unit')
    old=read(ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/build/result.json')['units']['runtime']['files']
    require(runtime['files']==old,'Unit runtime differs from the closed five-provider subset')
    nm=base.command([base.tool('nm'),'--defined-only',str(work/'unit_mass_check')],work,logs,'symbols')
    symbols=[line.split()[-1] for line in nm.splitlines() if line.split()]
    families=read(HERE/'cases.json')['families']
    expected={('n9unit_loop_'+row['name']+suffix+'_').lower()
              for row in families for suffix in ('','_qpmass')}
    observed={name for name in symbols if re.fullmatch(r'n9unit_loop_[0-9_]+(?:qpmass_)?',name)}
    require(observed==expected and all(symbols.count(name)==1 for name in expected),'Exact helper definitions missing/duplicated')
    require(not any('__mtirust_MOD_' in name for name in symbols),'Recording unit contains MTIRUST definitions')
    require(protected(base)==before,'Protected sources/dependencies changed during BUILD')
    result={'status':'passed','stage':'build','source_index_sha256':EXPECTED_SOURCE,
        'output':str(work),'executable_sha256':digest(work/'unit_mass_check'),
        'link_map_sha256':digest(work/'unit-link.map'),'prelink_sha256':digest(REPORT/'build/prelink.json'),
        'objects':{p.name:digest(p) for p in work.iterdir() if p.suffix in {'.o','.mod'}},
        'actual_link_loads':loads,'runtime':runtime,'helper_definitions':sorted(expected),
        'compiler_commands':6,'unit_executions':0,'actual_reducer_calls':0,'protected':before,
        'raw_files':inventory(REPORT/'build')}
    base.dump(REPORT/'build/result.json',result)


def verified_build():
    require(REVIEWED_BUILD and digest(REPORT/'build/terminal.json')==REVIEWED_BUILD,'Separate exact BUILD review required')
    terminal=read(REPORT/'build/terminal.json');row=read(REPORT/'build/result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and
            terminal['source_index_sha256']==EXPECTED_SOURCE and not terminal['cleanup']['survivors'],
            'BUILD did not close successfully')
    require(terminal['result_sha256']==digest(REPORT/'build/result.json') and row['status']=='passed' and
            row['stage']=='build' and row['source_index_sha256']==EXPECTED_SOURCE,'BUILD result binding changed')
    work=Path(row['output'])
    require(work==WORK/'build' and digest(work/'unit_mass_check')==row['executable_sha256'] and
            digest(work/'unit-link.map')==row['link_map_sha256'] and
            digest(REPORT/'build/prelink.json')==row['prelink_sha256'],'Reviewed ELF/link proof changed')
    for name,want in row['objects'].items():require(digest(work/name)==want,'Reviewed object/module changed')
    for name,want in {**row['actual_link_loads'],**row['runtime']['files']}.items():
        require(digest(name)==want,'Reviewed linked/runtime provider changed')
    for name,want in row['raw_files'].items():require(digest(REPORT/'build'/name)==want,'BUILD raw evidence changed')
    return row


def run(base):
    before=protected(base);built=verified_build();work=WORK/'run'
    shutil.copytree(WORK/'build',work)
    require(digest(work/'unit_mass_check')==built['executable_sha256'],'RUN executable copy changed')
    raw=base.command([str(work/'unit_mass_check')],work,REPORT/'run/commands','recording-unit')
    parsed=load('non9_strict_parser',HERE/'parser.py').parse(raw)
    base.dump(REPORT/'run/parsed.json',parsed)
    require(protected(base)==before,'Protected sources/dependencies changed during RUN')
    base.dump(REPORT/'run/result.json',{'status':'passed','stage':'run','source_index_sha256':EXPECTED_SOURCE,
        'reviewed_build':REVIEWED_BUILD,'parsed':parsed,'raw_files':inventory(REPORT/'run'),
        'actual_helper_calls':252,'actual_reducer_calls':0,'physical_amplitudes':0,
        'COLLIER_initialization_qualified':False,'runtime_scope':'Reviewed BUILD loader listing/providers and unchanged ELF; no per-run /proc maps',
        'promotion':False,'physical_accuracy':False,'performance':False})


def main():
    global EXPECTED_SOURCE,REVIEWED_BUILD
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--stage',choices=('build','run'));mode.add_argument('--child',choices=('build','run'))
    parser.add_argument('--execute',action='store_true');parser.add_argument('--source',required=True)
    parser.add_argument('--reviewed-build')
    args=parser.parse_args();EXPECTED_SOURCE=args.source;REVIEWED_BUILD=args.reviewed_build
    for value in (EXPECTED_SOURCE,REVIEWED_BUILD):
        if value is not None and not re.fullmatch('[0-9a-f]{64}',value):parser.error('Exact SHA256 required')
    verify_source();base=supervisor();protected(base)
    selected=args.stage or args.child
    require(bool(REVIEWED_BUILD)==(selected=='run'),'Only RUN requires exactly one separately reviewed BUILD')
    if selected=='run':verified_build()
    if args.child:
        base.limits();base.require_admission(args.child)
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX)
            {'build':lambda:build(base),'run':lambda:run(base)}[args.child]()
    elif args.stage:
        require(args.execute,'BUILD/RUN dormant until separate root admission with --execute')
        base.stage(args.stage)
    else:
        require(not args.execute,'--execute requires an explicit stage')
        require(base.CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
        print(json.dumps({'status':'source-only-preflight-passed','source':EXPECTED_SOURCE,
            'caps':base.CAPS,'cleanup':60,'limits':base.LIMITS,'cpu_reservation':False,
            'native_calls':0,'compiler_calls':0},sort_keys=True))


if __name__=='__main__':main()
