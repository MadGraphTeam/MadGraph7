"""Pure source/parser tests. Block process, loader and floating-library access."""
import ast
import builtins
import ctypes
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest import mock

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


def load(name):
    spec=importlib.util.spec_from_file_location('non9_test_'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    spec.loader.exec_module(module);return module


class SourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.preparation=load('prepare');cls.parser=load('parser')

    def test_exact_source_derivation_and_original_public_identity(self):
        result=self.preparation.verify()
        self.assertEqual(result['actual_helper_bodies'],14)
        self.assertEqual(result['pairs'],126)
        self.assertEqual(result['compiler_commands'],0)

    def test_actual_non9_branches_and_private_actual_index_guard(self):
        text=(HERE/'helpers.f').read_text()
        self.assertEqual(text.count('SUBROUTINE N9UNIT_LOOP_'),14)
        for name in ('CTLOOP','NINJA_LOOP','MP_NINJA_LOOP','NINJARS_LOOP','MP_NINJARS_LOOP','TIRLOOP'):
            self.assertIn('CALL N9UNIT_'+name,text)
        self.assertEqual(text.upper().count('IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.9) THEN'),7)

    def test_matrix_and_explicit_controlled_scope(self):
        spec=json.loads((HERE/'cases.json').read_text())
        self.assertEqual(len(spec['cases']),126)
        self.assertFalse(any(c['selected']==7 and c['mode']>=4 for c in spec['cases']))
        controlled=[c for c in spec['cases'] if c['controlled_selector']]
        self.assertEqual(len(controlled),28)
        self.assertTrue(all(c['requested']==9 and c['selected'] in (1,8) for c in controlled))
        self.assertIn('RECORDING-ONLY DP detector',(HERE/'stubs.f').read_text())

    def test_original_flags_and_finite_poison(self):
        spec=json.loads((HERE/'build-spec.json').read_text())
        self.assertEqual(spec['flags'],['-w','-fPIC','-ffixed-line-length-132'])
        self.assertEqual(len(spec['compile_commands']),6)
        self.assertIn('SCALE(REAL(I,KIND=16),10000)',(HERE/'driver.f').read_text())
        self.assertLess(10000,16384)
        self.assertGreater(2*10000,16384)

    def test_source_syntax_and_no_FP_state_setters(self):
        for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=path.name)
        for name in ('records.f90','stubs.f','driver.f'):
            text=(HERE/name).read_text().lower()
            self.assertNotIn('ieee_set_',text)
            self.assertNotIn('system(',text)
        for path in HERE.glob('*.f'):
            self.assertTrue(all(len(line.expandtabs(8))<=132 for line in path.read_text().splitlines()),path.name)

    def test_positive_synthetic_is_not_execution_attestation(self):
        parsed=self.parser.parse(self.parser.synthetic_stdout())
        self.assertEqual(parsed['actual_helper_calls_required'],252)
        self.assertFalse(parsed['execution_attested_by_parser'])
        self.assertFalse(parsed['real_reducers_executed'])

    def test_closed_supervisor_reuse_is_unit_only_and_bounded(self):
        controller=load('controller');controller.EXPECTED_SOURCE='0'*64
        base=controller.supervisor()
        self.assertEqual(base.CAPS,{'build':180.,'run':180.})
        self.assertEqual(base.CLEANUP,60.)
        self.assertEqual(base.LIMITS,{'address_space_bytes':4*1024**3,'file_bytes':256*1024**2,'core_bytes':0})
        self.assertEqual(base.__file__,str(HERE/'controller.py'))
        self.assertEqual(base.HERE,HERE.parent/'qp-mass-current-qualification-proposal-2')
        self.assertEqual(base.REVIEWED,{'build':None})
        with mock.patch.object(controller,'stage') as patched_stage:
            base.stage('build')
            patched_stage.assert_called_once_with(base,'build')

    def test_missing_execute_cannot_launch_a_stage(self):
        controller=load('controller')
        base=types.SimpleNamespace(stage=denied)
        with mock.patch.object(sys,'argv',['controller.py','--source','0'*64,'--stage','build']),\
             mock.patch.object(controller,'verify_source',return_value=True),\
             mock.patch.object(controller,'supervisor',return_value=base),\
             mock.patch.object(controller,'protected',return_value={}):
            with self.assertRaisesRegex(ValueError,'dormant'):
                controller.main()

    def constructor_failure(self,mismatch=False):
        controller=load('controller');controller.EXPECTED_SOURCE='0'*64
        ownership=controller.load('non9_test_qualified_ownership',HERE/'ownership.py')
        events=[];writes=[];deadlines=[]
        record={'pid':91234,'process_group':91234,'session':91234,'start_time':777}
        class Process:
            pid=91234
            returncode=None
            def poll(self):return self.returncode
            def wait(self,timeout):
                events.append(('wait',timeout));self.returncode=-15;return self.returncode
        process=Process()
        class Requests:
            def __enter__(self):return self
            def __exit__(self,*error):return False
            def check(self):pass
        class Deadline:
            def __init__(self,cap,absolute_end):
                deadlines.append((cap,absolute_end));self.end=absolute_end
                self.handoff=False;self.deferred=False
            def __enter__(self):return self
            def __exit__(self,*error):return False
        def identity(pid):events.append(('identity',pid));return record.copy()
        def construct(proc):events.append(('OwnedChild',proc.pid));raise RuntimeError('constructor regression')
        def matches(value):events.append(('matches',value.copy()));return not mismatch and value==record
        cleanup=types.SimpleNamespace(SignalRequests=Requests,identity=identity,OwnedChild=construct,matches=matches)
        def popen(*args,**kwargs):
            self.assertTrue(kwargs['start_new_session']);events.append(('Popen',));return process
        base=types.SimpleNamespace(CAPS={'build':180.},CLEANUP=60.,CPU=12,LIMITS={},CLEANUP_HELPER='unused',
            load=lambda *a:cleanup,tool=lambda name:'/pinned/'+name,environment=lambda:{},REVIEWED={'build':None},
            subprocess=types.SimpleNamespace(Popen=popen,STDOUT=-2),
            dump=lambda path,value:writes.append((path.name,json.loads(json.dumps(value)))))
        with mock.patch.object(controller,'load',return_value=ownership),\
             mock.patch.object(controller,'verify_source',return_value=True),\
             mock.patch.object(controller,'protected',return_value={}),\
             mock.patch.object(Path,'mkdir',return_value=None),\
             mock.patch.object(Path,'open',return_value=io.BytesIO()),\
             mock.patch.object(ownership,'StageDeadline',Deadline),\
             mock.patch.object(controller.time,'monotonic',return_value=10.),\
             mock.patch.object(ownership.os,'killpg',side_effect=lambda group,sig:events.append(('killpg',group,int(sig)))):
            with self.assertRaisesRegex(RuntimeError,'constructor regression'):
                controller.stage(base,'build')
        self.assertEqual(deadlines,[(180.,190.)])
        self.assertEqual([x[0] for x in events[:3]],['Popen','identity','OwnedChild'])
        terminal=next(value for name,value in writes if name=='terminal.json')
        self.assertEqual(terminal['status'],'failed')
        self.assertTrue(terminal['uncertainty_blocks_later_stages'])
        self.assertEqual(terminal['original_end_monotonic'],190.)
        self.assertEqual(terminal['deadline_monotonic'],190.)
        return terminal,events,record

    def test_constructor_raise_uses_captured_identity_and_bounded_raw_cleanup(self):
        terminal,events,record=self.constructor_failure()
        self.assertEqual(terminal['cleanup']['root'],record)
        self.assertTrue(terminal['cleanup']['failure_only'])
        self.assertEqual([x for x in events if x[0]=='killpg'],[('killpg',91234,15)])
        self.assertEqual([x for x in events if x[0]=='wait'],[('wait',2.)])

    def test_constructor_raise_never_signals_a_mismatched_identity(self):
        terminal,events,_=self.constructor_failure(mismatch=True)
        self.assertIn('Raw child start identity changed',terminal['cleanup_error'])
        self.assertFalse(any(x[0] in ('killpg','wait') for x in events))

    def test_qualified_ownership_source_unchanged(self):
        origin=HERE.parent/'generic-owned-snapshot-qualification-proposal-2/ownership.py'
        self.assertEqual((HERE/'ownership.py').read_bytes(),origin.read_bytes())

    def reject_mutation(self,prefix,edit):
        rows=self.parser.synthetic_stdout().splitlines()
        index=next(i for i,row in enumerate(rows) if row.startswith(prefix))
        edit(rows,index)
        with self.assertRaises(ValueError):self.parser.parse('\n'.join(rows)+'\n')

    def test_missing_duplicate_reordered_extra_rows(self):
        self.reject_mutation('ENTRY ',lambda rows,i:rows.pop(i))
        self.reject_mutation('MASS ',lambda rows,i:rows.insert(i,rows[i]))
        self.reject_mutation('PLD ',lambda rows,i:rows.__setitem__(slice(i,i+2),list(reversed(rows[i:i+2]))))
        with self.assertRaises(ValueError):self.parser.parse(self.parser.synthetic_stdout()+'EXTRA\n')

    def test_backend_precision_mass_status_and_FP_mutations(self):
        for prefix in ('CHOOSE ','ENTRY ','PLD ','PLQ ','MASS ','RESULT ','STATE ','ENV BEFORE ','CONTROL ','END '):
            with self.subTest(prefix=prefix):
                self.reject_mutation(prefix,lambda rows,i:rows.__setitem__(i,rows[i]+' BAD'))


def denied(*args,**kwargs):raise RuntimeError('Native/process access forbidden in pure tests')


if __name__=='__main__':
    with mock.patch.object(subprocess,'Popen',denied),mock.patch.object(subprocess,'run',denied),\
         mock.patch.object(subprocess,'check_output',denied),mock.patch.object(ctypes,'CDLL',denied):
        unittest.main(verbosity=2)
