      SUBROUTINE DETECT_LOOPLIB(LIBNUM,NLOOPLINE,RANK,complex_mass,HAS_HEFT_VERTEX,MAX_SPIN_CONNECTED_TO_LOOP,LPASS)
C
C DETECT WHICH LOOP LIB PASSED
C
      IMPLICIT NONE
C
C CONSTANTS
C
C
C ARGUMENTS
C
      INTEGER LIBNUM,NLOOPLINE,RANK,MAX_SPIN_CONNECTED_TO_LOOP
C     The argument HAS_HEFT_VERTEX is only to implement correctly CutTools limitation
      LOGICAL complex_mass,LPASS,HAS_HEFT_VERTEX
C     
C LOCAL VARIABLES
C
C
C GLOBAL VARIABLES
C
C ----------
C BEGIN CODE
C ----------
      IF(LIBNUM.EQ.1)THEN
C CutTools
         CALL DETECT_CUTTOOLS(NLOOPLINE,RANK,complex_mass,HAS_HEFT_VERTEX,MAX_SPIN_CONNECTED_TO_LOOP,LPASS)
      ELSEIF(LIBNUM.EQ.2)THEN
C PJFry++
         CALL DETECT_PJFRY(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.3)THEN
C IREGI
         CALL DETECT_IREGI(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.4)THEN
C Golem95
         CALL DETECT_GOLEM(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.5)THEN
C Samurai
         CALL DETECT_SAMURAI(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.6)THEN
C Ninja 
         CALL DETECT_NINJA(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.7)THEN
C Collier 
         CALL DETECT_COLLIER(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.8)THEN
C NinjaRS
         CALL DETECT_NINJARS(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSEIF(LIBNUM.EQ.9)THEN
         CALL DETECT_TIRUST(NLOOPLINE,RANK,complex_mass,LPASS)
      ELSE
         STOP 'Unknown MadLoop reduction library; supported IDs are 1 through 9'
      ENDIF
      RETURN
      END

      SUBROUTINE DETECT_CUTTOOLS(NLOOPLINE,RANK,complex_mass,HAS_HEFT_VERTEX,MAX_SPIN_CONNECTED_TO_LOOP,LPASS)
C
C DETECT whether CUTTOOLS CAN BE USED OR NOT
C
      IMPLICIT NONE

C
C CONSTANTS
C
C
C ARGUMENTS
C
      INTEGER NLOOPLINE,RANK
	  INTEGER MAX_SPIN_CONNECTED_TO_LOOP
      LOGICAL complex_mass,LPASS,HAS_HEFT_VERTEX
C
C LOCAL VARIABLES
C
      INTEGER MAX_RANK
C ----------
C BEGIN CODE
C ----------
      LPASS=.TRUE.
C     The limit of 10 loop lines is just a parameter hardcoded in CutTools sources.
C     It can easily be increased if necessary.
C     Also in the presence of spin2 particles, RANK=NLOOPLINE+1 is not supported,
C     or in general whenever the higher rank doesn't come from the Higgs effective vertex.

      IF (MAX_SPIN_CONNECTED_TO_LOOP.le.3.AND.HAS_HEFT_VERTEX) THEN
	    MAX_RANK = NLOOPLINE+1
	  ELSE
	    MAX_RANK = NLOOPLINE
	  ENDIF

      IF( (RANK.GT.MAX_RANK).OR.(NLOOPLINE.gt.10) ) THEN
	    LPASS=.FALSE.	  
	  endif

      RETURN
      END

      SUBROUTINE DETECT_NINJA(NLOOPLINE,RANK,complex_mass,LPASS)
C
C Detect whether Ninja can be used or not
C
      IMPLICIT NONE
C
C CONSTANTS
C
C
C ARGUMENTS
C
      INTEGER NLOOPLINE,RANK
      LOGICAL complex_mass,LPASS
C
C LOCAL VARIABLES
C
C
C GLOBAL VARIABLES
C
C ----------
C BEGIN CODE
C ----------
      LPASS=.TRUE.
C     The limit of rank 20 is just a parameter hardcoded in Ninja sources.
C     It can easily be increased if necessary.
      IF((NLOOPLINE+1.LT.RANK).OR.(RANK.GE.20)) then
	    LPASS=.FALSE.
      endif
      RETURN
      END

      SUBROUTINE DETECT_NINJARS(NLOOPLINE,RANK,complex_mass,LPASS)
C NinjaRS tensor reduction supports rank at most n+2 in both precisions.
      IMPLICIT NONE
      INTEGER NLOOPLINE,RANK
      LOGICAL complex_mass,LPASS
      LPASS=NLOOPLINE.GE.1.AND.RANK.GE.0.AND.
     &      RANK.LE.NLOOPLINE+2
      END

      SUBROUTINE DETECT_TIRUST(NLOOPLINE,RANK,complex_mass,LPASS)
C     The installed bridge qualifies undotted SM tensors through N=R=6.
      IMPLICIT NONE
      INTEGER NLOOPLINE,RANK
      LOGICAL complex_mass,LPASS
      LPASS=NLOOPLINE.GE.1.AND.NLOOPLINE.LE.6.AND.
     &      RANK.GE.0.AND.RANK.LE.6
      END
