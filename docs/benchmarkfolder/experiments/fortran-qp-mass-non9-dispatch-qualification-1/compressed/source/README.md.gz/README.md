# Dormant non9 helper recording unit

This second successor fixes the pre-native source1 supervisor blocker; e5ad
source1 is retained unchanged and was never admitted or executed. No compiler,
linker, loader listing, unit executable or physical reducer
has run. BUILD and RUN remain separately dormant until root admission. The
production QP-mass patch remains unapplied. No broader physical campaign is
included here.

Run from `/shared/external/madloop_tirust/madgraph7_madloop_tirust`.

## Exact code under test

`helpers.f` contains the seven public and seven private generated n3 helpers
from the reviewed current-mass source proposal2. Only the namespace changes
from `ML5_0_` to `N9UNIT_`; `prepare.py` verifies all fourteen bodies exactly,
including public identity against the original arm. Ninja, NinjaRS, CutTools
and generic TIR branches are retained from the actual installed-capability
render. `chooser.f` is the actual generated CHOOSE_LOOPLIB with the same private
namespace and a distinct REAL_CHOOSE name. `detectors.f` contains the actual
detector dispatch and CutTools/Ninja/NinjaRS/TIRust domain checks. Source hashes,
compiler/module/include dependencies and all helper/rank mappings are retained
in `build-spec.json` and `cases.json`.

COLLIER7 is DP only. Its detector is explicitly recording-only; no COLLIER
module, GETMODE call, initialization, numerical kernel or cache is linked or
qualified. Unsupported2/3/4/5 detector entries and both TIRust reduction targets
fail explicitly. The unchanged selected9 genuine113-bit unit is existing
evidence and is not repeated.

## Minimal compiled branch matrix

For each helper family LOOP_2/3/4/3_4/2_3/5/4_5, run public and private entries
with identical state, synthetic valid pairings and a valid rank from an actual
call. Modes1/2 select1/6/7/8; modes4/5 select1/6/8. These196 helper calls use the
real chooser. An additional56 helper calls use an explicitly controlled
selector for requested9 but actual8 or1 in modes4/5, targeting the actual-index
guard. The total is126 paired cases and252 helper calls, plus two separate
real-chooser-only controls: `9|8`, N7/rank6 selects8 in DP, and QP `7|8` skips7
and selects8. No integral is evaluated by those selector controls.

All reduction entries are recording stubs returning labelled synthetic
coefficients. They journal raw DP or QP momenta, legacy DP cyclic squared
masses, actual target, result destination, output/status and read-only IEEE
state. Nonzero dyadic DP masses and dyadic wavefunctions permit an independent
integer storage oracle without another numerical library. QP wavefunctions
contain a term2^-100 so an accidentally narrowed QP momentum is visible.
Private MP mass formals are finite values i*2^10000: squaring them would overflow
binary128. The literal source guard and recorded IEEE state test this diagnostic
under controlled mixed selection. Zero observed flags would not prove that no
hardware instruction executed or qualify trap freedom. This is a branch
diagnostic, not a physical-mass test.

`parser.py` requires the complete ordered raw journal and exact oracle words;
missing/extra/reordered records, wrong backend/precision/group/status or any
changed IEEE flag/rounding/halting state fail. All arithmetic in this fixture
is dyadic and exact, so every observed IEEE flag must remain zero. There is no
FP state setter. Synthetic parser fixtures never attest executable behavior.

## Separate bounded stages

`controller.py` narrowly reuses the closed selected9 controller's tool
environment, command journaling, prelink/link-map checks and runtime-subset
checks. Its original stage dispatcher is not called: successful Popen followed
by an OwnedChild-constructor exception could skip cleanup. The local dispatcher
uses the qualified snapshot ownership helper unchanged, captures the raw child
identity before constructing OwnedChild, and bounds fallback cleanup by the
original absolute deadline. A mismatched identity is never signalled; uncertainty
keeps the stage failed and blocks continuation. Parent source hashes are bound
before import. Pure constructor-raise tests use fake handles and signals.
Default preflight does not compile or execute.

- BUILD: six original-flag compiles plus one link;180s total including60s cleanup.
- RUN: copied reviewed executable, one252-call journal;180s total including60s cleanup.
- Both: 4GiB address space,256MiB per file, core dumps0, nonexclusive CPU12,
  shared numerical mutex, fresh exclusive work/report directories, no retry.
- Flags: `-w -fPIC -ffixed-line-length-132`; no optimization experiment.
- Runtime: the exact previously closed five-provider system/compiler subset,
  authenticated BUILD interpreter listing and unchanged executable/providers.
  This unit adds no per-RUN `/proc` maps and makes no stronger runtime claim.

After separate root source review, use the pinned Python interpreter and the
exact SHA256 of this directory's source-index.json:

```
python3 -B .tirust-build/qp-mass-non9-qualification-proposal-2/controller.py --source <source-sha256>
python3 -B .tirust-build/qp-mass-non9-qualification-proposal-2/controller.py --source <source-sha256> --stage build --execute
python3 -B .tirust-build/qp-mass-non9-qualification-proposal-2/controller.py --source <source-sha256> --reviewed-build <closed-reviewed-build-terminal-sha256> --stage run --execute
```

The RUN command requires a separately reviewed successful BUILD terminal;
creating an admission alone is not a numerical pass. Work is isolated in
`.tirust-build/qp-mass-non9-qualification-work-2`; receipts/logs go to
`.tirust-build/qp-mass-non9-qualification-execution-2`.

The gate can establish compiled helper dispatch/legacy-input parity. It cannot
qualify real reducers, COLLIER initialization, False-policy integrands, complex
model initialization, physical accuracy/rescue, caching, timing or promotion.
Those physical gates remain pending. The source-only review delta is described
in `review-diff.md`; preparation history retains the initial pure-test format
assertion correction.
