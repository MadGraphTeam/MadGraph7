module non9_records
  use aloha_object
  use, intrinsic :: iso_fortran_env, only: int8,int64,real64,real128
  use, intrinsic :: ieee_arithmetic
  use, intrinsic :: ieee_exceptions
  implicit none
  integer :: case_id=0,arm=0,family_id=0,expected_lib=0,controlled_selector=0
  integer :: choose_calls=0,reducer_calls=0,collier_calls=0
  integer :: loop_id,split_id,loop_rank,ctmode,libindex
  real(real64) :: lscale
  logical :: checkphase,heldoublechecked,goodamp(1,116),stable(1,116)
  integer :: goodhel(48),heloffset
  complex(real64) :: loopres(3,1,116),dm(5)
  complex(real128) :: qm(5)
  type(aloha) :: w(35)
  type(mp_aloha) :: mp_w(35)
  logical :: qp_tools_available
  integer :: index_qp_tools(5)
  common /N9UNIT_LOOP/ loop_id,split_id,loop_rank
  common /N9UNIT_CT/ lscale,ctmode
  common /N9UNIT_I_LIB/ libindex
  common /N9UNIT_INIT/ checkphase,heldoublechecked
  common /N9UNIT_FILTERS/ goodamp,goodhel,heloffset
  common /N9UNIT_LOOPRES/ loopres,stable
  common /N9UNIT_W/ w
  common /N9UNIT_MP_W/ mp_w
  common /N9UNIT_LOOP_TOOLS/ qp_tools_available,index_qp_tools
contains
  subroutine header()
    integer(int8) :: endian(8)
    endian=transfer(1_int64,endian)
    if (endian(1)/=1 .or. any(endian(2:)/=0)) error stop 81
    if (digits(0.0_real128)/=113 .or. storage_size(0.0_real128)/=128) error stop 82
    if (digits(0.0_real64)/=53 .or. storage_size(0.0_real64)/=64) error stop 83
    write(*,'(A)') 'META NON9 1 7 126 252 113 128 LITTLE'
  end subroutine

  subroutine dump_dp(label,index,z)
    character(*),intent(in) :: label
    integer,intent(in) :: index
    complex(real64),intent(in) :: z
    integer(int64) :: words(2)
    words=transfer(z,words)
    write(*,'(A,3(1X,I0),2(1X,Z16.16))') trim(label),case_id,arm,index,words
  end subroutine

  subroutine dump_qp(label,index,z)
    character(*),intent(in) :: label
    integer,intent(in) :: index
    complex(real128),intent(in) :: z
    integer(int64) :: words(4)
    words=transfer(z,words)
    write(*,'(A,3(1X,I0),4(1X,Z16.16))') trim(label),case_id,arm,index,words
  end subroutine

  subroutine environment(label)
    character(*),intent(in) :: label
    type(ieee_round_type) :: rounding
    logical :: flags(5),halting(5)
    integer :: code
    call ieee_get_rounding_mode(rounding)
    code=-1
    if (rounding==ieee_nearest) code=0
    if (rounding==ieee_up) code=1
    if (rounding==ieee_down) code=2
    if (rounding==ieee_to_zero) code=3
    call ieee_get_flag(ieee_invalid,flags(1))
    call ieee_get_flag(ieee_divide_by_zero,flags(2))
    call ieee_get_flag(ieee_overflow,flags(3))
    call ieee_get_flag(ieee_underflow,flags(4))
    call ieee_get_flag(ieee_inexact,flags(5))
    call ieee_get_halting_mode(ieee_invalid,halting(1))
    call ieee_get_halting_mode(ieee_divide_by_zero,halting(2))
    call ieee_get_halting_mode(ieee_overflow,halting(3))
    call ieee_get_halting_mode(ieee_underflow,halting(4))
    call ieee_get_halting_mode(ieee_inexact,halting(5))
    write(*,'(A,1X,A,2(1X,I0),11(1X,I0))') 'ENV',trim(label),case_id,arm, &
      code,merge(1,0,flags),merge(1,0,halting)
  end subroutine

  subroutine start_entry(kind,lib,n,rank)
    integer,intent(in) :: kind,lib,n,rank
    if (lib/=expected_lib .or. loop_id/=family_id .or. split_id/=1 .or. loop_rank/=rank) error stop 84
    if ((kind==2) .neqv. (ctmode>=4 .and. (lib==6 .or. lib==8))) error stop 85
    reducer_calls=reducer_calls+1
    write(*,'(A,8(1X,I0))') 'ENTRY',case_id,arm,kind,lib,n,rank,loop_id,split_id
  end subroutine

  subroutine result(res,ok)
    complex(real64),intent(out) :: res(3)
    logical,intent(out) :: ok
    integer :: i
    do i=1,3
      res(i)=cmplx(real(100*expected_lib+10*ctmode+i,real64),-real(i,real64),kind=real64)
    end do
    ok=.true.
  end subroutine

  subroutine record_dp(lib,n,pl,m2l,rank,res,ok)
    integer,intent(in) :: lib,n,rank
    real(real64),intent(in) :: pl(0:3,n)
    complex(real64),intent(in) :: m2l(n)
    complex(real64),intent(out) :: res(3)
    logical,intent(out) :: ok
    integer :: i,j
    integer(int64) :: word
    call start_entry(1,lib,n,rank)
    do i=1,n
      do j=0,3
        word=transfer(pl(j,i),word)
        write(*,'(A,4(1X,I0),1X,Z16.16)') 'PLD',case_id,arm,i,j,word
      end do
      call dump_dp('MASS',i,m2l(i))
    end do
    call result(res,ok)
  end subroutine

  subroutine record_qp(lib,n,pl,m2l,rank,res,ok)
    integer,intent(in) :: lib,n,rank
    real(real128),intent(in) :: pl(0:3,n)
    complex(real64),intent(in) :: m2l(n)
    complex(real64),intent(out) :: res(3)
    logical,intent(out) :: ok
    integer :: i,j
    integer(int64) :: words(2)
    call start_entry(2,lib,n,rank)
    do i=1,n
      do j=0,3
        words=transfer(pl(j,i),words)
        write(*,'(A,4(1X,I0),2(1X,Z16.16))') 'PLQ',case_id,arm,i,j,words
      end do
      call dump_dp('MASS',i,m2l(i))
    end do
    call result(res,ok)
  end subroutine
end module
