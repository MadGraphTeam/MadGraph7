#!/usr/bin/env python3
"""Pure, deterministic source derivation; --emit writes JSON to stdout only."""
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PARENT = ROOT / '.tirust-build/qp-mass-current-qualification-proposal-2'
CASE = ROOT / '.benchmark-work/tirust/campaigns/entry-latch-cache-guard-1/outputs/candidate/qcd_n3_uux_zgg'
PROC = CASE / 'SubProcesses/P0_uux_zgg'
FAMILIES = ('2', '3', '4', '3_4', '2_3', '5', '4_5')
FLAGS = ['-w', '-fPIC', '-ffixed-line-length-132']


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def routine(text, name):
    start = re.search(r'^      SUBROUTINE ' + re.escape(name) + r'\(', text, re.M)
    require(start, 'Missing exact routine: ' + name)
    end = re.search(r'^      END\s*$', text[start.start():], re.M)
    require(end, 'Missing routine END: ' + name)
    return text[start.start():start.start() + end.end()].rstrip() + '\n'


def logical_lines(text):
    rows = []
    for line in text.splitlines():
        if not line or line[0] in 'Cc*!':
            continue
        continuation = len(line) > 5 and line[5] not in ' 0'
        if continuation:
            require(rows, 'Orphan fixed-form continuation')
            rows[-1] += line[6:].strip()
        else:
            rows.append(line[6:].strip())
    return rows


def split_arguments(text):
    output = []; depth = 0; start = 0
    for i, char in enumerate(text):
        if char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
        elif char == ',' and depth == 0:
            output.append(text[start:i].strip()); start = i + 1
    output.append(text[start:].strip())
    return output


def call_lines(name, args):
    result = []; line = '      CALL ' + name + '('
    for i, arg in enumerate(args):
        token = arg + (',' if i + 1 < len(args) else ')')
        if len(line) + len(token) > 100:
            result.append(line); line = '     $ '
        line += token
    result.append(line)
    return '\n'.join(result)


def derive():
    candidate_path = PARENT / 'source-preview/candidate/CT_interface.f'
    original_path = PARENT / 'source-preview/original/CT_interface.f'
    calls_path = PARENT / 'source-preview/candidate/loop_CT_calls_1.f'
    candidate = candidate_path.read_text(); original = original_path.read_text()
    calls = logical_lines(calls_path.read_text())
    helpers = []; families = []; helper_pins = {}
    for number, family in enumerate(FAMILIES, 1):
        name = 'ML5_0_LOOP_' + family
        public = routine(candidate, name); private = routine(candidate, name + '_QPMASS')
        require(public == routine(original, name), 'Public helper changed: ' + name)
        for body in (public, private):
            helpers.append(body.replace('ML5_0_', 'N9UNIT_'))
        header = logical_lines(public)[0]
        formals = split_arguments(header[header.index('(') + 1:-1])
        actual = next(x for x in calls if x.startswith('CALL ' + name + '('))
        actual = split_arguments(actual[actual.index('(') + 1:-1])
        rank = int(actual[-3]); n = int(family.split('_')[0])
        nw = n if '_' not in family else int(family.split('_')[1])
        require(0 <= rank <= n, 'Selected actual rank outside non9 common support')
        pairings = [1] * n; pairings[-1] += nw - n
        args = []
        for arg in formals:
            if re.fullmatch('P[0-9]+', arg):
                args.append(str(pairings[int(arg[1:]) - 1]))
            elif re.fullmatch('W[0-9]+', arg):
                args.append(arg[1:])
            elif re.fullmatch('M[0-9]+', arg):
                args.append('DM(' + arg[1:] + ')')
            elif arg == 'RANK': args.append(str(rank))
            elif arg == 'SQUAREDSOINDEX': args.append('1')
            elif arg == 'LOOPNUM': args.append(str(number))
            else: raise ValueError('Unknown public formal: ' + arg)
        qp_args = []
        for arg in args:
            qp_args.append(arg)
            if arg.startswith('DM('): qp_args.append(arg.replace('DM(', 'QM('))
        families.append({'index':number, 'name':family, 'N':n, 'NW':nw, 'rank':rank,
                         'pairings':pairings, 'public_arguments':args, 'private_arguments':qp_args})
        helper_pins[name] = {'public_sha256':hashlib.sha256(public.encode()).hexdigest(),
                            'private_sha256':hashlib.sha256(private.encode()).hexdigest()}
    helper_text = '\n'.join(helpers)
    for needed in ('NINJA_LOOP', 'MP_NINJA_LOOP', 'NINJARS_LOOP', 'MP_NINJARS_LOOP', 'TIRLOOP', 'CTLOOP'):
        require(needed in helper_text, 'Installed compiled branch missing: ' + needed)
    chooser_path = PROC / 'TIR_interface.f'
    chooser = routine(chooser_path.read_text(), 'ML5_0_CHOOSE_LOOPLIB')
    chooser = chooser.replace('ML5_0_CHOOSE_LOOPLIB', 'N9UNIT_REAL_CHOOSE_LOOPLIB').replace('ML5_0_', 'N9UNIT_')
    commons_path = ROOT / 'Template/loop_material/StandAlone/SubProcesses/MadLoopCommons.inc'
    detector_names = ('DETECT_LOOPLIB', 'DETECT_CUTTOOLS', 'DETECT_NINJA', 'DETECT_NINJARS', 'DETECT_TIRUST')
    detector_text = '\n'.join(routine(commons_path.read_text(), name) for name in detector_names)
    cases = []
    for family in families:
        for mode, libs in ((1,(1,6,7,8)), (2,(1,6,7,8)), (4,(1,6,8)), (5,(1,6,8))):
            for lib in libs:
                cases.append({'family':family['index'], 'mode':mode, 'requested':lib,
                              'selected':lib, 'selected_index':1, 'controlled_selector':0})
        for mode in (4,5):
            for lib in (8,1):
                cases.append({'family':family['index'], 'mode':mode, 'requested':9,
                              'selected':lib, 'selected_index':2, 'controlled_selector':1})
    require(len(cases) == 126, 'Unexpected unit case count')
    for i, case in enumerate(cases, 1): case['case'] = i
    dispatch = []
    for family in families:
        name = 'N9UNIT_LOOP_' + family['name']
        dispatch += ['      CASE(' + str(family['index']) + ')', '        IF(ARM.EQ.1) THEN',
                     call_lines(name, family['public_arguments']), '        ELSE',
                     call_lines(name + '_QPMASS', family['private_arguments']), '        ENDIF']
    table = '\n'.join('      CALL RUN_CASE(' + ','.join(str(case[k]) for k in
                     ('case','family','mode','requested','selected','controlled_selector')) + ')' for case in cases)
    driver = (HERE / 'driver.f.in').read_text().replace('@CASES@', table).replace('@DISPATCH@', '\n'.join(dispatch))
    dependency_paths = [candidate_path, original_path, calls_path, chooser_path, commons_path,
                        PROC/'process_info.inc', CASE/'Source/DHELAS/aloha_object.mod',
                        CASE/'Source/DHELAS/aloha_functions.f', CASE/'SubProcesses/MadLoopParams.inc',
                        PARENT/'controller.py', PARENT/'source-index.json', PARENT/'support-pins.json',
                        PARENT/'toolchain-pins.json', PARENT/'tool_environment.py', PARENT/'input-pins.json',
                        PARENT/'units/build-spec.json',
                        ROOT/'.tirust-build/qp-mass-non9-qualification-proposal-1/source-index.json',
                        ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/ownership.py',
                        ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/build/terminal.json',
                        ROOT/'.tirust-build/qp-mass-current-qualification-execution-2/build/result.json',
                        ROOT/'tools/tirust_benchmark.py', ROOT/'tools/tirust_benchmark_compiler.py',
                        ROOT/'tools/tirust_benchmark_worker.py', ROOT/'tools/tirust_benchmark_warmup.py']
    dependencies = {str(path.relative_to(ROOT)): {'sha256':sha(path), 'bytes':path.stat().st_size}
                    for path in dependency_paths}
    compiler = json.loads((PARENT/'toolchain-pins.json').read_text())['required_tools']['gfortran']['path']
    sources = ['records.f90', 'helpers.f', 'chooser.f', 'detectors.f', 'stubs.f', 'driver.f']
    common = FLAGS + ['-I','{work}','-I',str(CASE/'Source/DHELAS'),'-I',str(CASE/'SubProcesses'),
                      '-I',str(PROC),'-J','{work}']
    specification = {'schema':'non9-recording-unit-build-spec-v1', 'sources':sources,
        'dependencies':dependencies, 'flags':FLAGS, 'native_commands_executed':0,
        'compile_commands':[{'label':'compile-'+Path(name).stem, 'argv':[compiler,*common,'-c',
                             '{source}/'+name,'-o','{work}/'+Path(name).stem+'.o']} for name in sources],
        'link_command':[compiler,'-Wl,-Map,unit-link.map,--cref',
                        *['{work}/'+Path(name).stem+'.o' for name in sources],'-o','{work}/unit_mass_check'],
        'execution_command':['{work}/unit_mass_check']}
    metadata = {'schema':'non9-recording-unit-source-derivation-v1', 'families':families, 'cases':cases,
        'helper_origins':helper_pins, 'prefix_replacement_only':['ML5_0_','N9UNIT_'],
        'actual_public_private_helpers':14, 'actual_chooser':True,
        'actual_detectors':list(detector_names), 'COLLIER_detector':'explicit recording-only DP domain stub',
        'helper_pairs':126, 'helper_calls':252, 'real_chooser_only_controls':2,
        'real_reducer_calls':0, 'physical_inputs':False}
    return {'helpers.f':helper_text, 'chooser.f':chooser, 'detectors.f':detector_text, 'driver.f':driver,
            'cases.json':json.dumps(metadata,sort_keys=True,indent=2)+'\n',
            'build-spec.json':json.dumps(specification,sort_keys=True,indent=2)+'\n'}


def verify():
    predecessor=ROOT/'.tirust-build/qp-mass-non9-qualification-proposal-1'
    require(sha(predecessor/'source-index.json')=='e5ad27c3cd698f25c74b38711f98e9e90c2c12de7da259ef414aafc8dc725f44',
            'Unadmitted source1 index changed')
    old=json.loads((predecessor/'source-index.json').read_text())
    require({str(p.relative_to(predecessor)) for p in predecessor.rglob('*') if p.is_file()}==
            set(old['files'])|{'source-index.json'},'Unadmitted source1 inventory changed')
    for name,row in old['files'].items():
        path=predecessor/name
        require(sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],'Unadmitted source1 bytes changed')
    payload = derive()
    for name, text in payload.items():
        require((HERE/name).read_text() == text, 'Derived source changed: ' + name)
    return {'derived_files':len(payload), 'actual_helper_bodies':14, 'pairs':126,
            'native_commands':0, 'compiler_commands':0}


if __name__ == '__main__':
    if sys.argv[1:] == ['--emit']:
        print(json.dumps(derive()))
    elif not sys.argv[1:]:
        print(json.dumps(verify(),sort_keys=True))
    else:
        raise SystemExit('usage: prepare.py [--emit]')
