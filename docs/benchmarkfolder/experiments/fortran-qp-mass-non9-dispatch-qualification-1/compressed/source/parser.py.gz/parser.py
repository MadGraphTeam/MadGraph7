"""Strict text-only oracle for this dyadic recording unit, never execution proof."""
from fractions import Fraction
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def require(value,message):
    if not value:raise ValueError(message)


def words(value,precision):
    """Encode exactly representable finite normals using integer arithmetic."""
    value=Fraction(value)
    width,bias=(64,1023) if precision==53 else (128,16383)
    if not value:bits=0
    else:
        sign=int(value<0);value=abs(value)
        exponent=value.numerator.bit_length()-value.denominator.bit_length()
        if value<Fraction(2)**exponent:exponent-=1
        significand=value/Fraction(2)**(exponent-precision+1)
        require(significand.denominator==1,'Fixture value is not exactly representable')
        require(0<exponent+bias<(2047 if width==64 else 32767),'Fixture is outside finite normals')
        bits=(sign<<(width-1))|((exponent+bias)<<(precision-1))|(int(significand)-(1<<(precision-1)))
    return [f'{(bits>>(64*i))&((1<<64)-1):016X}' for i in range(width//64)]


def cwords(real,imag=0,precision=53):return words(real,precision)+words(imag,precision)


def expected_rows():
    spec=json.loads((HERE/'cases.json').read_text())
    rows=[['META','NON9','1','7','126','252','113','128','LITTLE']]
    def row(*items):rows.append([str(item) for item in items])
    def env(label,case,arm):row('ENV',label,case,arm,*([0]*11))
    env('INITIAL',0,0)
    for i in range(1,6):
        row('DMASS',0,0,i,*cwords(1+Fraction(i,4)))
        row('QMASS',0,0,i,*cwords(i*Fraction(2)**10000,precision=113))
    env('PREPARED',0,0)
    total=0;collier=0
    for case in spec['cases']:
        f=spec['families'][case['family']-1]
        n=f['N'];rank=f['rank'];lib=case['selected'];mode=case['mode'];case_id=case['case']
        kind=2 if mode>=4 and lib in (6,8) else 1
        for arm in (1,2):
            total+=1
            if lib==7:collier+=1
            row('BEGIN',case_id,arm,f['index'],mode,case['requested'],lib,case['controlled_selector'])
            env('BEFORE',case_id,arm)
            row('CHOOSE',case_id,arm,case['controlled_selector'],1,case['requested'],
                case['selected_index'],lib,n,rank,0,int(mode>=4))
            row('ENTRY',case_id,arm,kind,lib,n,rank,f['index'],1)
            offset=1
            for j,pair in enumerate(f['pairings'],1):
                for component in range(4):
                    momentum=-sum((Fraction(w)+Fraction(component,8)+
                                  (Fraction(1,1<<100) if kind==2 else 0))
                                  for w in range(offset,offset+pair))
                    row('PLQ' if kind==2 else 'PLD',case_id,arm,j,component,
                        *words(momentum,113 if kind==2 else 53))
                mass_index=n if j==1 else j-1
                row('MASS',case_id,arm,j,*cwords((1+Fraction(mass_index,4))**2))
                offset+=pair
            for i in range(1,4):
                row('RESULT',case_id,arm,i,*cwords(100*lib+10*mode+i,-i))
            row('STATE',case_id,arm,f['index'],1,rank,1,total,total)
            env('AFTER',case_id,arm)
    row('CONTROL',1,1,9,2,8,7,6)
    row('CONTROL',2,1,7,2,8,3,2)
    env('FINAL',0,0)
    row('END','NON9',126,total,total,collier)
    require(total==252 and collier==28,'Source case matrix changed')
    return rows


def parse(text):
    require(isinstance(text,str),'stdout must be text')
    rows=[line.split() for line in text.splitlines() if line.strip()]
    expected=expected_rows()
    require(len(rows)==len(expected),'Missing/extra recording-unit row')
    for index,(actual,wanted) in enumerate(zip(rows,expected),1):
        require(actual==wanted,'Non9 record differs at line '+str(index)+': '+wanted[0])
    return {'schema':'non9-dyadic-recording-unit-parser-v1','verified':True,
        'helper_families':7,'paired_cases':126,'actual_helper_calls_required':252,
        'actual_chooser_helper_calls_required':196,'controlled_selector_helper_calls_required':56,
        'real_chooser_only_controls':2,'COLLIER_recording_only_DP_detector_calls':28,
        'raw_records':len(rows),'independent_integer_dyadic_oracle':True,
        'DP_and_QP_momenta_distinguished':True,'legacy_DP_squared_masses_unchanged':True,
        'finite_overflow_poison_and_source_guard_checked':True,'all_observed_IEEE_states_zero':True,
        'real_reducers_executed':False,'COLLIER_initialization_qualified':False,
        'physical_accuracy_qualified':False,'performance_qualified':False,
        'execution_attested_by_parser':False}


def synthetic_stdout():
    """Positive parser fixture; expressly not an observed Fortran journal."""
    return '\n'.join(' '.join(row) for row in expected_rows())+'\n'
