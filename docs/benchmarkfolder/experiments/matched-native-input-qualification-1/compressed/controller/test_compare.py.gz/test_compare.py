"""Pure retained-file tests; synthetic evidence never runs a native reducer."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

import compare as C

ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
FAKE_SOURCE_SHA='a'*64


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
    raw=Path(path).read_bytes()
    actual=pin(raw)
    matches=actual['sha256']==expected if isinstance(expected,str) else actual==expected
    if not matches:
        raise ValueError('Synthetic fixture source changed: '+str(path))
    return raw


def fixture_module(path,expected,name,anchor,bindings):
    source=checked(path,expected).decode('utf-8')
    if source.count(anchor)!=1:
        raise ValueError('Synthetic fixture import anchor differs')
    module=types.ModuleType(name);module.__file__=str(path)
    module.__dict__.update(bindings)
    exec(compile(source.replace(anchor,'# Authenticated module injected by pure test.',1),str(path),'exec'),module.__dict__)
    return module


def request(backend):
    return {'id':f'cms-p20-mode4-lib{backend}-matched','variant':'matched','stage':'run',
            'backend':backend,'requested_mode':4,'point':20,'expected_fixed_unchecked_return':120,
            'bootstrap_calls':1,'measurement_calls':1,'outer_entries_max':2,
            'card':f'backend{backend}-mode4-MadLoopParams.dat','physical_card':'inputs/cms-param_card.dat',
            'bootstrap':'inputs/cms-point1.dat','measurement':'inputs/cms-point20.dat'}


class MatchedCompare(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.science=C._scientific_source()
        cls.legacy=C._legacy()
        old_index=json.loads(checked(OLD/'index.json',OLD_SHA))
        cls.fixture=fixture_module(OLD/'test_amplitude_compare.py',old_index['files']['test_amplitude_compare.py'],
            'private_matched_outer_fixture','import amplitude_compare as C',{'C':cls.legacy})
        science_index=json.loads(checked(C.SCIENCE/'index.json',C.MATCHED_SHA))
        cls.trace_fixture=fixture_module(C.SCIENCE/'test_matched_inputs.py',science_index['files']['test_matched_inputs.py'],
            'private_matched_trace_fixture','import matched_inputs as M',{'M':cls.science['module']})

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name);self.runs=self.base/'results/runs';self.runs.mkdir(parents=True)
        self.requests=[request(8),request(9)]
        self.executable=self.base/'build/check';self.executable.parent.mkdir()
        self.executable.write_bytes(b'synthetic executable bytes; never loaded or executed\n')
        self.build={'variant':'matched','executable':str(self.executable),'executable_pin':pin(self.executable.read_bytes()),
                    'runtime':{'files':{}},'prelink_bound':{}}
        self.build_file=self.runs.parent/'builds/matched/build.json';self.build_file.parent.mkdir(parents=True)
        self.build_file.write_text(json.dumps(self.build,sort_keys=True))
        self.saved={'observation':{'id':'saved-ordinary-candidate9-QP','eligible':True,'failures':[],
                    'raw_rows':[{'phase':1,'point':1,'order':order,'call':2,'code':120,
                        'words':[self.fixture.word(x) for x in (1.,2.,-3.,4.,-1.)]} for order in (0,1)]},
                    'source_evidence':{'synthetic_saved_control':True}}
        self.legacy._MATCHED_GATE_OPEN=False
        for name,value in (('_controller_source',{'sha256':FAKE_SOURCE_SHA}),
                           ('_scientific_source',self.science),('_legacy',self.legacy),('_saved_control',self.saved)):
            patch=mock.patch.object(C,name,return_value=value)
            mocked=patch.start();self.addCleanup(patch.stop)
            setattr(self,name+'_mock',mocked)

    def calls(self,backend):
        calls=self.trace_fixture.synthetic_calls(backend)
        for call in calls:
            route=self.science['routes'][call['group']]
            call['meta'].update(ROUTE=[route['nw'],1,1],WE=route['we'][:],PAIRING=route['pairing'][:])
        return calls

    def worker(self,backend,*,coefs=(1.,2.,-3.,4.),bootstrap=(1.,2.,-3.,4.),flags=(0,0),warning=False,
               native_status=0,input_mismatch=False,nonfinite_input=None):
        req=request(backend)
        d=self.fixture.make_worker(self.runs,req,100+backend,coefs=coefs,final_flags=flags,warning=warning)
        calls=self.calls(backend)
        calls[28]['status']=native_status
        if input_mismatch:
            word=calls[0]['words']['SCALE'][0]
            calls[0]['words']['SCALE'][0]=f'{int(word,16)^1:032X}'
        if nonfinite_input is not None:
            calls[0]['words']['CANON'][0]=nonfinite_input
            calls[0]['words']['WIRE']=self.science['module'].expected_wire(
                calls[0]['words']['CANON'],backend,calls[0]['nc'])
        (d/'trace.dat').write_text(self.trace_fixture.render(calls))
        rows=(d/'driver-bits.dat').read_text().splitlines()
        for index in (0,1):
            fields=rows[index].split();fields[5:]=[self.fixture.word(x) for x in (*bootstrap,-1.)]
            rows[index]=' '.join(fields)
        (d/'driver-bits.dat').write_text('\n'.join(rows)+'\n')
        (d/'bootstrap-values.dat').write_text(''.join(f'1 1 {order} 120 '+' '.join(map(str,(*bootstrap,-1.)))+'\n' for order in (0,1)))
        self.fixture.reseal(d)
        cwd=self.base/'work/workers'/req['id']/'SubProcesses/P0_epem_mupmum';cwd.mkdir(parents=True)
        cards=cwd.parents[1]/'Cards';cards.mkdir()
        numerical=(C.SCIENCE/req['card']).read_bytes();(cards/'MadLoopParams.dat').write_bytes(numerical)
        physical=(C.SCIENCE/'inputs'/C.POINTS['physical_card']).read_bytes();(cards/'param_card.dat').write_bytes(physical)
        bootstrap_raw=(C.SCIENCE/'inputs'/C.POINTS['bootstrap']).read_bytes()
        point_raw=(C.SCIENCE/'inputs'/C.POINTS['measurement']).read_bytes()
        (cwd/'bootstrap-input.dat').write_bytes(bootstrap_raw);(cwd/'measurement-input.dat').write_bytes(point_raw)
        exe=cwd/'check';exe.write_bytes(self.executable.read_bytes())
        expected_runtime={str(exe):self.build['executable_pin']['sha256']}
        spec={'request':req,'cwd':str(cwd),'expected_runtime':expected_runtime,
            'bootstrap_file':str(cwd/'bootstrap-input.dat'),'point_file':str(cwd/'measurement-input.dat'),
            'bootstrap_pin':pin(bootstrap_raw),'point_pin':pin(point_raw),
            'executable':str(exe),'executable_pin':pin(exe.read_bytes()),'evidence':str(d),
            'source_index_sha256':FAKE_SOURCE_SHA,'scientific_source_index_sha256':C.MATCHED_SHA,
            'build_receipt_sha256':pin(self.build_file.read_bytes())['sha256'],
            'numerical_card':pin(numerical),'physical_card':pin(physical)}
        (d/'specification.json').write_text(json.dumps(spec))
        native=json.loads((d/'result.json').read_text())
        for capture in native['runtime_maps']:
            capture['elf']=expected_runtime.copy()
        (d/'result.json').write_text(json.dumps(native))
        return d

    def complete(self,**first):
        self.worker(8,**first);self.worker(9)
        return self.compare()

    def compare(self):
        return C.compare_stage(self.runs,self.requests,controller_source_sha=FAKE_SOURCE_SHA,build_receipt=self.build)

    def assert_no_decoding(self):
        with mock.patch.object(self.legacy,'decode64',side_effect=AssertionError('Blocked coefficients decoded')):
            report=self.compare()
        self.assertFalse(report['passed'])
        self.assertFalse(report['measurement_interpretation_allowed'])
        self.assertFalse(report['measurement_comparison']['eligible'])
        self.assertNotIn('residuals',report['measurement_comparison'])
        self._saved_control_mock.assert_not_called()
        return report

    def test_valid_full_gate_includes_all_columns_and_retains_limits(self):
        result=self.complete()
        self.assertTrue(result['passed']);self.assertTrue(result['execution_complete'])
        self.assertTrue(result['native_input_gate_passed']);self.assertTrue(result['outer_output_gate_passed'])
        self.assertTrue(result['bootstrap_controls_passed']);self.assertTrue(result['measurement_interpretation_allowed'])
        self.assertTrue(result['native_inputs_finite']);self.assertEqual(result['nonfinite_native_inputs'],[])
        self.assertEqual(result['outer_entries_observed'],4);self.assertEqual(result['ready_done_maps'],4)
        self.assertEqual(len(result['bootstrap_comparisons']),2)
        self.assertTrue(all(len(row['residuals'])==8 for row in result['bootstrap_comparisons']))
        self.assertEqual(len(result['measurement_comparison']['residuals']),8)
        self.assertEqual(result['input_match']['parsed'][0]['phase_call_counts'],[26,26])
        json.dumps(result,allow_nan=False)

    def test_completed_native_status_failure_blocks_both_outputs(self):
        self.worker(8,native_status=1,coefs=(123.,2.,-3.,4.));self.worker(9)
        result=self.assert_no_decoding()
        self.assertTrue(result['execution_complete']);self.assertFalse(result['native_input_gate_passed'])
        self.assertEqual(result['outer_entries_observed'],4);self.assertEqual(result['ready_done_maps'],4)
        self.assertTrue(result['input_match']['exact_input_match'])
        self.assertFalse(result['input_match']['native_status_qualified'])

    def test_native_nan_and_infinity_are_detected_in_every_input_tag(self):
        module=self.science['module']
        joined=module.join_inputs(self.trace_fixture.render(self.calls(8)),self.trace_fixture.render(self.calls(9)),
                                 self.science['routes'],caller_binding_verified=True)
        call=joined['parsed'][0]['calls'][0]
        for tag in module.WORD_TAGS:
            original=call['words'][tag][0]
            for sign in (0,1<<127):
                for payload in (0,1,1<<111): # Infinity, signaling NaN, quiet NaN.
                    word=f'{sign|(0x7FFF<<112)|payload:032X}'
                    with self.subTest(tag=tag,word=word):
                        call['words'][tag][0]=word
                        found=C._finite_inputs(joined)
                        self.assertEqual(found,[{'backend':8,'key':call['key'],'seq':call['seq'],
                            'field':tag,'index':0,'word':word}])
            call['words'][tag][0]=original

    def test_finite_extremes_subnormals_and_signed_zero_pass_integer_gate(self):
        module=self.science['module']
        joined=module.join_inputs(self.trace_fixture.render(self.calls(8)),self.trace_fixture.render(self.calls(9)),
                                 self.science['routes'],caller_binding_verified=True)
        call=joined['parsed'][0]['calls'][0]
        for tag in module.WORD_TAGS:
            original=call['words'][tag][0]
            for sign in (0,1<<127):
                for magnitude in (0,1,(1<<112)-1,1<<112,(0x7FFF<<112)-1):
                    word=f'{sign|magnitude:032X}'
                    with self.subTest(tag=tag,word=word):
                        call['words'][tag][0]=word
                        self.assertEqual(C._finite_inputs(joined),[])
            call['words'][tag][0]=original

    def test_identical_native_nan_with_success_status_blocks_all_output_arithmetic(self):
        word=f'{(0x7FFF<<112)|(1<<111):032X}'
        self.worker(8,nonfinite_input=word);self.worker(9,nonfinite_input=word)
        result=self.assert_no_decoding()
        self.assertTrue(result['execution_complete'])
        self.assertTrue(result['input_match']['exact_input_match'])
        self.assertTrue(result['input_match']['native_status_qualified'])
        self.assertFalse(result['native_inputs_finite']);self.assertFalse(result['native_input_gate_passed'])
        self.assertEqual(len(result['nonfinite_native_inputs']),4)
        self.assertEqual({x['field'] for x in result['nonfinite_native_inputs']},{'CANON','WIRE'})

    def test_single_input_bit_difference_blocks_every_output_decode(self):
        self.worker(8,input_mismatch=True);self.worker(9)
        result=self.assert_no_decoding()
        self.assertFalse(result['input_match']['exact_input_match'])

    def test_software_flags_block_both_outputs(self):
        self.worker(8,flags=(0,1));self.worker(9)
        result=self.assert_no_decoding()
        self.assertTrue(result['native_input_gate_passed']);self.assertFalse(result['outer_output_gate_passed'])

    def test_w03_warning_blocks_both_outputs(self):
        self.worker(8,warning=True);self.worker(9)
        self.assert_no_decoding()

    def test_nonfinite_output_word_blocks_decoding(self):
        d=self.worker(8);self.worker(9)
        rows=(d/'driver-bits.dat').read_text().splitlines()
        fields=rows[2].split();fields[6]='7FF0000000000001';rows[2]=' '.join(fields)
        (d/'driver-bits.dat').write_text('\n'.join(rows)+'\n');self.fixture.reseal(d)
        self.assert_no_decoding()

    def test_missing_split_order_blocks_decoding(self):
        d=self.worker(8);self.worker(9)
        rows=(d/'driver-bits.dat').read_text().splitlines()
        (d/'driver-bits.dat').write_text('\n'.join(rows[:-1])+'\n');self.fixture.reseal(d)
        self.assert_no_decoding()

    def test_wrong_actual_mode_blocks_decoding(self):
        d=self.worker(8);self.worker(9)
        rows=(d/'driver-state.dat').read_text().splitlines()
        fields=rows[-1].split();fields[7]='1';rows[-1]=' '.join(fields)
        (d/'driver-state.dat').write_text('\n'.join(rows)+'\n');self.fixture.reseal(d)
        self.assert_no_decoding()

    def test_failed_bootstrap_blocks_both_measurements(self):
        self.worker(8,bootstrap=(2.,2.,-3.,4.),coefs=(123.,2.,-3.,4.))
        self.worker(9,coefs=(124.,2.,-3.,4.))
        decoded=[];original=self.legacy.decode64
        def observe(word):
            decoded.append(word);return original(word)
        with mock.patch.object(self.legacy,'decode64',side_effect=observe):
            result=self.compare()
        self.assertFalse(result['bootstrap_controls_passed']);self.assertFalse(result['passed'])
        self.assertFalse(result['measurement_interpretation_allowed'])
        self.assertNotIn(self.fixture.word(123.),decoded);self.assertNotIn(self.fixture.word(124.),decoded)
        self.assertNotIn('residuals',result['measurement_comparison'])

    def test_measurement_disagreement_retains_both_split_orders(self):
        result=self.complete(coefs=(1.,3.,-3.,4.))
        self.assertTrue(result['measurement_interpretation_allowed']);self.assertFalse(result['passed'])
        row=result['measurement_comparison'];self.assertTrue(row['eligible'])
        self.assertEqual({x['coefficient'] for x in row['failures']},{'finite'})
        self.assertEqual({x['order'] for x in row['failures']},{0,1})
        self.assertEqual(len(row['residuals']),8)

    def test_scientific_source_pin_in_spec_cannot_change(self):
        d=self.worker(8);self.worker(9)
        spec=json.loads((d/'specification.json').read_text());spec['scientific_source_index_sha256']='b'*64
        (d/'specification.json').write_text(json.dumps(spec));self.assert_no_decoding()

    def test_controller_source_pin_in_spec_cannot_change(self):
        d=self.worker(8);self.worker(9)
        spec=json.loads((d/'specification.json').read_text());spec['source_index_sha256']='b'*64
        (d/'specification.json').write_text(json.dumps(spec));self.assert_no_decoding()

    def test_build_receipt_bytes_and_spec_pin_are_bound(self):
        self.worker(8);self.worker(9)
        self.build_file.write_bytes(self.build_file.read_bytes()+b'\n')
        self.assert_no_decoding()

    def test_runtime_map_must_equal_closed_build_providers(self):
        d=self.worker(8);self.worker(9)
        native=json.loads((d/'result.json').read_text())
        for capture in native['runtime_maps']:
            capture['elf']['/unadmitted/provider']='0'*64
        (d/'result.json').write_text(json.dumps(native));self.assert_no_decoding()

    def test_materialized_card_hash_cannot_change(self):
        d=self.worker(8);self.worker(9)
        spec=json.loads((d/'specification.json').read_text())
        card=Path(spec['cwd']).parents[1]/'Cards/MadLoopParams.dat'
        card.write_bytes(card.read_bytes()+b'! synthetic mutation\n');self.assert_no_decoding()

    def test_copied_worker_executable_hash_cannot_change(self):
        d=self.worker(8);self.worker(9)
        spec=json.loads((d/'specification.json').read_text())
        exe=Path(spec['executable']);exe.write_bytes(exe.read_bytes()+b'changed')
        self.assert_no_decoding()

    def test_failed_saved_control_loader_never_interprets_measurement(self):
        self.worker(8);self.worker(9)
        self._saved_control_mock.side_effect=ValueError('Saved control is ineligible')
        with mock.patch.object(self.legacy,'decode64',side_effect=AssertionError('Failed saved control decoded')):
            with self.assertRaisesRegex(ValueError,'Saved control is ineligible'):
                self.compare()


if __name__=='__main__':
    unittest.main(verbosity=2)
