"""Pure recipe/preservation/build boundary mocks; no command/compiler or loader."""
import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import run

def objects():
 prefix='SubProcesses/P0_epem_mupmum/'
 return {**{prefix+f'old{i}.o':{'bytes':1,'sha256':str(i)} for i in range(208)},
         **{prefix+n:{'bytes':1,'sha256':n} for n in ('check_sa.o','CT_interface.o','TIRUST_interface.o')}}
def modules():return {f'SubProcesses/P0_epem_mupmum/old{i}.mod':{'bytes':1,'sha256':str(i)} for i in range(10)}
class Preservation(unittest.TestCase):
 def test_exact_212_objects_and_no_unplanned_extra(self):
  old=objects();new={**old,'SubProcesses/P0_epem_mupmum/matched_trace.o':{'bytes':1,'sha256':'new'}}
  run.objects_preserved(old,new)
  with self.assertRaisesRegex(ValueError,'new/missing'):run.objects_preserved(old,{**new,'surprise.o':{}})
  with self.assertRaisesRegex(ValueError,'new/missing'):run.objects_preserved(old,{k:v for k,v in new.items() if 'old7.o' not in k})
 def test_all_ten_old_modules_unchanged_only_recorder_added(self):
  old=modules();new={**old,'SubProcesses/P0_epem_mupmum/ml_private_matched_inputs.mod':{'bytes':1,'sha256':'new'}}
  run.modules_preserved(old,new)
  changed=dict(new);changed[next(iter(old))]={'bytes':1,'sha256':'changed'}
  with self.assertRaisesRegex(ValueError,'Reused Fortran'):run.modules_preserved(old,changed)
  with self.assertRaisesRegex(ValueError,'count'):run.modules_preserved(old,{**new,'surprise.mod':{}})
 def test_explicit_make_module_order_and_only_four_targets(self):
  helper=run.load("matched_test_original_build",run.OLD/"build_stage.py")
  overlay=helper.make_addition(True)
  s=run.make_addition(overlay)
  self.assertIn('pc-objects: check_sa.o CT_interface.o TIRUST_interface.o matched_trace.o',s)
  self.assertIn('matched_trace.o: matched_trace.f90 amplitude_support.o',s)
  self.assertIn('check_sa.o CT_interface.o TIRUST_interface.o: matched_trace.o',s)
  self.assertEqual(s.count('PROCESS +='),2)
  self.assertEqual(s.count('PROCESS += matched_trace.o'),1)
  self.assertIn('environment_token.o: environment_token.c',s)
  self.assertIn('certificate.o: certificate.f90',s)
  self.assertIn('caller_bounds.o: caller_bounds.f90 cms_bounds_data.inc',s)
  self.assertNotIn('gfortran',s)
  self.assertIn('$(FC) $(FFLAGS)',s)
 def test_build_boundary_one_matched_link_no_main(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);donor=root/'donor';sub='P0_epem_mupmum';d=donor/'SubProcesses'/sub;d.mkdir(parents=True)
   helper=run.load('matched_mock_build_recipes',run.OLD/'build_stage.py')
   overlay=helper.make_addition(True);(d/'makefile').write_text('ORIGINAL_MAKE\n'+overlay)
   before=objects();mods=modules();original={'output':str(donor),'all_objects_after':before,'modules_after':mods}
   calls=[];saved=[]
   def clone(r,source,output):(output/'SubProcesses'/sub).mkdir(parents=True)
   def write(out,p,raw):p.write_bytes(raw)
   def link(r,stages,out,variant,old,targets):
    calls.append((variant,targets))
    text=(out/'SubProcesses'/sub/'makefile').read_text()
    self.assertEqual(text.count('PROCESS += certificate.o caller_bounds.o amplitude_support.o environment_token.o'),1)
    self.assertEqual(text.count('PROCESS += matched_trace.o'),1)
    return {'all_objects_after':{**before,'SubProcesses/'+sub+'/matched_trace.o':{'bytes':1,'sha256':'new'}},
      'modules_after':{**mods,'SubProcesses/'+sub+'/ml_private_matched_inputs.mod':{'bytes':1,'sha256':'new'}},
      'executable':'private/check','executable_pin':{'bytes':1,'sha256':'exe'}}
   H=SimpleNamespace(SUBPROCESS=sub,clone=clone,write_private=write,make_addition=lambda _:overlay,
     link_one=link,preserved_objects=lambda *args:None)
   R=SimpleNamespace(dependency_snapshot=lambda:{},load=lambda *args:object())
   P=SimpleNamespace(R=R,B={'current_stages':{'path':'unused'}},QUERIES=['matched'])
   V=SimpleNamespace(checked=lambda *args:None,pin=lambda _: {'bytes':1,'sha256':'pinned'})
   plan={'requests':[{}],'build':{'compiled_objects':['check_sa.o','CT_interface.o','TIRUST_interface.o','matched_trace.o']}}
   with patch.multiple(run,P=P,H=H,V=V,PLAN=plan,WORK=root/'work',RESULTS=root/'results'),\
        patch.object(run,'donor',return_value=original),patch.object(run,'literal_cards'),\
        patch.object(run,'save',side_effect=lambda p,data:saved.append(data)):
    run.build()
   self.assertEqual(calls,[('matched',tuple(plan['build']['compiled_objects']))])
   self.assertEqual(saved[-1]['native_main_calls'],0);self.assertEqual(saved[-1]['tensor_calls'],0)
   self.assertFalse(saved[-1]['scientific_library_rebuilds'])
if __name__=='__main__':unittest.main()
