# Successor after the retained recipe-audit failure

Controller1 `9ff20966…` and failed closure `d0343e3e…` are immutable prerequisites. Its two successful queries found missing recipes before any compilation/link/loader/main. This successor uses a fresh executor2 and preserves all inherited support recipes while retaining the exact four-object real build. Scientific source357e, libraries, flags, models/cards/points and output comparator are unchanged. The actual inherited compiler-audit parser is tested against closed failed query output and exact restored donor recipes; no substitute parser or weakened compiler-equality check is introduced.

# Bounded matched-input controller

This additive controller binds the unchanged scientific proposal `357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b`. It contains no numerical-source revision. `run.py` defaults to file-only preflight; `--execute` selects exactly one named stage. Build cannot automatically start the run. Each stage has a fresh append-only namespace; no automatic retries or alternatives are implemented.

## Build boundary

The closed candidate2 build is authenticated through closure `8cab371e…` and its candidate receipt `35b556bd…`, followed by current file hashes:211 objects,10 modules,4 scientific archives/libraries,151 prelink inputs and15 runtime providers. This actual donor preflight uses pure file hashing and does not require an initialized native-owner helper. The inherited150-file dependency snapshot is exercised before execution, including all three private prerequisite records and their exact `size` versus `bytes` conversion.

The controller creates one fresh private clone at `.tirust-build/kinematic-matched-native-input-executor-2/work/builds/cms/matched`. It replaces only the reviewed driver, CT and TIRUST adapters, adds `matched_trace.f90`, and preserves the entire original private makefile suffix, changing only its aggregate pc-objects prerequisite line to the exact four targets and appending the recorder object/rule/dependencies. The support recipes and their flags remain byte-for-byte; their objects stay frozen. This also satisfies the inherited audit of every present Fortran source. The support-object PROCESS entries occur once. Only `check_sa.o`, `CT_interface.o`, `TIRUST_interface.o`, and new `matched_trace.o` may compile. The new module precedes all three consumers. Closure requires exactly212 objects with all208 untouched donor objects preserved, exactly11 modules with all10 old hashes unchanged, and unchanged scientific libraries. No environment probe/C rebuild occurs.

Original compiler flags and inherited owned-process/deadline/link-admission machinery remain in force. One actual-PT_INTERP loader query is allowed after the loader bytes and prelink/provider inputs have been verified. Closed provider equality is mandatory. The proposed build cap is360s native work after acquiring the shared mutex, with60s nominal cleanup reserved, nonexclusive CPU12 and jobs1. Preflight, lock wait and final file verification are outside that work cap. The stage executes no Fortran main or tensor evaluation.

## Separate run boundary

The `run` stage requires an explicit reviewed closed-build SHA, even for its nonexecuting file preflight. It authenticates every closed payload plus current ELF/source/object/module/library/prelink/provider files before either worker. Exactly two fresh mode4 workers run in order8 then9. Each makes one ordinary point1 bootstrap and one CMS20 measurement: four outer entries and104 expected native calls total. No CMS21, Ninja6, additional bootstrap, retry or normal checked/performance execution is included.

Native ownership, READY/DONE maps, worker limits and cleanup are unchanged from the sealed earlier controller. Literal cards and points are exact copies from scientific357e. The native work cap is1440s after the shared mutex, with60s nominal cleanup reserved; each worker retains180s bootstrap/300s measurement/600s owned caps,8GiB address space,64MiB files and nonexclusive CPU12.

`compare.py` first authenticates the scientific/controller/build/specification/card/point/runtime evidence and complete native trace streams. It requires exact input, canonical numerator and ordered routing equality, actual group3 pair24 direct-use decisions, full provenance, raw native success and complete errors. It rejects every binary128 NaN/infinity input using integer exponent bits across all six word tags; no floating-point decoding is used for this gate. Original failed references are never loaded as controls.

Only after these gates, complete outer protocol/software flags and output-format checks pass does the comparator perform ordinary bootstrap arithmetic against the previously qualified candidate9 QP ordinary result. Both bootstraps must pass before either CMS20 measurement is decoded for arithmetic. It then compares Born/finite/single/double for every split order. A failure remains retained and prevents qualification; input agreement or native success alone is insufficient.

## Commands after review

Run from `/shared/external/madloop_tirust/madgraph7_madloop_tirust`, sourcing `tools/tirust_env.sh`. Replace `CONTROLLER_SHA` with this packet's `index.json` SHA256:

```sh
python3 -B .tirust-build/kinematic-matched-native-input-controller-2/run.py build --reviewed-source-index CONTROLLER_SHA
python3 -B .tirust-build/kinematic-matched-native-input-controller-2/run.py build --reviewed-source-index CONTROLLER_SHA --execute
```

The second command requires the admitting root's completed source/preflight/review conditions. After terminal build review, a separately admitted run uses:

```sh
python3 -B .tirust-build/kinematic-matched-native-input-controller-2/run.py run --reviewed-source-index CONTROLLER_SHA --reviewed-build-sha256 CLOSED_BUILD_SHA --execute
```

The scientific357e packet and all historical failed attempts remain immutable. This experiment is private finite-part adjudication, with no production promotion or performance acceptance claim.
