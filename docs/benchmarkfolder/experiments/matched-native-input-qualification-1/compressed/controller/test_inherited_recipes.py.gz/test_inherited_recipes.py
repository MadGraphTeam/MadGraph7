"""Replay the actual inherited recipe audit using hash-bound closed outputs.

No make/compiler/loader is invoked. This regression does not simulate GNU make:
restored recipe blocks must be byte-identical to the closed donor blocks, and
only their previously captured expanded lines are restored to the failed output.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
FAILED = ROOT / '.tirust-build/kinematic-matched-native-input-executor-1/results'
SOURCE1 = ROOT / '.tirust-build/kinematic-matched-native-input-controller-1'
SOURCE1_SHA = '9ff20966e4d24a3062a730a6037e9c9e50ab22d0007f343fdf6b4cee84cfaae7'
FAILED_SHA = 'd0343e3ec8f8b4db046a5fc3ac7c0dd2cace9c5a271fffb00394e1e7ca16af41'
DONOR = ROOT / '.tirust-build/kinematic-invariant-amplitude-executor-2/results/builds/candidate/build.json'
DONOR_SHA = '35b556bd50d4e40f34925145d69acd1fcc4ea865a3eaea2214c44e4727a9b5e6'
DONOR_CLOSURE_SHA = '8cab371e9affd5297c0f48c30184361959d20f3d3a48c6dbd6109b86bf49bacb'
OLD = ROOT / '.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA = 'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
HELPER = ROOT / 'docs/benchmarkfolder/experiments/current-cms-replay-supervisor-1/protocol/tirust_benchmark_compiler.py'
HELPER_SHA = '86dd3a860a39a1421e035dcf6555575addcbed0c99c80211f9f8b348a3e75e46'
SUPPORT = ('amplitude_support.f90', 'caller_bounds.f90', 'certificate.f90')
MISSING = "Unresolved numerical compilation recipes: ['amplitude_support.f90', 'caller_bounds.f90', 'certificate.f90']"


def checked(path, expected):
    raw = Path(path).read_bytes()
    actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    wanted = expected if isinstance(expected, str) else {k: expected[k] for k in ('bytes', 'sha256')}
    if (actual['sha256'] if isinstance(expected, str) else actual) != wanted:
        raise ValueError('Changed bound fixture: ' + str(path))
    return raw


def packet(directory, checksum):
    data = json.loads(checked(directory / 'index.json', checksum))
    for name, value in data['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('Unsafe source fixture path')
        checked(directory / name, value)
    return data


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def recipe_block(text, filename):
    target = Path(filename).with_suffix('.o').name
    pattern = r'^' + re.escape(target) + r':[^\n]*\n(?:\t[^\n]*\n)+'
    matches = re.findall(pattern, text, re.MULTILINE)
    if len(matches) != 1:
        raise ValueError('Missing/duplicate explicit support recipe: ' + filename)
    return matches[0]


class InheritedRecipes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Authenticate every executable helper before importing it, and every
        # closed fixture before JSON parsing/using its recipe evidence.
        packet(SOURCE1, SOURCE1_SHA)
        old_index = packet(OLD, OLD_SHA)
        checked(HELPER, HELPER_SHA)
        closure = json.loads(checked(FAILED / 'build-closure.json', FAILED_SHA))
        if closure['passed'] or closure['owned_command_count'] != 2 or closure['loader_query_count'] != 0:
            raise ValueError('Unexpected failed build scope')
        if closure['source_index_sha256'] != SOURCE1_SHA or len(closure['payloads']) != 8:
            raise ValueError('Unexpected failed source/closure')
        for name, value in closure['payloads'].items():
            if Path(name).is_absolute() or '..' in Path(name).parts:
                raise ValueError('Unsafe closed fixture path')
            checked(FAILED / name, value)
        attempt = json.loads((FAILED / 'builds/matched/attempt.json').read_bytes())
        if any(attempt[k] for k in ('compile_seen', 'link_seen', 'runtime_seen', 'commands')):
            raise ValueError('Failure unexpectedly reached native build')
        for name, value in attempt['sources_before'].items():
            checked(ROOT / name, value)
        if (FAILED / 'build-before.json').read_bytes() != (FAILED / 'build-after.json').read_bytes():
            raise ValueError('Protected failure inputs changed')
        cls.bad = (FAILED / 'execution/build-query-build-0001.txt').read_text()
        cls.version = (FAILED / 'execution/build-query-build-0002.txt').read_text()
        query = json.loads((FAILED / 'execution/build-query-build-0001.json').read_bytes())
        version_query = json.loads((FAILED / 'execution/build-query-build-0002.json').read_bytes())
        if query['returncode'] != 0 or version_query['returncode'] != 0:
            raise ValueError('Captured query failed')
        if query['argv'][:7] != ['taskset', '-c', '12', 'make', '--no-print-directory', '--dry-run', '--always-make']:
            raise ValueError('Captured make query was not the admitted dry run')
        if version_query['argv'][:3] != ['taskset', '-c', '12'] or version_query['argv'][-1] != '--version':
            raise ValueError('Captured compiler command was not a version query')
        cls.where = Path(query['cwd'])
        cls.process_command = query['argv'][3:-1]
        if not query['argv'][-1].startswith('SHELL='):
            raise ValueError('Captured owned shell override missing')
        donor_raw = checked(DONOR, DONOR_SHA)
        donor_closure = json.loads(checked(DONOR.parents[2] / 'build-closure.json', DONOR_CLOSURE_SHA))
        checked(DONOR, donor_closure['payloads']['builds/candidate/build.json'])
        cls.donor = json.loads(donor_raw)
        cls.flags = cls.donor['compiler_flags']
        cls.donor_dir = Path(cls.donor['output']) / 'SubProcesses/P0_epem_mupmum'
        donor_make = cls.donor_dir / 'makefile'
        checked(donor_make, cls.donor['sources'][str(donor_make.relative_to(ROOT))])
        checked(OLD / 'build_stage.py', old_index['files']['build_stage.py'])
        cls.build_helper = load('actual_bound_recipe_build_helper', OLD / 'build_stage.py')
        cls.old_overlay = cls.build_helper.make_addition(True)
        if not donor_make.read_text().endswith(cls.old_overlay):
            raise ValueError('Actual closed donor support overlay differs')
        cls.helper = load('actual_bound_recipe_compiler_helper', HELPER)
        # Only this unsealed successor's reviewed make_addition is used. Its
        # import has no native side effects; tests forbid every subprocess below.
        cls.successor = load('recipe_successor_controller', HERE / 'run.py')
        cls.lines = {}
        for line in cls.flags['scopes']['process']['expanded_make_output'].replace(chr(92) + chr(10), ' ').splitlines():
            tokens = shlex.split(line)
            names = set(SUPPORT).intersection(tokens)
            if '-c' in tokens and names:
                if len(names) != 1 or next(iter(names)) in cls.lines:
                    raise ValueError('Ambiguous closed support recipe output')
                cls.lines[next(iter(names))] = line
        if set(cls.lines) != set(SUPPORT):
            raise ValueError('Closed donor recipe coverage differs')

    def augmented(self, overlay):
        # Three exact original rule+recipe blocks authorize restoring only
        # their corresponding closed expanded lines; no fabricated flags.
        for name in SUPPORT:
            self.assertEqual(recipe_block(overlay, name), recipe_block(self.old_overlay, name))
        return self.bad + '\n' + '\n'.join(self.lines[name] for name in SUPPORT) + '\n'

    def capture(self, process_output):
        seen = []
        versions = []

        def fake_run(argv, cwd=None, **kwargs):
            if argv[:4] != ['make', '--no-print-directory', '--dry-run', '--always-make']:
                raise AssertionError('Unmocked subprocess request: ' + repr(argv))
            scope = 'process' if Path(cwd) == self.where else Path(cwd).name
            self.assertIn(scope, ('process', 'MODEL', 'DHELAS'))
            expected = self.process_command if scope == 'process' else self.flags['scopes'][scope]['make_command']
            self.assertEqual(argv, expected)
            seen.append(scope)
            text = process_output if scope == 'process' else self.flags['scopes'][scope]['expanded_make_output']
            return SimpleNamespace(returncode=0, stdout=text, stderr='')

        def fake_version(argv, **kwargs):
            self.assertEqual(len(argv), 2)
            self.assertEqual(argv[1], '--version')
            expected = self.flags['scopes']['process']['recipes']['certificate.f90']['compiler'][0]['path']
            self.assertEqual(argv[0], expected)
            versions.append(tuple(argv))
            return self.version

        with patch.object(self.helper.subprocess, 'run', side_effect=fake_run), \
             patch.object(self.helper.subprocess, 'check_output', side_effect=fake_version), \
             patch.object(self.helper.subprocess, 'Popen', side_effect=AssertionError('Native process forbidden')):
            result = self.helper.capture_effective_flags(self.where, env=self.flags['environment'])
        return result, seen, versions

    def test_closed_failure_reproduces_exact_missing_three(self):
        with self.assertRaisesRegex(ValueError, re.escape(MISSING)) as caught:
            self.capture(self.bad)
        self.assertEqual(str(caught.exception), MISSING)

    def test_successor_exact_restoration_passes_actual_capture_and_policy(self):
        overlay = self.successor.make_addition(self.old_overlay)
        output = self.augmented(overlay)
        result, seen, versions = self.capture(output)
        self.helper.validate_compiler_equality(self.flags, result)
        self.assertEqual({name: len(value['recipes']) for name, value in result['scopes'].items()},
                         {'process': 25, 'MODEL': 14, 'DHELAS': 175})
        self.assertEqual(seen, ['process', 'MODEL', 'DHELAS'])
        self.assertEqual(len(versions), 1)
        self.assertEqual(re.findall(r'^pc-objects: (.*)$', overlay, re.MULTILINE),
                         ['check_sa.o CT_interface.o TIRUST_interface.o matched_trace.o'])
        self.assertEqual(recipe_block(overlay, 'environment_token.c'),
                         recipe_block(self.old_overlay, 'environment_token.c'))
        self.assertIn('check_sa.o CT_interface.o TIRUST_interface.o: matched_trace.o', overlay)

    def test_missing_one_restored_recipe_still_fails_real_audit(self):
        restored = self.augmented(self.successor.make_addition(self.old_overlay))
        removed = self.lines['caller_bounds.f90'] + '\n'
        self.assertEqual(restored.count(removed), 1)
        partial = restored.replace(removed, '', 1)
        with self.assertRaisesRegex(ValueError, re.escape("Unresolved numerical compilation recipes: ['caller_bounds.f90']")):
            self.capture(partial)

    def test_wrong_restored_flag_rejected_by_actual_compiler_policy(self):
        restored = self.augmented(self.successor.make_addition(self.old_overlay))
        original = self.lines['certificate.f90']
        self.assertEqual(restored.count(original), 1)
        changed = restored.replace(original, original + ' -ffast-math', 1)
        result, _, _ = self.capture(changed)
        with self.assertRaisesRegex(ValueError, 'effective compiler flags differ'):
            self.helper.validate_compiler_equality(self.flags, result)

    def test_missing_or_modified_successor_support_block_rejected(self):
        overlay = self.successor.make_addition(self.old_overlay)
        block = recipe_block(overlay, 'certificate.f90')
        with self.assertRaises(ValueError):
            self.augmented(overlay.replace(block, '', 1))
        with self.assertRaises(AssertionError):
            self.augmented(overlay.replace(block, block.replace('$(FFLAGS)', '-ffast-math'), 1))


if __name__ == '__main__':
    unittest.main()
