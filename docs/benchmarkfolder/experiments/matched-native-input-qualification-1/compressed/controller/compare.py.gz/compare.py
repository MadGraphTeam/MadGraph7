"""Pure matched8/9 outer comparison; no compiler, loader or native invocation.

Authenticate source/specifications and structural evidence, then join exact
native inputs/statuses, then inspect software/output coverage. Only after both
ordinary controls pass may CMS20 coefficient arithmetic begin.
"""
import hashlib
import json
from pathlib import Path
import re
import types

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCIENCE=ROOT/'.tirust-build/kinematic-matched-native-input-proposal-1'
MATCHED_SHA='357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b'
OLD=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
OLD_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
OLD_COMPARE_SHA='ecce1e1f99f0de7d1798880cc9137251b4e553accc708f3cee357ed794b99272'
REFERENCE=ROOT/'.tirust-build/kinematic-invariant-reference-adjudication-proposal-1'
REFERENCE_SHA='0a0dba9baf12ff5a988e4d459141a48140f285a396658ee10f7f09099848dbd8'
REFERENCE_COMPARE_SHA='34277061d0a367e156f39519e2cad973adebaf89e9ee4c1c794313238f93cba4'
ORDINARY=ROOT/'.tirust-build/kinematic-invariant-amplitude-executor-2/results'
ORDINARY_CLOSURE_SHA='b364bd8535d0f5850cb5a21390c5678cbb1c1dd8fddfae6f0174cf50d261f7a7'
ORDINARY_COMPARE_SHA='6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451'
POINTS={'physical_card':'cms-param_card.dat','bootstrap':'cms-point1.dat','measurement':'cms-point20.dat'}


def require(ok,message):
    if not ok:
        raise ValueError(message)


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def checked(path,expected):
    raw=Path(path).read_bytes();actual=pin(raw)
    require(actual['sha256']==expected if isinstance(expected,str) else
            actual=={k:expected[k] for k in ('bytes','sha256')},'Pinned bytes changed: '+str(path))
    return raw


def _module(path,raw,*,globals_=None):
    module=types.ModuleType('private_matched_'+Path(path).stem);module.__file__=str(path)
    if globals_:
        module.__dict__.update(globals_)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def _packet(directory,sha):
    index_raw=checked(directory/'index.json',sha);index=json.loads(index_raw)
    payloads={}
    for name,expected in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source payload path')
        payloads[name]=checked(directory/name,expected)
    return index,payloads


def _controller_source(expected):
    require(re.fullmatch('[0-9a-f]{64}',expected) is not None,'Controller source seal is required')
    raw=checked(HERE/'index.json',expected);index=json.loads(raw)
    checked(HERE/'compare.py',index['files']['compare.py'])
    return pin(raw)


def _scientific_source():
    index,raw=_packet(SCIENCE,MATCHED_SHA)
    prepare=_module(SCIENCE/'prepare.py',raw['prepare.py'])
    matched=_module(SCIENCE/'matched_inputs.py',raw['matched_inputs.py'])
    source=raw['verify.py'].decode('utf-8')
    # Explicit isolated dependency injection: no sys.path/sys.modules mutation,
    # no unverified local import and no change to any verification expression.
    for statement in ('import prepare\n','import matched_inputs\n'):
        require(source.count(statement)==1,'Pure verifier import anchor differs')
        source=source.replace(statement,'',1)
    verify=_module(SCIENCE/'verify.py',source,globals_={'prepare':prepare,'matched_inputs':matched})
    preflight=verify.preflight(MATCHED_SHA)
    require(preflight['passed'] is True and preflight['native_actions']==0 and preflight['routes']==26,
            'Scientific source preflight failed')
    routes={int(k):v for k,v in json.loads(raw['expected-routes.json']).items()}
    return {'module':matched,'routes':routes,'preflight':preflight,
            'source_evidence':{'scientific_index_sha256':MATCHED_SHA,'payloads_verified':len(raw),
                'matched_inputs.py':index['files']['matched_inputs.py'],
                'expected-routes.json':index['files']['expected-routes.json']}}


def _legacy():
    index=json.loads(checked(OLD/'index.json',OLD_SHA))
    require(index['files']['amplitude_compare.py']['sha256']==OLD_COMPARE_SHA,'Legacy comparator seal differs')
    source=checked(OLD/'amplitude_compare.py',OLD_COMPARE_SHA).decode('utf-8')
    anchor="        require(not raw['trace.dat'],'Unexpected diagnostic trace output')"
    require(source.count(anchor)==1,'Legacy trace guard anchor differs')
    source=source.replace(anchor,
        "        require(_MATCHED_GATE_OPEN,'Matched native-input gate is not open')",1)
    module=_module(OLD/'amplitude_compare.py',source,globals_={'_MATCHED_GATE_OPEN':False})
    module.verify_sources()
    return module


def _reference():
    index=json.loads(checked(REFERENCE/'index.json',REFERENCE_SHA))
    require(index['files']['reference_compare.py']['sha256']==REFERENCE_COMPARE_SHA,'Structural helper seal differs')
    return _module(REFERENCE/'reference_compare.py',checked(REFERENCE/'reference_compare.py',REFERENCE_COMPARE_SHA))


def _saved_control():
    raw=checked(ORDINARY/'ordinary-closure.json',ORDINARY_CLOSURE_SHA);closure=json.loads(raw)
    require(closure['passed'] is True and closure['failure'] is None and closure['source_index_sha256']==OLD_SHA,
            'Closed ordinary controls are unqualified')
    record=closure['payloads']['ordinary-comparison.json']
    require(record['sha256']==ORDINARY_COMPARE_SHA,'Ordinary report closure binding differs')
    report_raw=checked(ORDINARY/'ordinary-comparison.json',record);report=json.loads(report_raw)
    require(report['passed'] is True,'Saved ordinary comparison failed')
    obs=report['observations']['cms-p1-mode4-lib9-candidate'];r=obs['request']
    require(obs['eligible'] is True and not obs['failures'] and not obs.get('incomplete_contribution_warnings'),
            'Saved candidate9 ordinary control failed')
    require((r['point'],r['backend'],r['requested_mode'],r['variant'])==(1,9,4,'candidate'),
            'Saved ordinary identity differs')
    after=[x for x in obs['states'] if x['stage']=='A']
    require(len(after)==2 and all((x['code'],x['actual_mode'],x['fpe_dp'],x['fpe_qp'])==(120,4,0,0) for x in after),
            'Saved ordinary state/mode/flags differ')
    require([(x['phase'],x['call'],x['point'],x['order'],x['code']) for x in obs['raw_rows']]==
            [(0,1,1,0,120),(0,1,1,1,120),(1,2,1,0,120),(1,2,1,1,120)],'Saved ordinary coverage differs')
    return {'observation':obs,'source_evidence':{'ordinary_closure':pin(raw),'ordinary_comparison':pin(report_raw),
            'selected_control':'cms-p1-mode4-lib9-candidate'}}


def validate_requests(requests):
    require(len(requests)==2 and [x['backend'] for x in requests]==[8,9],'Matched scope must be backend8 then9')
    for r in requests:
        expected={'id':f"cms-p20-mode4-lib{r['backend']}-matched",'variant':'matched','stage':'run',
            'point':20,'requested_mode':4,'expected_fixed_unchecked_return':120,'bootstrap_calls':1,
            'measurement_calls':1,'outer_entries_max':2,'card':f"backend{r['backend']}-mode4-MadLoopParams.dat",
            'physical_card':'inputs/cms-param_card.dat','bootstrap':'inputs/cms-point1.dat',
            'measurement':'inputs/cms-point20.dat'}
        require(all(r.get(k)==v for k,v in expected.items()),'Matched worker request differs')


def _build(runs_dir,provided):
    raw=(runs_dir.parent/'builds/matched/build.json').read_bytes();actual=json.loads(raw)
    require(actual==provided,'Provided build receipt differs from retained closed record')
    require(actual.get('variant')=='matched','Build variant differs')
    checked(actual['executable'],actual['executable_pin'])
    for table in ('prelink_bound',):
        for path,sha in actual[table].items():
            checked(path,sha)
    for path,sha in actual['runtime']['files'].items():
        checked(path,sha)
    return actual,pin(raw)


def _inspect(directory,request,controller_sha,build,build_pin,structural):
    obs={'id':request['id'],'request':request,'eligible':False,'failures':[],'raw_rows':[],'states':[],
        'source_evidence':{},'native_pid':None,'protocol_complete':False,'structural_complete':False,
        'outer_entries_observed':0,'ready_done_maps':0,'measurement_interpretation_allowed':False}
    trace=None
    try:
        spec_raw=(directory/'specification.json').read_bytes();spec=json.loads(spec_raw)
        obs['source_evidence']['specification.json']=pin(spec_raw)
        require(spec['request']==request,'Specification request differs')
        require(spec['source_index_sha256']==controller_sha and spec['scientific_source_index_sha256']==MATCHED_SHA,
                'Controller/scientific source specification differs')
        require(spec['build_receipt_sha256']==build_pin['sha256'],'Specification build receipt differs')
        cwd=Path(spec['cwd']);require(cwd.is_absolute(),'Worker cwd must be absolute')
        require(Path(spec['executable'])==cwd/'check' and Path(spec['evidence'])==directory,
                'Specification executable/evidence location differs')
        require(spec['executable_pin']==build['executable_pin'],'Worker executable build pin differs')
        checked(spec['executable'],build['executable_pin'])
        expected_runtime={**build['runtime']['files'],str((cwd/'check').resolve()):build['executable_pin']['sha256']}
        require(spec['expected_runtime']==expected_runtime,'Specification runtime providers differ')
        cards=cwd.parents[1]/'Cards'
        numerical=pin((SCIENCE/request['card']).read_bytes())
        physical=pin((SCIENCE/'inputs'/POINTS['physical_card']).read_bytes())
        require(spec['numerical_card']==numerical and spec['physical_card']==physical,'Worker card pin differs')
        checked(cards/'MadLoopParams.dat',numerical);checked(cards/'param_card.dat',physical)
        for name,key in (('bootstrap','bootstrap'),('point','measurement')):
            expected=pin((SCIENCE/'inputs'/POINTS[key]).read_bytes())
            require(spec[name+'_pin']==expected,'Worker phase-space pin differs')
            checked(spec[name+'_file'],expected)
        native_raw=(directory/'result.json').read_bytes();native=json.loads(native_raw)
        obs['source_evidence']['result.json']=pin(native_raw)
        require(native['request']==request,'Native worker request differs')
        structural._structural_evidence(directory,request,native,obs)
        require(all(x['elf']==expected_runtime for x in native['runtime_maps']),
                'Actual READY/DONE runtime differs from closed build')
        trace=checked(directory/'trace.dat',native['outputs']['trace.dat'])
        obs['source_evidence']['trace.dat']=pin(trace)
    except (KeyError,ValueError,TypeError,OSError,UnicodeError) as exc:
        obs['failures'].append(str(exc))
    return obs,trace


def _phase_view(obs,phase,*,saved=False):
    require(obs['eligible'] is True,'Failed coefficients remain opaque')
    if phase==1 and not saved:
        require(obs['measurement_interpretation_allowed'] is True,'Measurement interpretation remains blocked')
    rows=[x for x in obs['raw_rows'] if x['phase']==phase]
    require(len(rows)==2 and [x['order'] for x in rows]==[0,1],'Phase/split-order coverage differs')
    return {'id':obs['id'],'eligible':True,'raw_rows':[{**x,'phase':1} for x in rows]}


def _finite_inputs(joined):
    """Classify native-input encodings only; no FP conversion or arithmetic."""
    failures=[]
    for worker in joined['parsed']:
        for call in worker['calls']:
            for tag,words in call['words'].items():
                for index,word in enumerate(words):
                    if (int(word,16)>>112)&0x7FFF==0x7FFF:
                        failures.append({'backend':call['backend'],'key':call['key'],'seq':call['seq'],
                                         'field':tag,'index':index,'word':word})
    return failures


def compare_stage(runs_dir,requests,*,controller_source_sha,build_receipt):
    validate_requests(requests);runs_dir=Path(runs_dir)
    controller=_controller_source(controller_source_sha);science=_scientific_source()
    build,build_pin=_build(runs_dir,build_receipt)
    legacy=_legacy();structural=_reference();structural._legacy=lambda:legacy
    observations={};traces={};failures=[]
    for request in requests:
        backend=request['backend']
        observations[backend],traces[backend]=_inspect(runs_dir/request['id'],request,controller_source_sha,
                                                     build,build_pin,structural)
    pids=[obs['native_pid'] for obs in observations.values()]
    distinct=all(type(pid) is int and pid>0 for pid in pids) and len(set(pids))==2
    execution=distinct and all(x['structural_complete'] for x in observations.values())
    contracts=execution and all(not x['failures'] for x in observations.values())
    if not distinct:
        failures.append({'stage':'ownership','failure':'Two distinct owned native workers not established'})
    joined=None
    if all(trace is not None for trace in traces.values()):
        try:
            joined=science['module'].join_inputs(traces[8].decode('ascii'),traces[9].decode('ascii'),
                science['routes'],caller_binding_verified=contracts)
        except (KeyError,ValueError,TypeError,UnicodeError) as exc:
            failures.append({'stage':'input_trace','failure':str(exc)})
    nonfinite_inputs=_finite_inputs(joined) if joined is not None else []
    finite_inputs=joined is not None and not nonfinite_inputs
    input_gate=bool(contracts and joined is not None and joined['native_input_gate_passed'] and finite_inputs)
    if not input_gate:
        failures.append({'stage':'native_input','failure':'Complete source-bound input/native-status gate failed'})
    if input_gate:
        # Sole legacy adaptation is activated only after the complete native
        # input/status gate. It preserves every output/software/warning check.
        legacy._MATCHED_GATE_OPEN=True
        for request in requests:
            obs=observations[request['backend']]
            result=legacy.inspect_worker(runs_dir/request['id'],request)
            retained=obs['source_evidence'];retained.update(result['source_evidence'])
            obs.update(result);obs['source_evidence']=retained
            obs['measurement_interpretation_allowed']=False
    outer_gate=input_gate and all(x['eligible'] for x in observations.values())
    if not outer_gate:
        failures.append({'stage':'outer_outputs','failure':'Failed protocol/software/coverage gate; coefficients remain opaque'})
    bootstrap=[];saved_evidence=None
    for backend in (8,9):
        bootstrap.append({'backend':backend,'eligible':False,'passed':False,'interpretation_blocked':True})
    if outer_gate:
        saved=_saved_control();saved_evidence=saved['source_evidence']
        for backend,row in zip((8,9),bootstrap):
            row.update(legacy.compare_coefficients(_phase_view(saved['observation'],1,saved=True),
                                                   _phase_view(observations[backend],0)))
            row['interpretation_blocked']=False
    bootstrap_gate=outer_gate and all(x['passed'] for x in bootstrap)
    if not bootstrap_gate:
        failures.append({'stage':'bootstrap','failure':'Both ordinary controls must pass before CMS20 interpretation'})
    measurement={'eligible':False,'passed':False,'interpretation_blocked':True,
                 'reference_id':requests[0]['id'],'candidate_id':requests[1]['id']}
    if bootstrap_gate:
        for obs in observations.values():
            obs['measurement_interpretation_allowed']=True
        measurement.update(legacy.compare_coefficients(_phase_view(observations[8],1),_phase_view(observations[9],1)))
        measurement['interpretation_blocked']=False
        if not measurement['passed']:
            failures.append({'stage':'measurement','failure':'Matched-input coefficient disagreement'})
    for obs in observations.values():
        failures.extend({'stage':'worker','worker':obs['id'],'failure':x} for x in obs['failures'])
    return {'schema':'private-matched-native-outer-comparison-v1','passed':not failures,
        'execution_complete':execution,'native_input_gate_passed':input_gate,'outer_output_gate_passed':outer_gate,
        'native_inputs_finite':finite_inputs,'nonfinite_native_inputs':nonfinite_inputs,
        'bootstrap_controls_passed':bootstrap_gate,'measurement_interpretation_allowed':bootstrap_gate,
        'outer_entries_observed':sum(x['outer_entries_observed'] for x in observations.values()),
        'ready_done_maps':sum(x['ready_done_maps'] for x in observations.values()),
        'observations':{str(k):v for k,v in observations.items()},'input_match':joined,
        'bootstrap_comparisons':bootstrap,'measurement_comparison':measurement,'failures':failures,
        'source_evidence':{'controller_index':controller,'scientific':science['source_evidence'],
            'scientific_preflight':science['preflight'],'build_receipt':build_pin,'ordinary_control':saved_evidence,
            'legacy_comparator_sha256':OLD_COMPARE_SHA,'structural_helper_sha256':REFERENCE_COMPARE_SHA},
        'criterion':'LoopMEComparator: abs(a-b)/abs(a+b)<3e-6, or pole magnitude/finite maximum<3e-6',
        'ordinary_target_tolerance':'1e-8','accuracy_qualified':False,'normal_host_stability_qualified':False,
        'performance_measurement':False,'winner_selected':False,
        'limitations':['Fixed120 outer returns are unchecked host evaluations.',
            'Exact input agreement, native success and two-reducer agreement do not establish independent accuracy.',
            'No failed saved reference coefficients are selected or decoded.']}
