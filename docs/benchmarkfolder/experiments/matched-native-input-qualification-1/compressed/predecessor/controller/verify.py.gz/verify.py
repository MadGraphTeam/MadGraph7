"""Pure source/closed-lineage verification; no native imports or subprocesses."""
import hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCIENCE=ROOT/'.tirust-build/kinematic-matched-native-input-proposal-1'
SCIENCE_SHA='357e116b51879cda1e1145c9d040194732c21ffd9fcd2557d9f68451901b262b'
PINS={
 'scientific_source':SCIENCE_SHA,
 'reference_controller':'0a0dba9baf12ff5a988e4d459141a48140f285a396658ee10f7f09099848dbd8',
 'amplitude_source':'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74',
 'candidate_build_closure':'8cab371e9affd5297c0f48c30184361959d20f3d3a48c6dbd6109b86bf49bacb',
 'candidate_build':'35b556bd50d4e40f34925145d69acd1fcc4ea865a3eaea2214c44e4727a9b5e6',
 'ordinary_closure':'b364bd8535d0f5850cb5a21390c5678cbb1c1dd8fddfae6f0174cf50d261f7a7',
 'ordinary_comparison':'6d4f37f0b9b0cc0b3297d31b7167d176db640bbca21cd33f8861a0e4b9750451',
}
def require(ok,msg):
 if not ok:raise ValueError(msg)
def pin(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(path,item):
 require(pin(path)=={k:item[k] for k in ('bytes','sha256')},'Changed bound file: '+str(path))
def authenticate(path,sha):
 require(pin(path)['sha256']==sha,'Reviewed index changed: '+str(path))
 index=json.loads(Path(path).read_bytes())
 for name,item in index['files'].items():
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source index path')
  checked(Path(path).parent/name,item)
 return index
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
 sys.modules[name]=mod;spec.loader.exec_module(mod);return mod

def verify(expected):
 own=authenticate(HERE/'index.json',expected) if expected else {'files':{}}
 b=json.loads((HERE/'bindings.json').read_bytes())
 require(b['root']==str(ROOT) and set(b['files'])==set(PINS),'Unexpected controller bindings')
 for key,sha in PINS.items():
  item=b['files'][key];require(item['sha256']==sha,'Fixed lineage changed: '+key)
  require(not Path(item['path']).is_absolute() and '..' not in Path(item['path']).parts,'Unsafe lineage path')
  checked(ROOT/item['path'],item)
 indices={}
 for key in ('scientific_source','reference_controller','amplitude_source'):
  item=b['files'][key];indices[key]=authenticate(ROOT/item['path'],item['sha256'])
 counts={}
 for key in ('candidate_build_closure','ordinary_closure'):
  path=ROOT/b['files'][key]['path'];closure=json.loads(path.read_bytes())
  require(closure['passed'] is True,'Closed prerequisite failed: '+key)
  for name,item in closure['payloads'].items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe closed payload path')
   checked(path.parent/name,item)
  counts[key]=len(closure['payloads'])
 buildclosure=json.loads((ROOT/b['files']['candidate_build_closure']['path']).read_bytes())
 checked(ROOT/b['files']['candidate_build']['path'],buildclosure['payloads']['builds/candidate/build.json'])
 ordinary=json.loads((ROOT/b['files']['ordinary_closure']['path']).read_bytes())
 checked(ROOT/b['files']['ordinary_comparison']['path'],ordinary['payloads']['ordinary-comparison.json'])
 science=indices['scientific_source']
 derive=load('matched_controller_pure_derivation',SCIENCE/'prepare.py')
 for name,text in derive.products().items():
  require((SCIENCE/name).read_text()==text,'Sealed scientific derivation differs')
 ref=(ROOT/b['files']['reference_controller']['path']).parent
 for name in ('native_job.py','limit_exec.py'):
  require((HERE/name).read_bytes()==(ref/name).read_bytes(),'Native ownership helper differs')
 expected_worker=(ref/'worker_entry.py').read_text().replace(
  "root=ROOT/'.tirust-build/kinematic-invariant-reference-adjudication-executor-1'",
  "root=ROOT/'.tirust-build/kinematic-matched-native-input-executor-1'")
 require((HERE/'worker_entry.py').read_text()==expected_worker,'Worker root/owner derivative differs')
 for name in ('backend8-mode4-MadLoopParams.dat','backend9-mode4-MadLoopParams.dat',
              'inputs/cms-param_card.dat','inputs/cms-point1.dat','inputs/cms-point20.dat'):
  checked(HERE/name,science['files'][name])
 plan=json.loads((HERE/'validation-plan.json').read_bytes())
 require(plan['scientific_source_index_sha256']==SCIENCE_SHA,'Scientific source scope differs')
 require([r['backend'] for r in plan['requests']]==[8,9] and len(plan['requests'])==2,'Worker scope differs')
 for r in plan['requests']:
  require(r['id']==f"cms-p20-mode4-lib{r['backend']}-matched",'Worker identity differs')
  require(r['point']==20 and r['requested_mode']==4 and r['variant']=='matched' and r['stage']=='run','Worker policy differs')
  require(r['bootstrap_calls']==r['measurement_calls']==1 and r['outer_entries_max']==2,'Outer count differs')
  require(r['bootstrap']=='inputs/cms-point1.dat' and r['measurement']=='inputs/cms-point20.dat' and
          r['card']==f"backend{r['backend']}-mode4-MadLoopParams.dat" and r['physical_card']=='inputs/cms-param_card.dat','Worker input path differs')
 require(plan['build']['compiled_objects']==['check_sa.o','CT_interface.o','TIRUST_interface.o','matched_trace.o'],'Compile scope differs')
 require(plan['build']['seconds_total']==420 and plan['run']['seconds_total']==1500 and
         plan['cpu']==12 and not plan['cpu_exclusive'] and not plan['retry'],'Resource/retry scope differs')
 return {'passed':True,'controller_payloads':len(own['files']),'scientific_payloads':len(science['files']),
         'closed_payloads':counts,'direct_bindings':len(b['files']),'native_actions':0}
