"""Pure hash-before-parse derivative of sealed private candidate2. Never runs native code."""
from pathlib import Path
import difflib, hashlib, json, re
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'.tirust-build/kinematic-invariant-amplitude-proposal-2'
BASE_SHA='ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74'
REF=ROOT/'.tirust-build/kinematic-invariant-reference-adjudication-proposal-1'
REF_SHA='0a0dba9baf12ff5a988e4d459141a48140f285a396658ee10f7f09099848dbd8'
def require(ok,msg):
    if not ok: raise ValueError(msg)
def pin(path):
    raw=Path(path).read_bytes(); return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def sealed(root,sha):
    require(pin(root/'index.json')['sha256']==sha,'index hash')
    files=json.loads((root/'index.json').read_bytes())['files']
    for name,expected in files.items(): require(pin(root/name)==expected,('payload',name))
    return files
def once(text,old,new):
    require(text.count(old)==1,('anchor',text.count(old),old[:100])); return text.replace(old,new,1)
def sub(text,name):
    start=text.index('      SUBROUTINE '+name+'(')
    end=re.search(r'^      END\s*$',text[start:],re.M)
    require(end is not None,'subroutine end'); return text[start:start+end.end()]
def replace_sub(text,name,new): return once(text,sub(text,name),new)
USE='''      USE ML_PRIVATE_AMPLITUDE_SUPPORT, ONLY: PC_IK,
     $ PC_ENV_VALID,PC_DIFFERENCE_BOUNDS,PC_QP_BITS
      USE ML_PRIVATE_MATCHED_INPUTS, ONLY: PC_MATCH_BEGIN,
     $ PC_MATCH_END,PC_MATCH_NRS_ERROR
'''
DECL='''      INTEGER PC_NW,PC_WE(PC_NW),PC_PAIRING(NLOOPLINE)
      LOGICAL PC_ROUTE_OK,PC_PRODUCER_OK
      COMPLEX*32 PC_CANON(0:LOOPMAXCOEFS-1)
      INTEGER PC_CHORD(0:3,NLOOPLINE)
      INTEGER PC_CLASS(NLOOPLINE,NLOOPLINE)
      LOGICAL PC_HAVE(NLOOPLINE)
      INTEGER(PC_IK) PC_ENV
      INTEGER PC_QERROR(0:3,NLOOPLINE,NLOOPLINE),PC_TRACE_ID
      INTEGER(PC_IK) PC_SHIFTS(0:3,NLOOPLINE)
      LOGICAL PC_PAIR(NLOOPLINE,NLOOPLINE)
      LOGICAL PC_USE(NLOOPLINE,NLOOPLINE)
      REAL*16 PC_DIRECT(NLOOPLINE,NLOOPLINE)
      INTEGER(PC_IK) PC_INV_BITS(NLOOPLINE*NLOOPLINE)
      INTEGER(PC_IK),PARAMETER :: PC_EXP_MASK=
     $ INT(Z'7FFF0000000000000000000000000000',PC_IK)
'''
def private_nrs(text):
    old=sub(text,'ML5_0_MP_NINJARS_LOOP')
    body=once(old,'      SUBROUTINE ML5_0_MP_NINJARS_LOOP(NLOOPLINE,PL,M2L,RANK,RES\n     $ ,STABLE)',
      '      SUBROUTINE ML5_0_MATCHED_MP_NINJARS_LOOP(NLOOPLINE,PL,\n'
      '     $ M2L,RANK,RES,STABLE,ID,SQSOINDEX,PC_CHORD,PC_CLASS,\n'
      '     $ PC_HAVE,PC_ENV,PC_NW,PC_WE,PC_PAIRING,PC_ROUTE_OK,\n'
      '     $ PC_PRODUCER_OK)')
    body=once(body,'      USE MNINJARS\n','      USE MNINJARS\n'+USE)
    body=once(body,'      INTEGER NLOOPLINE,RANK\n','      INTEGER NLOOPLINE,RANK\n'+DECL)
    body=once(body,'      COMMON/ML5_0_LOOP/ID,SQSOINDEX,R\n','')
    oldhelper='''      CALL ML5_0_MP_BUILD_KINEMATIC_MATRIX(NLOOPLINE,P_S_MAT,MASSES
     $ ,S_MAT)'''
    helper='''      PC_SHIFTS=PC_QP_BITS(P_NRS)
      CALL PC_DIFFERENCE_BOUNDS(NLOOPLINE,128,PC_SHIFTS,
     $ PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV_VALID(PC_ENV),PC_QERROR,
     $ PC_PAIR)
      CALL ML5_0_MP_PRIVATE_KINEMATIC_MATRIX(NLOOPLINE,P_S_MAT,
     $ MASSES,PC_CLASS,PC_QERROR,PC_PAIR,PC_ENV,S_MAT,PC_DIRECT,PC_USE)'''
    body=once(body,oldhelper,helper)
    expr='''          REAL_S_MAT(I,J)=REAL(S_MAT(I,J)+MASSES(I)+MASSES(J)
     $     ,KIND=KI_QNRS)'''
    body=once(body,expr,'''          IF(PC_USE(I,J)) THEN
            REAL_S_MAT(I,J)=PC_DIRECT(I,J)
          ELSE
'''+expr+'\n          ENDIF')
    sym='''C     Same authoritative-upper finite-only policy as candidate9.
      PC_INV_BITS=TRANSFER(REAL_S_MAT,PC_INV_BITS,
     $ NLOOPLINE*NLOOPLINE)
      IF(ALL(IAND(PC_INV_BITS,PC_EXP_MASK).NE.PC_EXP_MASK)) THEN
      DO J=2,NLOOPLINE
        DO I=1,J-1
          IF(REAL_S_MAT(J,I).NE.REAL_S_MAT(I,J)) THEN
            REAL_S_MAT(J,I)=REAL_S_MAT(I,J)
          ENDIF
        ENDDO
      ENDDO
      ENDIF
'''
    body=once(body,'      CURR_MAXCOEF=NCOEF_R(RANK)\n',sym+'      CURR_MAXCOEF=NCOEF_R(RANK)\n'
      'C     Snapshot canonical coefficients before odd-degree conversion.\n'
      '      PC_CANON(0:CURR_MAXCOEF-1)=\n'
      '     $ LOOPCOEFS(0:CURR_MAXCOEF-1,SQSOINDEX,ID)\n')
    body=once(body,'      NRS_SCALE=REAL(MU_R**2,KIND=KI_QNRS)\n',
      'C     Diagnostic native-input alignment to unchanged candidate9.\n'
      '      NRS_SCALE=REAL(MU_R,KIND=KI_QNRS)**2\n')
    call='''      CALL NINJARS_TENSOR_EVALUATE(TENSORCOEFS(0:CURR_MAXCOEF-1)
     $ ,NLOOPLINE,RANK,REAL_S_MAT,P_NRS,MASSES,NRS_SCALE,NRS_RES,R1
     $ ,NRS_STATUS,MAX(0,LOOPPOLEMODE))'''
    before='''      CALL PC_MATCH_BEGIN(8,CTMODE,ID,SQSOINDEX,NLOOPLINE,RANK,
     $ CURR_MAXCOEF,P_NRS,REAL_S_MAT,MASSES,NRS_SCALE,
     $ PC_CANON(0:CURR_MAXCOEF-1),
     $ TENSORCOEFS(0:CURR_MAXCOEF-1),PC_CLASS,PC_HAVE,PC_PAIR,
     $ PC_USE,PC_CHORD,PC_QERROR,PC_ENV,PC_NW,PC_WE,
     $ PC_PAIRING,PC_ROUTE_OK,PC_PRODUCER_OK,PC_TRACE_ID)
'''
    after='''
C     Getter immediately precedes any later guarded NinjaRS call.
      CALL PC_MATCH_NRS_ERROR(PC_TRACE_ID)
      CALL PC_MATCH_END(PC_TRACE_ID,NRS_STATUS,P_NRS,REAL_S_MAT,
     $ MASSES,NRS_SCALE,LOOPCOEFS(0:CURR_MAXCOEF-1,SQSOINDEX,ID),
     $ TENSORCOEFS(0:CURR_MAXCOEF-1))
      IF(NRS_STATUS.NE.NINJARS_SUCCESS) THEN
        FPE_IN_QP_REDUCTION=.TRUE.
        RETURN
      ENDIF'''
    # Explicit failure return also prevents original finite check from reading failed native outputs.
    body=once(body,call,before+call+after)
    return body

def route8(text):
    old='''            CALL ML5_0_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L,RANK
     $       ,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),S(SQUAREDSOINDEX
     $       ,LOOPNUM))'''
    new='''            PC_ROUTE_OK=PC_PRODUCER_OK.AND.
     $       PC_ROUTE_MATCHES(LOOPNUM,NLOOPLINE,SIZE(WE),WE,PAIRING)
            DO J=1,4
              DO I=0,3
                PC_EXTERNAL(1,I,J)=PC_QP_BITS(REAL(MP_W(J)%P(I),
     $           KIND=16))
                PC_EXTERNAL(2,I,J)=PC_QP_BITS(AIMAG(MP_W(J)%P(I)))
              ENDDO
            ENDDO
            CALL PC_BUILD_CHORD(LOOPNUM,CTMODE,128,NLOOPLINE,
     $       PC_EXTERNAL,PC_ROUTE_OK.AND.PC_ENV_VALID(PC_ENV),
     $       PC_CHORD,PC_CLASS,PC_HAVE)
            CALL ML5_0_MATCHED_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L,
     $       RANK,LOOPRES(1,SQUAREDSOINDEX,LOOPNUM),
     $       S(SQUAREDSOINDEX,LOOPNUM),LOOPNUM,SQUAREDSOINDEX,
     $       PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV,SIZE(WE),WE,PAIRING,
     $       PC_ROUTE_OK,PC_PRODUCER_OK)'''
    require(text.count(old)==4,'four current generated LOOP_N callers')
    text=text.replace(old,new)
    old9='''     $       PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)'''
    new9='''     $       PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV,SIZE(WE),WE,PAIRING,
     $       PC_ROUTE_OK,PC_PRODUCER_OK)'''
    require(text.count(old9)==4,'four private9 explicit callers')
    return text.replace(old9,new9)

def trace9(text):
    original=sub(text,'ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC')
    body=once(original,'''      SUBROUTINE ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE
     $ ,RANK,PL,M2L,TIRCOEFS,STABLE,
     $ PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)''','''      SUBROUTINE ML5_0_MATCHED_MP_TIRUST_DIAGNOSTIC(CTMODE,
     $ NLOOPLINE,RANK,PL,M2L,TIRCOEFS,STABLE,
     $ PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV,ID,SQSOINDEX,PC_CANON,
     $ PC_NW,PC_WE,PC_PAIRING,PC_ROUTE_OK,PC_PRODUCER_OK)''')
    body=once(body,'      USE MTIRUST\n','      USE MTIRUST\n'
      '      USE ML_PRIVATE_MATCHED_INPUTS, ONLY: PC_MATCH_BEGIN,\n'
      '     $ PC_MATCH_END\n')
    body=once(body,'      INTEGER CTMODE,NLOOPLINE,RANK,I,J,K,NC,STATUS\n',
      '      INTEGER CTMODE,NLOOPLINE,RANK,I,J,K,NC,STATUS\n'
      '      INTEGER ID,SQSOINDEX,PC_TRACE_ID\n'
      '      COMPLEX*32 PC_CANON(0:LOOPMAXCOEFS-1)\n'
      '      INTEGER PC_NW,PC_WE(PC_NW),PC_PAIRING(NLOOPLINE)\n'
      '      LOGICAL PC_ROUTE_OK,PC_PRODUCER_OK\n')
    call='''      CALL TIRUST_TENSOR_EVALUATE(NLOOPLINE,RANK,SHIFTS,INVARIANTS
     $ ,MASSES,SCALE,RAW(1:NC,1:4),STATUS,MAX(0,LOOPPOLEMODE)
     $ ,TIRUSTCOMPUTEFINITE,CHECK_PASS,CACHE_ENABLED)'''
    before='''      CALL PC_MATCH_BEGIN(9,CTMODE,ID,SQSOINDEX,NLOOPLINE,RANK,
     $ NC,SHIFTS,INVARIANTS,MASSES,SCALE,PC_CANON(0:NC-1),
     $ PC_CANON(0:NC-1),PC_CLASS,PC_HAVE,PC_PAIR,PC_USE,PC_CHORD,
     $ PC_QERROR,PC_ENV,PC_NW,PC_WE,PC_PAIRING,PC_ROUTE_OK,
     $ PC_PRODUCER_OK,PC_TRACE_ID)
'''
    after='''
      CALL PC_MATCH_END(PC_TRACE_ID,STATUS,SHIFTS,INVARIANTS,
     $ MASSES,SCALE,PC_CANON(0:NC-1),PC_CANON(0:NC-1))'''
    body=once(body,call,before+call+after)
    caller=sub(text,'ML5_0_PRIVATE_MP_TIRUST_LOOP')
    caller=once(caller,'     $ PC_HAVE,PC_ENV)',
      '     $ PC_HAVE,PC_ENV,PC_NW,PC_WE,PC_PAIRING,PC_ROUTE_OK,\n'
      '     $ PC_PRODUCER_OK)')
    caller=once(caller,'      INTEGER NLOOPLINE,RANK,CTMODE,I,J\n',
      '      INTEGER NLOOPLINE,RANK,CTMODE,I,J\n'
      '      INTEGER PC_NW,PC_WE(PC_NW),PC_PAIRING(NLOOPLINE)\n'
      '      LOGICAL PC_ROUTE_OK,PC_PRODUCER_OK\n')
    caller=once(caller,'''      CALL ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,
     $ RANK,PL,M2L,COEFS,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)''','''      CALL ML5_0_MATCHED_MP_TIRUST_DIAGNOSTIC(CTMODE,NLOOPLINE,
     $ RANK,PL,M2L,COEFS,STABLE,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV,
     $ ID,SQSOINDEX,LOOPCOEFS(:,SQSOINDEX,ID),PC_NW,PC_WE,
     $ PC_PAIRING,PC_ROUTE_OK,PC_PRODUCER_OK)''')
    return replace_sub(text,'ML5_0_PRIVATE_MP_TIRUST_LOOP',caller)+'\n'+body+'\n'

def derive_driver(text):
    # Reuse reviewed bootstrap/READY/DONE/word-output driver, dropping old logger only.
    text=text[:text.index('\nC     Private bounded usage/status log.')]
    text=once(text,'backend(6/8)','backend(8/9)')
    text=once(text,"      IF(TRIM(ARG).NE.'6'.AND.TRIM(ARG).NE.'8') STOP 21\n",
       "      IF(TRIM(ARG).NE.'8'.AND.TRIM(ARG).NE.'9') STOP 21\n")
    text=once(text,'      PROGRAM KTRACE_MADLOOP_WORKER\n',
      '      PROGRAM KTRACE_MADLOOP_WORKER\n'
      '      USE ML_PRIVATE_MATCHED_INPUTS, ONLY: PC_MATCH_PHASE_START,\n'
      '     $ PC_MATCH_FLUSH\n')
    return text.replace('CALL PC_REF_PHASE_START(','CALL PC_MATCH_PHASE_START(').replace('CALL PC_REF_FLUSH','CALL PC_MATCH_FLUSH')

def products():
    sealed(BASE,BASE_SHA); sealed(REF,REF_SHA)
    names=('CT_interface.f','TIRUST_interface.f','TIR_interface.f',
           'loop_matrix.f','loop_CT_calls_1.f','mp_compute_loop_coefs.f')
    texts={name:(BASE/'candidate'/name).read_text() for name in names}
    ct=texts['CT_interface.f']; ti=texts['TIRUST_interface.f']
    texts['CT_interface.f']=route8(ct)+'\n'+private_nrs(ct)+'\n'
    texts['TIRUST_interface.f']=trace9(ti)
    result={'candidate/'+k:v for k,v in texts.items()}
    for name in ('CT_interface.f','TIRUST_interface.f'):
        result[name+'.patch']=''.join(difflib.unified_diff((BASE/'candidate'/name).read_text().splitlines(True),texts[name].splitlines(True),fromfile='sealed-candidate2/'+name,tofile='private-matched/'+name))
    driver=(REF/'driver-reference.f').read_text()
    result['driver-matched.f']=derive_driver(driver)
    result['driver-matched.f.patch']=''.join(difflib.unified_diff(driver.splitlines(True),result['driver-matched.f'].splitlines(True),fromfile='sealed-reference/driver-reference.f',tofile='private-matched/driver-matched.f'))
    card=(REF/'backend8-mode4-MadLoopParams.dat').read_text()
    result['backend8-mode4-MadLoopParams.dat']=card
    result['backend9-mode4-MadLoopParams.dat']=once(card,'#MLReductionLib\n8\n','#MLReductionLib\n9\n')
    return result

def main():
    require(not (HERE/'index.json').exists(),'Sealed proposal is immutable')
    for name,text in products().items():
        path=HERE/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(text)
if __name__=='__main__': main()
