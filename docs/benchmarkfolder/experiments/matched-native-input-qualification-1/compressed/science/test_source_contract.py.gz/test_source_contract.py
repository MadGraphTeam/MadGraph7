"""File-only regressions for the narrow matched8/9 derivative; no compiler/library."""
import json,re,unittest
from pathlib import Path
import prepare as P
H=Path(__file__).resolve().parent
class SourceContract(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.products=P.products()
  cls.ct=cls.products['candidate/CT_interface.f']
  cls.tir=cls.products['candidate/TIRUST_interface.f']
  cls.oldct=(P.BASE/'candidate/CT_interface.f').read_text()
  cls.oldtir=(P.BASE/'candidate/TIRUST_interface.f').read_text()
  cls.log=(H/'matched_trace.f90').read_text()
 def test_derivation_reproduces_all_products(self):
  for name,text in self.products.items(): self.assertEqual((H/name).read_text(),text,name)
 def test_legacy8_and_other_reducers_unchanged(self):
  for name in ('ML5_0_MP_NINJARS_LOOP','ML5_0_NINJARS_LOOP','ML5_0_MP_NINJA_LOOP','ML5_0_NINJA_LOOP','ML5_0_BUILD_KINEMATIC_MATRIX','ML5_0_MP_BUILD_KINEMATIC_MATRIX','ML5_0_PRIVATE_KINEMATIC_MATRIX','ML5_0_MP_PRIVATE_KINEMATIC_MATRIX'):
   self.assertEqual(P.sub(self.ct,name),P.sub(self.oldct,name),name)
 def test_existing_tirust_diagnostics_unchanged(self):
  for name in ('ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC','ML5_0_PRIVATE_TIRUST_DIAGNOSTIC','ML5_0_MP_TIRUST_TENSOR_DIAGNOSTIC','ML5_0_TIRUST_TENSOR_DIAGNOSTIC','ML5_0_MP_TIRUST_LOOP'):
   self.assertEqual(P.sub(self.tir,name),P.sub(self.oldtir,name),name)
 def test_unmodified_producers_and_kernel_files(self):
  for name in ('TIR_interface.f','loop_matrix.f','loop_CT_calls_1.f','mp_compute_loop_coefs.f'):
   self.assertEqual((H/'candidate'/name).read_bytes(),(P.BASE/'candidate'/name).read_bytes())
 def test_fresh_metadata_all_four_callers_each_backend(self):
  for name in ('ML5_0_LOOP_3','ML5_0_LOOP_4','ML5_0_LOOP_2','ML5_0_LOOP_1_2'):
   b=P.sub(self.ct,name)
   self.assertEqual(b.count('PC_ROUTE_MATCHES(LOOPNUM'),2)
   self.assertEqual(b.count('PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV,SIZE(WE),WE,PAIRING,'),2)
   self.assertEqual(b.count('PC_ROUTE_OK,PC_PRODUCER_OK)'),2)
   self.assertIn('PC_ROUTE_OK=PC_PRODUCER_OK.AND.',b)
 def test_private8_has_no_stale_loop_common(self):
  b=P.sub(self.ct,'ML5_0_MATCHED_MP_NINJARS_LOOP')
  self.assertNotIn('COMMON/ML5_0_LOOP/',b)
  self.assertIn('M2L,RANK,RES,STABLE,ID,SQSOINDEX',b)
  self.assertIn('PC_NW,PC_WE,PC_PAIRING,PC_ROUTE_OK,',b)
 def test_native8_failure_before_any_output_access(self):
  b=P.sub(self.ct,'ML5_0_MATCHED_MP_NINJARS_LOOP')
  a=b.index('CALL NINJARS_TENSOR_EVALUATE')
  error=b.index('CALL PC_MATCH_NRS_ERROR',a)
  end=b.index('CALL PC_MATCH_END',error)
  gate=b.index('IF(NRS_STATUS.NE.NINJARS_SUCCESS)',end)
  ret=b.index('RETURN',gate)
  inspect=b.index('IEEE_IS_FINITE(REAL(NRS_RES',ret)
  self.assertLess(ret,inspect)
  self.assertNotIn('NRS_RES(',b[error:ret])
 def test_original_prefix_and_residual_order_kept(self):
  old=P.sub(self.oldct,'ML5_0_MP_NINJARS_LOOP')
  new=P.sub(self.ct,'ML5_0_MATCHED_MP_NINJARS_LOOP')
  a=old.index('      P_TMP=0');z=old.index("C     Use MadLoop's thresholded")
  self.assertIn(old[a:z],new)
  self.assertNotIn('P_TMP(:,0)=0',new)
 def test_only_private8_scale_and_policy_alignment(self):
  new=P.sub(self.ct,'ML5_0_MATCHED_MP_NINJARS_LOOP')
  self.assertIn('NRS_SCALE=REAL(MU_R,KIND=KI_QNRS)**2',new)
  self.assertIn('NRS_SCALE=REAL(MU_R**2,KIND=KI_QNRS)',P.sub(self.ct,'ML5_0_MP_NINJARS_LOOP'))
  self.assertIn('CALL ML5_0_MP_PRIVATE_KINEMATIC_MATRIX',new)
  self.assertIn('IF(PC_USE(I,J)) THEN\n            REAL_S_MAT(I,J)=PC_DIRECT(I,J)',new)
  self.assertIn('REAL_S_MAT(J,I)=REAL_S_MAT(I,J)',new)
 def test_canonical_snapshot_precedes_odd_sign(self):
  new=P.sub(self.ct,'ML5_0_MATCHED_MP_NINJARS_LOOP')
  self.assertLess(new.index('PC_CANON(0:CURR_MAXCOEF-1)='),new.index('IF (MOD(COEFTORANK_MAP(I),2).EQ.1)'))
  self.assertEqual(new.count('IF (MOD(COEFTORANK_MAP(I),2).EQ.1)'),1)
  self.assertIn('PC_CANON(0:CURR_MAXCOEF-1),',new)
 def test_trace9_numerics_restore_to_old_body(self):
  b=P.sub(self.tir,'ML5_0_MATCHED_MP_TIRUST_DIAGNOSTIC')
  old=P.sub(self.oldtir,'ML5_0_MP_PRIVATE_TIRUST_DIAGNOSTIC')
  # Executable source after first assignment is unchanged except two integer input-only calls.
  b=b[b.index('      STABLE=.FALSE.'):]
  b=re.sub(r'      CALL PC_MATCH_BEGIN\(.*?\n(?=      CALL TIRUST_TENSOR_EVALUATE)', '',b,flags=re.S)
  b=re.sub(r'      CALL PC_MATCH_END\(.*?\n(?=      IF\(STATUS.NE.TIRUST_SUCCESS\))','',b,flags=re.S)
  self.assertEqual(b.rstrip(),old[old.index('      STABLE=.FALSE.'):].rstrip())
 def test_recorder_never_receives_result_buffers(self):
  self.assertNotRegex(self.log,r'\b(?:NRS_RES|TIRCOEFS|RAW|R1|COEFS)\b')
  for name in ('pc_match_begin','pc_match_end','copy_words'):
   b=self.log.split('  subroutine '+name+'(',1)[1].split('  end subroutine',1)[0]
   self.assertNotRegex(b,r'(?i)\b(?:write|read|open|flush|allocate)\s*\(')
  self.assertIn('max_calls=128',self.log)
  self.assertIn('after=record()',self.log)
 def test_driver_exact_bounded_scope(self):
  b=self.products['driver-matched.f']
  self.assertEqual(b.count('CALL ML5_0_SLOOPMATRIX_THRES('),2)
  self.assertEqual(b.count('CALL PC_MATCH_FLUSH'),2)
  self.assertIn("IF(TRIM(ARG).NE.'8'.AND.TRIM(ARG).NE.'9') STOP 21",b)
  self.assertIn("IF(TRIM(ARG).NE.'4') STOP 21",b)
  self.assertIn('CALL ML5_0_FORCE_STABILITY_CHECK(.FALSE.)',b)
  self.assertIn('IF(.NOT.UseQPIntegrandForNinjaRS) STOP 24',b)
  self.assertIn('IF(LoopPoleMode.NE.0) STOP 24',b)
 def test_no_new_fixed_form_truncation(self):
  for name in ('CT_interface.f','TIRUST_interface.f'):
   old=set((P.BASE/'candidate'/name).read_text().splitlines())
   for line in self.products['candidate/'+name].splitlines():
    if line not in old and line[:1] not in ('C','c','*','!'):
     self.assertLessEqual(len(line),72,line)
 def test_anchor_fail_closed(self):
  with self.assertRaises(ValueError): P.private_nrs(self.oldct.replace('      NRS_SCALE=REAL(MU_R**2,KIND=KI_QNRS)\n','      NRS_SCALE=0\n'))
  with self.assertRaises(ValueError): P.route8(self.oldct.replace('CALL ML5_0_MP_NINJARS_LOOP','CALL OTHER_MP_NINJARS_LOOP',1))
if __name__=='__main__': unittest.main()
