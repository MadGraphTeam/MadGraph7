! PRIVATE SOURCE-ONLY bounded input recorder; no output tensor/coefficient arguments.
! All native inputs are copied with integer TRANSFER, including the q0 residual.
module ml_private_matched_inputs
  use, intrinsic :: iso_c_binding, only: c_char,c_size_t,c_null_char
  use ml_private_amplitude_support, only: pc_ik,pc_capture_env
  implicit none
  private
  public :: pc_match_begin,pc_match_end,pc_match_nrs_error
  public :: pc_match_phase_start,pc_match_flush
  integer,parameter :: max_calls=128,max_n=4,max_nc=15,max_error=8192
  integer,parameter :: qp_assert=1/merge(1,0,storage_size(0.0_16)==128.and. &
      digits(0.0_16)==113.and.radix(0.0_16)==2.and.bit_size(0_pc_ik)==128)
  type record
    integer :: header(14)=0
    integer(pc_ik) :: env(2)=0,shifts(16)=0,invariants(16)=0,masses(8)=0,scale(1)=0
    integer(pc_ik) :: canonical(30)=0,wire(30)=0
    integer :: classes(16)=0,have(4)=0,pair(16)=0,used(16)=0,chord(16)=0,qerror(64)=0
    integer :: routing(3)=0,we(4)=0,pairing(4)=0
    integer :: error_required=0,error_copied=0,error_truncated=0,error_bytes(max_error)=0
  end type
  type(record),save :: records(max_calls)
  integer,save :: phase=-1,sequence=0,written=0,pending=0
  interface
    function existing_nrs_last_error(message,capacity) bind(C,name='ninjars_last_error') result(required)
      import :: c_char,c_size_t
      character(c_char),intent(out) :: message(*)
      integer(c_size_t),value :: capacity
      integer(c_size_t) :: required
    end function
  end interface
contains
  subroutine pc_match_phase_start(new_phase)
    integer,intent(in)::new_phase
    if(pending/=0.or.sequence/=written.or.new_phase/=phase+1.or.new_phase>1) stop 26
    phase=new_phase
    write(76,'(A,1X,I0)') 'MATCH_BEGIN',phase
    flush(76)
  end subroutine

  subroutine copy_words(n,nc,p,s,m,mu2,canonical,wire,out)
    integer,intent(in)::n,nc
    real(kind=16),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=16),intent(in)::m(n),canonical(nc),wire(nc)
    type(record),intent(inout)::out
    out%shifts(:4*n)=transfer(p,out%shifts,4*n)
    out%invariants(:n*n)=transfer(s,out%invariants,n*n)
    out%masses(:2*n)=transfer(m,out%masses,2*n)
    out%scale=transfer(mu2,out%scale,1)
    out%canonical(:2*nc)=transfer(canonical,out%canonical,2*nc)
    out%wire(:2*nc)=transfer(wire,out%wire,2*nc)
  end subroutine

  subroutine pc_match_begin(backend,mode,id,sqso,n,rank,nc,p,s,m,mu2,canonical,wire, &
       classes,have,pair,used,chord,qerror,entry_env,nw,we,pairing,route_ok,producer_ok,token)
    integer,intent(in)::backend,mode,id,sqso,n,rank,nc,classes(n,n),chord(0:3,n),qerror(0:3,n,n)
    logical,intent(in)::have(n),pair(n,n),used(n,n),route_ok,producer_ok
    integer,intent(in)::nw,we(nw),pairing(n)
    real(kind=16),intent(in)::p(0:3,n),s(n,n),mu2
    complex(kind=16),intent(in)::m(n),canonical(nc),wire(nc)
    integer(pc_ik),intent(in)::entry_env
    integer,intent(out)::token
    if(phase<0.or.phase>1.or.pending/=0.or.sequence>=max_calls) stop 26
    if(n<1.or.n>max_n.or.nc<1.or.nc>max_nc.or.nw<1.or.nw>4) stop 26
    if(rank<0.or.rank>2.or.nc/=(rank+1)*(rank+2)*(rank+3)*(rank+4)/24) stop 26
    if((backend/=8.and.backend/=9).or.mode/=4.or.id<1.or.id>26.or.sqso/=1) stop 26
    sequence=sequence+1; token=sequence; pending=token
    records(token)%header=[token,phase,backend,mode,id,sqso,n,rank,nc, &
                           storage_size(p(0,1)),digits(p(0,1)),-999,0,0]
    records(token)%env=[entry_env,pc_capture_env()]
    call copy_words(n,nc,p,s,m,mu2,canonical,wire,records(token))
    records(token)%routing=[nw,merge(1,0,route_ok),merge(1,0,producer_ok)]
    records(token)%we(:nw)=we
    records(token)%pairing(:n)=pairing
    records(token)%classes(:n*n)=reshape(classes,[n*n])
    records(token)%have(:n)=merge(1,0,have)
    records(token)%pair(:n*n)=reshape(merge(1,0,pair),[n*n])
    records(token)%used(:n*n)=reshape(merge(1,0,used),[n*n])
    records(token)%chord(:4*n)=reshape(chord,[4*n])
    records(token)%qerror(:4*n*n)=reshape(qerror,[4*n*n])
  end subroutine

  subroutine pc_match_nrs_error(token)
    integer,intent(in)::token
    character(c_char)::buffer(max_error+1)
    integer(c_size_t)::required
    integer::j,copied
    if(token/=pending.or.token<1.or.token>sequence) stop 26
    if(records(token)%header(3)/=8) stop 26
    ! Exactly one existing getter call immediately after evaluate; no new engine call.
    buffer=c_null_char
    required=existing_nrs_last_error(buffer,int(size(buffer),c_size_t))
    copied=0
    do j=1,max_error
      if(buffer(j)==c_null_char) exit
      copied=copied+1
      records(token)%error_bytes(copied)=iachar(buffer(j))
    enddo
    records(token)%error_copied=copied
    ! Required includes terminator in the pinned bridge. Overflow is retained, never accepted.
    if(required>int(huge(j),c_size_t)) then
      records(token)%error_required=-1;records(token)%error_truncated=1
    else
      records(token)%error_required=int(required)
      records(token)%error_truncated=merge(1,0,required/=int(copied+1,c_size_t))
    endif
  end subroutine

  subroutine pc_match_end(token,status,p,s,m,mu2,canonical,wire)
    integer,intent(in)::token,status
    real(kind=16),intent(in)::p(:,:),s(:,:),mu2
    complex(kind=16),intent(in)::m(:),canonical(:),wire(:)
    type(record)::after
    integer::n,nc
    logical::same
    if(token/=pending.or.token<1.or.token>sequence) stop 26
    n=records(token)%header(7);nc=records(token)%header(9)
    if(any(shape(p)/=[4,n]).or.any(shape(s)/=[n,n]).or.size(m)/=n) stop 26
    if(size(canonical)/=nc.or.size(wire)/=nc) stop 26
    after=record()
    call copy_words(n,nc,p,s,m,mu2,canonical,wire,after)
    same=all(records(token)%shifts==after%shifts).and. &
         all(records(token)%invariants==after%invariants).and. &
         all(records(token)%masses==after%masses).and. &
         all(records(token)%scale==after%scale).and. &
         all(records(token)%canonical==after%canonical).and.all(records(token)%wire==after%wire)
    records(token)%header(12:14)=[status,1,merge(1,0,same)]
    pending=0
  end subroutine

  subroutine words(seq,tag,data)
    integer,intent(in)::seq
    character(*),intent(in)::tag
    integer(pc_ik),intent(in)::data(:)
    write(76,'(A,1X,I0,1X,A,1X,I0,1X,*(Z32.32,1X))') 'MATCH_WORDS',seq,tag,size(data),data
  end subroutine
  subroutine metadata(seq,tag,data)
    integer,intent(in)::seq,data(:)
    character(*),intent(in)::tag
    write(76,'(A,1X,I0,1X,A,1X,I0,1X,*(I0,1X))') 'MATCH_META',seq,tag,size(data),data
  end subroutine

  subroutine pc_match_flush
    integer::k,n,nc,ec
    if(pending/=0.or.phase<0.or.phase>1) stop 26
    do k=written+1,sequence
      n=records(k)%header(7);nc=records(k)%header(9);ec=records(k)%error_copied
      write(76,'(A,1X,*(I0,1X))') 'MATCH_CALL',records(k)%header
      write(76,'(A,1X,I0,1X,2(Z32.32,1X))') 'MATCH_ENV',k,records(k)%env
      call words(k,'SHIFT',records(k)%shifts(:4*n))
      call words(k,'INV',records(k)%invariants(:n*n))
      call words(k,'MASS',records(k)%masses(:2*n))
      call words(k,'SCALE',records(k)%scale)
      call words(k,'CANON',records(k)%canonical(:2*nc))
      call words(k,'WIRE',records(k)%wire(:2*nc))
      call metadata(k,'ROUTE',records(k)%routing)
      call metadata(k,'WE',records(k)%we(:records(k)%routing(1)))
      call metadata(k,'PAIRING',records(k)%pairing(:n))
      call metadata(k,'CLASS',records(k)%classes(:n*n))
      call metadata(k,'HAVE',records(k)%have(:n))
      call metadata(k,'PAIR',records(k)%pair(:n*n))
      call metadata(k,'USE',records(k)%used(:n*n))
      call metadata(k,'CHORD',records(k)%chord(:4*n))
      call metadata(k,'QERROR',records(k)%qerror(:4*n*n))
      write(76,'(A,1X,*(I0,1X))') 'MATCH_ERROR',k,records(k)%error_required, &
         ec,records(k)%error_truncated,records(k)%error_bytes(:ec)
    enddo
    written=sequence
    write(76,'(A,1X,2(I0,1X))') 'MATCH_END',phase,sequence
    flush(76)
  end subroutine
end module
