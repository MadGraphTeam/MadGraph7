# QP8 / private QP9 matched-native-input source audit

Scope: source and binary-file reads only. Candidate source packet `ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74` and all 55 payloads verified. No compiler, loader, amplitude, Git operation, production edit, or failed-coefficient decoding occurred. The only writes are this audit and its adjacent source-pin record. Installed library bytes remain the already closed artifacts; none is rebuilt. A second reviewer independently checked NinjaRS API/layout, archive symbols, and error handling.

Paths below are relative to the repository. `C` means `.tirust-build/kinematic-invariant-amplitude-proposal-2/candidate`; `O` means `.tirust-build/kinematic-invariant-amplitude-executor-2/work/builds/cms/original/SubProcesses/P0_epem_mupmum`; `N` means `HEPTools/ninjars/include`; `T` means `.tirust-build/qp-transport-install/mg/HEPTools/tirust/include`. Exact file pins are in `routing-source-pins.json`.

## Native layouts and the required equality gate

Both QP adapters use real binary128 momenta/invariants/scale and complex binary128 squared masses. Fortran layouts are `P(0:3,N)`, `INV(N,N)`, `MASSES(N)`, and scalar `MU2`. P is `(E,x,y,z)` for each propagator; matrices use Fortran column-major order. The native invariant is `(P_i-P_j)^2`, not MadLoop's mass-subtracted complex `S_MAT`. Neither library should receive `S_MAT` directly.

`T/mtirust.f90:296–343` and `N/mninjars.f90:162–201` both pack each real value into a 64-byte decimal record with 39 fractional decimal digits. Shift record `4*(i-1)+mu+1` holds `P(mu,i)`. Invariant record `N*(i-1)+j` holds `INV(j,i)`. Squared masses are interleaved real/imaginary records. NinjaRS additionally takes one complex polynomial-coefficient vector and returns three Laurent coefficients and R1; TIRust takes no numerator and returns packed tensor moments. Comparing raw output layouts across these interfaces would be invalid.

For every `(outer phase, mode, group, split order, native-call sequence)`, require exact integer-word equality of native shifts, complete invariant matrix, complex squared masses and mu2 across private8/private9. Also require canonical MadLoop numerator words to agree, before backend sign conversion. Capture all 26 groups; do not whitelist the previously failing five. The frozen process has N=1..4, rank=0 or 2, one split order, and `NCOEF_R={1,5,15}` (`O/polynomial.f:7–15`). Rank0 groups are 9,14,16,17,19; all others have rank2. The pin record contains the complete N/rank group partition.

Equality is an admission criterion, not an assumption from identical cards or phase-space labels. Preserve every unequal input and reject same-input interpretation. A status failure blocks coefficient interpretation even when inputs match.

## Propagator order and first residual

Generated wrappers construct each corner by zero-seeded subtraction of the selected wavefunction momenta: `MP_PL(:,j) = -sum MP_W(WE(k))%P`, retaining the generated pairing and order. Complex wavefunction momentum is assigned to real MP_PL with the existing semantics. Do not replace that operation with a separately reconstructed physical momentum formula. Example: `C/CT_interface.f:1225–1252`; the one-propagator/two-wavefunction wrapper is at 1810–1829.

For N ordinary separate corners, squared masses are rotated once to `[M_N^2,M_1^2,...,M_(N-1)^2]` in the wrapper (the N=3 example is 1228–1230). These squares are computed in complex DP and promoted to complex QP in both adapters. N=1 retains `M1**2`. Preserve those original values and order; a coherent-mass recomputation would be a separate intervention.

`MP_SWITCH_ORDER` returns immediately in mode4 (`C/TIR_interface.f:341–345`). Thus the private mode4 proposal must neither reverse corners nor rotate masses again. Modes2/5 are outside this proposal. Their legacy path reverses/negates corners and reverses masses2..N; this audit does not authorize extending the candidate to those modes.

After the switch, the exact chord convention is

- `q0 = (((0 + PL1) + PL2) + ... + PLN)`;
- `qj = (((0 + PL1) + PL2) + ... + PLj)`, for j=1..N-1;
- native column i is `q_(i-1)`.

The first column is the accumulated conservation residual, not a forced zero. Retain it, including signed-zero words. Private9 uses a running zero-seeded prefix (`C/TIRUST_interface.f:274–300`); legacy8 recomputes each zero-seeded prefix (`C/CT_interface.f:1069–1098`). Their per-prefix additions have the same order in mode4. Copying private9's exact prefix source into private8 removes needless implementation ambiguity. Preserve the existing ABSP/REF_P conservation check and its failure behavior.

## Matching the private invariant policy

The legacy8 path calls `MP_BUILD_KINEMATIC_MATRIX` and reconstructs `REAL(S_MAT+MASSES(i)+MASSES(j),QP)` (`C/CT_interface.f:1102–1107`). Private9 first derives fresh bounds, calls `MP_PRIVATE_KINEMATIC_MATRIX`, then chooses direct `DIFFSQ` only where `PC_USE` is true (`C/TIRUST_interface.f:302–315`). Private8 must use that same policy; merely copying OSThres is insufficient.

The helper preserves this order (`C/CT_interface.f:2076–2140`): diagonal; original complex subtraction and Minkowski arithmetic; default mass-subtracted S; mass-i snap; mass-j snap; energy-normalized small-invariant test; certificate decision. A certificate can veto only the final zero snap. It cannot override an earlier mass snap. If admitted, use `PC_DIRECT` directly at the native matrix boundary; subtracting masses and adding them back would reintroduce the cancellation being studied. Unknown metadata retains the original policy.

Private9 then classifies all matrix entries using integer exponent bits and, only when all entries are finite, copies unequal lower entries from the upper triangle (`C/TIRUST_interface.f:318–334`). Preserve this rule, including already-equal pairs' original bits. TIRust consumes the upper triangle; NinjaRS receives the complete matrix. A private8 that omits this step can still have different native inputs.

**Scale mismatch requiring an explicit correction in private8:** private9 uses `REAL(MU_R,KIND=KI_QTIR)**2` at line335; legacy8 uses `REAL(MU_R**2,KIND=KI_QNRS)` at line1117. The latter squares in DP before promotion. A matched private8 must use promote-then-square with the same qualified kind, and capture the actual resulting mu2 words. Preserve old output normalization separately: private8's legacy normalization is DP, while private9 contracts/normalizes in QP then narrows. Matching native inputs does not make those output-stage arithmetic sequences identical.

## Fresh provenance and minimal private8 plumbing

Recommended private signature:

```fortran
SUBROUTINE ML5_0_PRIVATE_MP_NINJARS_LOOP(NLOOPLINE,PL,M2L,RANK,
     $ RES,STABLE,ID,SQSOINDEX,PC_CHORD,PC_CLASS,PC_HAVE,PC_ENV)
```

Pass `LOOPNUM,SQUAREDSOINDEX` directly from all four generated wrapper QP8 branches. The private adapter should not obtain them from `/ML5_0_LOOP/`; explicit arguments avoid stale identity. Keep public `MP_NINJARS_LOOP` and standalone diagnostics on their existing legacy path. Validate diagnostic-only mode4, group1..26, split order1, and the route's N/rank before indexing canonical arrays.

Mirror the QP9 wrapper block (`C/CT_interface.f:1292–1309`, with corresponding blocks for the other three wrapper shapes): check generated `WE` and `PAIRING` with `PC_ROUTE_MATCHES`; capture real and imaginary words of actual `MP_W(1:4)%P`; call `PC_BUILD_CHORD`; pass the resulting metadata as explicit arguments. Never use uninitialized MP_W on a DP path. Do not create a new metadata COMMON or recapture an environment token after numerator production.

The existing candidate already captures the environment before QP wavefunction/coefficient production (`C/loop_matrix.f:1022–1024`), receives the actual `COMPUTE_INTEGRAND_IN_QP` decision (`C/mp_compute_loop_coefs.f:185–191`, including backend8), and passes both through `PRIVATE_LOOP_CT_CALLS_1` (`loop_matrix.f:1149–1157`). Preserve that chain. Fresh direct helper entrypoints remain unknown.

`PC_CHORD` is a set of integer error exponents, not native momentum coordinates. `PC_HAVE` says that an arithmetic bound is available; it is not an assertion that an external momentum is physically on shell. Pair class2 enables the composite-pair certificate; class1 is never promoted into that certificate. `caller_bounds.f90:121–173` resets outputs before every construction; `finish_difference_bounds:175–211` derives pair bounds from the actual native shift words. The environment token excludes sticky IEEE status bits and checks rounding/control settings without changing them (`dependencies/environment_token.c:4–15`).

## Canonical numerator, sign, and weights

The canonical pre-backend-sign array is

```fortran
COMMON /ML5_0_MP_LCOEFS/ LOOPCOEFS
COMPLEX*32 LOOPCOEFS(0:LOOPMAXCOEFS-1,1,26)
```

Capture exactly `LOOPCOEFS(0:NCOEF_R(RANK)-1,SQSOINDEX,ID)`. It already contains the generated color/Born/helicity factors; it is not a bare diagram numerator (`O/polynomial.f:232–250`). The coefficient monomials in canonical indices0..14 are `1,q0,q1,q2,q3,q0²,q0q1,q1²,q0q2,q1q2,q2²,q0q3,q1q3,q2q3,q3²`. No multinomial factors belong in this polynomial vector.

For8, capture before the copy/sign loop at `C/CT_interface.f:1110–1115`. The native vector equals `(-1)^degree * canonical`, with degrees0,1,2 from `COEFTORANK_MAP`; only indices1..4 change sign. Apply that conversion once. No additional sign occurs in the installed NinjaRS packing layer.

For9, capture in `PRIVATE_MP_TIRUST_LOOP` before its diagnostic call (`C/TIRUST_interface.f:501–506`), with the explicit ID/SQSO already available. The existing contraction uses the canonical vector unchanged (513–517). TIRust's declared `Convention::MadLoop` places the odd-degree sign on tensor moments; component weights avoid multinomial duplication. The generated 1-based moment permutation is `[1,2,3,4,5,6,7,10,8,11,13,9,12,14,15]` (254–255). Native9 has no numerator argument, so compare the canonical contraction vector with private8's pre-sign vector, not with private8's signed native vector.

To join private9 geometry records without COMMON identity, extend only its private diagnostic call with explicit ID/SQSO (public wrappers supply unknown/zero identity), or give both private paths a narrow explicit shared input helper. In either case preserve the existing arithmetic and public unknown-metadata behavior. Never read failed tensor outputs merely to complete a trace.

Record QP values using integer TRANSFER words, not decimal output or FP comparisons. With 64-bit words, shifts use8N words, invariants2N², masses4N, mu2 two, canonical complex numerator4NC. Include backend/phase/serial/group/SQSO/mode/N/rank/NC and width128/digits113, plus actual PC_HAVE/PC_CLASS/PC_USE and environment validity. Bounded buffered integer logging with phase end/count markers should retain the established failure policy. Capture native inputs immediately before the call; capture status immediately after it; do not manufacture success from a complete log.

## Installed NinjaRS getter and context

`N/mninjars.f90:216–227` exposes `NINJARS_ERROR_MESSAGE(message)`. Its C binding is `ninjars_last_error` (72–77; header95–96). Pure ar/ELF symbol inspection of the original archive confirms both `ninjars_last_error` and `__mninjars_MOD_ninjars_error_message` are defined global functions; no new export or library rebuild is needed. Original archive is 298293528 bytes, SHA `0edfa89d7d83161a6ce3fdf0bb1fbca928b73d2b5ec44211a3b2efa186a155d6`; module SHA `bdbdea4365d04be8693de8ff10d9594137cca6ceaaf9ce2de3e6991467a625ec`.

Call the getter immediately after evaluation on the same thread, before any later guarded NinjaRS operation/finalize. Preserve raw status independently. Status1 is an ordinary `UNSTABLE` return and deliberately clears Rust LAST_ERROR (`vendor/ninjars/src/lib.rs:110–117,699–710`), so the five existing status1 groups cannot acquire explanatory text from this getter. Fortran-side kind/unpack failure also need not set a new Rust message. The public Fortran wrapper ignores returned required length and may truncate; label text bounded, or bind the already exported C getter and retain required/copied lengths if complete text is essential. Empty text is never success evidence.

The installed module retains one lazily created context (`N/mninjars.f90:19,80–91`); native MP plans/workspaces are reused by `(N,rank)` with fresh coefficients and inputs each call. There is no public integral-cache-off/reset control in this API. Preserve all26 group order, ordinary bootstrap, and fresh-worker lifetime. Pole mode0 includes finite and both poles; do not invent another context lifetime or cache option for this comparison.

## Qualification boundaries

This audit supports preparing a private mode4 matched-input experiment only. It does not establish numerical equality, accuracy, or a responsible failing kernel. Existing stock reference failures remain failures. Exact native-input capture, status/error evidence, ordinary-point controls, subprocess isolation, and independent coefficient eligibility are still required. A future native gate must be separately bounded and reviewed. NinjaRS and TIRust use the oneloopmaster code family at different pinned dependency revisions, so independent reduction is not complete scalar-engine independence.
