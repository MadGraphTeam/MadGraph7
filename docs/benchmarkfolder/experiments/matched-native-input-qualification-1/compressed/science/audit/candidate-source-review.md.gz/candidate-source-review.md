# Independent candidate source review

Verdict: **static clear, with qualification limits**. No concrete blocker was found in the reviewed Fortran adapters, input recorder, or pure source derivation. This is source review only; no compilation, loader invocation, reducer, amplitude, or Git operation was performed. Only these additive audit files were written.

The intended experiment is two fresh mode-4 workers, backend 8 then backend 9, each with one ordinary-point bootstrap followed by one CMS20 measurement: at most four outer amplitude entries. This review does not admit execution. The later controller must enforce this exact point/order/count restriction: the retained driver also accepts point ID 1 and cannot alone enforce two process launches.

## Evidence checked

The pure `prepare.products()` derivation was recomputed without calling `prepare.main()`: all twelve generated products exactly match their materialized copies. Both input seals and all payload hashes were checked before deriving. Ten legacy/public/private helper routines were compared byte for byte with sealed candidate2 and are unchanged. All 22 current pure matched-input tests passed; their full log is retained beside this review. The JSON review records exact payload pins and argument counts. An independent child review also confirmed the recorder/API limits and exact twelve products.

`candidate/CT_interface.f:1300,1512,1720,1924` call the new private8 adapter with 17 arguments; its declaration at line 2212 agrees. Each receives explicit loop ID, split order, fresh chord/class/have/environment, WE/pairing, route result, and genuine-producer result. Four private9 wrapper calls likewise have 17 arguments, matching `candidate/TIRUST_interface.f:473`; its call at line 508 matches the new 19-argument diagnostic at line 533. The types and active array extents agree. The private8 routine no longer reads ID/SQSO from the legacy loop COMMON.

The environment/provenance chain remains the sealed candidate2 implementation: `candidate/loop_matrix.f:1022` captures the environment immediately before the genuine-QP producer and carries the producer result through lines 1150–1157 and all 26 calls in `loop_CT_calls_1.f`. The four LOOP wrappers inspect actual MP_W external momentum components and verify runtime WE/pairing before calling PC_BUILD_CHORD. PC_HAVE denotes available arithmetic bounds, not a claim that external momenta satisfy physical mass shells. Invalid provenance retains the pre-existing fallback and is rejected by the input comparison qualification gate.

## Arithmetic and ABI

The new private8 code preserves its original propagator order, SWITCH_ORDER call, residual q0 accumulation, conservation guard, zero-seeded prefix order, native mass conversion, canonical numerator layout, and one odd-degree sign conversion. Its intentionally changed input preparation agrees with private9: the same private kinematic helper and direct-invariant override, finite-only authoritative-upper symmetrization, and `REAL(MU_R,KIND=QP)**2`. These changes are confined to the new private8 routine; legacy public8 is unchanged. This is therefore a matched-input diagnostic adapter, not an unmodified stock-backend8 result.

Both old public TIRust diagnostic entrypoints and both old private DP/QP diagnostics are byte-preserved. The new matched QP diagnostic is a clone with explicit provenance and input hooks, retaining the original tensor-call arguments and post-success contraction inputs. Canonical pre-sign coefficients are read from active `MP_LCOEFS(0:NC-1,SQSO,ID)`; NRS wire coefficients apply the odd-degree sign once. Backend9 receives no numerator argument at its native tensor API, so its WIRE record denotes the subsequent unchanged canonical contraction vector, not a tensor-API numerator.

The frozen process has N<=4 and rank<=2, hence NC<=15. Module procedures provide explicit interfaces for all trace calls. REAL(16), COMPLEX(16), INTEGER(PC_IK) extents match their TRANSFER word counts. The four actual wrapper WE arrays fit the recorder's limit of four. The existing fixed-format source recipe must retain its qualified 132-column limit; inherited long lines are unchanged.

## Recorder and failure handling

`matched_trace.f90:51–83` bounds each record and captures only input fields using integer TRANSFER. The 128-slot buffer exceeds the intended 52 native calls per worker. All padding is initialized, and the post-call temporary is reset before whole-buffer comparison. BEGIN/END use no native output tensor, Laurent coefficient, or R1 arguments. The recorder retains canonical numerator inputs even when native status fails; it never interprets failed outputs.

`candidate/CT_interface.f:2360–2372` calls the installed NRS evaluator, immediately obtains the existing same-thread error buffer, snapshots input words, and returns on nonzero native status before reading NRS_RES/R1. The C getter binding matches the installed `size_t` and `char*` ABI. Its required length includes the terminator; the recorder retains required/copied/truncated fields and up to 8192 bytes. A status-1 empty message is legitimate for this installed bridge and must not be fabricated into an explanation. The overflow sentinel is retained by the current pure parser and blocks native qualification.

`candidate/TIRUST_interface.f:680–690` similarly records input/status immediately and returns on nonzero status before reading RAW. The driver retains the earlier outer amplitude/status/bit files separately; that existing evidence path is not part of the new input recorder. New per-native records flush only after each outer call returns. An incomplete outer call can therefore leave buffered evidence absent, which cannot prove that its native calls never began.

## Remaining qualification limits

No compiler lowering, binary ABI integration, runtime provider closure, actual call ordering, or floating-point neutrality has been tested here. Build dependencies must compile the existing support module before the new recorder, and the recorder before its consumers. Exact build/controller admission remains separate work.

The private8 and private9 output normalizations/contraction implementations remain different. Input equality and native success are separate from numerical correctness and do not qualify an amplitude comparison. Failed output coefficients remain opaque. Claims are limited to the frozen CMS routes, mode4, genuine QP integrands, full finite and pole settings, cache-off TIRust, and one worker per process; this review makes no mode2/5 or broader-process claim.
