#!/usr/bin/env python3
"""File-only authentication/preflight. No subprocess, compiler, loader or native imports."""
import argparse,hashlib,json
from pathlib import Path
import prepare
import matched_inputs
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
def require(ok,msg):
 if not ok: raise ValueError(msg)
def pin(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(path,expected):
 require(pin(path)=={k:expected[k] for k in ('bytes','sha256')},'Changed file: '+str(path))
def preflight(expected_index=None):
 if expected_index is not None:
  require(pin(HERE/'index.json')['sha256']==expected_index,'Source seal differs')
  index=json.loads((HERE/'index.json').read_bytes())
  for name,item in index['files'].items():
   require(not name.startswith('/') and '..' not in Path(name).parts,'Unsafe payload name')
   checked(HERE/name,item)
 bindings=json.loads((HERE/'bindings.json').read_bytes())
 for item in bindings['files'].values(): checked(ROOT/item['path'],item)
 products=prepare.products()
 for name,text in products.items(): require((HERE/name).read_text()==text,'Derived source differs: '+name)
 source_contract=matched_inputs.verify_source_contract(ROOT)
 routing=json.loads((ROOT/bindings['files']['source_routing']['path']).read_bytes())
 reductions=next(iter(routing['cases'].values()))['reductions']
 routes={str(r['reduction_identifier']):{'n':len(r['corner_wavefunctions']),'rank':r['rank'],'sqso':1,\
  'nw':sum(map(len,r['corner_wavefunctions'])),'we':[w for c in r['corner_wavefunctions'] for w in c],\
  'pairing':list(map(len,r['corner_wavefunctions']))} for r in reductions}
 require(json.loads((HERE/'expected-routes.json').read_bytes())==routes,'Source-bound routes differ')
 matched_inputs._routes({int(k):v for k,v in routes.items()})
 for name in ('cms-param_card.dat','cms-point1.dat','cms-point20.dat'):
  checked(HERE/'inputs'/name,pin(prepare.REF/'inputs'/name))
 plan=json.loads((HERE/'validation-plan.json').read_bytes())
 require(plan['native_admitted'] is False and plan['current_scope'].startswith('source-only'),'Native scope changed')
 require(plan['modes']==[4] and plan['outer_entries_max']==4,'Outer mode/count scope changed')
 require([r['backend'] for r in plan['requests']]==[8,9],'Worker order changed')
 for r in plan['requests']:
  require(r['bootstrap_point']==1 and r['measurement_point']==20 and r['requested_mode']==4,'Worker points/mode changed')
  require(r['bootstrap_outer_calls']==r['measurement_outer_calls']==1,'Worker outer count changed')
 require(plan['build']['compile_targets']==['check_sa.o','CT_interface.o','TIRUST_interface.o','matched_trace.o'],'Compile target scope changed')
 return {'schema':'private-matched-input-source-preflight-v1','passed':True,'sealed_index':expected_index,\
  'bound_files':len(bindings['files']),'generated_products':len(products),'routes':len(routes),\
  'source_contract_pins':source_contract,'native_actions':0,'native_controller_present':False,\
  'compiled':False,'physics_evaluated':False,'accuracy_qualified':False}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reviewed-source-index');a=p.parse_args()
 print(json.dumps(preflight(a.reviewed_source_index),indent=2,sort_keys=True))
if __name__=='__main__':main()
