"""Actual-file only admission regressions; no loader/compile/control processes."""
import copy,json,unittest
from unittest import mock
from pathlib import Path
import verify
H=Path(__file__).resolve().parent
class Preflight(unittest.TestCase):
 def test_actual_source_preflight_has_no_native_capability(self):
  result=verify.preflight()
  self.assertTrue(result['passed']);self.assertEqual(result['native_actions'],0)
  self.assertEqual(result['routes'],26);self.assertFalse(result['native_controller_present'])
 def test_changed_external_input_fails_before_parse(self):
  original=verify.pin
  def changed(path):
   result=original(path)
   if str(path).endswith('HEPTools/ninjars/include/mninjars.f90'):
    result=dict(result,sha256='0'*64)
   return result
  with mock.patch.object(verify,'pin',side_effect=changed):
   with self.assertRaisesRegex(ValueError,'Changed file'):verify.preflight()
 def test_build_gate_contains_no_fortran_main(self):
  plan=json.loads((H/'validation-plan.json').read_bytes())
  self.assertFalse(plan['native_admitted'])
  self.assertEqual(plan['build']['fortran_main_calls'],0)
  self.assertEqual(plan['build']['scientific_library_rebuilds'],0)
  self.assertEqual(plan['build']['loader_queries'],1)
  self.assertEqual(plan['build']['compile_targets'],['check_sa.o','CT_interface.o','TIRUST_interface.o','matched_trace.o'])
 def test_bounded_run_and_preserved_cards(self):
  plan=json.loads((H/'validation-plan.json').read_bytes())
  self.assertEqual([x['backend'] for x in plan['requests']],[8,9])
  self.assertEqual(sum(x['bootstrap_outer_calls']+x['measurement_outer_calls'] for x in plan['requests']),4)
  c8=(H/'backend8-mode4-MadLoopParams.dat').read_text()
  c9=(H/'backend9-mode4-MadLoopParams.dat').read_text()
  self.assertEqual(c8.replace('#MLReductionLib\n8\n','#MLReductionLib\n9\n'),c9)
 def test_parser_accepts_complete_bounded_log_budget(self):
  # 128 calls with 8192 three-digit byte values plus every largest word/meta record.
  worst_error=128*8192*4
  worst_words=128*(16+16+8+1+30+30)*33
  conservative_meta=128*200*12
  self.assertLess(worst_error+worst_words+conservative_meta,verify.matched_inputs.MAX_BYTES)
  self.assertLess(verify.matched_inputs.MAX_BYTES,64*1024**2)
if __name__=='__main__':unittest.main()
