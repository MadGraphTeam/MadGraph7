"""Pure, bounded CMS1/CMS20 matched-input decoder. No output coefficients.

Words remain exact IEEE128 encodings; geometry is never rotated, sorted,
reconstructed or normalized. Caller/point provenance belongs to the sealed
controller. A matching token alone does not establish the producer contract.
"""
import hashlib
import math
from pathlib import Path
import re

CALL_FIELDS=('seq','phase','backend','mode','group','sqso','n','rank','nc',
             'width','digits','status','complete','unchanged')
WORD_TAGS=('SHIFT','INV','MASS','SCALE','CANON','WIRE')
META_TAGS=('ROUTE','WE','PAIRING','CLASS','HAVE','PAIR','USE','CHORD','QERROR')
MAX_CALLS=128
MAX_BYTES=8*1024*1024
MAX_ERROR=8192
HEX=re.compile(r'[0-9A-F]{32}\Z')
INTEGER=re.compile(r'-?(?:0|[1-9][0-9]*)\Z')
# Closed CMS polynomial ordering: constant, four rank1, ten rank2 terms.
# Exact source proof is supplied by the controller's bound source packet.
DEGREES=(0,1,1,1,1,2,2,2,2,2,2,2,2,2,2)
SIGN=1<<127
CMS_ROUTES={i:{'n':n,'rank':rank,'sqso':1} for i,(n,rank) in enumerate((
    (3,2),(3,2),(4,2),(4,2),(4,2),(4,2),(4,2),(4,2),(2,0),(3,2),(3,2),(4,2),
    (4,2),(1,0),(2,2),(1,0),(1,0),(2,2),(1,0),(3,2),(3,2),(3,2),(3,2),(4,2),
    (2,2),(2,2)),1)}
SOURCE_PINS={
    '.tirust-build/kinematic-invariant-amplitude-proposal-2/index.json':
        'ccbb3dff88f673043251dac5d5099d184f709fdffdba1e5f2c3c1dc0aca37a74',
    '.tirust-build/kinematic-invariant-amplitude-proposal-2/candidate/TIR_interface.f':
        '493c967fd6c8eec19bf5c8bf5642c2d9f08da67c878b3e2f694fd254df9f0cf3',
    '.tirust-build/kinematic-invariant-amplitude-proposal-2/candidate/loop_CT_calls_1.f':
        'a9405b6b94ce63ab2b1da3af652754f2c8bf660c340c483878ed8fe2ecee2a6b',
    '.tirust-build/kinematic-invariant-amplitude-proposal-2/dependencies/caller_bounds.f90':
        'a0f941fc4ea7904bfd1e81880239637ad42e676f3a57ac47879f357a1241f71e',
    '.tirust-build/kinematic-provenance-current-executor-1/work/exports/cms/SubProcesses/P0_epem_mupmum/polynomial.f':
        '2c56aa11e489dae7823b0d0ecf113362dd1fefa810324749d4516c78a9f1b2cf',
}


def require(condition,message):
    if not condition:
        raise ValueError(message)


def integers(fields):
    require(all(INTEGER.fullmatch(x) and len(x)<=20 for x in fields),'Malformed integer')
    return [int(x) for x in fields]


def verify_source_contract(root):
    """File-only authentication of the retained route/rank/token source proof."""
    result={}
    for path,expected in SOURCE_PINS.items():
        raw=(Path(root)/path).read_bytes();sha=hashlib.sha256(raw).hexdigest()
        require(sha==expected,'Bound source changed: '+path)
        result[path]={'bytes':len(raw),'sha256':sha}
    return result


def _routes(routes):
    require(set(routes)==set(range(1,27)),'Expected source-bound groups1..26')
    for group,row in routes.items():
        require(set(row)=={'n','rank','sqso','nw','we','pairing'},'Expected route schema differs')
        require(all(type(row[k]) is int for k in ('n','rank','sqso','nw')),'Route fields must be integers')
        require(1<=row['n']<=4 and 0<=row['rank']<=2 and row['sqso']==1,
                'Unsupported CMS route')
        require(type(row['we']) is list and type(row['pairing']) is list,'Expected routing arrays must be lists')
        require(1<=row['nw']<=4 and len(row['we'])==row['nw'] and len(row['pairing'])==row['n'],
                'Expected routing array shape differs')
        require(all(type(x) is int for x in row['we']+row['pairing']),'Expected routing indices differ')
        require({k:row[k] for k in ('n','rank','sqso')}==CMS_ROUTES[group],
                'Routes differ from the retained CMS source proof')
    require(routes[3]['n']==4,'CMS group3 must have four propagators')


def environment_valid(word):
    """Mirror only the pinned read-only token predicate, not producer proof."""
    if not HEX.fullmatch(word):
        return False
    token=int(word,16)
    if token>>64 or token & 0xFFFFFFFF00000000 != 0x4B45000000000000:
        return False
    csr=(token>>16)&0xFFFF;cw=token&0xFFFF
    return (csr&0x003F==0 and cw&0xE0C0==0 and csr&0xE040==0 and
            cw&0x0C00==0 and cw&0x0300==0x0300)


def expected_wire(canonical,backend,nc):
    require(backend in (8,9) and nc in (1,5,15) and len(canonical)==2*nc,
            'Unsupported canonical numerator shape')
    return [f'{int(word,16) ^ (SIGN if backend==8 and DEGREES[i//2]%2 else 0):032X}'
            for i,word in enumerate(canonical)]


def parse_trace(text,backend,expected_routes):
    """Strict text schema; returns retained inputs even when native status fails.

    `expected_routes` must be independently hash-bound before this call. Error
    required counts include NUL for backend8; copied payload excludes it.
    Backend9 does not call that getter and emits required=copied=truncated=0.
    """
    require(type(text) is str and text.isascii(),'Trace is not ASCII text')
    require(len(text)<=MAX_BYTES,'Trace byte limit exceeded')
    require(backend in (8,9),'Unsupported native backend')
    _routes(expected_routes)
    calls=[];active=None;phase=None;phases=[];last_seq=0;seen=set()
    def finish():
        nonlocal active
        if active is None:
            return
        require(set(active['words'])==set(WORD_TAGS),'Incomplete word tags')
        require(set(active['meta'])==set(META_TAGS),'Incomplete metadata tags')
        require(active['meta']['ROUTE'][0]==len(active['meta']['WE']),'Runtime WE count differs from NW')
        require('environment' in active and 'error' in active,'Incomplete call record')
        calls.append(active);active=None
    for lineno,line in enumerate(text.splitlines(),1):
        require(line.strip(),f'Blank trace record at line{lineno}')
        fields=line.split();kind=fields[0]
        try:
            if kind=='MATCH_BEGIN':
                require(len(fields)==2 and phase is None and active is None,'Bad phase begin')
                value=integers(fields[1:])[0]
                require(value==len(phases) and value in (0,1),'Phase order differs')
                phase=value
            elif kind=='MATCH_CALL':
                require(phase is not None and len(fields)==15,'Call outside phase or wrong shape')
                finish()
                require(len(calls)<MAX_CALLS,'Call count limit exceeded')
                row=dict(zip(CALL_FIELDS,integers(fields[1:])))
                require(row['seq']==last_seq+1 and row['phase']==phase,'Sequence/phase differs')
                require(row['backend']==backend and (row['mode'],row['width'],row['digits'])==(4,128,113),
                        'Backend/mode/native precision differs')
                require(row['group'] in expected_routes,'Unexpected loop group')
                expected=expected_routes[row['group']]
                require(all(row[k]==expected[k] for k in ('n','rank','sqso')),'Route dimensions differ')
                require(row['nc']==math.comb(row['rank']+4,4),'Combinatorial numerator count differs')
                require(row['complete'] in (0,1) and row['unchanged'] in (0,1),'Malformed logical call flags')
                key=(phase,row['group'],row['sqso'],row['rank'],row['n'])
                require(key not in seen,'Duplicate call key')
                seen.add(key);last_seq=row['seq']
                active={**row,'key':list(key),'words':{},'meta':{}}
            elif kind=='MATCH_ENV':
                require(active is not None and len(fields)==4,'Environment record shape differs')
                require(integers(fields[1:2])[0]==active['seq'] and 'environment' not in active,
                        'Environment sequence or duplicate')
                require(all(HEX.fullmatch(x) for x in fields[2:]),'Malformed environment word')
                active['environment']=fields[2:]
            elif kind in ('MATCH_WORDS','MATCH_META'):
                require(active is not None and len(fields)>=4,'Array outside call or wrong shape')
                seq=integers(fields[1:2])[0];tag=fields[2];count=integers(fields[3:4])[0]
                require(seq==active['seq'],'Array sequence differs')
                n=active['n'];nc=active['nc']
                sizes={'SHIFT':4*n,'INV':n*n,'MASS':2*n,'SCALE':1,'CANON':2*nc,'WIRE':2*nc} if kind=='MATCH_WORDS' else {
                    'ROUTE':3,'WE':count,'PAIRING':n,'CLASS':n*n,'HAVE':n,'PAIR':n*n,
                    'USE':n*n,'CHORD':4*n,'QERROR':4*n*n}
                target=active['words' if kind=='MATCH_WORDS' else 'meta']
                require(tag in sizes and tag not in target,'Unexpected or duplicate array tag')
                require(count==sizes[tag] and len(fields)==count+4,'Array count differs')
                if kind=='MATCH_WORDS':
                    require(all(HEX.fullmatch(x) for x in fields[4:]),'Malformed input word')
                    target[tag]=fields[4:]
                else:
                    values=integers(fields[4:])
                    if tag in ('HAVE','PAIR','USE'):
                        require(all(x in (0,1) for x in values),'Malformed metadata logical')
                    if tag=='CLASS':
                        require(all(x in (0,1,2) for x in values),'Unknown class encoding')
                    if tag=='ROUTE':
                        require(1<=values[0]<=4 and all(x in (0,1) for x in values[1:]),'Malformed runtime route')
                    if tag=='WE':
                        require(1<=count<=4,'Runtime WE count exceeds bound')
                    target[tag]=values
            elif kind=='MATCH_ERROR':
                require(active is not None and len(fields)>=5,'Error record shape differs')
                seq,required,copied,truncated=integers(fields[1:5])
                require(seq==active['seq'] and 'error' not in active,'Error sequence or duplicate')
                require(required>=-1 and 0<=copied<=MAX_ERROR and truncated in (0,1),'Error bounds differ')
                require(len(fields)==5+copied,'Error payload count differs')
                payload=integers(fields[5:]);require(all(0<=x<=127 for x in payload),'Non-ASCII error byte')
                if backend==9:
                    require((required,copied,truncated)==(0,0,0),'Unexpected backend9 error getter record')
                elif required==-1:
                    require(truncated==1,'Unknown error length must be explicitly truncated')
                else:
                    require(required>=1 and copied<=required-1,'Error required count omits NUL')
                    require(truncated==int(required>MAX_ERROR+1 or copied!=required-1),'Error truncation flag differs')
                active['error']={'required':required,'copied':copied,'truncated':truncated,'bytes':payload}
            elif kind=='MATCH_END':
                require(phase is not None and len(fields)==3,'Bad phase end')
                require(integers(fields[1:])==[phase,last_seq],'Phase end sequence differs')
                finish()
                require({x['group'] for x in calls if x['phase']==phase}==set(expected_routes),
                        'Missing phase group coverage')
                phases.append(phase);phase=None
            else:
                raise ValueError('Unexpected trace record: '+kind)
        except (ValueError,KeyError) as exc:
            raise ValueError(f'Line{lineno}: {exc}') from exc
    require(phase is None and active is None and phases==[0,1],'Truncated trace phases')
    require(len(calls)==52,'Expected exactly52 native calls')
    return {'schema':'private-cms-matched-input-v1','backend':backend,'calls':calls,
            'source':{'bytes':len(text),'sha256':hashlib.sha256(text.encode('ascii')).hexdigest()},
            'phase_call_counts':[sum(x['phase']==p for x in calls) for p in (0,1)]}


def join_inputs(trace8,trace9,expected_routes,*,caller_binding_verified=False):
    """Compare two raw traces; no amplitudes, tensors, decimal or FP decoding."""
    parsed=[parse_trace(trace8,8,expected_routes),parse_trace(trace9,9,expected_routes)]
    indexed=[{tuple(x['key']):x for x in result['calls']} for result in parsed]
    mismatches=[];geometry_failures=[];status_failures=[];rows=[]
    for key,left in indexed[0].items():
        right=indexed[1][key];pair=(left,right);row_mismatch=[];row_geometry=[]
        if left['seq']!=right['seq']:
            row_mismatch.append({'field':'SEQ','backend8':left['seq'],'backend9':right['seq']})
        for tag in WORD_TAGS[:-1]:
            for index,(a,b) in enumerate(zip(left['words'][tag],right['words'][tag])):
                if a!=b:
                    row_mismatch.append({'field':tag,'index':index,'backend8':a,'backend9':b})
        for tag in META_TAGS:
            for index,(a,b) in enumerate(zip(left['meta'][tag],right['meta'][tag])):
                if a!=b:
                    row_mismatch.append({'field':tag,'index':index,'backend8':a,'backend9':b})
        if left['environment']!=right['environment']:
            row_mismatch.append({'field':'ENV','backend8':left['environment'],'backend9':right['environment']})
        for call in pair:
            backend=call['backend'];meta=call['meta'];n=call['n']
            expected=expected_routes[call['group']]
            if (meta['ROUTE']!=[expected['nw'],1,1] or meta['WE']!=expected['we'] or
                    meta['PAIRING']!=expected['pairing']):
                row_geometry.append({'backend':backend,'failure':'Runtime route or producer provenance differs'})
            if call['words']['WIRE']!=expected_wire(call['words']['CANON'],backend,call['nc']):
                row_mismatch.append({'field':'WIRE','backend':backend,'failure':'Canonical wire sign mapping differs'})
            if call['complete']!=1 or call['unchanged']!=1:
                row_geometry.append({'backend':backend,'failure':'Call capture incomplete or input arrays changed'})
            entry,use=call['environment']
            if entry!=use or not environment_valid(entry):
                row_geometry.append({'backend':backend,'failure':'Invalid or changed environment controls'})
            if not all(meta['HAVE']) or 0 in meta['CLASS']:
                row_geometry.append({'backend':backend,'failure':'Unknown caller/chord fallback'})
            for index,classification in enumerate(meta['CLASS']):
                i=index%n;j=index//n
                if (classification!=2 or i==j) and meta['USE'][index]:
                    row_geometry.append({'backend':backend,'index':index,'failure':'Protected row uses direct invariant'})
                if classification in (1,2) and i!=j and not meta['PAIR'][index]:
                    row_geometry.append({'backend':backend,'index':index,'failure':'Off-diagonal pair lacks certified bound'})
            if call['phase']==1 and call['group']==3:
                for index in (13,7): # (2,4)/(4,2), column-major N=4.
                    if (meta['CLASS'][index],meta['PAIR'][index],meta['USE'][index])!=(2,1,1):
                        row_geometry.append({'backend':backend,'index':index,'failure':'CMS20 critical pair used fallback'})
            if call['status']!=0 or call['error']['truncated']:
                status_failures.append({'key':list(key),'backend':backend,'status':call['status'],'error':call['error']})
        mismatches.extend({'key':list(key),**x} for x in row_mismatch)
        geometry_failures.extend({'key':list(key),**x} for x in row_geometry)
        rows.append({'key':list(key),'seq8':left['seq'],'seq9':right['seq'],
                     'exact_input_match':not row_mismatch,'certified_geometry_match':not row_geometry and not row_mismatch,
                     'status8':left['status'],'status9':right['status']})
    exact=not mismatches;geometry=exact and not geometry_failures;native=not status_failures
    require(type(caller_binding_verified) is bool,'Caller binding verification must be boolean')
    qualified=exact and geometry and caller_binding_verified
    return {'schema':'private-cms-matched-input-comparison-v1','parsed':parsed,'rows':rows,
            'exact_input_match':exact,'certified_geometry_match':geometry,
            'caller_binding_verified':caller_binding_verified,'qualified_input_match':qualified,
            'native_status_qualified':native,'native_input_gate_passed':qualified and native,
            'finite_comparison_admitted':False,'accuracy_qualified':False,
            'mismatches':mismatches,'geometry_failures':geometry_failures,'native_status_failures':status_failures,
            'limitations':['Caller/point/source provenance must be established by the sealed controller.',
                'Read-only token equality does not by itself establish the original momentum producer contract.',
                'No coefficient output is read; complete outer protocol, software flags and bootstrap control remain required.',
                'Input agreement and native success do not establish coefficient accuracy.']}
