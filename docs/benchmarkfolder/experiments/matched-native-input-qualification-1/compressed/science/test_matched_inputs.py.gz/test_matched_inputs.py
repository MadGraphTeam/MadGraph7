"""Pure synthetic matched-input tests; no reducer or native process is run."""
import copy
import json
import math
from pathlib import Path
import unittest
import matched_inputs as M

ENV=f'{0x4B4500001F80033F:032X}'
ONE=f'{0x3FFF<<112:032X}'
ZERO='0'*32
# Deliberately synthetic routing arrays. Real producer provenance is separately
# supplied by the source-bound controller; these fixtures do not qualify it.
ROUTES={group:{**row,'nw':row['n'],'we':list(range(1,row['n']+1)),
               'pairing':[1]*row['n']} for group,row in M.CMS_ROUTES.items()}


def synthetic_calls(backend):
    calls=[]
    for phase in (0,1):
        for group,route in ROUTES.items():
            n=route['n'];nc=math.comb(route['rank']+4,4)
            canonical=[f'{(0x3FFF<<112)+k:032X}' for k in range(2*nc)]
            # Include both signed zero components; unary sign transport must
            # preserve their exact sign bits rather than compare FP equality.
            if nc>1:
                canonical[2]=ZERO;canonical[3]=f'{M.SIGN:032X}'
            classification=[1 if i==j else 2 for j in range(n) for i in range(n)]
            pair=[int(i!=j) for j in range(n) for i in range(n)]
            use=[0]*(n*n)
            if phase==1 and group==3:
                use[13]=use[7]=1
            calls.append({'seq':len(calls)+1,'phase':phase,'backend':backend,'mode':4,'group':group,
                **route,'nc':nc,'width':128,'digits':113,'status':0,'complete':1,'unchanged':1,
                'environment':[ENV,ENV],
                'words':{'SHIFT':[f'{(0x3FFF<<112)+group*100+k:032X}' for k in range(4*n)],
                    'INV':[f'{(0x4000<<112)+group*100+k:032X}' for k in range(n*n)],
                    'MASS':[ONE,ZERO]*n,'SCALE':[ONE],'CANON':canonical,
                    'WIRE':M.expected_wire(canonical,backend,nc)},
                'meta':{'ROUTE':[route['nw'],1,1],'WE':route['we'][:],'PAIRING':route['pairing'][:],
                    'CLASS':classification,'HAVE':[1]*n,'PAIR':pair,'USE':use,
                    'CHORD':[-1000000]*(4*n),'QERROR':[-1000000]*(4*n*n)},
                'error':{'required':1 if backend==8 else 0,'copied':0,'truncated':0,'bytes':[]}})
    return calls


def render(calls):
    lines=[]
    for phase in (0,1):
        lines.append(f'MATCH_BEGIN {phase}')
        rows=[x for x in calls if x['phase']==phase]
        for call in rows:
            seq=call['seq']
            lines.append('MATCH_CALL '+' '.join(str(call[k]) for k in M.CALL_FIELDS))
            lines.append(f'MATCH_ENV {seq} '+' '.join(call['environment']))
            for tag in M.WORD_TAGS:
                words=call['words'][tag]
                lines.append(f'MATCH_WORDS {seq} {tag} {len(words)} '+' '.join(words))
            for tag in M.META_TAGS:
                values=call['meta'][tag]
                lines.append(f'MATCH_META {seq} {tag} {len(values)} '+' '.join(map(str,values)))
            error=call['error']
            lines.append(f'MATCH_ERROR {seq} {error["required"]} {error["copied"]} {error["truncated"]}'+
                         ((' '+' '.join(map(str,error['bytes']))) if error['bytes'] else ''))
        lines.append(f'MATCH_END {phase} {rows[-1]["seq"] if rows else 0}')
    return '\n'.join(lines)+'\n'


class MatchedInputs(unittest.TestCase):
    def setUp(self):
        self.left=synthetic_calls(8);self.right=synthetic_calls(9)

    def join(self,**kwargs):
        return M.join_inputs(render(self.left),render(self.right),ROUTES,**kwargs)

    def test_source_hashes_and_explicit_rank_map(self):
        root=Path(__file__).resolve().parents[2]
        self.assertEqual(len(M.verify_source_contract(root)),5)
        path=next(x for x in M.SOURCE_PINS if x.endswith('/polynomial.f'))
        source=(root/path).read_text()
        for line in ('DATA COEFTORANK_MAP(0:0)/1*0/',
                     'DATA COEFTORANK_MAP(1:4)/4*1/',
                     'DATA COEFTORANK_MAP(5:14)/10*2/'):
            self.assertIn(line,source)
        self.assertEqual([i for i,x in enumerate(M.DEGREES) if x%2],[1,2,3,4])

    def test_complete_match_preserves_all_words_and_separate_provenance_gate(self):
        result=self.join()
        self.assertTrue(result['exact_input_match']);self.assertTrue(result['certified_geometry_match'])
        self.assertTrue(result['native_status_qualified']);self.assertFalse(result['qualified_input_match'])
        qualified=self.join(caller_binding_verified=True)
        self.assertTrue(qualified['qualified_input_match']);self.assertTrue(qualified['native_input_gate_passed'])
        self.assertFalse(qualified['finite_comparison_admitted']);self.assertFalse(qualified['accuracy_qualified'])
        self.assertEqual(len(qualified['rows']),52)
        self.assertEqual(qualified['parsed'][0]['phase_call_counts'],[26,26])
        self.assertEqual(qualified['parsed'][0]['calls'][0]['words'],self.left[0]['words'])
        json.dumps(qualified,allow_nan=False)

    def test_failed_native_status_keeps_input_agreement(self):
        self.left[28]['status']=1
        self.left[28]['error']={'required':4,'copied':3,'truncated':0,'bytes':[98,97,100]}
        result=self.join(caller_binding_verified=True)
        self.assertTrue(result['exact_input_match']);self.assertTrue(result['qualified_input_match'])
        self.assertFalse(result['native_status_qualified']);self.assertFalse(result['native_input_gate_passed'])
        self.assertEqual(result['native_status_failures'][0]['error']['bytes'],[98,97,100])

    def test_missing_end_and_missing_tag_fail_closed(self):
        text=render(self.left)
        with self.assertRaisesRegex(ValueError,'Truncated trace'):
            M.parse_trace('\n'.join(text.splitlines()[:-1])+'\n',8,ROUTES)
        with self.assertRaisesRegex(ValueError,'Incomplete word tags'):
            M.parse_trace('\n'.join(x for x in text.splitlines() if not x.startswith('MATCH_WORDS 1 SCALE ')),8,ROUTES)

    def test_count_and_malformed_word_fail_closed(self):
        text=render(self.left)
        for bad,message in ((text.replace('MATCH_WORDS 1 SCALE 1','MATCH_WORDS 1 SCALE 2',1),'Array count'),
                            (text.replace('MATCH_WORDS 1 SCALE 1 '+ONE,'MATCH_WORDS 1 SCALE 1 '+ONE[:-1],1),'Malformed input word')):
            with self.assertRaisesRegex(ValueError,message):
                M.parse_trace(bad,8,ROUTES)

    def test_duplicate_call_and_missing_group_fail_closed(self):
        self.left[1]['group']=1
        with self.assertRaisesRegex(ValueError,'Duplicate call key'):
            M.parse_trace(render(self.left),8,ROUTES)
        self.left=synthetic_calls(8);self.left.pop(25)
        with self.assertRaisesRegex(ValueError,'Missing phase group coverage'):
            M.parse_trace(render(self.left),8,ROUTES)

    def test_q0_is_not_zeroed_or_rebased(self):
        self.right[0]['words']['SHIFT'][0]=ZERO
        result=self.join()
        self.assertFalse(result['exact_input_match'])
        self.assertEqual(result['mismatches'][0]['field'],'SHIFT')
        self.assertEqual(result['mismatches'][0]['index'],0)
        self.assertNotEqual(result['mismatches'][0]['backend8'],ZERO)

    def test_one_bit_scale_and_numerator_mismatches_are_not_tolerated(self):
        for tag in ('SCALE','CANON','INV','MASS'):
            with self.subTest(tag=tag):
                self.right=synthetic_calls(9)
                self.right[0]['words'][tag][0]=f'{int(self.right[0]["words"][tag][0],16)^1:032X}'
                if tag=='CANON':
                    self.right[0]['words']['WIRE']=self.right[0]['words']['CANON'][:]
                result=self.join()
                self.assertFalse(result['exact_input_match'])
                self.assertTrue(any(x['field']==tag for x in result['mismatches']))

    def test_wire_requires_sign_bit_only_on_odd_indices_including_signed_zero(self):
        expected=M.expected_wire(self.left[0]['words']['CANON'],8,15)
        self.assertEqual(expected[2],f'{M.SIGN:032X}');self.assertEqual(expected[3],ZERO)
        self.left[0]['words']['WIRE'][0]=f'{int(expected[0],16)^M.SIGN:032X}'
        result=self.join();self.assertFalse(result['exact_input_match'])
        self.assertTrue(any(x['field']=='WIRE' for x in result['mismatches']))

    def test_mode_width_digits_and_rank_count_fail_closed(self):
        for field,value,message in (('mode',1,'precision'),('width',64,'precision'),
                                    ('digits',53,'precision'),('nc',14,'numerator count')):
            with self.subTest(field=field):
                self.left=synthetic_calls(8);self.left[0][field]=value
                with self.assertRaisesRegex(ValueError,message):
                    M.parse_trace(render(self.left),8,ROUTES)

    def test_fallback_even_when_identical_does_not_qualify(self):
        for calls in (self.left,self.right):
            calls[0]['meta']['HAVE'][0]=0
            calls[0]['meta']['CLASS'][1]=0
        result=self.join(caller_binding_verified=True)
        self.assertTrue(result['exact_input_match']);self.assertFalse(result['certified_geometry_match'])
        self.assertFalse(result['qualified_input_match'])

    def test_composite_bounds_and_critical_cms20_bypass_required(self):
        for tag,index in (('PAIR',1),('USE',13)):
            with self.subTest(tag=tag):
                self.left=synthetic_calls(8);self.right=synthetic_calls(9)
                for calls in (self.left,self.right):
                    calls[28]['meta'][tag][index]=0
                result=self.join()
                self.assertTrue(result['exact_input_match']);self.assertFalse(result['certified_geometry_match'])

    def test_protected_use_forbidden_but_diagonal_pair_false_allowed(self):
        self.assertTrue(self.join()['certified_geometry_match'])
        for calls in (self.left,self.right):
            calls[0]['meta']['USE'][0]=1
        self.assertFalse(self.join()['certified_geometry_match'])

    def test_environment_control_validation_and_cross_backend_matching(self):
        for mask in (1<<22,1<<31,1<<29,1<<10,1<<8,1<<100):
            with self.subTest(mask=mask):
                self.left=synthetic_calls(8);self.right=synthetic_calls(9)
                bad=f'{int(ENV,16)^mask:032X}'
                for calls in (self.left,self.right):
                    calls[0]['environment']=[bad,bad]
                self.assertFalse(self.join()['certified_geometry_match'])
        self.left=synthetic_calls(8);self.right=synthetic_calls(9)
        self.right[0]['environment'][1]=f'{int(ENV,16)^1:032X}'
        result=self.join();self.assertFalse(result['exact_input_match']);self.assertFalse(result['certified_geometry_match'])

    def test_incomplete_or_changed_capture_cannot_qualify(self):
        for calls in (self.left,self.right):
            calls[0]['unchanged']=0
        result=self.join(caller_binding_verified=True)
        self.assertTrue(result['exact_input_match']);self.assertFalse(result['qualified_input_match'])

    def test_error_truncation_retained_and_payload_count_checked(self):
        self.left[0]['error']={'required':9000,'copied':3,'truncated':1,'bytes':[65,66,67]}
        result=self.join();self.assertTrue(result['exact_input_match']);self.assertFalse(result['native_status_qualified'])
        self.left[0]['error']['copied']=2
        with self.assertRaisesRegex(ValueError,'payload count'):
            M.parse_trace(render(self.left),8,ROUTES)

    def test_error_required_overflow_sentinel_retains_inputs_but_blocks_native_gate(self):
        self.left[0]['error']={'required':-1,'copied':3,'truncated':1,'bytes':[65,66,67]}
        result=self.join(caller_binding_verified=True)
        self.assertTrue(result['exact_input_match']);self.assertTrue(result['qualified_input_match'])
        self.assertFalse(result['native_status_qualified']);self.assertFalse(result['native_input_gate_passed'])
        self.assertEqual(result['native_status_failures'][0]['error']['required'],-1)
        self.left[0]['error']['truncated']=0
        with self.assertRaisesRegex(ValueError,'explicitly truncated'):
            M.parse_trace(render(self.left),8,ROUTES)
        self.left[0]['error']['required']=-2
        with self.assertRaisesRegex(ValueError,'Error bounds'):
            M.parse_trace(render(self.left),8,ROUTES)

    def test_call_join_does_not_hide_native_sequence_changes(self):
        self.right[0],self.right[1]=self.right[1],self.right[0]
        self.right[0]['seq']=1;self.right[1]['seq']=2
        result=self.join()
        self.assertFalse(result['exact_input_match'])
        self.assertEqual([x['field'] for x in result['mismatches']],['SEQ','SEQ'])

    def test_metadata_changes_and_unknown_records_fail_closed(self):
        self.right[0]['meta']['CHORD'][0]=-999999
        self.assertFalse(self.join()['exact_input_match'])
        with self.assertRaisesRegex(ValueError,'Unexpected trace record'):
            M.parse_trace(render(self.left)+'FINITE_OUTPUT 1\n',8,ROUTES)

    def test_expected_routes_cannot_be_redefined_from_trace(self):
        routes=copy.deepcopy(ROUTES);routes[1]['rank']=1
        with self.assertRaisesRegex(ValueError,'retained CMS source proof'):
            M.parse_trace(render(self.left),8,routes)

    def test_runtime_routing_and_producer_flags_must_match_expected(self):
        for tag,index,value in (('ROUTE',1,0),('ROUTE',2,0),('WE',0,8),('PAIRING',0,2)):
            with self.subTest(tag=tag,index=index):
                self.left=synthetic_calls(8);self.right=synthetic_calls(9)
                for calls in (self.left,self.right):
                    calls[0]['meta'][tag][index]=value
                result=self.join(caller_binding_verified=True)
                self.assertTrue(result['exact_input_match']);self.assertFalse(result['qualified_input_match'])

    def test_runtime_nw_and_we_count_must_agree(self):
        self.left[0]['meta']['ROUTE'][0]=2
        with self.assertRaisesRegex(ValueError,'WE count differs'):
            M.parse_trace(render(self.left),8,ROUTES)


if __name__=='__main__':
    unittest.main(verbosity=2)
