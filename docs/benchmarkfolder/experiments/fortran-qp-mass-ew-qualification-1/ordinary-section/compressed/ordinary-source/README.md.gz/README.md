# Dormant ordinary EW original9/candidate9 RUN

SOURCE ONLY. No driver, model, reducer, compiler, make, loader or installed
library is executed during preparation/default preflight/pure tests. Default
preflight reads retained source/card/point text only, with no live BUILD object,
executable or runtime-library hashes. Numerical execution requires a separate
root-reviewed exact source seal, closed BUILD gate and role admission.
Production, references, installed dependencies, public evidence and Git remain
unchanged. The genuine two-target protocol is a separate next packet; this
runner never changes its100-point stream or invokes the fixed-mode anchors.

## Exact prerequisites

Actual EW BUILD2 source `f245a106...` is closed at terminal `f7cac8b0...`,
result `60a99e60...`. Independent closed review `fa3e423b...` is pinned exactly,
including its path and retained receipt bytes. The571-file raw inventory
`c1e46e69...` binds all command/compile/link/policy/runtime reports. This owner
inventory alone is not independent review. The future root gate must name the
exact review and inventory and accept the closed build only.

Copy REVIEWED_BUILD_GATE.example.json to a fresh ignored path and set only
build_accepted/independent_review_accepted true after root review. The example
itself rejects execution. Source_qualified remains false: BUILD/compiler/ABI
proof does not manufacture physical accuracy or a numerical RUN admission.
The binder first authenticates this root gate, exact review and571 raw files,
then the passed terminal/result; only afterwards can it hash the actual closed
Fortran sources/objects/modules/archives, actual LOAD closure, ELF and15 runtime
providers. No compiler or generic ldd query is used during RUN.

Both actual21-object executables contain the unchanged qualified five-external-
leg full100 normal driver, source cf2816e4... . No driver source is rebuilt or
substituted. Its only requested command is EXACT1 after normal READY; the
provided ANCHOR/fixedCT and TIMED commands are never sent. This is the real
loop_qcd_qed_sm_Gmu e+e->ttbar+photon EW export, with the physical card891e4b89,
cache0 card97aaad78 and saved100 ordinary points56294e1d. No QCD87/13 cohort or
historical output is imported. TIRust/bridge/NinjaRS identities are unchanged.

## Isolated runtime and policy

Each role receives exactly16 regular static/card/resource files plus its
actual bound executable in a fresh work root. This excludes object/archive
clones and the298MB NinjaRS directory aliases. Cards/ident_card.dat is mandatory.
Retained actual source and startup-audit.json trace bare SETPARA, DP/MP LHA
getters and the actual MadLoop path resolver: parameter and identifier reads
resolve through ../../Cards; P0's ./MadLoop5_resources provides the numerical
card, color numerator/denominator and helicity configuration. Both resource
locations and all four numerical card copies remain exact. Missing companion
inputs are not assumed away. Learned filters start absent and are wholly owned
by normal MadLoop learning; no filters, readiness or IEEE state are restored.

Cards preserve singleton backend9, CTModeRun=-1, finite true, all UV/IR poles,
TIRustGlobalCache0, UseQPIntegrandForTIRust true and MLStabThres1e-6. The actual
compiled driver forces independent stability. It performs its original bootstrap
then normal full100 learning (possibly extra initialization calls), followed by
one final100 EXACT traversal. Returned DP/QP cohorts are discovered dynamically.
There is no requirement to observe QP: a DP-only EW ordinary run is useful
regression evidence but does not qualify the changed QP transport itself.

The collector retains every bootstrap/learning row, final Born/finite/simple/
double coefficients, accuracy/status words and actual accepted precision. It
requires complete100×(overall,one-order) coverage, finite results and checked
backend9 aliases with0<=accuracy<=1e-6. Overall and split-order rows duplicate
these physical coefficients. Candidate compares original9/candidate9 with the
unchanged3e-6 criterion and hard1e-8 target, including final and steady-learning
rows; accepted histories and observed final IEEE/software state must agree.
Every failed raw stream is retained; failure stops without retry.

## Protocol and limits

Both roles have separate root admissions: original first, candidate only with
its exact separately reviewed successful original terminal. Each role has600s
total including the original60s cleanup reserve,16GiB address space,512MiB per
file, core0, single-thread libraries, nonexclusiveCPU12 and the shared fail-if-
busy numerical mutex. The qualified absolute-end/handoff helper is unchanged;
environment reconstruction precedes handoff, and a raw Popen handle/identity
survives ownership-construction failure. No deadline extension or retry occurs.

The same qualified Worker FIFO/continuous stdout-drain implementation gains
retained messages and strict graceful STOP/BYE/exit handling: both buffered
and unread trailing FIFO bytes are refused. READY/EXACTED/STOP/BYE/exit are
retained; before/after final traversal maps bind the livePID/start/session/CPU,
actual ELF and initialized15-provider closure. Raw files and work directories
survive failed parse/protocol/numerical gates. Actual ROOT BUILD evidence and
critical live scientific/runtime bindings are checked again after evaluation.

Commands from the required repository with pinned Python:

```text
python3 -B .tirust-build/ew-qp-mass-ordinary-run-proposal-1/controller.py --source SOURCE_SHA
python3 -B .tirust-build/ew-qp-mass-ordinary-run-proposal-1/controller.py --source SOURCE_SHA --role original --build-gate ROOT_GATE_PATH --build-gate-sha ROOT_GATE_SHA --execute
python3 -B .tirust-build/ew-qp-mass-ordinary-run-proposal-1/controller.py --source SOURCE_SHA --role candidate --build-gate ROOT_GATE_PATH --build-gate-sha ROOT_GATE_SHA --reviewed-original ORIGINAL_TERMINAL_SHA --execute
```

The latter commands remain dormant until separate admissions. Work/report roots
are ew-qp-mass-ordinary-run-{work,execution}-1; source preflight creates neither.

The unchanged normal driver redirects final-traversal stdout to /dev/null;
its pre-READY learning diagnostics remain in worker.log. This runner therefore
claims observed public statuses/raw final IEEE/software states, not every
internal retry, genuine-QP constructor, consumed native input, canonical repaired
point or a warning-free final traversal. Actual readiness COMMON flags are not
newly instrumented in this unchanged ordinary driver. Target protocol will
observe those separately. No independent finite truth, stress/cache/target,
performance acceptance, source promotion or complete-delivery claim follows.
Hua-Sheng's precise local paired campaign remains a TODO.
