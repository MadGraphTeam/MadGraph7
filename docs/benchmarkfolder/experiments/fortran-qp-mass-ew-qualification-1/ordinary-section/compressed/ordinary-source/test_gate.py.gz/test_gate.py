"""Pure ordinary EW RUN contract tests; no actual driver or runtime is read."""
import builtins,ctypes,importlib.util,json,os,struct,subprocess,tempfile,types,unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import Mock,patch
HERE=Path(__file__).resolve().parent

def module(name):
    spec=importlib.util.spec_from_file_location('_test_ordinary_'+name,HERE/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
c=module('controller');collector=module('collector');compare=module('comparison');binding=module('binding');worker_module=module('worker')
def hexword(x):return struct.pack('>d',x).hex().upper()
def raw(code=219):
    words=' '.join(hexword(x) for x in (1.,2.,3.,4.,1e-10));exact=[];warm=['# learning'];ieee=[];soft=[]
    for k in range(101):
        p=1 if k==0 else k
        for order in (0,1):warm.append(f'{k} {p} {order} {0 if k==0 else code} 1 2 3 4 1e-10')
    for p in range(1,101):
        for order in (0,1):exact.append(f'{p} {order} {code} {words}')
        for phase in (1,2):ieee.append(' '.join(map(str,[p,phase,1]+[0]*10)));soft.append(f'{p} {phase} 0 0')
    return {'dimensions.dat':'1 1 1\n','warmup.dat':'\n'.join(warm)+'\n','exact-words.dat':'\n'.join(exact)+'\n','exact-ieee.dat':'\n'.join(ieee)+'\n','software-flags.dat':'\n'.join(soft)+'\n'}

class OrdinaryTests(unittest.TestCase):
    def test_real_default_preflight_blocks_effects_and_runtime_reads(self):
        c.SOURCE=c.digest(HERE/'source-index.json');attempts=[];real_import=builtins.__import__;real_open=builtins.open;real_path_open=Path.open
        def denied(*args,**kwargs):attempts.append('effect');raise AssertionError('Forbidden effect/runtime read')
        def forbidden(path):
            text=str(path);return '/ew-qp-mass-build-work-' in text or '/HEPTools/' in text or text.startswith('/nix/store/')
        def opened(path,mode='r',*args,**kwargs):
            if any(x in mode for x in 'wax+') or forbidden(path):return denied(path)
            return real_open(path,mode,*args,**kwargs)
        def path_open(path,mode='r',*args,**kwargs):
            if any(x in mode for x in 'wax+') or forbidden(path):return denied(path)
            return real_path_open(path,mode,*args,**kwargs)
        def imported(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','aloha','models','mg5decay','tirust_benchmark'}:return denied(name)
            return real_import(name,*args,**kwargs)
        with patch.object(subprocess,'Popen',side_effect=denied),patch.object(subprocess,'run',side_effect=denied),patch.object(os,'system',side_effect=denied),patch.object(os,'fork',side_effect=denied),patch.object(ctypes,'CDLL',side_effect=denied),patch.object(Path,'write_text',side_effect=denied),patch.object(Path,'write_bytes',side_effect=denied),patch.object(Path,'mkdir',side_effect=denied),patch.object(Path,'open',path_open),patch.object(builtins,'open',opened),patch.object(builtins,'__import__',imported):r=c.verify_source()
        self.assertEqual(attempts,[]);self.assertFalse(r['live_BUILD_or_runtime_files_read']);self.assertEqual(r['native_calls'],0)
    def test_DP_only_has_no_QP_requirement(self):
        lane=collector.collect(raw());r=collector.compare(lane,lane,compare.compare_rows);self.assertTrue(r['passed']);self.assertFalse(r['accepted_QP_observed_in_each_arm']);self.assertEqual(lane['cohort']['status_counts'],{'219':100})
    def test_QP_only_is_dynamically_collected(self):
        lane=collector.collect(raw(323));self.assertEqual(lane['cohort']['status_counts'],{'323':100});self.assertTrue(collector.compare(lane,lane,compare.compare_rows)['passed'])
    def test_unchecked_or_other_backend_status_rejected(self):
        for code in (120,328,218,420):
            with self.assertRaises(ValueError):collector.collect(raw(code))
    def test_nonfinite_or_excess_accuracy_rejected(self):
        for value in (float('nan'),float('inf'),-1.,2e-6):
            rows=raw();rows['exact-words.dat']=rows['exact-words.dat'].replace(hexword(1e-10),hexword(value))
            with self.assertRaises(ValueError):collector.collect(rows)
    def test_final_coverage_and_bootstrap_are_mandatory(self):
        for name in ('exact-words.dat','warmup.dat'):
            rows=raw();rows[name]='\n'.join(rows[name].splitlines()[2:])+'\n'
            with self.assertRaises(ValueError):collector.collect(rows)
    def test_hard_target_catches_small_finite_shift(self):
        left=collector.collect(raw());right=collector.collect(raw());right['rows'][0]['coefficients'][1]*=1+1e-7;r=collector.compare(left,right,compare.compare_rows)
        self.assertFalse(r['passed']);self.assertTrue(r['final']['regression']['passed']);self.assertFalse(r['final']['ordinary_target']['passed'])
    def test_history_IEEE_and_software_differences_fail(self):
        for name in ('history','ieee','software'):
            a=collector.collect(raw());b=collector.collect(raw())
            if name=='history':b['learning']['history'][0]['status']=139
            elif name=='ieee':b['ieee'][0][-1]=1
            else:b['software'][0][-1]=1
            self.assertFalse(collector.compare(a,b,compare.compare_rows)['passed'])
    def test_rejecting_example_BUILD_gate_stays_dormant(self):
        gate=c.read(HERE/'REVIEWED_BUILD_GATE.example.json')
        with self.assertRaises(ValueError):binding.accept_gate(gate,c.pins())
    def test_pure_gate_requires_exact_BUILD_and_raw_inventory(self):
        gate=c.read(HERE/'REVIEWED_BUILD_GATE.example.json');gate.update(build_accepted=True,independent_review_accepted=True);self.assertEqual(binding.accept_gate(gate,c.pins()),gate)
        gate['build_result_sha256']='b'*64
        with self.assertRaises(ValueError):binding.accept_gate(gate,c.pins())
    def test_actual17_runtime_copy_plan_contains_identifier_and_resources(self):
        p=c.pins();names=p['required_runtime_data_files'];self.assertEqual(len(names),16);self.assertIn('Cards/ident_card.dat',names);self.assertEqual(set(names),set(p['data_pins']['original']));self.assertEqual(p['data_pins']['original'],p['data_pins']['candidate']);self.assertEqual(len([n for n in names if n.endswith('MadLoopParams.dat')]),4)
    def test_source_driver_and_caps_frozen(self):
        self.assertEqual(c.pins()['driver']['sha256'],'cf2816e4d8ef9a176522f319ae44982e9f07c2003088daccab4313700c5b990b');self.assertEqual((c.CPU,c.CAP,c.CLEANUP),(12,600.,60.));self.assertEqual(len(c.pins()['required_process_sources']),21)
    def test_environment_is_reconstructed_without_tool_execution(self):
        env=c.environment('original');self.assertEqual(env['PYTHONHASHSEED'],'0');self.assertEqual(env['OMP_NUM_THREADS'],'1');self.assertEqual(env['LD_PRELOAD'],'');self.assertIn('/original/xdg/',env['XDG_CONFIG_HOME'])
    def test_strict_worker_accepts_BYE_and_zero_tail(self):
        w=worker_module.Worker.__new__(worker_module.Worker);w.closed=False;w.process=Mock(returncode=0);w.process.poll.return_value=None;w.timeout=1.;w.buffer=bytearray();w.protocol=[];w.fd=99;w._send=Mock();w._message=Mock(return_value=['BYE'])
        with patch.object(worker_module.os,'read',side_effect=BlockingIOError),patch.object(worker_module.base.Worker,'close') as close:w.close()
        w._send.assert_called_once_with('STOP 0 0');close.assert_called_once_with(graceful=False);self.assertEqual(w.protocol[-1]['trailing_bytes'],0)
    def test_strict_worker_rejects_buffered_or_unread_tail(self):
        for buffered in (True,False):
            w=worker_module.Worker.__new__(worker_module.Worker);w.closed=False;w.process=Mock(returncode=0);w.process.poll.return_value=None;w.timeout=1.;w.buffer=bytearray(b'junk' if buffered else b'');w.protocol=[];w.fd=99;w._send=Mock();w._message=Mock(return_value=['BYE'])
            reads=[BlockingIOError] if buffered else [b'junk',BlockingIOError]
            with patch.object(worker_module.os,'read',side_effect=reads),patch.object(worker_module.base.Worker,'close'):
                with self.assertRaises(worker_module.base.ProtocolError):w.close()
    def test_postPopen_owner_failure_retains_raw_cleanup(self):
        process=Mock(pid=123);record={'pid':123,'session':123,'process_group':123,'start_time_ticks':55};cleanup=Mock();cleanup.SignalRequests.side_effect=lambda:nullcontext(Mock());cleanup.identity.return_value=record;cleanup.OwnedChild.side_effect=RuntimeError('ownership failed');deadline=types.SimpleNamespace(end=1e30,handoff=False,deferred=False);owner=types.SimpleNamespace(StageDeadline=lambda *a,**k:nullcontext(deadline),raw_cleanup=Mock(return_value={'failure_only':True,'uncertainty_blocks_later_stages':True}))
        with tempfile.TemporaryDirectory() as temp:
            report=Path(temp)/'report'
            with patch.object(c,'REPORT',report),patch.object(c,'WORK',Path(temp)/'work'),patch.object(c,'SOURCE','sealed'),patch.object(c,'BUILD_GATE','.tirust-build/gate.json'),patch.object(c,'BUILD_GATE_SHA','c'*64),patch.object(c,'REVIEWED_ORIGINAL',None),patch.object(c,'local',side_effect=lambda name:cleanup if name=='process_cleanup' else owner),patch.object(c,'limits'),patch.object(c,'verify_source',return_value={}),patch.object(c,'reviewed_build',return_value={}),patch.object(c,'environment',return_value={}),patch.object(c,'tool',side_effect=lambda n:'/pinned/'+n),patch.object(subprocess,'Popen',return_value=process):
                with self.assertRaisesRegex(RuntimeError,'ownership failed'):c.supervise('original')
            owner.raw_cleanup.assert_called_once_with(process,record,cleanup,deadline.end);self.assertEqual(c.read(report/'original/terminal.json')['status'],'failed')
if __name__=='__main__':unittest.main(verbosity=2)
