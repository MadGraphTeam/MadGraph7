"""Reviewed closed-BUILD gate first; live binaries are read only afterwards."""
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROC='SubProcesses/P0_epem_ttxa'

def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):
    value=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):value.update(block)
    return value.hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def pins():return read(HERE/'input-pins.json')
def ignored(name):
    path=Path(name);require(not path.is_absolute() and '..' not in path.parts and str(path).startswith('.tirust-build/'),'Expected ignored relative path')
    full=ROOT/path;require(not full.is_symlink() and full.resolve().is_relative_to(ROOT/'.tirust-build'),'Ignored path escaped/aliased');return full

def accept_gate(gate,p):
    require(gate['schema']=='ew-qp-mass-closed-build-run-gate-v1' and gate['build_accepted'] is True and gate['independent_review_accepted'] is True,'Closed BUILD independent review not accepted')
    require(gate['source_qualified'] is False and gate['qualification_scope']=='closed-build-compiler-ABI-runtime-only','BUILD gate must not manufacture numerical/source qualification')
    for key,wanted in (('build_source_index_sha256',p['build_source']['source_index_sha256']),('build_terminal_sha256',p['closed_build']['terminal_sha256']),('build_result_sha256',p['closed_build']['result_sha256'])):require(gate[key]==wanted,'Wrong exact closed BUILD identity')
    require(gate['build_raw_inventory']==p['closed_build']['raw_inventory'],'Independent raw inventory identity changed')
    require(gate['independent_review']==p['independent_build_review'],'Exact independently closed BUILD review is required')
    return gate

def closed(gate_path,gate_sha):
    require(gate_path and gate_sha,'Separately reviewed closed BUILD gate required')
    path=ignored(gate_path);require(digest(path)==gate_sha,'Root BUILD gate bytes changed');p=pins();gate=accept_gate(read(path),p)
    review=ignored(gate['independent_review']['path']);require(digest(review)==gate['independent_review']['sha256'],'Independent review changed')
    raw=gate['build_raw_inventory'];rawpath=ignored(raw['path']);require(digest(rawpath)==raw['sha256'],'Closed raw BUILD inventory changed');inventory=read(rawpath)
    report=ignored(p['closed_build']['report']);require(inventory['base']==str(report) and inventory['build_terminal_sha256']==gate['build_terminal_sha256'] and inventory['build_result_sha256']==gate['build_result_sha256'],'Raw BUILD inventory scope changed')
    actual=set()
    for file in report.rglob('*'):
        require(not file.is_symlink(),'BUILD report alias forbidden')
        if file.is_file():actual.add(str(file.relative_to(report)))
    require(actual==set(inventory['files']),'Closed BUILD report inventory changed')
    for name,row in inventory['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe raw report name');require(ident(report/name)==row,'Closed raw BUILD evidence changed')
    require(digest(report/'terminal.json')==gate['build_terminal_sha256'] and digest(report/'result.json')==gate['build_result_sha256'],'Closed BUILD receipt changed')
    terminal=read(report/'terminal.json');result=read(report/'result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['result_sha256']==gate['build_result_sha256'],'BUILD failed or unresolved cleanup')
    require(result['status']=='passed' and result['stage']=='build' and result['source_index_sha256']==p['build_source']['source_index_sha256'] and set(result['variants'])=={'original','candidate'},'Wrong closed BUILD result')
    require(result['native_amplitude_calls']==result['model_probes']==result['reducer_calls']==0 and result['RUN_admitted'] is False,'BUILD result already includes scientific execution')
    return {'gate':gate,'result':result,'gate_sha256':gate_sha,'review_sha256':gate['independent_review']['sha256'],'raw_inventory_sha256':raw['sha256']}

def live_manifest(closed_build):
    p=pins();bindings={}
    def add(path,row):
        name=str(Path(path).resolve());value=row['sha256'] if isinstance(row,dict) else row
        require(name not in bindings or bindings[name]==value,'Conflicting live BUILD binding');bindings[name]=value
    for role,row in closed_build['result']['variants'].items():
        output=Path(row['output']);require(output==ROOT/'.tirust-build/ew-qp-mass-build-work-2/build'/role,'Unexpected actual BUILD output')
        require(row['sources'][PROC+'/check_sa.f']=={k:p['driver'][k] for k in ('bytes','sha256')},'Actual compiled normal driver source changed')
        require(set(row['compiled_process_sources'])==set(p['required_process_sources']) and len(row['process_objects'])==21,'Wrong process object closure')
        require(row['runtime']['files']==p['expected_runtime']['files'],'Actual15-provider closure changed')
        for field in ('sources','stock_objects','stock_modules','canonical_libraries','private_data','process_modules','process_objects'):
            for name,record in row[field].items():add(output/name,record)
        for path,value in row['actual_link_loads'].items():add(path,value)
        for path,value in row['runtime']['files'].items():add(path,value)
        add(output/PROC/'check',row['executable_sha256'])
        for name,wanted in p['data_pins'][role].items():require(row['private_data'][name]==wanted,'Compiled runtime card/resource identity changed')
    require(p['native_library_sha256'] in bindings.values(),'Pinned eb3 native library absent from actual bound closure')
    return bindings

def verify_live(bindings):
    for name,wanted in bindings.items():require(Path(name).is_file() and digest(name)==wanted,'Live closed BUILD/runtime input changed: '+name)
    return {'files':len(bindings),'digest':hashlib.sha256(json.dumps(bindings,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
