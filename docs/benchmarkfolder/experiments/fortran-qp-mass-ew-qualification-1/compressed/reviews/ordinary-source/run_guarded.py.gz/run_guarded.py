"""Independent pure tests/preflight/accepted-gate metadata checks only."""
import builtins
from contextlib import ExitStack
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import runpy
import signal
import socket
import subprocess
import sys
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];SOURCE=HERE.parent/'ew-qp-mass-ordinary-run-proposal-1'
SEAL='0c6792e4531a9da678f098f9b9ceb93479f21734c9c06e731316139a9f45cd41'
def main():
    kind=sys.argv[1];effects=[];original=builtins.__import__
    def denied(*a,**kw):effects.append(repr(a[:1]));raise AssertionError('Source review forbids native/process/network/resource/signal/mutex effects')
    def imports(name,*args,**kwargs):
        if name.split('.')[0] in {'madgraph','mg5decay','aloha','models','MadSpin','madmatrix','PLUGIN','tirust_benchmark'}:return denied(name)
        return original(name,*args,**kwargs)
    with ExitStack() as stack:
        for module,name in ((subprocess,'Popen'),(subprocess,'run'),(subprocess,'check_output'),(ctypes,'CDLL'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve'),(resource,'setrlimit'),(signal,'signal'),(signal,'setitimer'),(fcntl,'flock'),(socket,'socket'),(socket,'create_connection')):stack.enter_context(patch.object(module,name,side_effect=denied))
        stack.enter_context(patch.object(builtins,'__import__',side_effect=imports))
        if kind=='tests':sys.argv=[str(SOURCE/'test_gate.py')];runpy.run_path(str(SOURCE/'test_gate.py'),run_name='__main__')
        elif kind=='preflight':
            true_open=builtins.open;true_path_open=Path.open;reads=[]
            def blocked_path(path):
                value=str(path)
                return '/ew-qp-mass-build-work-' in value or '/HEPTools/' in value or value.startswith('/nix/store/')
            def opened(path,mode='r',*args,**kwargs):
                if any(c in mode for c in 'wax+') or blocked_path(path):return denied(path)
                reads.append(str(path));return true_open(path,mode,*args,**kwargs)
            def path_open(path,mode='r',*args,**kwargs):
                if any(c in mode for c in 'wax+') or blocked_path(path):return denied(path)
                reads.append(str(path));return true_path_open(path,mode,*args,**kwargs)
            with patch.object(Path,'open',path_open),patch.object(builtins,'open',opened):
                sys.argv=[str(SOURCE/'controller.py'),'--source',SEAL];runpy.run_path(str(SOURCE/'controller.py'),run_name='__main__')
            if any(blocked_path(p) for p in reads):raise AssertionError('Default preflight read live BUILD/runtime')
        elif kind=='accepted-gate':
            gate=ROOT/'.tirust-build/ew-qp-mass-root-reviewed-build-1.json';wanted='d19814faae3c2e5e6ae2235e2b7b87dbb25337021ff497cdec8bc7b204576ebf'
            if hashlib.sha256(gate.read_bytes()).hexdigest()!=wanted:raise ValueError('Root accepted gate changed')
            spec=importlib.util.spec_from_file_location('_ordinary_independent_binding',SOURCE/'binding.py');binding=importlib.util.module_from_spec(spec);spec.loader.exec_module(binding)
            closed=binding.closed('.tirust-build/ew-qp-mass-root-reviewed-build-1.json',wanted);manifest=binding.live_manifest(closed)
            # This is a metadata/source-binding shape check after root acceptance.
            # It does not hash/read the live object/ELF/provider bytes or invoke a loader.
            print(json.dumps({'root_gate_sha256':wanted,'gate_accepted':True,'source_qualified':closed['gate']['source_qualified'],'independent_review_sha256':closed['review_sha256'],'raw_inventory_sha256':closed['raw_inventory_sha256'],'live_manifest_bindings_derived_after_gate':len(manifest),'live_binary_hash_pass_performed':False,'native_calls':0,'effects_attempted':effects},sort_keys=True))
        else:raise ValueError('Unknown pure mode')
    if effects:raise AssertionError(effects)
if __name__=='__main__':main()
