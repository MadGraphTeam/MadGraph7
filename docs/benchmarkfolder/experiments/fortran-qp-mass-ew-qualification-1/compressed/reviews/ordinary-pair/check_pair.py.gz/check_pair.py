"""Independent file-only replay of the closed ordinary EW pair; never run science."""
import ast
import builtins
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import types

ROOT = Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust')
HERE = Path(__file__).resolve().parent
PROPOSAL = ROOT / '.tirust-build/ew-qp-mass-ordinary-run-proposal-1'
RUN = ROOT / '.tirust-build/ew-qp-mass-ordinary-run-execution-1'
PROC = 'SubProcesses/P0_epem_ttxa'
PINS = {
 'source': '0c6792e4531a9da678f098f9b9ceb93479f21734c9c06e731316139a9f45cd41',
 'source_review': '5993ed5bad1bf8b76fa66ed9d9cfb729357b47771ea70b5873bc343ca42719fd',
 'gate': 'd19814faae3c2e5e6ae2235e2b7b87dbb25337021ff497cdec8bc7b204576ebf',
 'build_review': 'fa3e423b60d76d840efe66376ec47d00b8ffb73642192f3504eb3bfcbbefa9be',
 'build_terminal': 'f7cac8b007f41e09964b95c9a0fb6172cb0f4eaa249ed3192188f9fa1af46b22',
 'build_result': '60a99e609b0aae3576c31f3f49cf6a250f21dfa1e7dbc670e95f4c49ac72d603',
 'build_inventory': 'c1e46e69465817ec0e43b6df490eeac8ec5d0d7fd96548ea4b36baf71edec82a',
 'original_terminal': '9663923d31ee9a87238aa564380c435dc3a81ab631649d9b604cfa05a4110173',
 'original_result': 'e9e8c7f35dacc0264157d9edf93d0d7b1c2654b924a169ce4b533e714f7eef30',
 'candidate_terminal': '0614cdc57afeb21551151e7ea53c2f5ff9e1a64700d08e0d5a86bbc00f3e3b60',
 'candidate_result': 'f1c3c7eaae4f7dc8175860637964073f94aadfcfc4a3db1c55ea093d2036a89e',
}
CHECKS = []
GUARDED = False
DENIED = []

def require(ok, message):
    if not ok:
        raise ValueError(message)

def check(ok, message):
    require(ok, message)
    CHECKS.append(message)

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def identity(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'nonregular/aliased input: ' + str(path))
    return {'bytes': path.stat().st_size, 'sha256': digest(path)}

def pin(path, expected):
    check(digest(path) == expected, 'exact pin: ' + str(Path(path).relative_to(ROOT)))

def guard(event, args):
    if not GUARDED:
        return
    bad = event.startswith(('subprocess.', 'ctypes.', 'socket.', 'os.exec', 'os.spawn', 'os.fork'))
    bad = bad or event in ('os.system', 'os.kill', 'os.killpg', 'os.posix_spawn', 'fcntl.flock', 'resource.setrlimit')
    bad = bad or event in ('os.remove', 'os.rename', 'os.rmdir', 'os.mkdir', 'os.chmod', 'os.symlink', 'os.link', 'os.truncate')
    if event == 'open':
        mode, flags = args[1:3]
        bad = bad or (isinstance(mode, str) and any(c in mode for c in 'wax+'))
        bad = bad or (isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
    if bad:
        DENIED.append(event)
        raise RuntimeError('file-only guard denied ' + event)

sys.addaudithook(guard)

def load_pure(name):
    path = PROPOSAL / (name + '.py')
    source = path.read_text()
    tree = ast.parse(source)
    allowed = {'collections', 'math', 're', 'struct', 'hashlib', 'json', 'pathlib'}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            require(all(n.name in allowed for n in node.names), 'unexpected pure import')
        elif isinstance(node, ast.ImportFrom):
            require(node.module in allowed, 'unexpected pure from import')
    module = types.ModuleType('independent_' + name)
    module.__file__ = str(path)
    exec(compile(tree, str(path), 'exec'), module.__dict__)
    return module

def rejected(call, label):
    try:
        call()
    except (ValueError, RuntimeError):
        CHECKS.append('rejects tamper/effect: ' + label)
    else:
        raise ValueError('accepted tamper/effect: ' + label)

def main():
    global GUARDED
    GUARDED = True
    index = read(PROPOSAL / 'source-index.json')
    pin(PROPOSAL / 'source-index.json', PINS['source'])
    for name, wanted in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe packet name')
        require(identity(PROPOSAL / name) == wanted, 'packet payload differs: ' + name)
    check(True, 'all frozen source packet payload identities and containment')
    points = (PROPOSAL / 'inputs/ordinary100.dat').read_text().splitlines()
    check(points[0] == '100' and len(points) == 501 and all(len(line.split()) == 4 and all(math.isfinite(float(v)) for v in line.split()) for line in points[1:]), 'frozen input contains100 physical five-leg points, not200 split-order points')
    pin(ROOT / '.tirust-build/ew-qp-mass-ordinary-run-source-independent-review-1/receipt.json', PINS['source_review'])
    pin(ROOT / '.tirust-build/ew-qp-mass-root-reviewed-build-1.json', PINS['gate'])
    pin(ROOT / '.tirust-build/ew-qp-mass-build-independent-review-2/receipt.json', PINS['build_review'])
    ip = read(PROPOSAL / 'input-pins.json')
    builddir = ROOT / ip['closed_build']['report']
    pin(builddir / 'terminal.json', PINS['build_terminal'])
    pin(builddir / 'result.json', PINS['build_result'])
    pin(ROOT / ip['closed_build']['raw_inventory']['path'], PINS['build_inventory'])
    br = read(builddir / 'result.json')
    collector, comparator, binding = (load_pure(n) for n in ('collector', 'comparison', 'binding'))
    gate = binding.accept_gate(read(ROOT / '.tirust-build/ew-qp-mass-root-reviewed-build-1.json'), ip)
    manifest = binding.live_manifest({'result': br})
    protected = {'files': len(manifest), 'digest': hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}
    check(protected == {'files': 1682, 'digest': 'd66279dcc06ff778e2e74c7762baf00b4b872b3645030c6783c4a03a30173009'}, 'accepted BUILD metadata reproduces exact protected1682 manifest without broad live rehash')
    sources_checked = 0
    providers_checked = 0
    for path, wanted in ip['expected_runtime']['files'].items():
        require(digest(path) == wanted, 'runtime provider changed')
        providers_checked += 1
    check(providers_checked == 15, '15 exact current runtime providers read as bytes only')
    collected = {}
    evidence = {}
    raw_counts = {}
    runtime_counts = {}
    for role in ('original', 'candidate'):
        where = RUN / role
        term, result = read(where / 'terminal.json'), read(where / 'result.json')
        pin(where / 'terminal.json', PINS[role + '_terminal'])
        pin(where / 'result.json', PINS[role + '_result'])
        require(term['status'] == result['status'] == 'passed' and term['returncode'] == 0, 'not closed successful pair')
        require(term['result_sha256'] == PINS[role + '_result'], 'terminal result mismatch')
        require(term['source_index_sha256'] == result['source_index_sha256'] == PINS['source'], 'run source changed')
        require(term['BUILD_gate_sha256'] == result['BUILD_gate_sha256'] == PINS['gate'], 'gate changed')
        for k, name in (('BUILD_independent_review_sha256', 'build_review'), ('BUILD_terminal_sha256', 'build_terminal'), ('BUILD_raw_inventory_sha256', 'build_inventory')):
            require(result[k] == PINS[name], 'closed BUILD binding changed')
        require(result['protected'] == protected, 'protected manifest mismatch')
        require(not term['cleanup']['events'] and not term['cleanup']['survivors'], 'cleanup unresolved')
        require(term['cpu'] == 12 and term['cpu_reservation'] is False and term['cap_seconds'] == 600 and term['cleanup_reserve_seconds'] == 60, 'ownership budget changed')
        require(term['deadline_monotonic'] == term['original_end_monotonic'], 'deadline reset')
        require(term['resource_limits'] == {'address_space_bytes': 17179869184, 'core_bytes': 0, 'file_bytes': 536870912}, 'resource policy changed')
        original = None if role == 'original' else PINS['original_terminal']
        require(term['reviewed_original'] == result['reviewed_original'] == original, 'exact original prerequisite changed')
        actual_files = {str(f.relative_to(where)) for f in where.rglob('*') if f.is_file()}
        require(not any(f.is_symlink() for f in where.rglob('*')), 'raw alias')
        require(actual_files == set(result['raw_files']) | {'terminal.json', 'result.json'}, 'raw inventory not complete')
        for name, wanted in result['raw_files'].items():
            require(not Path(name).is_absolute() and '..' not in Path(name).parts and digest(where / name) == wanted, 'raw evidence changed: ' + name)
        raw_counts[role] = len(result['raw_files'])
        raw = {name: (where / name).read_text() for name in ('dimensions.dat', 'exact-words.dat', 'warmup.dat', 'exact-ieee.dat', 'software-flags.dat')}
        lane = collector.collect(raw)
        require(lane == read(where / 'collected.json') == result['lane'], 'raw replay not exact')
        require(len(lane['rows']) == len(lane['learning']['rows']) == 200, 'returned row count')
        require(len(lane['learning']['history']) == 101 and len(lane['learning']['all_raw_records']) == 202, 'learning closure')
        require((lane['learning']['first_steady_call'], lane['learning']['last_steady_call']) == (1, 100), 'steady call window')
        for kind in ('rows',):
            for a, b in zip(lane[kind][::2], lane[kind][1::2], strict=True):
                require({k:v for k,v in a.items() if k != 'order'} == {k:v for k,v in b.items() if k != 'order'}, 'overall/soleorder not duplicates')
        require(lane['cohort']['status_counts'] == {'219': 100} and lane['cohort']['backend_precision_counts'] == {'9:DP': 100} and not lane['cohort']['accepted_QP_points'], 'derived cohort differs')
        for k, wanted in {'normal_CTModeRun':-1, 'LoopPoleMode':0, 'finite':True, 'UseQPIntegrandForTIRust':True, 'TIRust_caches':{'DP':0,'QP':0}, 'full100_learning':True, 'final_points':100, 'QP_cohort_required':False, 'historical_cohort_assumed':False, 'threshold':1e-6, 'forced_independent_stability':True, 'protocol_complete':True, 'performance_acceptance':False, 'source_promoted':False}.items():
            require(result[k] == wanted, 'normal policy changed: ' + k)
        before, after = read(where / 'maps-before.json'), read(where / 'maps-after.json')
        require({k:v for k,v in before.items() if k != 'raw_maps'} == {k:v for k,v in after.items() if k != 'raw_maps'}, 'worker identity/provider changed')
        command = read(where / 'worker-command.json')
        runtime = ROOT / '.tirust-build/ew-qp-mass-ordinary-run-work-1' / role
        exe = runtime / PROC / 'check'
        require(command['cwd'] == str(runtime / PROC), 'wrong cwd')
        require(command['argv'] == ['/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset', '-c', '12', str(exe), str(PROPOSAL / 'inputs/ordinary100.dat')], 'scientific argv changed')
        require(command['executable_sha256'] == br['variants'][role]['executable_sha256'] and command['driver_source_sha256'] == ip['driver']['sha256'], 'compiled executable/driver changed')
        expected = dict(ip['expected_runtime']['files']); expected[str(exe)] = command['executable_sha256']
        require(before['files'] == after['files'] == expected, 'not exact15providers+ELF')
        for maps in (before, after):
            paths = set()
            for line in maps['raw_maps'].splitlines():
                fields = line.split(maxsplit=5)
                if len(fields) == 6 and fields[5].startswith('/'):
                    require(not fields[5].endswith(' (deleted)'), 'deleted provider mapping')
                    paths.add(str(Path(fields[5]).resolve()))
            require(paths == set(expected), 'raw maps/path dictionary disagree')
            require(maps['parent_pid'] == term['pid'] and maps['affinity'] == [12] and maps['process_group'] == maps['session'] == maps['pid'], 'worker ownership/CPU changed')
            require(any(all(row[k] == maps[k] for k in ('pid', 'parent_pid', 'process_group', 'session', 'start_time_ticks')) for row in term['cleanup']['observed_owned_processes']), 'worker identity not cleanup-owned')
        for name, wanted in ip['data_pins'][role].items():
            require(identity(runtime / name) == wanted, 'private runtime data changed: ' + name)
        require(digest(exe) == command['executable_sha256'] and not exe.is_symlink(), 'runtime ELF changed')
        files = {str(f.relative_to(runtime)) for f in runtime.rglob('*') if f.is_file()}
        inputs = set(ip['data_pins'][role]) | {PROC + '/check'}
        generated = {PROC + '/' + name for name in (*raw.keys(), 'param.log')}
        startups = list((runtime / PROC / 'worker-raw').glob('*/startup'))
        require(len(startups) == 1, 'startup snapshot count changed')
        generated |= {str((startups[0] / name).relative_to(runtime)) for name in ('startup.json','dimensions.dat','warmup.dat')}
        require(files == inputs | generated and len(inputs) == 17 and not any(f.is_symlink() for f in runtime.rglob('*')), 'private runtime inventory changed')
        for name in raw:
            require((runtime / PROC / name).read_bytes() == (where / name).read_bytes(), 'runtime/raw output bytes disagree')
        for name in ('dimensions.dat','warmup.dat'):
            require((startups[0] / name).read_bytes() == (where / name).read_bytes(), 'startup/raw learning snapshot differs')
        require(read(startups[0] / 'startup.json') == {'error':None,'log':str(where/'worker.log')}, 'startup ownership/log changed')
        require(not (runtime / PROC / 'worker-protocol.fifo').exists(), 'protocol FIFO survives')
        runtime_counts[role] = {'immutable_inputs':len(inputs),'generated_outputs':len(generated),'total':len(files)}
        for name, wanted in ip['startup_sources'].items():
            require(identity(Path(br['variants'][role]['output']) / name) == {k:wanted[k] for k in ('bytes','sha256')}, 'critical startup source changed')
            sources_checked += 1
        for name in ip['required_process_sources']:
            path = Path(br['variants'][role]['output']) / PROC / name
            require(identity(path) == br['variants'][role]['sources'][PROC + '/' + name], 'compiled process source changed')
            sources_checked += 1
        protocol, ready = read(where / 'protocol.json'), read(where / 'ready.json')
        require(len(protocol) == 6 and protocol[0]['direction'] == 'receive' and protocol[0]['fields'][:6] == ['READY','1','100','1','1','1'], 'READY coverage changed')
        require(ready == {'cold_seconds':float(protocol[0]['fields'][6]),'nborn':1,'ndim':1,'nso':1,'points':100}, 'READY raw parse changed')
        require(protocol[1:] == [{'direction':'send','line':'EXACT 1 0'},{'direction':'receive','fields':['EXACTED','1']},{'direction':'send','line':'STOP 0 0'},{'direction':'receive','fields':['BYE']},{'direction':'exit','returncode':0,'trailing_bytes':0}], 'not exact graceful STOP/BYE/exit0/zero-tail')
        start, admission = read(where / 'started.json'), read(where / 'admission.json')
        for k, value in start.items():
            if k != 'status':
                require(term[k] == value, 'started/terminal join changed: ' + k)
        for k in ('BUILD_gate','BUILD_gate_sha256','cap_seconds','cleanup_reserve_seconds','cpu','cpu_reservation','deadline_monotonic','original_end_monotonic','resource_limits','reviewed_original','role','source_index_sha256'):
            require(admission[k] == term[k], 'admission/terminal join changed: ' + k)
        require(admission['status'] == start['status'] == 'running', 'start state differs')
        admitted = ['/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset','-c','12','/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3','-B',str(PROPOSAL/'controller.py'),'--source',PINS['source'],'--role',role,'--build-gate','.tirust-build/ew-qp-mass-root-reviewed-build-1.json','--build-gate-sha',PINS['gate'],'--child']
        if role == 'candidate':
            admitted += ['--reviewed-original',PINS['original_terminal']]
        require(admission['command'] == admitted, 'admitted controller argv changed')
        require(any(row['pid'] == term['pid'] and row['parent_pid'] == admission['parent_pid'] for row in term['cleanup']['observed_owned_processes']), 'controller parent not bound')
        for row in term['cleanup']['observed_owned_processes']:
            stat = Path('/proc') / str(row['pid']) / 'stat'
            if stat.exists():
                parts = stat.read_text().rsplit(')',1)[1].split()
                require(int(parts[19]) != row['start_time_ticks'] or int(parts[3]) != row['session'], 'owned PID identity still present')
        evidence[role] = {'terminal_sha256':PINS[role+'_terminal'],'result_sha256':PINS[role+'_result'],'worker_pid':before['pid'],'start_time_ticks':before['start_time_ticks'],'cpu':[12],'raw_inventory_files':raw_counts[role],'runtime_files':17,'provider_files':15,'protocol_records':6,'learning_calls':101,'raw_learning_rows':202,'steady_learning_rows':200,'physical_points':100,'returned_final_rows':200,'returned_coefficient_slots':800,'accuracy_word_slots':200,'accepted_DP_points':100,'accepted_QP_points':0,'max_final_accuracy':max(r['accuracy'] for r in lane['rows'])}
        collected[role] = lane
        check(True, role + ': exact raw replay, scientific argv/cards, process-start/maps/provider/ELF, graceful protocol, immutable critical source/runtime and cleanup joins')
    comparison = collector.compare(collected['original'], collected['candidate'], comparator.compare_rows)
    require(comparison == read(RUN / 'candidate/comparison.json') == read(RUN / 'candidate/result.json')['comparison'], 'comparison not reproduced')
    require(comparison['passed'] and not comparison['accepted_QP_observed_in_each_arm'], 'pair result differs')
    for phase in ('final','learning'):
        require(comparison[phase]['passed'] and not comparison[phase]['word_differences'] and not comparison[phase]['status_changes'], 'pair not word exact')
        for criterion in ('regression','ordinary_target'):
            require(comparison[phase][criterion]['passed'] and comparison[phase][criterion]['maximum_relative_error'] == 0 and len(comparison[phase][criterion]['residuals']) == 800, 'numerical parity not exact')
    check(comparison['learning_history_equal'] and comparison['observed_IEEE_equal'] and comparison['software_latches_equal'], 'exact final/steady-learning coefficient+accuracy words and status/learning/observed IEEE/software parity at3e-6 and1e-8')
    text = (RUN / 'original/exact-words.dat').read_text()
    rejected(lambda: collector.exact('\n'.join(text.splitlines()[:-1])), 'missing physical point/order')
    fields = text.splitlines()[0].split(); fields[2] = '339'
    rejected(lambda: collector.exact(' '.join(fields) + '\n' + '\n'.join(text.splitlines()[1:])), 'invented backend/precision alias')
    fields = text.splitlines()[0].split(); fields[3] = '7FF0000000000000'
    rejected(lambda: collector.exact(' '.join(fields) + '\n' + '\n'.join(text.splitlines()[1:])), 'nonfinite coefficient word')
    rejected(lambda: collector.ieee(''), 'missing IEEE traversal')
    rejected(lambda: collector.software('1 1 9 0'), 'invalid software latch')
    for event, args in (('subprocess.Popen', ('forbidden', [], None, None)), ('ctypes.dlopen', ('forbidden',)), ('os.kill', (0,0)), ('open', (str(HERE/'forbidden'), 'w', os.O_WRONLY|os.O_CREAT))):
        rejected(lambda e=event,a=args: sys.audit(e,*a), event)
    check(DENIED == ['subprocess.Popen','ctypes.dlopen','os.kill','open'], 'guarded replay denied4 effect probes and recorded zero non-probe effects')
    GUARDED = False
    output = {'schema':'ordinary-ew-closed-pair-independent-checks-v1','passed':True,'pins':PINS,'evidence':evidence,'checks':CHECKS,'checks_count':len(CHECKS),'protected_manifest_metadata':protected,'current_provider_files_hashed':providers_checked,'current_critical_source_files_hashed':sources_checked,'runtime_inventory_counts':runtime_counts,'effect_guard':{'unexpected_effects':0,'denied_probes':DENIED,'native_queries':0,'scientific_calls':0,'public_or_Git_writes':0},'comparison':{'final_coefficient_relative_max':0.0,'learning_coefficient_relative_max':0.0,'final_word_differences':0,'learning_word_differences':0,'accepted_QP_observed_in_each_arm':False},'scope':'Original9/candidate9 ordinary full100 DP regression only; no changed QP-mass/native-input/genuine-QP coverage, independent finite truth, internal retry/readiness/IEEE lowering proof, cache/performance acceptance, source promotion or broader numerical qualification.'}
    target = HERE / ('checks-optimized.json' if sys.flags.optimize else 'checks.json')
    target.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'passed':True,'checks':len(CHECKS),'output':str(target),'sha256':digest(target),'physical_points_per_arm':100,'accepted_DP_per_arm':100,'accepted_QP_per_arm':0}))

if __name__ == '__main__':
    main()
