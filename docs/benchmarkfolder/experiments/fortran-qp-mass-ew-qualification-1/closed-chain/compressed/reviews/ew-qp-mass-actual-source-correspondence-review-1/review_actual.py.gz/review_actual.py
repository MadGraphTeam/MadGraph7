"""Independent file-only actual EW source review; no GEN/BUILD/model execution."""
import builtins
from contextlib import ExitStack
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import signal
import socket
import subprocess
import sys
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
GEN=ROOT/'.tirust-build/ew-qp-mass-cli-generation-proposal-1';WORK=ROOT/'.tirust-build/ew-qp-mass-cli-generation-work-1';EXEC=ROOT/'.tirust-build/ew-qp-mass-cli-generation-execution-1'
HELPER=ROOT/'.tirust-build/ew-qp-mass-generated-source-review-proposal-2';HELPER_SHA='6d9407f27372ed45e5dc9b9a2ab672f638d273ea85ab1cc17ba85eb70924025e';GEN_SHA='6fb69ba7da6fe07e702047c211c04329be2003ea577f6bf1574eeb1dd210f917'
TERMINALS={'original':'026f54e26f163c6cacec3262ae9b6a27273e59447e9302038a12979be18761d9','candidate':'99085edcf65ba41297eb4f393efcb3070a6c10adff573dcfd65d59a0b2e4959d'}
RESULTS={'original':'f0c85c95311e1f73c0782a5f9e2ecec6d67a7861d704d27b4d7d4c0334750555','candidate':'2ed7b8ddb064c85163224ce0f3b41e17bca796ec2077ad6a13da398706a9f2ad'}
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rec(path):return json.loads(Path(path).read_text())
def check(path,row):
    path=Path(path)
    if row['sha256'] is None:
        require(row.get('link') is None and not path.exists() or path.is_symlink() and str(path.readlink())==row['link'],'Pinned source alias/absence changed: '+str(path));return
    require(path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'Pinned source changed: '+str(path))
def inventory(folder):
    suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
    return {str(p.relative_to(folder)):{'bytes':p.stat().st_size,'sha256':sha(p)} for subtree in ('Source','SubProcesses') for p in sorted((folder/subtree).rglob('*')) if p.is_file() and (p.suffix.lower() in suffixes or p.name.startswith('makefile') or p.name in ('make_opts','MadLoop_makefile_definitions'))}
def save(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
def main():
    effects=[];original_import=builtins.__import__
    def denied(*a,**kw):effects.append(repr(a[:1]));raise AssertionError('Independent actual-source review forbids effects')
    def imports(name,*args,**kwargs):
        if name.split('.')[0] in {'madgraph','mg5decay','aloha','MadSpin','madmatrix','PLUGIN'}:return denied(name)
        return original_import(name,*args,**kwargs)
    with ExitStack() as outer:
        for module,name in ((subprocess,'Popen'),(subprocess,'run'),(subprocess,'check_output'),(ctypes,'CDLL'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve'),(resource,'setrlimit'),(signal,'signal'),(signal,'setitimer'),(fcntl,'flock'),(socket,'socket'),(socket,'create_connection')):outer.enter_context(patch.object(module,name,side_effect=denied))
        outer.enter_context(patch.object(builtins,'__import__',side_effect=imports))
        require(sha(GEN/'source-index.json')==GEN_SHA and sha(HELPER/'source-index.json')==HELPER_SHA,'Source seals changed')
        gp=rec(GEN/'input-pins.json');parent=Path(gp['parent']['directory']);pp=rec(parent/'input-pins.json');tools=rec(parent/'toolchain-pins.json')
        require(sha(parent/'source-index.json')==gp['parent']['source_index_sha256'],'Parent GEN source seal changed')
        for folder in (GEN,HELPER,parent):
            index=rec(folder/'source-index.json')
            for name,row in index['files'].items():check(folder/name,row)
        data={};inv={};provenance={};aliases={}
        for role in ('original','candidate'):
            report=EXEC/role;base=WORK/role;mg=base/'mg';output=base/'output/ew_n3_epem_ttxa'
            require(sha(report/'terminal.json')==TERMINALS[role] and sha(report/'result.json')==RESULTS[role],'Closed GEN receipt changed')
            terminal=rec(report/'terminal.json');result=rec(report/'result.json');staging=rec(report/'staging.json')
            require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['result_sha256']==RESULTS[role],'GEN not closed')
            require(result['status']=='generated_pending_source_review' and result['source_index_sha256']==GEN_SHA and result['role']==role and result['source_commit']==gp['production_commit'],'GEN role/source changed')
            require(result['overlaid_candidate']==(role=='candidate') and result['actual_CLI_invocations']==1 and result['amplitude_evaluations']==0 and not result['BUILD_admitted'] and not result['RUN_admitted'],'GEN scope changed')
            require(sha(report/'generation.log')==result['generation_log_sha256'],'Closed CLI log changed')
            require(rec(report/'generation.command-terminal.json')['returncode']==0,'Stock CLI command failed')
            require(terminal['cap_seconds']==600 and terminal['cleanup_reserve_seconds']==60 and terminal['original_end_monotonic']==terminal['deadline_monotonic'],'GEN deadline changed')
            overlays=pp['overlay_files'] if role=='candidate' else {}
            for name,row in pp['source_files'].items():check(mg/name,overlays.get(name,row))
            for name,row in overlays.items():check(mg/name,row)
            for name,row in pp['bootstrap_files'].items():
                check(mg/name,row);raw=(mg/name).read_bytes();require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1'],'Bootstrap Git-blob mathematical identity changed')
            model=mg/'models/loop_qcd_qed_sm_Gmu'
            for name,row in gp['model']['files'].items():check(model/name,row)
            extra=[]
            for path in model.rglob('*'):
                require(not path.is_symlink(),'Model alias forbidden')
                if path.is_file() and str(path.relative_to(model)) not in gp['model']['files']:
                    name=str(path.relative_to(model));require(bool(re.fullmatch(r'py[0-9]+_model_[A-Za-z0-9_]+\.pkl',name)) or name=='loop_qcd_qed_sm_Gmu_debug.log' or (name.startswith('__pycache__/') and path.suffix=='.pyc'),'Unexpected model source/cache');extra.append(name)
            config=mg/'input/mg7_configuration.txt';require(sha(config)==staging['startup_configuration_sha256'],'Private configuration changed')
            settings={'auto_update':'0','automatic_html_opening':'False','nb_core':'1','fortran_compiler':tools['required_tools']['gfortran']['path'],'cpp_compiler':tools['required_tools']['g++']['path'],**pp['library_paths']}
            expected=(mg/'input/.mg7_configuration_default.txt').read_text()+'\n'+''.join(k+' = '+v+'\n' for k,v in settings.items());require(config.read_text()==expected,'Configuration not exact pinned overrides')
            for source,target in (('param_card.dat','param_card.dat'),('cache0.dat','MadLoopParams.dat')):
                check(output/'Cards'/target,gp['frozen_inputs'][source]);require(sha(output/'Cards'/target)==result['physical_card_sha256' if source=='param_card.dat' else 'numerical_card_sha256'],'Output card result join changed')
            for name,row in gp['frozen_inputs'].items():check(GEN/'inputs'/name,row)
            inv[role]=inventory(output);require(inv[role]==result['source_inventory'],'Full actual generated inventory changed')
            data[role]={name:(output/name).read_bytes() for name in inv[role]}
            aliases[role]={name:{'readlink':str((output/name).readlink()),'resolved':str((output/name).resolve()),'inside_output':(output/name).resolve().is_relative_to(output.resolve())} for name in inv[role] if (output/name).is_symlink()}
            require(all(row['inside_output'] for row in aliases[role].values()),'Generated source alias escapes output')
            require(not any((output/'SubProcesses').rglob('*.o')) and not any((output/'SubProcesses').rglob('check')),'Unexpected subprocess native build')
            provenance[role]={'terminal_sha256':TERMINALS[role],'result_sha256':RESULTS[role],'source_bindings':len(pp['source_files']),'bootstrap_bindings':len(pp['bootstrap_files']),'overlay_bindings':len(overlays),'model_source_bindings':len(gp['model']['files']),'configuration_sha256':sha(config),'physical_card_sha256':result['physical_card_sha256'],'numerical_card_sha256':result['numerical_card_sha256'],'source_commit':result['source_commit'],'overlaid_candidate':result['overlaid_candidate'],'generated_source_bindings':len(inv[role]),'MODEL_DHELAS_object_count_recorded_only':result['stock_Model_DHELAS_build_objects'],'allowed_generated_model_cache_files':extra,'cleanup_survivors':[]}
        require(rec(EXEC/'candidate/terminal.json')['reviewed_original']==TERMINALS['original'],'Separate original GEN review join changed')
        spec=importlib.util.spec_from_file_location('_actual_ew_review2',HELPER/'review.py');review=importlib.util.module_from_spec(spec);spec.loader.exec_module(review)
        with ExitStack() as pure:
            for name in ('open','read_bytes','read_text','write_bytes','write_text','stat','exists','resolve','glob','rglob','iterdir','is_file','is_dir'):pure.enter_context(patch.object(Path,name,side_effect=denied))
            report=review.analyze(data['original'],data['candidate'],'SubProcesses/'+gp['subprocess'])
        require(not effects,'Unexpected review effects')
        save(HERE/'source-inventories.json',inv);save(HERE/'provenance.json',{'GEN_source_index_sha256':GEN_SHA,'helper_source_index_sha256':HELPER_SHA,'roles':provenance,'source_aliases':aliases,'native_execution_in_this_review':False})
        save(HERE/'correspondence.json',report)
        changed=sorted(n for n in set(data['original'])&set(data['candidate']) if data['original'][n]!=data['candidate'][n]);identical=sorted(n for n in set(data['original'])&set(data['candidate']) if data['original'][n]==data['candidate'][n])
        summary={'helper2_source_index_sha256':HELPER_SHA,'GEN_source_index_sha256':GEN_SHA,'inventory_counts':{role:len(rows) for role,rows in inv.items()},'identical_source_bindings':len(identical),'changed_source_bindings':len(changed),'changed_files':changed,'added_sources':sorted(set(data['candidate'])-set(data['original'])),'missing_sources':sorted(set(data['original'])-set(data['candidate'])),'narrow_checks_passed':report['narrow_checks_passed'],'findings':report['findings'],'source_qualified':False,'BUILD_admitted':False,'actual_public_units':report.get('actual_public_units'),'actual_private_helpers':report.get('actual_private_helpers'),'original_reduction_calls':report.get('original_reduction_calls'),'actual_private_reduction_calls':report.get('actual_private_reduction_calls'),'verified_guarded_calls':report.get('verified_guarded_calls'),'verified_DP_MP_mass_pair_counts':report.get('verified_DP_MP_mass_pair_counts'),'declared_include_edges':len(report.get('include_edges',[])),'effect_attempts':effects}
        save(HERE/'summary.json',summary);print(json.dumps(summary,indent=2,sort_keys=True))
if __name__=='__main__':main()
