# Independent EW GEN source review

The sealed source is clear for separate root consideration of GEN admission.
This review admits neither role and supplies no generated-source or numerical
qualification. No CLI, compiler query/build, loader, model, reducer, project
runtime import, Git mutation or network operation was performed.

Both roles are constrained to stage the exact 0fcd scientific source. The original applies no
overlay; the candidate alone applies nine authenticated payloads: three changed
existing files, four identical existing files and two new templates. Both use
the qualified candidate dependency closure because production 0fcd includes
backend9. The starting 9228 performance baseline is not used as the original.

Each staged model is required to have exactly 175 declared regular sources. The observed
ambient py3_model_Feynman.pkl and model debug log are excluded before import;
postchecks permit only declared sources and narrowly named private generated
caches. Each stock CLI card has one exact EW model import, one requested
process, standalone output -nojpeg and quit. All set commands use --no_save.
Ordinary100, target2, physical and cache0 cards retain their exact hashes.

Private source/configuration/model/dependency checks are required around each GEN.
Both roots must be fresh and separate. The stock output may compile MODEL/DHELAS and
query compiler metadata as disclosed; no check/launch/install command occurs,
and unexpected subprocess objects or check executable fail. `Source/make_opts`
must retain all bytes except the exact compiler selector paths. Successful GEN
still ends generated_pending_source_review. Candidate requires the exact
separately reviewed successful original terminal; BUILD/RUN are absent.

The qualified ownership helper `51ca38f0…` is byte-identical. The original 600 s end
is carried into the deadline, with 60 s cleanup inside it, fixed 16 GiB / 512 MiB / core 0,
CPU 12 nonexclusive and fail-if-busy shared mutex. Environment reconstruction
finishes before handoff; the raw successful Popen handle/identity is retained
before ownership construction. Uncertainty cannot qualify a pass, and no retry
or deadline extension is provided.

Twelve guarded pure tests passed independently with normal Python and again
with -O. Their real preflight blocks external process/library calls, MG runtime
imports and writes; its attempted forbidden-effect count is zero. Other tests
use only mocked processes and temporary local fixtures. Both work/report roots
remain absent. No source blocker was found.

The inherited static import closure retains 129 visited files and 29 dynamic-site
limitations. Actual EW import/generation, generated legacy/helper/include
correspondence, expanded recipes, runtime inputs, independent accuracy and
performance must be qualified later. MAKE-internal children are not individually
journalled by this proposal; the full stock CLI command/log/exit is retained.
