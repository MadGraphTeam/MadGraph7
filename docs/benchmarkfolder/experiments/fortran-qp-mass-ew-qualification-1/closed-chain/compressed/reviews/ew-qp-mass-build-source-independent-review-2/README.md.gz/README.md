# Independent EW BUILD source2 review

The exact f245a106 source is clear for separate root consideration of BUILD
admission. Neither BUILD nor any later scientific stage is admitted by this
review. Root's b8e6be67 gate accepts generated-text correspondence only; its
source_qualified flag remains false. The actual compiler/include/module,
linker/runtime and ABI outcomes are pending the admitted BUILD.

All 21 payloads and the unchanged source1 predecessor authenticate. Source2
changes only controller namespace/containment plumbing, direct-os.open preflight
guards and matching tests/documentation. Driver, policy, include binder,
scientific inputs and compiler/dependency decisions match the predecessor.
Both closed stock GEN outputs have 427 source/build records, 344 byte-identical
support objects and four byte-identical support modules with source/producer
maps. Historical stock-GEN individual compiler argv are not invented; reuse is
limited to that closed source/environment/configuration/object provenance plus
the controller's required effective-recipe recapture. No blanket support
recompilation is needed for this declared scope.

The actual PROCESS family supplies 21 fresh units per role. Polynomial source
provides its own module and must precede all 11 other users. Current ISO_C_BINDING
uses are explicitly INTRINSIC. GNU IEEE module files and compiler closure are
pinned. Literal include case and search candidates are preserved; unbound,
different-content, recursive or unsupported dependency forms fail closed.
Every selected compile requires source/include/USE binding immediately before
execution, including the fresh polynomial module after its producing compile.
This is a source-workflow check, not a claim that those future bindings already
exist. The effective compiler helper preserves per-shared-source policy, including
the original polynomial O3 exception and unchanged link inputs plus map option.

Cloning preserves only the two exact NinjaRS aliases and their eight regular
leaves. All other aliases become private files; writes under shared aliases
are excluded. Explicit five canonical leaves avoid directory-rglob omissions.
The original wrapper archive, expected 23 MTIRUST definitions and nine candidate
private definitions remain required. Before linking, all inputs are prebound;
actual LOADs, ELF interpreter, static closure, interpreter-only provider list,
15 providers and unique symbols must subsequently agree. No main/model probe
or numerical executable is run by this BUILD protocol.

Namespace containment, fresh destinations, paired source-review path/hash,
qualified ownership helper 51ca38f0, original absolute 1800 s / 60 s cleanup reserve,
16 GiB / 512 MiB / core 0 limits and nonexclusive CPU 12 / shared mutex are explicit. Environment
construction precedes Popen handoff; its raw handle/identity is retained before
OwnedChild construction and uncertainty cannot qualify success. No retry or
RUN entry is supplied.

All 32 existing pure tests pass normally and under optimized Python. The real
root-gated preflight also passes with zero forbidden API attempts, no compiler,
make, loader, model or reducer invocation, and empty stderr. Work and execution
roots remain absent. No source blocker was found, and no public/Git edit occurred.
