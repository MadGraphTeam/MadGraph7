from pathlib import Path
from collections import Counter
import hashlib,json,types,sys
ROOT=Path.cwd();PACK=ROOT/'.tirust-build/ew-qp-mass-build-proposal-2';BUILD=ROOT/'.tirust-build/ew-qp-mass-build-execution-2/build';OUT=ROOT/'.tirust-build/ew-qp-mass-build-independent-review-2'
def require(x,m):
    if not x:raise ValueError(m)
def read(p):return json.loads(Path(p).read_text())
def ident(p):p=Path(p);return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
p=read(PACK/'input-pins.json');r=read(BUILD/'result.json');f=types.ModuleType('EW_closed_extra_compiler');source=ROOT/p['support_paths']['compiler'];exec(compile(source.read_bytes(),str(source),'exec'),f.__dict__)
calls=[]
def deny(*a,**k):calls.append(str(a));raise RuntimeError('No compiler query permitted')
f.subprocess=types.SimpleNamespace(check_output=deny,STDOUT=-2)
extra={}
for role,row in r['variants'].items():
    policy=row['compiler_flags'];require(policy['environment']=={},'Compiler injection')
    expected=p['reference_policy']['policy_classes'];cache={}
    for scope,records in policy['scopes'].items():
        require({tuple(x['flags']) for x in records['recipes'].values()}=={tuple(x) for x in expected[scope]},'Recorded GNU flags differ')
        for x in records['recipes'].values():
            require(len(x['compiler'])==1 and x['compiler'][0]['sha256']==read(PACK/'toolchain-pins.json')['required_tools']['gfortran']['sha256'],'Recorded compiler identity')
            cache[x['compiler'][0]['path']]=x['compiler'][0]
    case=Path(row['output'])/'SubProcesses/P0_epem_ttxa';env={'PATH':read(PACK/'toolchain-pins.json')['path']}
    for name,argv in row['selected_recipes']:
        parsed=f._compile_command(f.shlex.join(argv),case,env,cache)
        require(parsed[0]==name and parsed[1]==policy['scopes']['process']['recipes'][name],'Actual selected compile differs from its own effective recipe')
    for name,meta in row['stock_modules'].items():require(ident(Path(row['output'])/name)==meta,'Reused support module current hash')
    static=read(BUILD/role/'static-runtime.json');objects={x['path']:x for x in static['objects']};require(set(objects)==set(row['runtime']['files'])|{str(case/'check')},'Static object closure')
    needed=Counter((name,n) for name,obj in objects.items() for n in obj['needed']);actual=Counter((x['requester'],x['needed']) for x in static['resolutions']);require(needed==actual and sum(actual.values())==49,'Every actual NEEDED edge resolved')
    for edge in static['resolutions']:
        require(static['sonames'][edge['needed']]==edge['selected'] and edge['selected'] in row['runtime']['files'],'SONAME provider binding')
        if edge['reason'].startswith('first existing'):
            match=next((Path(d)/edge['needed'] for d in edge['search_paths'] if (Path(d)/edge['needed']).is_file()),None)
            require(match is not None and str(match.resolve())==edge['selected'] and str(match)==edge['spelling'],'First existing runtime candidate')
        else:require(edge['reason']=='already-loaded SONAME','Unexpected default/runtime cache lookup')
    require(all(obj['rpath'] is None for obj in objects.values()),'Unexpected RPATH')
    extra[role]={'actual_selected_argv_matches_per_source_policy':21,'policy_classes_equal_original':True,'reused_support_modules_current_hashes':4,'NEEDED_resolution_edges':49,'first_existing_and_already_loaded_bindings_valid':True}
require(not calls,'Compiler query attempted');(OUT/'policy-provider-checks.json').write_text(json.dumps({'passed':True,'roles':extra,'compiler_queries':0},indent=2,sort_keys=True)+'\n');print(json.dumps({'passed':True,'selected_argv_policy_matches':42,'support_modules_checked':8,'NEEDED_edges':98,'new_queries':0}))
