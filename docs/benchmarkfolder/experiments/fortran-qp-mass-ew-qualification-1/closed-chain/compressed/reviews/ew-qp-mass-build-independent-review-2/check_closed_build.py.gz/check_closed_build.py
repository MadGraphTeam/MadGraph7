from pathlib import Path
from collections import Counter
from contextlib import ExitStack
from unittest.mock import patch
import builtins, ctypes, fcntl, hashlib, importlib.util, json, os, re, resource, signal, socket, struct, subprocess, sys, types
ROOT=Path.cwd();PACK=ROOT/'.tirust-build/ew-qp-mass-build-proposal-2';BUILD=ROOT/'.tirust-build/ew-qp-mass-build-execution-2/build';OUT=ROOT/'.tirust-build/ew-qp-mass-build-independent-review-2'
def require(ok,m):
    if not ok:raise ValueError(m)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def module(name,path):
    path=Path(path);m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
pins=read(PACK/'input-pins.json');result=read(BUILD/'result.json');terminal=read(BUILD/'terminal.json');inventory=read(ROOT/'.tirust-build/ew-qp-mass-build-raw-inventory-2.json')
require(terminal['status']=='passed' and terminal['returncode']==0 and terminal['result_sha256']==sha(BUILD/'result.json') and not terminal['cleanup']['events'] and not terminal['cleanup']['survivors'],'Closed stage result/cleanup')
require(terminal['cap_seconds']==1800 and terminal['cleanup_reserve_seconds']==60 and terminal['resource_limits']=={'address_space_bytes':17179869184,'file_bytes':536870912,'core_bytes':0} and terminal['cpu']==12 and not terminal['cpu_reservation'],'Phase limits')
require(terminal['review_sha256']==result['source_review_admission_sha256']==sha(ROOT/terminal['review_path'])=='b8e6be67dc0b38da9b15a0df05c5ea1fb4bdf0a692970f6857c80881e71d18a9','Root source gate')
require(sha(ROOT/'.tirust-build/ew-qp-mass-build-source-independent-review-2/receipt.json')=='17dd53d024d276bca415d3ce891de4a5a0f9f5f2919b89a01004de2da4336494','Accepted source review drift')
require(len(inventory['files'])==571 and Path(inventory['base'])==BUILD,'Raw inventory shape')
for n,row in inventory['files'].items():
    require(not Path(n).is_absolute() and '..' not in Path(n).parts and ident(BUILD/n)==row,'Raw evidence changed '+n)
require({str(p.relative_to(BUILD)) for p in BUILD.rglob('*') if p.is_file()}==set(inventory['files']),'Raw inventory set')
require((BUILD/'console.log').stat().st_size==0,'Console failure output')
for n,h in {'source-index.json':'f245a10696fea62dad8a7bb116675ea43e09d5e3376686d3433bbc3f47d24f2f'}.items():require(sha(PACK/n)==h,'Source drift')
for n,row in read(PACK/'source-index.json')['files'].items():require(ident(PACK/n)==row,'Source payload drift')
D=module('ew_review_compile_inputs',PACK/'compile_inputs.py');P=module('ew_review_policy',PACK/'policy.py');T=module('ew_review_environment',PACK/'tool_environment.py');C=module('ew_review_clone',PACK/'cloning.py')
compiler_path=ROOT/pins['support_paths']['compiler'];require(ident(compiler_path)==pins['support_files'][str(compiler_path.relative_to(ROOT))],'Compiler helper drift');F=module('ew_review_compiler',compiler_path)
parser_path=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/unit_runtime.py';require(sha(parser_path)=='4552d6b3bcd8d37a11f2eba81f505e71769010314246c4382e20d15fd441b0b5','ELF parser drift');E=module('ew_review_ELF',parser_path)
toolchain=read(PACK/'toolchain-pins.json');env=T.reconstruct(toolchain,pins['compiler_environment_names'],{},pins['library_paths']);fc=toolchain['required_tools']['gfortran']['path']
effects=[]
def deny(*a,**k):effects.append(repr(a[:1]));raise RuntimeError('Independent file-only BUILD review effect guard')
real_import=builtins.__import__
def imported(name,*a,**k):
    if name.split('.')[0] in ('madgraph','models','mg5decay','aloha','MadSpin','PLUGIN'):return deny(name)
    return real_import(name,*a,**k)
def elf_symbols(blob):
    require(blob[:7]==b'\x7fELF\x02\x01\x01','ELF class')
    h=struct.unpack_from('<HHIQQQIHHHHHH',blob,16);require(h[1]==62 and h[10]==64,'ELF sections')
    sections=[struct.unpack_from('<IIQQQQIIQQ',blob,h[5]+i*h[10]) for i in range(h[11])];names=[]
    for sec in sections:
        if sec[1]!=2:continue
        strings=sections[sec[6]];text=blob[strings[4]:strings[4]+strings[5]];require(sec[9]==24,'ELF symbol size')
        for off in range(sec[4],sec[4]+sec[5],24):
            name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',blob,off)
            if index and name:
                end=text.find(b'\0',name);require(end>=name,'ELF symbol name');names.append(text[name:end].decode())
    return names
summaries={};all_commands={};policies={};checked_bound_files=set();direct_object_hashes=0;canonical_hashes=0;provider_cache={};alias_leaf_cache={};command_totals=Counter();policy_response_replays=0
with ExitStack() as blockers:
    blockers.enter_context(patch.object(builtins,'__import__',imported))
    for obj,names in ((subprocess,('Popen','run','call','check_call','check_output')),(ctypes,('CDLL','PyDLL')),(os,('system','popen','fork','execv','execve','kill','killpg','replace','rename','unlink','mkdir','makedirs')),(socket,('socket','create_connection')),(signal,('signal','setitimer','alarm')),(resource,('setrlimit',)),(fcntl,('flock',)),(Path,('write_text','write_bytes','mkdir','unlink','rename','replace','touch','chmod','symlink_to','hardlink_to'))):
        for n in names:
            if hasattr(obj,n):blockers.enter_context(patch.object(obj,n,side_effect=deny))
    for role in ('original','candidate'):
        row=result['variants'][role];accepted=pins['roles'][role];evidence=BUILD/role;output=Path(row['output']);case=output/'SubProcesses/P0_epem_ttxa'
        require(row['stock_objects']==accepted['stock_objects'] and row['stock_modules']==accepted['support_modules'] and len(row['stock_objects'])==344 and len(row['stock_modules'])==4,'Accepted stock support closure')
        require(row['canonical_libraries']==accepted['canonical_libraries'] and row['private_data']==accepted['data_files'],'Canonical or card metadata changed')
        expected_sources=dict(accepted['sources']);expected_sources['SubProcesses/P0_epem_ttxa/check_sa.f']=ident(PACK/'check_sa.f');original_makefile=Path(accepted['output'])/'SubProcesses/P0_epem_ttxa/makefile'
        raw=P.private_makefile(original_makefile.read_text()).encode();expected_sources['SubProcesses/P0_epem_ttxa/makefile']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        require(row['sources']==expected_sources and len(row['sources'])==427,'Expected only driver/map source changes')
        for n,meta in accepted['support_module_producers'].items():require(meta['object'] in row['stock_objects'] and meta['source'] in row['sources'],'Support module producer')
        require(C.links(output)=={n:{'readlink':v['canonical_target'],'resolved':v['canonical_target'],'directory':True} for n,v in accepted['shared_aliases'].items()},'Only exact NRS aliases')
        for n,alias in accepted['shared_aliases'].items():
            path=output/n;require(path.is_symlink() and str(path.readlink())==alias['canonical_target'] and path.resolve()==Path(alias['canonical_target']),'NRS alias target')
            entries={p.name:p for p in path.resolve().iterdir()};require(set(entries)==set(alias['leaves']),'NRS eight leaves')
            for leaf,meta in alias['leaves'].items():
                f=entries[leaf];require(f.is_file() and not f.is_symlink(),'Regular NRS leaf')
                if str(f) not in alias_leaf_cache:alias_leaf_cache[str(f)]=ident(f)
                require(alias_leaf_cache[str(f)]==meta,'NRS selected leaf identity')
        for n,meta in row['canonical_libraries'].items():require(ident(output/n)==meta,'Canonical selected library/module leaf');canonical_hashes+=1
        for n,meta in row['private_data'].items():require(ident(output/n)==meta,'Actual card/static data');
        commands={}
        for f in sorted((evidence/'commands').glob('*.command.json')):
            stem=f.name[:-len('.command.json')];cmd=read(f);term=read(f.with_name(stem+'.terminal.json'));stdout=f.with_name(stem+'.stdout.txt')
            require(term['returncode']==0 and sha(stdout)==term['stdout_sha256'],'Command return/stdout '+stem)
            if 'stderr_sha256' in term:require(sha(f.with_name(stem+'.stderr.txt'))==term['stderr_sha256'],'Policy stderr')
            category='compile' if stem.startswith('compile-') else 'policy' if stem.startswith('policy-') else 'prelink_query' if stem.startswith('prelink-query-') else stem
            require(category in {'compile','policy','prelink_query','link','expanded-check','actual-pt-interp-runtime','symbols'},'Unexpected command scope')
            command_totals[category]+=1;commands[stem]=cmd
        require(len(commands)==84,'Per-role command count');all_commands[role]=commands
        recipes,link=P.select_commands((evidence/'commands/expanded-check.stdout.txt').read_text(),fc,accepted['linked_sources'])
        require([[n,a] for n,a in recipes]==row['selected_recipes'] and link==row['link_command'],'Actual expanded/selected recipes')
        order={n:i for i,(n,a) in enumerate(recipes)};require(all(order['polynomial.f']<order[n] for n in accepted['polynomial_module_users']) and len(accepted['polynomial_module_users'])==11,'Polynomial before all users')
        module=case/'ml5_0_polynomial_constants.mod';require(ident(module)==row['process_modules']['SubProcesses/P0_epem_ttxa/ml5_0_polynomial_constants.mod'],'Fresh module result')
        generated={str(module.resolve()):ident(module)};compile_row={**accepted,'expected_build_sources':row['sources']};edge_counts=Counter()
        for i,(name,argv) in enumerate(recipes):
            command=commands[f'compile-{i:03d}-'+name];require(command['argv']==argv and command['cwd']==str(case) and command['controller_pid']==terminal['child_pid']==command['session']==command['process_group'] and not command['new_session'],'Compile command identity')
            bound=D.bind(case/name,argv,output,compile_row,pins,generated);recorded=read(evidence/'compile-inputs'/f'{i:03d}-{name}.json')
            require(bound==recorded==row['actual_compile_inputs'][i],'Actual include/USE/source provider replay '+name)
            checked_bound_files.update(bound['bound_files']);edge_counts.update(e['kind'] for e in bound['edges'])
            object_name='SubProcesses/P0_epem_ttxa/'+str(Path(name).with_suffix('.o'));require(ident(output/object_name)==row['process_objects'][object_name],'Fresh object binding');direct_object_hashes+=1
            expected_flags=['-w','-fPIC','-ffixed-line-length-132']+(['-O3'] if name=='polynomial.f' else [])
            actual_flags=F._compile_command(' '.join(argv),case,env,{}) if False else None
            require(('-O3' in argv)==(name=='polynomial.f'),'Original polynomial-only O3 policy')
        require(len(row['process_objects'])==21 and len(row['actual_compile_inputs'])==21 and len(row['process_modules'])==2,'Fresh selected compile/module count')
        require(set(p.name for p in case.glob('*.mod'))=={'mpmodule.mod','ml5_0_polynomial_constants.mod'},'No unbound process module output')
        for n,meta in row['process_modules'].items():require(ident(output/n)==meta,'Process module current binding')
        def replay_policy(label):
            nonlocal_dummy=None
            entries=[(stem,commands[stem]) for stem in sorted(commands) if stem.startswith(label+'-')];position=0
            def recorded(argv,**kwargs):
                nonlocal position
                require(position<len(entries),'Extra policy query attempted');stem,cmd=entries[position];position+=1
                require(list(map(str,argv))==cmd['argv'] and str(kwargs.get('cwd',case))==cmd['cwd'],'Recorded policy argv/cwd mismatch')
                return subprocess.CompletedProcess(argv,0,stdout=(evidence/'commands'/(stem+'.stdout.txt')).read_text(),stderr=(evidence/'commands'/(stem+'.stderr.txt')).read_text())
            def output(argv,**kwargs):return recorded(argv,**kwargs).stdout
            original=F.subprocess;F.subprocess=types.SimpleNamespace(run=recorded,check_output=output,PIPE=subprocess.PIPE,STDOUT=subprocess.STDOUT)
            try:value=F.capture_effective_flags(case,env=env)
            finally:F.subprocess=original
            require(position==len(entries)==4,'Not all policy responses consumed');return value,position
        before,n=replay_policy('policy-before');after,m=replay_policy('policy-after');policy_response_replays+=n+m
        require(after==row['compiler_flags'],'After-policy full raw replay');F.validate_compiler_equality(before,after);policies[role]=after
        pre=read(evidence/'prelink.json');require(sha(evidence/'prelink.json')==row['prelink_sha256'] and pre['completed_before_link'] and pre['command']==link and pre['cwd']==str(case),'Prelink metadata')
        mapfile=case/'private-link.map';require(sha(mapfile)==row['link_map_sha256'],'Actual link map digest');raw_loads=re.findall(r'^LOAD\s+(.+)$',mapfile.read_text(),re.M)
        loads={str((case/s).resolve()):pre['bound'][str((case/s).resolve())] for s in raw_loads};require(loads==row['actual_link_loads'] and len(loads)==54,'Actual54 LOAD/prebind exact set')
        runtime=row['runtime'];require(runtime['files']==pins['expected_runtime']['files'] and len(runtime['files'])==15,'Original15 runtime closure')
        static=read(evidence/'static-runtime.json');require(sha(evidence/'static-runtime.json')==row['static_runtime_sha256'] and static['files']==runtime['files'],'Static runtime receipt')
        for obj in static['objects']:
            if obj['path'] not in provider_cache:provider_cache[obj['path']]=E.describe(obj['path'])
            require(provider_cache[obj['path']]==obj,'Current pure ELF metadata differs')
        exe=case/'check';blob=exe.read_bytes();require(hashlib.sha256(blob).hexdigest()==row['executable_sha256'],'Current actual ELF digest')
        exe_description=provider_cache[str(exe.resolve())];require(exe_description['interpreter']==runtime['loader'] and pre['bound'][runtime['loader']]==runtime['loader_sha256']==runtime['files'][runtime['loader']],'Actual PT_INTERP prebinding')
        require(commands['link']['argv']==link and commands['link']['cwd']==str(case),'Actual link command')
        require(commands['actual-pt-interp-runtime']['argv']==[runtime['loader'],'--list',str(exe)] and (evidence/'commands/actual-pt-interp-runtime.stdout.txt').read_text()==runtime['listing'],'Retained interpreter-only list')
        listed=[]
        for line in runtime['listing'].splitlines():
            if 'linux-vdso.so.1' in line:continue
            found=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line.strip());require(found is not None,'Runtime line parse');listed.append(str(Path(found[1]).resolve()))
        require(set(listed)|{runtime['loader']}==set(runtime['files']),'Listed/current15 provider paths')
        require(all(pre['bound'].get(path)==h for path,h in runtime['files'].items()),'All runtime providers prebound')
        elf_names=elf_symbols(blob);nm_names=[line.split()[-1] for line in (evidence/'commands/symbols.stdout.txt').read_text().splitlines() if len(line.split())>=3]
        for token,wanted in (('__mtirust_MOD_',pins['expected_mtirust_symbols']),('_qpmass_',accepted['expected_private_symbols'])):
            values={n:elf_names.count(n) for n in set(elf_names) if token in n};observed={n:nm_names.count(n) for n in set(nm_names) if token in n}
            require(values==observed=={n:1 for n in wanted},'Independent ELF/nm unique symbol ownership')
        require(row['MTIRUST_definitions']==pins['expected_mtirust_symbols'] and row['private_definitions']==accepted['expected_private_symbols'],'Retained definition metadata')
        require(row['native_main_calls']==0 and row['support_objects_source_environment_provenance'] and not row['support_GEN_child_commands_individually_journalled'],'Build/support scope')
        summaries[role]={'command_records':84,'fresh_compiles':21,'source_inputs':427,'reused_support_objects':344,'reused_support_modules':4,'canonical_leaves':5,'polynomial_users':11,'include_USE_edges':dict(edge_counts),'bound_compile_file_instances':sum(len(x['bound_files']) for x in row['actual_compile_inputs']),'actual_LOAD_records':len(raw_loads),'unique_actual_LOADs':54,'prebound_files':len(pre['bound']),'runtime_providers':15,'pure_static_objects':len(static['objects']),'static_resolutions':len(static['resolutions']),'unique_MTIRUST_symbols':23,'unique_private_symbols':len(accepted['expected_private_symbols']),'executable_sha256':row['executable_sha256'],'current_ELF_hash_verified':True}
    F.validate_compiler_equality(policies['original'],policies['candidate'])
    require(command_totals==Counter({'compile':42,'link':2,'expanded-check':2,'policy':16,'prelink_query':102,'actual-pt-interp-runtime':2,'symbols':2}),'All168 command scope')
    require(result['native_amplitude_calls']==result['model_probes']==result['reducer_calls']==0 and not result['RUN_admitted'] and not result['candidate_promoted'] and not result['performance_acceptance'],'No scientific/RUN/promotion scope')
require(not effects,'Unexpected review effect')
remaining=[]
for row in terminal['cleanup']['observed_owned_processes']:
    path=Path('/proc')/str(row['pid'])/'stat'
    try:fields=path.read_text().rsplit(') ',1)[1].split()
    except FileNotFoundError:continue
    if int(fields[2])==row['process_group'] and int(fields[3])==row['session'] and int(fields[19])==row['start_time_ticks']:remaining.append(row['pid'])
require(not remaining,'Matching owned process remains')
summary={'status':'passed-closed-BUILD-only','raw_evidence_files':571,'recorded_command_counts':dict(command_totals),'recorded_policy_responses_replayed_without_queries':policy_response_replays,'roles':summaries,'unique_actual_compile_files_rehashed':len(checked_bound_files),'fresh_process_objects_rehashed':direct_object_hashes,'canonical_selected_leaves_rehashed':canonical_hashes,'unique_NinjaRS_alias_leaves_rehashed':len(alias_leaf_cache),'blanket_reused_support_object_rehashes':0,'pure_ELF_descriptors_checked':len(provider_cache),'matching_owned_processes_remaining':remaining,'cleanup_events':terminal['cleanup']['events'],'cleanup_survivors':terminal['cleanup']['survivors'],'forbidden_review_effects':effects,'new_compiler_make_loader_queries':0,'scientific_native_calls':0,'RUN_or_public_or_Git_action':False}
(OUT/'checks.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':summary['status'],'raw_files':571,'commands':168,'actual_compile_inputs':42,'policy_replays':policy_response_replays,'LOADs_per_role':54,'providers_per_role':15,'native_queries':0,'owned_remaining':remaining,'effects':len(effects)}))
