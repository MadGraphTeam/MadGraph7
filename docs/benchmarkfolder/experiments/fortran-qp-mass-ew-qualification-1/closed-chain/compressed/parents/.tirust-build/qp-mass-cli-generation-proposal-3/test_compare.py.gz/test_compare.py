"""Pure comparison tests. Process creation is blocked throughout each test."""
import copy
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from contextlib import ExitStack
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qp_mass_cli_compare', HERE / 'compare.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def unit(name, statement='X=1', comment=''):
    return '      SUBROUTINE '+name+'(X)\n'+comment+'      INTEGER X\n      '+statement+'\n      END\n'


def fixture():
    block = '      BLOCK DATA RETRY_INIT\n      INTEGER X\n      COMMON/RETRY/X\n      DATA X/0/\n      END\n'
    original = {'CT_interface.f': block + unit('LOOP_2') + unit('LOOP_3'),
                'TIRUST_interface.f': unit('MP_TIRUST_LOOP'), 'loop_CT_calls_1.f': unit('LOOP_CT_CALLS', 'CALL LOOP_2(X)')}
    candidate = dict(original)
    candidate['CT_interface.f'] += unit('LOOP_2_QPMASS') + unit('LOOP_3_QPMASS')
    candidate['TIRUST_interface.f'] += unit('MP_TIRUST_LOOP_QPMASS')
    candidate['loop_CT_calls_1.f'] = unit('LOOP_CT_CALLS', 'CALL LOOP_2_QPMASS(X)')
    return original, candidate


class Compare(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        for module, names in ((subprocess, ('run', 'Popen', 'check_output', 'check_call', 'call')),
                              (os, ('system', 'popen', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp',
                                    'execl', 'execle', 'execlp', 'execlpe', 'execv', 'execve', 'execvp', 'execvpe'))):
            for name in names:
                if hasattr(module, name):
                    self.stack.enter_context(mock.patch.object(module, name, side_effect=AssertionError('External execution forbidden')))

    def test_identical_and_block_data_are_strict(self):
        original, candidate = fixture()
        result = C.compare_sources(original, candidate, original, candidate)
        self.assertTrue(result['strict_pass'])
        self.assertIn('RETRY_INIT', result['files']['CT_interface.f']['public'])
        changed = dict(candidate)
        changed['CT_interface.f'] = changed['CT_interface.f'].replace('DATA X/0/', 'DATA X/1/')
        result = C.compare_sources(original, changed, original, candidate)
        self.assertFalse(result['public_legacy_bodies_exact'])
        self.assertFalse(result['strict_pass'])

    def test_known_private_order_comments_and_wrapping_are_not_strict_pass(self):
        original, materialized = fixture()
        fresh = dict(materialized)
        old = C.routines(original['CT_interface.f'])
        fresh['CT_interface.f'] = old['RETRY_INIT']['text'] + old['LOOP_2']['text'] + unit('LOOP_2_QPMASS', comment='C Added explanation\n') + old['LOOP_3']['text'] + unit('LOOP_3_QPMASS')
        fresh['TIRUST_interface.f'] = fresh['TIRUST_interface.f'].replace('SUBROUTINE MP_TIRUST_LOOP_QPMASS(X)', 'SUBROUTINE MP_TIRUST_LOOP_QPMASS(\n     $ X)')
        result = C.compare_sources(original, fresh, original, materialized)
        self.assertTrue(result['public_legacy_bodies_exact'])
        self.assertFalse(result['strict_pass'])
        self.assertFalse(result['files']['CT_interface.f']['routine_order']['equal'])
        private = result['files']['CT_interface.f']['private']['LOOP_2_QPMASS']
        self.assertTrue(private['logical_diagnostic']['equal'])
        self.assertIn('Added explanation', private['raw_diff'])
        self.assertFalse(result['semantic_equivalence_proven'])

    def test_private_coefficient_and_caller_arguments_remain_visible(self):
        original, materialized = fixture()
        fresh = dict(materialized)
        fresh['CT_interface.f'] = fresh['CT_interface.f'].replace('SUBROUTINE LOOP_2_QPMASS(X)\n      INTEGER X\n      X=1', 'SUBROUTINE LOOP_2_QPMASS(X)\n      INTEGER X\n      X=2')
        fresh['loop_CT_calls_1.f'] = fresh['loop_CT_calls_1.f'].replace('CALL LOOP_2_QPMASS(X)', 'CALL LOOP_2_QPMASS(2*X)')
        result = C.compare_sources(original, fresh, original, materialized)
        self.assertFalse(result['strict_pass'])
        self.assertFalse(result['files']['CT_interface.f']['private']['LOOP_2_QPMASS']['logical_diagnostic']['equal'])
        self.assertFalse(result['files']['loop_CT_calls_1.f']['fresh_vs_materialized']['logical_diagnostic']['equal'])

    def test_only_declared_exact_banner_and_root_literals(self):
        original, materialized = fixture()
        fresh = dict(materialized)
        fresh['CT_interface.f'] = 'C Export from /fresh/root/tree\n' + fresh['CT_interface.f']
        materialized['CT_interface.f'] = 'C Export from /donor/root/tree\n' + materialized['CT_interface.f']
        result = C.compare_sources(original, fresh, original, materialized,
                    {'root_paths': [{'source': '/fresh/root', 'target': '/donor/root'}]})
        self.assertTrue(result['strict_pass'])
        self.assertIn('/fresh/root', result['files']['CT_interface.f']['fresh_vs_materialized']['raw_diff'])
        policy = C.validate_normalization({'banner_lines': [{'source': 'C Date one\n', 'target': 'C Date two\n'}]})
        self.assertEqual(C.normalize('C Date one\n C Date one\n', policy)[0], 'C Date two\n C Date one\n')
        policy = C.validate_normalization({'root_paths': [{'source': '/fresh/root', 'target': '/canonical/root'}]})
        self.assertEqual(C.normalize('/fresh/rootX /path/fresh/root /fresh/root/a', policy)[0], '/fresh/rootX /path/fresh/root /canonical/root/a')

    def test_no_whitespace_comment_or_literal_normalization_in_strict_gate(self):
        original, materialized = fixture()
        for before, after in (('X=1', 'X = 1'), ('      INTEGER X', 'C comment\n      INTEGER X')):
            fresh = dict(materialized)
            fresh['CT_interface.f'] = fresh['CT_interface.f'].replace(before, after, 1)
            result = C.compare_sources(original, fresh, original, materialized)
            self.assertFalse(result['public_legacy_bodies_exact'])
            self.assertFalse(result['strict_pass'])
        self.assertNotEqual(C.canonical_statement("PRINT *, 'a b'"), C.canonical_statement("PRINT *, 'ab'"))
        self.assertNotEqual(C.logical_diagnostic('  100 X=1\n'), C.logical_diagnostic('  101 X=1\n'))
        self.assertNotEqual(C.logical_diagnostic('C$OMP SIMD\n      X=1\n'), C.logical_diagnostic('      X=1\n'))

    def test_invalid_normalizations_fail(self):
        rows = [{'strip_comments': True}, {'root_paths': [{'source': '/', 'target': '/x'}]},
                {'banner_lines': [{'source': '      X=1\n', 'target': '      X=2\n'}]},
                {'banner_lines': [{'source': 'C$OMP X\n', 'target': 'C$OMP Y\n'}]},
                {'root_paths': [{'source': '/a', 'target': '/b'}, {'source': '/b', 'target': '/c'}]}]
        for row in rows:
            with self.assertRaises(ValueError):
                C.validate_normalization(row)

    def test_duplicate_missing_and_unterminated_units_fail(self):
        for text in (unit('X') + unit('X'), unit('X').removesuffix('      END\n'),
                     '     $ X=1\n', '      X=1\n', '      SUBROUTINE X()\n      '+('X'*134)+'\n      END\n'):
            with self.assertRaises(ValueError):
                C.routines(text)
        original, candidate = fixture()
        fresh = dict(candidate)
        fresh['CT_interface.f'] = fresh['CT_interface.f'].replace(unit('LOOP_3'), '')
        self.assertFalse(C.compare_sources(original, fresh, original, candidate)['public_legacy_bodies_exact'])

    def test_extra_private_unit_fails_name_gate(self):
        original, candidate = fixture()
        fresh = dict(candidate)
        fresh['CT_interface.f'] += unit('UNEXPECTED')
        self.assertFalse(C.compare_sources(original, fresh, original, candidate)['private_names_exact'])

    def test_tree_reader_preserves_CRLF_and_actual_preview_is_pure(self):
        original, candidate = fixture()
        with tempfile.TemporaryDirectory() as tmp:
            dirs = [Path(tmp) / str(i) for i in range(4)]
            for directory, source in zip(dirs, (original, candidate, original, candidate)):
                directory.mkdir()
                for name, text in source.items():
                    (directory/name).write_bytes(text.encode())
            self.assertTrue(C.compare_trees(*dirs)['strict_pass'])
            p = dirs[1]/'CT_interface.f'
            p.write_bytes(p.read_bytes().replace(b'\n', b'\r\n'))
            self.assertFalse(C.compare_trees(*dirs)['strict_pass'])
        preview = HERE.parent/'qp-mass-current-qualification-proposal-2/source-preview'
        result = C.compare_trees(preview/'original', preview/'candidate', preview/'original', preview/'candidate')
        self.assertTrue(result['strict_pass'])
        self.assertIn('ML5_0_NINJARS_RETRY_INIT', result['files']['CT_interface.f']['public'])
        self.assertEqual(len(result['files']['CT_interface.f']['private']), 7)
        self.assertEqual(len(result['files']['TIRUST_interface.f']['private']), 2)


if __name__ == '__main__':
    unittest.main()
