"""Pure exact-CMS ELF closure, reusing the frozen ELF parser; no load/query."""
from collections import deque
from pathlib import Path
import hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PARSER=ROOT/'.tirust-build/generic-owned-snapshot-qualification-proposal-2/unit_runtime.py'
PARSER_SHA='4552d6b3bcd8d37a11f2eba81f505e71769010314246c4382e20d15fd441b0b5'
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_parser():
    require(digest(PARSER)==PARSER_SHA,'frozen ELF parser changed')
    spec=importlib.util.spec_from_file_location('cms_frozen_ELF_parser',PARSER)
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    return m

def absolute_paths(raw,label):
    if raw in (None,''):return []
    values=raw.split(':')
    require(all(v and Path(v).is_absolute() and '$' not in v for v in values),'unsupported '+label)
    for value in values:require(not (Path(value)/'glibc-hwcaps').exists(),'hwcaps outside exact CMS scope')
    return values

def derive(executable,prebound,expected,ld_library_path):
    parser=load_parser();bound=prebound['bound'];exe=Path(executable).resolve();root=parser.describe(exe)
    require(len(expected)==15,'exact original15 CMS providers required')
    provider_objects={};allowed={}
    for path,sha in expected.items():
        require(bound.get(path)==digest(path)==sha,'unbound/changed expected CMS provider')
        obj=parser.describe(path);name=obj['soname']
        require(name and '/' not in name and name not in allowed,'duplicate/unknown original SONAME')
        allowed[name]=path;provider_objects[path]=obj
    loader=Path(root['interpreter']).resolve() if root['interpreter'] else None
    require(loader and str(loader)==allowed.get('ld-linux-x86-64.so.2'),'unexpected actual interpreter')
    initial=provider_objects[str(loader)]
    require(not initial['needed'],'interpreter dependencies outside scope')
    env_paths=absolute_paths(ld_library_path,'controlled LD_LIBRARY_PATH')
    require(env_paths,'empty controlled LD_LIBRARY_PATH outside scope')
    files={str(loader):initial['sha256']};loaded={initial['soname']:str(loader)}
    queue=deque([root]);objects=[initial];resolutions=[]
    while queue:
        obj=queue.popleft();objects.append(obj)
        require(not obj['rpath'],'RPATH/inherited lookup outside exact CMS scope')
        paths=env_paths+absolute_paths(obj['runpath'],'absolute RUNPATH')
        require(len(obj['needed'])==len(set(obj['needed'])),'duplicate NEEDED entries')
        for needed in obj['needed']:
            require(needed in allowed,'unqualified CMS SONAME '+needed)
            if needed in loaded:
                resolutions.append({'requester':obj['path'],'needed':needed,'selected':loaded[needed],'reason':'already-loaded SONAME'})
                continue
            found=next((Path(p)/needed for p in paths if (Path(p)/needed).is_file()),None)
            require(found is not None,'cache/default lookup outside exact CMS scope: '+needed)
            path=str(found.resolve());sha=digest(path)
            require(path==allowed[needed] and expected.get(path)==sha==bound.get(path),'first existing runtime candidate differs from original15: '+str(found))
            child=provider_objects[path];require(child['soname']==needed,'provider SONAME differs')
            loaded[needed]=path;files[path]=sha;queue.append(child)
            resolutions.append({'requester':obj['path'],'needed':needed,'selected':path,'reason':'first existing controlled LD path then absolute RUNPATH','search_paths':paths,'spelling':str(found)})
    require(files==expected,'actual static CMS closure differs from exact original15')
    for path,sha in files.items():require(digest(path)==bound.get(path)==sha,'provider changed during pure derivation')
    require(digest(exe)==root['sha256'],'executable changed during pure derivation')
    return {'schema':'exact-CMS-static-ELF-closure-v1','files':dict(sorted(files.items())),
            'sonames':dict(sorted(loaded.items())),'objects':objects,'resolutions':resolutions,
            'controlled_LD_LIBRARY_PATH':env_paths,'scope':'ELF64 x86_64 exact15 SONAMEs,controlled absolute LD path then absolute RUNPATH; no RPATH/cache/default/ORIGIN/hwcaps',
            'compiler_or_loader_invocations':0,'actual_interpreter_query_still_required':True}
