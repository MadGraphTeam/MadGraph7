# Dormant single-process fresh CLI export for QP mass transport

Source3 preserves the closed failed source2 GEN exactly: source seal
`ea987abb0c313cfe2d01423ca26b3231ff40b9ba1af6896143f70cee594f00e1`,
terminal `61b000fbf56ab27dd32f37accf37ce69fc73635254ceb76fcc9a0c5616a47304`,
and independent failure audit
`720ed92486e4d82f5c976a31c7f5b883cd4c6069624b4dc14a93a9539dd183dd`.
That actual CLI exited during its initial interface import because the retained
benchmark exporter inventory omitted mandatory package `mg5decay`. No card,
exporter, compiler, output, source comparison or numerical action was reached.
Its empty cleanup, failed logs, command, staging and postfailure protected
checks are pinned as predecessors. No failed receipt is rewritten or relabelled.

Source3 fixes the **static frontend bootstrap closure**, not just the first
missing import. The original 2664 scientific bindings and two root metadata
files remain unchanged. A separate `bootstrap_files` field adds twelve
startup/compatibility-only files, all authenticated against exact Git blob IDs
at frozen production `0fcd2cd873d61d134837e1d9e87afb13a47824fd` and matching
current tracked bytes: two mandatory `mg5decay` modules, three conservative
optional MadSpin modules, six madmatrix frontend modules, and the empty PLUGIN
namespace. These add no scientific source change or native dependency.

The static import analysis starts at the actual bin/master/interface sources,
traverses absolute and relative imports and package initializers, and includes
lazy function imports conservatively. MadSpin is a lazy frontend route;
including it does not imply the n3 command executes it. MadSpin imports
madmatrix.density, whose package initializer eagerly imports output/trex and
their relative/dynamic frontend aliases. Required backend template directory
contents already occur in the retained scientific inventory. Existing logging,
version, input defaults, SM/loop_sm package/default-restriction and make_opts
template assets remain bound. PLUGIN's empty tracked namespace preserves plugin
discovery without installing or selecting any plugin.

`tracked-bootstrap-tree.json` and `git-read-provenance.json` retain the explicitly
authorized read-only Git source query. Runtime/default preflight uses SHA-256
and Git-blob SHA-1 computations only; no Git command or MG import executes.
The AST report distinguishes static closure from nonliteral dynamic import
limitations: it visits129 local Python files and records29 nonliteral/unresolved
dynamic-import sites. The source2 counterfactual has11 missing declared files;
the source3 static report has none and no parse errors. Both missing files and
analysis errors block preflight. Static source closure is not an executed-import completeness
result. Source3 has fresh work/report3 destinations. Candidate overlays,
libraries, flags, caps, card options, comparison rules and the single proposed
GEN scope are unchanged; only the output destination changes.

Prior source2 preserved unadmitted source1 seal
`1e0f94b56e5b83d8da1d3315c48dd91136cee8153f8d837feae4431dcb997f58`.
Before any native action, root review identified the interval between successful
Popen and ownership construction: a constructor failure left no owned object
for cleanup. Source2 retains the raw child handle and session/start identity
first, then uses the unchanged pinned host-repair ownership helper for bounded
failure-only cleanup if construction fails. Uncertainty always blocks later
work; a raw-root cleanup is never treated as descendant closure or a pass.
It also rejects any extra, missing or symlinked proposal payload/directory
before execution. Pure regression tests cover the actual supervisor's mocked
post-Popen ownership failure and exact inventory. No source1 native admission
occurred. Source2 used fresh work/report2 destinations; physics sources,
generation card options, dependencies, compiler policy, caps and scope remain
unchanged. Only the card's fresh output destination changes.

This source-only proposal exercises the **actual modified call writer and
exporter** from frozen mass source
`75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25`.
No MG CLI, compiler query, compilation, linker, loader, reducer or amplitude has
run for this proposal. Its default controller mode reads and hashes files only.
Actual execution requires separate review and explicit `--execute`.

The proposed single action runs the stock `bin/madgraph --plain` entrypoint in
an isolated ignored source tree and emits one real optimized standalone
`loop_sm; u u~ > z g g [virt=QCD]` process. It does not stub exporter finalization.
**Stock output compiles MODEL/DHELAS libraries and queries compilers.** Those
normal children belong to the proposed generation admission. No `launch`,
`check`, installation, amplitude evaluation or subprocess compilation is included.

## Frozen source and inputs

The retained n3 generation receipt binds 2664 exporter source entries. Its
historical revision is `6c77fe0604902d690513e28c30e22c17410f7747`; that receipt is
not relabelled as a new generation at `0fcd2cd…`. Current production matches all
2664 entries, including two absent/broken NLO links. The scientific source
anchor remains `0fcd2cd873d61d134837e1d9e87afb13a47824fd`.

At execution only, the controller copies those exact entries plus root VERSION
and LICENSE into `.tirust-build/qp-mass-cli-generation-work-3/mg-current-qpmass`.
Readable source symlinks are dereferenced; the two explicitly bound broken links
are recreated. It performs no Git operation and imports no Git state. Then it
overlays the nine exact `75f32…/src/` payloads: **seven existing files, of which
three change and four remain identical, plus two new templates**. The untouched
public templates are deliberately included in that exact overlay. The private
generator sources and all production source pins are rechecked after output.

The already successful current-source staging pattern supplies 123 explicitly
pinned private prebuilt CutTools/IREGI files and 24 external dependency bindings.
They are copied/read using the unchanged pinned `prerequisites.py` helper. The
external Ninja, COLLIER, NinjaRS and TIRust prefixes match the current n3 donor,
including TIRust native `eb3d67fd…`. Dependencies and shared configuration are
checked before and after; no library is rebuilt or repinned. The exact local
`loop_sm` sources and `restrict_default.dat` are in the copied inventory.

The physical parameter card and cache0 numerical card are the current checked
n3 inputs. They are copied to the fresh output only after the stock export;
the unmodified generated parameter-card hash is retained separately. No
phase-space points or numerical results are generated. This card installation
does not imply a physical qualification of the fresh generated output.

The controller reconstructs the successful pinned tool environment, with its
empty original compiler-injection policy, rather than inherit the current
harness PATH or Nix compiler flags. All 14 required tool paths/hashes/executable
bits and the pinned compiler closure are validated without executing them.
The added explicit tools are g++, ar and ranlib. Ninja's exact `ninja-config`
metadata executable is also pinned. No Nix store glob discovery is used.
MAKEFLAGS uses `-j1` and the pinned Bash; `nb_core=1` is session-local.
Thread pools are one, PYTHONHASHSEED=0, and XDG directories are private.
The isolated startup configuration disables updates **before** the card runs.

## Exact future action and bounds

Run only from
`/shared/external/madloop_tirust/madgraph7_madloop_tirust`, with the pinned Python:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/qp-mass-cli-generation-proposal-3/controller.py --source SOURCE_SHA
```

Only after exact source review, the separately admitted single action is:

```sh
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/qp-mass-cli-generation-proposal-3/controller.py --source SOURCE_SHA --execute
```

The supervisor uses nonexclusive CPU12, the existing numerical mutex (fail if
busy), 16GiB address space, 512MiB per-file limit, zero core dumps, and **300s
total with a 60s cleanup reserve**. Staging, source verification, CLI output and
postchecks are within that deadline. Owned process-group/descendant cleanup
uses the same sealed helper as the successful physical qualification. First
failure stops; no retry, source correction, follow-on build or automatic
qualification occurs. Work and execution destinations must both be absent.

The actual child CLI command, after staging, is exactly:

```text
<pinned Python> -B ./bin/madgraph --plain <absolute proposal>/generate.mg5
```

Its cwd is the isolated MG tree. The card sets pinned compilers and all four
external backend prefixes, imports local `loop_sm`, generates the one process,
and uses a fresh output path with `-nojpeg`; it ends with `quit`. No JPEG helper
or output-deletion prompt is needed. The prior n3 generation took 19.83s on the
shared host; that is sizing history, not a timing promise or this proposal's
measurement.

Expected native activity is compiler/version and metadata queries (including
gfortran `--version`/`-dumpversion`, C++ `--version`, Ninja `-quadsupport`, and
make's `uname`/compiler detection), then stock Fortran MODEL/DHELAS object
compilation and static archiving with ar/ranlib. Source/make can repeat internal
queries; not every make-internal process command is individually captured.
The complete CLI log and outer command/exit/hash are retained. No scientific
Fortran executable, reducer DSO entrypoint or generated subprocess check is run.
CutTools/IREGI rebuild markers, unexpected subprocess objects or `check`
executables are hard failures. MODEL/DHELAS build objects are counted, and their
source/make inputs are inventoried. Source/make_opts must match the retained
original byte-for-byte after substituting only the two exact compiler selector
paths; no optimization, floating-point or other flag is changed. This gate
does not freshly recapture all expanded selected-unit compilation recipes.

## Source correspondence and separate review

The comparison covers CT_interface.f, TIRUST_interface.f and loop_CT_calls_1.f
against both the retained original actual CLI sources and the reviewed source2
plain candidate preview. Legacy public routines, including BLOCK DATA, must
remain exact. The original preview and expected private routine names must
also match. The caller intentionally changes and is compared as such.

Whole-file candidate equality is **not** the expected pass condition: the real
exporter interleaves private helpers with legacy helpers, whereas the source2
materializer appended private helpers. The real template has two additional
comments, and its FortranWriter controls wrapping/indentation. Raw whole-file,
public/private-routine and caller diffs remain in source-comparison.json. The
strict comparator does not remove comments, whitespace, labels, literals or
statements. Its only optional normalization mechanism accepts exact declared
banner/root replacements; this proposal declares none by default.

Separate logical statement diagnostics preserve labels, literals, statement
order and control flow, but **never qualify source or authorize another build**.
They help a reviewer distinguish expected formatting from changes in actual
argument order, mass symbols, guards, selection, squaring or contraction. A
successful generation closes as `generated_pending_source_review`. Root must
separately review actual Fortran statement/argument equivalence and raw deltas
before considering compilation of the three selected actual generated units
or another candidate full100 gate. Neither is part of this proposal.

Source-only tests cover strict comparisons, changed arguments/coefficients,
helper interleaving/comments/wrapping, BLOCK DATA, CRLF, the actual pure
preflight with process creation blocked, exact nine-file overlay counts and
card/cap restrictions. They do not qualify actual CLI behavior. Preparation's
source3 preflight also blocks imports of all MG frontend packages while
replaying the static derivation; no MG package is imported by these checks.
They do not turn the nonliteral import sites into executed evidence.
Preparation's
first inventory attempt encountered two inherited broken NLO links before any
pin file was written; the second explicitly bound their absent/link state.
That source-only preparation correction is not a failed native generation.
