"""Pure strict observer parser and independent n3 real-mass square attribution."""
from collections import Counter
from fractions import Fraction
import re


def require(value,message):
    if not value:raise ValueError(message)


def word(value):
    require(re.fullmatch('[0-9A-Fa-f]{16}',value) is not None,'Malformed raw word')
    return value.upper()


def number(bits,width,precision):
    exponent_bits=15 if width==128 else 11
    fraction_bits=precision-1;bias=(1<<(exponent_bits-1))-1
    exponent=(bits>>fraction_bits)&((1<<exponent_bits)-1)
    fraction=bits&((1<<fraction_bits)-1)
    require(exponent!=(1<<exponent_bits)-1,'Nonfinite observed floating word')
    value=(fraction+(1<<fraction_bits) if exponent else fraction)*Fraction(2)**(
        (exponent-bias if exponent else 1-bias)-fraction_bits)
    return -value if bits>>(width-1) else value


def qp(words):
    require(len(words)==2,'Expected two binary128 machine words')
    return number(int(words[0],16)+(int(words[1],16)<<64),128,113)


def complex_qp(words):
    require(len(words)==4,'Expected four complex binary128 machine words')
    return qp(words[:2]),qp(words[2:])


def complex_dp(words):
    require(len(words)==2,'Expected two complex binary64 words')
    return tuple(number(int(x,16),64,53) for x in words)


def round_binary(value,precision):
    if not value:return Fraction(0)
    sign=-1 if value<0 else 1;value=abs(value)
    exponent=value.numerator.bit_length()-value.denominator.bit_length()
    if value<Fraction(2)**exponent:exponent-=1
    quantum=Fraction(2)**(exponent-precision+1);scaled=value/quantum
    result,remainder=divmod(scaled.numerator,scaled.denominator)
    if 2*remainder>scaled.denominator or 2*remainder==scaled.denominator and result%2:result+=1
    return sign*result*quantum


def parse(text,role):
    require(role in (0,1),'Invalid role')
    lines=[s.split() for s in text.splitlines() if s.strip()]
    require(lines[:2]==[['MGMASS','1'],['ENDIAN','1','0','0','0','0','0','0','0']],
            'Wrong observer version or unsupported actual endianness')
    cursor=2;points=[];models={};groups=[];current_point=0
    def take(tag,fields=None):
        nonlocal cursor
        require(cursor<len(lines),'Truncated observer journal')
        row=lines[cursor];cursor+=1
        require(row and row[0]==tag and (fields is None or len(row)==fields),'Wrong observer record: '+tag)
        return row[1:]
    def values(tag,indices,count):
        fields=take(tag,1+len(indices)+count)
        require(list(map(int,fields[:len(indices)]))==indices,'Raw value indices differ')
        return [word(v) for v in fields[len(indices):]]
    while cursor<len(lines) and lines[cursor][0]!='END':
        tag=lines[cursor][0]
        if tag=='POINT':
            fields=take(tag,2);current_point=int(fields[0]);points.append(current_point)
            require(points==list(range(1,current_point+1)) and current_point<=100,'Point sequence incomplete/reordered')
        elif tag=='MODELDP':
            require(current_point and str(current_point) not in models,'Duplicate/missing point model')
            fields=take(tag,4);require(int(fields[0])==current_point,'Model point differs')
            dp=[word(v) for v in fields[1:]]
            mp=[values('MODELMP',[current_point,i],2) for i in (1,2)]
            for words in mp:qp(words)
            models[str(current_point)]={'DP':dp,'MP':mp}
        elif tag=='GROUP':
            fields=list(map(int,take(tag,8)));sequence,point,actual_role,mode,n,rank,id=fields
            require(sequence==len(groups)+1 and point==current_point and actual_role==role and mode in (4,5,6)
                and 1<=n<=6 and 0<=rank<=6 and id>0,'Invalid group metadata')
            entry={'sequence':sequence,'point':point,'role':role,'mode':mode,'n':n,'rank':rank,'id':id,
                   'formals':[],'DP_squares':[],'QP_squares':[],'coefficients':None,'native':None,'status':None}
            for i in range(1,n+1):
                f=values('FORMAL',[i],4);d=values('DPSQUARE',[i],2);q=values('QPSQUARE',[i],4)
                complex_qp(f);complex_dp(d);complex_qp(q)
                entry['formals'].append(f);entry['DP_squares'].append(d);entry['QP_squares'].append(q)
            if cursor<len(lines) and lines[cursor][0]=='COEFFICIENTS':
                header=list(map(int,take('COEFFICIENTS',8)));nc=(rank+1)*(rank+2)*(rank+3)*(rank+4)//24
                require(header==[sequence,point,role,n,rank,id,nc],'Numerator group identity differs')
                entry['coefficients']=[values('COEF',[i],4) for i in range(nc)]
                for coef in entry['coefficients']:complex_qp(coef)
            if cursor<len(lines) and lines[cursor][0]=='NATIVE':
                require(list(map(int,take('NATIVE',7)))==[sequence,point,role,mode,n,rank],'Native group identity differs')
                native={'scale':values('SCALE',[0,0],2),'masses':[],'shifts':[],'invariants':[]}
                qp(native['scale'])
                for i in range(1,n+1):
                    mass=values('MASS',[i],4);complex_qp(mass);native['masses'].append(mass)
                    shifts=[values('SHIFT',[j,i],2) for j in range(4)]
                    invariants=[values('INVARIANT',[j,i],2) for j in range(1,n+1)]
                    for words in shifts+invariants:qp(words)
                    native['shifts'].append(shifts);native['invariants'].append(invariants)
                entry['native']=native
                fields=list(map(int,take('STATUS',4)));require(fields[:2]==[sequence,point] and fields[2] in (0,1,2,3),'Wrong native status')
                entry['status']=fields[2]
            groups.append(entry)
        else:raise ValueError('Unknown or misordered observer record: '+tag)
    actual=list(map(int,take('END',7)))
    counts=[100,len(groups),sum(g['coefficients'] is not None for g in groups),
        sum(g['native'] is not None for g in groups),sum(g['status'] is not None for g in groups),100]
    require(actual==counts and cursor==len(lines) and points==list(range(1,101)) and len(models)==100,'Missing observer footer/point/model/count coverage')
    return {'role':role,'points':points,'models':models,'groups':groups,
        'incomplete_groups':[g['sequence'] for g in groups if g['coefficients'] is None or g['native'] is None],
        'native_status_counts':dict(Counter(str(g['status']) for g in groups if g['status'] is not None)),
        'scope':'Untimed Fortran boundary observations; internal MPFR work precision, tensor outputs and trap safety unobserved'}


def validate_mass_words(observed,proof):
    role=observed['role'];mapping={g['group']:g for g in proof['groups']}
    recovered=0;by_symbol=Counter();native_reversal=0;native_MB_witnesses=Counter()
    for entry in observed['groups']:
        require(entry['id'] in mapping,'Unknown CLI group')
        meta=mapping[entry['id']];require(len(meta['mass_pairs'])==entry['n'] and meta['rank']==entry['rank'],'CLI group shape differs')
        model=observed['models'][str(entry['point'])]
        for index,pair in enumerate(meta['mass_pairs']):
            symbol=pair['model_symbol'];by_symbol[symbol]+=1
            require(symbol in ('ZERO','MDL_MB','MDL_MT'),'Unsupported current n3 physical mass oracle')
            which=0 if symbol=='MDL_MB' else 1
            expected=Fraction(0) if symbol=='ZERO' else (
                qp(model['MP'][which]) if role else number(int(model['DP'][which],16),64,53))
            actual=complex_qp(entry['formals'][index]);require(actual==(expected,0),'Actual model/formal mass join failed')
        # Original cyclic order is[last,first,...]; all source formals are observed.
        cyclic=[entry['formals'][-1],*entry['formals'][:-1]]
        symbols=[meta['mass_pairs'][-1]['model_symbol'],*[m['model_symbol'] for m in meta['mass_pairs'][:-1]]]
        for symbol,f,dp_square,qp_square in zip(symbols,cyclic,entry['DP_squares'],entry['QP_squares'],strict=True):
            real,imag=complex_qp(f);require(imag==0,'Current physical oracle requires real mass inputs')
            actual=complex_qp(qp_square)
            expected=(round_binary(real*real,113),Fraction(0)) if role else complex_dp(dp_square)
            require(actual==expected,'Actual QP square differs from independent real-mass oracle')
            if role and actual!=complex_dp(dp_square):
                recovered+=1
                if symbol=='MDL_MB' and entry['native'] is not None and entry['status']==0:
                    native_MB_witnesses[str(entry['point'])]+=1
        if entry['native'] is not None:
            expected=entry['QP_squares']
            if entry['mode']==5 and entry['n']>2:
                expected=[expected[0],*reversed(expected[1:])];native_reversal+=1
            require(entry['native']['masses']==expected,'Native mass words/order differ from actual QP squares')
    require(observed['groups'] and (role==0 or recovered>0),'No observed recovered-square witness')
    require(role==0 or native_MB_witnesses.get('16',0)>0,'Automatic-QP anchor16 has no actual successful native bottom-square witness')
    return {'groups':len(observed['groups']),'actual_formal_symbols':dict(by_symbol),
        'recovered_square_entries':recovered,'native_reversed_mass_groups':native_reversal,
        'native_bottom_square_witnesses_by_point':dict(native_MB_witnesses),
        'independent_real_mass_square_gate':True,'true113bit_mass_input_scope':False,
        'physical_finite_truth_qualified':False}


def compare(original,candidate,proof):
    require(original['role']==0 and candidate['role']==1,'Wrong comparison roles')
    left=validate_mass_words(original,proof);right=validate_mass_words(candidate,proof)
    require(original['models']==candidate['models'],'Model words differ between matched workers')
    require(len(original['groups'])==len(candidate['groups']),'Reduction call counts changed')
    invariant_changes=0;mass_changes=0
    for l,r in zip(original['groups'],candidate['groups'],strict=True):
        require({k:l[k] for k in ('sequence','point','mode','n','rank','id')}==
                {k:r[k] for k in ('sequence','point','mode','n','rank','id')},'Actual group/call history differs')
        require(l['coefficients']==r['coefficients'],'QP numerator words changed')
        require(l['DP_squares']==r['DP_squares'],'Original DP square arrays changed')
        require(l['native'] is not None and r['native'] is not None and l['coefficients'] is not None,
                'Missing native/numerator observation; input attribution incomplete')
        require(l['native']['scale']==r['native']['scale'] and l['native']['shifts']==r['native']['shifts'],
                'Nonmass native scale/shift words changed')
        require(l['status']==r['status'],'Native failure/status history changed; retained as unqualified')
        mass_changes+=sum(a!=b for a,b in zip(l['native']['masses'],r['native']['masses'],strict=True))
        invariant_changes+=sum(a!=b for aa,bb in zip(l['native']['invariants'],r['native']['invariants'],strict=True)
                               for a,b in zip(aa,bb,strict=True))
    require(mass_changes>0,'No changed native mass-square witness')
    return {'passed':True,'original':left,'candidate':right,'nonmass_scale_shifts_numerators_exact':True,
        'changed_native_mass_entries':mass_changes,'changed_mass_dependent_invariant_entries':invariant_changes,
        'input_precision_improvement_observed':True,'independent_physical_finite_truth_qualified':False,
        'generic_CMS_or_running_mass_policy_qualified':False}
