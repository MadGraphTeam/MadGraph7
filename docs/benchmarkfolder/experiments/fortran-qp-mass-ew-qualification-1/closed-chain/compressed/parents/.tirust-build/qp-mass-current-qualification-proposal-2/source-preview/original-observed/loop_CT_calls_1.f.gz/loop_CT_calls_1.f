      SUBROUTINE ML5_0_LOOP_CT_CALLS_1(P,NHEL,H,IC)
C     
C     Modules
C     
      USE ML5_0_POLYNOMIAL_CONSTANTS
      USE ALOHA_OBJECT
C     
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=5)
      INTEGER    NCOMB
      PARAMETER (NCOMB=48)
      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=8)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=224, NLOOPGROUPS=116, NCTAMPS=278)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=502)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=35,NLOOPWAVEFUNCS=388)
      REAL*8     ZERO
      PARAMETER (ZERO=0D0)
      REAL*16     MP__ZERO
      PARAMETER (MP__ZERO=0.0E0_16)
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*8 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      INTEGER FLAVOR(NEXTERNAL)
      DATA FLAVOR /NEXTERNAL*1/
      COMPLEX*16 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)

      LOGICAL DUMMYFALSE
      DATA DUMMYFALSE/.FALSE./
C     
C     GLOBAL VARIABLES
C     

      INCLUDE 'coupl.inc'
      INCLUDE 'mp_coupl.inc'

      INTEGER HELOFFSET
      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/ML5_0_FILTERS/GOODAMP,GOODHEL,HELOFFSET

      LOGICAL CHECKPHASE
      LOGICAL HELDOUBLECHECKED
      COMMON/ML5_0_INIT/CHECKPHASE, HELDOUBLECHECKED

      INTEGER SQSO_TARGET
      COMMON/ML5_0_SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/ML5_0_SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      INTEGER I_SO
      COMMON/ML5_0_I_SO/I_SO
      INTEGER I_LIB
      COMMON/ML5_0_I_LIB/I_LIB

      COMPLEX*16 AMP(NBORNAMPS)
      COMMON/ML5_0_AMPS/AMP
      TYPE(ALOHA) W(NWAVEFUNCS)
      COMMON/ML5_0_W/W
      COMPLEX*16 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*16 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/ML5_0_WL/WL,PL

      COMPLEX*16 AMPL(3,NCTAMPS)
      COMMON/ML5_0_AMPL/AMPL

C     
C     ----------
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.CTCALL_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

C     CutTools call for loop numbers 1
      CALL ML5_0_LOOP_2(7,13,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,1)
C     CutTools call for loop numbers 2,25
      CALL ML5_0_LOOP_2(6,14,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,2)
C     CutTools call for loop numbers 3,4
      CALL ML5_0_LOOP_3(5,6,7,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),2
     $ ,I_SO,3)
C     CutTools call for loop numbers 5
      CALL ML5_0_LOOP_2(8,15,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,4)
C     CutTools call for loop numbers 6
      CALL ML5_0_LOOP_2(6,16,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,5)
C     CutTools call for loop numbers 7,8
      CALL ML5_0_LOOP_3(4,6,8,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),2
     $ ,I_SO,6)
C     CutTools call for loop numbers 9,19
      CALL ML5_0_LOOP_3(2,5,15,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,7)
C     CutTools call for loop numbers 10,17
      CALL ML5_0_LOOP_3(2,4,13,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,8)
C     CutTools call for loop numbers 11,15
      CALL ML5_0_LOOP_4(2,4,5,6,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,9)
C     CutTools call for loop numbers 12,18
      CALL ML5_0_LOOP_4(2,5,4,6,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,10)
C     CutTools call for loop numbers 13,14
      CALL ML5_0_LOOP_3(2,6,9,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),2
     $ ,I_SO,11)
C     CutTools call for loop numbers 16,20
      CALL ML5_0_LOOP_4(2,4,6,5,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,12)
C     CutTools call for loop numbers 21,22,23
      CALL ML5_0_LOOP_3_4(1,1,2,2,6,5,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),1,I_SO,13)
C     CutTools call for loop numbers 24,121,139
      CALL ML5_0_LOOP_2(9,17,DCMPLX(ZERO),DCMPLX(ZERO),2,I_SO,14)
C     CutTools call for loop numbers 26,122,123,140,141
      CALL ML5_0_LOOP_3(4,5,17,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,15)
C     CutTools call for loop numbers 27,28,29
      CALL ML5_0_LOOP_2_3(1,2,4,5,17,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,16)
C     CutTools call for loop numbers 30,31,32
      CALL ML5_0_LOOP_2_3(1,2,5,4,17,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,17)
C     CutTools call for loop numbers 33,34,35
      CALL ML5_0_LOOP_2_3(2,1,5,4,17,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,18)
C     CutTools call for loop numbers 36,109
      CALL ML5_0_LOOP_2(11,19,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,19)
C     CutTools call for loop numbers 37
      CALL ML5_0_LOOP_2(10,20,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,20)
C     CutTools call for loop numbers 38,39
      CALL ML5_0_LOOP_3(5,11,10,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,21)
C     CutTools call for loop numbers 40
      CALL ML5_0_LOOP_2(8,21,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,22)
C     CutTools call for loop numbers 41
      CALL ML5_0_LOOP_2(10,22,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,23)
C     CutTools call for loop numbers 42
      CALL ML5_0_LOOP_3(3,10,8,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,24)
C     CutTools call for loop numbers 43,47
      CALL ML5_0_LOOP_3(2,5,21,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,25)
C     CutTools call for loop numbers 44,120
      CALL ML5_0_LOOP_3(2,3,19,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,26)
C     CutTools call for loop numbers 45
      CALL ML5_0_LOOP_4(2,3,5,10,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,27)
C     CutTools call for loop numbers 46
      CALL ML5_0_LOOP_4(2,5,3,10,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,28)
C     CutTools call for loop numbers 48
      CALL ML5_0_LOOP_4(2,3,10,5,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,29)
C     CutTools call for loop numbers 49
      CALL ML5_0_LOOP_2(11,23,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,30)
C     CutTools call for loop numbers 50
      CALL ML5_0_LOOP_2(12,24,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,31)
C     CutTools call for loop numbers 51,52
      CALL ML5_0_LOOP_3(4,11,12,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,32)
C     CutTools call for loop numbers 53
      CALL ML5_0_LOOP_2(7,25,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,33)
C     CutTools call for loop numbers 54
      CALL ML5_0_LOOP_2(12,26,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO,34)
C     CutTools call for loop numbers 55
      CALL ML5_0_LOOP_3(3,7,12,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,35)
C     CutTools call for loop numbers 56,60
      CALL ML5_0_LOOP_3(2,4,25,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,36)
C     CutTools call for loop numbers 57
      CALL ML5_0_LOOP_3(2,3,23,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,37)
C     CutTools call for loop numbers 58
      CALL ML5_0_LOOP_4(2,3,4,12,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,38)
C     CutTools call for loop numbers 59
      CALL ML5_0_LOOP_4(2,4,3,12,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,39)
C     CutTools call for loop numbers 61
      CALL ML5_0_LOOP_4(2,3,12,4,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,40)
C     CutTools call for loop numbers 62,69
      CALL ML5_0_LOOP_3(1,4,20,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,41)
C     CutTools call for loop numbers 63,68
      CALL ML5_0_LOOP_4(1,4,5,11,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,42)
C     CutTools call for loop numbers 64,73
      CALL ML5_0_LOOP_3(1,5,24,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,43)
C     CutTools call for loop numbers 65,71
      CALL ML5_0_LOOP_4(1,5,4,11,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,44)
C     CutTools call for loop numbers 66,67
      CALL ML5_0_LOOP_3(1,11,9,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,45)
C     CutTools call for loop numbers 70,72
      CALL ML5_0_LOOP_4(1,4,11,5,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,46)
C     CutTools call for loop numbers 74,75,76
      CALL ML5_0_LOOP_3_4(1,1,2,1,11,5,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),1,I_SO,47)
C     CutTools call for loop numbers 77,97
      CALL ML5_0_LOOP_3(1,3,14,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,48)
C     CutTools call for loop numbers 78
      CALL ML5_0_LOOP_4(1,3,5,7,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,49)
C     CutTools call for loop numbers 79,82
      CALL ML5_0_LOOP_3(1,5,26,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,50)
C     CutTools call for loop numbers 80
      CALL ML5_0_LOOP_4(1,5,3,7,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,51)
C     CutTools call for loop numbers 81
      CALL ML5_0_LOOP_4(1,3,7,5,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,52)
C     CutTools call for loop numbers 83
      CALL ML5_0_LOOP_3(1,3,16,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,53)
C     CutTools call for loop numbers 84
      CALL ML5_0_LOOP_4(1,3,4,8,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,54)
C     CutTools call for loop numbers 85,88
      CALL ML5_0_LOOP_3(1,4,22,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,2,I_SO,55)
C     CutTools call for loop numbers 86
      CALL ML5_0_LOOP_4(1,4,3,8,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,56)
C     CutTools call for loop numbers 87
      CALL ML5_0_LOOP_4(1,3,8,4,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,57)
C     CutTools call for loop numbers 89
      CALL ML5_0_LOOP_5(1,2,4,5,3,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,58)
C     CutTools call for loop numbers 90
      CALL ML5_0_LOOP_5(1,2,5,4,3,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,59)
C     CutTools call for loop numbers 91
      CALL ML5_0_LOOP_5(1,2,3,5,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,60)
C     CutTools call for loop numbers 92
      CALL ML5_0_LOOP_5(1,2,5,3,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,61)
C     CutTools call for loop numbers 93
      CALL ML5_0_LOOP_5(1,2,3,4,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,62)
C     CutTools call for loop numbers 94
      CALL ML5_0_LOOP_5(1,2,4,3,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,63)
C     CutTools call for loop numbers 95
      CALL ML5_0_LOOP_4(1,2,9,3,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,64)
C     CutTools call for loop numbers 96
      CALL ML5_0_LOOP_4(1,2,3,9,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,65)
C     CutTools call for loop numbers 98
      CALL ML5_0_LOOP_4(1,3,2,9,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),3,I_SO,66)
C     CutTools call for loop numbers 99
      CALL ML5_0_LOOP_5(1,3,5,2,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,67)
C     CutTools call for loop numbers 100
      CALL ML5_0_LOOP_5(1,3,2,5,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,68)
C     CutTools call for loop numbers 101
      CALL ML5_0_LOOP_5(1,4,2,3,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,69)
C     CutTools call for loop numbers 102
      CALL ML5_0_LOOP_5(1,3,4,2,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,70)
C     CutTools call for loop numbers 103
      CALL ML5_0_LOOP_5(1,3,2,4,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,71)
C     CutTools call for loop numbers 104
      CALL ML5_0_LOOP_5(1,4,3,2,5,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO),4,I_SO,72)
C     CutTools call for loop numbers 105,106,107
      CALL ML5_0_LOOP_4_5(1,1,1,2,1,3,2,5,4,DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),DCMPLX(ZERO),2,I_SO,73)
C     CutTools call for loop numbers 108,124,146
      CALL ML5_0_LOOP_2(9,27,DCMPLX(ZERO),DCMPLX(ZERO),2,I_SO,74)
C     CutTools call for loop numbers 110,125,126,147,148
      CALL ML5_0_LOOP_3(4,5,27,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,75)
C     CutTools call for loop numbers 111,112,113
      CALL ML5_0_LOOP_2_3(1,2,4,5,27,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,76)
C     CutTools call for loop numbers 114,115,116
      CALL ML5_0_LOOP_2_3(1,2,5,4,27,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,77)
C     CutTools call for loop numbers 117,118,119
      CALL ML5_0_LOOP_2_3(2,1,5,4,27,DCMPLX(ZERO),DCMPLX(ZERO),1,I_SO
     $ ,78)
C     CutTools call for loop numbers 127,137,153,163
      CALL ML5_0_LOOP_3(3,5,30,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,79)
C     CutTools call for loop numbers 128,135,154,161
      CALL ML5_0_LOOP_3(3,4,31,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,80)
C     CutTools call for loop numbers 129,133,155,159
      CALL ML5_0_LOOP_4(3,4,5,29,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),4,I_SO,81)
C     CutTools call for loop numbers 130,136,156,162
      CALL ML5_0_LOOP_4(3,5,4,29,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),4,I_SO,82)
C     CutTools call for loop numbers 131,132,157,158
      CALL ML5_0_LOOP_3(3,29,9,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,83)
C     CutTools call for loop numbers 134,138,160,164
      CALL ML5_0_LOOP_4(3,4,29,5,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,DCMPLX(ZERO),4,I_SO,84)
C     CutTools call for loop numbers 142,143,165,166
      CALL ML5_0_LOOP_3(3,5,32,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,85)
C     CutTools call for loop numbers 144,145,167,168
      CALL ML5_0_LOOP_3(3,4,33,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,86)
C     CutTools call for loop numbers 149,150,169,170
      CALL ML5_0_LOOP_3(3,5,34,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,87)
C     CutTools call for loop numbers 151,152,171,172
      CALL ML5_0_LOOP_3(3,4,35,DCMPLX(ZERO),DCMPLX(ZERO),DCMPLX(ZERO)
     $ ,3,I_SO,88)
C     CutTools call for loop numbers 173,183
      CALL ML5_0_LOOP_3(3,5,30,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,89)
C     CutTools call for loop numbers 174,181
      CALL ML5_0_LOOP_3(3,4,31,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,90)
C     CutTools call for loop numbers 175,179
      CALL ML5_0_LOOP_4(3,4,5,29,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),DCMPLX(MDL_MB),4,I_SO,91)
C     CutTools call for loop numbers 176,182
      CALL ML5_0_LOOP_4(3,5,4,29,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),DCMPLX(MDL_MB),4,I_SO,92)
C     CutTools call for loop numbers 177,178
      CALL ML5_0_LOOP_3(3,29,9,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,93)
C     CutTools call for loop numbers 180,184
      CALL ML5_0_LOOP_4(3,4,29,5,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),DCMPLX(MDL_MB),4,I_SO,94)
C     CutTools call for loop numbers 185
      CALL ML5_0_LOOP_2(9,17,DCMPLX(MDL_MB),DCMPLX(MDL_MB),2,I_SO,95)
C     CutTools call for loop numbers 186,187
      CALL ML5_0_LOOP_3(4,5,17,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,96)
C     CutTools call for loop numbers 188,189
      CALL ML5_0_LOOP_3(3,5,32,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,97)
C     CutTools call for loop numbers 190,191
      CALL ML5_0_LOOP_3(3,4,33,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,98)
C     CutTools call for loop numbers 192
      CALL ML5_0_LOOP_2(9,27,DCMPLX(MDL_MB),DCMPLX(MDL_MB),2,I_SO,99)
C     CutTools call for loop numbers 193,194
      CALL ML5_0_LOOP_3(4,5,27,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,100)
C     CutTools call for loop numbers 195,196
      CALL ML5_0_LOOP_3(3,5,34,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,101)
C     CutTools call for loop numbers 197,198
      CALL ML5_0_LOOP_3(3,4,35,DCMPLX(MDL_MB),DCMPLX(MDL_MB)
     $ ,DCMPLX(MDL_MB),3,I_SO,102)
C     CutTools call for loop numbers 199,209
      CALL ML5_0_LOOP_3(3,5,30,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,103)
C     CutTools call for loop numbers 200,207
      CALL ML5_0_LOOP_3(3,4,31,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,104)
C     CutTools call for loop numbers 201,205
      CALL ML5_0_LOOP_4(3,4,5,29,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),DCMPLX(MDL_MT),4,I_SO,105)
C     CutTools call for loop numbers 202,208
      CALL ML5_0_LOOP_4(3,5,4,29,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),DCMPLX(MDL_MT),4,I_SO,106)
C     CutTools call for loop numbers 203,204
      CALL ML5_0_LOOP_3(3,29,9,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,107)
C     CutTools call for loop numbers 206,210
      CALL ML5_0_LOOP_4(3,4,29,5,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),DCMPLX(MDL_MT),4,I_SO,108)
C     CutTools call for loop numbers 211
      CALL ML5_0_LOOP_2(9,17,DCMPLX(MDL_MT),DCMPLX(MDL_MT),2,I_SO,109)
C     CutTools call for loop numbers 212,213
      CALL ML5_0_LOOP_3(4,5,17,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,110)
C     CutTools call for loop numbers 214,215
      CALL ML5_0_LOOP_3(3,5,32,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,111)
C     CutTools call for loop numbers 216,217
      CALL ML5_0_LOOP_3(3,4,33,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,112)
C     CutTools call for loop numbers 218
      CALL ML5_0_LOOP_2(9,27,DCMPLX(MDL_MT),DCMPLX(MDL_MT),2,I_SO,113)
C     CutTools call for loop numbers 219,220
      CALL ML5_0_LOOP_3(4,5,27,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,114)
C     CutTools call for loop numbers 221,222
      CALL ML5_0_LOOP_3(3,5,34,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,115)
C     CutTools call for loop numbers 223,224
      CALL ML5_0_LOOP_3(3,4,35,DCMPLX(MDL_MT),DCMPLX(MDL_MT)
     $ ,DCMPLX(MDL_MT),3,I_SO,116)
C     At this point, all reductions needed for (QCD=6), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 5000

      GOTO 1001
 5000 CONTINUE
      CTCALL_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END

