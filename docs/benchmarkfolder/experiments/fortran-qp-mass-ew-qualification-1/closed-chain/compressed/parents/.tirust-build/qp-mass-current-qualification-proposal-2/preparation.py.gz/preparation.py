"""Pure derivation and verification against the complete frozen actual CLI family."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def require(value,message):
    if not value:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
def local(name):
    spec=importlib.util.spec_from_file_location('mgmass_prepare_'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);return module


def derive():
    row=read(HERE/'input-pins.json')['cases']['n3'];output=Path(row['output']);proc=output/'SubProcesses'/row['subprocess']
    original={name:(proc/name).read_text() for name in ('CT_interface.f','TIRUST_interface.f','loop_CT_calls_1.f')}
    matrix=local('materialize');new,proof=matrix.candidate(original['CT_interface.f'],original['TIRUST_interface.f'],
        original['loop_CT_calls_1.f'],(output/'Source/MODEL/mp_coupl.inc').read_text())
    plain_driver=local('drivers').worker((proc/'check_sa.f').read_text(),local('driver_base'),False)
    observed_driver=local('drivers').worker((proc/'check_sa.f').read_text(),local('driver_base'),True)
    variants={'original':{**original,'check_sa.f':plain_driver},'candidate':{**new,'check_sa.f':plain_driver},
        'original-observed':{**matrix.observed(original,0),'check_sa.f':observed_driver},
        'candidate-observed':{**matrix.observed(new,1),'check_sa.f':observed_driver}}
    for name,body in matrix.routines(original['CT_interface.f']).items():
        require(matrix.routines(new['CT_interface.f'])[name]==body,'Existing CT/LOOP routine changed')
    for name,body in matrix.routines(original['TIRUST_interface.f']).items():
        require(matrix.routines(new['TIRUST_interface.f'])[name]==body,'Existing TIRust routine changed')
    card=(output/'Cards/MadLoopParams.dat').read_text()
    require(card.count('#TIRustGlobalCache\n-1\n')==1,'Original explicit cache−1 card expected')
    cards={'cacheall.dat':card,'cache0.dat':card.replace('#TIRustGlobalCache\n-1\n','#TIRustGlobalCache\n0\n')}
    def entries(text):
        result={};lines=text.splitlines()
        for i,line in enumerate(lines):
            if line.startswith('#') and line[1:].strip() and ' ' not in line[1:].strip():
                values=[s.strip() for s in lines[i+1:] if s.strip() and not s.lstrip().startswith(('!','#'))]
                require(values,'Missing card value');result[line[1:].strip()]=values[0]
        return result
    for name,text in cards.items():
        values=entries(text)
        for key,wanted in {'MLReductionLib':'9','CTModeRun':'-1','LoopPoleMode':'0',
                           'UseQPIntegrandForTIRust':'.true.','TIRustComputeFinite':'.true.'}.items():
            require(values[key].lower()==wanted.lower(),'Required physical policy differs:'+key)
    proof['complete_original_source_bindings']=len(row['generated_sources'])
    proof['original_numerical_object_bindings']=len(row['numerical_objects'])
    proof['actual_CLI_generation_sha256']=sha(output/'generation.json')
    proof['current_n3_mass_arguments']={name:sum(m['model_symbol']==name for g in proof['groups'] for m in g['mass_pairs'])
        for name in ('ZERO','MDL_MB','MDL_MT')}
    require(proof['complete_original_source_bindings']==195 and proof['original_numerical_object_bindings']==144 and
            proof['current_n3_mass_arguments']=={'ZERO':293,'MDL_MB':43,'MDL_MT':43},'Complete process/model family differs')
    return variants,proof,cards


def verify_materialized():
    variants,proof,cards=derive()
    require(read(HERE/'source-proof.json')==proof,'Full actual process derivation changed')
    for variant,files in variants.items():
        for name,text in files.items():require((HERE/'source-preview'/variant/name).read_text()==text,'Materialized source changed:'+variant+'/'+name)
    for name,text in cards.items():require((HERE/'cards'/name).read_text()==text,'Materialized card changed:'+name)
    return {'actual_CLI_groups':len(proof['groups']),'helper_families':len(proof['helpers']),
        'complete_source_bindings':195,'original_object_bindings':144,'source_and_policy_rederived':True,
        'compiler_calls':0,'native_calls':0}


def prepare():
    require(not (HERE/'source-preview').exists(),'Source materialization is exclusive')
    variants,proof,cards=derive()
    for variant,files in variants.items():
        for name,text in files.items():
            path=HERE/'source-preview'/variant/name;path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('x') as stream:stream.write(text)
    for name,text in cards.items():
        path=HERE/'cards'/name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('x') as stream:stream.write(text)
    dump(HERE/'source-proof.json',proof)
    patch=''.join(''.join(difflib.unified_diff(variants['original'][name].splitlines(keepends=True),
        variants['candidate'][name].splitlines(keepends=True),fromfile='original/'+name,tofile='candidate/'+name))
        for name in variants['original'])
    with (HERE/'actual-process.patch').open('x') as stream:stream.write(patch)
    print(json.dumps(verify_materialized(),indent=2))


if __name__=='__main__':prepare()
