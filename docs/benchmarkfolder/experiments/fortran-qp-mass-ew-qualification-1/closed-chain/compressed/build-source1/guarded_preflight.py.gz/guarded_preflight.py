"""Run the real default file-only preflight with scientific/mutation effects denied."""
import argparse,builtins,ctypes,fcntl,importlib.util,json,os,resource,signal,socket,subprocess,sys
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--reviewed-source');p.add_argument('--reviewed-source-sha');a=p.parse_args()
 spec=importlib.util.spec_from_file_location('_guarded_ew_build_controller',HERE/'controller.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
 m.SOURCE=a.source;m.REVIEW_PATH=a.reviewed_source;m.REVIEW_SHA=a.reviewed_source_sha;attempts=[];real_import=builtins.__import__;real_open=builtins.open
 def denied(*args,**kwargs):attempts.append('effect');raise AssertionError('Forbidden source-preflight effect')
 def imported(name,*args,**kwargs):
  if name.split('.')[0] in {'madgraph','models','aloha','tirust_benchmark','tirust_benchmark_worker'}:return denied()
  return real_import(name,*args,**kwargs)
 def opened(file,mode='r',*args,**kwargs):
  if any(x in mode for x in 'wax+'):return denied()
  return real_open(file,mode,*args,**kwargs)
 with ExitStack() as stack:
  for obj,names in ((subprocess,('Popen','run','check_call','check_output','call')),(os,('system','fork','posix_spawn','posix_spawnp','kill','killpg','chdir','mkdir','makedirs','remove','unlink','rename','replace')),(socket,('socket','create_connection')),(ctypes,('CDLL','PyDLL')),(signal,('signal','setitimer')),(resource,('setrlimit',)),(fcntl,('flock',)),(Path,('write_text','write_bytes','mkdir','unlink','rename','replace','symlink_to'))):
   for name in names:
    if hasattr(obj,name):stack.enter_context(patch.object(obj,name,denied))
  stack.enter_context(patch.object(builtins,'open',opened));stack.enter_context(patch.object(builtins,'__import__',imported))
  result=m.preflight()
  if attempts:raise AssertionError('Forbidden attempts occurred')
 print(json.dumps({'status':'passed','forbidden_API_attempts':attempts,'preflight':result},sort_keys=True))
if __name__=='__main__':main()
