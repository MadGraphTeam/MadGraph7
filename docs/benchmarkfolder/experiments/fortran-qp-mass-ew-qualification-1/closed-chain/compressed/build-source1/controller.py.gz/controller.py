#!/usr/bin/env python3
"""Dormant actual-EW BUILD only; no scientific main or later RUN entry."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import sys
import time
BOOTSTRAP_STARTED=time.monotonic()
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/ew-qp-mass-build-work-1'
REPORT=ROOT/'.tirust-build/ew-qp-mass-build-execution-1'
PROC='SubProcesses/P0_epem_ttxa'
ROLES=('original','candidate')
CPU,CAP,CLEANUP=12,1800.,60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
SOURCE=None
REVIEW_PATH=None
REVIEW_SHA=None

def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def pins():return read(HERE/'input-pins.json')
def dump(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def check(p,row):
    require(Path(p).is_file() and ident(p)=={k:row[k] for k in ('bytes','sha256')},'Changed bound input: '+str(p))
def load(name,path):
    path=Path(path)
    if not path.is_relative_to(HERE):
        key=str(path.relative_to(ROOT));check(path,pins()['support_files'][key])
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def local(name):return load('_ew_build_'+name,HERE/(name+'.py'))
def support(name):return load('_ew_build_support_'+name,ROOT/pins()['support_paths'][name])
def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']
def environment():
    p=pins();return local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),p['compiler_environment_names'],{},p['library_paths'])
def sources(output):
    output=Path(output)
    return {str(p.relative_to(output)):ident(p) for subtree in ('Source','SubProcesses') for p in sorted((output/subtree).rglob('*')) if p.is_file()
        and (p.suffix.lower() in {'.f','.f90','.for','.inc','.c','.cc','.h'} or p.name.startswith('makefile') or p.name in ('make_opts','MadLoop_makefile_definitions'))}
def stock_objects(output):return {str(p.relative_to(output)):ident(p) for p in sorted((Path(output)/'Source').rglob('*.o')) if p.is_file()}
def stock_modules(output):return {str(p.relative_to(output)):ident(p) for p in sorted((Path(output)/'Source').rglob('*.mod')) if p.is_file()}
def data_files(output):
    output=Path(output);found={str(p.relative_to(output)):ident(p) for tree in ('Cards','Source','SubProcesses') for p in (output/tree).rglob('*.dat') if p.is_file()}
    resource=output/PROC/'MadLoop5_resources'
    for p in resource.rglob('*.dat'):
        if p.is_file():found[str(p.relative_to(output))]=ident(p)
    return found

def canonical_libraries(output):
    # Explicit leaves: rglob does not traverse library-directory aliases.
    return {name:ident(Path(output)/name) for name in ('lib/libcts.a','lib/libiregi.a','lib/libdhelas.a','lib/libmodel.a','lib/mpmodule.mod')}

def verify_source():
    require(Path.cwd()==ROOT and SOURCE and digest(HERE/'source-index.json')==SOURCE,'Exact source seal and repository cwd required')
    index=read(HERE/'source-index.json');actual=set()
    for p in HERE.rglob('*'):
        require(not p.is_symlink(),'Proposal aliases forbidden')
        if p.is_file():actual.add(str(p.relative_to(HERE)))
    require(actual==set(index['files'])|{'source-index.json'},'Proposal payload inventory changed')
    for n,row in index['files'].items():
        require(not Path(n).is_absolute() and '..' not in Path(n).parts,'Unsafe proposal name');check(HERE/n,row)
    for n,row in pins()['support_files'].items():check(ROOT/n,row)
    for n,row in pins()['protected_files'].items():check(n,row)

def protected():
    p=pins();cloning=local('cloning');summaries={}
    for role,row in p['roles'].items():
        check(row['terminal']['path'],row['terminal']);check(row['result']['path'],row['result']);check(row['generation_log']['path'],row['generation_log'])
        terminal=read(row['terminal']['path']);result=read(row['result']['path']);output=Path(row['output'])
        require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['result_sha256']==row['result']['sha256'],'GEN not cleanly closed')
        require(result['status']=='generated_pending_source_review' and result['source_index_sha256']==p['generation_source_index_sha256'] and result['role']==role
            and result['overlaid_candidate']==(role=='candidate') and result['actual_CLI_invocations']==1 and result['amplitude_evaluations']==0,'Wrong GEN identity/scope')
        require(sources(output)==row['sources']==result['source_inventory'] and stock_objects(output)==row['stock_objects'] and stock_modules(output)==row['support_modules'],'GEN source/support outputs changed')
        require(canonical_libraries(output)==row['canonical_libraries'] and cloning.links(output)==row['aliases'],'GEN library/alias changed')
        cloning.validate_shared(output,row['shared_aliases'])
        require(not any((output/'SubProcesses').rglob('*.o')) and not any((output/'SubProcesses').rglob('check')),'GEN unexpectedly compiled process/executable')
        for n,w in row['cards'].items():check(output/n,w)
        require(data_files(output)==row['data_files'],'GEN cards/static resource data changed')
        for n,m in row['support_object_source_map'].items():
            require(m['source_sha256']==row['sources'][m['source']]['sha256'] and m['object']==row['stock_objects'][n] and Path(n).stem==Path(m['source']).stem,'Support source/object mapping changed')
        for n,m in row['support_module_producers'].items():
            require(m['object'] in row['stock_objects'] and m['source'] in row['sources'],'Support module producer missing')
        summaries[role]={'source_inputs':len(row['sources']),'support_objects':len(row['stock_objects']),'support_modules':len(row['support_modules']),'canonical_leaves':len(row['canonical_libraries'])}
    require(p['roles']['original']['stock_objects']==p['roles']['candidate']['stock_objects'] and p['roles']['original']['support_modules']==p['roles']['candidate']['support_modules'],'Role stock objects/modules differ')
    for n,row in p['external_compile_inputs'].items():check(n,row)
    check(ROOT/p['expected_actual_source_review']['path'],p['expected_actual_source_review'])
    for n,h in p['expected_runtime']['files'].items():require(digest(n)==h,'Pinned runtime provider changed')
    for n,row in p['frozen_inputs'].items():check(HERE/row['path'],row)
    local('tool_environment').validate(read(HERE/'toolchain-pins.json'),environment())
    return {'roles':summaries,'support_objects_byte_equal':True,'support_modules_byte_equal':True,'runtime_providers':len(p['expected_runtime']['files']),'native_calls':0,'compiler_queries':0,'loader_queries':0}

def reviewed_source():
    require(REVIEW_PATH and REVIEW_SHA,'Actual independent EW generated-source review required before BUILD')
    name=Path(REVIEW_PATH);require(not name.is_absolute() and '..' not in name.parts and str(name).startswith('.tirust-build/'),'Review gate path must be ignored/repository-contained')
    path=ROOT/name;require(not path.is_symlink() and path.resolve().is_relative_to(ROOT/'.tirust-build') and digest(path)==REVIEW_SHA,'Root source admission changed/escaped')
    gate=local('policy').source_gate(read(path),pins());review=ROOT/gate['independent_review_path']
    require(not review.is_symlink() and review.resolve().is_relative_to(ROOT/'.tirust-build') and digest(review)==gate['independent_review_sha256'],'Independent source review missing/changed/escaped')
    return gate

def preflight():
    verify_source();summary=protected();require(CPU in os.sched_getaffinity(0),'Nonexclusive CPU12 unavailable')
    gate=reviewed_source() if REVIEW_PATH or REVIEW_SHA else None
    return {'status':'source-only-preflight-passed','source_index_sha256':SOURCE,'protected':summary,'actual_source_review_supplied':gate is not None,'BUILD_admitted_by_preflight':False,
        'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,'limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'new_native_calls':0,'new_compiler_queries':0,'new_loader_queries':0}

def command(argv,cwd,logs,name):
    logs=Path(logs);logs.mkdir(parents=True,exist_ok=True);argv=list(map(str,argv));env=environment();env['PWD']=str(cwd)
    dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd),'controller_pid':os.getpid(),'session':os.getsid(0),'process_group':os.getpgrp(),'new_session':False})
    with (logs/(name+'.stdout.txt')).open('xb') as out:done=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))})
    require(done.returncode==0,'BUILD command failed; no retry: '+name)
    return (logs/(name+'.stdout.txt')).read_text()

def capture_policy(directory,logs,label):
    old=support('legacy_controller');old.environment=environment
    # This existing helper journals make/version requests and imports no model.
    return old.capture_policy(directory,logs,label)

def verify_policy(value):
    require(value['environment']=={},'Compiler injection appeared')
    expected=pins()['reference_policy']['policy_classes'];require(set(value['scopes'])==set(expected),'Compiler scopes differ')
    for scope,row in value['scopes'].items():
        actual={tuple(r['flags']) for r in row['recipes'].values()};require(actual=={tuple(x) for x in expected[scope]},'Original numerical policy classes differ: '+scope)
        for recipe in row['recipes'].values():
            require(len(recipe['compiler'])==1 and recipe['compiler'][0]['sha256']==read(HERE/'toolchain-pins.json')['required_tools']['gfortran']['sha256'],'Wrong effective compiler identity')
    return True

def clone_role(role):
    row=pins()['roles'][role];output=WORK/'build'/role
    local('cloning').clone(row['output'],output,row['aliases'],row['shared_aliases']);case=output/PROC
    require(sources(output)==row['sources'] and stock_objects(output)==row['stock_objects'] and stock_modules(output)==row['support_modules'] and canonical_libraries(output)==row['canonical_libraries'],'Private initial clone differs')
    (case/'check_sa.f').write_bytes((HERE/'check_sa.f').read_bytes());(case/'makefile').write_text(local('policy').private_makefile((case/'makefile').read_text()))
    card=(HERE/'inputs/cache0.dat').read_bytes()
    for name in row['cards']:
        if name.endswith('MadLoopParams.dat'):(output/name).write_bytes(card)
    require(digest(output/'Cards/param_card.dat')==pins()['frozen_inputs']['param_card.dat']['sha256'] and digest(output/'Cards/ident_card.dat')==row['cards']['Cards/ident_card.dat']['sha256'],'Private model/ident card changed')
    require(data_files(output)==row['data_files'],'Private card/static-resource expansion changed')
    return output

def build():
    before=protected();gate=reviewed_source();p=pins();results={};policies={};loader=support('loader');policy=local('policy');compiler=None
    for role in ROLES:
        output=clone_role(role);directory=output/PROC;row=p['roles'][role];logs=REPORT/'build'/role/'commands'
        expected=dict(row['sources']);expected[PROC+'/check_sa.f']=ident(HERE/'check_sa.f');expected[PROC+'/makefile']=ident(directory/'makefile')
        require(sources(output)==expected,'Private BUILD changed an unselected input')
        before_policy=capture_policy(directory,logs,'policy-before');verify_policy(before_policy)
        expanded=command([tool('make'),'--no-print-directory','--dry-run','--always-make','SHELL='+tool('bash'),'check'],directory,logs,'expanded-check')
        recipes,link=policy.select_commands(expanded,tool('gfortran'),row['linked_sources'])
        order={n:i for i,(n,_) in enumerate(recipes)}
        require(all(order['polynomial.f']<order[n] for n in row['polynomial_module_users']),'Polynomial module compile order differs')
        generated={};compile_inputs=[];compile_row={**row,'expected_build_sources':expected}
        for i,(name,argv) in enumerate(recipes):
            inputs=local('compile_inputs').bind(directory/name,argv,output,compile_row,p,generated)
            dump(REPORT/'build'/role/'compile-inputs'/f'{i:03d}-{name}.json',inputs);compile_inputs.append(inputs)
            command(argv,directory,logs,f'compile-{i:03d}-'+name)
            if name=='polynomial.f':
                module=(directory/'ml5_0_polynomial_constants.mod').resolve();require(module.is_file(),'Fresh polynomial module missing');generated[str(module)]=ident(module)

        pre=loader.prelink(link,directory,environment(),lambda a,n:command(a,directory,logs,n))
        for path,h in p['expected_runtime']['files'].items():
            require(digest(path)==h and pre['bound'].get(path,h)==h,'Runtime/prelink changed or conflicted');pre['bound'][path]=h
        dump(REPORT/'build'/role/'prelink.json',pre)
        command(link,directory,logs,'link');exe=directory/'check';mapfile=directory/'private-link.map'
        loads=loader.requireactualmap(mapfile.read_text(),directory,pre,exe)
        static=support('runtime').derive(exe,pre,p['expected_runtime']['files'],environment()['LD_LIBRARY_PATH'])
        dump(REPORT/'build'/role/'static-runtime.json',static)
        runtime=loader.query_runtime(exe,p['expected_runtime']['files'],pre,lambda a,n:command(a,directory,logs,n))
        nm=command([tool('nm'),'--defined-only','check'],directory,logs,'symbols');names=[x.split()[-1] for x in nm.splitlines() if len(x.split())>=3]
        require({n:names.count(n) for n in names if '__mtirust_MOD_' in n}=={n:1 for n in p['expected_mtirust_symbols']},'Installed wrapper ownership differs')
        require({n:names.count(n) for n in names if '_qpmass_' in n}=={n:1 for n in row['expected_private_symbols']},'Private QP-mass ownership differs')
        require(not (directory/'mtirust.o').exists() and 'libtirust.a(' in mapfile.read_text(),'Original installed Fortran wrapper archive not retained')
        after_policy=capture_policy(directory,logs,'policy-after');verify_policy(after_policy)
        if compiler is None:compiler=support('compiler')
        compiler.validate_compiler_equality(before_policy,after_policy);policies[role]=after_policy
        require(stock_objects(output)==row['stock_objects'] and stock_modules(output)==row['support_modules'] and canonical_libraries(output)==row['canonical_libraries'],'Unselected stock object/module/library changed')
        require(sources(output)==expected and data_files(output)==row['data_files'],'BUILD mutated unselected sources/cards/static resources')
        require({p.name for p in directory.glob('*.mod')}=={'mpmodule.mod','ml5_0_polynomial_constants.mod'} and ident(directory/'mpmodule.mod')==row['canonical_libraries']['lib/mpmodule.mod'],'Process module input/output closure differs')
        results[role]={'output':str(output),'sources':sources(output),'stock_objects':stock_objects(output),'stock_modules':stock_modules(output),'canonical_libraries':canonical_libraries(output),
            'actual_compile_inputs':compile_inputs,'private_data':data_files(output),'process_modules':{str(p.relative_to(output)):ident(p) for p in sorted(directory.glob('*.mod'))},'compiled_process_sources':[n for n,_ in recipes],'selected_recipes':recipes,'process_objects':{str(p.relative_to(output)):ident(p) for p in sorted(directory.glob('*.o'))},
            'compiler_flags':after_policy,'executable_sha256':digest(exe),'link_command':link,'actual_link_loads':loads,'link_map_sha256':digest(mapfile),'prelink_sha256':digest(REPORT/'build'/role/'prelink.json'),
            'static_runtime_sha256':digest(REPORT/'build'/role/'static-runtime.json'),'runtime':runtime,'MTIRUST_definitions':p['expected_mtirust_symbols'],'private_definitions':row['expected_private_symbols'],
            'native_main_calls':0,'support_objects_source_environment_provenance':True,'support_GEN_child_commands_individually_journalled':False}
    compiler.validate_compiler_equality(policies['original'],policies['candidate'])
    require(protected()==before,'Protected GEN/source/tool/runtime bindings changed')
    dump(REPORT/'build/result.json',{'status':'passed','stage':'build','source_index_sha256':SOURCE,'source_review_admission_sha256':REVIEW_SHA,'source_review':gate,'variants':results,
        'native_amplitude_calls':0,'model_probes':0,'reducer_calls':0,'RUN_admitted':False,'candidate_promoted':False,'performance_acceptance':False})

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        v=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=v,'Inherited hard limit too low');resource.setrlimit(kind,(v,v))
def child():
    row=read(REPORT/'build/admission.json');require(row['parent_pid']==os.getppid() and row['source_index_sha256']==SOURCE and row['review_path']==REVIEW_PATH and row['review_sha256']==REVIEW_SHA,'Exact supervisor admission required')
    require(os.sched_getaffinity(0)=={CPU},'Child affinity differs')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limits differ')
    verify_source();reviewed_source();build()

def supervise():
    end=BOOTSTRAP_STARTED+CAP;cleanup=support('cleanup');ownership=local('ownership');directory=REPORT/'build';directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':'build','source_index_sha256':SOURCE,'review_path':REVIEW_PATH,'review_sha256':REVIEW_SHA,'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'original_end_monotonic':end,'status':'running'}
    process=None;raw_record=None;owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAP,absolute_end=end) as deadline:
            limits();verify_source();protected();reviewed_source();requests.check();require(not (WORK/'build').exists(),'Fresh build required; no retry')
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B','-I',str(HERE/'controller.py'),'--source',SOURCE,'--reviewed-source',REVIEW_PATH,'--reviewed-source-sha',REVIEW_SHA,'--child']
            dump(directory/'admission.json',{**entry,'parent_pid':os.getpid(),'command':argv});process_env=environment()
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=process_env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['child_pid']=process.pid;dump(directory/'started.json',entry);entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'BUILD failed; no retry')
            verify_source();protected();reviewed_source();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'));dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=ownership.cleanup_owned(owned,end) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,end)
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));dump(directory/'terminal.json',entry);raise

def main():
    global SOURCE,REVIEW_PATH,REVIEW_SHA
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--execute',action='store_true');p.add_argument('--reviewed-source');p.add_argument('--reviewed-source-sha');p.add_argument('--child',action='store_true',help=argparse.SUPPRESS)
    a=p.parse_args();SOURCE=a.source;REVIEW_PATH=a.reviewed_source;REVIEW_SHA=a.reviewed_source_sha
    require(bool(REVIEW_PATH)==bool(REVIEW_SHA),'Source review path/hash must be paired');verify_source()
    if a.child:child()
    elif a.execute:
        reviewed_source()
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise()
    else:print(json.dumps(preflight(),sort_keys=True))
if __name__=='__main__':main()
