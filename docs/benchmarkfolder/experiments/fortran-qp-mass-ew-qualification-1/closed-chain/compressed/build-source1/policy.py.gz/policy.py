"""Pure selection of the unchanged generated process build and source gate."""
from pathlib import Path
import fnmatch
import json
import re
import shlex

def require(ok,message):
    if not ok:raise ValueError(message)

def inventory_digest(inventory):
    import hashlib
    return hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def source_gate(value,pins):
    required={'schema','source_qualified','generated_text_accepted','qualification_scope','generation_source_index_sha256','generation_terminals',
              'generated_inventory_digests','independent_review_path','independent_review_sha256','findings'}
    require(isinstance(value,dict) and set(value)==required,'Exact reviewed-source gate schema required')
    require(value['schema']=='ew-qp-mass-generated-source-admission-v1' and value['source_qualified'] is False
        and value['generated_text_accepted'] is True and value['qualification_scope']=='generated-text-correspondence-only' and value['findings']==[],'Actual EW source correspondence has not cleared')
    require(value['generation_source_index_sha256']==pins['generation_source_index_sha256'],'Wrong generation source')
    require(value['generation_terminals']=={role:pins['roles'][role]['terminal']['sha256'] for role in pins['roles']},'Wrong GEN terminals')
    require(value['generated_inventory_digests']=={role:inventory_digest(pins['roles'][role]['sources']) for role in pins['roles']},'Wrong reviewed EW source inventories')
    path=Path(value['independent_review_path']);h=value['independent_review_sha256']
    require(not path.is_absolute() and '..' not in path.parts and str(path).startswith('.tirust-build/'),'Review path must be ignored/repository-contained')
    require(isinstance(h,str) and re.fullmatch('[0-9a-f]{64}',h),'Full independent review SHA256 required')
    require(value['independent_review_path']==pins['expected_actual_source_review']['path'] and value['independent_review_sha256']==pins['expected_actual_source_review']['sha256'],'Wrong actual EW correspondence review')
    return value

def process_sources(makefile,names):
    require(len(re.findall(r'(?m)^PROCESS\s*=',makefile))==1 and len(re.findall(r'(?m)^OLP_PROCESS\s*=',makefile))==1,'Unexpected PROCESS declaration')
    text=re.split(r'(?m)^PROCESS\s*=\s*',makefile,maxsplit=1)[1].split('OLP_PROCESS=',1)[0]
    initial=text.splitlines()[0].replace('\\','').split()
    require(initial==['MadLoopParamReader.o','MadLoopCommons.o'],'Unexpected literal PROCESS roots')
    patterns=re.findall(r'\$\(wildcard ([A-Za-z0-9_*?.-]+\.f)\)',text)
    require(patterns and len(patterns)==len(set(patterns)),'Missing/duplicate PROCESS wildcard')
    stripped=re.sub(r'\$\(patsubst \$\(DOTF\),\$\(DOTO\),\$\(wildcard [A-Za-z0-9_*?.-]+\.f\)\)','',text)
    stripped=stripped.replace('MadLoopParamReader.o','').replace('MadLoopCommons.o','').replace('\\','').strip()
    require(not stripped,'Unparsed PROCESS expression')
    sources=['MadLoopParamReader.f','MadLoopCommons.f']
    for pattern in patterns:sources.extend(sorted(n for n in names if fnmatch.fnmatchcase(n,pattern)))
    require(len(sources)==len(set(sources)) and all(n in names for n in sources),'Duplicate/missing linked source')
    return ['check_sa.f',*sources]

def private_makefile(text):
    old='$(FC) $(FFLAGS) -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)'
    new='$(FC) $(FFLAGS) -Wl,-Map,private-link.map,--cref -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)'
    require(text.count(old)==1,'Unique original check link recipe required')
    return text.replace(old,new,1)

def select_commands(text,compiler,expected):
    selected=[];seen=set();links=[]
    objects=[str(Path(n).with_suffix('.o')) for n in expected]
    for line in text.replace('\\\n',' ').splitlines():
        argv=shlex.split(line)
        if not argv:continue
        sources=[a for a in argv if not a.startswith('-') and Path(a).suffix.lower() in {'.f','.for','.f90','.f95','.f03','.f08'}]
        outputs=[argv[i+1] for i,a in enumerate(argv[:-1]) if a=='-o']
        relevant=any(Path(a).name in expected for a in sources) or ('-c' not in argv and outputs==['check'])
        if not relevant:continue
        require(argv[0]==compiler and not any(a in {';','&&','||','|','>','>>','<','&'} or a.startswith('@') for a in argv),'Wrong/compound selected compiler command')
        require(argv.count('-o')==1 and len(outputs)==1 and not any(a=='-J' or a.startswith('-J') for a in argv),'Unadmitted output/module path')
        if '-c' in argv:
            require(argv.count('-c')==1 and len(sources)==1 and sources[0] in expected,'Unexpected selected source')
            name=sources[0];require(name not in seen and outputs==[str(Path(name).with_suffix('.o'))],'Duplicate/wrong process compile')
            seen.add(name);selected.append((name,argv))
        else:
            require(not sources and '-ltirust' in argv and '-lmadloop_tirust' in argv,'Original backend9 link closure missing')
            require([a for a in argv if a.endswith('.o')]==objects,'Selected link object order differs from generated PROCESS')
            require('mtirust.o' not in argv and '-Wl,-Map,private-link.map,--cref' in argv,'Installed wrapper/map policy differs')
            links.append(argv)
    require(seen==set(expected) and len(links)==1,'Incomplete exact process build closure')
    return selected,links[0]

def module_definitions(text):
    # Only module declarations, never USE or MODULE PROCEDURE statements.
    return re.findall(r'(?im)^\s*module\s+(?!procedure\b|function\b|subroutine\b)([a-z][a-z0-9_]*)\s*(?:!.*)?$',text)
