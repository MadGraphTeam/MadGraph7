"""Meaningful pure controls for the dormant actual-EW build packet."""
from copy import deepcopy
from contextlib import ExitStack
from pathlib import Path
import ctypes,importlib.util,io,json,os,resource,signal,socket,subprocess,sys,unittest
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True

def load(name):
 s=importlib.util.spec_from_file_location('_ew_build_test_'+name,HERE/(name+'.py'));m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
P=load('policy');D=load('compile_inputs');C=load('cloning');B=load('controller')
def expect_error(fn):
 try:fn()
 except (ValueError,TypeError,KeyError):return
 raise AssertionError('Expected refusal')

def gate_fixture():
 p={'generation_source_index_sha256':'a'*64,'roles':{'original':{'terminal':{'sha256':'b'*64},'sources':{'x':{'bytes':1,'sha256':'c'*64}}},'candidate':{'terminal':{'sha256':'d'*64},'sources':{'x':{'bytes':1,'sha256':'e'*64}}}},'expected_actual_source_review':{'path':'.tirust-build/review.json','sha256':'f'*64}}
 g={'schema':'ew-qp-mass-generated-source-admission-v1','source_qualified':False,'generated_text_accepted':True,'qualification_scope':'generated-text-correspondence-only','generation_source_index_sha256':p['generation_source_index_sha256'],'generation_terminals':{r:v['terminal']['sha256'] for r,v in p['roles'].items()},'generated_inventory_digests':{r:P.inventory_digest(v['sources']) for r,v in p['roles'].items()},'independent_review_path':p['expected_actual_source_review']['path'],'independent_review_sha256':'f'*64,'findings':[]}
 return p,g

class GateTests(unittest.TestCase):
 def test_exact_text_scope(self):
  p,g=gate_fixture();self.assertEqual(P.source_gate(g,p),g)
 def test_full_source_qualification_not_invented(self):
  p,g=gate_fixture();g['source_qualified']=True;expect_error(lambda:P.source_gate(g,p))
 def test_acceptance_required(self):
  p,g=gate_fixture();g['generated_text_accepted']=False;expect_error(lambda:P.source_gate(g,p))
 def test_no_findings(self):
  p,g=gate_fixture();g['findings']=['unclassified'];expect_error(lambda:P.source_gate(g,p))
 def test_exact_gen_source(self):
  p,g=gate_fixture();g['generation_source_index_sha256']='0'*64;expect_error(lambda:P.source_gate(g,p))
 def test_both_terminals(self):
  p,g=gate_fixture();g['generation_terminals']['candidate']='0'*64;expect_error(lambda:P.source_gate(g,p))
 def test_exact_inventory(self):
  p,g=gate_fixture();g['generated_inventory_digests']['original']='0'*64;expect_error(lambda:P.source_gate(g,p))
 def test_exact_independent_review(self):
  p,g=gate_fixture();g['independent_review_sha256']='0'*64;expect_error(lambda:P.source_gate(g,p))
 def test_safe_review_path(self):
  p,g=gate_fixture();g['independent_review_path']='../outside';expect_error(lambda:P.source_gate(g,p))
 def test_exact_gate_keys(self):
  p,g=gate_fixture();g['RUN_admitted']=True;expect_error(lambda:P.source_gate(g,p))

class PolicyTests(unittest.TestCase):
 def test_generated_process(self):
  text='PROCESS= MadLoopParamReader.o MadLoopCommons.o \\\n $(patsubst $(DOTF),$(DOTO),$(wildcard polynomial.f)) \\\n $(patsubst $(DOTF),$(DOTO),$(wildcard loop*.f))\n\nOLP_PROCESS= unused\n'
  names={'MadLoopParamReader.f','MadLoopCommons.f','polynomial.f','loop_b.f','loop_a.f','unlinked.f'}
  self.assertEqual(P.process_sources(text,names),['check_sa.f','MadLoopParamReader.f','MadLoopCommons.f','polynomial.f','loop_a.f','loop_b.f'])
 def test_unparsed_process_refused(self):
  expect_error(lambda:P.process_sources('PROCESS= MadLoopParamReader.o MadLoopCommons.o $(shell echo p.o)\nOLP_PROCESS=x',{'MadLoopParamReader.f','MadLoopCommons.f'}))
 def test_link_patch_only_map(self):
  a='$(FC) $(FFLAGS) -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)';b=P.private_makefile(a)
  self.assertEqual(b.replace(' -Wl,-Map,private-link.map,--cref',''),a)
 def test_duplicate_link_refused(self):
  a='$(FC) $(FFLAGS) -o $(PROG) check_sa.o $(PROCESS) $(LINKLIBS)';expect_error(lambda:P.private_makefile(a+'\n'+a))
 def commands(self):
  return ['/fc -w -c polynomial.f -o polynomial.o','/fc -w -c check_sa.f -o check_sa.o','/fc -w -c CT_interface.f -o CT_interface.o','/fc -w -Wl,-Map,private-link.map,--cref -o check check_sa.o polynomial.o CT_interface.o -ltirust -lmadloop_tirust']
 def test_actual_compile_order_preserved(self):
  r,l=P.select_commands('\n'.join(self.commands()),'/fc',['check_sa.f','polynomial.f','CT_interface.f']);self.assertEqual([n for n,a in r],['polynomial.f','check_sa.f','CT_interface.f'])
 def test_wrong_link_order_refused(self):
  rows=self.commands();rows[-1]=rows[-1].replace('check_sa.o polynomial.o','polynomial.o check_sa.o');expect_error(lambda:P.select_commands('\n'.join(rows),'/fc',['check_sa.f','polynomial.f','CT_interface.f']))
 def test_compound_compiler_refused(self):
  rows=self.commands();rows[0]+=' ; touch unsafe';expect_error(lambda:P.select_commands('\n'.join(rows),'/fc',['check_sa.f','polynomial.f','CT_interface.f']))
 def test_module_output_escape_refused(self):
  rows=self.commands();rows[0]+=' -J/outside';expect_error(lambda:P.select_commands('\n'.join(rows),'/fc',['check_sa.f','polynomial.f','CT_interface.f']))
 def test_duplicate_compile_refused(self):
  rows=self.commands();rows.insert(1,rows[0]);expect_error(lambda:P.select_commands('\n'.join(rows),'/fc',['check_sa.f','polynomial.f','CT_interface.f']))
 def test_module_declarations_not_use_or_procedure(self):
  self.assertEqual(P.module_definitions('      MODULE M\n      MODULE PROCEDURE f\n      USE elsewhere\n      END MODULE M\n'),['M'])

class DependencyTests(unittest.TestCase):
 def test_include_literal_case_and_spaces(self):self.assertEqual(D.directives("      INCLUDE 'Case Sensitive.inc'\n"),[('include','Case Sensitive.inc')])
 def test_inserted_type_continuation_not_include(self):self.assertEqual(D.directives("      INCLUDE 'cts_mpc.h'\n     $ ,INTENT(IN) :: Q\n"),[('include','cts_mpc.h')])
 def test_intrinsic_use(self):self.assertEqual(D.directives('      USE, INTRINSIC :: IEEE_EXCEPTIONS\n'),[('module','ieee_exceptions')])
 def test_use_only_continuation(self):self.assertEqual(D.directives('      USE MTIRUST, ONLY: A,\n     $ B\n'),[('module','mtirust')])
 def test_nonliteral_include_refused(self):expect_error(lambda:D.directives('      INCLUDE NAME\n'))
 def test_continued_dependency_literal_refused(self):expect_error(lambda:D.directives("      INCLUDE 'long\n     $ file.inc'\n"))
 def test_shared_alias_writes_refused(self):
  expect_error(lambda:C.writable('lib/ninjars_lib/new.mod'));expect_error(lambda:C.writable('../outside'));C.writable('Source/MODEL/x.o')
 def test_no_broad_shared_allowance(self):self.assertEqual(C.SHARED,{'lib/ninjars_include','lib/ninjars_lib'});self.assertEqual(C.CAP,512*1024**2)

if __name__=='__main__':unittest.main(verbosity=2)
