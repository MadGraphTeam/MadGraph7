"""Guarded synthetic adversarial controls; no generated EW output is read."""
import builtins
from contextlib import ExitStack
import ctypes
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import socket
import subprocess
import sys
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PROPOSAL=HERE

def main():
    effects=[]
    def denied(*args,**kwargs):effects.append(repr(args[:1]));raise AssertionError('Forbidden effect during independent pure review')
    original_import=builtins.__import__
    def imports(name,*args,**kwargs):
        if name.split('.')[0] in {'madgraph','mg5decay','aloha','MadSpin','madmatrix','PLUGIN'}:return denied(name)
        return original_import(name,*args,**kwargs)
    with ExitStack() as outer:
        for module,name in ((subprocess,'Popen'),(subprocess,'run'),(subprocess,'check_output'),(ctypes,'CDLL'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve'),(resource,'setrlimit'),(signal,'signal'),(signal,'setitimer'),(fcntl,'flock'),(socket,'socket'),(socket,'create_connection')):outer.enter_context(patch.object(module,name,side_effect=denied))
        outer.enter_context(patch.object(builtins,'__import__',side_effect=imports))
        spec=importlib.util.spec_from_file_location('_ew_independent_fixture',PROPOSAL/'test_review.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t);r=t.r;P=t.P
        results={}
        with ExitStack() as pure:
            for name in ('open','read_bytes','read_text','write_bytes','write_text','stat','exists','resolve','glob','rglob','iterdir','is_file','is_dir'):pure.enter_context(patch.object(Path,name,side_effect=denied))
            def run(label,edit):
                old,new=t.fixture();edit(old,new);report=r.analyze(old,new)
                results[label]={'narrow_checks_passed':report['narrow_checks_passed'],'source_qualified':report['source_qualified'],'BUILD_admitted':report['BUILD_admitted'],'findings':report['findings'],'verified_guarded_calls':report['verified_guarded_calls'],'verified_DP_MP_mass_pair_counts':report['verified_DP_MP_mass_pair_counts'],'raw_changed_files':report['raw_changed_files']}
                return report
            files={P+'case.f':t.f("INCLUDE 'MP_COUPL.INC'").encode(),'Source/MODEL/mp_coupl.inc':t.f('REAL*16 MP__MDL_MT').encode()}
            edges=r.include_edges(files,[P+'case.f'])
            results['include_literal_case_is_lost']={'source_literal':'MP_COUPL.INC','exact_case_candidate_key_present':False,'reported_edges':edges}
            def remove_include(old,new):
                for mapping in (old,new):mapping[P+'loop_CT_calls_1.f']=mapping[P+'loop_CT_calls_1.f'].replace(t.f("INCLUDE 'mp_coupl.inc'").encode(),b'')
            run('missing_caller_MP_include_is_accepted',remove_include)
            def foreign(old,new):
                for mapping in (old,new):
                    mapping['Source/MODEL/mp_coupl.inc']=t.f('REAL*16 OTHER').encode()
                    mapping[P+'unrelated.f']=t.f('SUBROUTINE UNRELATED()','REAL*16 MP__MDL_MT','END').encode()
            run('unrelated_unit_MP_declaration_is_accepted',foreign)
            def dimension(old,new):
                for mapping in (old,new):mapping['Source/MODEL/mp_coupl.inc']=t.f('REAL*16 OTHER(MP__MDL_MT)').encode()
            run('dimension_reference_is_treated_as_MP_declaration',dimension)
            def wrong_zero(old,new):
                for mapping in (old,new):mapping[P+'loop_CT_calls_1.f']=mapping[P+'loop_CT_calls_1.f'].replace(b'REAL*16 MP__ZERO',b'INTEGER MP__ZERO')
            run('integer_local_zero_parameter_is_accepted',wrong_zero)
            def no_common(old,new):new[P+'loop_CT_calls_1.f']=new[P+'loop_CT_calls_1.f'].replace(t.COMMON.encode(),b'')
            report=run('guard_without_CTMode_COMMON_is_accepted',no_common)
            results['guard_without_CTMode_COMMON_is_accepted']['reported_common_additions']=report['split_and_common_checks'][P+'loop_CT_calls_1.f']['CT_common_additions']
            def metadata(old,new):
                old['Source/make_opts']=b'DEFAULT_F_COMPILER=gfortran\n';new['Source/make_opts']=b'DEFAULT_F_COMPILER=unexplained_alternate\n'
            run('unexplained_metadata_has_no_finding',metadata)
            literal_line=t.f("MESSAGE='a literal with  spaces'").encode()
            continued_a=b"      MESSAGE='a literal with\n     $    spaces'\n"
            continued_b=b"      MESSAGE='a literal with\n     $          spaces'\n"
            def continuation(old,new):
                old[P+'TIRUST_interface.f']=old[P+'TIRUST_interface.f'].replace(literal_line,continued_a)
                original,private=new[P+'TIRUST_interface.f'].split(t.PRIVATE_DIAG.encode(),1)
                original=original.replace(literal_line,continued_a)
                private_diag=t.PRIVATE_DIAG.encode().replace(literal_line,continued_b)
                new[P+'TIRUST_interface.f']=original+private_diag+private
            run('continued_literal_payload_blanks_collapse',continuation)
            results['continued_literal_payload_blanks_collapse']['different_raw_literal_records']=continued_a!=continued_b
            try:r.logical(continued_a.decode());r.logical(continued_b.decode())
            except ValueError as error:results['continued_literal_payload_blanks_collapse']['explicit_unsupported_literal']=str(error)
            else:raise AssertionError('Continued quoted literals must be refused explicitly')
            def label(old,new):new[P+'CT_interface.f']=new[P+'CT_interface.f'].replace(b'      MP_M2L(1)=MP_M2**2',b'12345 MP_M2L(1)=MP_M2**2')
            run('changed_statement_label_is_refused',label)
            try:list(r.fixed.logical_blocks("      X=F(A,\nC     comment between continuation records\n     $ B)\n"))
            except ValueError as error:results['intervening_comment_continuation_fails_closed']={'error':str(error),'structured_analyze_report_not_guaranteed':True}
            else:results['intervening_comment_continuation_fails_closed']={'nonliteral_continuation_comment_explicitly_supported':True,'logical':r.logical("      X=F(A,\nC     comment between continuation records\n     $ B)\n")}
            try:r.fixed.routines(t.f('SUBROUTINE A()','END SUBROUTINE B'))
            except ValueError as error:results['unsupported_named_END_name_validation']={'explicit_refusal':str(error),'input_has_mismatched_END_name':True}
            else:raise AssertionError('Mismatched named END must be refused')
            negative=('missing_caller_MP_include_is_accepted','unrelated_unit_MP_declaration_is_accepted','dimension_reference_is_treated_as_MP_declaration','integer_local_zero_parameter_is_accepted','guard_without_CTMode_COMMON_is_accepted','unexplained_metadata_has_no_finding','continued_literal_payload_blanks_collapse','changed_statement_label_is_refused')
            if any(results[name]['narrow_checks_passed'] for name in negative):raise AssertionError('A source1 adversarial counterexample still passes')
            edge=results['include_literal_case_is_lost']['reported_edges'][0]
            if edge['include']!='MP_COUPL.INC' or not edge['unresolved_in_source_inventory']:raise AssertionError('Exact-case include control still passes falsely')
        if effects:raise AssertionError('Unexpected effects: '+repr(effects))
    print(json.dumps({'source_only':True,'effects_attempted':effects,'normal_or_optimized':not __debug__,'synthetic_controls':results},indent=2,sort_keys=True))
if __name__=='__main__':main()
