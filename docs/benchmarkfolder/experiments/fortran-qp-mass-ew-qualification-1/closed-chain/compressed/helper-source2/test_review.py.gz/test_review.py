"""Synthetic source-only checks. No actual future EW outputs or counts assumed."""
import builtins
import importlib.util
import os
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_ew_review_tested',HERE/'review.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
P='SubProcesses/P0_epem_ttxa/'

def f(*statements):
    result=[]
    for statement in statements:
        first=True
        while len(statement)>110:
            at=statement.rfind(',',0,110)+1
            if not at:raise ValueError('Synthetic statement must provide comma wrapping')
            result.append(('      ' if first else '     $ ')+statement[:at]+'\n');statement=statement[at:];first=False
        result.append(('      ' if first else '     $ ')+statement+'\n')
    return ''.join(result)

OLD=f('SUBROUTINE P_LOOP_2(W1,W2,M1,M2,RANK,SQUAREDSOINDEX,LOOPNUM)','COMPLEX*16 M1,M2','COMPLEX*16 M2L(NLOOPLINE)','M2L(1)=M2**2','M2L(2)=M1**2','DOING_QP=(CTMODE.GE.4)','CALL P_CHOOSE_LOOPLIB(LIBINDEX,NLOOPLINE,RANK,COMPLEX_MASS,ID,DOING_QP,I_LIB)','IF(MLREDUCTIONLIB(I_LIB).EQ.8)THEN','CALL P_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L,RANK,RES,S)','ELSEIF(MLREDUCTIONLIB(I_LIB).EQ.9.AND.DOING_QP)THEN','CALL P_MP_TIRUST_LOOP(NLOOPLINE,MP_PL,M2L,RANK,RES,S)','ENDIF','END')
NEW=f('SUBROUTINE P_LOOP_2_QPMASS(W1,W2,M1,MP_M1,M2,MP_M2,RANK,SQUAREDSOINDEX,LOOPNUM)','COMPLEX*16 M1,M2','COMPLEX*32 MP_M1,MP_M2','COMPLEX*16 M2L(NLOOPLINE)','COMPLEX*32 MP_M2L(NLOOPLINE)','M2L(1)=M2**2','M2L(2)=M1**2','IF(CTMODE.LT.4)THEN','CALL P_LOOP_2(W1,W2,M1,M2,RANK,SQUAREDSOINDEX,LOOPNUM)','RETURN','ENDIF','DOING_QP=(CTMODE.GE.4)','CALL P_CHOOSE_LOOPLIB(LIBINDEX,NLOOPLINE,RANK,COMPLEX_MASS,ID,DOING_QP,I_LIB)','IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.9)THEN','MP_M2L(1)=MP_M2**2','MP_M2L(2)=MP_M1**2','ENDIF','IF(MLREDUCTIONLIB(I_LIB).EQ.8)THEN','CALL P_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L,RANK,RES,S)','ELSEIF(MLREDUCTIONLIB(I_LIB).EQ.9.AND.DOING_QP)THEN','CALL P_MP_TIRUST_LOOP_QPMASS(NLOOPLINE,MP_PL,MP_M2L,RANK,RES,S)','ENDIF','END')
DIAG=f('SUBROUTINE P_MP_TIRUST_TENSOR_DIAGNOSTIC(CTMODE,NLOOPLINE,RANK,PL,M2L,TIRCOEFS,STABLE)','COMPLEX*16 M2L(NLOOPLINE)',"MESSAGE='a literal with  spaces'",'END')
LOOP=f('SUBROUTINE P_MP_TIRUST_LOOP(NLOOPLINE,PL,M2L,RANK,RES,STABLE)','COMPLEX*16 M2L(NLOOPLINE)','CALL P_MP_TIRUST_TENSOR_DIAGNOSTIC(CTMODE,NLOOPLINE,RANK,PL,M2L,TIRCOEFS,STABLE)','END')
PRIVATE_DIAG=DIAG.replace('P_MP_TIRUST_TENSOR_DIAGNOSTIC(','P_MP_TIRUST_TENSOR_DIAGNOSTIC_QPMASS(').replace('COMPLEX*16 M2L','COMPLEX*32 M2L')
PRIVATE_LOOP=LOOP.replace('P_MP_TIRUST_LOOP(','P_MP_TIRUST_LOOP_QPMASS(').replace('COMPLEX*16 M2L','COMPLEX*32 M2L').replace('P_MP_TIRUST_TENSOR_DIAGNOSTIC(','P_MP_TIRUST_TENSOR_DIAGNOSTIC_QPMASS(')
CALL=f('CALL P_LOOP_2(W1,W2,DCMPLX(MDL_MT),DCMPLX(ZERO),RANK,I_SO,1)')
QPCALL=f('IF(CTMODE.LT.4)THEN','CALL P_LOOP_2(W1,W2,DCMPLX(MDL_MT),DCMPLX(ZERO),RANK,I_SO,1)','ELSE','CALL P_LOOP_2_QPMASS(W1,W2,DCMPLX(MDL_MT),CMPLX(MP__MDL_MT,KIND=16),DCMPLX(ZERO),CMPLX(MP__ZERO,KIND=16),RANK,I_SO,1)','ENDIF')
HEAD=f('SUBROUTINE P_CT_CALLS(P,NHEL,H,IC)',"INCLUDE 'coupl.inc'", "INCLUDE 'mp_coupl.inc'",'REAL*16 MP__ZERO','PARAMETER(MP__ZERO=0.0E0_16)')
COMMON=f('REAL*8 LSCALE','INTEGER CTMODE','COMMON/P_CT/LSCALE,CTMODE')


def fixture(calls=1):
    original={P+'CT_interface.f':OLD.encode(),P+'TIRUST_interface.f':(DIAG+LOOP).encode(),P+'loop_CT_calls_1.f':(HEAD+CALL*calls+f('END')).encode(),'Source/MODEL/mp_coupl.inc':f('REAL*16 MP__MDL_MT').encode(),'Source/MODEL/coupl.inc':f('REAL*8 MDL_MT').encode(),P+'NINJARS_interface.f':f('SUBROUTINE OTHER()','END').encode()}
    candidate=dict(original);candidate[P+'CT_interface.f']=(OLD+NEW).encode();candidate[P+'TIRUST_interface.f']=(DIAG+LOOP+PRIVATE_DIAG+PRIVATE_LOOP).encode();candidate[P+'loop_CT_calls_1.f']=(HEAD.replace(f("INCLUDE 'coupl.inc'"),f("INCLUDE 'coupl.inc'")+COMMON)+QPCALL*calls+f('END')).encode()
    return original,candidate

class ReviewTests(unittest.TestCase):
    def checked(self,changes=None,calls=1):
        old,new=fixture(calls)
        if changes:changes(old,new)
        return r.analyze(old,new)
    def test_valid_source_only_pair_counts_come_from_actual_bytes(self):
        result=self.checked();self.assertTrue(result['narrow_checks_passed']);self.assertEqual(result['actual_public_units'],3);self.assertEqual(result['actual_private_helpers'],3);self.assertEqual(result['verified_guarded_calls'],1);self.assertEqual(result['verified_DP_MP_mass_pair_counts'],{'MDL_MT':1,'ZERO':1});self.assertFalse(result['source_qualified']);self.assertFalse(result['BUILD_admitted'])
    def test_second_actual_call_changes_counts(self):
        result=self.checked(calls=2);self.assertTrue(result['narrow_checks_passed']);self.assertEqual(result['verified_guarded_calls'],2);self.assertEqual(result['verified_DP_MP_mass_pair_counts'],{'MDL_MT':2,'ZERO':2})
    def test_private_cyclic_order_change_is_refused(self):
        def change(a,b):b[P+'CT_interface.f']=b[P+'CT_interface.f'].replace(b'MP_M2L(1)=MP_M2**2',b'MP_M2L(1)=MP_M1**2')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_wrong_selected_backend_is_refused(self):
        def change(a,b):b[P+'CT_interface.f']=b[P+'CT_interface.f'].replace(b'IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.9)',b'IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.8)')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_non9_mass_policy_change_is_refused(self):
        def change(a,b):b[P+'CT_interface.f']=b[P+'CT_interface.f'].replace(b'P_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,M2L',b'P_MP_NINJARS_LOOP(NLOOPLINE,MP_PL,MP_M2L')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_public_comment_bytes_are_strict(self):
        def change(a,b):b[P+'CT_interface.f']=b[P+'CT_interface.f'].replace(b'      COMPLEX*16 M1,M2\n',b'C     a new comment\n      COMPLEX*16 M1,M2\n',1)
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_private_literal_bytes_are_preserved(self):
        def change(a,b):b[P+'TIRUST_interface.f']=b'a literal with spaces'.join(b[P+'TIRUST_interface.f'].rsplit(b'a literal with  spaces',1))
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_qp_wrong_symbol_or_kind_is_refused(self):
        for old,new in [(b'MP__MDL_MT,KIND=16',b'MP__MDL_MW,KIND=16'),(b'MP__MDL_MT,KIND=16',b'MP__MDL_MT,KIND=8')]:
            def change(a,b):b[P+'loop_CT_calls_1.f']=b[P+'loop_CT_calls_1.f'].replace(old,new)
            self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_missing_guard_in_unchanged_caller_is_refused(self):
        def change(a,b):b[P+'loop_CT_calls_1.f']=a[P+'loop_CT_calls_1.f']
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_common_width_change_is_refused(self):
        def change(a,b):b[P+'loop_CT_calls_1.f']=b[P+'loop_CT_calls_1.f'].replace(b'REAL*8 LSCALE',b'REAL*16 LSCALE')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_missing_declared_mp_symbol_is_refused(self):
        def change(a,b):a['Source/MODEL/mp_coupl.inc']=f('REAL*16 OTHER').encode();b['Source/MODEL/mp_coupl.inc']=a['Source/MODEL/mp_coupl.inc']
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_comment_cannot_declare_an_mp_model_symbol(self):
        def change(a,b):a['Source/MODEL/mp_coupl.inc']=b'C     MP__MDL_MT is only a comment\n';b['Source/MODEL/mp_coupl.inc']=a['Source/MODEL/mp_coupl.inc']
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_other_public_adapter_must_remain_raw_exact(self):
        def change(a,b):b[P+'NINJARS_interface.f']=f('SUBROUTINE OTHER()','X=1','END').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_raw_unknown_scientific_addition_is_reported(self):
        def change(a,b):b['Source/MODEL/new.inc']=b'new'
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_balanced_arguments_preserve_nested_literals(self):
        self.assertEqual(r.arguments("A,CMPLX(X,KIND=16),'a,b',F(G(1),2)"),['A','CMPLX(X,KIND=16)',"'a,b'",'F(G(1),2)'])
        for value in ['A,F(1','A,,B',"A,'bad"]:
            with self.assertRaises(ValueError):r.arguments(value)
    def test_analyze_is_file_process_and_import_free(self):
        old,new=fixture();attempts=[];original=builtins.__import__
        def denied(*args,**kwargs):attempts.append('effect');raise AssertionError('Forbidden effect')
        def imports(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','mg5decay','aloha','MadSpin','madmatrix','PLUGIN'}:return denied()
            return original(name,*args,**kwargs)
        with patch.object(Path,'open',side_effect=denied),patch.object(Path,'read_bytes',side_effect=denied),patch.object(Path,'write_text',side_effect=denied),patch.object(subprocess,'Popen',side_effect=denied),patch.object(os,'system',side_effect=denied),patch.object(builtins,'__import__',side_effect=imports):result=r.analyze(old,new)
        self.assertTrue(result['narrow_checks_passed']);self.assertEqual(attempts,[])

class StrictSuccessorTests(unittest.TestCase):
    checked=ReviewTests.checked
    def test_missing_caller_mp_include_rejected_even_if_file_exists(self):
        def change(a,b):
            for files in (a,b):files[P+'loop_CT_calls_1.f']=files[P+'loop_CT_calls_1.f'].replace(f("INCLUDE 'mp_coupl.inc'").encode(),b'')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_unrelated_procedure_cannot_supply_typed_mp_mass(self):
        def change(a,b):
            for files in (a,b):
                files['Source/MODEL/mp_coupl.inc']=f('REAL*16 OTHER').encode();files[P+'unrelated.f']=f('SUBROUTINE UNRELATED()','REAL*16 MP__MDL_MT','END').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_other_unit_in_same_file_cannot_supply_mp_mass(self):
        def change(a,b):
            for files in (a,b):
                files['Source/MODEL/mp_coupl.inc']=f('REAL*16 OTHER').encode();files[P+'loop_CT_calls_1.f']+=f('SUBROUTINE UNRELATED()','REAL*16 MP__MDL_MT','END').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_mp_dimension_reference_is_not_declarator(self):
        def change(a,b):
            for files in (a,b):files['Source/MODEL/mp_coupl.inc']=f('REAL*16 OTHER(MP__MDL_MT)').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_mp_rhs_reference_is_not_declarator(self):
        def change(a,b):
            for files in (a,b):files['Source/MODEL/mp_coupl.inc']=f('REAL*16 OTHER=MP__MDL_MT').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_mp_array_is_not_scalar_mass(self):
        def change(a,b):
            for files in (a,b):files['Source/MODEL/mp_coupl.inc']=f('REAL*16 MP__MDL_MT(1)').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_integer_zero_parameter_is_not_real16_zero(self):
        def change(a,b):
            for files in (a,b):files[P+'loop_CT_calls_1.f']=files[P+'loop_CT_calls_1.f'].replace(b'REAL*16 MP__ZERO',b'INTEGER MP__ZERO')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_wrong_zero_value_is_rejected(self):
        def change(a,b):
            for files in (a,b):files[P+'loop_CT_calls_1.f']=files[P+'loop_CT_calls_1.f'].replace(b'MP__ZERO=0.0E0_16',b'MP__ZERO=1.0E0_16')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_no_typed_ct_common_rejected(self):
        def change(a,b):b[P+'loop_CT_calls_1.f']=b[P+'loop_CT_calls_1.f'].replace(COMMON.encode(),b'')
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_preexisting_typed_ct_common_qualifies_without_new_copy(self):
        def change(a,b):a[P+'loop_CT_calls_1.f']=a[P+'loop_CT_calls_1.f'].replace(f("INCLUDE 'coupl.inc'").encode(),(f("INCLUDE 'coupl.inc'")+COMMON).encode())
        self.assertTrue(self.checked(change)['narrow_checks_passed'])
    def test_integer_CTMode_parameter_is_not_mutable_common_member(self):
        def change(a,b):
            for files in (a,b):files[P+'loop_CT_calls_1.f']=files[P+'loop_CT_calls_1.f'].replace(f("INCLUDE 'mp_coupl.inc'").encode(),f("INCLUDE 'mp_coupl.inc'",'PARAMETER(CTMODE=4)').encode())
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_include_case_does_not_resolve_lowercase_file(self):
        files={P+'case.f':f("INCLUDE 'MP_COUPL.INC'").encode(),'Source/MODEL/mp_coupl.inc':f('REAL*16 MP__MDL_MT').encode()};edge=r.include_edges(files,[P+'case.f'])[0]
        self.assertEqual(edge['include'],'MP_COUPL.INC');self.assertTrue(edge['unresolved_in_source_inventory']);self.assertEqual(edge['candidate_search_matches'],[])
    def test_exact_uppercase_include_key_resolves(self):
        def change(a,b):
            for files in (a,b):
                files['Source/MODEL/MP_COUPL.INC']=files.pop('Source/MODEL/mp_coupl.inc');files[P+'loop_CT_calls_1.f']=files[P+'loop_CT_calls_1.f'].replace(b"'mp_coupl.inc'",b"'MP_COUPL.INC'")
        self.assertTrue(self.checked(change)['narrow_checks_passed'])
    def test_transitive_exact_include_supplies_typed_mass(self):
        def change(a,b):
            for files in (a,b):files['Source/MODEL/masses.inc']=files['Source/MODEL/mp_coupl.inc'];files['Source/MODEL/mp_coupl.inc']=f("INCLUDE 'masses.inc'").encode()
        self.assertTrue(self.checked(change)['narrow_checks_passed'])
    def test_ambiguous_shadow_include_stays_open(self):
        def change(a,b):
            for files in (a,b):files[P+'mp_coupl.inc']=f('REAL*16 OTHER').encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_recursive_include_stays_open(self):
        def change(a,b):
            for files in (a,b):files['Source/MODEL/mp_coupl.inc']=f("INCLUDE 'mp_coupl.inc'").encode()
        self.assertFalse(self.checked(change)['narrow_checks_passed'])
    def test_continued_quoted_literal_is_explicitly_unsupported(self):
        def change(a,b):
            for files in (a,b):files[P+'TIRUST_interface.f']=files[P+'TIRUST_interface.f'].replace(f("MESSAGE='a literal with  spaces'").encode(),b"      MESSAGE='a literal with\n     $    spaces'\n")
        report=self.checked(change);self.assertFalse(report['narrow_checks_passed']);self.assertIn('Unsupported quoted literal',report['findings'][0])
    def test_comments_between_nonliteral_continuations_are_handled(self):
        rows=r.logical("      X=F(A,\nC     ordinary comment\n     $ B)\n");self.assertEqual(rows,[('', 'X=F(A,B)')])
    def test_directive_between_continuations_is_unsupported(self):
        with self.assertRaisesRegex(ValueError,'Unsupported directive'):r.logical("      X=F(A,\nC$    directive\n     $ B)\n")
    def test_named_END_mismatch_is_refused(self):
        with self.assertRaisesRegex(ValueError,'Named END identifier'):r.fixed.routines(f('SUBROUTINE A()','END SUBROUTINE B'))
    def test_named_END_matching_is_supported(self):
        self.assertEqual(list(r.fixed.routines(f('SUBROUTINE A()','END SUBROUTINE A'))),['A'])
    def test_unexplained_build_metadata_is_a_finding(self):
        def change(a,b):a['Source/make_opts']=b'DEFAULT_F_COMPILER=gfortran\n';b['Source/make_opts']=b'DEFAULT_F_COMPILER=unexplained\n'
        report=self.checked(change);self.assertFalse(report['narrow_checks_passed']);self.assertTrue(any('metadata delta' in item for item in report['findings']))

if __name__=='__main__':unittest.main(verbosity=2)
