# Strict file-only generated-source reviewer2

SOURCE ONLY. Helper1 `4c7ea157...` and its blocked independent review
`7f260554...` remain immutable. This successor addresses R1–R5; it changes no
GEN source/output, production, reference, installed dependency or public file.
No actual EW outputs are read during preparation or these tests. No CLI,
compiler, model, reducer, native library, installer or Git operation runs.

The two actual EW GEN receipts remain `generated_pending_source_review`.
This helper creates neither source qualification nor BUILD/RUN admission.
Its pure API accepts already authenticated raw source-byte mappings; the CLI
adapter only reads source/build inputs and prints JSON. Future independent
review must first bind every actual input to the closed GEN receipts.

The original selected-edit checklist remains: exact public legacy CT/TIRust
bodies, unchanged other scientific source, actual added private helper families,
paired DP/MP mass arguments, exact early-DP delegation, unchanged legacy DP
mass policy, actual CHOOSE_LOOPLIB before actual9-only cyclic QP squares,
private tensor formal/target changes only, complete caller guards, same labels,
literals and statement/control order. Counts derive from actual supplied bytes,
never an assumed EW/QCD count. Original requests, observed private calls and
verified guards/model pairs remain distinct on failures.

R1: INCLUDE literals retain exact spelling/case. Candidate matches use exact
source keys, with all source-parent/SubProcesses/MODEL/DHELAS matches retained.
Missing exact keys, differing shadow contents and recursive includes remain
open. Equal-content aliases may supply the same declaration source; real
compiler -I order and external include closure remain separately unqualified.
No lowercasing can make MP_COUPL.INC resolve to mp_coupl.inc on Linux.

R2: typed declarations resolve separately inside each named caller routine,
through its own transitive exact include edges. Unrelated routines/files do
not supply declarations. Declarator names are parsed separately from array
bounds and initialization RHS tokens. Required MP masses are scalar REAL*16
or COMPLEX*32. MP__ZERO must specifically be REAL*16 and have an explicit
kind16 real-zero PARAMETER. An INTEGER zero or a bound/RHS-only name fails.
Unsupported declaration attributes and duplicated declarations remain open.

R3: every newly guarded routine must expose mutable scalar REAL*8 LSCALE,
INTEGER CTMODE and exactly its namespace COMMON/CT/LSCALE,CTMODE. The new
three-declaration insertion or an actual already-visible correctly typed
COMMON can satisfy this. Merely matching an expected body without the new
COMMON does not pass. Required declarations cannot come from another routine.

R4: the fresh narrow column132 parser preserves quoted payloads on supported
single physical records. Quoted literals spanning physical continuation
records are explicitly unsupported and refuse the entire narrow report;
no strip/join whitespace equivalence is claimed for them. Raw changed file
identities/diffs remain retained even on unsupported input. Ordinary comments
between nonliteral continuation records are handled explicitly. Directives
between continuation records, tab-based fixed-form layout, mismatched named
END and unsupported units fail closed. Matching named END is checked against
its active unit. Logical selected-edit diagnostics still ignore ordinary
comments/whitespace only outside supported quoted literals. Public unit
comparisons continue to use raw bytes; no Fortran semantic proof is claimed.

R5: every unexplained source/build metadata delta, including make_opts or
makefiles, creates an explicit open finding. Raw retention cannot leave
narrow_checks_passed=True. A real later path-only difference needs independent
explicit classification; this helper does not silently normalize it away.

The current lexer is a fresh strict successor, not an exact copy of the old
qualified QCD parser. Input metadata retains that historical parser origin and
blocked helper1 lineage without relabelling them as helper2 qualification.
Thirty-eight unique synthetic tests include all earlier16 controls plus22
strict scope/parser cases. The eleven independent source1 adversarial controls
are adapted only to expect explicit refusals or the documented nonliteral
comment support. Pure API probes block filesystem/process/loader/import and
resource/signal/mutex/network operations; they must attempt none.

A bounded additional parser-format control may read only selected already
closed QCD source/header texts. It is not EW data, a new numerical evaluation
or independent physical truth. No object/archive/binary is hashed by that
control; any retained counts apply only to its selected old QCD files.

After both actual GEN outputs and this helper are independently reviewed:

```text
<pinned Python> -B .tirust-build/ew-qp-mass-generated-source-review-proposal-2/review.py --original <actual-original-output> --candidate <actual-candidate-output>
```

Every result still sets source_qualified=False, BUILD_admitted=False and
semantic_equivalence_proven=False. A clean narrow report is evidence for the
independent source review; an open/unsupported result requires investigation.
No compiler/object/runtime/IEEE, constructor, tensor, physics, cache or timing
qualification follows. Formal precise timing remains Hua-Sheng's local TODO.
