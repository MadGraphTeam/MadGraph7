"""Pure, narrow fixed-form correspondence diagnostics; never an equivalence oracle."""
from collections import Counter
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_ew_fixed_source',HERE/'fixed_source.py');fixed=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixed)
spec=importlib.util.spec_from_file_location('_ew_typed_scope',HERE/'scope.py');scope_api=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope_api)
SUFFIXES={'.f','.f90','.for','.inc','.c','.cc','.h'}

def require(ok,message):
    if not ok:raise ValueError(message)
def identity(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def decode(data):
    require(isinstance(data,bytes),'Source reader must expose raw bytes');return data.decode('utf-8')
def logical(text):return [tuple(row) for row in fixed.logical_diagnostic(text)]
def arguments(text):
    result=[];start=0;depth=0;quote=None;i=0
    while i<len(text):
        ch=text[i]
        if quote:
            if ch==quote:
                if i+1<len(text) and text[i+1]==quote:i+=1
                else:quote=None
        elif ch in "'\"":quote=ch
        elif ch=='(':depth+=1
        elif ch==')':depth-=1;require(depth>=0,'Unbalanced actual arguments')
        elif ch==',' and depth==0:result.append(text[start:i]);start=i+1
        i+=1
    require(depth==0 and quote is None,'Unbalanced argument/literal');result.append(text[start:]);require(all(result),'Empty argument');return result

def header(text):
    rows=logical(text);match=re.fullmatch(r'SUBROUTINE(\w+)\((.*)\)',rows[0][1]);require(match is not None,'Expected subroutine header');return match[1],arguments(match[2])
def call(statement):
    match=re.fullmatch(r'CALL(\w+)\((.*)\)',statement);return (match[1],arguments(match[2])) if match else None

def delta(a,b,label):
    return {'original':identity(a),'candidate':identity(b),'raw_equal':a==b,'raw_diff':''.join(difflib.unified_diff(decode(a).splitlines(keepends=True),decode(b).splitlines(keepends=True),fromfile='original/'+label,tofile='candidate/'+label)) if a!=b else ''}

def helper_contract(old_text,new_text):
    """Exact label/literal/statement sequence after the explicitly listed edits."""
    name,formals=header(old_text);newname,newformals=header(new_text);require(newname==name+'_QPMASS','Private helper name changed')
    masses=[arg for arg in formals if re.fullmatch(r'M\d+',arg)];n=len(masses);require(masses==['M'+str(i) for i in range(1,n+1)] and n>0,'Unsupported mass formal layout')
    paired=[item for arg in formals for item in ([arg,'MP_'+arg] if arg in masses else [arg])];require(newformals==paired,'Paired helper argument order changed')
    old=logical(old_text);expected=[];inserted=Counter();selected=False
    for label,statement in old:
        if statement.startswith('SUBROUTINE'+name+'('):statement='SUBROUTINE'+newname+'('+','.join(paired)+')'
        if statement=='ENDSUBROUTINE'+name:statement='ENDSUBROUTINE'+newname
        if statement=='DOING_QP=(CTMODE.GE.4)':
            expected += [('', 'IF(CTMODE.LT.4)THEN'),('','CALL'+name+'('+','.join(formals)+')'),('','RETURN'),('','ENDIF')];inserted['DP_fallback']+=1
        parsed=call(statement)
        if parsed and parsed[0].endswith('MP_TIRUST_LOOP'):
            target,args=parsed;require(args[2]=='M2L','Legacy QP tensor mass actual changed');args[2]='MP_M2L';statement='CALL'+target+'_QPMASS('+','.join(args)+')';inserted['QP_TIRust_target']+=1
        expected.append((label,statement))
        if statement=='COMPLEX*16'+','.join(masses):expected.append(('', 'COMPLEX*32'+','.join('MP_'+m for m in masses)));inserted['MP_formals']+=1
        if statement=='COMPLEX*16M2L(NLOOPLINE)':expected.append(('', 'COMPLEX*32MP_M2L(NLOOPLINE)'));inserted['MP_mass_array']+=1
        if parsed and parsed[0].endswith('CHOOSE_LOOPLIB'):
            require(not selected,'Duplicate actual backend selection');selected=True
            expected.append(('', 'IF(DOING_QP.AND.MLREDUCTIONLIB(I_LIB).EQ.9)THEN'))
            expected += [('', 'MP_M2L('+str(i)+')=MP_M'+str(n if i==1 else i-1)+'**2') for i in range(1,n+1)]
            expected.append(('', 'ENDIF'));inserted['post_selection_cyclic_squares']+=1
    require(inserted==Counter(DP_fallback=1,QP_TIRust_target=1,MP_formals=1,MP_mass_array=1,post_selection_cyclic_squares=1),'Unsupported private-helper skeleton')
    actual=logical(new_text);return {'name':newname,'denominators':n,'checks_passed':expected==actual,'expected_logical':expected,'actual_logical':actual,'allowed_edits':['paired QP mass formals/array','early exact DP delegation','actual9-only post-selection cyclic QP squares','QP TIRust private target/mass actual'],'non9_policy_source_sequence_unchanged_if_checks_pass':True}

def tensor_contract(old_text,new_text):
    name,oldargs=header(old_text);newname,newargs=header(new_text);require(newname==name+'_QPMASS' and oldargs==newargs,'Private tensor entry name/formals changed')
    expected=[];changes=Counter()
    for label,statement in logical(old_text):
        if statement.startswith('SUBROUTINE'+name+'('):statement='SUBROUTINE'+newname+'('+','.join(oldargs)+')'
        if statement=='ENDSUBROUTINE'+name:statement='ENDSUBROUTINE'+newname
        if statement=='COMPLEX*16M2L(NLOOPLINE)':statement='COMPLEX*32M2L(NLOOPLINE)';changes['mass_formal']+=1
        parsed=call(statement)
        if parsed and parsed[0].endswith('MP_TIRUST_TENSOR_DIAGNOSTIC'):
            statement='CALL'+parsed[0]+'_QPMASS('+','.join(parsed[1])+')';changes['private_diagnostic_target']+=1
        expected.append((label,statement))
    require(changes['mass_formal']==1,'Expected exactly one QP mass formal widening')
    require(changes['private_diagnostic_target']==int(name.endswith('MP_TIRUST_LOOP')),'Unexpected tensor target edits')
    actual=logical(new_text);return {'name':newname,'checks_passed':expected==actual,'expected_logical':expected,'actual_logical':actual,'allowed_edits':['own private name','M2L complex16 to complex32','private diagnostic target in contraction only']}

def rewrite_callers(text,helpers,scope):
    rows=[];counts=Counter();actuals=[];prefixes=set()
    for label,statement in logical(text):
        parsed=call(statement)
        if not parsed or parsed[0] not in helpers:rows.append((label,statement));continue
        require(label=='','Labelled reduction calls require separate review');name,args=parsed;formals=header(helpers[name])[1];require(len(args)==len(formals),'Actual/formal count differs');paired=[]
        for formal,arg in zip(formals,args,strict=True):
            paired.append(arg)
            if re.fullmatch(r'M\d+',formal):
                mass=re.fullmatch(r'DCMPLX\((\w+)\)',arg);require(mass is not None,'Unsupported DP model-mass actual: '+arg);symbol=mass[1];mp=scope_api.mass_contract(scope,symbol)
                paired.append('CMPLX('+mp+',KIND=16)');counts[symbol]+=1;actuals.append({'helper':name,'formal':formal,'DP':arg,'QP':'CMPLX('+mp+',KIND=16)'})
        rows += [('', 'IF(CTMODE.LT.4)THEN'),('',statement),('','ELSE'),('','CALL'+name+'_QPMASS('+','.join(paired)+')'),('','ENDIF')];counts['__guarded_calls__']+=1;prefixes.add(name.split('LOOP_')[0])
    require(len(prefixes)<=1,'Multiple process namespaces in a split unit');return rows,counts,actuals

def common_variant(rows,prefix):
    result=[];count=0
    for row in rows:
        result.append(row)
        if row[1]=="INCLUDE'coupl.inc'":result += [('', 'REAL*8LSCALE'),('','INTEGERCTMODE'),('','COMMON/'+prefix+'CT/LSCALE,CTMODE')];count+=1
    return result,count

def include_edges(files,changed):
    edges=[]
    for name in changed:
        if not name.lower().endswith(('.f','.for','.inc')):continue
        for _,statement in logical(decode(files[name])):
            match=re.fullmatch(r"INCLUDE['\"]([^'\"]+)['\"]",statement)
            if match:edges.append(scope_api.include_record(files,name,match[1]))
    return edges


def caller_file_contract(old_text,new_text,helpers,files,path,prefix):
    before=fixed.routines(old_text);after=fixed.routines(new_text)
    require(set(before)==set(after),'Caller unit names/kinds changed')
    records={};counts=Counter();verified=Counter();actuals=[];observed=0;guarded=0;problems=[];scopes={}
    for name,old in before.items():
        fresh=after[name];require(old['kind']==fresh['kind'],'Caller unit kind changed')
        rows,edges,issues=scope_api.closure(files,path,fresh['text'],logical)
        scope=scope_api.declarations(rows,arguments);scope['include_edges']=edges;scopes[name]=scope
        try:new_expected,unit_counts,pairs=rewrite_callers(old['text'],helpers,scope)
        except ValueError as error:
            actual_original_calls=sum(bool(call(statement) and call(statement)[0] in helpers) for _,statement in logical(old['text']))
            records[name]={'checks_passed':False,'error':str(error),'scope_problems':issues+scope['problems']+[str(error)],'original_reduction_calls':actual_original_calls,'actual_private_reduction_calls':sum(bool(call(statement) and call(statement)[0] in {helper+'_QPMASS' for helper in helpers}) for _,statement in logical(fresh['text'])),'verified_guarded_calls':0,'CT_common_additions':0};problems.append(name+': '+str(error));continue
        actual=logical(fresh['text']);with_common,insertions=common_variant(new_expected,prefix)
        match=actual==new_expected or (insertions>0 and actual==with_common)
        expected_calls=unit_counts.pop('__guarded_calls__',0)
        checks=issues+scope['problems']
        if expected_calls:checks+=scope_api.common_contract(scope,prefix)
        if checks:match=False;problems.extend(name+': '+item for item in checks)
        unit_observed=sum(bool(call(statement) and call(statement)[0] in {helper+'_QPMASS' for helper in helpers}) for _,statement in actual)
        records[name]={'checks_passed':match,'CT_common_additions':insertions if actual==with_common else 0,'original_reduction_calls':expected_calls,'actual_private_reduction_calls':unit_observed,'verified_guarded_calls':expected_calls if match else 0,'scope_problems':checks,'expected_without_common':new_expected,'expected_with_common':with_common,'actual_logical':actual}
        scopes[name]=scope;counts.update(unit_counts);observed+=unit_observed
        if match:verified.update(unit_counts);actuals+=pairs;guarded+=expected_calls
    return {'checks_passed':all(row['checks_passed'] for row in records.values()),'routines':records,'CT_common_additions':sum(row.get('CT_common_additions',0) for row in records.values()),'routine_scopes':scopes,'scope_problems':problems,'original_reduction_calls':sum(row['original_reduction_calls'] for row in records.values()),'actual_private_reduction_calls':sum(row.get('actual_private_reduction_calls',0) for row in records.values()),'verified_guarded_calls':guarded,'original_DP_mass_symbol_counts':dict(counts),'verified_DP_MP_mass_pair_counts':dict(verified),'verified_DP_MP_actuals':actuals}

def _analyze(original,candidate,process_directory='SubProcesses/P0_epem_ttxa'):
    """Mappings contain raw source bytes only; no files, imports or tools accessed."""
    require(all(isinstance(n,str) and isinstance(v,bytes) for files in (original,candidate) for n,v in files.items()),'Raw source mappings required')
    for files in (original,candidate):
        for name in files:require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source mapping name')
    findings=[];public={};contracts={};helpers={};actuals=[];totals=Counter();verified_totals=Counter();additions_by_file={};prefix=None
    ct=process_directory+'/CT_interface.f';tir=process_directory+'/TIRUST_interface.f'
    for name in (ct,tir):
        require(name in original and name in candidate,'Missing actual public interface: '+name)
        before=fixed.routines(decode(original[name]));after=fixed.routines(decode(candidate[name]));public[name]={}
        for symbol,row in before.items():
            passed=symbol in after and row['text'].encode()==after[symbol]['text'].encode();public[name][symbol]={'raw_exact':passed,'kind':row['kind'],'original_sha256':hashlib.sha256(row['text'].encode()).hexdigest(),'candidate_sha256':hashlib.sha256(after[symbol]['text'].encode()).hexdigest() if symbol in after else None}
            if not passed:findings.append('Public legacy body differs/missing: '+symbol)
        if name==ct:
            helpers={n:r['text'] for n,r in before.items() if re.fullmatch(r'.*LOOP_\d+(?:_\d+)?',n)};require(helpers,'No actual LOOP helper family');prefixes={n.split('LOOP_')[0] for n in helpers};require(len(prefixes)==1,'Ambiguous actual namespace');prefix=next(iter(prefixes));expected={n+'_QPMASS':n for n in helpers}
        else:expected={n+'_QPMASS':n for n in before if n.endswith(('MP_TIRUST_TENSOR_DIAGNOSTIC','MP_TIRUST_LOOP'))};require(len(expected)==2,'Actual QP tensor entry family incomplete')
        additions=set(after)-set(before);additions_by_file[name]=sorted(additions)
        if additions!=set(expected):findings.append('Private helper family differs in '+name)
        for new,old in expected.items():
            if new not in after:continue
            try:record=helper_contract(before[old]['text'],after[new]['text']) if name==ct else tensor_contract(before[old]['text'],after[new]['text'])
            except ValueError as error:record={'name':new,'checks_passed':False,'error':str(error)}
            contracts[new]=record
            if not record['checks_passed']:findings.append('Private selected-edit correspondence differs: '+new)
    common={};changed=[];deltas={}
    for name in sorted(set(original)|set(candidate)):
        if name not in original or name not in candidate:
            findings.append('Added/missing generated source/build input: '+name);continue
        same=original[name]==candidate[name]
        if not same:changed.append(name);deltas[name]=delta(original[name],candidate[name],name)
        if name in (ct,tir):continue
        supported=bool(re.fullmatch(re.escape(process_directory)+r'/(?:loop_CT_calls|coef_construction|helas_calls_ampb|helas_calls_uvct)_\d+\.f',name))
        if same and not supported:continue
        if supported:
            try:
                record=caller_file_contract(decode(original[name]),decode(candidate[name]),helpers,candidate,name,prefix)
                common[name]=record;totals.update(record['original_DP_mass_symbol_counts']);verified_totals.update(record['verified_DP_MP_mass_pair_counts']);actuals+=record['verified_DP_MP_actuals']
                if not record['checks_passed']:findings.append('Unexplained fixed-form/scope source delta: '+name)
            except ValueError as error:common[name]={'checks_passed':False,'error':str(error)};findings.append('Unparsed/unsupported source delta: '+name)
        elif not same and Path(name).suffix.lower() in SUFFIXES:findings.append('Unexpected non-caller scientific source delta: '+name)
        elif not same:findings.append('Open unclassified source/build metadata delta: '+name)
    return {'schema':'ew-qp-mass-generated-source-correspondence-v2','status':'requires_explicit_independent_source_review','findings':findings,'narrow_checks_passed':not findings,'native_calls':0,'compiler_calls':0,'MG_runtime_imports':0,'source_qualified':False,'BUILD_admitted':False,'semantic_equivalence_proven':False,'actual_public_units':sum(len(r) for r in public.values()),'public_units':public,'actual_private_helpers':sum(len(names) for names in additions_by_file.values()),'actual_private_additions':additions_by_file,'private_contracts':contracts,'original_reduction_calls':sum(r.get('original_reduction_calls',0) for r in common.values()),'actual_private_reduction_calls':sum(r.get('actual_private_reduction_calls',0) for r in common.values()),'verified_guarded_calls':sum(r.get('verified_guarded_calls',0) for r in common.values()),'original_DP_mass_symbol_counts':dict(totals),'verified_DP_MP_mass_pair_counts':dict(verified_totals),'verified_DP_MP_actuals':actuals,'split_and_common_checks':common,'source_counts':{'original':len(original),'candidate':len(candidate)},'raw_changed_files':changed,'raw_deltas':deltas,'include_edges':include_edges(candidate,changed),'limitations':['Counts derive solely from supplied actual file bytes; no EW counts are assumed.','Logical selected-edit diagnostics retain labels, literals and order but ignore ordinary whitespace/comments; all raw deltas remain.','Actual include search flags/object rebuild/runtime/no-floating-point-effects require later BUILD/RUN review.','No native numerical, constructor, tensor, physical accuracy, cache or performance qualification follows.']}

def analyze(original,candidate,process_directory='SubProcesses/P0_epem_ttxa'):
    try:return _analyze(original,candidate,process_directory)
    except (ValueError,UnicodeError) as error:
        changed=[];raw={}
        if isinstance(original,dict) and isinstance(candidate,dict):
            for name in sorted(set(original)|set(candidate)):
                a=original.get(name);b=candidate.get(name)
                if a==b:continue
                changed.append(name)
                if isinstance(a,bytes) and isinstance(b,bytes):
                    try:raw[name]=delta(a,b,name)
                    except UnicodeError:raw[name]={'original':identity(a),'candidate':identity(b),'raw_equal':False,'raw_diff_unsupported':'Invalid UTF8; exact byte identities retained'}
                else:raw[name]={'original':identity(a) if isinstance(a,bytes) else None,'candidate':identity(b) if isinstance(b,bytes) else None,'raw_equal':False}
        return {'schema':'ew-qp-mass-generated-source-correspondence-v2','status':'unsupported_source_requires_explicit_review','findings':['Unsupported source/input: '+str(error)],'narrow_checks_passed':False,'source_qualified':False,'BUILD_admitted':False,'semantic_equivalence_proven':False,'native_calls':0,'compiler_calls':0,'MG_runtime_imports':0,'verified_guarded_calls':0,'verified_DP_MP_mass_pair_counts':{},'raw_changed_files':changed,'raw_deltas':raw,'limitations':['Unsupported lexical/scope forms are refused; no counts or equivalence are inferred.']}

def read_sources(directory):
    directory=Path(directory);require(directory.is_dir(),'Actual GEN output directory absent');result={}
    for subtree in ('Source','SubProcesses'):
        base=directory/subtree;require(base.is_dir(),'Actual GEN source subtree missing')
        for path in sorted(base.rglob('*')):
            if path.is_file() and (path.suffix.lower() in SUFFIXES or path.name.startswith('makefile') or path.name in ('make_opts','MadLoop_makefile_definitions')):result[str(path.relative_to(directory))]=path.read_bytes()
    return result

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--original',required=True);parser.add_argument('--candidate',required=True);parser.add_argument('--process-directory',default='SubProcesses/P0_epem_ttxa');args=parser.parse_args()
    print(json.dumps(analyze(read_sources(args.original),read_sources(args.candidate),args.process_directory),indent=2,sort_keys=True))
