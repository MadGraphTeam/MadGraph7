"""Pure exact-case include closure and narrow typed routine scope."""
from pathlib import PurePosixPath as Path
import hashlib
import posixpath
import re

def require(ok,message):
    if not ok:raise ValueError(message)
def identity(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def include_record(files,unit,literal):
    require(literal and not Path(literal).is_absolute(),'Unsupported absolute/empty INCLUDE literal')
    matches=[];seen=set()
    for parent in (Path(unit).parent,Path('SubProcesses'),Path('Source/MODEL'),Path('Source/DHELAS')):
        key=posixpath.normpath(str(parent/literal));require(not key.startswith('../'),'INCLUDE escapes source inventory')
        if key in files and key not in seen:matches.append({'logical_path':key,**identity(files[key])});seen.add(key)
    unique={m['sha256'] for m in matches}
    return {'unit':unit,'include':literal,'candidate_search_matches':matches,'unresolved_in_source_inventory':not matches,'ambiguous_source_candidates':len(unique)>1,'selected_logical_path':matches[0]['logical_path'] if matches and len(unique)==1 else None,'actual_compile_search_order_not_yet_qualified':True}

def closure(files,unit,text,logical):
    statements=[];edges=[];problems=[]
    def visit(name,body,stack):
        for label,statement in logical(body):
            include=re.fullmatch(r"INCLUDE['\"]([^'\"]+)['\"]",statement)
            if not include:statements.append((name,label,statement));continue
            edge=include_record(files,name,include[1]);edges.append(edge);target=edge['selected_logical_path']
            if target is None:problems.append('Unresolved/ambiguous exact INCLUDE '+repr(include[1])+' in '+name);continue
            if target in stack:problems.append('Recursive INCLUDE cycle at '+target);continue
            visit(target,files[target].decode('utf-8'),(*stack,target))
    visit(unit,text,(unit,));return statements,edges,problems

def declarations(rows,arguments):
    typed={};parameters={};commons={};problems=[]
    for origin,label,statement in rows:
        decl=re.fullmatch(r'(REAL\*\d+|COMPLEX\*\d+|INTEGER(?:\*\d+)?|DOUBLEPRECISION|LOGICAL(?:\*\d+)?)(.*)',statement)
        if decl:
            kind,tail=decl.groups();is_parameter=False
            if tail.startswith(',PARAMETER::'):tail=tail[len(',PARAMETER::'):];is_parameter=True
            elif tail.startswith('::'):tail=tail[2:]
            elif tail.startswith(','):problems.append('Unsupported typed attributes in '+origin);continue
            for item in arguments(tail):
                # Only the declarator's own leading identifier is a declaration.
                # Array bounds and initialization RHS never create names.
                match=re.fullmatch(r'([A-Z][A-Z0-9_]*)(\([^=]*\))?(?:=(.*))?',item)
                if not match:problems.append('Unsupported declarator '+item+' in '+origin);continue
                name,shape,value=match.groups()
                if name in typed:problems.append('Duplicate typed declaration '+name+' in routine closure')
                typed[name]={'kind':kind,'scalar':shape is None,'origin':origin,'declarator':item}
                if is_parameter:
                    if value is None:problems.append('PARAMETER declaration without value '+name)
                    else:parameters[name]=value
        elif statement.startswith('PARAMETER('):
            require(statement.endswith(')'),'Malformed PARAMETER statement')
            for item in arguments(statement[len('PARAMETER('):-1]):
                value=re.fullmatch(r'([A-Z][A-Z0-9_]*)=(.*)',item)
                if not value:problems.append('Unsupported PARAMETER assignment in '+origin);continue
                if value[1] in parameters:problems.append('Duplicate PARAMETER '+value[1])
                parameters[value[1]]=value[2]
        elif statement.startswith('COMMON/'):
            match=re.fullmatch(r'COMMON/(\w+)/(.*)',statement)
            if not match:problems.append('Unsupported COMMON syntax in '+origin);continue
            block,tail=match.groups();fields=arguments(tail)
            if any(not re.fullmatch(r'[A-Z][A-Z0-9_]*',name) for name in fields):
                # Other model COMMON arrays are descriptive. A CT block with
                # these unsupported fields cannot satisfy common_contract.
                commons.setdefault(block,[]).append({'fields':fields,'origin':origin,'simple_fields':False})
            else:commons.setdefault(block,[]).append({'fields':fields,'origin':origin,'simple_fields':True})
    return {'typed':typed,'parameters':parameters,'commons':commons,'problems':problems}

def common_contract(scope,prefix):
    needed={'LSCALE':'REAL*8','CTMODE':'INTEGER'};problems=[]
    for name,kind in needed.items():
        row=scope['typed'].get(name)
        if not row or row['kind']!=kind or not row['scalar'] or name in scope['parameters']:problems.append('Missing/mistyped mutable scalar '+name+' '+kind)
    blocks=scope['commons'].get(prefix+'CT',[])
    if len(blocks)!=1 or blocks[0]['fields']!=['LSCALE','CTMODE'] or not blocks[0]['simple_fields']:problems.append('Missing/extraneous namespace COMMON/'+prefix+'CT/LSCALE,CTMODE')
    return problems

def mass_contract(scope,symbol):
    name='MP__'+symbol;row=scope['typed'].get(name)
    require(row is not None and row['kind'] in ('REAL*16','COMPLEX*32') and row['scalar'],'Required MP mass is not a typed scalar in this routine/include closure: '+name)
    if symbol=='ZERO':
        require(row['kind']=='REAL*16','Local MP__ZERO must be REAL*16')
        value=scope['parameters'].get(name);require(value is not None and re.fullmatch(r'\+?0+\.0+(?:[ED][+-]?0+)?_16',value),'Local MP__ZERO must have an explicit real-kind16 zero PARAMETER')
    return name
