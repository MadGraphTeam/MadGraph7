"""Narrow fixed-column132 parser. Unsupported lexical forms fail closed."""
import re

def require(ok,message):
    if not ok:raise ValueError(message)
def directive(line):return line.startswith(('C$','c$','!$','*$')) or bool(re.match(r'^[Cc][Ff]2[Pp][Yy]',line))
def comment(line):return not line.strip() or line[0] in 'Cc*!' or line[6:132].lstrip().startswith('!')
def code(line):
    require('\t' not in line,'Unsupported fixed-form tab semantics')
    require(not line[132:].strip(),'Executable source beyond fixed column132')
    value=line[6:132].rstrip('\r\n');quote=None;i=0
    while i<len(value):
        ch=value[i]
        if quote:
            if ch==quote:
                if i+1<len(value) and value[i+1]==quote:i+=1
                else:quote=None
        elif ch in "'\"":quote=ch
        elif ch=='!':value=value[:i];break
        i+=1
    require(quote is None,'Unsupported quoted literal spanning physical continuation records; raw payload must be reviewed')
    return value.strip()

def logical_blocks(text):
    """Yield raw spans; comments between continuations are handled explicitly."""
    lines=text.splitlines(keepends=True);i=0
    while i<len(lines):
        first=i;line=lines[i]
        if comment(line):yield first,i+1,None;i+=1;continue
        require(len(line)>5 and line[5] in ' 0\r\n','Orphan fixed-form continuation')
        label=line[:5].strip();require(not label or label.isdigit(),'Invalid fixed-form label');statement=code(line);i+=1;last=i
        while i<len(lines):
            following=i
            while following<len(lines) and comment(lines[following]):following+=1
            if following==len(lines):break
            continuation=lines[following]
            if len(continuation)<=5 or continuation[5] in ' 0\r\n':break
            require(not any(directive(row) for row in lines[i:following]),'Unsupported directive between continuation records')
            require(not continuation[:5].strip(),'Label on continuation record');statement+=' '+code(continuation);i=following+1;last=i
        yield first,last,(label,statement)

def canonical_statement(statement):
    result=[];i=0
    while i<len(statement):
        ch=statement[i]
        if ch in "'\"":
            quote=ch;start=i;i+=1
            while i<len(statement):
                if statement[i]==quote:
                    i+=1
                    if i<len(statement) and statement[i]==quote:i+=1;continue
                    break
                i+=1
            else:raise ValueError('Unterminated literal')
            result.append(statement[start:i])
        elif ch.isspace():i+=1
        else:result.append(ch.upper());i+=1
    return ''.join(result)

def logical_diagnostic(text):
    lines=text.splitlines(keepends=True);rows=[]
    for first,last,value in logical_blocks(text):
        if value is None:
            if directive(lines[first]):rows.append(['directive',lines[first]])
        else:rows.append([value[0],canonical_statement(value[1])])
    return rows

def routines(text):
    lines=text.splitlines(keepends=True);found={};active=None
    for first,last,logical in logical_blocks(text):
        if logical is None:continue
        _,statement=logical
        header=re.fullmatch(r'SUBROUTINE\s+(\w+)\s*\((.*)\)',statement,re.I)
        block=re.fullmatch(r'BLOCK\s+DATA\s+(\w+)',statement,re.I)
        end=re.fullmatch(r'END(?:\s+(SUBROUTINE|BLOCK\s+DATA)(?:\s+(\w+))?)?',statement,re.I)
        if header or block:
            match=header or block;require(active is None,'Nested/unterminated Fortran unit');name=match[1].upper();require(name not in found,'Duplicate Fortran unit');active=(name,first,'subroutine' if header else 'block_data')
        elif end:
            require(active is not None,'END outside supported unit');name,start,kind=active
            if end[1]:require(end[1].replace(' ','_').lower()==kind,'Named END kind differs from active unit')
            if end[2]:require(end[2].upper()==name,'Named END identifier differs from active unit')
            found[name]={'text':''.join(lines[start:last]),'kind':kind};active=None
        elif active is None:raise ValueError('Unsupported executable text outside named unit: '+statement)
    require(active is None,'Unterminated Fortran unit');require(found,'No supported named units');return found
