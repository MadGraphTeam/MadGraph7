# Dormant EW QP-mass actual-CLI GEN proposal

SOURCE ONLY, 2026-11-11. Preparation/default preflight/pure tests invoke no
CLI, compiler query, compiler, loader, model, reducer, amplitude or installer.
No production, reference, installed dependency, public evidence, card or Git
state is changed. GEN execution requires a separately reviewed exact source
seal and explicit root admission per role. BUILD and RUN are not implemented
or admitted here. Every successful GEN closes as `generated_pending_source_review`.

## Scientific scope

The two roles use production `0fcd2cd873d61d134837e1d9e87afb13a47824fd`:

- `original`: unmodified0fcd, with no mass overlay. This is the source control,
  not the starting9228fc performance baseline.
- `candidate`: the same source plus only the mass correction sealed by
  `75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25`.
  Its nine exact overlay payloads comprise seven existing files (three changed,
  four identical) and two new templates: five changed scientific files total.

Each real stock `bin/madgraph --plain` invocation generates exactly
`e+ e- > t t~ a [virt=QED]`, optimized standalone, real-mass scheme, pinned
`loop_qcd_qed_sm_Gmu`. It uses all existing backend paths, nb_core1 and exact
pinned GNU15.2 compiler selectors. It ends in output `-nojpeg` and `quit`;
there is no launch/check/install command or finalization stub.

The converted UFO manifest contains175 source files, archive SHA
`cffc0916c8edda35e78e3d45156b5356e84459dc086cf4c71bff9c9b6bbf5955`
and converted-tree SHA
`94ef93760f946dcaeb68544de55fada8904fc1556af647efe6460d33ca19c15e`.
Only those declared regular files are copied to each private MG model tree.
The original model directory's pickle, debug log and pycache are excluded.
Generated private model caches may appear after import; every declared model
source remains exact and unexpected additional source payloads are rejected.

This is a real-card square-precision test. The actual model reads MT=173.3 and
MW=80.419 through a REAL*8 buffer before assigning their MP counterparts.
Neither a113-bit physical mass input nor a derived/complex MW is claimed.
The science motivation and independent-truth limits are retained in the pinned
`.tirust-build/ew-qp-mass-qualification-design-1` design. The historical EW mass
transport experiment did not remove37 refused groups; GEN implies no fix.
No geometry, on-shell/Gram guard, numerator, scale, cache or native ABI change
is added. TIRust DSO remains `eb3d67fd...`; NinjaRS is not repinned or patched.

## Exact reused staging and environment

The qualified QCD GEN3 source is pinned at
`044c90afa64f3c65a6f96a46d67c781b8d643aec39e1e9506611299b3e59021b`.
Its full17 payloads are authenticated before importing its pure helper code.
Its2666 scientific/root source bindings and12 extra0fcd Git-blob-authenticated
frontend bootstrap files are reused unchanged; static import closure retains
its129 visited files and29 nonliteral/dynamic-site limitations. No runtime MG
package is imported by preflight. This does not extend QCD's executed import
or physical qualification to EW.

At execution only, each role materializes its own private MG tree from that
inventory; the candidate applies the exact overlay. Both use the qualified
candidate dependency closure because both sources include production backend9.
The helper's `baseline` dependency key describes old922 source and is not used.
The123 prebuilt CutTools/IREGI files and24 external dependency bindings are
copied/checked through the pinned helper; no shared library is rebuilt. Exact
source/bootstrap/model/library/configuration pins are checked before and after.
Private source configuration disables updates before the card is read and
must remain byte-identical after output; protected real checkout configs are
checked through the unchanged parent preflight.

Tool paths, compiler closure, empty original injection policy, MAKEFLAGS-j1,
Bash, thread counts1, PYTHONHASHSEED0 and loader environment come from GEN3.
Each role overrides only its private XDG/TMP/PWD paths. No Nix discovery,
ambient compiler flags, Git operation or installation is used.

**Stock output compiles Source/MODEL and Source/DHELAS, archives libraries and
queries compilers/dependency metadata.** Those children belong to a future GEN
admission, exactly as in qualified QCD GEN3. There is no generated subprocess
compilation, check executable, model probe or scientific executable invocation.
The complete outer CLI command/log/exit is retained; make-internal children are
not claimed individually journalled. Unexpected dependency rebuild markers,
SubProcesses objects or a check executable stop the stage. Full generated
source/build-input inventory, stock Source object count and reducer availability
are retained. Source/make_opts must match the retained original policy apart
from the two exact compiler-selector paths; expanded recipes are not freshly
recaptured in this phase.

The exact physical card `891e4b89...` and common cache0 numerical card97aaad78...
are installed into fresh output Cards only after stock generation; the original
generated physical-card hash is retained separately. `inputs/ordinary100.dat`
and `inputs/targets2.dat` bind100 ordinary points and the exact two-record
EW target stream `f1663e76...`. They are never evaluated or regenerated here.
Target1 is ordinary; target2 is top-pair threshold with a soft photon.
No result/cohort/oracle claim is inherited from any preceding stress source.

## Separate future GEN actions

Work root `.tirust-build/ew-qp-mass-cli-generation-work-1/{original,candidate}`;
execution root `.tirust-build/ew-qp-mass-cli-generation-execution-1/{original,candidate}`.
Each role has its own fresh checkout/model/output and exact card. No retry is
permitted. The candidate additionally requires the exact separately reviewed
successful original terminal; a closed original GEN still leaves its Fortran
source correspondence pending.

From the required repository, pinned Python default file-only preflight:

```text
<pinned Python> -B .tirust-build/ew-qp-mass-cli-generation-proposal-1/controller.py --source SOURCE_SHA
```

Future commands after separate root admission:

```text
<pinned Python> -B .tirust-build/ew-qp-mass-cli-generation-proposal-1/controller.py --source SOURCE_SHA --role original --execute
<pinned Python> -B .tirust-build/ew-qp-mass-cli-generation-proposal-1/controller.py --source SOURCE_SHA --role candidate --reviewed-original ORIGINAL_TERMINAL_SHA --execute
```

Each role has600seconds total including60seconds cleanup,16GiB address space,
512MiB per file, core0, nonexclusiveCPU12, single-thread numerical libraries and
the shared fail-if-busy numerical mutex. The corrected qualified absolute-end
ownership helper is copied byte-for-byte from snapshot proposal2. Preflight,
execution and cleanup share the original end. Environment reconstruction occurs
before process handoff. A successful Popen retains its raw handle/identity before
OwnedChild construction; construction uncertainty cannot qualify a pass. One
failed stage stops without deadline extension or automatic correction/retry.

Only after closed GEN and independent review of all actual generated source,
public legacy bodies, guarded mass symbols/arguments/cyclic squares and include
closure should a new BUILD proposal be prepared. It must inspect all actual
changed units, not assume the three originally expected QCD units. No old QCD
object recipe, actual EW group numbering, source equivalence, native/runtime
closure or numerical result is manufactured by this source-only proposal.
Later ordinary100, normal checked target rescue, causal observations, independent
pole/finite checks, cache modes and local precise timing remain separate gates.
