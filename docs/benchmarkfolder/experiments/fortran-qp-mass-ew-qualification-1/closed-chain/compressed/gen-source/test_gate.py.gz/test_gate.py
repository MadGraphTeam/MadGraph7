"""Pure EW GEN contract tests: no CLI, compiler, model or reducer execution."""
import builtins
from contextlib import nullcontext
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from unittest.mock import Mock,patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_ew_gen_tested',HERE/'controller.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def identity(path):return {'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

class GateTests(unittest.TestCase):
    def test_guarded_real_preflight_has_no_effects(self):
        c.SOURCE=c.sha(HERE/'source-index.json');original=builtins.__import__;attempts=[]
        def blocked(*args,**kwargs):attempts.append('forbidden');raise AssertionError('External/write effect forbidden')
        def imports(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','mg5decay','MadSpin','madmatrix','aloha','PLUGIN'}:attempts.append('MG import');raise AssertionError('MG runtime import forbidden')
            return original(name,*args,**kwargs)
        with patch.object(subprocess,'Popen',side_effect=blocked),patch.object(subprocess,'run',side_effect=blocked),patch.object(os,'system',side_effect=blocked),patch.object(os,'fork',side_effect=blocked),patch.object(os,'execv',side_effect=blocked),patch.object(os,'execve',side_effect=blocked),patch.object(ctypes,'CDLL',side_effect=blocked),patch.object(Path,'write_text',side_effect=blocked),patch.object(Path,'write_bytes',side_effect=blocked),patch.object(Path,'mkdir',side_effect=blocked),patch.object(builtins,'__import__',side_effect=imports):
            result=c.verify_source()
        self.assertEqual(attempts,[]);self.assertEqual(result['CLI_calls'],0);self.assertEqual(result['compiler_queries'],0);self.assertEqual(result['scientific_native_calls'],0);self.assertEqual(result['MG_import_execution'],0)
        self.assertEqual((result['source_bindings'],result['bootstrap_bindings'],result['EW_model_files']),(2666,12,175))

    def test_exact_ew_cli_cards(self):
        for role in c.ROLES:
            lines=c.validate_card(role);self.assertEqual(lines[-3],'generate e+ e- > t t~ a [virt=QED]');self.assertEqual(lines[-1],'quit');self.assertIn('set complex_mass_scheme False --no_save',lines)
            self.assertTrue(all(line.endswith(' --no_save') for line in lines if line.startswith('set ')))
            self.assertEqual(sum(line.startswith('import model ') for line in lines),1);self.assertEqual(sum(line.startswith('output ') for line in lines),1)
            self.assertIn('/'+role+'/mg/models/loop_qcd_qed_sm_Gmu',lines[-4]);self.assertIn('/'+role+'/output/ew_n3_epem_ttxa',lines[-2]);self.assertTrue(lines[-2].endswith(' -nojpeg'))

    def test_cli_argv_only_uses_stock_frontend(self):
        for role in c.ROLES:
            args=c.argv(role);self.assertEqual(args[1:4],['-B','./bin/madgraph','--plain']);self.assertEqual(args[-1],str(HERE/('generate-'+role+'.mg5')))
            self.assertEqual(len(args),5)

    def test_model_manifest_is_exact_and_excludes_origin_generated_cache(self):
        rows=c.pin()['model']['files'];manifest=c.read(HERE/'model-pin.json')
        self.assertEqual({n:r['sha256'] for n,r in rows.items()},manifest['files']);self.assertEqual(len(rows),175)
        self.assertFalse(any(n.endswith(('.pkl','.pyc','.log')) or '__pycache__' in n for n in rows))
        self.assertEqual(c.pin()['model']['archive_sha256'],'cffc0916c8edda35e78e3d45156b5356e84459dc086cf4c71bff9c9b6bbf5955')
        self.assertEqual(c.pin()['model']['converted_tree_sha256'],'94ef93760f946dcaeb68544de55fada8904fc1556af647efe6460d33ca19c15e')

    def test_model_missing_changed_alias_or_escape_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);p=root/'one.py';p.write_text('source');rows={'one.py':identity(p)}
            with patch.object(c,'pin',return_value={'model':{'files':rows}}):
                self.assertEqual(c.verify_model(root),1);p.write_text('changed')
                with self.assertRaises(ValueError):c.verify_model(root)
                p.unlink();p.symlink_to(root/'absent')
                with self.assertRaises(ValueError):c.verify_model(root)
            with patch.object(c,'pin',return_value={'model':{'files':{'../outside':rows['one.py']}}}):
                with self.assertRaises(ValueError):c.verify_model(root)

    def test_frozen_ordinary_and_target_and_physical_cards(self):
        rows=c.pin()['frozen_inputs'];self.assertEqual((HERE/'inputs/ordinary100.dat').read_text().splitlines()[0],'100');self.assertEqual((HERE/'inputs/targets2.dat').read_text().splitlines()[0],'2')
        self.assertEqual(rows['targets2.dat']['sha256'],'f1663e764a65d5b9ca89691177f3607ba85f3daff8b52af9360b1a4f09e26de3')
        self.assertEqual(rows['param_card.dat']['sha256'],'891e4b89d522804e1f21c3f8b19b8cc2209b29cbfb7809189a5e7062c1363ea8')
        self.assertEqual(rows['cache0.dat']['sha256'],'97aaad78a84d4fd4b122caab7ed56c8cff63988b53ff6b29dd16d463b61b69a1')

    def test_caps_are_fixed_and_no_preparation_work_exists(self):
        self.assertEqual((c.CPU,c.CAP,c.CLEANUP),(12,600.,60.));self.assertEqual(c.LIMITS,{'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0})
        self.assertFalse(c.WORK.exists());self.assertFalse(c.REPORT.exists())

    def test_original_is_0fcd_not_starting_performance_baseline(self):
        self.assertEqual(c.pin()['production_commit'],'0fcd2cd873d61d134837e1d9e87afb13a47824fd');self.assertIn('not starting922',c.pin()['original_kind'])
        self.assertEqual(c.pin()['candidate_source_seal'],'75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25')

    def test_request_roles_need_separate_review(self):
        c.validate_request(None,False,False,None);c.validate_request('original',True,False,None);c.validate_request('candidate',True,False,'review')
        for args in [('candidate',True,False,None),('original',True,False,'review'),('build',True,False,None),('original',False,False,None),(None,False,False,'review')]:
            with self.assertRaises(ValueError):c.validate_request(*args)

    def test_inventory_rejects_extra_symlink_and_empty_dir(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'source-index.json').write_text('{}');(root/'a').write_text('one');index={'files':{'a':identity(root/'a')}}
            with patch.object(c,'HERE',root):
                c.own_inventory(index);(root/'extra').write_text('x')
                with self.assertRaises(ValueError):c.own_inventory(index)
                (root/'extra').unlink();(root/'empty').mkdir()
                with self.assertRaises(ValueError):c.own_inventory(index)
                (root/'empty').rmdir();(root/'a').unlink();(root/'a').symlink_to('source-index.json')
                with self.assertRaises(ValueError):c.own_inventory(index)

    def test_qualified_owner_is_unchanged(self):
        p=c.pin()['protected_private_helper_origin'];self.assertEqual(c.sha(HERE/'ownership.py'),p['sha256']);self.assertEqual(c.sha(p['path']),p['sha256'])
        text=(HERE/'ownership.py').read_text();self.assertIn('absolute_end',text);self.assertIn('Original unit all-in cap reached during process handoff',text)

    def test_post_popen_owned_constructor_failure_cleans_raw_child(self):
        process=Mock(pid=123);record={'pid':123,'process_group':123,'session':123,'start_time_ticks':999}
        cleanup=Mock();cleanup.SignalRequests.side_effect=lambda:nullcontext(Mock());cleanup.identity.return_value=record;cleanup.OwnedChild.side_effect=RuntimeError('owned constructor failed')
        deadline=types.SimpleNamespace(end=1.e30,handoff=False,deferred=False)
        owner=types.SimpleNamespace(StageDeadline=lambda *a,**k:nullcontext(deadline),raw_cleanup=Mock(return_value={'failure_only':True,'uncertainty_blocks_later_stages':True}))
        parent=types.SimpleNamespace(CLEANUP_HELPER='cleanup.py',load=lambda *a:cleanup,tool=lambda n:'/pinned/'+n)
        with tempfile.TemporaryDirectory() as temp:
            report=Path(temp)/'execution'
            with patch.object(c,'REPORT',report),patch.object(c,'WORK',Path(temp)/'work'),patch.object(c,'SOURCE','sealed'),patch.object(c,'ancestor',return_value=parent),patch.object(c,'load',return_value=owner),patch.object(c,'limits'),patch.object(c,'verify_source',return_value={}),patch.object(c,'environment',return_value={}),patch.object(subprocess,'Popen',return_value=process) as popen:
                with self.assertRaisesRegex(RuntimeError,'owned constructor failed'):c.supervise('original')
            popen.assert_called_once();owner.raw_cleanup.assert_called_once_with(process,record,cleanup,deadline.end)
            terminal=c.read(report/'original/terminal.json');self.assertEqual(terminal['status'],'failed');self.assertTrue(terminal['cleanup']['failure_only'])

if __name__=='__main__':unittest.main(verbosity=2)
