#!/usr/bin/env python3
"""Dormant two-arm EW stock GEN; default mode reads/hashes files only."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/ew-qp-mass-cli-generation-work-1'
REPORT=ROOT/'.tirust-build/ew-qp-mass-cli-generation-execution-1'
ROLES=('original','candidate')
CPU,CAP,CLEANUP=12,600.,60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
SOURCE=None
REVIEWED_ORIGINAL=None

def require(ok,message):
    if not ok:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin():return read(HERE/'input-pins.json')
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
def check(path,row):
    path=Path(path);require(path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'Pinned text changed: '+str(path))
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def ancestor():
    data=pin()['parent'];directory=Path(data['directory']);require(sha(directory/'source-index.json')==data['source_index_sha256'],'Qualified GEN3 seal changed')
    for name,row in read(directory/'source-index.json')['files'].items():check(directory/name,row)
    check(directory/'controller.py',data['controller'])
    if '_ew_gen_parent' not in sys.modules:
        module=load('_ew_gen_parent',directory/'controller.py');module.EXPECTED=data['source_index_sha256']
    return sys.modules['_ew_gen_parent']

def own_inventory(index):
    expected=set(index['files'])|{'source-index.json'};actual=set()
    directories={str(p) for n in expected for p in Path(n).parents if str(p)!='.'}
    for path in HERE.rglob('*'):
        name=str(path.relative_to(HERE));require(not path.is_symlink(),'Source alias forbidden')
        if path.is_file():actual.add(name)
        else:require(path.is_dir() and name in directories,'Unexpected proposal directory')
    require(actual==expected,'Proposal inventory changed')
    for name,row in index['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe source name');check(HERE/name,row)

def verify_model(directory):
    rows=pin()['model']['files']
    for name,row in rows.items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe model source path')
        path=Path(directory)/name;require(not path.is_symlink() and path.resolve().is_relative_to(Path(directory).resolve()),'Model source alias/escape');check(path,row)
    return len(rows)

def role_paths(role):
    require(role in ROLES,'Unknown GEN role');base=WORK/role
    return base,base/'mg',base/'output/ew_n3_epem_ttxa',REPORT/role

def argv(role):
    return [ancestor().tool('python3'),'-B','./bin/madgraph','--plain',str(HERE/('generate-'+role+'.mg5'))]

def card_lines(role):
    return (HERE/pin()['cards'][role]['path']).read_text().splitlines()

def validate_card(role):
    parent=ancestor();base,mg,output,_=role_paths(role);lines=card_lines(role)
    expected=(parent.HERE/'generate.mg5').read_text().splitlines()
    expected=[x for x in expected if not x.startswith(('import model ','generate ','output ','quit'))]
    expected+=['import model '+str(mg/'models/loop_qcd_qed_sm_Gmu'),'generate '+pin()['process'],'output standalone '+str(output)+' -nojpeg','quit']
    require(lines==expected,'GEN card changed beyond exact EW/model/output substitutions')
    require(not any(x.startswith(('launch','check','install')) for x in lines),'Non-GEN command forbidden')
    return lines

def verify_source():
    require(Path.cwd()==ROOT,'Run only from the MadGraph working repository')
    require(SOURCE and sha(HERE/'source-index.json')==SOURCE,'Exact reviewed EW GEN source seal required')
    own_inventory(read(HERE/'source-index.json'));data=pin();parent=ancestor();proven=parent.verify_source()
    require(data['production_commit']=='0fcd2cd873d61d134837e1d9e87afb13a47824fd','Unexpected original source')
    require(data['candidate_source_seal']=='75f32af86266ed01ad06a3b42caabf12897ce6f6c5cefac4032ccf6d77cd9d25','Candidate science changed')
    check(data['model']['manifest_source'],data['model']['manifest'])
    require(read(HERE/'model-pin.json')==read(data['model']['manifest_source']),'Copied model manifest differs')
    manifest=read(HERE/'model-pin.json');require({n:r['sha256'] for n,r in data['model']['files'].items()}==manifest['files'],'EW model inventory changed')
    count=verify_model(data['model']['root']);require(count==175,'Pinned converted model count changed')
    for name,row in data['frozen_inputs'].items():check(row['origin'],row);check(HERE/'inputs'/name,row)
    require((HERE/'inputs/ordinary100.dat').read_text().splitlines()[0]=='100','Ordinary point count changed')
    require((HERE/'inputs/targets2.dat').read_text().splitlines()[0]=='2','Target point count changed')
    owner=data['protected_private_helper_origin'];check(owner['path'],owner);check(HERE/'ownership.py',owner)
    design=Path(data['design']['directory']);require(sha(design/'design-index.json')==data['design']['index_sha256'],'Scientific design changed')
    for role in ROLES:check(HERE/data['cards'][role]['path'],data['cards'][role]);validate_card(role)
    native=str(Path(parent.pin()['library_paths']['tirust'])/'libmadloop_tirust.so')
    require(data['external_native_sha256']=='eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9'
        and parent.dependency().DATA['external'][native]['sha256']==data['external_native_sha256'],'Bridge repin forbidden')
    return {'status':'source-only-preflight-passed','source_index_sha256':SOURCE,'source_bindings':proven['source_bindings'],
        'bootstrap_bindings':proven['bootstrap_bindings'],'EW_model_files':count,'CLI_calls':0,'compiler_queries':0,'scientific_native_calls':0,'MG_import_execution':0,
        'caps_seconds_per_role':CAP,'cleanup_seconds_inside_cap':CLEANUP,'limits':LIMITS,'cpu':CPU,'cpu_reservation':False}

def environment(role,cwd=ROOT):
    base,_,_,_=role_paths(role);env=ancestor().environment(cwd)
    env.update(PWD=str(cwd),XDG_CONFIG_HOME=str(base/'xdg/config'),XDG_STATE_HOME=str(base/'xdg/state'),XDG_DATA_HOME=str(base/'xdg/data'),TMPDIR=str(base/'tmp'))
    return env

def stage_checkout(role):
    parent=ancestor();row=parent.pin();base,mg,output,report=role_paths(role)
    require(not base.exists() and not base.is_symlink(),'Fresh role work root required; no retry');mg.mkdir(parents=True)
    for name,record in row['source_files'].items():
        target=mg/name;require(target.resolve().is_relative_to(mg.resolve()),'Source path escaped private checkout')
        if record['sha256'] is None:
            if record.get('link') is not None:target.parent.mkdir(parents=True,exist_ok=True);target.symlink_to(record['link'])
            continue
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target,follow_symlinks=True);parent.verify_record(target,record)
    for name,record in row['bootstrap_files'].items():
        target=mg/name;require(not target.exists() and not target.is_symlink(),'Bootstrap would overwrite scientific source');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target);parent.verify_record(target,record)
    if role=='candidate':
        for name,record in row['overlay_files'].items():
            target=mg/name;require(target.resolve().is_relative_to(mg.resolve()),'Overlay path escaped checkout');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/record['source'],target);parent.verify_record(target,record)
    model=mg/'models/loop_qcd_qed_sm_Gmu';require(not model.exists(),'Unexpected copied EW model');model.mkdir(parents=True)
    for name,record in pin()['model']['files'].items():
        origin=Path(pin()['model']['root'])/name;target=model/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,target);check(target,record)
    require({str(p.relative_to(model)) for p in model.rglob('*') if p.is_file()}==set(pin()['model']['files']),'Copied model must contain only pinned source')
    parent.dependency().copy_private('candidate',mg)
    require(not (mg/'.git').exists(),'Private checkout must not have Git state')
    config=mg/'input/mg7_configuration.txt';require(not config.exists(),'Unexpected inherited user/install config')
    settings={'auto_update':'0','automatic_html_opening':'False','nb_core':'1','fortran_compiler':parent.tool('gfortran'),'cpp_compiler':parent.tool('g++'),**row['library_paths']}
    config.write_text((mg/'input/.mg7_configuration_default.txt').read_text()+'\n'+''.join(n+' = '+v+'\n' for n,v in settings.items()))
    output.parent.mkdir(parents=True);(base/'tmp').mkdir()
    save(report/'staging.json',{'role':role,'source_entries':len(row['source_files']),'bootstrap_entries':len(row['bootstrap_files']),'overlay_files':len(row['overlay_files']) if role=='candidate' else 0,'model_source_files':175,'origin_generated_model_caches_copied':False,'private_dependency_copies':123,'config':str(config),'startup_configuration_sha256':sha(config),'no_Git_operations':True})

def verify_private(role):
    parent=ancestor();row=parent.pin();_,mg,_,_=role_paths(role)
    overlays=row['overlay_files'] if role=='candidate' else {}
    for name,record in row['source_files'].items():parent.verify_record(mg/name,overlays.get(name,record))
    for name,record in overlays.items():parent.verify_record(mg/name,record)
    for name,record in row['bootstrap_files'].items():parent.verify_record(mg/name,record)
    model=mg/'models/loop_qcd_qed_sm_Gmu';verify_model(model)
    declared=set(pin()['model']['files'])
    for path in model.rglob('*'):
        require(not path.is_symlink(),'Generated model alias forbidden')
        name=str(path.relative_to(model))
        if path.is_file() and name not in declared:
            require(bool(re.fullmatch(r'py[0-9]+_model_[A-Za-z0-9_]+\.pkl',name)) or name=='loop_qcd_qed_sm_Gmu_debug.log'
                or (name.startswith('__pycache__/') and path.suffix=='.pyc'),'Unexpected generated model payload: '+name)
    staging=read((REPORT/role)/'staging.json');require(sha(mg/'input/mg7_configuration.txt')==staging['startup_configuration_sha256'],'Private startup configuration changed')
    parent.dependency().check_private('candidate',mg)

def reviewed_original():
    path=REPORT/'original/terminal.json';require(REVIEWED_ORIGINAL and sha(path)==REVIEWED_ORIGINAL,'Candidate GEN needs separately reviewed exact original terminal')
    terminal=read(path);result=read(REPORT/'original/result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors'] and terminal['source_index_sha256']==SOURCE,'Original GEN failed/changed')
    require(terminal['result_sha256']==sha(REPORT/'original/result.json') and result['status']=='generated_pending_source_review','Original GEN result not closed')
    require(result['source_index_sha256']==SOURCE and result['role']=='original','Wrong original source/role')
    require(sha(REPORT/'original/generation.log')==result['generation_log_sha256'],'Original CLI log changed')
    return terminal

def make_opts_policy(role):
    parent=ancestor();_,_,output,report=role_paths(role);original=Path(parent.pin()['original_make_opts']['path']).read_text();actual=(output/'Source/make_opts').read_text()
    expected=original.replace('DEFAULT_CPP_COMPILER=g++\n','DEFAULT_CPP_COMPILER='+parent.tool('g++')+'\n').replace('DEFAULT_F_COMPILER=gfortran\n','DEFAULT_F_COMPILER='+parent.tool('gfortran')+'\n')
    require(expected!=original and actual==expected,'GEN compiler policy changed beyond exact compiler selectors')
    save(report/'make-opts-policy.json',{'original_sha256':sha(parent.pin()['original_make_opts']['path']),'actual_sha256':sha(output/'Source/make_opts'),'all_other_bytes_exact':True,'expanded_recipes_not_freshly_recaptured':True})

def generate(role):
    parent=ancestor();base,mg,output,report=role_paths(role);admission=read(report/'admission.json')
    require(admission['parent_pid']==os.getppid() and admission['source_index_sha256']==SOURCE and admission['role']==role and admission['reviewed_original']==REVIEWED_ORIGINAL,'Exact supervisor admission required')
    require(os.sched_getaffinity(0)=={CPU},'Child affinity changed')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limit differs')
    verify_source()
    if role=='candidate':reviewed_original()
    stage_checkout(role);command=argv(role);save(report/'generation.command.json',{'argv':command,'cwd':str(mg),'role':role,'model_files':175,'expected_children':'stock MODEL/DHELAS compiles/archives and compiler/version metadata only','make_internal_children_individually_recorded':False})
    with (report/'generation.log').open('xb') as stream:result=subprocess.run(command,cwd=mg,env=environment(role,mg),stdout=stream,stderr=subprocess.STDOUT)
    save(report/'generation.command-terminal.json',{'returncode':result.returncode,'log_sha256':sha(report/'generation.log')})
    require(result.returncode==0,'CLI failed; retain evidence and stop without retry')
    raw=(report/'generation.log').read_text();require(not any(s in raw for s in ('Error detected','interrupted in sub-command','Traceback (most recent call last)','Compiling CutTools','Compiling IREGI','Re-compiling it now')),'CLI failure/dependency rebuild marker')
    require(sorted(p.name for p in (output/'SubProcesses').glob('P*') if p.is_dir())==[pin()['subprocess']],'Expected exactly one EW subprocess')
    require(not any((output/'SubProcesses').rglob('*.o')) and not any((output/'SubProcesses').rglob('check')),'Unexpected subprocess compilation/native executable')
    verify_private(role);make_opts_policy(role);availability=parent.dependency().check_generated('candidate',output,'SubProcesses/'+pin()['subprocess'])
    original_card=sha(output/'Cards/param_card.dat')
    for source,target in (('param_card.dat','param_card.dat'),('cache0.dat','MadLoopParams.dat')):shutil.copy2(HERE/'inputs'/source,output/'Cards'/target);check(output/'Cards'/target,pin()['frozen_inputs'][source])
    save(report/'result.json',{'status':'generated_pending_source_review','source_index_sha256':SOURCE,'role':role,'source_commit':'0fcd2cd873d61d134837e1d9e87afb13a47824fd','overlaid_candidate':role=='candidate','actual_CLI_invocations':1,'amplitude_evaluations':0,'source_inventory':parent.source_inventory(output),'availability':availability,'stock_Model_DHELAS_build_objects':len(list((output/'Source').rglob('*.o'))),'original_generated_param_card_sha256':original_card,'physical_card_sha256':sha(output/'Cards/param_card.dat'),'numerical_card_sha256':sha(output/'Cards/MadLoopParams.dat'),'generation_log_sha256':sha(report/'generation.log'),'later_source_review_required':True,'BUILD_admitted':False,'RUN_admitted':False})
    verify_source()

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited resource hard limit too small');resource.setrlimit(kind,(value,value))

def supervise(role):
    original_end=time.monotonic()+CAP;parent=ancestor();cleanup=parent.load('_ew_gen_cleanup',ROOT/parent.CLEANUP_HELPER);ownership=load('_ew_gen_owner',HERE/'ownership.py');base,_,_,report=role_paths(role)
    require(not report.exists(),'Fresh execution role required; no retry');report.mkdir(parents=True)
    entry={'source_index_sha256':SOURCE,'role':role,'reviewed_original':REVIEWED_ORIGINAL,'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'original_end_monotonic':original_end,'status':'running'}
    process=None;raw_record=None;owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAP,absolute_end=original_end) as deadline:
            entry['deadline_monotonic']=deadline.end;limits();verify_source();requests.check();require(not base.exists(),'Fresh work role required')
            if role=='candidate':reviewed_original()
            command=[parent.tool('taskset'),'-c',str(CPU),parent.tool('python3'),'-B',str(HERE/'controller.py'),'--source',SOURCE,'--role',role,'--child']
            if REVIEWED_ORIGINAL:command+=['--reviewed-original',REVIEWED_ORIGINAL]
            save(report/'admission.json',{**entry,'parent_pid':os.getpid(),'command':command});process_env=environment(role)
            with (report/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(command,cwd=ROOT,env=process_env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;save(report/'started.json',entry);entry['returncode']=owned.wait(requests);requests.check();entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'GEN failed; no retry');verify_source();requests.check()
            entry.update(status='passed',result_sha256=sha(report/'result.json'),qualification='Actual CLI export only; source correspondence pending separate review');save(report/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=ownership.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));save(report/'terminal.json',entry);raise

def validate_request(role,execute,child,review):
    if execute or child:require(role in ROLES and bool(review)==(role=='candidate'),'Separate role required; candidate needs reviewed original GEN')
    else:require(role is None and review is None,'Source-only preflight takes no role/review')

def main():
    global SOURCE,REVIEWED_ORIGINAL
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source',required=True);parser.add_argument('--role',choices=ROLES);parser.add_argument('--execute',action='store_true');parser.add_argument('--child',action='store_true',help=argparse.SUPPRESS);parser.add_argument('--reviewed-original')
    args=parser.parse_args();SOURCE=args.source;REVIEWED_ORIGINAL=args.reviewed_original;validate_request(args.role,args.execute,args.child,REVIEWED_ORIGINAL)
    if args.child:generate(args.role)
    elif args.execute:
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise(args.role)
    else:print(json.dumps(verify_source(),sort_keys=True))
if __name__=='__main__':main()
