# File-only EW generated-source correspondence reviewer

This separate source-only helper leaves sealed GEN1 `6fb69ba7...` unchanged.
It neither generates outputs nor infers EW helper/call/mass counts before the
actual original/candidate exports exist. No CLI, compiler, model, native
library, reducer, installation, Git, production or reference change is made.
The current original GEN is a separately admitted action, not a qualification
created by this helper.

Reviewer checklist for the later actual output pair:

1. Authenticate the separately closed GEN terminals/results, complete source
   inventories, exact0fcd versus mass-overlay source/model/config/tool pins and
   physical/numerical card identities. `original` is0fcd, not922 performance
   baseline. This helper does not replace that provenance review.
2. Compare every public legacy unit in actual CT_interface/TIRUST_interface
   byte-for-byte, including BLOCK DATA. Other scientific source and adapters
   must stay byte-identical except the explicit shared split-template changes.
   Retain raw whole-file and unit deltas; no blanket whitespace equivalence.
3. Derive actual old LOOP family/formals and actual newly added private names
   from the generated files. Require paired DP/MP mass formals, exact early-DP
   delegation, original DP squares/classification and actual CHOOSE_LOOPLIB
   before the actual9-only QP square block. Check the cyclic order last,first,...
   for the observed denominator count. Every old non9 branch/call/mass actual
   must remain in the same logical sequence.
4. Check the private TIRust diagnostic/contraction selected edits only: private
   name, M2L formal complex16→complex32, private diagnostic target in contraction.
   Numerator, normalization, invariants, scale, cache and failure logic remain
   in exact label/literal/statement order.
5. For every actual old split reduction call, require the complete
   CTMODE<4/ELSE guard, unchanged DP call and exact paired MP model actuals.
   Parse actual nested arguments; require the MP symbols to be declared by
   generated MP model/common or local zero declarations, never only comments
   or their own use in the new CALL. Derive all counts from actual source;
   no EW200/QCD116 count is hard-coded. Counts on failed correspondence are
   distinguished as original requests, observed private calls and verified
   guards/model pairs. A missing guard in an otherwise unchanged file fails.
6. Inspect every common/include change. Only exact REAL*8 LSCALE, INTEGER
   CTMODE and same-prefix COMMON/CT additions after the literal lower-case
   'coupl.inc' are admitted as split-template selected edits. Includes retain
   source-only candidate search matches and unresolved edges. Actual compile
   -I order, include shadows, all changed dependent objects and module outputs
   must be separately joined to the future BUILD recipes; this helper does
   not claim compilation closure.

`review.py` exposes pure `analyze(original,candidate,process_directory=...)`,
where mappings contain relative source filenames and raw bytes. The API does
not read files, import MG or start processes. The optional CLI adapter reads
only Source/SubProcesses source/build inputs, prints JSON to stdout and writes
no report or future output. Example after both actual GEN stages close:

```text
<pinned Python> -B .tirust-build/ew-qp-mass-generated-source-review-proposal-1/review.py --original <actual-original-output> --candidate <actual-candidate-output>
```

The fixed-form parser is an exact copy of the previously qualified QCD GEN3
`compare.py` (SHA256 `6d2e5bd6...`), pinned in input-pins.json. It preserves
raw bytes separately and logical labels, quoted literals, statement/control
order and compiler directives. Logical selected-edit diagnostics ignore
ordinary comments/whitespace; they are not a Fortran semantic proof. Public
legacy units and unchanged files use strict raw bytes.

All outcomes remain `requires_explicit_independent_source_review` with
`source_qualified=False`, `BUILD_admitted=False`, `semantic_equivalence_proven=False`.
A finding requires investigation. A clear helper report still requires actual
independent source review before a separately proposed BUILD, and establishes
no numerical, IEEE, constructor, tensor, physical-truth, cache or runtime result.
No future output/count is fabricated. Sixteen synthetic controls cover good
and deliberately broken selected edits, source literals/comments, missing
model declarations/guards, common width, non9 policy and file/process-free API.
