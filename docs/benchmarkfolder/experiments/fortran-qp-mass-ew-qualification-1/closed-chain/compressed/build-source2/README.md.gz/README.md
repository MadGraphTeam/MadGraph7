# Dormant actual-EW subprocess BUILD

SOURCE ONLY. This packet compiles no source, queries no compiler/make/loader,
and invokes no model, reducer or amplitude during preparation, tests or default
preflight. Only a separately reviewed exact source seal, external root textual
correspondence gate, and explicit BUILD admission can enable execution.

Both actual stock CLI exports are frozen: unmodified production0fcd and its
five-file QP-mass candidate, for `e+ e- > t t~ a [virt=QED]` with the pinned
converted `loop_qcd_qed_sm_Gmu` model. Each has427 source/build bindings and344
stock Source objects (15 MODEL +329 DHELAS). Their source input sets differ in
exactly six files. All344 support objects and all four generated support modules
are byte-identical between roles. Every object has a unique same-stem source;
each module has a declared source and producer object. Actual generated-text
correspondence review5e9ba7d7 is a prerequisite, not a compilation claim.

The root gate template `REVIEWED_SOURCE_GATE.example.json` deliberately refuses
execution until root copies it to a fresh ignored path and sets only
`generated_text_accepted=true` after review. `source_qualified` stays false and
`qualification_scope` stays `generated-text-correspondence-only`: actual compiler
include/module, object, ABI and runtime checks are still pending BUILD. Both GEN
terminals and complete canonical inventory digests plus the exact independent
review path/hash are required. CLI uses `--reviewed-source RELPATH` and
`--reviewed-source-sha SHA256`. Default preflight does not admit BUILD.

BUILD clones each immutable GEN output into a fresh private tree. It preserves
only the two exact read-only NinjaRS directory aliases and their eight regular
leaf identities. Other aliases become private copies; no write below either
shared NinjaRS alias is allowed. The512MiB per-file cap also avoids the prior
298MiB-alias-copy failure without copying that archive twice. Five canonical
library/module leaves are bound explicitly, rather than relying on directory
alias traversal by rglob. Native15-provider and eb3 bridge identities remain
unchanged; NinjaRS is not repinned.

The generated PROCESS expression derives21 linked Fortran sources per role,
including the normal full100 driver. No original subprocess objects exist or
are reused. BUILD keeps generated compile flags, special polynomial-O3 rule,
include order and original link inputs, adding only a linker-map option. It
captures effective process/MODEL/DHELAS recipes before and after with the closed
policy helper and compares the fixed GNU15.2 policy classes and both roles.
Only the21 linked process/driver units per role are compiled, in actual dry-run
order, with polynomial module ordering enforced for its users. Every actual
literal INCLUDE/USE input is bound immediately before that compilation. Exact
include case is retained; different existing candidate contents are refused
rather than guessing search order. Same-source generated and GNU builtin
modules are explicit. Generated support modules and GNU intrinsic module bytes
are pinned; the new polynomial module is recorded after its producing compile.

Support objects are reused on exact stock-GEN source, environment, configuration,
object/module/archive and future recaptured recipe evidence. Stock GEN does not
journal each internal compiler argv, and this packet never invents that historical
trace. Any unbound source/object/recipe/module stops qualification. No blanket
344-object rebuild is used. Link proof binds inputs before linking, validates
actual linker LOADs/PT_INTERP, derives the exact static closure, then lists the
actual interpreter's15 providers and records unique wrapper/private definitions.
Original wrapper archive and scientific flags stay unchanged. BUILD runs no
executable main, model probe or numerical evaluation.

Run only from `/shared/external/madloop_tirust/madgraph7_madloop_tirust`.
Use the pinned Python:

```
python3 -B .tirust-build/ew-qp-mass-build-proposal-2/controller.py --source SOURCE_SHA
python3 -B .tirust-build/ew-qp-mass-build-proposal-2/guarded_preflight.py --source SOURCE_SHA
python3 -B .tirust-build/ew-qp-mass-build-proposal-2/test_build.py
python3 -O -B .tirust-build/ew-qp-mass-build-proposal-2/test_build.py
```

A future separately admitted BUILD adds:

```
python3 -B .tirust-build/ew-qp-mass-build-proposal-2/controller.py --source SOURCE_SHA --reviewed-source ROOT_GATE_PATH --reviewed-source-sha ROOT_GATE_SHA --execute
```

The1800-second total includes its original60-second cleanup reserve. The larger
cap covers two fresh process compilations plus policy, linker and loader metadata;
actual command counts are recorded rather than guessed. Limits:16GiB address
space,512MiB per file, core0, one thread, nonexclusive CPU12 and shared fail-if-busy
numerical mutex. The qualified51ca absolute-end/handoff helper is copied exactly;
environment reconstruction precedes handoff, raw Popen identity is retained before
OwnedChild construction, and uncertainty never qualifies success. No retry is
permitted. `--execute` has no RUN or other-stage option.

The compiled ordinary driver is the exact previously qualified five-external-leg
normal full100-learning/final100 source, with explicit dimensional checks and
independent stability enabled; it is not run here. Frozen ordinary100 points,
physical card891e4b89, cache0 numerical card97aaad78 and two-record target stream
f1663e76 are included. Existing Cards/ident_card.dat is bound so parameter lookup
cannot repeat the omitted-identifier startup failure.

Later target protocol is a separate design in `target-protocol.json`, not an
admitted driver: initialize/learn only on ordinary100, verify real filters and
readiness, then request the ordinary/threshold-soft-photon fixtures through the
normal threshold-aware entry with no state restoration. Failures remain failures.
A later runner must preserve dynamic DP/QP histories, raw values, actual scales,
software/IEEE observations and mappings; it may not inherit a QCD87/13 cohort or
claim independent finite truth. No target, accuracy, cache, precision, performance
or production-promotion outcome is established by this BUILD packet.

Source2 retains unexecuted source1 seal97283fce unchanged. Before any admission,
self-review added explicit work/report namespace containment and symlink refusal,
and direct os.open mutation blocking to the guarded preflight. Scientific inputs,
compiler policy, driver, resource/deadline and support-reuse decisions are unchanged.
