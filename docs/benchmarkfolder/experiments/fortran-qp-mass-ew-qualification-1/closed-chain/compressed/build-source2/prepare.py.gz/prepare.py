"""File-only preparation of the dormant, review-gated EW BUILD packet."""
from pathlib import Path
import hashlib,json,importlib.util,re,shutil,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ROLES=('original','candidate')
PROC='SubProcesses/P0_epem_ttxa'
GEN=ROOT/'.tirust-build/ew-qp-mass-cli-generation-proposal-1'
GEN_SHA='6fb69ba7da6fe07e702047c211c04329be2003ea577f6bf1574eeb1dd210f917'
TERMINALS={'original':'026f54e26f163c6cacec3262ae9b6a27273e59447e9302038a12979be18761d9','candidate':'99085edcf65ba41297eb4f393efcb3070a6c10adff573dcfd65d59a0b2e4959d'}
def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')
def local(name):
    spec=importlib.util.spec_from_file_location('ew_build_prepare_'+name,HERE/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def produce():
    require(Path.cwd()==ROOT,'Run from the MadGraph repository')
    require(sha(GEN/'source-index.json')==GEN_SHA,'EW GEN source changed')
    genpin=read(GEN/'input-pins.json');fresh=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-proposal-1';fp=read(fresh/'input-pins.json')
    policy=local('policy');cloning=local('cloning');roles={};protected={}
    for role in ROLES:
        report=ROOT/'.tirust-build/ew-qp-mass-cli-generation-execution-1'/role
        terminal=read(report/'terminal.json');result=read(report/'result.json')
        require(sha(report/'terminal.json')==TERMINALS[role] and terminal['status']=='passed' and terminal['returncode']==0
            and not terminal['cleanup']['survivors'] and terminal['result_sha256']==sha(report/'result.json'),'GEN did not close')
        require(result['status']=='generated_pending_source_review' and result['role']==role and result['amplitude_evaluations']==0,'Wrong GEN role/status')
        output=ROOT/'.tirust-build/ew-qp-mass-cli-generation-work-1'/role/'output/ew_n3_epem_ttxa'
        sources=result['source_inventory'];require(len(sources)==427,'Actual EW source count changed')
        for name,row in sources.items():require(ident(output/name)==row,'GEN source changed')
        objects={str(p.relative_to(output)):ident(p) for p in sorted((output/'Source').rglob('*.o'))}
        require(len(objects)==344 and not list((output/'SubProcesses').rglob('*.o')) and not list((output/'SubProcesses').rglob('check')),'Wrong stock Source/process objects')
        source_map={};declared_modules={}
        for name,h in sources.items():
            if not name.startswith('Source/') or Path(name).suffix.lower() not in {'.f','.f90','.for'}:continue
            for module in policy.module_definitions((output/name).read_text()):
                require(module.lower() not in declared_modules,'Duplicate support module declaration')
                declared_modules[module.lower()]=name
        for name,row in objects.items():
            parent=Path(name).parent;stem=Path(name).stem
            candidates=[n for n in sources if Path(n).parent==parent and Path(n).stem==stem and Path(n).suffix.lower() in {'.f','.f90','.for'}]
            require(len(candidates)==1,'Object has no unique same-stem declared source: '+name)
            source_map[name]={'source':candidates[0],'source_sha256':sources[candidates[0]]['sha256'],'scope':parent.name,'object':row}
        modules={};module_sources={}
        for p in sorted((output/'Source').rglob('*.mod')):
            name=str(p.relative_to(output));module=p.stem.lower();require(module in declared_modules,'Generated module source unbound')
            source=declared_modules[module];obj=str(Path(source).with_suffix('.o'));require(obj in objects,'Module producer object unbound')
            modules[name]=ident(p);module_sources[name]={'source':source,'object':obj}
        require(len(modules)==4,'Actual EW generated module count changed')
        libraries={name:ident(output/name) for name in ('lib/libcts.a','lib/libiregi.a','lib/libdhelas.a','lib/libmodel.a','lib/mpmodule.mod')}
        links=cloning.links(output);shared={}
        for name in sorted(cloning.SHARED):
            p=output/name;target=p.resolve();require(p.is_symlink() and p.is_dir(),'Missing NinjaRS alias')
            entries={q.name:q for q in target.iterdir()};require(len(entries)==8 and all(q.is_file() and not q.is_symlink() for q in entries.values()),'NinjaRS exact regular leaves changed')
            shared[name]={'readlink':str(p.readlink()),'canonical_target':str(target),'leaves':{n:ident(q) for n,q in entries.items()}}
        names={p.name for p in (output/PROC).iterdir() if p.is_file() and p.suffix.lower()=='.f'}
        linked=policy.process_sources((output/PROC/'makefile').read_text(),names)
        users=[n for n in linked if n!='polynomial.f' and re.search(r'(?im)^\s*USE\s+ML5_0_POLYNOMIAL_CONSTANTS\b',(output/PROC/n).read_text())]
        private=[]
        for n in ('CT_interface.f','TIRUST_interface.f'):
            text=(output/PROC/n).read_text()
            private+=re.findall(r'(?im)^\s*(?:RECURSIVE\s+)?(?:[A-Z0-9*]+\s+)?(?:SUBROUTINE|FUNCTION)\s+([A-Z0-9_]*QPMASS[A-Z0-9_]*)\s*\(',text)
        private=sorted(n.lower()+'_' for n in private);require(len(private)==len(set(private)),'Duplicate private source definition')
        require(bool(private)==(role=='candidate'),'Wrong role QP-mass private definitions')
        cards={str(p.relative_to(output)):ident(p) for p in sorted(output.rglob('MadLoopParams.dat')) if p.is_file()}
        for n in ('Cards/param_card.dat','Cards/ident_card.dat'):cards[n]=ident(output/n)
        data_files={str(q.relative_to(output)):ident(q) for q in output.rglob('*.dat') if q.is_file()}
        for q in (output/PROC/'MadLoop5_resources').rglob('*.dat'):
            if q.is_file():data_files[str(q.relative_to(output))]=ident(q)
        roles[role]={'output':str(output),'terminal':{'path':str(report/'terminal.json'),**ident(report/'terminal.json')},'result':{'path':str(report/'result.json'),**ident(report/'result.json')},
            'generation_log':{'path':str(report/'generation.log'),**ident(report/'generation.log')},'sources':sources,'stock_objects':objects,'support_object_source_map':source_map,
            'support_modules':modules,'support_module_producers':module_sources,'canonical_libraries':libraries,'aliases':links,'shared_aliases':shared,'linked_sources':linked,
            'polynomial_module_users':users,'expected_private_symbols':private,'cards':cards,'data_files':data_files}
        for name in ('admission.json','make-opts-policy.json'):
            if (report/name).is_file():protected[str(report/name)]=ident(report/name)
    a,b=(roles[n] for n in ROLES)
    require(set(a['sources'])==set(b['sources']) and len([n for n in a['sources'] if a['sources'][n]!=b['sources'][n]])==6,'Actual six EW source deltas changed')
    require(a['stock_objects']==b['stock_objects'] and a['support_modules']==b['support_modules'],'Role stock objects/modules are not byte-identical')
    require(a['linked_sources']==b['linked_sources'],'Actual PROCESS object family differs')
    support_paths=dict(fp['support_paths']);support_paths.pop('deadline')
    support_paths['compiler']='tools/tirust_benchmark_compiler.py'
    support_paths['runtime']='.tirust-build/generic-owned-CMS-plain-build-proposal-2/cms_runtime.py'
    support_files={}
    family=read(ROOT/'.tirust-build/qp-mass-current-qualification-proposal-2/support-pins.json')['files']
    for name,h in family.items():require(sha(ROOT/name)==h,'Qualified support changed');support_files[name]=ident(ROOT/name)
    for name in support_paths.values():support_files[name]=ident(ROOT/name)
    for name in ('.tirust-build/generic-owned-snapshot-qualification-proposal-2/unit_runtime.py',):support_files[name]=ident(ROOT/name)
    for name,meta in fp['support_files'].items():
        if name.startswith('/'):
            continue
        if (ROOT/name).is_file():support_files[name]=ident(ROOT/name)
    flags={scope:sorted({tuple(row['flags']) for row in data['recipes'].values()}) for scope,data in fp['case']['compiler_flags']['scopes'].items()}
    reference={'policy_classes':{scope:[list(x) for x in value] for scope,value in flags.items()},'original_compiler_environment':{},'support_gen_children_individually_journalled':False}
    files={'driver':{'path':'check_sa.f',**ident(fresh/'check_sa.f')},'ownership':{'path':str(GEN/'ownership.py'),**ident(GEN/'ownership.py')},'tool_environment':{'path':str(fresh/'tool_environment.py'),**ident(fresh/'tool_environment.py')}}
    include_line=next(line for line in (Path(a['output'])/'SubProcesses/MadLoop_makefile_definitions').read_text().splitlines() if line.startswith('LOOP_INCLUDE = '))
    import shlex
    tokens=shlex.split(include_line.split('=',1)[1]);external_dirs=[]
    while tokens:
        require(tokens.pop(0)=='-I','Unexpected literal LOOP_INCLUDE syntax');path=Path(tokens.pop(0));require(path.is_absolute() and path.is_dir(),'External include root changed');external_dirs.append(str(path.resolve()))
    intrinsic=Path('/nix/store/g825z4hlkyiqm8zpv4kbjkvw5fl901pz-gfortran-15.2.0/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/finclude')
    require(intrinsic.is_dir(),'Pinned GNU intrinsic module directory missing')
    external_inputs={str(q.resolve()):ident(q) for directory in [*map(Path,external_dirs),intrinsic] for q in directory.rglob('*') if q.is_file() and q.suffix.lower() in {'.mod','.inc','.h','.f','.f90','.for'}}
    actual_review=ROOT/'.tirust-build/ew-qp-mass-actual-source-correspondence-review-1/receipt.json'
    require(sha(actual_review)=='5e9ba7d71757d08a58f3e9a8834e26cb8e51667163162e25f7d9c171892a1570','Actual textual correspondence receipt changed')
    data={'schema':'ew-qp-mass-build-inputs-v1','generation_source_index_sha256':GEN_SHA,'generation_source':str(GEN),'roles':roles,
        'support_paths':support_paths,'support_files':support_files,'protected_files':protected,'compiler_environment_names':fp['compiler_environment_names'],
        'library_paths':fp['library_paths'],'expected_runtime':fp['expected_runtime'],'expected_mtirust_symbols':fp['expected_mtirust_symbols'],
        'reference_policy':reference,'driver':files['driver'],'helper_origins':files,
        'external_include_directories':external_dirs,'intrinsic_include_directory':str(intrinsic),'external_compile_inputs':external_inputs,
        'expected_actual_source_review':{'path':str(actual_review.relative_to(ROOT)),**ident(actual_review)},
        'frozen_inputs':{n:{'path':'inputs/'+n,**ident(GEN/'inputs'/n)} for n in ('cache0.dat','param_card.dat','ordinary100.dat','targets2.dat')}}
    return data

def write():
    require(not (HERE/'input-pins.json').exists(),'Fresh preparation only')
    fresh=ROOT/'.tirust-build/qp-mass-fresh-cli-qualification-proposal-1'
    data=produce()
    shutil.copyfile(fresh/'check_sa.f',HERE/'check_sa.f');shutil.copyfile(fresh/'tool_environment.py',HERE/'tool_environment.py');shutil.copyfile(GEN/'ownership.py',HERE/'ownership.py')
    shutil.copyfile(fresh/'toolchain-pins.json',HERE/'toolchain-pins.json');(HERE/'inputs').mkdir(exist_ok=True)
    for n in ('cache0.dat','param_card.dat','ordinary100.dat','targets2.dat'):shutil.copyfile(GEN/'inputs'/n,HERE/'inputs'/n)
    dump(HERE/'input-pins.json',data)

if __name__=='__main__':write()
