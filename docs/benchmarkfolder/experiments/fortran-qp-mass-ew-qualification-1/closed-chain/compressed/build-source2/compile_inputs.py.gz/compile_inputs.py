"""Bound literal INCLUDE and USE inputs for the actual fixed-form source family.

Different existing candidates are refused rather than guessing include-search
precedence. Continued INCLUDE literals and unsupported USE forms fail closed.
"""
from pathlib import Path
import hashlib,re

def require(ok,message):
    if not ok:raise ValueError(message)
def ident(p):
    p=Path(p);return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def directives(text):
    lines=text.splitlines();result=[];i=0
    while i<len(lines):
        raw=lines[i];i+=1
        if not raw or raw[0] in 'Cc*!#':continue
        code=raw[6:132] if len(raw)>6 else ''
        if not re.match(r'(?i)^\s*(INCLUDE|USE)\b',code):continue
        immediate=re.fullmatch(r"\s*INCLUDE\s+(['\"])([^'\"]+)\1\s*(?:!.*)?",code,re.I)
        if immediate:
            # INCLUDE is processed before Fortran continuation syntax; the
            # following continuation may belong to the inserted type text.
            result.append(('include',immediate.group(2)));continue
        require(not re.match(r'(?i)^\s*INCLUDE\b',code),'Nonliteral/continued INCLUDE outside scope')
        joined=code
        while i<len(lines) and lines[i] and lines[i][0] not in 'Cc*!#' and len(lines[i])>5 and lines[i][5] not in ' 0':
            # A literal crossing a physical line invokes fixed-source padding;
            # the current family has none and requires separate audit if added.
            require(joined.count("'")%2==0 and joined.count('"')%2==0,'Continued dependency literal outside scope')
            joined+=' '+lines[i][6:132];i+=1
        m=re.fullmatch(r"\s*INCLUDE\s+(['\"])([^'\"]+)\1\s*(?:!.*)?",joined,re.I)
        if m:result.append(('include',m.group(2)));continue
        m=re.fullmatch(r'\s*USE\s*(?:,\s*(?:NON_)?INTRINSIC\s*)?(?:::)?\s+([A-Z][A-Z0-9_]*)(?:\s*,.*)?\s*(?:!.*)?',joined,re.I)
        require(m is not None,'Unparsed fixed-form dependency: '+joined)
        result.append(('module',m.group(1).lower()))
    return result

def include_dirs(argv,cwd):
    result=[];i=1
    while i<len(argv):
        a=argv[i];i+=1
        if a=='-I':require(i<len(argv),'Missing include directory');a=argv[i];i+=1
        elif a.startswith('-I'):a=a[2:]
        else:continue
        p=(Path(cwd)/a).resolve();require(p.is_dir(),'Missing include directory');result.append(str(p))
    return result

def bind(source,argv,output,row,pins,generated):
    output=Path(output).resolve();source=Path(source).resolve();cwd=source.parent
    dirs=include_dirs(argv,cwd)
    allowed={str((output/'Source/MODEL').resolve()),str((output/'Source/DHELAS').resolve()),*pins['external_include_directories']}
    require(set(dirs)==allowed,'Actual compile include-directory closure differs')
    roots=[cwd,*map(Path,dirs),Path(pins['intrinsic_include_directory'])];seen={};edges=[]
    def check(path):
        path=Path(path).resolve();actual=ident(path)
        if path.is_relative_to(output):
            name=str(path.relative_to(output))
            if name in row['expected_build_sources']:wanted=row['expected_build_sources'][name]
            elif name in row['support_modules']:wanted=row['support_modules'][name]
            elif name=='SubProcesses/P0_epem_ttxa/mpmodule.mod':wanted=row['canonical_libraries']['lib/mpmodule.mod']
            else:wanted=generated.get(str(path))
        else:wanted=pins['external_compile_inputs'].get(str(path))
        require(wanted==actual,'Unbound/changed actual compile input: '+str(path));seen[str(path)]=actual;return actual
    def choose(name,parent,kind):
        search=([parent,*roots] if kind=='include' else roots)
        candidates=[]
        for directory in search:
            p=directory/name
            if p.is_file() and p.resolve() not in candidates:candidates.append(p.resolve())
        require(candidates,'Unresolved '+kind+': '+name)
        signatures=[check(p) for p in candidates]
        require(all(v==signatures[0] for v in signatures),'Different candidate contents make search order material: '+name)
        edges.append({'kind':kind,'literal':name,'candidates':[str(p) for p in candidates],'identity':signatures[0]})
        return candidates[0]
    stack=set()
    def walk(path):
        path=Path(path).resolve();require(path not in stack,'Recursive INCLUDE outside scope');stack.add(path);check(path)
        text=path.read_text();own={x.lower() for x in re.findall(r'(?im)^\s*module\s+(?!procedure\b|function\b|subroutine\b)([a-z][a-z0-9_]*)\s*(?:!.*)?$',text)}
        for kind,name in directives(text):
            if kind=='include':walk(choose(name,path.parent,kind))
            elif name in own:edges.append({'kind':'same-source-generated-module','name':name,'producer':str(path),'source_sha256':ident(path)['sha256']})
            elif name in {'iso_c_binding','iso_fortran_env'}:edges.append({'kind':'GNU-intrinsic-builtin','name':name,'compiler_closure_bound':True})
            else:choose(name+'.mod',path.parent,kind)
        stack.remove(path)
    walk(source)
    return {'source':str(source),'include_directories':dirs,'bound_files':seen,'edges':edges,'scope':'Actual literal source dependencies; equal-content candidates only; fresh same-source and GNU builtin modules explicit'}
