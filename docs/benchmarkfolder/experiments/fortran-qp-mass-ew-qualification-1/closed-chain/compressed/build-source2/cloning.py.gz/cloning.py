"""Fresh private clone with only the exact two immutable NinjaRS aliases."""
from pathlib import Path
import hashlib
import shutil
SHARED={'lib/ninjars_include','lib/ninjars_lib'}
CAP=512*1024**2

def require(ok,message):
    if not ok:raise ValueError(message)
def identity(p):
    p=Path(p);return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def links(root):
    return {str(p.relative_to(root)):{'readlink':str(p.readlink()),'resolved':str(p.resolve()),'directory':p.is_dir()} for p in sorted(Path(root).rglob('*')) if p.is_symlink()}
def below_shared(relative):
    p=Path(relative);return any(p==Path(n) or Path(n) in p.parents for n in SHARED)
def writable(relative):
    p=Path(relative);require(not p.is_absolute() and '..' not in p.parts and not below_shared(p),'Write outside private mutable clone')
def validate_shared(root,aliases):
    require(set(aliases)==SHARED,'Only two NinjaRS shared aliases are permitted')
    result={}
    for name,row in aliases.items():
        p=Path(root)/name;target=Path(row['canonical_target'])
        require(p.is_symlink() and str(p.readlink())==row['readlink'] and p.resolve()==target,'Shared alias changed')
        entries={p.name:p for p in target.iterdir()};require(set(entries)==set(row['leaves']),'Shared leaf set changed')
        for leaf,pin in row['leaves'].items():
            q=entries[leaf];require(not q.is_symlink() and q.is_file() and identity(q)==pin,'Shared regular leaf changed')
        result[name]=row
    return result

def clone(source,target,expected_links,aliases):
    source,target=Path(source),Path(target)
    require(links(source)==expected_links,'GEN alias inventory changed');validate_shared(source,aliases)
    def ignore(directory,names):
        return [n for n in names if str((Path(directory)/n).relative_to(source)) in SHARED or n=='__pycache__' or n.endswith(('.pyc','.fifo','HelFilter.dat','LoopFilter.dat')) or n=='check']
    def copy_private(src,dst):
        relative=Path(dst).relative_to(target);writable(relative)
        require(Path(dst).parent.resolve().is_relative_to(target.resolve()) and 0<=Path(src).stat().st_size<=CAP,'Unsafe/oversized private copy')
        return shutil.copy2(src,dst)
    shutil.copytree(source,target,symlinks=False,ignore=ignore,copy_function=copy_private)
    for name,row in aliases.items():(target/name).symlink_to(row['canonical_target'],target_is_directory=True)
    require(links(target)=={name:{'readlink':row['canonical_target'],'resolved':row['canonical_target'],'directory':True} for name,row in aliases.items()},'Unexpected private alias')
    validate_shared(target,aliases);validate_shared(source,aliases)
