# Dormant EW target driver and BUILD proposal 1

This is a source proposal for `e+ e- > t t~ a [virt=QED]`, original0fcd versus the five-file mass candidate. It does not execute a compiler, loader, model or amplitude during source preflight or pure tests. Root must accept an independent review of this exact source seal before separately admitting BUILD. A clean BUILD and independent closed-BUILD review are then required before any target RUN. No RUN controller is implemented here, and BUILD never starts one automatically.

The parent is the independently closed EW BUILD2: source `f245a10696fea62dad8a7bb116675ea43e09d5e3376686d3433bbc3f47d24f2f`, terminal `f7cac8b007f41e09964b95c9a0fb6172cb0f4eaa249ed3192188f9fa1af46b22`, result `60a99e609b0aae3576c31f3f49cf6a250f21dfa1e7dbc670e95f4c49ac72d603`, independent review `fa3e423b60d76d840efe66376ec47d00b8ffb73642192f3504eb3bfcbbefa9be`, and root BUILD gate `d19814faae3c2e5e6ae2235e2b7b87dbb25337021ff497cdec8bc7b204576ebf`. The immutable ordinary RUN source is `0c6792e4531a9da678f098f9b9ceb93479f21734c9c06e731316139a9f45cd41`; its qualified binding authenticates all 571 closed BUILD report files before reading live reused objects, libraries, source or runtime providers. Input pins retain the already converted model indirectly through that reviewed complete source/object closure; no conversion, installation, bridge revision or model change occurs here.

The source-only default invocation is:

```sh
cd /shared/external/madloop_tirust/madgraph7_madloop_tirust
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/ew-qp-mass-target-build-proposal-1/controller.py --source SOURCE_INDEX_SHA256
```

After independent source review and separate root admission, the exact standalone BUILD command is:

```sh
cd /shared/external/madloop_tirust/madgraph7_madloop_tirust
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/ew-qp-mass-target-build-proposal-1/controller.py --source SOURCE_INDEX_SHA256 --build-gate .tirust-build/ew-qp-mass-root-reviewed-build-1.json --build-gate-sha d19814faae3c2e5e6ae2235e2b7b87dbb25337021ff497cdec8bc7b204576ebf --execute
```

`SOURCE_INDEX_SHA256` is the SHA-256 of this directory's `source-index.json`, supplied outside this immutable payload to avoid a self-reference. This is one serial BUILD stage covering both arms, with a 900-second all-in cap starting at the first controller instruction in the initial interpreter, including a 60-second cleanup reserve. It uses nonexclusive CPU12, the existing numerical mutex, 16 GiB address-space and 512 MiB per-file caps, zero core dumps, one owned process session, inherited qualified cleanup/raw-Popen failure handling, and a fresh work/report namespace. It performs no retry. Parent source/runtime inputs are authenticated before and after the stage. The work and report roots are respectively `.tirust-build/ew-qp-mass-target-build-work-1` and `.tirust-build/ew-qp-mass-target-build-execution-1`.

Each arm copies the actual closed BUILD tree with only the two authenticated NinjaRS aliases and their exact regular leaves. Its 21 process objects, 344 stock objects, four stock modules, two process modules and five canonical library/module leaves remain unchanged. The one new `target_driver.f` uses the same exact driver compiler recipe, include-directory closure, typed model includes, IEEE modules and compiler environment. The actual include/module binding proof is written before compilation. Only `target_driver.f` is compiled. The final link replaces exactly `check_sa.o` with `target_driver.o`, preserving the other 20 scientific objects in order and all flags/libraries. The old normal driver object remains as an unchanged private file but is never linked. New output/map basenames are `target-check` and `target-link.map`. The controller checks actual link LOADs, static ELF/runtime closure, loader `--list` metadata, 15 runtime providers, and unique main/driver/23 MTIRUST/private helper symbols. No scientific process source is compiled again. No makefile is changed. These future compiler/linker/metadata children are BUILD scope; no scientific main, model probe or reducer is invoked.

## Driver semantics and later RUN requirements

The exact ordinary100 stream is `56294e1d42f0524d9d04ac451cf0f5a098dace5dd10d2a4970b27286ed0e955f`; the exact independent ordinary-control/threshold-soft-photon target2 stream is `f1663e764a65d5b9ca89691177f3607ba85f3daff8b52af9360b1a4f09e26de3`. The first target is exactly ordinary point1. Cards remain physical `891e4b89d522804e1f21c3f8b19b8cc2209b29cbfb7809189a5e7062c1363ea8` and finite/all-poles/cache0/UseQPTrue `97aaad78a84d4fd4b122caab7ed56c8cff63988b53ff6b29dd16d463b61b69a1`. The normal forced threshold is `1e-6`. Ordinary and target buffers and argv positions are separate; targets never enter learning. `ordinary-learning-reference.f` and `qualified-helper-reference.f` are exact unchanged slices from the closed compiled ordinary driver.

After ordinary-only bootstrap and a complete accepted100 learning sweep, the driver observes actual `ML5_0_INIT` and `ML5_0_FILTERS`: CHECKPHASE must be false and HELDOUBLECHECKED true before READY. It records the actual 32 GOODHEL integers, 200 GOODAMP logical values, HELOFFSET and INIT flags before and after each target. These dimensions come from the exact hash-bound generated `loop_matrix.f`. No common state, filter or IEEE flag is restored or assigned by the driver. Target commands are `TARGETS 1 0`, reply `TARGETED 1 2`, then `STOP 0 0`, `BYE`, exit0. There are two normal `SLOOPMATRIX_THRES` requests in the target loop even if the first returns numerical refusal. Only infrastructure/protocol/I/O failure or native abort prevents later requests. Fixed CTMode4 is not used and must not be counted as automatic rescue.

Raw records preserve every answer column's Born/finite/simple/double/accuracy words and public status, before/after **public caller** P and MU_R words, IEEE flags/halting/rounding, and software failure latches. Caller records do not establish the actual reduction inputs: repaired internal momenta, native q/masses/scales and precision constructors remain unobserved. The parser exposes `caller_P`, `caller_MU_R` and `canonical_repaired_or_native_input_claim=False` explicitly. No geometry/clamp modification or truth claim is introduced.

The pure API is `protocol.raw(text)`, `protocol.readiness(text, dimensions)`, `protocol.caller_input_check(target_stream, parsed_raw)` and `protocol.ordinary_control(closed_ordinary_rows, parsed_raw, compare_rows)`. It requires a complete target2 stream and exact readiness records, preserves nonfinite words as JSON-safe diagnostics, and distinguishes public TIRust DP `(H,U)=(2,9)` from QP `(3,3)`. Only accepted finite rows with finite accuracy in `[0,1e-6]` are comparison eligible. Ordinary target1 must have accepted parity with its own arm's independently closed ordinary point1 under `3e-6` and hard `1e-8` criteria and equal status. Refused/unchecked buffers are never truth or references. Target2 is observed without forced baseline/candidate success. Even an accepted target2 does not establish scientific qualification without independent finite/pole truth. Current ordinary pair observations are DP-only and do not qualify the EW QP mass path.

Later RUN source must independently bind the newly reviewed target BUILD, fresh regular runtime/resource/card copies (including Cards/ident_card.dat), frozen ordinary/target/card inputs and the own-arm closed ordinary reference. It must retain actual process PID/start/session/CPU, target ELF and 15-provider maps at READY and after TARGETED; strict protocol without unread FIFO tail; complete learning, raw answers, readiness and stdout diagnostics; STOP/BYE/exit0; final post-shutdown hashes and owned cleanup. This packet deliberately implements none of that RUN admission or execution. It does not inspect any actual target result, canonical/native observer input or perform a performance measurement.

Pure verification commands, safe before any BUILD admission:

```sh
cd /shared/external/madloop_tirust/madgraph7_madloop_tirust
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/ew-qp-mass-target-build-proposal-1/test_pure.py
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B -O .tirust-build/ew-qp-mass-target-build-proposal-1/test_pure.py
```

All packet payloads and exact source-only lineage are in the source index. Existing GEN, reviewer helper1/2, BUILD1/2 and ordinary RUN histories remain untouched. No production, reference, public report or Git changes belong to this packet.
