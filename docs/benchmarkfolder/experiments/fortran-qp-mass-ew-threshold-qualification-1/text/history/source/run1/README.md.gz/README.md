# Dormant target RUN source proposal 1

This frozen proposal is separate from the compiled target-driver/BUILD source `276ac5e9539e90882cc31a31d62d23da82b67626e17bb1a5af00dfa1048548a6`. The independently reviewed closed target BUILD is bound by outside root gate `.tirust-build/ew-qp-mass-target-root-reviewed-build-1.json`, SHA `9429ebafb63ba633cb1d8ce95d179cdff0365c6b7b6a7291469db7e24965e18b`. The exact compiled-source index, terminal `f5b438a5edb10a620db884c48a6f4df48d0fb057767af732a18c06c20f895d6d`, result `4adf0d4f2a480d4e4d92171cb5adea8057e83b12e65a1783cf211678c8f911ff`, 341-file raw inventory `a9c9b5d4dd90fb4611de69044e1c0d591ce702589117415aa13628fdef1b2fba` and independent review `62f307ab726e1911ee6bc55f06286ea536a6a8d331e59a64101c0bd6fe1086d9` are pinned independently of this new RUN source seal. Source preparation reads closed receipt text only; no target ELF, object or runtime provider is read until an admitted RUN binder authenticates the full closed inventory and joins to the reviewed parent BUILD.

The existing ordinary reference gate is pinned exactly at `.tirust-build/ew-qp-mass-root-reviewed-ordinary-1.json`, SHA `c20854f8e1f447ff8c9f99052caa9fde2c27e786b257367eb7ed06f49196accf`, with independent receipt `f34cf67f3b21ecd934d67e40c14534c9d2a8a7ba8332464286a3234e6b4ce391`. It authorizes the accepted own-arm ordinary point1 as a regression control only. Both ordinary observations were DP219; independent truth and the EW QP mass path remain unqualified. Binding an ordinary reference authenticates its existing exact root gate, terminal/result, complete raw inventory and a replay of the frozen ordinary collector.

Neither numerical role is admitted by this source packet or the BUILD gate. Root must first accept independent review of this exact RUN seal, then separately admit original. Candidate additionally requires root review of the closed original target observation. No automatic progression or retry occurs.

Source-only preflight (replace RUN_SOURCE_INDEX_SHA256 with the externally supplied hash of source-index.json):

```sh
cd /shared/external/madloop_tirust/madgraph7_madloop_tirust
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/ew-qp-mass-target-run-proposal-1/controller.py --source RUN_SOURCE_INDEX_SHA256
```

After independent source review and separate root admission, the exact original command is:

```sh
cd /shared/external/madloop_tirust/madgraph7_madloop_tirust
/nix/store/4jddwqz8nx9v4p4wzvhz1kfg88gnjcv8-python3-3.13.12-env/bin/python3 -B .tirust-build/ew-qp-mass-target-run-proposal-1/controller.py --source RUN_SOURCE_INDEX_SHA256 --role original --build-gate .tirust-build/ew-qp-mass-target-root-reviewed-build-1.json --build-gate-sha 9429ebafb63ba633cb1d8ce95d179cdff0365c6b7b6a7291469db7e24965e18b --execute
```

The candidate command changes only `--role candidate` and adds `--reviewed-original REVIEWED_ORIGINAL_TARGET_RUN_TERMINAL_SHA256`; it requires its own root admission. The source-index hash is supplied outside this immutable payload to avoid a self-reference.

Each role has one 900-second total cap from the first controller instruction, with a 60-second cleanup reserve inside that cap and 180 seconds per protocol reply. Limits are 16 GiB address space, 512 MiB per file, zero core files, nonexclusive CPU12 and the existing numerical mutex. Qualified owned-session supervision, deferred-handoff handling and raw-Popen failure cleanup are reused. Proposed work/report roots are `.tirust-build/ew-qp-mass-target-run-work-1` and `.tirust-build/ew-qp-mass-target-run-execution-1`. All writes remain in these ignored roots; sources, providers, production and references are unchanged.

Fresh per-role runtime preparation copies the exact 16 regular card/resource files from the reviewed target BUILD plus the actual target-check ELF. This includes Cards/ident_card.dat and all local/fallback MadLoop resource inputs. No filter is inherited. Both immutable point streams are separate argv buffers: full ordinary100 `56294e1d42f0524d9d04ac451cf0f5a098dace5dd10d2a4970b27286ed0e955f` and exact target2 `f1663e764a65d5b9ca89691177f3607ba85f3daff8b52af9360b1a4f09e26de3`. Physical and finite/all-poles/cache0/UseQPTrue cards retain hashes `891e4b89d522804e1f21c3f8b19b8cc2209b29cbfb7809189a5e7062c1363ea8` and `97aaad78a84d4fd4b122caab7ed56c8cff63988b53ff6b29dd16d463b61b69a1`. The forced normal stability threshold remains 1e-6.

The strict worker accepts only `TARGETS 1 0`, requires `TARGETED 1 2`, and shuts down with exact `STOP 0 0`, `BYE`, exit0 and no buffered or unread FIFO tail. The target driver learns only on ordinary100, observes actual readiness after learning, and requests both normal SLOOPMATRIX_THRES targets even on numerical refusal. Raw outputs contain all returned Born/finite/simple/double/accuracy/status words, public caller P/MU_R before and after, IEEE/rounding/halting observations, software latches and five actual INIT/full32 GOODHEL/full200 GOODAMP snapshots. The collector checks the separate initial readiness snapshot against the final full state stream. It never writes or restores INIT/filter/IEEE state.

Actual mapped files plus PID, parent, process group, session, start ticks and CPU are retained at READY and after TARGETED. The exact target ELF and 15 runtime provider hashes must be observed; anonymous mapping changes remain allowed. Full learning and target stdout/stderr are continuously drained to worker.log, including warnings; the target driver does not redirect these to /dev/null. Raw files are hashed before shutdown and copied/rechecked after STOP/BYE/exit0. Runtime files and protected reused source/object/provider identities are rechecked at closure. Failure paths retain first-failure evidence and all available partial raw files without retry.

Target1 requires accepted own-arm ordinary point1 parity under 3e-6 and hard1e-8 coefficient criteria and equal public status. Full100 learning is validated independently. Target2 status, words and numerical estimates are observed without requiring either arm to succeed, without a forced QP cohort and without treating420/unchecked/nonfinite buffers as truth. If both target2 arms are comparison eligible, their numerical comparison is retained as a diagnostic; this does not establish physical truth. All accepted/refused statuses and nonfinite word classes remain visible. A completed observation stage is not scientific qualification.

`caller_P` and `caller_MU_R` always mean the public call's actual buffers. Internal repaired momenta, native reduction momenta/masses/scales and precision constructors remain unobserved. Source inspection of MP mass use during phase-space repair does not count as an actual native-input witness. The mass candidate preserves QP squaring of a model mass lifted from DP input; this protocol does not claim 113-bit physical model input precision or independent finite/pole truth. No geometry/clamp changes, backend repins, fixed CTMode4, performance qualification or production promotion are introduced.

Pure tests use clearly synthetic data only; they do not manufacture an actual result or target outcome. Run `python3 -B test_pure.py` and `python3 -B -O test_pure.py` with the pinned Python. Source preflight authenticates this proposal and retained source/receipt text without invoking the live BUILD/runtime binder.
