#!/usr/bin/env python3
"""Dormant target EW roles; independent compiled BUILD and own ordinary controls."""
import time
BOOTSTRAP_MONOTONIC=time.monotonic()
import argparse,fcntl,hashlib,importlib.util,json,os,resource,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/ew-qp-mass-target-run-work-1'
REPORT=ROOT/'.tirust-build/ew-qp-mass-target-run-execution-1'
ROLES=('original','candidate');CPU,CAP,CLEANUP=12,900.,60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
PROC='SubProcesses/P0_epem_ttxa'
RAW=('warmup.dat','dimensions.dat','target-raw.dat','target-readiness.dat')
SOURCE=None;BUILD_GATE=None;BUILD_GATE_SHA=None;REVIEWED_ORIGINAL=None

def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def pins():return read(HERE/'input-pins.json')
def dump(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location('_ew_target_run_'+name,path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
def local(name):return load(name,HERE/(name+'.py'))
def tool(name):return read(HERE/'toolchain-pins.json')['required_tools'][name]['path']
def environment(role):
    p=pins();env=local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),p['compiler_environment_names'],{},p['library_paths'])
    env.update(XDG_CONFIG_HOME=str(WORK/role/'xdg/config'),XDG_STATE_HOME=str(WORK/role/'xdg/state'),XDG_DATA_HOME=str(WORK/role/'xdg/data'))
    return env

def namespace():
    base=ROOT/'.tirust-build'
    for path in (WORK,REPORT):require(not path.is_symlink() and path.resolve().is_relative_to(base),'Work/report namespace escaped/aliased')
def verify_source():
    require(Path.cwd()==ROOT and SOURCE and digest(HERE/'source-index.json')==SOURCE,'Exact reviewed source seal/cwd required')
    index=read(HERE/'source-index.json');actual=set();directories={str(p) for name in index['files'] for p in Path(name).parents if str(p)!='.'}
    for p in HERE.rglob('*'):
        require(not p.is_symlink(),'Proposal source alias forbidden')
        if p.is_file():actual.add(str(p.relative_to(HERE)))
        else:require(p.is_dir() and str(p.relative_to(HERE)) in directories,'Unexpected proposal directory')
    require(actual==set(index['files'])|{'source-index.json'},'Exact proposal payload inventory changed')
    for name,row in index['files'].items():require(ident(HERE/name)==row,'Proposal source changed')
    p=pins()
    for field in ('compiled_source','ordinary_source'):
        row=p[field];base=Path(row['directory']);require(digest(base/'source-index.json')==row['source_index_sha256'],'Retained source index changed')
        for name,record in read(base/'source-index.json')['files'].items():require(ident(base/name)==record,'Retained source payload changed')
    compiled=Path(p['compiled_source']['directory']);require(ident(compiled/'target_driver.f')=={k:p['driver'][k] for k in ('bytes','sha256')},'Actual compiled target driver source changed')
    ordinary=Path(p['ordinary_source']['directory']);require(ident(HERE/'process_cleanup.py')==ident(ordinary/'process_cleanup.py'),'Qualified cleanup helper changed')
    require(digest(HERE/'ordinary-reference-gate.json')==p['ordinary_reference_gate']['sha256'] and digest(HERE/'ordinary-reference-review.json')==p['ordinary_reference_review']['sha256'],'Pinned ordinary reference source text changed')
    require(digest(HERE/'target-BUILD-gate.json')==p['root_target_BUILD_gate']['sha256'] and digest(HERE/'target-BUILD-review.json')==p['independent_target_BUILD_review']['sha256'],'Pinned closed target BUILD receipt text changed')
    local('binding').accept_gate(read(HERE/'target-BUILD-gate.json'),p)
    for name,row in p['frozen_inputs'].items():require(ident(HERE/'inputs'/name)==row,'Frozen ordinary/target/card input changed')
    namespace()
    return {'status':'source-only-preflight-passed','source_index_sha256':SOURCE,'BUILD_gate_supplied':False,'live_BUILD_or_runtime_files_read':False,'native_calls':0,'compiler_queries':0,'loader_queries':0,'MG_runtime_imports':0,'cap_seconds_per_role':CAP,'cleanup_reserve_inside_cap':CLEANUP,'cpu':CPU,'cpu_reservation':False}

def reviewed_build():return local('binding').closed(BUILD_GATE,BUILD_GATE_SHA)
def clone_runtime(role,closed):
    row=closed['result']['variants'][role];donor=Path(row['output']);output=WORK/role
    require(not output.exists() and not output.is_symlink(),'Fresh isolated role required; no retry');output.mkdir(parents=True)
    planned={**pins()['data_pins'][role],PROC+'/target-check':{'sha256':row['executable_sha256']}}
    for name,record in planned.items():
        source=donor/name;require(source.is_file() and not source.is_symlink() and source.resolve().is_relative_to(donor.resolve()),'Runtime source not a bound regular in-BUILD file')
        require(digest(source)==record['sha256'] and source.stat().st_size<=LIMITS['file_bytes'],'Runtime copy source changed/exceeds file limit')
        target=output/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);require(digest(target)==record['sha256'],'Runtime copy changed')
    require(not any(p.is_symlink() for p in output.rglob('*')),'Runtime aliases forbidden')
    return output,planned

def runtime_binding(output,planned):
    for name,row in planned.items():require(digest(output/name)==row['sha256'],'Private executable/card/static resource changed')
    params={str(p.relative_to(output)):digest(p) for p in output.rglob('MadLoopParams.dat')}
    expected={name:pins()['frozen_inputs']['cache0.dat']['sha256'] for name in planned if name.endswith('MadLoopParams.dat')}
    require(params==expected,'Resolved numerical card copy changed')
    return {'runtime_files':len(planned),'numerical_cards':params,'physical_card_sha256':digest(output/'Cards/param_card.dat'),'identifier_card_sha256':digest(output/'Cards/ident_card.dat')}

def maps(worker):
    raw=Path('/proc/'+str(worker.process.pid)+'/maps').read_text();found={}
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'Deleted runtime mapping');name=str(Path(fields[-1]).resolve());found[name]=digest(name)
    p=pins();exe=(worker.directory/'target-check').resolve();allowed={**p['expected_runtime']['files'],**p['extra_mappings'],str(exe):digest(exe)}
    require(all(found.get(name)==h for name,h in p['expected_runtime']['files'].items()) and found.get(str(exe))==digest(exe),'Initialized15-provider/ELF mapping incomplete')
    require(all(allowed.get(name)==h for name,h in found.items()),'Unexpected or changed mapped file')
    fields=Path('/proc/'+str(worker.process.pid)+'/stat').read_text();tail=fields[fields.rfind(')')+2:].split()
    return {'pid':worker.process.pid,'parent_pid':int(tail[1]),'process_group':int(tail[2]),'session':int(tail[3]),'start_time_ticks':int(tail[19]),'affinity':sorted(os.sched_getaffinity(worker.process.pid)),'files':found,'raw_maps':raw}

def reviewed_original():
    path=REPORT/'original/terminal.json';require(REVIEWED_ORIGINAL and digest(path)==REVIEWED_ORIGINAL,'Separately reviewed successful original RUN required')
    t=read(path);r=read(REPORT/'original/result.json')
    require(t['status']=='passed' and t['returncode']==0 and not t['cleanup']['survivors'] and t['source_index_sha256']==SOURCE and t['result_sha256']==digest(REPORT/'original/result.json'),'Original RUN receipt changed/failed')
    require(r['stage']=='original' and r['source_index_sha256']==SOURCE and r['BUILD_gate_sha256']==BUILD_GATE_SHA and r['compiled_source_index_sha256']==pins()['compiled_source']['source_index_sha256'],'Wrong original source/BUILD gate')
    require(r['status']=='passed' and r['requested_targets']==2 and r['all_declared_targets_completed'] is True and r['scientific_qualified'] is False and r['lane']['ordinary_control']['passed'] is True,'Original target observation/control incomplete')
    for name,h in r['raw_files'].items():require(digest(REPORT/'original'/name)==h,'Original raw numerical/protocol evidence changed')
    return r

def inventory(report):return {str(p.relative_to(report)):digest(p) for p in sorted(report.rglob('*')) if p.is_file() and p.name not in ('result.json','terminal.json')}
def retained_case_raw(case,report,prefix=''):
    for name in RAW:
        path=case/name
        if path.is_file() and not path.is_symlink():
            destination=report/(prefix+name)
            if not destination.exists():shutil.copy2(path,destination)

def same_worker(before,after):
    fields=('pid','parent_pid','process_group','session','start_time_ticks','affinity','files')
    require(all(before[name]==after[name] for name in fields),'Worker identity/provider maps changed')
    require(before['pid']==before['process_group']==before['session'] and before['affinity']==[CPU],'Actual worker session/CPU differs')
    return {'same_process_and_file_providers':True,'anonymous_VMA_changes_allowed':True}

def run(role):
    binding=local('binding');closed=reviewed_build();manifest=binding.live_manifest(closed);before=binding.verify_live(manifest);ordinary=binding.ordinary_reference(role);reference=reviewed_original() if role=='candidate' else None
    output,planned=clone_runtime(role,closed);case=output/PROC;report=REPORT/role;initial=runtime_binding(output,planned);collector=local('collector');comparison=local('comparison');Worker=local('worker').Worker
    command=[tool('taskset'),'-c',str(CPU),str(case/'target-check'),str(HERE/'inputs/ordinary100.dat'),str(HERE/'inputs/targets2.dat')];dump(report/'worker-command.json',{'argv':command,'cwd':str(case),'compiled_source_index_sha256':pins()['compiled_source']['source_index_sha256'],'driver_source_sha256':pins()['driver']['sha256'],'executable_sha256':digest(case/'target-check')})
    worker=None
    try:
        with Worker(command,case,report/'worker.log',env=environment(role),timeout=180.) as worker:
            require([worker.points,worker.ndim,worker.nso,worker.nborn]==[100,1,1,1],'Wrong ordinary-learning/target dimensions');require(os.sched_getaffinity(worker.process.pid)=={CPU},'Worker CPU differs')
            dump(report/'ready.json',{name:getattr(worker,name) for name in ('points','ndim','nso','nborn','cold_seconds')});first=maps(worker);dump(report/'maps-before.json',first)
            shutil.copy2(case/'target-readiness.dat',report/'ready-readiness.dat');collector.initial_readiness((report/'ready-readiness.dat').read_text(),pins()['actual_filter_dimensions'])
            for name in ('warmup.dat','dimensions.dat'):shutil.copy2(case/name,report/name)
            worker.targets()
            second=maps(worker);dump(report/'maps-after.json',second);identity=same_worker(first,second)
            preclose={name:ident(case/name) for name in RAW};dump(report/'pre-shutdown-raw-identities.json',preclose)
            require(runtime_binding(output,planned)==initial,'Private runtime/card binding changed')
        dump(report/'protocol.json',worker.protocol);require(not (case/'worker-protocol.fifo').exists(),'Worker FIFO survived cleanup')
        require(worker.thread is None or not worker.thread.is_alive(),'Stdout drain did not complete')
        for name,record in preclose.items():require(ident(case/name)==record,'Target raw file changed during shutdown')
        retained_case_raw(case,report)
        for name in RAW:require(ident(report/name)==ident(case/name),'Final retained raw differs from post-shutdown case')
        lane=collector.collect({name:(report/name).read_text() for name in (*RAW,'ready-readiness.dat')},(HERE/'inputs/targets2.dat').read_text(),ordinary,comparison.compare_rows,pins()['actual_filter_dimensions']);dump(report/'collected.json',lane)
        compared=collector.compare(reference['lane'],lane,comparison.compare_rows) if reference else None
        if compared is not None:dump(report/'comparison.json',compared)
        require(runtime_binding(output,planned)==initial,'Private runtime/card binding changed after exit');require(binding.verify_live(manifest)==before,'Closed BUILD/runtime binding changed')
        dump(report/'result.json',{'status':'passed','stage':role,'source_index_sha256':SOURCE,'compiled_source_index_sha256':pins()['compiled_source']['source_index_sha256'],'BUILD_gate_sha256':BUILD_GATE_SHA,'BUILD_terminal_sha256':pins()['closed_target_build']['terminal_sha256'],'BUILD_independent_review_sha256':closed['review_sha256'],'BUILD_raw_inventory_sha256':closed['raw_inventory_sha256'],'reviewed_original':REVIEWED_ORIGINAL,'ordinary_reference':{key:ordinary[key] for key in ('gate_sha256','result_sha256','terminal_sha256','independent_physical_truth','QP_mass_path_qualified')},'lane':lane,'comparison':compared,'runtime_binding':initial,'worker_identity':identity,'normal_CTModeRun':-1,'forced_independent_stability':True,'threshold':1e-6,'finite':True,'LoopPoleMode':0,'UseQPIntegrandForTIRust':True,'TIRust_caches':{'DP':0,'QP':0},'full100_ordinary_learning':True,'requested_targets':2,'all_declared_targets_completed':True,'target2_numeric_success_required':False,'QP_cohort_required':False,'protocol_complete':True,'full_stdout_retained':True,'stdout':ident(report/'worker.log'),'protected':before,'scope':'Two normal public THRES observations after actual ordinary-only readiness. Caller_P/MU_R are public-call observations; repaired/native reduction inputs and constructors remain unobserved. Numeric target2 refusal is retained; no independent physical truth or QP path qualification.','independent_physical_truth':False,'scientific_qualified':False,'source_promoted':False,'performance_acceptance':False,'raw_files':inventory(report)})
    except BaseException as error:
        retained_case_raw(case,report,'failure-')
        if worker is not None and not (report/'failure-protocol.json').exists():dump(report/'failure-protocol.json',worker.protocol)
        dump(report/'first-failure.json',{'type':type(error).__name__,'error':str(error),'raw_retained':True,'retry':False,'scientific_qualified':False});raise
    finally:binding.verify_live(manifest)

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard limit too low');resource.setrlimit(kind,(value,value))
def child(role):
    a=read(REPORT/role/'admission.json');require(a['parent_pid']==os.getppid() and a['source_index_sha256']==SOURCE and a['BUILD_gate_sha256']==BUILD_GATE_SHA and a['BUILD_gate']==BUILD_GATE and a['reviewed_original']==REVIEWED_ORIGINAL and a['role']==role,'Exact supervisor admission required')
    require(os.sched_getaffinity(0)=={CPU},'Child CPU changed')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limit changed')
    verify_source();run(role)
def supervise(role):
    end=BOOTSTRAP_MONOTONIC+CAP;cleanup=local('process_cleanup');owner=local('ownership');directory=REPORT/role;require(not directory.exists(),'Fresh role report required; no retry');directory.mkdir(parents=True)
    entry={'role':role,'source_index_sha256':SOURCE,'BUILD_gate':BUILD_GATE,'BUILD_gate_sha256':BUILD_GATE_SHA,'reviewed_original':REVIEWED_ORIGINAL,'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'bootstrap_monotonic':BOOTSTRAP_MONOTONIC,'original_end_monotonic':end,'status':'running'};process=None;raw=None;owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,owner.StageDeadline(CAP,absolute_end=end) as deadline:
            entry['deadline_monotonic']=deadline.end;limits();verify_source();reviewed_build();requests.check();require(not (WORK/role).exists(),'Fresh role work required')
            if role=='candidate':reviewed_original()
            command=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(HERE/'controller.py'),'--source',SOURCE,'--role',role,'--build-gate',BUILD_GATE,'--build-gate-sha',BUILD_GATE_SHA,'--child']
            if REVIEWED_ORIGINAL:command+=['--reviewed-original',REVIEWED_ORIGINAL]
            dump(directory/'admission.json',{**entry,'parent_pid':os.getpid(),'command':command});env=environment(role)
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);raw=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry);entry['returncode']=owned.wait(requests);requests.check();entry['cleanup']=owner.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'RUN failed; no retry');verify_source();reviewed_build();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'));dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=owner.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else owner.raw_cleanup(process,raw,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));dump(directory/'terminal.json',entry);raise

def main():
    global SOURCE,BUILD_GATE,BUILD_GATE_SHA,REVIEWED_ORIGINAL
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--role',choices=ROLES);p.add_argument('--build-gate');p.add_argument('--build-gate-sha');p.add_argument('--reviewed-original');p.add_argument('--execute',action='store_true');p.add_argument('--child',action='store_true',help=argparse.SUPPRESS);a=p.parse_args();SOURCE=a.source;BUILD_GATE=a.build_gate;BUILD_GATE_SHA=a.build_gate_sha;REVIEWED_ORIGINAL=a.reviewed_original
    if a.execute or a.child:
        require(a.role and BUILD_GATE and BUILD_GATE_SHA and bool(REVIEWED_ORIGINAL)==(a.role=='candidate'),'Separate reviewed BUILD/original gates required')
        if a.child:child(a.role)
        else:
            with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise(a.role)
    else:
        require(not a.role and not BUILD_GATE and not BUILD_GATE_SHA and not REVIEWED_ORIGINAL,'Default source preflight accepts no execution gates');print(json.dumps(verify_source(),sort_keys=True))
if __name__=='__main__':main()
