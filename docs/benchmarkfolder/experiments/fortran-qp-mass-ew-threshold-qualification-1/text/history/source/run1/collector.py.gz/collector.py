"""Pure observed target collection; numerical refusal is retained, never truth."""
import importlib.util,math,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
def module(name):
    spec=importlib.util.spec_from_file_location('_ew_target_collector_'+name,HERE/(name+'.py'));obj=importlib.util.module_from_spec(spec);sys.modules[spec.name]=obj;spec.loader.exec_module(obj);return obj
P=module('target_protocol');O=module('ordinary_collector')
def require(ok,message):
    if not ok:raise ValueError(message)
def initial_readiness(text,dimensions):
    n=dimensions['NCOMB'];groups=dimensions['NLOOPGROUPS'];orders=dimensions['NSQUAREDSO'];take,end=P.parser(text)
    take(['META','EW_TARGET_READY_V1',str(n),str(groups),str(orders)],5);state=list(map(int,take(['STATE','0','0'],6)[3:]));require(state[:2]==[0,1],'Actual ordinary-only readiness not achieved');hels=[];amps=[]
    for i in range(1,n+1):hels.append(int(take(['HEL','0','0',str(i)],5)[-1]))
    for j in range(1,groups+1):
        for i in range(1,orders+1):value=int(take(['AMP','0','0',str(i),str(j)],6)[-1]);require(value in (0,1),'Invalid initial GOODAMP');amps.append(value)
    end();return {'target':0,'phase':0,'CHECKPHASE':state[0],'HELDOUBLECHECKED':state[1],'HELOFFSET':state[2],'GOODHEL':hels,'GOODAMP':amps}
def collect(raw,targets,ordinary_reference,comparator,dimensions):
    require(raw['dimensions.dat'].split()==['1','1','1'],'Wrong target dimensions');learned=O.learning(raw['warmup.dat']);values=P.raw(raw['target-raw.dat']);ready=P.readiness(raw['target-readiness.dat'],dimensions);initial=initial_readiness(raw['ready-readiness.dat'],dimensions)
    require(initial==ready['states'][0],'Initial readiness snapshot changed after target calls');inputs=P.caller_input_check(targets,values);control=P.ordinary_control(ordinary_reference['lane']['rows'],values,comparator);require(control['passed'],'Own-arm ordinary target1 parity failed')
    learning_comparison=O.compare_rows(ordinary_reference['lane']['learning']['rows'],learned['rows'],comparator)
    statuses=[{'target':target['target'],**target['answers'][0]['public'],'comparison_eligible':all(row['comparison_eligible'] for row in target['answers'])} for target in values['targets']]
    return {'values':values,'readiness':ready,'ready_snapshot':initial,'caller_input_check':inputs,'ordinary_control':control,'learning':learned,'learning_comparison':learning_comparison,'observed_statuses':statuses,'all_declared_targets_requested':True,'target2_success_required':False,'QP_cohort_required':False,'independent_physical_truth':False,'scientific_qualified':False}
def compare(left,right,comparator):
    first=O.compare_rows(left['values']['targets'][0]['answers'],right['values']['targets'][0]['answers'],comparator)
    a=left['values']['targets'][1]['answers'];b=right['values']['targets'][1]['answers'];eligible=all(row['comparison_eligible'] for row in a+b)
    numeric=None
    if eligible:numeric={'regression':comparator(a,b,tolerance=3e-6),'ordinary_target':comparator(a,b,tolerance=1e-8)}
    return {'ordinary_control_pair':first,'target2_both_comparison_eligible':eligible,'target2_numerical_comparison':numeric,'target2_statuses':{'original':[row['status'] for row in a],'candidate':[row['status'] for row in b]},'target2_words':{'original':[row['words'] for row in a],'candidate':[row['words'] for row in b]},'observed_readiness_equal':left['readiness']==right['readiness'],'learning_history_equal':left['learning']['history']==right['learning']['history'],'target2_status_or_numerical_success_enforced':False,'independent_physical_truth':False,'scientific_qualified':False}
