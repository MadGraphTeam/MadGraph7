"""Policy-aware driver BUILD2 source audit; all native/live paths blocked."""
from pathlib import Path
import ast,difflib,hashlib,io,json,os,runpy,subprocess,sys,unittest
R=Path.cwd();S=R/'.tirust-build/ew-qp-mass-target-build-proposal-2';OLD=R/'.tirust-build/ew-qp-mass-target-build-proposal-1'
D=R/'.tirust-build/ew-qp-mass-target-build2-independent-source-review-1'
SEAL='d00a9c97b5c4a47264ac1a8e2dcc9d07984313fb618f0d7a993f75702f98a3c5'
sys.dont_write_bytecode=True
def require(ok,message):
    if not ok:raise ValueError(message)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':h(p)}
def read(p):return json.loads(Path(p).read_text())
def seal(base,wanted):
    require(h(base/'source-index.json')==wanted,'source seal');ix=read(base/'source-index.json')
    require(not any(p.is_symlink() for p in base.rglob('*')),'source alias')
    require({str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}==set(ix['files'])|{'source-index.json'},'source inventory')
    for n,w in ix['files'].items():require(ident(base/n)==w,'source payload '+n)
    return {'sha256':wanted,'files':len(ix['files']),'bytes':sum(w['bytes'] for w in ix['files'].values())}
require(R==Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust'),'cwd')
auth={'BUILD2':seal(S,SEAL),'oldBUILD1':seal(OLD,'276ac5e9539e90882cc31a31d62d23da82b67626e17bb1a5af00dfa1048548a6')};p=read(S/'input-pins.json');oldp=read(OLD/'input-pins.json')
for key in ('parent_BUILD','ordinary_source'):auth[key]=seal(Path(p[key]['directory']),p[key]['source_index_sha256'])
require(p['selected_driver_recipes']==oldp['selected_driver_recipes'] and p['selected_link_recipes']==oldp['selected_link_recipes'],'all compile/link flags byteidentical')
require(p['frozen_inputs']==oldp['frozen_inputs'] and p['actual_filter_dimensions']==oldp['actual_filter_dimensions'],'same physics/card/matrix shape')
for name in ('ordinary-learning-reference.f','qualified-helper-reference.f','toolchain-pins.json','tool_environment.py','ownership.py','process_cleanup.py'):
    require(ident(S/name)==ident(OLD/name),'unchanged helper '+name)
for n in p['frozen_inputs']:require(ident(S/'inputs'/n)==ident(OLD/'inputs'/n),'unchanged physical/numerical stream '+n)
for record in p['retained_history'].values():require(h(record['path'])==record['sha256'],'failed history pins')
changed=sorted(n for n in read(S/'source-index.json')['files'] if ident(S/n)!=ident(OLD/n))
require(changed==sorted(['README.md','controller.py','input-pins.json','protocol.json','protocol.py','target_driver.f','test_pure.py']),'bounded delta set')
attempts=[]
def block(name):
    def fail(*a,**k):attempts.append(name);raise RuntimeError('forbidden source API '+name)
    return fail
for name in ('Popen','run','call','check_call','check_output','getoutput','getstatusoutput'):setattr(subprocess,name,block('subprocess.'+name))
for name in ('system','fork','forkpty','posix_spawn','posix_spawnp','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe'):
    if hasattr(os,name):setattr(os,name,block('os.'+name))
live_prefixes=tuple(str(R/n) for n in ('HEPTools','.tirust-build/ew-qp-mass-target-build-work-1','.tirust-build/ew-qp-mass-target-build-work-2','.tirust-build/ew-qp-mass-build-work-2','.tirust-build/qp-transport-install'))
def audit(event,args):
    if event in {'ctypes.dlopen','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'}:attempts.append(event);raise RuntimeError('forbidden process/native event')
    if event=='open' and isinstance(args[0],(str,bytes)) and os.fsdecode(args[0]).startswith(live_prefixes):attempts.append('live-open:'+os.fsdecode(args[0]));raise RuntimeError('forbidden live BUILD/runtime read')
    if event=='import' and str(args[0]).split('.')[0] in {'madgraph','models','aloha'}:attempts.append('model-import');raise RuntimeError('forbidden model import')
sys.addaudithook(audit)
ns=runpy.run_path(str(S/'test_pure.py'),run_name='_independent_policy_ready_BUILD2');C=ns['C'];P=ns['P'];C.SOURCE=SEAL;pre=C.verify_source()
require(pre['native_main_calls']==pre['compiler_queries']==pre['loader_queries']==0 and not pre['live_BUILD_runtime_inputs_read'],'source preflight only')
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(ns[n]) for n in ('SourceTests','ProtocolTests'));stream=io.StringIO();outcome=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
require(outcome.wasSuccessful() and outcome.testsRun==33,'33 pure tests')
# Real preserved INIT/filter words with an explicitly synthetic policy row.
# This is a counterfactual parser fixture, never an actual policy observation.
F=R/'.tirust-build/ew-qp-mass-target-run-execution-1/original/failure-target-readiness.dat'
require(h(F)=='cec535d70936c5cb021c1a37e331e1ae50e21f4d46d8c4a03abbfbe473ad3111','retained actual failed fixture')
lines=F.read_text().splitlines();lines[0]=lines[0].replace('EW_TARGET_READY_V1','EW_TARGET_READY_V2');policy='POLICY 0 0 0 0 1 1 0 2 -1 3EB0C6F7A0B5ED8D';lines.insert(1,policy);fixture='\n'.join(lines)+'\n';state=P.readiness_initial(fixture,p['actual_filter_dimensions'])
require(state['CHECKPHASE']==1 and state['HELDOUBLECHECKED']==0 and state['stored_INIT_flags_are_learned'] is False and state['policy']['internal_local_bypass_observed'] is False,'actual stored TF accepted only under explicit source-derived policy')
rejected=0
for bad in [fixture.replace(policy,'POLICY 0 0 -1 0 1 0 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace(policy,'POLICY 0 0 0 1 1 1 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace(policy,'POLICY 0 0 0 0 0 1 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace('HEL        0       0       1       1','HEL        0       0       1       0'),fixture.replace('3EB0C6F7A0B5ED8D','3EB0C6F7A0B5ED8C')]:
    try:P.readiness_initial(bad,p['actual_filter_dimensions'])
    except ValueError:rejected+=1
    else:raise ValueError('bad source-policy counterfactual accepted')
require(rejected==5,'five independent policy rejection fixtures')
driver=(S/'target_driver.f').read_text();controller=(S/'controller.py').read_text()
require((S/'ordinary-learning-reference.f').read_text() in driver and driver.endswith((S/'qualified-helper-reference.f').read_text()),'learning and qualified helpers exact')
require(driver.count("INCLUDE 'MadLoopParams.inc'")==2,'exact common include in observation/helper only')
for forbidden in ['BYPASS_CHECK=','ALWAYS_TEST_STABILITY=','LOOPPOLEMODE=','MLSTABTHRES=','HELOFFSET=','GOODHEL=','GOODAMP=','CHECKPHASE=','HELDOUBLECHECKED=']:require(forbidden not in driver,'read-only policy/state '+forbidden)
require(C.CAP==900 and C.CLEANUP==60 and C.CPU==12 and C.LIMITS=={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0},'same cap/limits')
require('end=BOOTSTRAP_MONOTONIC+CAP' in controller and 'StageDeadline(CAP,absolute_end=end)' in controller and 'fcntl.LOCK_EX|fcntl.LOCK_NB' in controller,'deadline/mutex unchanged')
seal(S,SEAL);seal(OLD,'276ac5e9539e90882cc31a31d62d23da82b67626e17bb1a5af00dfa1048548a6');require(h(F)=='cec535d70936c5cb021c1a37e331e1ae50e21f4d46d8c4a03abbfbe473ad3111' and not attempts,'packet/history unchanged zero forbidden calls')
mode='normal' if __debug__ else 'optimized';(D/(mode+'.log')).write_text(stream.getvalue());report={'schema':'independent-policy-ready-BUILD2-source-guarded-replay-v1','status':'passed','mode':mode,'source_index_sha256':SEAL,'authenticated_source_text':auth,'changed_payload_names':changed,'pure_tests':33,'independent_counterfactual_policy_checks':6,'failed_raw_fixture_unchanged':True,'counterfactual_policy_row_is_synthetic':True,'new_runtime_policy_observation_required':True,'old_BUILD_not_reaudited':True,'compiler_or_loader_or_model_or_native_calls':0,'live_BUILD_or_runtime_read_attempts':0,'forbidden_API_attempts':attempts,'preflight':pre,'BUILD_or_RUN_admission_given':False};(D/(mode+'.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'passed','mode':mode,'tests':33,'independent_counterfactuals':6,'forbidden_attempts':len(attempts)},sort_keys=True))
