"""File/source-only diagnosis of the preserved pre-READY target failure."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys
R=Path.cwd();D=R/'.tirust-build/ew-qp-mass-target-readiness-failure-independent-diagnosis-1'
F=R/'.tirust-build/ew-qp-mass-target-run-execution-1/original'
RUN=R/'.tirust-build/ew-qp-mass-target-run-proposal-1'
BUILD=R/'.tirust-build/ew-qp-mass-target-build-proposal-1'
M=R/'.tirust-build/ew-qp-mass-build-work-2/build/original/SubProcesses/P0_epem_ttxa/loop_matrix.f'
def require(ok,message):
    if not ok:raise ValueError(message)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':h(p)}
def read(p):return json.loads(Path(p).read_text())
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def source(base,wanted):
    require(h(base/'source-index.json')==wanted,'source seal')
    ix=read(base/'source-index.json')
    for name,w in ix['files'].items():require(ident(base/name)==w,'source payload')
    return wanted
attempts=[]
def forbid(name):
    def fail(*a,**kw):attempts.append(name);raise RuntimeError('forbidden native API '+name)
    return fail
for name in ('Popen','run','call','check_call','check_output','getoutput','getstatusoutput'):setattr(subprocess,name,forbid('subprocess.'+name))
for name in ('system','fork','forkpty','posix_spawn','posix_spawnp','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe'):
    if hasattr(os,name):setattr(os,name,forbid('os.'+name))
def audit(event,args):
    if event in {'ctypes.dlopen','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'}:attempts.append(event);raise RuntimeError('forbidden native event')
sys.addaudithook(audit);sys.dont_write_bytecode=True
require(h(F/'terminal.json')=='40d966bcf175d2698a8065ea6f8175d9733c26cabf865670f3999aea69611064','closed failure terminal')
require(h(F/'console.log')=='2e132f9091f654585313a12bbf9552b8ec6d33408d0bf6c5e6ad0f5f5dc5d88c','closed failure console')
require(h(F/'failure-warmup.dat')=='f69a4ab5636ada444c152c27c8b842589d23f43203eb9494b64068a7daedaa08','retained learning')
require(h(F/'failure-target-readiness.dat')=='cec535d70936c5cb021c1a37e331e1ae50e21f4d46d8c4a03abbfbe473ad3111','retained INIT/filter raw')
require(h(M)=='87e1c28b7ffa50db9416f88a38883e43ddb289ca8336c493a46eb3b35886cb0b','actual frozen numerical source')
source(RUN,'4f5d55c4653f014f43a8456815fda2907e44a56d9bba4de39e87c2841409eb59');source(BUILD,'276ac5e9539e90882cc31a31d62d23da82b67626e17bb1a5af00dfa1048548a6')
term=read(F/'terminal.json');require(term['status']=='failed' and term['returncode']==1 and term['cleanup']['survivors']==[],'failure scope')
require(not (F/'result.json').exists() and not (F/'target-raw.dat').exists() and not (F/'failure-target-raw.dat').exists(),'no target final/raw result')
require(not (F.parent/'candidate').exists(),'candidate not run')
spec=importlib.util.spec_from_file_location('_diagnose_ordinary_collector',RUN/'ordinary_collector.py');O=importlib.util.module_from_spec(spec);spec.loader.exec_module(O)
learned=O.learning((F/'failure-warmup.dat').read_text())
require(len(learned['history'])==101 and len(learned['rows'])==200,'complete bootstrap plus100 checked learning')
require(all(row['status']==219 and row['precision']=='DP' and 0<=row['accuracy']<=1e-6 for row in learned['rows']),'full100 accepted DP219')
raw=(F/'failure-target-readiness.dat').read_text().splitlines();require(raw[0].split()==['META','EW_TARGET_READY_V1','32','200','1'],'actual common shape')
require(raw[1].split()==['STATE','0','0','1','0','10000'],'actual stored INIT/offset')
hels=[line.split() for line in raw if line.startswith('HEL')];amps=[line.split() for line in raw if line.startswith('AMP')]
require(len(hels)==32 and all(int(v[-1])==1 for v in hels),'fresh stored32 full helicities')
require(len(amps)==200 and all(int(v[-1])==1 for v in amps),'fresh stored200 full loop groups')
require(len(raw)==234,'only initial readiness snapshot; no target snapshots')
stdout=(F/'worker.log').read_text();require(re.search(r'> LoopPoleMode\s*=\s*0\b',stdout) and re.search(r'> UseLoopFilter\s*=\s*F\b',stdout),'actual runtime card observations')
text=M.read_text();driver=(BUILD/'target_driver.f').read_text()
for wanted in ['BYPASS_FILTERS=BYPASS_CHECK.OR.LOOPPOLEMODE.GE.0','IF(.NOT.BYPASS_FILTERS) THEN','OLD_CHECKPHASE = CHECKPHASE','OLD_HELDOUBLECHECKED = HELDOUBLECHECKED','CHECKPHASE = .FALSE.','HELDOUBLECHECKED = .TRUE.','CHECKPHASE = OLD_CHECKPHASE','HELDOUBLECHECKED = OLD_HELDOUBLECHECKED','GOODHEL(I)=OLD_GOODHEL(I)','GOODAMP(I,J)=OLD_GOODAMP(I,J)']:
    require(wanted in text,'exact source branch '+wanted)
require('IF(CHECKPHASE.OR..NOT.HELDOUBLECHECKED) GOTO 800' in driver,'wrong old driver predicate preserved')
require(driver.index('IF(CHECKPHASE.OR..NOT.HELDOUBLECHECKED) GOTO 800')<driver.index("'READY '")<driver.index("IF(TRIM(COMMAND).NE.'TARGETS'"),'pre-READY rejection before possible TARGETS')
# A policy contract illustration only, not a numerical call or successor code.
def abstract_ready(mode,bypass_check,always,check,hel_double,offset,all_hel1,all_amp_true):
    if not always:return False
    derived=bypass_check or mode>=0
    if derived:return not bypass_check and offset==10000 and all_hel1 and all_amp_true
    return not check and hel_double
tests=[('actual pole0 restoredT/F',abstract_ready(0,False,True,True,False,10000,True,True),True),('same T/F legacy nonbypass',abstract_ready(-1,False,True,True,False,10000,True,True),False),('legacy learnedF/T',abstract_ready(-1,False,True,False,True,10000,True,True),True),('bypasscheckunexpected',abstract_ready(0,True,True,True,False,10000,True,True),False),('stabilitynotforced',abstract_ready(0,False,False,True,False,10000,True,True),False),('wrongoffset',abstract_ready(0,False,True,True,False,0,True,True),False),('partialhel',abstract_ready(0,False,True,True,False,10000,False,True),False),('partialloop',abstract_ready(0,False,True,True,False,10000,True,False),False)]
require(all(actual==wanted for _,actual,wanted in tests),'abstract policy regression truth table')
require(not attempts,'no native API attempts')
files={str(p.relative_to(F)):ident(p) for p in sorted(F.rglob('*')) if p.is_file()}
dump(D/'failed-report-inventory.json',{'base':str(F),'files':files,'status':'preserved-failed-before-READY','native_by_audit':0})
dump(D/'diagnosis.json',{'schema':'independent-EW-preREADY-policy-diagnosis-v1','status':'source-confirmed-infrastructure-readiness-predicate-defect','terminal_sha256':h(F/'terminal.json'),'failed_console_sha256':h(F/'console.log'),'full100_learning_sha256':h(F/'failure-warmup.dat'),'initial_raw_readiness_sha256':h(F/'failure-target-readiness.dat'),'learning':{'bootstrap_records':2,'checked_point_order_rows':200,'status':'all219 DP with finitecheckedaccuracy<=1e-6','physical_truth_claim':False},'stored_state':{'CHECKPHASE':True,'HELDOUBLECHECKED':False,'HELOFFSET':10000,'GOODHEL':[1]*32,'GOODAMP':[True]*200},'actual_policy':{'worker_stdout_LoopPoleMode':0,'worker_stdout_UseLoopFilter':False,'BYPASS_CHECK':'defaultfalse from source; not runtime-observed in failed protocol','ALWAYS_TEST_STABILITY':'driver calls FORCE_STABILITY_CHECK(TRUE); not runtime-observed in failed protocol','BYPASS_FILTERS':'source-derived from actualmode0, not directly sampled inside amplitude'},'source':{'path':str(M),'sha256':h(M),'bypass_formula_line':566,'skip_NTRY_increment_line':831,'temporary_effective_INIT_filters_line':883,'restore_stored_INIT_filters_line':1786,'force_stability_only_sets_ALWAYS_line':2900},'failure':'compiled driver incorrectly required persistent learned F/T even though the frozen mode0 intentionally computes with temporary full-sum F/T then restores the stored T/F profile','readiness_source_review_gap':'Earlier synthetic source tests modeled learned F/T but omitted deliberate mode0 restored-state behavior; actual failure is retained and must become a policy-aware source regression.','targets_called':0,'candidate_called':False,'final_target_result':False,'cleanup_survivors':[],'abstract_policy_test_cases':[{'name':name,'actual':actual,'expected':wanted} for name,actual,wanted in tests],'successor_contract':{'new_driver_BUILD_and_RUN_namespaces_only':True,'record_actual_policy_each_snapshot':['LoopPoleMode','BYPASS_CHECK','ALWAYS_TEST_STABILITY'],'source_derived_effective_bypass_clearly_labeled':True,'fixed_campaign_policy':['LoopPoleMode=0','BYPASS_CHECK=false','ALWAYS_TEST_STABILITY=true','samecard97aa','sameCTModeRun-1/finite/cache0/UseQPTrue'],'fresh_bypass_profile':['retain raw stored INIT flags without claiming learned state','HELOFFSET=10000','all32GOODHEL=1','all200GOODAMP=true','consistent actualpolicy across5snapshots'],'nonbypass_legacy':'require persistent CHECKPHASEfalse/HELDOUBLECHECKEDtrue; do not waive readiness indiscriminately','unchanged':['full100 acceptedlearning/status/accuracy','ownacceptedordinarypoint1 hard3e-6/1e-8/status','both2normaltargetcalls unconditionally on refusal','all frozen cards/points/THRES/physics/numerical objects','no INIT/filter/IEEE writes or restoration'],'separate_source_BUILD_RUN_admissions':True},'native_calls_by_audit':0,'forbidden_attempts':attempts,'old_packets_untouched':True,'scientific_qualification':False})
print(json.dumps({'status':'diagnosis-confirmed','checked_learning_rows':200,'stored_state':'T/F','targets_called':0,'policy_cases':len(tests),'native_attempts':len(attempts)},sort_keys=True))
