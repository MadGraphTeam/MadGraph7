"""Independent file-only replay of CLOSED candidate target RUN2 + pair; no native APIs."""
import collections
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / '.tirust-build/ew-qp-mass-target-run-proposal-2'
REPORT = ROOT / '.tirust-build/ew-qp-mass-target-run-execution-2/candidate'
OUT = Path(__file__).resolve().parent
attempts = []

def forbidden(*a, **kw):
    attempts.append('forbidden process/native API')
    raise AssertionError('Native/process operations forbidden in file-only review')

for name in ('Popen', 'run', 'call', 'check_call', 'check_output', 'getoutput', 'getstatusoutput'):
    setattr(subprocess, name, forbidden)
os.system = forbidden
os.popen = forbidden

def require(ok, message):
    if not ok:
        raise AssertionError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def auth(path, expected):
    require(sha(path) == expected, 'Hash mismatch: ' + str(path))
    return path

def read(path):
    return json.loads(path.read_text())

def load(name):
    spec = importlib.util.spec_from_file_location('_independent_run2_' + name, SOURCE / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

source_hash = '543cf39207106d354add7972072aa0bfebf20e22882be2bd1199a733647b2009'
terminal_hash = 'f5e47c5b7e3f897815d6ff3fecd5efa10464225cddccf7f00090bcc8b45d8e84'
result_hash = '04b7df18b738899627fa8e7eadfb7d4abd9774fa205edca0ae940f01b9433a29'
source = read(auth(SOURCE / 'source-index.json', source_hash))
require(len(source['files']) == 24, 'Unexpected source payload count')
for name, identity in source['files'].items():
    path = SOURCE / name
    require(not path.is_symlink() and path.resolve().is_relative_to(SOURCE.resolve()), 'Unsafe source payload')
    auth(path, identity['sha256'])
    require(path.stat().st_size == identity['bytes'], 'Payload byte count changed')
terminal = read(auth(REPORT / 'terminal.json', terminal_hash))
result = read(auth(REPORT / 'result.json', result_hash))
require(terminal['status'] == 'passed' and terminal['returncode'] == 0 and terminal['cleanup']['survivors'] == [], 'Not a closed successful observation')
require(terminal['result_sha256'] == result_hash and terminal['source_index_sha256'] == source_hash, 'Terminal source/result mismatch')
require(result['stage'] == 'candidate' and result['source_index_sha256'] == source_hash and result['status'] == 'passed', 'Wrong role/source')
require(not result['scientific_qualified'] and not result['independent_physical_truth'] and not result['source_promoted'] and not result['performance_acceptance'], 'Scientific scope changed')

# Reuse the authenticated independently accepted ordinary result: no old raw,
# process-object, runtime, or whole scientific BUILD inventory is reread here.
gate_hash = 'c20854f8e1f447ff8c9f99052caa9fde2c27e786b257367eb7ed06f49196accf'
review_hash = 'f34cf67f3b21ecd934d67e40c14534c9d2a8a7ba8332464286a3234e6b4ce391'
gate = read(auth(SOURCE / 'ordinary-reference-gate.json', gate_hash))
ordinary_review = read(auth(SOURCE / 'ordinary-reference-review.json', review_hash))
require(gate['ordinary_pair_accepted'] and gate['independent_review_accepted'] and gate['independent_review_sha256'] == review_hash, 'Ordinary pair not independently accepted')
require(not gate['independent_physical_truth'] and not gate['QP_mass_path_qualified'], 'Ordinary reference scope changed')
arm = gate['arms']['candidate']
old_terminal = read(auth(ROOT / arm['terminal'], arm['terminal_sha256']))
old_result = read(auth(ROOT / arm['result'], arm['result_sha256']))
require(old_terminal['status'] == 'passed' and old_terminal['returncode'] == 0 and old_terminal['cleanup']['survivors'] == [] and old_terminal['result_sha256'] == arm['result_sha256'], 'Ordinary reference not closed')
require(old_result['stage'] == 'candidate' and old_result['source_index_sha256'] == gate['source_index_sha256'], 'Wrong ordinary reference role/source')
reference = {'gate_sha256': gate_hash, 'result_sha256': arm['result_sha256'], 'terminal_sha256': arm['terminal_sha256'], 'lane': old_result['lane'], 'independent_physical_truth': False, 'QP_mass_path_qualified': False}
require({k: v for k, v in reference.items() if k != 'lane'} == result['ordinary_reference'], 'Recorded ordinary reference differs')

raw_names = ('warmup.dat', 'dimensions.dat', 'target-raw.dat', 'target-readiness.dat', 'ready-readiness.dat')
used_names = raw_names + ('protocol.json', 'worker.log', 'collected.json', 'ready.json', 'comparison.json')
for name in used_names:
    auth(REPORT / name, result['raw_files'][name])
raw = {name: (REPORT / name).read_text() for name in raw_names}
dimensions = read(SOURCE / 'input-pins.json')['actual_filter_dimensions']
require(dimensions == {'NCOMB': 32, 'NLOOPGROUPS': 200, 'NSQUAREDSO': 1}, 'Wrong readiness dimensions')
collector, comparison = load('collector'), load('comparison')
lane = collector.collect(raw, (SOURCE / 'inputs/targets2.dat').read_text(), reference, comparison.compare_rows, dimensions)
require(lane == result['lane'] == read(REPORT / 'collected.json'), 'Actual collector replay differs')

learning = lane['learning']
require(len(learning['history']) == 101 and len(learning['all_raw_records']) == 202 and len(learning['rows']) == 200, 'Full initialization coverage differs')
require((learning['first_steady_call'], learning['last_steady_call']) == (1, 100), 'Wrong steady calls')
require(all(row['status'] == 219 for row in learning['rows']) and all(x['status'] == 219 for x in learning['history']), 'Unexpected actual cohort')
require(learning['rows'] == reference['lane']['learning']['rows'], 'Initialization row words/status/accuracy differ')
require(learning['history'] == reference['lane']['learning']['history'], 'Initialization history differs')
lc = lane['learning_comparison']
require(lc['passed'] and not lc['status_changes'] and not lc['word_differences'], 'Learning numerical comparison failed')
for key in ('regression', 'ordinary_target'):
    require(lc[key]['passed'] and lc[key]['maximum_relative_error'] == 0 and all(r['relative_error'] == 0 for r in lc[key]['residuals']), 'Nonzero learning residuals')

states = lane['readiness']['states']
require([(s['target'], s['phase']) for s in states] == [(0, 0), (1, 1), (1, 2), (2, 1), (2, 2)], 'Missing readiness phase')
for state in states:
    require([state[k] for k in ('CHECKPHASE', 'HELDOUBLECHECKED', 'HELOFFSET')] == [1, 0, 10000], 'Unexpected raw stored INIT state')
    require(state['GOODHEL'] == [1] * 32 and state['GOODAMP'] == [1] * 200, 'Incomplete actual filter COMMON')
    policy = state['policy']
    require([policy[k] for k in ('LoopPoleMode', 'BYPASS_CHECK', 'ALWAYS_TEST_STABILITY', 'derived_bypass_from_observed_policy_and_source', 'UseLoopFilter', 'HelicityFilterLevel', 'CTModeRun')] == [0, 0, 1, 1, 0, 2, -1], 'Wrong actual policy')
    require(policy['MLStabThres']['word'] == '3EB0C6F7A0B5ED8D' and policy['internal_local_bypass_observed'] is False and state['stored_INIT_flags_are_learned'] is False, 'False internal/learned state claim')
require(lane['ready_snapshot'] == states[0] and lane['readiness']['state_restoration_performed'] is False, 'Readiness replay/restoration mismatch')

targets = lane['values']['targets']
require([x['target'] for x in targets] == [1, 2] and lane['values']['both_targets_complete'], 'Missing actual target')
ordinary_one = [r for r in reference['lane']['rows'] if r['point'] == 1]
first = targets[0]['answers']
require([r['words'] for r in first] == [r['words'] for r in ordinary_one] and [r['status'] for r in first] == [219, 219], 'Ordinary target1 word/status mismatch')
require(lane['ordinary_control']['passed'] and not lane['ordinary_control']['word_differences'], 'Hard ordinary parity failed')
for row in first:
    require(row['comparison_eligible'] and not row['buffers_are_diagnostics_only'], 'Ordinary anchor not accepted')
for row in targets[1]['answers']:
    require(row['status'] == 420 and row['accuracy'] == 1.0 and row['finite_words'] and not row['comparison_eligible'] and row['buffers_are_diagnostics_only'] and row['public']['precision'] is None, 'Refusal scope changed')
for target in targets:
    require(target['before'] == target['after'], 'Public caller inputs changed')
    require(target['environment_before']['IEEE'] == target['environment_after']['IEEE'] == [1] + [0] * 10, 'Unexpected IEEE snapshot')
require(targets[0]['environment_before']['software'] == targets[0]['environment_after']['software'] == [0, 0], 'Target1 software latch changed')
require(targets[1]['environment_before']['software'] == [0, 0] and targets[1]['environment_after']['software'] == [0, 1], 'Target2 software latch observation changed')
require(lane['caller_input_check']['before_caller_P_matches_frozen_decimal_stream'] and lane['caller_input_check']['canonical_repaired_or_native_input_claim'] is False, 'Caller input scope changed')

protocol = read(REPORT / 'protocol.json')
require(len(protocol) == 6, 'Unexpected protocol messages')
require(protocol[0]['direction'] == 'receive' and protocol[0]['fields'][:6] == ['READY', '1', '100', '1', '1', '1'] and len(protocol[0]['fields']) == 7, 'Bad READY')
require(protocol[1:] == [
    {'direction': 'send', 'line': 'TARGETS 1 0'},
    {'direction': 'receive', 'fields': ['TARGETED', '1', '2']},
    {'direction': 'send', 'line': 'STOP 0 0'},
    {'direction': 'receive', 'fields': ['BYE']},
    {'direction': 'exit', 'returncode': 0, 'trailing_bytes': 0},
], 'Wrong target/shutdown protocol')
ready = read(REPORT / 'ready.json')
require(ready == {'cold_seconds': float(protocol[0]['fields'][6]), 'nborn': 1, 'ndim': 1, 'nso': 1, 'points': 100}, 'READY metadata differs')
stdout = (REPORT / 'worker.log').read_bytes()
require(len(stdout) == result['stdout']['bytes'] == 5267 and sha(REPORT / 'worker.log') == result['stdout']['sha256'] and result['full_stdout_retained'], 'Full stdout retention differs')
lines = stdout.decode().splitlines()
warnings = [line for line in lines if 'warning' in line.lower() or 'floating point exception' in line.lower()]
require(len(warnings) == 2 and '##W03 WARNING' in warnings[0] and 'last QP reduction' in warnings[1], 'Diagnostic warnings absent')
require(not attempts, 'Forbidden API attempted')

# Authenticate the prior original component and closed result/terminal only.
original_component_path = ROOT / '.tirust-build/ew-qp-mass-target-RUN2-original-science-protocol-review-1/receipt.json'
original_component_sha = '244f05e2ede3c139d28f18f3aaf3fb8eda0f7a4a845ff0ece995db3efba0f754'
original_component = read(auth(original_component_path, original_component_sha))
require(original_component['status'] == 'passed' and original_component['collector_lane_exact_replay'] and original_component['protocol_exit_0_zero_tail'], 'Original component not accepted')
original_report = ROOT / '.tirust-build/ew-qp-mass-target-run-execution-2/original'
original_terminal = read(auth(original_report / 'terminal.json', original_component['terminal_sha256']))
original_result = read(auth(original_report / 'result.json', original_component['result_sha256']))
require(original_terminal['status'] == 'passed' and original_terminal['returncode'] == 0 and original_terminal['cleanup']['survivors'] == [], 'Original no longer closed')
require(terminal['reviewed_original'] == result['reviewed_original'] == original_component['terminal_sha256'], 'Candidate did not bind exact reviewed original')
paired = collector.compare(original_result['lane'], lane, comparison.compare_rows)
require(paired == result['comparison'] == read(REPORT / 'comparison.json'), 'Conditional pair replay differs')
require(paired['ordinary_control_pair']['passed'] and not paired['ordinary_control_pair']['status_changes'] and not paired['ordinary_control_pair']['word_differences'], 'Ordinary target1 pair changed')
require(paired['observed_readiness_equal'] and paired['learning_history_equal'], 'Paired common/history differs')
require(paired['target2_statuses'] == {'original': [420, 420], 'candidate': [420, 420]} and paired['target2_both_comparison_eligible'] is False and paired['target2_numerical_comparison'] is None, 'Refused target2 became numerical comparison')
require(paired['target2_status_or_numerical_success_enforced'] is False and paired['scientific_qualified'] is False and paired['independent_physical_truth'] is False, 'Pair qualification scope changed')
require(original_result['lane']['learning']['rows'] == lane['learning']['rows'], 'Paired steady learning row words/status/accuracy changed')
diagnostic_word_changes = []
for left, right in zip(original_result['lane']['values']['targets'][1]['answers'], targets[1]['answers'], strict=True):
    for column, (a, b) in enumerate(zip(left['words'], right['words'], strict=True)):
        if a != b:
            diagnostic_word_changes.append({'order': left['order'], 'column': column, 'column_name': ['Born', 'finite', 'simple_pole', 'double_pole', 'accuracy'][column], 'original_word': a, 'candidate_word': b, 'diagnostic_only': True})
require([(v['order'], v['column']) for v in diagnostic_word_changes] == [(0, 1), (0, 2), (1, 1), (1, 2)], 'Unexpected refusal diagnostic word changes')

receipt = {
    'schema': 'independent-closed-EW-target-RUN2-candidate-pair-science-protocol-component-v1',
    'status': 'passed', 'component_only': True,
    'source_index_sha256': source_hash, 'source_payloads_verified': 24,
    'terminal_sha256': terminal_hash, 'result_sha256': result_hash,
    'used_raw_files_authenticated': {name: result['raw_files'][name] for name in used_names},
    'ordinary_reference_gate_sha256': gate_hash, 'ordinary_reference_review_sha256': review_hash,
    'ordinary_reference_result_sha256': arm['result_sha256'], 'ordinary_reference_terminal_sha256': arm['terminal_sha256'],
    'old_full_science_BUILD_or_raw_inventory_rehashed': False,
    'collector_lane_exact_replay': True, 'collected_json_exact_replay': True,
    'initialization': {'calls': 101, 'steady_calls': [1, 100], 'raw_order_rows': 202, 'steady_order_rows': 200, 'steady_status_counts': dict(collections.Counter(str(r['status']) for r in learning['rows'])), 'history_exact_ordinary_reference': True, 'steady_words_status_accuracy_exact_ordinary_reference': True, 'maximum_coefficient_relative_error': 0.0, 'regression_3e_6_passed': True, 'ordinary_1e_8_passed': True, 'stored_filters_learned': False, 'learning_numeric_parity_hard_gate_in_controller': False},
    'readiness': {'actual_policy': states[0]['policy'], 'snapshots': [{k: s[k] for k in ('target', 'phase', 'CHECKPHASE', 'HELDOUBLECHECKED', 'HELOFFSET', 'stored_INIT_flags_are_learned')} for s in states], 'each_GOODHEL_32_all_1': True, 'each_GOODAMP_200_all_true': True, 'raw_common_before_after': True, 'internal_local_bypass_observed': False, 'state_restoration_performed': False},
    'targets': targets,
    'target1_own_accepted_ordinary_point1_all_five_words_status_exact': True,
    'target1_hard_3e_6_and_1e_8_comparison_passed': True,
    'target2_status': 420, 'target2_accepted': False, 'target2_QP_success_inferred': False,
    'target2_buffers_diagnostic_only': True, 'all_two_targets_completed': True,
    'caller_input_scope': 'All before public caller P words match frozen f166 target stream; after P and caller MU_R are identical public-call observations. Repaired/canonical/native reduction inputs and constructors remain unobserved.',
    'protocol': protocol, 'protocol_exit_0_zero_tail': True,
    'full_stdout': {**result['stdout'], 'lines': len(lines), 'diagnostic_warning_lines': warnings, 'scope': 'Whole worker stdout retained without deletion; no phase delimiters, warning attribution to individual target/native constructor is not independently established.'},
    'native_or_process_API_attempts': len(attempts),
    'native_executed_by_review': False, 'loader_or_toolchain_queries_by_review': False,
    'scientific_qualified': False, 'independent_physical_truth': False,
    'EW_QP_mass_path_qualified': False, 'candidate_admitted_by_component': False,
    'performance_acceptance': False, 'production_promoted': False,
    'scope': 'Closed candidate observation/control, original/candidate conditional pair replay and strict protocol verified. Explicit QP mass construction did not close the EW stress refusal. Refused420 and retained warning/IEEE/software diagnostics are not physical/QP success. Parent retains responsibility for full raw inventory, process/runtime bindings, maps, CPU/deadline/cleanup, and overall candidate admission.',
}
receipt['original_component_sha256'] = original_component_sha
receipt['original_closed_result_sha256'] = original_component['result_sha256']
receipt['original_closed_terminal_sha256'] = original_component['terminal_sha256']
receipt['conditional_pair_collector_exact_replay'] = True
receipt['paired_original_candidate_learning_200_rows_exact'] = True
receipt['paired_target1_all_five_words_status_exact'] = True
receipt['target2_diagnostic_word_changes'] = diagnostic_word_changes
receipt['paired_target2_numerical_comparison'] = None
receipt['both_target2_refused420'] = True
receipt['explicit_QP_mass_fix_closed_EW_stress'] = False
receipt['actual_native_QP_mass_inputs_observed'] = False
receipt['pair_comparison'] = paired
receipt['review_script_sha256'] = sha(Path(__file__))
out = OUT / 'receipt.json'
out.write_text(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + '\n')
print(json.dumps({'status': receipt['status'], 'receipt': str(out.relative_to(ROOT)), 'sha256': sha(out), 'collector_exact_replay': True, 'learning_rows_exact': 200, 'targets': ['DP219 accepted', 'REFUSED420 diagnostic'], 'forbidden_API_attempts': len(attempts), 'scientific_qualified': False}))
