"""Narrow file-only closed ORIGINAL RUN2 protocol/binding review."""
from pathlib import Path
import hashlib,json,math,os,re,subprocess,sys
R=Path.cwd();D=R/'.tirust-build/ew-qp-mass-target-RUN2-original-independent-review-1'
F=R/'.tirust-build/ew-qp-mass-target-run-execution-2/original';S=R/'.tirust-build/ew-qp-mass-target-run-proposal-2'
TERM='3e8facada671f781aa10976958265789d192fa2deddd95a656120bb277858c15';RESULT='edb82a9f99972b3f6eaef714e2a42835a6acff499c1870cd77444a5d026c854f';SEAL='543cf39207106d354add7972072aa0bfebf20e22882be2bd1199a733647b2009';PROC='SubProcesses/P0_epem_ttxa'
def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):v.update(b)
    return v.hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':h(p)}
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
attempts=[]
def block(name):
    def fail(*a,**k):attempts.append(name);raise RuntimeError('forbidden closed review API '+name)
    return fail
for n in ('Popen','run','call','check_call','check_output','getoutput','getstatusoutput'):setattr(subprocess,n,block('subprocess.'+n))
for n in ('system','fork','forkpty','posix_spawn','posix_spawnp','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe'):
    if hasattr(os,n):setattr(os,n,block('os.'+n))
def audit(event,args):
    if event in {'ctypes.dlopen','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'}:attempts.append(event);raise RuntimeError('forbidden native event')
    if event=='open' and isinstance(args[0],(str,bytes)) and os.fsdecode(args[0]).startswith('/proc/'):attempts.append('liveproc');raise RuntimeError('liveprocess reads forbidden')
    if event=='import' and str(args[0]).split('.')[0] in {'madgraph','models','aloha'}:attempts.append('modelimport');raise RuntimeError('modelimport forbidden')
sys.addaudithook(audit);sys.dont_write_bytecode=True
require(h(F/'terminal.json')==TERM and h(F/'result.json')==RESULT,'root closed identities')
t=read(F/'terminal.json');r=read(F/'result.json');p=read(S/'input-pins.json');raw=r['raw_files'];files={str(f.relative_to(F)) for f in F.rglob('*') if f.is_file()}
require(len(raw)==16 and files==set(raw)|{'result.json','terminal.json'} and not any(f.is_symlink() for f in F.rglob('*')),'exact16raw closedreport')
for name,sha in raw.items():require(h(F/name)==sha,'closedraw '+name)
require(t['status']=='passed' and t['returncode']==0 and t['cleanup']['survivors']==[] and t['result_sha256']==RESULT,'closed original pass')
require(t['role']==r['stage']=='original' and t['source_index_sha256']==r['source_index_sha256']==SEAL and t['reviewed_original'] is None and r['reviewed_original'] is None,'actualrole source')
require(t['cap_seconds']==900 and t['cleanup_reserve_seconds']==60 and t['deadline_monotonic']==t['original_end_monotonic']==t['bootstrap_monotonic']+900,'allin deadline')
require(t['cpu']==12 and t['cpu_reservation'] is False and t['resource_limits']=={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0},'actualscope limits')
require((F/'console.log').read_bytes()==b'' and r['status']=='passed' and r['scientific_qualified'] is False and r['independent_physical_truth'] is False and r['source_promoted'] is False and r['performance_acceptance'] is False,'observation only')
require(r['full100_ordinary_initialization_sweep'] is True and r['stored_filters_learned'] is False and r['requested_targets']==2 and r['all_declared_targets_completed'] is True and r['target2_numeric_success_required'] is False and r['QP_cohort_required'] is False,'declaredobservations')
require(h(S/'source-index.json')==SEAL,'source seal');ix=read(S/'source-index.json')
for name,row in ix['files'].items():require(ident(S/name)==row,'retained RUN2source')
require(h(R/p['root_target_BUILD_gate']['path'])==p['root_target_BUILD_gate']['sha256']==t['BUILD_gate_sha256']==r['BUILD_gate_sha256'],'root BUILD2gate')
gate=read(S/'target-BUILD-gate.json');require(gate==read(R/p['root_target_BUILD_gate']['path']),'embeddedactualBUILDgate')
require(h(R/p['independent_target_BUILD_review']['path'])==p['independent_target_BUILD_review']['sha256']==r['BUILD_independent_review_sha256'],'reusedBUILDreview')
require(h(R/p['closed_target_build']['raw_inventory']['path'])==p['closed_target_build']['raw_inventory']['sha256']==r['BUILD_raw_inventory_sha256'],'reusedBUILD rawindex')
build_report=R/p['closed_target_build']['report'];require(h(build_report/'result.json')==p['closed_target_build']['result_sha256'] and h(build_report/'terminal.json')==p['closed_target_build']['terminal_sha256']==r['BUILD_terminal_sha256'],'reusedBUILDclosedidentities')
br=read(build_report/'result.json')['variants']['original'];require(br['sources'][PROC+'/target_driver.f']=={k:p['driver'][k] for k in ('bytes','sha256')},'newdriver source binding')
require(r['compiled_source_index_sha256']==p['compiled_source']['source_index_sha256']=='d00a9c97b5c4a47264ac1a8e2dcc9d07984313fb618f0d7a993f75702f98a3c5','compiled source')
case=R/'.tirust-build/ew-qp-mass-target-run-work-2/original'/PROC;output=case.parents[1]
require(output==R/'.tirust-build/ew-qp-mass-target-run-work-2/original','fresh private root')
planned={**p['data_pins']['original'],PROC+'/target-check':{'sha256':br['executable_sha256']}};require(len(planned)==17,'17runtime inputs')
for name,row in planned.items():
    f=output/name;require(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(output) and h(f)==row['sha256'],'privateinput '+name)
require(not any(f.is_symlink() for f in output.rglob('*')),'privatealiases')
require(not (case/'worker-protocol.fifo').exists(),'FIFOclosed')
params={str(f.relative_to(output)):h(f) for f in output.rglob('MadLoopParams.dat')};expected={n:p['frozen_inputs']['cache0.dat']['sha256'] for n in planned if n.endswith('MadLoopParams.dat')};require(params==expected==r['runtime_binding']['numerical_cards'],'allnumericalcardcopies')
require(r['runtime_binding']['runtime_files']==17 and r['runtime_binding']['physical_card_sha256']==h(output/'Cards/param_card.dat') and r['runtime_binding']['identifier_card_sha256']==h(output/'Cards/ident_card.dat'),'physical/ident cardbindings')
for name,row in p['frozen_inputs'].items():require(ident(S/'inputs'/name)==row,'immutablephysicsstreams')
before=read(F/'maps-before.json');after=read(F/'maps-after.json')
require(all(before[n]==after[n] for n in ('pid','parent_pid','process_group','session','start_time_ticks','affinity','files')),'sameactualworker')
require(before['pid']==before['process_group']==before['session'] and before['parent_pid']==t['pid'] and before['affinity']==[12],'workerpid/session/cpu')
observed={row['pid']:row for row in t['cleanup']['observed_owned_processes']};require(before['pid'] in observed and observed[before['pid']]['start_time_ticks']==before['start_time_ticks'],'cleanupworkeridentity')
executable=str((case/'target-check').resolve());expected_files={**p['expected_runtime']['files'],executable:br['executable_sha256']};allowed={**expected_files,**p['extra_mappings']}
for snapshot in (before,after):
    names=set()
    for line in snapshot['raw_maps'].splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'deletedmapping');names.add(str(Path(fields[-1]).resolve()))
    require(names==set(snapshot['files']) and all(snapshot['files'].get(n)==sha for n,sha in expected_files.items()),'actual15providers+ELFmap completeness')
    require(all(allowed.get(n)==sha==h(n) for n,sha in snapshot['files'].items()),'actualmapped provider bindings')
require(len(before['files'])==16,'actual16mappedfiles; nooptional locale')
require(r['worker_identity']=={'same_process_and_file_providers':True,'anonymous_VMA_changes_allowed':True},'identityreport')
tools=read(S/'toolchain-pins.json')['required_tools'];w=read(F/'worker-command.json');argv=[tools['taskset']['path'],'-c','12',str(case/'target-check'),str(S/'inputs/ordinary100.dat'),str(S/'inputs/targets2.dat')]
require(w['argv']==argv and w['cwd']==str(case) and w['executable_sha256']==h(case/'target-check')==br['executable_sha256'] and w['driver_source_sha256']==p['driver']['sha256'] and w['compiled_source_index_sha256']==p['compiled_source']['source_index_sha256'],'actualworkercommand')
ad=read(F/'admission.json');require(ad['command']==[tools['taskset']['path'],'-c','12',tools['python3']['path'],'-B',str(S/'controller.py'),'--source',SEAL,'--role','original','--build-gate',p['root_target_BUILD_gate']['path'],'--build-gate-sha',p['root_target_BUILD_gate']['sha256'],'--child'],'admissionargv')
protocol=read(F/'protocol.json');require(len(protocol)==6 and protocol[0]['direction']=='receive' and protocol[0]['fields'][:6]==['READY','1','100','1','1','1'],'actualREADY')
require(protocol[1:]==[{'direction':'send','line':'TARGETS 1 0'},{'direction':'receive','fields':['TARGETED','1','2']},{'direction':'send','line':'STOP 0 0'},{'direction':'receive','fields':['BYE']},{'direction':'exit','returncode':0,'trailing_bytes':0}],'strictactualshutdown')
ready=read(F/'ready.json');require(ready=={'points':100,'ndim':1,'nso':1,'nborn':1,'cold_seconds':float(protocol[0]['fields'][6])} and math.isfinite(ready['cold_seconds']) and ready['cold_seconds']>0,'readydimensions')
pre=read(F/'pre-shutdown-raw-identities.json');require(set(pre)=={'warmup.dat','dimensions.dat','target-raw.dat','target-readiness.dat'},'four raw files')
for name,row in pre.items():require(ident(F/name)==ident(case/name)==row,'unchangedrawafterexit '+name)
require(read(F/'collected.json')==r['lane'],'collected lanehash')
require(r['stdout']==ident(F/'worker.log') and r['full_stdout_retained'] is True and r['protocol_complete'] is True,'fullstdoutandprotocol')
stdout=(F/'worker.log').read_text();require('##W03 WARNING An unstable PS point was detected.' in stdout and 'last QP reduction was deemed unstable because a floating point exception was encountered.' in stdout,'completeunstableQPwarning')
warning=stdout[stdout.index(' ##W03 WARNING'):];(D/'target2-warning.txt').write_text(warning)
learning=r['lane']['learning_comparison'];require(learning['passed'] is True and learning['regression']['passed'] is True and learning['ordinary_target']['passed'] is True and learning['word_differences']==[] and learning['status_changes']==[] and learning['ordinary_target']['maximum_relative_error']==0.,'actuallearningdiagnosticPASS')
require(not attempts,'zeroAPIattempts')
for name,sha in raw.items():require(h(F/name)==sha,'rawunchangedafteraudit')
dump(D/'raw-inventory.json',{'schema':'independent-closed-original-EW-target-RUN2-raw-inventory-v1','base':str(F),'terminal_sha256':TERM,'result_sha256':RESULT,'files':{str(f.relative_to(F)):ident(f) for f in sorted(F.rglob('*')) if f.is_file()},'native_by_audit':0})
dump(D/'bindings-and-protocol.json',{'schema':'independent-closed-original-RUN2-bindings-protocol-v1','status':'passed','source_index_sha256':SEAL,'terminal_sha256':TERM,'result_sha256':RESULT,'closed_raw_files':16,'copied_runtime_inputs':17,'actual_mapped_files':16,'actual_runtime_providers':15,'worker_identity':{k:before[k] for k in ('pid','parent_pid','process_group','session','start_time_ticks','affinity')},'strict_protocol':protocol,'learning_comparison_passed':True,'learning_word_differences':0,'learning_status_differences':0,'warning_retained_sha256':h(D/'target2-warning.txt'),'root_cleanup_survivors':[],'forbidden_API_attempts':attempts,'whole_old_BUILD_science_reaudit':False,'liveprocess_queries':0,'native_queries':0,'candidate_admission_given':False,'scientific_qualified':False})
print(json.dumps({'status':'passed','raw':16,'runtime_inputs':17,'mapped_files':16,'learning_diagnostic_pass':True,'native_attempts':len(attempts)},sort_keys=True))
