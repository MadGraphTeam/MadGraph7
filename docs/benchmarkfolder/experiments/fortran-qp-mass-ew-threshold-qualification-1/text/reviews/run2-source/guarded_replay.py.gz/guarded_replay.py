"""Independent sealed target RUN source replay; live/native paths forbidden."""
from pathlib import Path
import ast,hashlib,io,json,os,runpy,subprocess,sys,unittest
ROOT=Path.cwd();SOURCE=ROOT/'.tirust-build/ew-qp-mass-target-run-proposal-2'
HERE=ROOT/'.tirust-build/ew-qp-mass-target-run2-independent-source-review-1'
SEAL='543cf39207106d354add7972072aa0bfebf20e22882be2bd1199a733647b2009'
sys.dont_write_bytecode=True
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def read(p):return json.loads(Path(p).read_text())
def seal(base,wanted):
    require(digest(base/'source-index.json')==wanted,'source seal')
    ix=read(base/'source-index.json');require(not any(f.is_symlink() for f in base.rglob('*')),'source alias')
    require({str(f.relative_to(base)) for f in base.rglob('*') if f.is_file()}==set(ix['files'])|{'source-index.json'},'source inventory')
    for n,w in ix['files'].items():require(ident(base/n)==w,'source payload '+n)
    return {'sha256':wanted,'files':len(ix['files']),'bytes':sum(w['bytes'] for w in ix['files'].values())}
require(ROOT==Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust'),'cwd')
authenticated={'RUN':seal(SOURCE,SEAL)};p=read(SOURCE/'input-pins.json')
for key in ('compiled_source','ordinary_source'):authenticated[key]=seal(Path(p[key]['directory']),p[key]['source_index_sha256'])
ordinary=Path(p['ordinary_source']['directory']);compiled=Path(p['compiled_source']['directory'])
copies={}
for own,original in [('process_cleanup.py','process_cleanup.py'),('ownership.py','ownership.py'),('comparison.py','comparison.py'),('ordinary_collector.py','collector.py'),('worker_base.py','worker_base.py'),('tool_environment.py','tool_environment.py')]:
    require(ident(SOURCE/own)==ident(ordinary/original),'retained qualified helper '+own);copies[own]=digest(SOURCE/own)
require(ident(SOURCE/'target_protocol.py')==ident(compiled/'protocol.py'),'retained exact target parser')
for local,key in [('ordinary-reference-gate.json','ordinary_reference_gate'),('ordinary-reference-review.json','ordinary_reference_review'),('target-BUILD-gate.json','root_target_BUILD_gate'),('target-BUILD-review.json','independent_target_BUILD_review')]:
    require(digest(SOURCE/local)==p[key]['sha256']==digest(ROOT/p[key]['path']),'exact source receipt/gate text '+local)
for name,w in p['frozen_inputs'].items():require(ident(SOURCE/'inputs'/name)==w==ident(compiled/'inputs'/name),'frozen streams/cards')
require(p['root_target_BUILD_gate']['sha256']=='712c40a4634fc62bd0648769e18bd72c0abfbfb5214f920b529c3a02977c6138','exact target root gate')
require(p['ordinary_reference_gate']['sha256']=='c20854f8e1f447ff8c9f99052caa9fde2c27e786b257367eb7ed06f49196accf','exact ordinary root gate')
attempts=[]
def forbidden(name):
    def fail(*a,**k):attempts.append(name);raise RuntimeError('forbidden source audit API '+name)
    return fail
for name in ('Popen','run','call','check_call','check_output','getoutput','getstatusoutput'):setattr(subprocess,name,forbidden('subprocess.'+name))
for name in ('system','fork','forkpty','posix_spawn','posix_spawnp','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe'):
    if hasattr(os,name):setattr(os,name,forbidden('os.'+name))
live_prefixes=tuple(str(ROOT/name) for name in ('HEPTools','.tirust-build/ew-qp-mass-target-build-work-1','.tirust-build/ew-qp-mass-build-work-2','.tirust-build/ew-qp-mass-target-run-work-1','.tirust-build/ew-qp-mass-target-run-work-2','.tirust-build/qp-transport-install'))
def audit(event,args):
    if event in {'ctypes.dlopen','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'}:attempts.append(event);raise RuntimeError('forbidden process/native event '+event)
    if event=='open' and isinstance(args[0],(str,bytes)):
        path=os.fsdecode(args[0])
        if path.startswith(live_prefixes):attempts.append('live-open:'+path);raise RuntimeError('forbidden live BUILD/runtime read '+path)
    if event=='import' and str(args[0]).split('.')[0] in {'madgraph','models','aloha'}:attempts.append('runtime-import:'+str(args[0]));raise RuntimeError('forbidden MG/model import')
sys.addaudithook(audit)
ns=runpy.run_path(str(SOURCE/'test_pure.py'),run_name='_independent_target_RUN_source_tests');C=ns['C'];C.SOURCE=SEAL
preflight=C.verify_source();require(preflight['live_BUILD_or_runtime_files_read'] is False and preflight['native_calls']==preflight['compiler_queries']==preflight['loader_queries']==preflight['MG_runtime_imports']==0,'source-only preflight')
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(ns[name]) for name in ('SourceTests','ProtocolTests','WorkerTests'))
stream=io.StringIO();outcome=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
require(outcome.wasSuccessful() and outcome.testsRun==34 and not attempts,'guarded34 tests')
text=(SOURCE/'controller.py').read_text();tree=ast.parse(text);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
require(C.CAP==900 and C.CLEANUP==60 and C.CPU==12 and C.LIMITS=={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0},'resource policy')
for required in ['end=BOOTSTRAP_MONOTONIC+CAP','StageDeadline(CAP,absolute_end=end)','timeout=180.','fcntl.LOCK_EX|fcntl.LOCK_NB','owner.raw_cleanup(process,raw,cleanup','start_new_session=True',"'scientific_qualified':False"]:require(required in text,'controller guard '+required)
run=ast.get_source_segment(text,functions['run']);require(run.count('worker.targets()')==1 and 'worker.run(' not in run and 'command(' not in run,'one target command/no compilation')
require(len(p['data_pins']['original'])==len(p['data_pins']['candidate'])==16,'16 runtime data inputs plus bound target ELF')
require(p['data_pins']['original']==p['data_pins']['candidate'],'identical physical/card resources')
require(p['actual_filter_dimensions']=={'NCOMB':32,'NLOOPGROUPS':200,'NSQUAREDSO':1},'actual common dimensions')
require(p['policy']=={'CTModeRun':-1,'LoopPoleMode':0,'MLReductionLib':'9','MLStabThres':1e-6,'TIRustComputeFinite':True,'TIRustGlobalCache':0,'UseQPIntegrandForTIRust':True},'unchanged numerical policy')
require(p['compiled_source']['source_index_sha256']!=SEAL,'new RUN versus compiled source distinct')
# Independent exact diff checks for execution mechanisms.
OLD=ROOT/'.tirust-build/ew-qp-mass-target-run-proposal-1'
require(ident(SOURCE/'worker.py')==ident(OLD/'worker.py') and ident(SOURCE/'worker_base.py')==ident(OLD/'worker_base.py'),'strict worker byteidentical')
before=(OLD/'binding.py').read_text().replace('ew-qp-mass-target-build-work-1','ew-qp-mass-target-build-work-2')
require(before==(SOURCE/'binding.py').read_text(),'binding delta only authenticated freshBUILD2root')
def function_map(txt):return {n.name:n for n in ast.parse(txt).body if isinstance(n,ast.FunctionDef)}
oldfunctions=function_map((OLD/'controller.py').read_text())
require(set(oldfunctions)==set(functions),'controller entrypoints unchanged')
for name in functions:
    if name=='run':continue
    require(ast.dump(functions[name])==ast.dump(oldfunctions[name]),'controller mechanism unchanged '+name)
def strip_result(function):
    function.body=[n for n in function.body]
    for node in ast.walk(function):
        for field in ('body','orelse','finalbody'):
            value=getattr(node,field,None)
            if isinstance(value,list):
                setattr(node,field,[n for n in value if not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dump' and any(isinstance(q,ast.Constant) and q.value=='result.json' for q in ast.walk(n.value.args[0])))])
    return ast.dump(function)
require(strip_result(functions['run'])==strip_result(oldfunctions['run']),'run computation/protocol unchanged except truthful resultlabels')
F=ROOT/'.tirust-build/ew-qp-mass-target-run-execution-1/original/failure-target-readiness.dat'
require(digest(F)=='cec535d70936c5cb021c1a37e331e1ae50e21f4d46d8c4a03abbfbe473ad3111','preservedfailedfixture')
lines=F.read_text().splitlines();lines[0]=lines[0].replace('READY_V1','READY_V2');policy='POLICY 0 0 0 0 1 1 0 2 -1 3EB0C6F7A0B5ED8D';lines.insert(1,policy);fixture='\n'.join(lines)+'\n'
state=ns['COL'].initial_readiness(fixture,p['actual_filter_dimensions'])
require(state['CHECKPHASE']==1 and state['HELDOUBLECHECKED']==0 and not state['stored_INIT_flags_are_learned'] and not state['policy']['internal_local_bypass_observed'],'counterfactualactualTF profileacceptednotlearned')
for bad in [fixture.replace(policy,'POLICY 0 0 -1 0 1 0 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace(policy,'POLICY 0 0 0 1 1 1 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace(policy,'POLICY 0 0 0 0 0 1 0 2 -1 3EB0C6F7A0B5ED8D'),fixture.replace('3EB0C6F7A0B5ED8D','3EB0C6F7A0B5ED8C')]:
    try:ns['COL'].initial_readiness(bad,p['actual_filter_dimensions'])
    except ValueError:pass
    else:raise ValueError('counterfactualwrongpolicyaccepted')
seal(SOURCE,SEAL);require(not attempts,'zero forbidden attempts')
mode='normal' if __debug__ else 'optimized';HERE.mkdir(exist_ok=True);(HERE/(mode+'.log')).write_text(stream.getvalue())
out={'schema':'independent-EW-target-RUN-source-guarded-replay-v1','status':'passed','mode':mode,'source_index_sha256':SEAL,'authenticated_source_text':authenticated,'copied_qualified_helpers_exact':copies,'ordinary_and_target_gate_text_exact':True,'frozen_physics_inputs_identical_to_compiled_family':True,'tests':34,'forbidden_API_or_live_runtime_read_attempts':attempts,'preflight':preflight,'runtime_files_per_role':17,'root_gate_target_sha256':p['root_target_BUILD_gate']['sha256'],'root_gate_ordinary_sha256':p['ordinary_reference_gate']['sha256'],'native_calls':0,'toolchain_queries':0,'live_BUILD_reads':0,'model_imports':0,'RUN_admission_given':False,'diff_execution_mechanisms_unchanged':True,'independent_counterfactual_policy_cases':5,'counterfactual_policy_is_synthetic':True}
(HERE/(mode+'.json')).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'mode':mode,'tests':34,'forbidden_attempts':len(attempts),'status':'passed'},sort_keys=True))
