"""Independent closed target BUILD replay. All tool/native APIs are blocked."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,struct,subprocess,sys
ROOT=Path.cwd();SOURCE=ROOT/'.tirust-build/ew-qp-mass-target-build-proposal-2'
OUT=ROOT/'.tirust-build/ew-qp-mass-target-build2-independent-closed-review-1'
REPORT=ROOT/'.tirust-build/ew-qp-mass-target-build-execution-2/build'
SEAL='d00a9c97b5c4a47264ac1a8e2dcc9d07984313fb618f0d7a993f75702f98a3c5'
TERM='30c92c137088fe014c1b939149def320fc2f3888bc7b830f748c7ba850231591'
RESULT='bc9fcee46366192bb6544593a0220c0055575c12ab6c9b99dadff04234d19f2c'
PROC='SubProcesses/P0_epem_ttxa';sys.dont_write_bytecode=True
def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def inventory(base):
    require(not any(f.is_symlink() for f in base.rglob('*')),'report aliases')
    return {str(f.relative_to(base)):ident(f) for f in sorted(base.rglob('*')) if f.is_file()}
def verify_source(base,wanted):
    require(digest(base/'source-index.json')==wanted,'source seal')
    index=read(base/'source-index.json')
    require(not any(f.is_symlink() for f in base.rglob('*')),'source aliases')
    require({str(f.relative_to(base)) for f in base.rglob('*') if f.is_file()}==set(index['files'])|{'source-index.json'},'source inventory')
    for name,w in index['files'].items():require(ident(base/name)==w,'source payload '+name)
    return len(index['files'])
def elf(path):
    raw=Path(path).read_bytes();require(raw[:6]==b'\x7fELF\x02\x01','ELF64LE required')
    h=struct.unpack_from('<16sHHIQQQIHHHHHH',raw,0);require(h[2]==62,'x86_64 required')
    loader=[]
    for i in range(h[10]):
        p=struct.unpack_from('<IIQQQQQQ',raw,h[5]+i*h[9])
        if p[0]==3:loader.append(raw[p[2]:p[2]+p[5]].rstrip(b'\0').decode())
    sections=[struct.unpack_from('<IIQQQQIIQQ',raw,h[6]+i*h[11]) for i in range(h[12])]
    names=[]
    for sec in sections:
        if sec[1]!=2:continue
        strings=sections[sec[6]];st=raw[strings[4]:strings[4]+strings[5]]
        require(sec[9]==24,'ELF symbol stride')
        for off in range(sec[4],sec[4]+sec[5],sec[9]):
            n,info,other,shndx,value,size=struct.unpack_from('<IBBHQQ',raw,off)
            if n and shndx:
                names.append(st[n:st.index(b'\0',n)].decode())
    require(len(loader)==1 and names,'ELF interpreter/symtab')
    return str(Path(loader[0]).resolve()),names

# No Popen, system, fork, exec or dlopen may be reached by this file-only audit.
attempts=[]
def block(name):
    def fail(*a,**k):attempts.append(name);raise RuntimeError('forbidden audit API '+name)
    return fail
for n in ('Popen','run','call','check_call','check_output','getoutput','getstatusoutput'):setattr(subprocess,n,block('subprocess.'+n))
for n in ('system','fork','forkpty','posix_spawn','posix_spawnp','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe'):
    if hasattr(os,n):setattr(os,n,block('os.'+n))
def audit(event,args):
    if event in {'ctypes.dlopen','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'}:attempts.append(event);raise RuntimeError('forbidden audit event '+event)
sys.addaudithook(audit)
require(ROOT==Path('/shared/external/madloop_tirust/madgraph7_madloop_tirust'),'cwd')
require(digest(REPORT/'terminal.json')==TERM and digest(REPORT/'result.json')==RESULT,'root-forwarded closed identities')
raw=inventory(REPORT);require(len(raw)==341,'closed target raw count')
term=read(REPORT/'terminal.json');result=read(REPORT/'result.json');admission=read(REPORT/'admission.json');started=read(REPORT/'started.json')
require(term['status']=='passed' and term['returncode']==0 and term['result_sha256']==RESULT and not term['cleanup']['survivors'],'closed target success/cleanup')
require(term['source_index_sha256']==SEAL and result['source_index_sha256']==SEAL,'closed target source')
require(term['cap_seconds']==900 and term['cleanup_reserve_seconds']==60 and term['cpu']==12 and term['cpu_reservation'] is False,'caps/CPU')
require(term['deadline_monotonic']==term['original_end_monotonic']==term['bootstrap_monotonic']+900,'absolute bootstrap cap')
require(term['resource_limits']=={'address_space_bytes':16*1024**3,'core_bytes':0,'file_bytes':512*1024**2},'resource limits')
require(term['pid']==started['pid'] and admission['parent_pid']!=term['pid'] and term['pid'] in {x['pid'] for x in term['cleanup']['observed_owned_processes']},'owned child identity')
require(all(x['session']==term['pid'] and x['process_group']==term['pid'] for x in term['cleanup']['observed_owned_processes']),'owned child sessions')
require((REPORT/'console.log').read_bytes()==b'','empty child console')
require(result['new_driver_compiles']==result['new_links']==2 and result['native_main_calls']==result['model_probes']==result['reducer_calls']==0,'exact compile/link scope')
require(result['target_RUN_admitted'] is False and result['scientific_qualified'] is False and result['candidate_promoted'] is False and result['performance_acceptance'] is False,'truthful BUILD scope')
verify_source(SOURCE,SEAL);pins=read(SOURCE/'input-pins.json')
for name in ('parent_BUILD','ordinary_source'):verify_source(Path(pins[name]['directory']),pins[name]['source_index_sha256'])
gatepath=ROOT/pins['root_BUILD_gate']['path'];require(digest(gatepath)==pins['root_BUILD_gate']['sha256']==term['BUILD_gate_sha256'],'parent gate')
gate=read(gatepath);ip=ROOT/gate['build_raw_inventory']['path'];require(digest(ip)==gate['build_raw_inventory']['sha256'],'parent raw inventory seal')
parentraw=read(ip);parentreport=Path(parentraw['base'])
require(len(parentraw['files'])==571,'reused parent raw count')
# Reuse the already independent closed parent proof, not a whole old-science audit.
require(digest(parentreport/'result.json')==gate['build_result_sha256'] and digest(parentreport/'terminal.json')==gate['build_terminal_sha256'],'reused closed parent identities')
require(digest(ROOT/gate['independent_review']['path'])==gate['independent_review']['sha256'],'reused parent independent proof')
parent_result=read(parentreport/'result.json');pp=read(Path(pins['parent_BUILD']['directory'])/'input-pins.json')
for n,w in pp['support_files'].items():require(ident(ROOT/n)=={k:w[k] for k in ('bytes','sha256')},'pinned support source '+n)
expected_runtime=pp['expected_runtime']['files'];require(len(expected_runtime)==15,'expected15 providers')
toolpins=read(SOURCE/'toolchain-pins.json');tools=toolpins['required_tools']
expected_child=[tools['taskset']['path'],'-c','12',tools['python3']['path'],'-B',str(SOURCE/'controller.py'),'--source',SEAL,'--build-gate',pins['root_BUILD_gate']['path'],'--build-gate-sha',pins['root_BUILD_gate']['sha256'],'--child']
require(admission['command']==expected_child,'actual child argv')
runtime_path=ROOT/pp['support_paths']['runtime'];spec=importlib.util.spec_from_file_location('_independent_target_runtime',runtime_path);rt=importlib.util.module_from_spec(spec);spec.loader.exec_module(rt)
roles={};command_total=0
for role,row in result['variants'].items():
    base=REPORT/role;cmd=base/'commands';output=Path(row['output']);case=output/PROC;old=parent_result['variants'][role]
    require(output==ROOT/'.tirust-build/ew-qp-mass-target-build-work-2/build'/role,'target private output')
    require(digest(case/'target-check')==row['executable_sha256'] and digest(case/'target-link.map')==row['link_map_sha256'],'closed ELF/map')
    pre=read(base/'target-prelink.json');static=read(base/'target-static-runtime.json')
    require(digest(base/'target-prelink.json')==row['prelink_sha256'] and digest(base/'target-static-runtime.json')==row['static_runtime_sha256'],'prelink/static receipts')
    command_files=list(cmd.glob('*.command.json'));require(len(command_files)==55,'55 closed commands each')
    expected_labels={q['label'] for q in pre['queries']}|{'compile-target-driver','link-target-driver','actual-pt-interp-runtime','target-symbols'}
    require({p.name.removesuffix('.command.json') for p in command_files}==expected_labels and len(pre['queries'])==51,'exact command inventory')
    for f in command_files:
        label=f.name.removesuffix('.command.json');c=read(f);t=read(cmd/(label+'.terminal.json'));stdout=cmd/(label+'.stdout.txt')
        require(c['cwd']==str(case) and t['returncode']==0 and digest(stdout)==t['stdout_sha256'],'actual command closure '+label)
    for query in pre['queries']:require(read(cmd/(query['label']+'.command.json'))['argv']==query['argv'],'actual prelink query argv')
    require(read(cmd/'compile-target-driver.command.json')['argv']==row['compile_recipe'],'actual compile argv')
    require(read(cmd/'link-target-driver.command.json')['argv']==row['link_recipe']==pre['command'] and pre['cwd']==str(case) and pre['completed_before_link'] is True,'actual link/prebind argv')
    require(read(cmd/'target-symbols.command.json')['argv']==[tools['nm']['path'],'--defined-only','target-check'],'actual nm argv')
    for name,sha in pre['bound'].items():require(digest(name)==sha,'prebound file changed '+name)
    require(len(pre['bound'])==87,'prebound87 files')
    for name,sha in expected_runtime.items():require(pre['bound'].get(name)==sha,'expected provider prebound')
    maploads={}
    for name in re.findall(r'^LOAD\s+(.+)$',(case/'target-link.map').read_text(),re.M):
        f=(case/name).resolve();maploads[str(f)]=digest(f)
    require(maploads==row['actual_link_loads'] and len(maploads)==54,'actual54 LOAD records')
    require(all(pre['bound'].get(n)==sha for n,sha in maploads.items()),'all actual LOADs prebound')
    require(str((case/'check_sa.o').resolve()) not in maploads and str((case/'target_driver.o').resolve()) in maploads,'actual oldmain excluded/newmain linked')
    interpreter,names=elf(case/'target-check')
    require(read(cmd/'actual-pt-interp-runtime.command.json')['argv']==[interpreter,'--list',str(case/'target-check')],'actual PT_INTERP query argv')
    listed=(cmd/'actual-pt-interp-runtime.stdout.txt').read_text();providers=set()
    for line in listed.splitlines():
        line=line.strip()
        if not line or re.fullmatch(r'linux-vdso\.so\.1\s+\(0x[0-9a-fA-F]+\)',line):continue
        m=re.fullmatch(r'(?:\S+\s+=>\s+)?(/[^\s()]+)\s+\(0x[0-9a-fA-F]+\)',line);require(m is not None,'actual runtime line');providers.add(str(Path(m.group(1)).resolve()))
    providers.add(interpreter)
    require({n:digest(n) for n in sorted(providers)}==row['runtime']['files']==expected_runtime,'actual15 runtime providers')
    require(row['runtime']['listing']==listed and row['runtime']['loader']==interpreter and row['runtime']['loader_sha256']==expected_runtime[interpreter],'actual listing/interpreter provenance')
    require(rt.derive(case/'target-check',pre,expected_runtime,':'.join(static['controlled_LD_LIBRARY_PATH']))==static,'pure exact static ELF closure replay')
    nmnames=[line.split()[-1] for line in (cmd/'target-symbols.stdout.txt').read_text().splitlines() if len(line.split())>=3]
    expected_mt=pp['expected_mtirust_symbols'];expected_private=pp['roles'][role]['expected_private_symbols']
    for group,wanted in (('__mtirust_MOD_',expected_mt),('_qpmass_',expected_private)):
        require({n:names.count(n) for n in names if group in n}=={n:1 for n in wanted},'ELF symbol ownership '+group)
        require({n:nmnames.count(n) for n in nmnames if group in n}=={n:1 for n in wanted},'logged nm symbol ownership '+group)
    for n in ('main','ew_target_input_record_','ew_target_env_record_','ew_target_ready_record_','ew_target_io_check_','ew_target_policy_ready_','o3_capture_fp_'):require(names.count(n)==nmnames.count(n)==1,'ELF/log main/helper '+n)
    roles[role]={'closed_commands':55,'prelink_queries':51,'all_exit_zero':True,'prebound_files':87,'actual_link_LOADs':54,'runtime_providers':15,'pure_static_ELF_replay_exact':True,'ELF_symtab_and_logged_nm_ownership_exact':True,'MTIRUST_symbols':len(expected_mt),'private_mass_symbols':len(expected_private),'old_main_not_linked':True,'executable_sha256':row['executable_sha256']}
    command_total+=55
require(not attempts,'zero forbidden calls')
require(inventory(REPORT)==raw,'closed target raw files unchanged during review')
verify_source(SOURCE,SEAL)
dump(OUT/'raw-inventory.json',{'schema':'independently-verified-closed-EW-target-build-raw-inventory-v1','base':str(REPORT),'build_terminal_sha256':TERM,'build_result_sha256':RESULT,'files':raw,'compiler_or_loader_queries_by_audit':0,'native_executions_by_audit':0})
dump(OUT/'runtime-and-supervision.json',{'schema':'independent-closed-EW-target-build-runtime-review-v1','status':'passed','source_index_sha256':SEAL,'terminal_sha256':TERM,'result_sha256':RESULT,'raw_files':len(raw),'all_closed_commands':command_total,'roles':roles,'absolute_bootstrap_deadline_verified':True,'cleanup_survivors':[],'forbidden_API_attempts':attempts,'native_calls_by_audit':0,'BUILD_only':True,'RUN_admission_given':False,'whole_old_science_reaudit':False,'reused_parent_result_sha256':gate['build_result_sha256'],'reused_parent_review_sha256':gate['independent_review']['sha256']})
print(json.dumps({'status':'passed','raw_files':len(raw),'commands':command_total,'forbidden_attempts':len(attempts)},sort_keys=True))
