"""Pure target-producer grammar. Refusal buffers never become references."""
import math,re,struct

def require(ok,message):
    if not ok:raise ValueError(message)
def rows(text):return [line.split() for line in text.splitlines() if line.strip()]
def number(word):
    require(bool(re.fullmatch('[0-9A-Fa-f]{16}',word)),'Malformed binary64 word');word=word.upper();x=struct.unpack('>d',bytes.fromhex(word))[0]
    return {'word':word,'finite':math.isfinite(x),'value':x if math.isfinite(x) else None,'nonfinite':None if math.isfinite(x) else 'nan' if math.isnan(x) else '+inf' if x>0 else '-inf'}
def public_status(code):
    h,t,u=code//100,(code//10)%10,code%10;precision={(2,9):'DP',(3,3):'QP'}.get((h,u));accepted=code>=0 and precision is not None and t in (1,2)
    return {'code':code,'precision':precision,'accepted_public_status':accepted,'reason':None if accepted else 'Unaccepted/unknown status; returned buffers are diagnostics only'}
def parser(text):
    data=rows(text);position=0
    def take(prefix,count=None):
        nonlocal position
        require(position<len(data),'Truncated target record');row=data[position];position+=1;require(row[:len(prefix)]==prefix and (count is None or len(row)==count),'Unexpected target schema record: '+str(row));return row
    def end():require(position==len(data),'Trailing target records')
    return take,end

def raw(text):
    take,end=parser(text);take(['META','EW_TARGET_RAW_V1','2','1','1','1'],6);targets=[]
    def inputs(k,phase):
        vectors=[]
        for i in range(1,6):
            vector=[]
            for j in range(4):vector.append(number(take(['P',str(k),str(phase),str(i),str(j)],6)[-1]))
            vectors.append(vector)
        mur=number(take(['MUR',str(k),str(phase)],4)[-1]);return {'caller_P':vectors,'caller_MU_R':mur,'canonical_repaired_or_native_input_claim':False}
    def environment(k,phase):
        fp=list(map(int,take(['FP',str(k),str(phase)],14)[3:]));soft=list(map(int,take(['SOFT',str(k),str(phase)],5)[3:]))
        require(fp[0] in range(-1,5) and all(v in (-1,0,1) for v in fp[1:]) and all(v in (0,1) for v in soft),'Malformed raw IEEE/software observation');return {'IEEE':fp,'software':soft}
    for k in (1,2):
        take(['BEGIN',str(k)],2);before=inputs(k,1);env_before=environment(k,1);env_after=environment(k,2);after=inputs(k,2);answers=[]
        for order in (0,1):
            row=take(['ANS',str(k),str(order)],9);code=int(row[3]);values=[number(word) for word in row[4:]];status=public_status(code);eligible=status['accepted_public_status'] and all(v['finite'] for v in values) and 0<=values[-1]['value']<=1e-6
            answers.append({'point':k,'order':order,'status':code,'public':status,'words':[v['word'] for v in values],'coefficients':[v['value'] for v in values[:4]],'accuracy':values[-1]['value'],'finite_words':all(v['finite'] for v in values),'comparison_eligible':eligible,'buffers_are_diagnostics_only':not eligible})
        require(answers[0]['status']==answers[1]['status'],'Split-order status differs');take(['ENDTARGET',str(k)],2);targets.append({'target':k,'before':before,'after':after,'environment_before':env_before,'environment_after':env_after,'answers':answers})
    take(['END','1','2'],3);end();return {'targets':targets,'both_targets_complete':True,'scientific_qualified':False,'independent_truth_required':True}

def readiness_state(take,dimensions,k,phase,expected_mode=0):
    n=dimensions['NCOMB'];groups=dimensions['NLOOPGROUPS'];orders=dimensions['NSQUAREDSO']
    row=take(['POLICY',str(k),str(phase)],11);v=list(map(int,row[3:10]));threshold=number(row[10]);require(all(x in (0,1) for x in v[1:5]),'Invalid observed policy logicals')
    policy={'LoopPoleMode':v[0],'BYPASS_CHECK':v[1],'ALWAYS_TEST_STABILITY':v[2],'derived_bypass_from_observed_policy_and_source':v[3],'UseLoopFilter':v[4],'HelicityFilterLevel':v[5],'CTModeRun':v[6],'MLStabThres':threshold,'internal_local_bypass_observed':False}
    require(v[0]==expected_mode and v[1]==0 and v[2]==1 and v[3]==int(bool(v[1] or v[0]>=0)),'Unexpected pole/stability/bypass policy')
    require(v[4:]==[0,2,-1] and threshold['word']=='3EB0C6F7A0B5ED8D','Frozen full-amplitude policy/threshold differs')
    state=list(map(int,take(['STATE',str(k),str(phase)],6)[3:]));require(state[0] in (0,1) and state[1] in (0,1),'Invalid stored INIT flags');hels=[];amps=[]
    for i in range(1,n+1):hels.append(int(take(['HEL',str(k),str(phase),str(i)],5)[-1]))
    for j in range(1,groups+1):
        for i in range(1,orders+1):value=int(take(['AMP',str(k),str(phase),str(i),str(j)],6)[-1]);require(value in (0,1),'Invalid GOODAMP state');amps.append(value)
    if v[3]:require(state[2]==10000 and all(x==1 for x in hels) and all(x==1 for x in amps),'Unexpected fresh full-sum stored filter profile')
    else:require(state[:2]==[0,1],'Nonbypass path has not actually finished legacy learning')
    return {'target':k,'phase':phase,'CHECKPHASE':state[0],'HELDOUBLECHECKED':state[1],'HELOFFSET':state[2],'GOODHEL':hels,'GOODAMP':amps,'policy':policy,'stored_INIT_flags_are_learned':not bool(v[3])}

def readiness(text,dimensions,expected_mode=0):
    take,end=parser(text);take(['META','EW_TARGET_READY_V2',str(dimensions['NCOMB']),str(dimensions['NLOOPGROUPS']),str(dimensions['NSQUAREDSO'])],5)
    states=[readiness_state(take,dimensions,k,phase,expected_mode) for k,phase in ((0,0),(1,1),(1,2),(2,1),(2,2))];end();require(all(s['policy']==states[0]['policy'] for s in states),'Observed policy changed across target snapshots')
    return {'states':states,'initial_actual_policy_consistent':True,'state_restoration_performed':False,'internal_local_bypass_observed':False}

def readiness_initial(text,dimensions,expected_mode=0):
    take,end=parser(text);take(['META','EW_TARGET_READY_V2',str(dimensions['NCOMB']),str(dimensions['NLOOPGROUPS']),str(dimensions['NSQUAREDSO'])],5);state=readiness_state(take,dimensions,0,0,expected_mode);end();return state

def ordinary_control(ordinary_rows,target_report,comparator):
    target=target_report['targets'][0]['answers'];require(all(r['comparison_eligible'] for r in target),'Target1 ordinary control must be accepted; refusal buffers cannot be compared')
    old=[r for r in ordinary_rows if r['point']==1];require([r['order'] for r in old]==[0,1],'Closed ordinary point1 reference missing/ambiguous');require(all(public_status(r['status'])['accepted_public_status'] and all(math.isfinite(v) for v in r['coefficients']) and math.isfinite(r['accuracy']) and 0<=r['accuracy']<=1e-6 for r in old),'Closed ordinary refusal/nonfinite buffers cannot be references');reg=comparator(old,target,tolerance=3e-6);tight=comparator(old,target,tolerance=1e-8)
    return {'passed':reg['passed'] and tight['passed'] and all(a['status']==b['status'] for a,b in zip(old,target,strict=True)),'regression':reg,'ordinary_target':tight,'word_differences':[{'order':a['order'],'ordinary':a['words'],'target':b['words']} for a,b in zip(old,target,strict=True) if a['words']!=b['words']],'scientific_qualified':False}


def caller_input_check(target_text,target_report):
    """Check public caller words against the frozen decimal target stream only."""
    tokens=target_text.split();require(tokens and tokens[0]=='2' and len(tokens)==41,'Exact two-target five-leg stream required');values=[float(x.replace('D','E').replace('d','e')) for x in tokens[1:]];require(all(math.isfinite(v) for v in values),'Nonfinite frozen caller input')
    expected=[[[struct.pack('>d',values[k*20+i*4+j]).hex().upper() for j in range(4)] for i in range(5)] for k in range(2)]
    actual=[[[v['word'] for v in leg] for leg in target['before']['caller_P']] for target in target_report['targets']]
    require(actual==expected,'Observed public caller words differ from frozen target stream')
    return {'before_caller_P_matches_frozen_decimal_stream':True,'scope':'Public caller P only; after-call P and caller MU_R remain observations','canonical_repaired_or_native_input_claim':False}
