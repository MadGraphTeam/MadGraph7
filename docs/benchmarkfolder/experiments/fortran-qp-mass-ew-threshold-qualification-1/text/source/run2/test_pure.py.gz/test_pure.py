"""Synthetic source/protocol controls only; no actual target output exists here."""
import ast,copy,importlib.util,json,struct,sys,unittest
from pathlib import Path
from unittest.mock import Mock,patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def module(name):
    spec=importlib.util.spec_from_file_location('_target_run_pure_'+name,HERE/(name+'.py'));obj=importlib.util.module_from_spec(spec);sys.modules[spec.name]=obj;spec.loader.exec_module(obj);return obj
C=module('controller');B=module('binding');P=module('target_protocol');COL=module('collector');O=module('ordinary_collector');W=module('worker');COMPARE=module('comparison').compare_rows
def word(v):return struct.pack('>d',v).hex().upper()
def raw(status2=420,nan=False):
    values=list(map(float,(HERE/'inputs/targets2.dat').read_text().split()[1:]));out=['META EW_TARGET_RAW_V1 2 1 1 1']
    for k in (1,2):
        out.append(f'BEGIN {k}')
        def inputs(phase):
            out.extend(f'P {k} {phase} {i} {j} {word(values[(k-1)*20+(i-1)*4+j])}' for i in range(1,6) for j in range(4));out.append(f'MUR {k} {phase} {word(1000.)}')
        def env(phase):out.extend([f'FP {k} {phase} '+' '.join(map(str,[1]+[0]*10)),f'SOFT {k} {phase} 0 0'])
        inputs(1);env(1);env(2);inputs(2)
        for order in (0,1):out.append(f'ANS {k} {order} {219 if k==1 else status2} '+' '.join(map(word,[1.,float('nan') if k==2 and nan else 2.,3.,4.,1e-8])))
        out.append(f'ENDTARGET {k}')
    return '\n'.join(out+['END 1 2'])+'\n'
def readiness(initial_only=False):
    out=['META EW_TARGET_READY_V2 32 200 1']
    for k,phase in ([(0,0)] if initial_only else [(0,0),(1,1),(1,2),(2,1),(2,2)]):
        out.append(f'POLICY {k} {phase} 0 0 1 1 0 2 -1 3EB0C6F7A0B5ED8D');out.append(f'STATE {k} {phase} 1 0 10000');out.extend(f'HEL {k} {phase} {i} 1' for i in range(1,33));out.extend(f'AMP {k} {phase} 1 {i} 1' for i in range(1,201))
    return '\n'.join(out)+'\n'
def warmup():
    return '\n'.join(f'{call} {1 if call==0 else 1+(call-1)%100} {order} {0 if call==0 else 219} 1 2 3 4 1e-8' for call in range(101) for order in (0,1))+'\n'
def raw_set(**kwargs):return {'dimensions.dat':'1 1 1\n','warmup.dat':warmup(),'target-raw.dat':raw(**kwargs),'target-readiness.dat':readiness(),'ready-readiness.dat':readiness(True)}
def reference():
    learned=O.learning(warmup());return {'lane':{'rows':learned['rows'],'learning':learned}}
def collect(**kwargs):return COL.collect(raw_set(**kwargs),(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
class SourceTests(unittest.TestCase):
    def test_source_seal_preflight_without_live_binding(self):
        C.SOURCE=C.digest(HERE/'source-index.json')
        with patch.object(C,'reviewed_build',side_effect=AssertionError('live BUILD read')),patch.object(C.subprocess,'Popen',side_effect=AssertionError('native execution')),patch.object(C.subprocess,'run',side_effect=AssertionError('tool execution')):
            result=C.verify_source()
        self.assertFalse(result['live_BUILD_or_runtime_files_read']);self.assertEqual(result['native_calls'],0)
    def test_actual_closed_build_gate_pins(self):
        p=C.pins();self.assertEqual(C.digest(HERE/'target-BUILD-gate.json'),p['root_target_BUILD_gate']['sha256']);self.assertEqual(C.digest(HERE/'target-BUILD-review.json'),p['independent_target_BUILD_review']['sha256']);B.accept_gate(C.read(HERE/'target-BUILD-gate.json'),p)
    def test_python_syntax_without_importing_runtime(self):
        for path in HERE.glob('*.py'):ast.parse(path.read_text())
    def test_compiled_and_run_source_are_distinct(self):
        p=C.pins();self.assertEqual(p['compiled_source']['source_index_sha256'],'d00a9c97b5c4a47264ac1a8e2dcc9d07984313fb618f0d7a993f75702f98a3c5');self.assertNotIn('source_index_sha256',p)
    def test_target_build_is_unbound_in_mutable_draft(self):
        p=copy.deepcopy(C.pins());p.update(root_target_BUILD_gate=None,closed_target_build=None,independent_target_BUILD_review=None)
        with patch.object(B,'pins',return_value=p),patch.object(B,'read',side_effect=AssertionError('future BUILD read')),self.assertRaises(ValueError):B.closed('future','0'*64)
    def test_candidate_requires_separately_reviewed_original(self):
        argv=['controller.py','--source','synthetic-source','--role','candidate','--build-gate','synthetic-gate','--build-gate-sha','synthetic-hash','--execute']
        with patch.object(sys,'argv',argv),patch.object(C,'supervise',side_effect=AssertionError('native stage')),self.assertRaises(ValueError):C.main()
    def test_original_rejects_candidate_review_argument(self):
        argv=['controller.py','--source','synthetic-source','--role','original','--build-gate','synthetic-gate','--build-gate-sha','synthetic-hash','--reviewed-original','synthetic-original','--execute']
        with patch.object(sys,'argv',argv),patch.object(C,'supervise',side_effect=AssertionError('native stage')),self.assertRaises(ValueError):C.main()
    def test_default_rejects_execution_gate(self):
        with patch.object(sys,'argv',['controller.py','--source','synthetic','--build-gate','synthetic']),patch.object(C,'verify_source',side_effect=AssertionError('unexpected preflight')),self.assertRaises(ValueError):C.main()
    def test_build_gate_cannot_qualify_science_or_change_compiled_source(self):
        p=copy.deepcopy(C.pins());p.update(root_target_BUILD_gate={'path':'synthetic','sha256':'a'*64},closed_target_build={'terminal_sha256':'b'*64,'result_sha256':'c'*64,'raw_inventory':{'path':'synthetic','sha256':'d'*64}},independent_target_BUILD_review={'path':'synthetic','sha256':'e'*64})
        gate={'schema':'ew-qp-mass-target-build-run-gate-v1','build_accepted':True,'independent_review_accepted':True,'qualification_scope':'closed-target-build-compiler-ABI-runtime-only','scientific_qualified':False,'target_RUN_admitted':False,'compiled_source_index':{'path':str(Path(p['compiled_source']['directory']).relative_to(C.ROOT)/'source-index.json'),'sha256':p['compiled_source']['source_index_sha256']},'build_terminal_sha256':'b'*64,'build_result_sha256':'c'*64,'build_raw_inventory':p['closed_target_build']['raw_inventory'],'independent_review':p['independent_target_BUILD_review'],'reviewed_parent_BUILD_gate':p['root_parent_BUILD_gate']}
        self.assertEqual(B.accept_gate(gate,p),gate)
        for key,value in [('scientific_qualified',True),('target_RUN_admitted',True),('compiled_source_index',{'path':'wrong-run-source','sha256':'f'*64}),('independent_review',{'path':'different','sha256':'e'*64})]:
            bad=copy.deepcopy(gate);bad[key]=value
            with self.assertRaises(ValueError):B.accept_gate(bad,p)
    def test_frozen_streams_cards_and_ident(self):
        p=C.pins()
        for name,row in p['frozen_inputs'].items():self.assertEqual(C.ident(HERE/'inputs'/name),row)
        for role in C.ROLES:self.assertEqual(set(p['data_pins'][role]),set(p['required_runtime_data_files']));self.assertIn('Cards/ident_card.dat',p['data_pins'][role])
        self.assertEqual(p['frozen_inputs']['targets2.dat']['sha256'],'f1663e764a65d5b9ca89691177f3607ba85f3daff8b52af9360b1a4f09e26de3')
    def test_ordinary_reference_gate_exact_source_bytes(self):
        p=C.pins();self.assertEqual(C.digest(HERE/'ordinary-reference-gate.json'),p['ordinary_reference_gate']['sha256']);gate=C.read(HERE/'ordinary-reference-gate.json');self.assertFalse(gate['QP_mass_path_qualified']);self.assertFalse(gate['independent_physical_truth'])
    def test_only_target_command_and_two_input_argv(self):
        text=(HERE/'controller.py').read_text();self.assertIn("str(HERE/'inputs/ordinary100.dat'),str(HERE/'inputs/targets2.dat')",text);self.assertIn('worker.targets()',text);self.assertNotIn("_send('EXACT",text);self.assertNotIn('worker.run(',text)
    def test_deadline_resources_and_reply_caps(self):
        text=(HERE/'controller.py').read_text();self.assertIn('end=BOOTSTRAP_MONOTONIC+CAP',text);self.assertIn('StageDeadline(CAP,absolute_end=end)',text);self.assertIn('timeout=180.',text);self.assertEqual((C.CAP,C.CLEANUP,C.CPU),(900.,60.,12));self.assertEqual(C.LIMITS,{'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0})
    def test_strict_post_shutdown_raw_and_stdout_binding(self):
        text=(HERE/'controller.py').read_text()
        for value in ["ident(case/name)==record","ident(report/name)==ident(case/name)",'not worker.thread.is_alive()',"'full_stdout_retained':True",'binding.verify_live(manifest)==before','owner.raw_cleanup(process,raw,cleanup']:self.assertIn(value,text)
        self.assertNotIn('/dev/null',text)
    def test_same_actual_worker_identity(self):
        before={'pid':10,'parent_pid':9,'process_group':10,'session':10,'start_time_ticks':123,'affinity':[12],'files':{'provider':'hash'},'raw_maps':'different anonymous text'};after=copy.deepcopy(before);after['raw_maps']='permitted anonymous changes';self.assertTrue(C.same_worker(before,after)['same_process_and_file_providers'])
        after['start_time_ticks']=124
        with self.assertRaises(ValueError):C.same_worker(before,after)
    def test_namespaces_are_fresh_and_regular_runtime_copies(self):
        text=(HERE/'controller.py').read_text();self.assertEqual(C.WORK,C.ROOT/'.tirust-build/ew-qp-mass-target-run-work-2');self.assertEqual(C.REPORT,C.ROOT/'.tirust-build/ew-qp-mass-target-run-execution-2');self.assertIn('not source.is_symlink()',text);self.assertIn('not output.exists()',text);self.assertNotIn('compile-target-driver',text)
class ProtocolTests(unittest.TestCase):
    def test_numeric_refusal_completes_observation(self):
        lane=collect();self.assertEqual([x['code'] for x in lane['observed_statuses']],[219,420]);self.assertTrue(lane['ordinary_control']['passed']);self.assertTrue(lane['all_declared_targets_requested']);self.assertFalse(lane['scientific_qualified']);self.assertFalse(lane['QP_cohort_required'])
    def test_nonfinite_refusal_remains_json_safe(self):
        lane=collect(nan=True);json.dumps(lane,allow_nan=False);self.assertIsNone(lane['values']['targets'][1]['answers'][0]['coefficients'][1]);self.assertFalse(lane['values']['targets'][1]['answers'][0]['comparison_eligible'])
    def test_actual_readiness_initial_and_full(self):
        lane=collect();self.assertEqual(lane['ready_snapshot'],lane['readiness']['states'][0]);self.assertEqual(len(lane['readiness']['states']),5)
    def test_pole_bypass_accepts_restored_flags_without_learning_claim(self):
        state=collect()['ready_snapshot'];self.assertEqual([state['CHECKPHASE'],state['HELDOUBLECHECKED'],state['HELOFFSET']],[1,0,10000]);self.assertFalse(state['stored_INIT_flags_are_learned']);self.assertTrue(state['policy']['derived_bypass_from_observed_policy_and_source']);self.assertFalse(state['policy']['internal_local_bypass_observed'])
    def test_wrong_bypass_policy_and_fullsum_profile_rejected(self):
        for transform in [lambda s:s.replace('POLICY 2 1 0 0 1 1','POLICY 2 1 -1 0 1 0'),lambda s:s.replace('HEL 0 0 1 1','HEL 0 0 1 0'),lambda s:s.replace('STATE 0 0 1 0 10000','STATE 0 0 1 0 0')]:
            data=raw_set();data['target-readiness.dat']=transform(data['target-readiness.dat'])
            with self.assertRaises(ValueError):COL.collect(data,(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
    def test_no_inferred_state_or_input_truth(self):
        lane=collect();self.assertFalse(lane['values']['targets'][0]['before']['canonical_repaired_or_native_input_claim']);self.assertFalse(lane['independent_physical_truth']);self.assertFalse(lane['readiness']['state_restoration_performed'])
    def test_initial_readiness_failure_and_trailing_rejected(self):
        for text in [readiness(True).replace('POLICY 0 0 0 0 1 1','POLICY 0 0 0 0 0 1'),readiness(True)+'EXTRA\n',readiness(True).replace('HEL 0 0 32 1\n','')]:
            with self.assertRaises(ValueError):COL.initial_readiness(text,C.pins()['actual_filter_dimensions'])
    def test_incomplete_targets_rejected(self):
        data=raw_set();data['target-raw.dat']=data['target-raw.dat'].split('BEGIN 2')[0]
        with self.assertRaises(ValueError):COL.collect(data,(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
    def test_ordinary_control_refusal_never_reference(self):
        data=raw_set();data['target-raw.dat']=data['target-raw.dat'].replace('ANS 1 0 219','ANS 1 0 420').replace('ANS 1 1 219','ANS 1 1 420')
        with self.assertRaises(ValueError):COL.collect(data,(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
    def test_ordinary_control_hard_parity_required(self):
        ref=reference();ref['lane']['rows'][0]['coefficients'][1]=20.
        with self.assertRaises(ValueError):COL.collect(raw_set(),(HERE/'inputs/targets2.dat').read_text(),ref,COMPARE,C.pins()['actual_filter_dimensions'])
    def test_target_caller_input_mismatch_rejected(self):
        data=raw_set();token=data['target-raw.dat'].splitlines()[2].split()[-1];data['target-raw.dat']=data['target-raw.dat'].replace(token,word(42.),1)
        with self.assertRaises(ValueError):COL.collect(data,(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
    def test_no_forced_target2_success_across_arms(self):
        pair=COL.compare(collect(),collect(status2=323),COMPARE);self.assertFalse(pair['target2_both_comparison_eligible']);self.assertIsNone(pair['target2_numerical_comparison']);self.assertEqual(pair['target2_statuses'],{'original':[420,420],'candidate':[323,323]});self.assertFalse(pair['target2_status_or_numerical_success_enforced'])
    def test_both_eligible_target2_is_still_observation(self):
        pair=COL.compare(collect(status2=323),collect(status2=219),COMPARE);self.assertTrue(pair['target2_both_comparison_eligible']);self.assertTrue(pair['target2_numerical_comparison']['regression']['passed']);self.assertFalse(pair['scientific_qualified'])
    def test_learning_requires_actual_full100_records(self):
        data=raw_set();data['warmup.dat']=data['warmup.dat'].splitlines()[0]+'\n'
        with self.assertRaises(ValueError):COL.collect(data,(HERE/'inputs/targets2.dat').read_text(),reference(),COMPARE,C.pins()['actual_filter_dimensions'])
class WorkerTests(unittest.TestCase):
    def fresh(self):
        worker=W.Worker.__new__(W.Worker);worker.closed=False;worker.sequence=0;worker.protocol=[];worker.timeout=180.;worker.process=Mock();worker.process.poll.return_value=None;worker.process.returncode=0;worker.fd=123;worker.buffer=bytearray();worker._send=Mock();worker._message=Mock(return_value=['TARGETED','1','2']);return worker
    def test_exact_target_command_only(self):
        worker=self.fresh();worker.targets();worker._send.assert_called_once_with('TARGETS 1 0');self.assertEqual(worker.sequence,1)
        with self.assertRaises(W.base.ProtocolError):worker.targets()
        with self.assertRaises(W.base.ProtocolError):worker.run(1)
    def test_target_reply_incomplete_rejected(self):
        worker=self.fresh();worker._message.return_value=['TARGETED','1','1']
        with self.assertRaises(W.base.ProtocolError):worker.targets()
    def test_stop_bye_requires_zero_tail(self):
        for buffered,unread in [(b'EXTRA\n',b''),(b'',b'EXTRA\n')]:
            worker=self.fresh();worker._message.return_value=['BYE'];worker.buffer=bytearray(buffered)
            with patch.object(W.base.Worker,'close',return_value=None),patch.object(W.os,'read',side_effect=[unread,b'']),self.assertRaises(W.base.ProtocolError):worker.close()
    def test_stop_bye_exit0_records_protocol(self):
        worker=self.fresh();worker._message.return_value=['BYE']
        with patch.object(W.base.Worker,'close',return_value=None),patch.object(W.os,'read',return_value=b''):worker.close()
        worker._send.assert_called_once_with('STOP 0 0');self.assertEqual(worker.protocol[-1],{'direction':'exit','returncode':0,'trailing_bytes':0})
if __name__=='__main__':unittest.main()
