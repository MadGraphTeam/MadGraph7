"""Dormant reviewed BUILD/reference bindings; no native or tool queries."""
import hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROC='SubProcesses/P0_epem_ttxa'
def require(ok,message):
    if not ok:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
    return h.hexdigest()
def ident(path):return {'bytes':Path(path).stat().st_size,'sha256':digest(path)}
def pins():return read(HERE/'input-pins.json')
def ignored(name):
    relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts and str(relative).startswith('.tirust-build/'),'Expected ignored repository path')
    path=ROOT/relative;require(not path.is_symlink() and path.resolve().is_relative_to(ROOT/'.tirust-build'),'Ignored binding escaped/aliased');return path
def module(name,path):
    spec=importlib.util.spec_from_file_location('_ew_target_binding_'+name,path);obj=importlib.util.module_from_spec(spec);sys.modules[spec.name]=obj;spec.loader.exec_module(obj);return obj
def normal_binding():return module('ordinary',Path(pins()['ordinary_source']['directory'])/'binding.py')
def exact_file(row):
    path=ignored(row['path']);require(digest(path)==row['sha256'],'Bound review/gate bytes changed');return path
def accept_gate(gate,p):
    require(p['closed_target_build'] is not None and p['root_target_BUILD_gate'] is not None and p['independent_target_BUILD_review'] is not None,'Target BUILD and independent review remain unbound')
    require(gate['schema']=='ew-qp-mass-target-build-run-gate-v1' and gate['build_accepted'] is True and gate['independent_review_accepted'] is True,'Target BUILD not independently accepted')
    require(gate['qualification_scope']=='closed-target-build-compiler-ABI-runtime-only' and gate['scientific_qualified'] is False and gate['target_RUN_admitted'] is False,'BUILD gate scope must not manufacture numerical qualification/admission')
    expected_index={'path':str(Path(p['compiled_source']['directory']).relative_to(ROOT)/'source-index.json'),'sha256':p['compiled_source']['source_index_sha256']}
    require(gate['compiled_source_index']==expected_index,'Actual compiled target source must be pinned separately from RUN source')
    for key,field in [('build_terminal_sha256','terminal_sha256'),('build_result_sha256','result_sha256')]:require(gate[key]==p['closed_target_build'][field],'Wrong closed target BUILD identity')
    require(gate['build_raw_inventory']==p['closed_target_build']['raw_inventory'] and gate['independent_review']==p['independent_target_BUILD_review'],'Wrong exact target BUILD inventory/review')
    require(gate['reviewed_parent_BUILD_gate']==p['root_parent_BUILD_gate'],'Wrong original closed BUILD provenance');return gate
def closed(gate_path,gate_sha):
    p=pins();require(p['root_target_BUILD_gate'] is not None,'Future target BUILD gate not yet supplied')
    require({'path':gate_path,'sha256':gate_sha}==p['root_target_BUILD_gate'],'Exact root-provided target BUILD gate required')
    gate=accept_gate(read(exact_file(p['root_target_BUILD_gate'])),p);exact_file(gate['independent_review']);inventory=read(exact_file(gate['build_raw_inventory']));closed=p['closed_target_build'];report=ignored(closed['report'])
    require(inventory['base']==str(report) and inventory['build_terminal_sha256']==closed['terminal_sha256'] and inventory['build_result_sha256']==closed['result_sha256'],'Raw inventory describes another BUILD')
    actual=set()
    for path in report.rglob('*'):
        require(not path.is_symlink(),'Target BUILD report aliases forbidden')
        if path.is_file():actual.add(str(path.relative_to(report)))
    require(actual==set(inventory['files']),'Target BUILD report inventory changed')
    for name,record in inventory['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe BUILD raw name');require(ident(report/name)==record,'Target BUILD raw proof changed')
    require(digest(report/'terminal.json')==closed['terminal_sha256'] and digest(report/'result.json')==closed['result_sha256'],'Closed target BUILD receipts changed')
    terminal=read(report/'terminal.json');result=read(report/'result.json')
    require(terminal['status']=='passed' and terminal['returncode']==0 and terminal['cleanup']['survivors']==[] and terminal['result_sha256']==closed['result_sha256'],'Target BUILD did not close successfully')
    require(result['status']=='passed' and result['stage']=='target-build' and result['source_index_sha256']==p['compiled_source']['source_index_sha256'] and set(result['variants'])=={'original','candidate'},'Wrong compiled target BUILD/source')
    require(result['new_driver_compiles']==2 and result['new_links']==2 and result['native_main_calls']==result['model_probes']==result['reducer_calls']==0 and result['target_RUN_admitted'] is False and result['scientific_qualified'] is False,'Target BUILD exceeded declared scope')
    require(result['reviewed_parent_BUILD_gate_sha256']==p['root_parent_BUILD_gate']['sha256'],'Wrong normal BUILD parent')
    old=p['root_parent_BUILD_gate'];parent=normal_binding().closed(old['path'],old['sha256'])
    return {'gate':gate,'gate_sha256':gate_sha,'result':result,'parent':parent,'review_sha256':gate['independent_review']['sha256'],'raw_inventory_sha256':gate['build_raw_inventory']['sha256']}
def live_manifest(closed_build):
    p=pins();normal=normal_binding();bound=normal.live_manifest(closed_build['parent'])
    def add(path,record):
        name=str(Path(path).resolve());value=record['sha256'] if isinstance(record,dict) else record;require(name not in bound or bound[name]==value,'Conflicting target BUILD binding');bound[name]=value
    for role,row in closed_build['result']['variants'].items():
        output=Path(row['output']);require(output==ROOT/'.tirust-build/ew-qp-mass-target-build-work-2/build'/role,'Wrong target BUILD output root');base=closed_build['parent']['result']['variants'][role]
        driver={k:p['driver'][k] for k in ('bytes','sha256')}
        require(row['sources']=={**base['sources'],PROC+'/target_driver.f':driver} and row['closed_process_objects']==base['process_objects'] and row['private_data']==base['private_data'],'Target source/object/card lineage differs')
        require(row['runtime']['files']==p['expected_runtime']['files'] and row['old_main_object_retained_but_not_linked'] is True and row['normal_model_and_process_sources_unchanged'] is True,'Target runtime/old-main policy differs')
        require(not any(name.endswith('/check_sa.o') for name in row['actual_link_loads']),'Old normal main object was linked')
        for field in ('sources','closed_process_objects','private_data'):
            for name,record in row[field].items():add(output/name,record)
        for field in ('stock_objects','stock_modules','process_modules','canonical_libraries'):
            for name,record in base[field].items():add(output/name,record)
        for name,record in row['target_compile_inputs']['bound_files'].items():add(name,record)
        for field in ('actual_link_loads',):
            for name,record in row[field].items():add(name,record)
        for name,record in row['runtime']['files'].items():add(name,record)
        add(output/PROC/'target_driver.o',row['target_driver_object']);add(output/PROC/'target-check',row['executable_sha256'])
        for name,wanted in p['data_pins'][role].items():require(row['private_data'][name]==wanted,'Target runtime cards/resources changed')
    return bound
def verify_live(bindings):return normal_binding().verify_live(bindings)
def ordinary_reference(role):
    p=pins();gate=read(exact_file(p['ordinary_reference_gate']));require(gate['schema']=='root-reviewed-EW-ordinary-pair-v1' and gate['ordinary_pair_accepted'] is True and gate['independent_review_accepted'] is True,'Ordinary pair not independently accepted')
    require(gate['source_index_sha256']==p['ordinary_source']['source_index_sha256'] and gate['QP_mass_path_qualified'] is False and gate['independent_physical_truth'] is False and gate['production_promoted'] is False,'Ordinary reference scope changed')
    require({'path':gate['independent_review'],'sha256':gate['independent_review_sha256']}==p['ordinary_reference_review'],'Ordinary independent review changed');exact_file(p['ordinary_reference_review'])
    require(gate==read(HERE/'ordinary-reference-gate.json') and read(exact_file(p['ordinary_reference_review']))==read(HERE/'ordinary-reference-review.json'),'Pinned ordinary reference text changed')
    row=gate['arms'][role];terminal_path=ignored(row['terminal']);result_path=ignored(row['result']);require(digest(terminal_path)==row['terminal_sha256'] and digest(result_path)==row['result_sha256'],'Closed ordinary receipts changed');terminal=read(terminal_path);result=read(result_path)
    require(terminal['status']=='passed' and terminal['returncode']==0 and terminal['cleanup']['survivors']==[] and terminal['result_sha256']==row['result_sha256'],'Ordinary reference did not close cleanly')
    require(result['stage']==role and result['source_index_sha256']==p['ordinary_source']['source_index_sha256'] and result['BUILD_gate_sha256']==p['root_parent_BUILD_gate']['sha256'],'Wrong ordinary role/source/BUILD')
    for name,h in result['raw_files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe ordinary raw name');require(digest(result_path.parent/name)==h,'Ordinary raw evidence changed')
    collector=module('ordinary_collector',HERE/'ordinary_collector.py');files=('warmup.dat','dimensions.dat','exact-words.dat','exact-ieee.dat','software-flags.dat');lane=collector.collect({name:(result_path.parent/name).read_text() for name in files});require(lane==result['lane'],'Closed ordinary lane did not replay')
    return {'gate_sha256':p['ordinary_reference_gate']['sha256'],'result_sha256':row['result_sha256'],'terminal_sha256':row['terminal_sha256'],'lane':lane,'independent_physical_truth':False,'QP_mass_path_qualified':False}
