      CALL ML5_0_FORCE_STABILITY_CHECK(.TRUE.)
      P=POINTS(:,:,1)
      TOTAL=P(:,1)+P(:,2)
      MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
      CALL UPDATE_AS_PARAM()
      CALL SYSTEM_CLOCK(T0,RATE)
      IF(RATE.LE.0) STOP 5
      CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
C     The first call bootstraps MadLoop and may have an unknown status.
C     Retain it, but require a recognized status on every later call.
      CALL BENCHMARK_TRACE_WARMUP(75,0,1,NDIM,NSO,CODE,ANS,ACC)
      WARM_POINTS=0
      DO K=1,1000+NPOINTS
         WARM_POINT=1+MOD(K-1,NPOINTS)
         P=POINTS(:,:,WARM_POINT)
         TOTAL=P(:,1)+P(:,2)
         MU_R=SQRT(ABS(TOTAL(0)**2-SUM(TOTAL(1:3)**2)))
         CALL UPDATE_AS_PARAM()
         ANS=0D0
         ACC=-1D0
         CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)
         CALL BENCHMARK_TRACE_WARMUP(75,K,WARM_POINT,NDIM,NSO,
     $        CODE,ANS,ACC)
         IF(.NOT.BENCHMARK_WARM_STATUS(CODE)) THEN
            WRITE(74,'(A,2I12)') 'ERROR warmup-status ',
     $           WARM_POINT,CODE
            FLUSH(74)
            CLOSE(75)
            CALL ML5_0_EXIT_MADLOOP()
            STOP 3
         ENDIF
         TENS=MOD(CODE,100)/10
         IF(TENS.EQ.1.OR.TENS.EQ.2) THEN
            WARM_POINTS=WARM_POINTS+1
         ELSE
            WARM_POINTS=0
         ENDIF
         IF(WARM_POINTS.GE.NPOINTS) EXIT
      ENDDO
      IF(WARM_POINTS.LT.NPOINTS) THEN
         WRITE(74,'(A,2I12)') 'ERROR warmup-limit ',WARM_POINT,CODE
         FLUSH(74)
         CLOSE(75)
         CALL ML5_0_EXIT_MADLOOP()
         STOP 3
      ENDIF
      CLOSE(75)
      CALL SYSTEM_CLOCK(T1)
      COLD=DBLE(T1-T0)/DBLE(RATE)
