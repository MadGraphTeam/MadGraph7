#!/usr/bin/env python3
"""Dormant target-driver BUILD: two driver compiles/two links, no main."""
import time
BOOTSTRAP_MONOTONIC=time.monotonic()
import argparse,fcntl,hashlib,importlib.util,json,os,resource,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/ew-qp-mass-target-build-work-2'
REPORT=ROOT/'.tirust-build/ew-qp-mass-target-build-execution-2'
PROC='SubProcesses/P0_epem_ttxa';ROLES=('original','candidate')
CPU,CAP,CLEANUP=12,900.,60.
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
SOURCE=None;GATE=None;GATE_SHA=None

def require(ok,message):
    if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text())
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def ident(p):return {'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def pins():return read(HERE/'input-pins.json')
def dump(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def load(name,p):
    s=importlib.util.spec_from_file_location('_ew_target_'+name,p);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
def local(n):return load(n,HERE/(n+'.py'))
def parent():
    if '_ew_target_parent' not in sys.modules:
        p=pins()['parent_BUILD'];m=load('parent',Path(p['directory'])/'controller.py');m.SOURCE=p['source_index_sha256']
    return sys.modules['_ew_target_parent']
def binding():return load('reviewed_binding',Path(pins()['ordinary_source']['directory'])/'binding.py')
def tool(n):return read(HERE/'toolchain-pins.json')['required_tools'][n]['path']
def environment():
    p=parent().pins();return local('tool_environment').reconstruct(read(HERE/'toolchain-pins.json'),p['compiler_environment_names'],{},p['library_paths'])

def verify_source():
    require(Path.cwd()==ROOT and SOURCE and digest(HERE/'source-index.json')==SOURCE,'Exact reviewed target source/cwd required')
    index=read(HERE/'source-index.json');files=set()
    for p in HERE.rglob('*'):
        require(not p.is_symlink(),'Proposal aliases forbidden')
        if p.is_file():files.add(str(p.relative_to(HERE)))
    require(files==set(index['files'])|{'source-index.json'},'Target proposal inventory changed')
    for n,row in index['files'].items():require(ident(HERE/n)==row,'Target payload changed')
    for key in ('parent_BUILD','ordinary_source'):
        pin=pins()[key];base=Path(pin['directory']);require(digest(base/'source-index.json')==pin['source_index_sha256'],'Parent source seal changed')
        for n,row in read(base/'source-index.json')['files'].items():require(ident(base/n)==row,'Parent source text changed')
    for record in pins()['retained_history'].values():require(digest(record['path'])==record['sha256'],'Retained failed history changed')
    require(digest(HERE/'target_driver.f')==pins()['driver_source_sha256'],'Target driver changed')
    for n,row in pins()['frozen_inputs'].items():require(ident(HERE/'inputs'/n)==row,'Frozen input changed')
    for path in (WORK,REPORT):require(not path.is_symlink() and path.resolve().is_relative_to(ROOT/'.tirust-build'),'Target namespace escaped/aliased')
    return {'status':'source-only-preflight-passed','source_index_sha256':SOURCE,'planned_driver_compiles':2,'planned_links':2,'actual_driver_compiles':0,'actual_links':0,'native_main_calls':0,'compiler_queries':0,'loader_queries':0,'live_BUILD_runtime_inputs_read':False,'target_RUN_admitted':False,'cap_seconds':CAP,'cleanup_reserve_inside_cap':CLEANUP,'cpu':CPU,'cpu_reservation':False}

def closed():
    require(GATE==pins()['root_BUILD_gate']['path'] and GATE_SHA==pins()['root_BUILD_gate']['sha256'],'Exact independently reviewed parent BUILD gate required');return binding().closed(GATE,GATE_SHA)
def relocate(argv,origin,target):return [str(a).replace(str(origin),str(target)) for a in argv]
def compile_recipe(role,origin,target):
    a=relocate(pins()['selected_driver_recipes'][role],origin,target);require(a.count('check_sa.f')==1 and a.count('check_sa.o')==1,'Actual driver compile recipe changed')
    return ['target_driver.f' if x=='check_sa.f' else 'target_driver.o' if x=='check_sa.o' else x for x in a]
def link_recipe(role,origin,target):
    a=relocate(pins()['selected_link_recipes'][role],origin,target);require(a.count('check_sa.o')==1 and a.count('check')==1,'Actual link driver/output slot changed')
    a=['target_driver.o' if x=='check_sa.o' else 'target-check' if x=='check' else x for x in a]
    indices=[i for i,x in enumerate(a) if x.startswith('-Wl,-Map,')];require(len(indices)==1,'Actual link map flag missing/ambiguous');pieces=a[indices[0]].split(',');require(len(pieces)>=3 and pieces[2],'Actual link map output missing');pieces[2]='target-link.map';a[indices[0]]=','.join(pieces);return a

def command(argv,cwd,logs,name):
    logs=Path(logs);logs.mkdir(parents=True,exist_ok=True);argv=list(map(str,argv));env=environment();env['PWD']=str(cwd);dump(logs/(name+'.command.json'),{'argv':argv,'cwd':str(cwd)})
    with (logs/(name+'.stdout.txt')).open('xb') as f:done=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    dump(logs/(name+'.terminal.json'),{'returncode':done.returncode,'stdout_sha256':digest(logs/(name+'.stdout.txt'))});require(done.returncode==0,'Target BUILD command failed; no retry');return (logs/(name+'.stdout.txt')).read_text()

def build():
    b=binding();closed_build=closed();manifest=b.live_manifest(closed_build);before=b.verify_live(manifest);p=parent();parentpins=p.pins();p.local('tool_environment').validate(read(p.HERE/'toolchain-pins.json'),environment());cloning=p.local('cloning');loader=p.support('loader');results={}
    for role in ROLES:
        row=closed_build['result']['variants'][role];origin=Path(row['output']);target=WORK/'build'/role;case=target/PROC;logs=REPORT/'build'/role/'commands'
        shared=parentpins['roles'][role]['shared_aliases'];aliases={name:{'readlink':record['canonical_target'],'resolved':record['canonical_target'],'directory':True} for name,record in shared.items()};cloning.clone(origin,target,aliases,shared)
        require(p.sources(target)==row['sources'] and p.stock_objects(target)==row['stock_objects'] and p.stock_modules(target)==row['stock_modules'] and p.canonical_libraries(target)==row['canonical_libraries'],'Private clone differs from closed BUILD')
        require({str(f.relative_to(target)):ident(f) for f in case.glob('*.o')}==row['process_objects'],'Actual21 closed process objects changed before reuse')
        shutil.copyfile(HERE/'target_driver.f',case/'target_driver.f');expected={**row['sources'],PROC+'/target_driver.f':ident(case/'target_driver.f')};compile_row={**parentpins['roles'][role],'expected_build_sources':expected}
        generated={str((target/n).resolve()):record for n,record in row['process_modules'].items()}
        argv=compile_recipe(role,origin,target);inputs=p.local('compile_inputs').bind(case/'target_driver.f',argv,target,compile_row,parentpins,generated);dump(REPORT/'build'/role/'target-compile-inputs.json',inputs);command(argv,case,logs,'compile-target-driver')
        require(ident(case/'check_sa.o')==row['process_objects'][PROC+'/check_sa.o'],'Retained unused original main object changed')
        selected=link_recipe(role,origin,target);pre=loader.prelink(selected,case,environment(),lambda a,n:command(a,case,logs,n))
        for name,h in parentpins['expected_runtime']['files'].items():require(pre['bound'].get(name,h)==h and digest(name)==h,'Runtime/prelink provider changed');pre['bound'][name]=h
        dump(REPORT/'build'/role/'target-prelink.json',pre);command(selected,case,logs,'link-target-driver');exe=case/'target-check';mapfile=case/'target-link.map';loads=loader.requireactualmap(mapfile.read_text(),case,pre,exe)
        static=p.support('runtime').derive(exe,pre,parentpins['expected_runtime']['files'],environment()['LD_LIBRARY_PATH']);dump(REPORT/'build'/role/'target-static-runtime.json',static)
        runtime=loader.query_runtime(exe,parentpins['expected_runtime']['files'],pre,lambda a,n:command(a,case,logs,n));symbols=command([tool('nm'),'--defined-only','target-check'],case,logs,'target-symbols');names=[line.split()[-1] for line in symbols.splitlines() if len(line.split())>=3]
        require({name:names.count(name) for name in names if '__mtirust_MOD_' in name}=={name:1 for name in parentpins['expected_mtirust_symbols']},'MTIRUST ownership changed')
        require({name:names.count(name) for name in names if '_qpmass_' in name}=={name:1 for name in parentpins['roles'][role]['expected_private_symbols']},'Private mass helper ownership changed')
        for symbol in ('main','ew_target_input_record_','ew_target_env_record_','ew_target_ready_record_','ew_target_io_check_','ew_target_policy_ready_','o3_capture_fp_'):require(names.count(symbol)==1,'Target/main symbol absent or duplicated: '+symbol)
        require(p.sources(target)==expected and p.stock_objects(target)==row['stock_objects'] and p.stock_modules(target)==row['stock_modules'] and p.canonical_libraries(target)==row['canonical_libraries'] and p.data_files(target)==row['private_data'],'Target BUILD changed unselected source/support/card input')
        actual_objects={str(f.relative_to(target)):ident(f) for f in case.glob('*.o')};wanted={**row['process_objects'],PROC+'/target_driver.o':ident(case/'target_driver.o')};require(actual_objects==wanted,'Unselected process object changed')
        require({str(f.relative_to(target)):ident(f) for f in case.glob('*.mod')}==row['process_modules'],'Unselected process module changed')
        require(not any(name.endswith('/check_sa.o') for name in loads),'Original main object was accidentally linked')
        results[role]={'output':str(target),'sources':expected,'closed_process_objects':row['process_objects'],'target_driver_object':ident(case/'target_driver.o'),'target_compile_inputs':inputs,'compile_recipe':argv,'link_recipe':selected,'actual_link_loads':loads,'executable_sha256':digest(exe),'link_map_sha256':digest(mapfile),'prelink_sha256':digest(REPORT/'build'/role/'target-prelink.json'),'static_runtime_sha256':digest(REPORT/'build'/role/'target-static-runtime.json'),'runtime':runtime,'private_data':row['private_data'],'normal_model_and_process_sources_unchanged':True,'old_main_object_retained_but_not_linked':True,'native_main_calls':0}
    require(b.verify_live(manifest)==before,'Protected parent BUILD/runtime changed');verify_source();dump(REPORT/'build/result.json',{'status':'passed','stage':'target-build','source_index_sha256':SOURCE,'reviewed_parent_BUILD_gate_sha256':GATE_SHA,'variants':results,'new_driver_compiles':2,'new_links':2,'native_main_calls':0,'model_probes':0,'reducer_calls':0,'target_RUN_admitted':False,'scientific_qualified':False,'candidate_promoted':False,'performance_acceptance':False,'protected_parent':before})

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard limit too small');resource.setrlimit(kind,(value,value))
def child():
    a=read(REPORT/'build/admission.json');require(a['parent_pid']==os.getppid() and a['source_index_sha256']==SOURCE and a['BUILD_gate']==GATE and a['BUILD_gate_sha256']==GATE_SHA,'Exact target BUILD supervisor admission required');require(os.sched_getaffinity(0)=={CPU},'Target BUILD CPU changed')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Target BUILD resource limit changed')
    verify_source();build()
def supervise():
    end=BOOTSTRAP_MONOTONIC+CAP;cleanup=local('process_cleanup');owner=local('ownership');directory=REPORT/'build';require(not directory.exists(),'Fresh target BUILD report required');directory.mkdir(parents=True)
    entry={'stage':'target-build','source_index_sha256':SOURCE,'BUILD_gate':GATE,'BUILD_gate_sha256':GATE_SHA,'cap_seconds':CAP,'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'bootstrap_monotonic':BOOTSTRAP_MONOTONIC,'original_end_monotonic':end,'status':'running'};process=None;raw=None;owned=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,owner.StageDeadline(CAP,absolute_end=end) as deadline:
            entry['deadline_monotonic']=deadline.end;limits();verify_source();closed();requests.check();require(not WORK.exists(),'Fresh target BUILD work required; no retry')
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(HERE/'controller.py'),'--source',SOURCE,'--build-gate',GATE,'--build-gate-sha',GATE_SHA,'--child'];dump(directory/'admission.json',{**entry,'parent_pid':os.getpid(),'command':argv});env=environment()
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:process=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);raw=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry);entry['returncode']=owned.wait(requests);requests.check();entry['cleanup']=owner.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'Target BUILD failed; no retry');verify_source();closed();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'));dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=owner.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else owner.raw_cleanup(process,raw,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));dump(directory/'terminal.json',entry);raise

def main():
    global SOURCE,GATE,GATE_SHA
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--build-gate');p.add_argument('--build-gate-sha');p.add_argument('--execute',action='store_true');p.add_argument('--child',action='store_true',help=argparse.SUPPRESS);a=p.parse_args();SOURCE=a.source;GATE=a.build_gate;GATE_SHA=a.build_gate_sha
    if a.child:child()
    elif a.execute:
        require(GATE and GATE_SHA,'Exact parent BUILD gate required')
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise()
    else:require(not GATE and not GATE_SHA,'Default source preflight takes no execution gate');print(json.dumps(verify_source(),sort_keys=True))
if __name__=='__main__':main()
