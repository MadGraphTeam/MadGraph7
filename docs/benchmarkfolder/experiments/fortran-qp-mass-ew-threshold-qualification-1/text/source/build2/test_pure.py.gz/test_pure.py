"""Source/grammar controls only: no compiler, model, loader, or native main."""
import ast,copy,hashlib,importlib.util,json,math,struct,sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
C=module('target_test_controller',HERE/'controller.py')
P=module('target_test_protocol',HERE/'protocol.py')
COMPARE=module('target_test_comparison',Path(C.pins()['ordinary_source']['directory'])/'comparison.py').compare_rows
def word(x):return struct.pack('>d',x).hex().upper()
def raw_text(second_status=420,nan_refusal=False):
    out=['META EW_TARGET_RAW_V1 2 1 1 1'];stream=[float(v.replace('D','E')) for v in (HERE/'inputs/targets2.dat').read_text().split()[1:]]
    for k in (1,2):
        out.append(f'BEGIN {k}')
        def inputs(phase):
            for leg in range(1,6):
                for comp in range(4):out.append(f'P {k} {phase} {leg} {comp} {word(stream[(k-1)*20+(leg-1)*4+comp])}')
            out.append(f'MUR {k} {phase} {word(1000.)}')
        def env(phase):out.extend([f'FP {k} {phase} '+' '.join(map(str,[1]+[0]*10)),f'SOFT {k} {phase} 0 0'])
        inputs(1);env(1);env(2);inputs(2)
        for order in (0,1):
            values=[1.,2.,3.,4.,1e-8]
            if k==2 and nan_refusal:values[1]=float('nan')
            out.append(f'ANS {k} {order} {219 if k==1 else second_status} '+' '.join(map(word,values)))
        out.append(f'ENDTARGET {k}')
    return '\n'.join(out+['END 1 2'])+'\n'
def ready_text(checkphase=1,heldouble=0,mode=0):
    dims=C.pins()['actual_filter_dimensions'];n=dims['NCOMB'];groups=dims['NLOOPGROUPS'];out=[f'META EW_TARGET_READY_V2 {n} {groups} 1']
    for k,phase in ((0,0),(1,1),(1,2),(2,1),(2,2)):
        out.append(f'POLICY {k} {phase} {mode} 0 1 {int(mode>=0)} 0 2 -1 3EB0C6F7A0B5ED8D');out.append(f'STATE {k} {phase} {checkphase} {heldouble} 10000')
        out.extend(f'HEL {k} {phase} {i} 1' for i in range(1,n+1))
        out.extend(f'AMP {k} {phase} 1 {i} 1' for i in range(1,groups+1))
    return '\n'.join(out)+'\n'
class SourceTests(unittest.TestCase):
    def setUp(self):self.driver=(HERE/'target_driver.f').read_text();self.pin=C.pins()
    def test_source_seal_and_default_preflight(self):
        C.SOURCE=C.digest(HERE/'source-index.json')
        with patch.object(C,'closed',side_effect=AssertionError('live BUILD read')),patch.object(C,'binding',side_effect=AssertionError('runtime read')),patch.object(C.subprocess,'run',side_effect=AssertionError('tool execution')),patch.object(C.subprocess,'Popen',side_effect=AssertionError('tool execution')):
            result=C.verify_source()
        self.assertFalse(result['live_BUILD_runtime_inputs_read']);self.assertEqual(result['native_main_calls'],0)
    def test_exact_ordinary_learning(self):
        reference=(HERE/'ordinary-learning-reference.f').read_text();self.assertIn(reference,self.driver)
        self.assertNotIn('TPOINTS',reference);self.assertEqual(C.digest(HERE/'ordinary-learning-reference.f'),self.pin['normal_learning_reference_sha256'])
    def test_qualified_helper_source(self):
        ref=(HERE/'qualified-helper-reference.f').read_text();self.assertTrue(self.driver.endswith(ref));self.assertEqual(C.digest(HERE/'qualified-helper-reference.f'),self.pin['qualified_helpers_sha256'])
    def test_two_buffers_and_exact_argv(self):
        for value in ['TPOINTS(0:3,NEXTERNAL,2)','ALLOCATE(POINTS(0:3,NEXTERNAL,NPOINTS))','CALL GET_COMMAND_ARGUMENT(1,ARG)','CALL GET_COMMAND_ARGUMENT(2,ARG)','CALL GET_COMMAND_ARGUMENT(3,ARG)','IF(NPOINTS.NE.100)','IF(NTARGETS.NE.2)']:
            self.assertIn(value,self.driver)
        self.assertNotIn('POINTS=TPOINTS',self.driver)
    def test_target_stream_ordinary_control_identity(self):
        ordinary=(HERE/'inputs/ordinary100.dat').read_text().split();targets=(HERE/'inputs/targets2.dat').read_text().split()
        self.assertEqual(ordinary[0],'100');self.assertEqual(targets[0],'2');self.assertEqual(ordinary[1:21],targets[1:21])
    def test_pinned_input_identities(self):
        for name,record in self.pin['frozen_inputs'].items():self.assertEqual(C.ident(HERE/'inputs'/name),record)
        self.assertEqual(self.pin['frozen_inputs']['targets2.dat']['sha256'],'f1663e764a65d5b9ca89691177f3607ba85f3daff8b52af9360b1a4f09e26de3')
    def test_common_layout_dimensions(self):
        self.assertEqual(self.pin['actual_filter_dimensions'],{'NCOMB':32,'NLOOPGROUPS':200,'NSQUAREDSO':1})
        for value in ['COMMON/ML5_0_INIT/CHECKPHASE,HELDOUBLECHECKED','COMMON/ML5_0_FILTERS/GOODAMP,GOODHEL,HELOFFSET','LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)','INTEGER HELOFFSET,GOODHEL(NCOMB)']:self.assertIn(value,self.driver)
        self.assertNotIn('CHECKPHASE=',self.driver);self.assertNotIn('HELDOUBLECHECKED=',self.driver);self.assertNotIn('GOODHEL=',self.driver);self.assertNotIn('GOODAMP=',self.driver)
    def test_required_mass_constant_and_readiness(self):
        for value in ["INCLUDE 'coupl.inc'","INCLUDE 'pmass.inc'",'REAL*8 ZERO','PARAMETER(ZERO=0D0)','IF(.NOT.EW_TARGET_POLICY_READY(0,CHECKPHASE,']:self.assertIn(value,self.driver)
    def test_both_requests_normal_threshold(self):
        block=self.driver[self.driver.index('      DO K=1,NTARGETS'):]
        block=block[block.index('      DO K=1,NTARGETS'):] if block.count('      DO K=1,NTARGETS')==1 else block[block.rindex('      DO K=1,NTARGETS'):]
        block=block[:block.index("      WRITE(80,'(A,2I8)'")]
        self.assertEqual(block.count('CALL ML5_0_SLOOPMATRIX_THRES(P,ANS,-1D0,ACC,CODE)'),1)
        for forbidden in ['IF(CODE','IF(.NOT.BENCHMARK','GOTO',' CYCLE',' EXIT','CTMODE','/dev/null','IEEE_SET']:self.assertNotIn(forbidden,block.upper())
        self.assertIn('P=TPOINTS(:,:,K)',block)
    def test_no_fp_setters_or_stdout_redirection(self):
        self.assertNotIn('IEEE_SET',self.driver.upper());self.assertNotIn('/dev/null',self.driver);self.assertNotIn('FORCE_STABILITY_CHECK(.FALSE.)',self.driver)
    def test_fixed_form_length_and_zero_tabs(self):
        self.assertNotIn('\t',self.driver)
        self.assertFalse([i for i,line in enumerate(self.driver.splitlines(),1) if line and line[0] not in 'Cc*!' and len(line)>132])
    def test_compile_recipe_only_driver_slots(self):
        for role in C.ROLES:
            origin=Path('/old')/role;target=Path('/new')/role;old=self.pin['selected_driver_recipes'][role];new=C.compile_recipe(role,origin,target)
            self.assertEqual(new,['target_driver.f' if x=='check_sa.f' else 'target_driver.o' if x=='check_sa.o' else x for x in old]);self.assertNotIn('check_sa.f',new);self.assertNotIn('check_sa.o',new)
    def test_link_preserves_scientific_object_order(self):
        for role in C.ROLES:
            old=self.pin['selected_link_recipes'][role];new=C.link_recipe(role,Path('/old'),Path('/new'))
            before=[x for x in old if x.endswith('.o')];after=[x for x in new if x.endswith('.o')]
            self.assertEqual(len(before),21);self.assertEqual(after,['target_driver.o']+before[1:]);self.assertNotIn('check_sa.o',new);self.assertIn('target-check',new);self.assertIn('-Wl,-Map,target-link.map,--cref',new);self.assertEqual(new,['target_driver.o' if x=='check_sa.o' else 'target-check' if x=='check' else x.replace('private-link.map','target-link.map') for x in old])
    def test_compile_recipe_ambiguous_main_rejected(self):
        bad=copy.deepcopy(self.pin);bad['selected_driver_recipes']['original'].append('check_sa.o')
        with patch.object(C,'pins',return_value=bad),self.assertRaises(ValueError):C.compile_recipe('original',Path('/old'),Path('/new'))
    def test_source_controller_limits_and_absolute_end(self):
        text=(HERE/'controller.py').read_text();self.assertIn('end=BOOTSTRAP_MONOTONIC+CAP',text);self.assertIn('StageDeadline(CAP,absolute_end=end)',text);self.assertEqual((C.CAP,C.CLEANUP,C.CPU),(900.,60.,12));self.assertEqual(C.LIMITS,{'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0})
    def test_supervisor_cleanup_and_no_automatic_run(self):
        text=(HERE/'controller.py').read_text();ast.parse(text)
        for value in ['start_new_session=True','owner.raw_cleanup(process,raw,cleanup','deadline.handoff=True','environment()','target_RUN_admitted']:self.assertIn(value,text)
        self.assertNotIn("command([str(exe)",text);self.assertNotIn('ordinary-run-work',text);self.assertNotIn('ninjars-build',text)
    def test_target_build_outputs_isolated(self):
        self.assertEqual(C.WORK,C.ROOT/'.tirust-build/ew-qp-mass-target-build-work-2');self.assertEqual(C.REPORT,C.ROOT/'.tirust-build/ew-qp-mass-target-build-execution-2')
    def test_default_gate_not_execution(self):
        with patch.object(C,'binding',side_effect=AssertionError('runtime read')),self.assertRaises(ValueError):C.closed()
class ProtocolTests(unittest.TestCase):
    def test_complete_refusal_retained(self):
        result=P.raw(raw_text());self.assertTrue(result['both_targets_complete']);self.assertTrue(result['targets'][0]['answers'][0]['comparison_eligible']);self.assertFalse(result['targets'][1]['answers'][0]['comparison_eligible']);self.assertFalse(result['scientific_qualified'])
    def test_nonfinite_refusal_json_safe(self):
        result=P.raw(raw_text(nan_refusal=True));json.dumps(result,allow_nan=False);self.assertIsNone(result['targets'][1]['answers'][0]['coefficients'][1]);self.assertTrue(result['targets'][1]['answers'][0]['buffers_are_diagnostics_only'])
    def test_actual_qp_alias(self):
        result=P.raw(raw_text(second_status=323));self.assertEqual(result['targets'][1]['answers'][0]['public']['precision'],'QP');self.assertTrue(result['targets'][1]['answers'][0]['comparison_eligible'])
    def test_unchecked_and_wrong_alias_not_accepted(self):
        for code in [239,329,419,318,-1]:self.assertFalse(P.public_status(code)['accepted_public_status'])
    def test_raw_trailing_missing_reordered_rejected(self):
        text=raw_text()
        for bad in [text+'SURPRISE\n',text.replace('ENDTARGET 2\n',''),text.replace('P 1 1 1 0','P 1 1 1 1',1)]:
            with self.assertRaises(ValueError):P.raw(bad)
    def test_bad_words_status_and_ieee_rejected(self):
        text=raw_text()
        for bad in [text.replace(word(1000.),'XYZ',1),text.replace('ANS 1 1 219','ANS 1 1 323'),text.replace('FP 1 1 1 0','FP 1 1 1 7',1)]:
            with self.assertRaises(ValueError):P.raw(bad)
    def test_caller_input_words_exact(self):
        report=P.raw(raw_text());result=P.caller_input_check((HERE/'inputs/targets2.dat').read_text(),report);self.assertTrue(result['before_caller_P_matches_frozen_decimal_stream']);self.assertFalse(result['canonical_repaired_or_native_input_claim'])
        report['targets'][0]['before']['caller_P'][0][0]['word']=word(42.)
        with self.assertRaises(ValueError):P.caller_input_check((HERE/'inputs/targets2.dat').read_text(),report)
    def test_readiness_exact_full_state(self):
        result=P.readiness(ready_text(),C.pins()['actual_filter_dimensions']);self.assertEqual(len(result['states']),5);self.assertTrue(all(len(r['GOODHEL'])==32 and len(r['GOODAMP'])==200 for r in result['states']));self.assertFalse(result['state_restoration_performed'])
    def test_bad_readiness_rejected(self):
        for text in [ready_text(mode=-1),ready_text().replace('AMP 2 2 1 200 1\n',''),ready_text()+'EXTRA\n',ready_text().replace('AMP 1 1 1 1 1','AMP 1 1 1 1 2')]:
            with self.assertRaises(ValueError):P.readiness(text,C.pins()['actual_filter_dimensions'])
    def test_explicit_pole_bypass_preserves_actual_stored_flags(self):
        result=P.readiness(ready_text(),C.pins()['actual_filter_dimensions']);state=result['states'][0]
        self.assertEqual([state['CHECKPHASE'],state['HELDOUBLECHECKED'],state['HELOFFSET']],[1,0,10000]);self.assertFalse(state['stored_INIT_flags_are_learned']);self.assertFalse(state['policy']['internal_local_bypass_observed'])
    def test_legacy_nonbypass_requires_actual_learned_flags(self):
        dims=C.pins()['actual_filter_dimensions']
        with self.assertRaises(ValueError):P.readiness(ready_text(mode=-1),dims,expected_mode=-1)
        result=P.readiness(ready_text(checkphase=0,heldouble=1,mode=-1),dims,expected_mode=-1);self.assertTrue(result['states'][0]['stored_INIT_flags_are_learned'])
    def test_wrong_policy_profile_and_changed_snapshots_rejected(self):
        text=ready_text();bad=[text.replace('POLICY 0 0 0 0 1 1','POLICY 0 0 0 1 1 1'),text.replace('POLICY 0 0 0 0 1 1','POLICY 0 0 0 0 0 1'),text.replace('STATE 0 0 1 0 10000','STATE 0 0 1 0 0'),text.replace('HEL 0 0 1 1','HEL 0 0 1 0'),text.replace('AMP 0 0 1 1 1','AMP 0 0 1 1 0'),text.replace('3EB0C6F7A0B5ED8D','3F1A36E2EB1C432D',1)]
        for value in bad:
            with self.assertRaises(ValueError):P.readiness(value,C.pins()['actual_filter_dimensions'])
    def test_policy_state_is_read_only_and_include_is_exact(self):
        driver=(HERE/'target_driver.f').read_text();self.assertEqual(driver.count("INCLUDE 'MadLoopParams.inc'"),2);self.assertIn('COMMON/ML5_0_BYPASS_CHECK/BYPASS_CHECK,ALWAYS_TEST_STABILITY',driver)
        for forbidden in ['BYPASS_CHECK=','ALWAYS_TEST_STABILITY=','LOOPPOLEMODE=','MLSTABTHRES=','HELOFFSET=','GOODHEL=','GOODAMP=']:self.assertNotIn(forbidden,driver)
    def test_ordinary_control_requires_accepted_parity(self):
        result=P.raw(raw_text());ordinary=copy.deepcopy(result['targets'][0]['answers']);answer=P.ordinary_control(ordinary,result,COMPARE);self.assertTrue(answer['passed']);self.assertEqual(answer['word_differences'],[])
        result['targets'][0]['answers'][0]['coefficients'][1]=20.;self.assertFalse(P.ordinary_control(ordinary,result,COMPARE)['passed'])
    def test_refusal_buffers_never_compared(self):
        result=P.raw(raw_text());old=copy.deepcopy(result['targets'][0]['answers']);old[0]['status']=420
        with self.assertRaises(ValueError):P.ordinary_control(old,result,lambda *a,**k: self.fail('refusal compared'))
        result['targets'][0]['answers'][0]['comparison_eligible']=False
        with self.assertRaises(ValueError):P.ordinary_control(result['targets'][0]['answers'],result,lambda *a,**k:self.fail('refusal compared'))
if __name__=='__main__':unittest.main()
