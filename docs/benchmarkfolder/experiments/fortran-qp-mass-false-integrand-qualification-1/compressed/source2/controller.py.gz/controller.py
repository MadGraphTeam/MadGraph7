#!/usr/bin/env python3
"""Dormant two-arm False-policy RUN; default is source/file-only preflight."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WORK=ROOT/'.tirust-build/qp-mass-false-integrand-qualification-work-2'
REPORT=ROOT/'.tirust-build/qp-mass-false-integrand-qualification-execution-2'
CPU=12;CLEANUP=60.;CAPS={'original':600.,'candidate':600.}
LIMITS={'address_space_bytes':16*1024**3,'file_bytes':512*1024**2,'core_bytes':0}
LEAVES=('libcts.a','libdhelas.a','libiregi.a','libmodel.a','mpmodule.mod')
EXPECTED=None;REVIEWED_ORIGINAL=None
RAW=('warmup.dat','dimensions.dat','exact-words.dat','exact-ieee.dat','software-flags.dat')

def require(ok,message):
    if not ok:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def pins():return read(HERE/'input-pins.json')
def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
def check(path,record):
    path=Path(path);require(path.is_file() and path.stat().st_size==record['bytes'] and digest(path)==record['sha256'],'Pinned file changed: '+str(path))
def load(name,path):
    path=Path(path)
    if path.parent!=HERE:check(path,pins()['external_files'][str(path)])
    spec=importlib.util.spec_from_file_location('false_gate_'+name,path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
def local(name):return load(name,HERE/(name+'.py'))
def support(name):return load(name,pins()['support_paths'][name])
def tool(name):return read(pins()['toolchain'])['required_tools'][name]['path']
def environment():
    p=pins();return support('tool_environment').reconstruct(read(p['toolchain']),p['compiler_environment_names'],{},p['library_paths'])
def proc(output):return Path(output)/'SubProcesses'/pins()['subprocess']
def sources(output):
    output=Path(output);suffixes={'.f','.f90','.for','.inc','.c','.cc','.h'}
    return {str(p.relative_to(output)):digest(p) for subtree in ('Source','SubProcesses') for p in sorted((output/subtree).rglob('*'))
        if p.is_file() and (p.suffix.lower() in suffixes or p.name.startswith('makefile') or p.name in ('make_opts','MadLoop_makefile_definitions'))}
def objects(output):
    output=Path(output)
    actual={str(p.relative_to(output)):digest(p) for p in sorted(output.rglob('*')) if p.is_file() and p.suffix.lower() in ('.o','.mod','.a') and 'build-history' not in p.parts and 'worker-raw' not in p.parts}
    # pathlib does not recurse through the sole read-only lib directory alias.
    # Bind all five direct leaves independently, never the unit's five providers.
    for name in LEAVES:actual['lib/'+name]=digest(output/'lib'/name)
    return actual

def verify_source():
    require(Path.cwd()==ROOT,'Use the required MadGraph working directory')
    require(EXPECTED and digest(HERE/'source-index.json')==EXPECTED,'Exact reviewed source seal required')
    index=read(HERE/'source-index.json');expected=set(index['files'])|{'source-index.json'}
    directories={str(q) for name in expected for q in Path(name).parents if str(q)!='.'};actual=set()
    for path in HERE.rglob('*'):
        name=str(path.relative_to(HERE));require(not path.is_symlink() and path.resolve().is_relative_to(HERE),'Proposal aliases/escape forbidden')
        if path.is_file():actual.add(name)
        else:require(path.is_dir() and name in directories,'Unexpected proposal directory')
    require(actual==expected,'Exact source payload inventory differs')
    for name,record in index['files'].items():check(HERE/name,record)

def closed_build(role):
    p=pins()['builds'][role];terminal=read(p['terminal']);result=read(p['result'])
    require(terminal['status']=='passed' and terminal['returncode']==0 and not terminal['cleanup']['survivors']
        and terminal['result_sha256']==digest(p['result']) and terminal['source_index_sha256']==p['source_seal'],'Closed BUILD terminal changed/failed')
    require(result['status']=='passed' and result['stage']=='build' and result['source_index_sha256']==p['source_seal'],'Wrong closed BUILD result')
    row=result['variants']['original'] if role=='original' else result
    require(row['output']==p['output'],'Wrong reused executable output')
    return row

def protected():
    p=pins()
    for name,record in p['external_files'].items():check(name,record)
    summary={}
    for role in CAPS:
        row=closed_build(role);output=Path(row['output']);directory=proc(output)
        require(sources(output)==row['sources'] and objects(output)==row['objects'],'Reused source/object family changed: '+role)
        require(digest(directory/'check')==row['executable_sha256'] and digest(directory/'private-link.map')==row['link_map_sha256'],'Reused executable/link map changed')
        for name,wanted in row['actual_link_loads'].items():require(digest(name)==wanted,'Actual bound link input changed: '+name)
        require(row['runtime']['files']==p['runtime']['files'],'Physical provider closure changed')
        require(row['runtime']['loader']==p['runtime']['actual_interpreter'],'Actual PT_INTERP binding changed')
        require(not list(output.rglob('worker-protocol.fifo')),'Protected donor has an active worker')
        require(len(row['sources'])==195 and len(row['objects'])==144,'Full physical source/object closure differs')
        require(row['policy_evidence']['all_original_compiler_policies_preserved'],'Closed compiler policy not preserved')
        for name,record in p['runtime_copies'][role].items():check(output/name,record)
        summary[role]={'sources':195,'objects':144,'executable_sha256':row['executable_sha256'],
            'closed_build_result_sha256':digest(p['builds'][role]['result']),'recipes_bound':True}
    require(len(p['runtime']['files'])==15,'Physical closure must retain15 providers plus executable')
    for name,wanted in {**p['runtime']['files'],**p['extra_mappings']}.items():require(digest(name)==wanted,'Pinned physical provider changed')
    support('tool_environment').validate(read(p['toolchain']),environment())
    return {'builds':summary,'runtime_provider_count':15,'native_calls':0,'compiler_queries':0,'loader_queries':0}

def clone_runtime(role):
    output=WORK/role;require(not output.exists(),'Fresh arm required; no retry')
    donor=Path(pins()['builds'][role]['output']);row=closed_build(role)
    # Whitelist regular file copies only. Never traverse lib/ or NinjaRS aliases.
    planned=pins()['runtime_copies'][role]
    require(set(planned)==set(pins()['runtime_copies']['original']),'Both runtime copy layouts must match')
    for name,record in planned.items():
        source=donor/name;target=output/name
        require(source.is_file() and not source.is_symlink() and source.resolve().is_relative_to(donor.resolve()),'Runtime copy source escaped donor')
        check(source,record);require(source.stat().st_size<=LIMITS['file_bytes'],'Runtime copy exceeds file cap')
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);check(target,record)
    numerical=pins()['numerical_cards']
    for name in numerical:(output/name).write_bytes((HERE/'false-cache0.dat').read_bytes())
    require(not any(p.is_symlink() for p in output.rglob('*')),'Runtime aliases forbidden')
    require(digest(proc(output)/'check')==row['executable_sha256'],'Copied executable changed')
    return output

def runtime_binding(output):
    numerical=set(pins()['numerical_cards']);static={name:record for name,record in pins()['runtime_copies']['original'].items() if name not in numerical and not name.endswith('/check')}
    # Both cards/resources are pinned independently for each arm at clone time;
    # shared non-executable runtime resources must be identical before admission.
    for name,record in static.items():check(Path(output)/name,record)
    found={str(p.relative_to(output)):digest(p) for p in Path(output).rglob('MadLoopParams.dat')}
    wanted={name:digest(HERE/'false-cache0.dat') for name in numerical}
    require(found==wanted,'All four private numerical card copies must be False/cache0')
    require(digest(Path(output)/'Cards/param_card.dat')==pins()['param_card_sha256'],'Physical card changed')
    return {'numerical_cards':found,'physical_card_sha256':pins()['param_card_sha256'],'copied_runtime_only':True}

def maps(worker):
    raw=Path('/proc/'+str(worker.process.pid)+'/maps').read_text();files={}
    for line in raw.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[-1].startswith('/'):
            require(not fields[-1].endswith(' (deleted)'),'Deleted runtime mapping');name=str(Path(fields[-1]).resolve());files[name]=digest(name)
    p=pins();exe=(worker.directory/'check').resolve();allowed={**p['runtime']['files'],**p['extra_mappings'],str(exe):digest(exe)}
    require(all(files.get(name)==wanted for name,wanted in p['runtime']['files'].items()) and files.get(str(exe))==digest(exe),'Required15 initialized providers plus executable missing')
    require(all(allowed.get(name)==wanted for name,wanted in files.items()),'Unexpected initialized mapping')
    return {'pid':worker.process.pid,'maps':raw,'files':files,'required_provider_count':15}

def modules():
    # Every imported tools/ Python file is bound before import by protected().
    sys.path.insert(0,str(ROOT/'tools'))
    import tirust_benchmark as bench
    from tirust_benchmark_worker import Worker
    return bench,Worker

def inventory(directory):return {str(p.relative_to(directory)):digest(p) for p in sorted(Path(directory).rglob('*')) if p.is_file() and p.name not in ('result.json','terminal.json')}
def reviewed_original():
    require(REVIEWED_ORIGINAL and digest(REPORT/'original/terminal.json')==REVIEWED_ORIGINAL,'Separately reviewed exact original=False RUN terminal required')
    t=read(REPORT/'original/terminal.json');r=read(REPORT/'original/result.json')
    require(t['status']=='passed' and t['returncode']==0 and not t['cleanup']['survivors'] and t['source_index_sha256']==EXPECTED
        and t['result_sha256']==digest(REPORT/'original/result.json'),'Reviewed original arm failed/changed')
    require(r['stage']=='original' and r['source_index_sha256']==EXPECTED and r['integrand_policy'] is False,'Wrong original False arm')
    for name,wanted in r['raw_files'].items():require(digest(REPORT/'original'/name)==wanted,'Original raw evidence changed')
    return r

def run(role):
    before=protected();reference=reviewed_original() if role=='candidate' else None
    output=clone_runtime(role);directory=proc(output);binding=runtime_binding(output);report=REPORT/role
    bench,Worker=modules();collector=local('collector')
    worker_command=[tool('taskset'),'-c',str(CPU),str(directory/'check'),pins()['points']]
    dump(report/'worker-command.json',{'argv':worker_command,'cwd':str(directory),'executable_sha256':digest(directory/'check')})
    with Worker(worker_command,directory,report/'worker.log',env=environment(),timeout=240.) as worker:
        require(os.sched_getaffinity(worker.process.pid)=={CPU},'Worker affinity changed')
        ready={name:getattr(worker,name) for name in ('points','ndim','nso','nborn','cold_seconds')}
        dump(report/'ready.json',ready);require([ready[n] for n in ('points','ndim','nso','nborn')]==[100,1,1,1],'Wrong full100 normal dimensions')
        for name in ('warmup.dat','dimensions.dat'):shutil.copy2(directory/name,report/name)
        dump(report/'maps-before.json',maps(worker))
        worker.sequence+=1;require(worker.sequence==1,'Only one final full100 traversal admitted')
        dump(report/'exact-command.json',{'command':['EXACT',1,0]});worker._send('EXACT 1 0')
        require(worker._message()==['EXACTED','1'],'Full100 final traversal failed')
        for name in RAW:
            if not (report/name).exists():shutil.copy2(directory/name,report/name)
        dump(report/'maps-after.json',maps(worker));lane=collector.collect({name:(report/name).read_text() for name in RAW})
        dump(report/'collected.json',lane)
        require(lane['cohort']['accepted_QP_points'],'No accepted checked QP observed; QP qualification remains open')
        # Do not edit filters or learning state. The driver owns all state changes.
        require(runtime_binding(output)==binding and digest(directory/'check')==closed_build(role)['executable_sha256'],'Private runtime binding changed')
    require(not (directory/'worker-protocol.fifo').exists(),'Worker FIFO survived cleanup')
    comparison=None
    if reference is not None:
        comparison=collector.compare(reference['lane'],lane,bench.compare_rows);dump(report/'comparison.json',comparison)
        require(comparison['passed'],'False/False numerical/history/observed-state gate failed')
    require(protected()==before,'Protected source/object/runtime bindings changed')
    dump(report/'result.json',{'status':'passed','stage':role,'source_index_sha256':EXPECTED,'integrand_policy':False,
        'reviewed_original':REVIEWED_ORIGINAL,'lane':lane,'comparison':comparison,'full100_learning':True,'final_points':100,
        'normal_CTModeRun':-1,'forced_independent_stability':True,'threshold':1e-6,'finite':True,'LoopPoleMode':0,'TIRust_cache_layers':{'DP':0,'QP':0},
        'backend_history_scope':'Observed public statuses; no unrecorded internal reducer-entry or copied-coefficient claim.',
        'observed_IEEE_scope':'Raw host state only; no trap-freedom claim.','native_failures_retained_in_raw':True,
        'performance_acceptance':False,'candidate_promoted':False,'protected':before,'raw_files':inventory(report)})

def limits():
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        value=LIMITS[name];_,hard=resource.getrlimit(kind);require(hard==resource.RLIM_INFINITY or hard>=value,'Inherited hard limit too small');resource.setrlimit(kind,(value,value))
def child(role):
    admission=read(REPORT/role/'admission.json')
    require(admission['parent_pid']==os.getppid() and admission['source_index_sha256']==EXPECTED and admission['stage']==role
        and admission['reviewed_original']==REVIEWED_ORIGINAL,'Missing exact supervisor admission')
    require(os.sched_getaffinity(0)=={CPU},'Child affinity differs')
    for kind,name in ((resource.RLIMIT_AS,'address_space_bytes'),(resource.RLIMIT_FSIZE,'file_bytes'),(resource.RLIMIT_CORE,'core_bytes')):
        require(resource.getrlimit(kind)==(LIMITS[name],LIMITS[name]),'Child resource limit differs')
    verify_source();run(role)
def supervise(role):
    original_end=time.monotonic()+CAPS[role]
    cleanup=support('cleanup');ownership=support('ownership')
    directory=REPORT/role;directory.mkdir(parents=True,exist_ok=False)
    entry={'stage':role,'source_index_sha256':EXPECTED,'reviewed_original':REVIEWED_ORIGINAL,'cap_seconds':CAPS[role],
        'cleanup_reserve_seconds':CLEANUP,'resource_limits':LIMITS,'cpu':CPU,'cpu_reservation':False,'status':'running',
        'original_end_monotonic':original_end}
    owned=None;process=None;raw_record=None;cleaned=False
    try:
        with cleanup.SignalRequests() as requests,ownership.StageDeadline(CAPS[role],absolute_end=original_end) as deadline:
            entry['deadline_monotonic']=deadline.end;limits();verify_source();protected();requests.check()
            require(not (WORK/role).exists(),'Fresh RUN arm required; no retry')
            if role=='candidate':reviewed_original()
            argv=[tool('taskset'),'-c',str(CPU),tool('python3'),'-B',str(HERE/'controller.py'),'--source',EXPECTED,'--child',role]
            if REVIEWED_ORIGINAL:argv+=['--reviewed-original',REVIEWED_ORIGINAL]
            dump(directory/'admission.json',{**entry,'parent_pid':os.getpid(),'command':argv})
            process_env=environment()
            with (directory/'console.log').open('xb') as stream:
                deadline.handoff=True
                try:
                    process=subprocess.Popen(argv,cwd=ROOT,env=process_env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                    raw_record=cleanup.identity(process.pid);owned=cleanup.OwnedChild(process)
                finally:
                    deadline.handoff=False
                    if deadline.deferred:deadline.expired(None,None)
                entry['pid']=process.pid;dump(directory/'started.json',entry);entry['returncode']=owned.wait(requests);requests.check()
                entry['cleanup']=ownership.cleanup_owned(owned,deadline.end);cleaned=True
            require(entry['returncode']==0 and not entry['cleanup']['survivors'],'RUN failed; no automatic retry')
            protected();verify_source();requests.check();entry.update(status='passed',result_sha256=digest(directory/'result.json'));dump(directory/'terminal.json',entry)
    except BaseException as error:
        if process is not None and not cleaned:
            try:entry['cleanup']=ownership.cleanup_owned(owned,entry['deadline_monotonic']) if owned is not None else ownership.raw_cleanup(process,raw_record,cleanup,entry['deadline_monotonic'])
            except BaseException as cleanup_error:entry['cleanup_error']=repr(cleanup_error)
        entry.update(status='failed',error=repr(error));dump(directory/'terminal.json',entry);raise

def main():
    global EXPECTED,REVIEWED_ORIGINAL
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--stage',choices=tuple(CAPS));p.add_argument('--execute',action='store_true');p.add_argument('--reviewed-original');p.add_argument('--child',choices=tuple(CAPS),help=argparse.SUPPRESS)
    args=p.parse_args();EXPECTED=args.source;REVIEWED_ORIGINAL=args.reviewed_original
    verify_source()
    if args.child:child(args.child)
    elif args.execute:
        require(args.stage and bool(REVIEWED_ORIGINAL)==(args.stage=='candidate'),'Explicit separate RUN required; candidate requires reviewed original=False terminal')
        with (ROOT/'.tirust-build/numerical-tests.lock').open('a+b') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX|fcntl.LOCK_NB);supervise(args.stage)
    else:
        require(not args.stage and not REVIEWED_ORIGINAL,'Source preflight takes no stage/review options');verify_source()
        print(json.dumps({'status':'source-only-preflight-passed','source_index_sha256':EXPECTED,'protected':protected(),'caps_seconds':CAPS,'cleanup_reserve_seconds':CLEANUP,'limits':LIMITS,'native_calls':0,'compiler_queries':0,'loader_queries':0,'MG_import_execution':0},sort_keys=True))
if __name__=='__main__':main()
