# Dormant False-integrand physical pair

Successor2 preserves dormant source1 seal
`eab42489ae3fb3b0b4bd9b51b5ad4e83607a62a4fa09323a3b156aac8bc26a79`.
Its only controller change is the qualified absolute-end ownership deadline:
a handoff cutoff rearms the original hard-end alarm, a handoff reaching that
hard end raises, and environment reconstruction finishes before handoff.
The original600-second end is carried through preflight, execution and cleanup.
All collector/card/scientific/16-file worker bindings are unchanged.

Source-only proposal for the unapplied TIRust QP-mass patch, 2026-11-11.
Only two existing N3 `loop_sm` executables for `u u~ > z g g [virt=QCD]`
are reused. There is no BUILD stage, generation, compiler/loader query, native
execution, production/reference edit, Git operation, patch promotion or timing
claim in source preparation or default preflight.

Run only from `/shared/external/madloop_tirust/madgraph7_madloop_tirust`.
The original donor is `.tirust-build/qp-mass-current-qualification-work-2/build/original`;
the candidate is the actual fresh-CLI export already compiled at
`.tirust-build/qp-mass-fresh-cli-qualification-work-1/build/candidate`.
Their exact closed BUILD terminals/results bind all 195 source/build inputs,
144 numerical objects/modules/archives, effective recipes, link commands,
actual linker LOADs, link maps, executables and runtime providers. Source-only
preflight rehashes those bindings. The five direct numerical library leaves
are joined independently; they are not confused with the physical 15-provider
runtime closure. The native DSO stays
`eb3d67fdc99b742b1c5d66101522c8b8fb97e74b0b71ac69fd4452fb60c42af9`.

Each arm receives a fresh 16-file runtime-only copy: its exact executable,
physical/numerical cards, and the two small MadLoop resource directories.
The original and candidate executable copies are approximately 80 MB each;
no Source/object/lib tree or 298 MB NinjaRS alias is copied. All runtime copy
sources are exact regular in-donor files. The runtime copies contain no
symlinks. Fresh filter files are absent initially, then remain wholly owned
by normal driver learning; no learned state is rewritten or borrowed.

Both arms use the same sealed `false-cache0.dat`. Its only change from the
closed physical cache0 card is `UseQPIntegrandForTIRust=.false.`. It preserves
backend9, `CTModeRun=-1`, forced independent stability checks in the existing
driver, `MLStabThres=1e-6`, finite=True, `LoopPoleMode=0` (UV+IR), and
`TIRustGlobalCache=0` for both DP/QP caching. Other integrand flags, scale,
point input and rescue policy remain identical. Every arm performs normal
full100 learning followed by exactly one final full100 `EXACT 1 0` traversal
of the same saved physical points. No fixed120/CT4/5 call, strict-target
fixture, retries or live deadline extension is included.

The collector learns each arm's actual public status cohort. It has no
87DP/13QP constant, point16 anchor or True-policy numerical reference.
Every final point/order retains Born, finite, single pole, double pole,
accuracy, status and their binary64 words; complete learning raw records,
public backend/precision histories, pre/post IEEE observations and software
latches remain retained. Steady accepted statuses must decode as checked
backend9 DP/QP, and every accepted coefficient/accuracy must be finite with
nonnegative accuracy. At least one accepted final QP point per arm is required;
a DP-only traversal leaves QP qualification open. Bootstrap raw records are
retained without inventing a checked bootstrap status.

The candidate stage compares original=False to candidate=False with the
unchanged `tirust_benchmark.compare_rows` criterion at 3e-6 and target1e-8,
for both steady learning and final100 rows. Both criteria must pass. All word
and accuracy differences are retained; no DP word identity or historical
cohort is assumed. Paired accepted status changes, learning call/status
history changes, or observed IEEE/software-state changes fail this small gate
and retain evidence for investigation. Failure raw data remains in the fresh
worker/report directories; no unsuccessful native request is converted to
an accepted result.

The unchanged source calls `MP_UPDATE_AS_PARAM()` unconditionally before its
integrand branch. With False, the existing DP coefficient construction is
copied into QP containers. These plain executable workers expose public
status observations, not internal reducer-entry counters, copied-DP coefficient
anchors or native request mass words. This gate makes no claim to directly
observe those uninstrumented internals and demonstrates no stale-MP defect.
It qualifies this normal physical False/False pair only; independent finite
truth, broader models, mass transport observer anchors and performance remain
outside this gate.

Two separately admitted RUN stages are proposed: `original`, then `candidate`
only after review of the exact successful original terminal. Each stage has
600 seconds total including its original 60-second cleanup reserve, 16 GiB
address space, 512 MiB file cap, core0, single-thread libraries, nonexclusive
CPU12 and the shared fail-if-busy numerical mutex. Safe absolute-deadline and
raw-child cleanup helpers are pinned byte-for-byte to snapshot proposal2
(the qualified41797bbf source family);
a failure after Popen but before OwnedChild construction retains the raw
identity and cannot qualify a pass. Failure stops with no retry.

The exact source seal is SHA256 of `source-index.json`. Default preflight and
pure tests are the only admitted operations at preparation time:

```text
<pinned Python> -B .tirust-build/qp-mass-false-integrand-qualification-proposal-2/controller.py --source SOURCE_SHA
<pinned Python> -B .tirust-build/qp-mass-false-integrand-qualification-proposal-2/test_gate.py
<pinned Python> -O -B .tirust-build/qp-mass-false-integrand-qualification-proposal-2/test_gate.py
```

After independent source review and explicit root admission, concrete future
commands are the same controller plus `--stage original --execute`, and only
after its separate closed review, `--stage candidate --execute
--reviewed-original ORIGINAL_TERMINAL_SHA`. This README admits neither stage.
The fresh work/report roots end in `qualification-{work,execution}-2`.
