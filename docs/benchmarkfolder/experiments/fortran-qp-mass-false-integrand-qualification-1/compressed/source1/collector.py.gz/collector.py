"""Pure False/False collectors; no historical True-policy cohort is imported."""
from collections import Counter
import math
import re
import struct

WORD=re.compile(r'[0-9A-Fa-f]{16}\Z')
def require(ok,message):
    if not ok:raise ValueError(message)
def lines(text):return [line.split() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
def status(code,steady=True):
    require(type(code) is int and code>=0,'Invalid public status')
    h,t,u=code//100,code//10%10,code%10
    require(t in ((1,2) if steady else (1,2,3)),'Unchecked/failing public status')
    actual={(2,9):(9,'DP'),(3,3):(9,'QP')}.get((h,u))
    if not steady and (h,t,u)==(1,3,9):actual=(9,'initializing')
    require(actual is not None,'Unexpected actual backend/precision for backend9 card')
    return {'status':code,'backend':actual[0],'precision':actual[1],'stable':t in (1,2),'hundreds':h,'tens':t,'units':u}
def word(value):
    require(isinstance(value,str) and WORD.fullmatch(value),'Malformed binary64 word')
    value=value.upper();number=struct.unpack('>d',bytes.fromhex(value))[0]
    require(math.isfinite(number),'Nonfinite numerical word')
    return value,number
def exact(text):
    rows=[]
    for fields in lines(text):
        require(len(fields)==8,'Malformed final row')
        p,o,s=map(int,fields[:3]);actual=status(s);pairs=[word(v) for v in fields[3:]]
        require(pairs[-1][1]>=0,'Missing/negative checked accuracy')
        rows.append({'point':p,'order':o,'status':s,'words':[x[0] for x in pairs],
            'coefficients':[x[1] for x in pairs[:4]],'accuracy':pairs[-1][1],
            'actual_backend':actual['backend'],'precision':actual['precision']})
    require([(r['point'],r['order']) for r in rows]==[(p,o) for p in range(1,101) for o in (0,1)],'Final100 point/order coverage differs')
    require(all(rows[i]['status']==rows[i+1]['status'] for i in range(0,200,2)),'Split-order statuses differ')
    return rows

def learning(text):
    groups=[];raw=[]
    for fields in lines(text):
        require(len(fields)==9,'Malformed learning record')
        call,p,o,s=map(int,fields[:4]);raw.append({'call':call,'point':p,'order':o,'status':s,'raw_fields':fields})
        require(call>=0,'Negative learning call')
        if not groups or groups[-1][0]!=call:
            require(not groups or call==groups[-1][0]+1,'Learning calls missing/reordered')
            groups.append((call,[]))
        groups[-1][1].append(fields)
    require(groups and groups[0][0]==0 and len(groups)>=101,'Bootstrap and full100 learning required')
    history=[]
    for call,records in groups:
        point=1 if call==0 else 1+(call-1)%100
        require([(int(f[1]),int(f[2])) for f in records]==[(point,0),(point,1)],'Learning point/order coverage differs')
        require(records[0][3]==records[1][3],'Learning split-order statuses differ')
        code=int(records[0][3]);actual=None if call==0 else status(code,steady=False)
        history.append({'call':call,'point':point,'status':code,'observed':actual})
    window=groups[-100:];steady=[]
    for call,records in window:
        status(int(records[0][3]))
        for fields in records:
            values=[float(x.replace('D','E').replace('d','e')) for x in fields[4:]]
            require(all(math.isfinite(x) for x in values) and values[-1]>=0,'Nonfinite/negative steady learning result')
            steady.append({'point':int(fields[1]),'order':int(fields[2]),'status':int(fields[3]),
                'words':[struct.pack('>d',v).hex().upper() for v in values],
                'coefficients':values[:4],'accuracy':values[-1],
                'actual_backend':9,'precision':status(int(fields[3]))['precision']})
    steady.sort(key=lambda x:(x['point'],x['order']))
    require([(r['point'],r['order']) for r in steady]==[(p,o) for p in range(1,101) for o in (0,1)],'Steady learning does not cover all100')
    return {'history':history,'all_raw_records':raw,'rows':steady,'first_steady_call':window[0][0],'last_steady_call':window[-1][0]}

def ieee(text):
    rows=[list(map(int,f)) for f in lines(text)]
    require(len(rows)==200 and all(len(r)==13 for r in rows),'Incomplete IEEE records')
    require([r[:2] for r in rows]==[[p,phase] for p in range(1,101) for phase in (1,2)],'IEEE order differs')
    require(all(r[2] in range(-1,5) and all(x in (-1,0,1) for x in r[3:]) for r in rows),'Invalid IEEE state')
    return rows

def software(text):
    rows=[list(map(int,f)) for f in lines(text)]
    require(len(rows)==200 and all(len(r)==4 and all(x in (0,1) for x in r[2:]) for r in rows),'Incomplete/invalid software latch records')
    require([r[:2] for r in rows]==[[p,phase] for p in range(1,101) for phase in (1,2)],'Software order differs')
    return rows

def cohort(rows):
    observations=[{'point':r['point'],**status(r['status'])} for r in rows if r['order']==0]
    return {'history':observations,'status_counts':dict(sorted(Counter(str(r['status']) for r in observations).items())),
        'backend_precision_counts':dict(sorted(Counter(str(r['backend'])+':'+r['precision'] for r in observations).items())),
        'accepted_QP_points':[r['point'] for r in observations if r['precision']=='QP']}

def collect(raw):
    require(raw['dimensions.dat'].split()==['1','1','1'],'Wrong physical answer dimensions')
    rows=exact(raw['exact-words.dat'])
    return {'rows':rows,'learning':learning(raw['warmup.dat']),'cohort':cohort(rows),
        'ieee':ieee(raw['exact-ieee.dat']),'software':software(raw['software-flags.dat'])}

def compare_rows(left,right,comparator):
    require([(r['point'],r['order']) for r in left]==[(r['point'],r['order']) for r in right],'Paired points/orders differ')
    regression=comparator(left,right,tolerance=3e-6);target=comparator(left,right,tolerance=1e-8)
    changes=[];status_changes=[]
    for l,r in zip(left,right,strict=True):
        if l['status']!=r['status']:status_changes.append({'point':l['point'],'order':l['order'],'original':l['status'],'candidate':r['status']})
        if l['words']!=r['words']:changes.append({'point':l['point'],'order':l['order'],'original_words':l['words'],'candidate_words':r['words']})
    return {'passed':regression['passed'] and target['passed'] and not status_changes,'regression':regression,'ordinary_target':target,
        'regression_tolerance':3e-6,'ordinary_target_tolerance':1e-8,'status_changes':status_changes,'word_differences':changes,
        'accuracy_scope':'Finite nonnegative checked estimates retained; accuracy differences are diagnostic.'}

def compare(left,right,comparator):
    final=compare_rows(left['rows'],right['rows'],comparator)
    learned=compare_rows(left['learning']['rows'],right['learning']['rows'],comparator)
    history_equal=left['learning']['history']==right['learning']['history']
    ieee_equal=left['ieee']==right['ieee'];software_equal=left['software']==right['software']
    qp=bool(left['cohort']['accepted_QP_points']) and bool(right['cohort']['accepted_QP_points'])
    return {'passed':final['passed'] and learned['passed'] and history_equal and ieee_equal and software_equal and qp,
        'final':final,'learning':learned,'learning_history_equal':history_equal,'observed_IEEE_equal':ieee_equal,
        'software_latches_equal':software_equal,'accepted_QP_observed_in_each_arm':qp,
        'original_cohort':left['cohort'],'candidate_cohort':right['cohort'],
        'reference_policy':'original=False versus candidate=False; no True-policy numerical reference',
        'performance_acceptance':False,'candidate_promoted':False}
