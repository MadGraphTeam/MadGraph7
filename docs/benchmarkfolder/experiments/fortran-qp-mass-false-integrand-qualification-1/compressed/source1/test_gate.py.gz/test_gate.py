"""Source/file-only tests. All subprocess/native execution and MG imports blocked."""
import builtins
from contextlib import nullcontext
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import types
import unittest
from unittest.mock import Mock,patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('false_gate_test_controller',HERE/'controller.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
a=c.local('collector')
def w(value):return struct.pack('>d',value).hex().upper()
def fixture(qp=(3,44)):
    final=[];warm=[];ieee=[];software=[]
    for call in range(101):
        p=1 if call==0 else call;s=323 if p in qp else 219
        for o in (0,1):warm.append(f'{call} {p} {o} {s} 10 1 .01 .001 1e-9')
    for p in range(1,101):
        for o in (0,1):final.append(f'{p} {o} {323 if p in qp else 219} '+ ' '.join(map(w,(10.,1.,.01,.001,1e-9))))
        for phase in (1,2):ieee.append(f'{p} {phase} 0 '+' '.join(['0']*10));software.append(f'{p} {phase} 0 0')
    return {'dimensions.dat':'1 1 1\n','warmup.dat':'\n'.join(warm),'exact-words.dat':'\n'.join(final),'exact-ieee.dat':'\n'.join(ieee),'software-flags.dat':'\n'.join(software)}

class Gate(unittest.TestCase):
    def setUp(self):
        self.guards=[]
        for module,name in ((subprocess,'Popen'),(os,'system'),(os,'fork'),(os,'execv'),(os,'execve')):
            g=patch.object(module,name,side_effect=AssertionError('process/native execution blocked'));g.start();self.guards.append(g)
        original=builtins.__import__
        def guarded(name,*args,**kwargs):
            if name.split('.')[0] in {'madgraph','mg5decay','MadSpin','madmatrix','aloha','PLUGIN'}:raise AssertionError('MG import blocked')
            return original(name,*args,**kwargs)
        g=patch.object(builtins,'__import__',side_effect=guarded);g.start();self.guards.append(g)
    def tearDown(self):
        for g in reversed(self.guards):g.stop()
    def test_source_and_closed_builds_without_execution(self):
        c.EXPECTED=c.digest(HERE/'source-index.json');c.verify_source();result=c.protected()
        self.assertEqual(result['runtime_provider_count'],15)
        for row in result['builds'].values():self.assertEqual((row['sources'],row['objects']),(195,144))
        self.assertFalse(c.WORK.exists());self.assertFalse(c.REPORT.exists())
    def test_card_only_one_intended_change(self):
        original=Path(c.pins()['support_paths']['ownership']).parent/'cards/cache0.dat'
        before=original.read_text();after=(HERE/'false-cache0.dat').read_text()
        self.assertEqual(after,before.replace('#UseQPIntegrandForTIRust\n.true.\n','#UseQPIntegrandForTIRust\n.false.\n'))
        for name,value in (('MLReductionLib','9'),('CTModeRun','-1'),('MLStabThres','1.000000d-06'),('LoopPoleMode','0'),('TIRustGlobalCache','0'),('TIRustComputeFinite','.true.')):
            self.assertIn('#'+name+'\n'+value+'\n',after)
    def test_dynamic_cohort_and_all_words(self):
        lane=a.collect(fixture());self.assertEqual(lane['cohort']['accepted_QP_points'],[3,44]);self.assertEqual(len(lane['rows']),200)
        self.assertEqual(lane['cohort']['backend_precision_counts'],{'9:DP':98,'9:QP':2})
        lane2=a.collect(fixture((1,2,4,91)));self.assertEqual(lane2['cohort']['accepted_QP_points'],[1,2,4,91])
    def test_bad_QP_accuracy_and_status_rejected(self):
        for bad in (w(-1.),'7FF0000000000000','7FF8000000000001'):
            raw=fixture();parts=raw['exact-words.dat'].splitlines();f=parts[4].split();f[-1]=bad;parts[4]=' '.join(f);raw['exact-words.dat']='\n'.join(parts)
            with self.assertRaises(ValueError):a.collect(raw)
        for bad in ('423','120','324','322'):
            raw=fixture();raw['exact-words.dat']=raw['exact-words.dat'].replace('3 0 323','3 0 '+bad)
            with self.assertRaises(ValueError):a.collect(raw)
    def test_missing_final_learning_ieee_and_software_rejected(self):
        for name in ('exact-words.dat','warmup.dat','exact-ieee.dat','software-flags.dat'):
            raw=fixture();raw[name]='\n'.join(raw[name].splitlines()[:-1])
            with self.assertRaises(ValueError):a.collect(raw)
    def test_false_pair_comparison_uses_both_thresholds(self):
        bench=c.modules()[0];left=a.collect(fixture());right=copy.deepcopy(left)
        result=a.compare(left,right,bench.compare_rows);self.assertTrue(result['passed'])
        for field in ('final','learning'):
            self.assertEqual((result[field]['regression']['tolerance'],result[field]['ordinary_target']['tolerance']),(3e-6,1e-8))
        right['rows'][4]['coefficients'][1]*=2;right['rows'][4]['words'][1]=w(right['rows'][4]['coefficients'][1]);self.assertFalse(a.compare(left,right,bench.compare_rows)['passed'])
    def test_status_and_observed_state_changes_preserved_and_fail(self):
        bench=c.modules()[0];left=a.collect(fixture());right=a.collect(fixture((3,44,80)))
        result=a.compare(left,right,bench.compare_rows);self.assertFalse(result['passed']);self.assertTrue(result['final']['status_changes'])
        right=copy.deepcopy(left);right['ieee'][0][3]=1;self.assertFalse(a.compare(left,right,bench.compare_rows)['passed'])
    def test_accuracy_drift_is_retained_not_physics_failure(self):
        bench=c.modules()[0];left=a.collect(fixture());right=copy.deepcopy(left);right['rows'][4]['accuracy']=2e-9;right['rows'][4]['words'][-1]=w(2e-9)
        result=a.compare(left,right,bench.compare_rows);self.assertTrue(result['passed']);self.assertEqual(len(result['final']['word_differences']),1)
    def test_zero_QP_does_not_qualify(self):
        lane=a.collect(fixture(()));self.assertFalse(a.compare(lane,lane,c.modules()[0].compare_rows)['passed'])
    def test_runtime_copy_whitelist_never_copies_libraries(self):
        p=c.pins()
        for role,planned in p['runtime_copies'].items():
            self.assertEqual(len(planned),16);self.assertFalse(any('lib' in Path(n).parts or Path(n).suffix in ('.o','.a','.mod') for n in planned))
        with tempfile.TemporaryDirectory() as directory,patch.object(c,'WORK',Path(directory)/'work'):
            # Do not copy the real80MB executable in pure tests. An exact small
            # synthetic donor tests the same whitelist and no-alias rules.
            donor=Path(directory)/'donor';name='SubProcesses/P0/check';source=donor/name;source.parent.mkdir(parents=True);source.write_bytes(b'fixture')
            pin=copy.deepcopy(p);pin['builds']['original']['output']=str(donor);record={'bytes':7,'sha256':c.digest(source)}
            pin['runtime_copies']={r:{name:record} for r in ('original','candidate')};pin['numerical_cards']=[]
            with patch.object(c,'pins',return_value=pin),patch.object(c,'closed_build',return_value={'executable_sha256':record['sha256']}),patch.object(c,'proc',side_effect=lambda root:Path(root)/'SubProcesses/P0'):
                out=c.clone_runtime('original');self.assertEqual((out/name).read_bytes(),b'fixture')
                with self.assertRaises(ValueError):c.clone_runtime('original')
    def test_reviewed_original_required(self):
        with patch.object(c,'REVIEWED_ORIGINAL',None):
            with self.assertRaises(ValueError):c.reviewed_original()
        self.assertEqual(c.CAPS,{'original':600.,'candidate':600.});self.assertEqual((c.CPU,c.CLEANUP),(12,60.))
    def test_foreign_original_source_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            report=Path(directory);stage=report/'original';stage.mkdir();(stage/'result.json').write_text('{}')
            (stage/'terminal.json').write_text(json.dumps({'status':'passed','returncode':0,'cleanup':{'survivors':[]},'source_index_sha256':'foreign','result_sha256':c.digest(stage/'result.json')}))
            with patch.object(c,'REPORT',report),patch.object(c,'EXPECTED','this-source'),patch.object(c,'REVIEWED_ORIGINAL',c.digest(stage/'terminal.json')):
                with self.assertRaises(ValueError):c.reviewed_original()
    def test_popen_constructor_gap_uses_raw_identity_cleanup(self):
        process=Mock(pid=123);record={'pid':123,'process_group':123,'session':123,'start_time_ticks':7}
        cleanup=Mock();cleanup.SignalRequests.side_effect=lambda:nullcontext(Mock());cleanup.identity.return_value=record;cleanup.OwnedChild.side_effect=RuntimeError('owned init failure')
        deadline=types.SimpleNamespace(end=1e30,handoff=False,deferred=False);clock=types.SimpleNamespace(StageDeadline=lambda:nullcontext(deadline))
        owner=types.SimpleNamespace(raw_cleanup=Mock(return_value={'failure_only':True,'uncertainty_blocks_later_stages':True}))
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(c,'REPORT',Path(directory)/'report'),patch.object(c,'WORK',Path(directory)/'work'),patch.object(c,'EXPECTED','seal'),patch.object(c,'REVIEWED_ORIGINAL',None), \
                patch.object(c,'support',side_effect=lambda n:{'cleanup':cleanup,'deadline':clock,'ownership':owner}[n]),patch.object(c,'limits'),patch.object(c,'verify_source'),patch.object(c,'protected'),patch.object(c,'environment',return_value={}),patch.object(c,'tool',side_effect=lambda n:'/pinned/'+n),patch.object(subprocess,'Popen',return_value=process):
                with self.assertRaisesRegex(RuntimeError,'owned init failure'):c.supervise('original')
            owner.raw_cleanup.assert_called_once_with(process,record,cleanup,deadline.end)
            terminal=json.loads((Path(directory)/'report/original/terminal.json').read_text());self.assertEqual(terminal['status'],'failed');self.assertTrue(terminal['cleanup']['uncertainty_blocks_later_stages'])
    def test_absolute_cleanup_budget(self):
        owner=c.support('ownership');owned=Mock();owned.stop.return_value={'survivors':[]}
        with patch.object(owner.time,'monotonic',return_value=99.):owner.cleanup_owned(owned,100.)
        self.assertAlmostEqual(sum(owned.stop.call_args.kwargs.values()),1.)
        with patch.object(owner.time,'monotonic',return_value=101.):owner.cleanup_owned(owned,100.)
        self.assertEqual(sum(owned.stop.call_args.kwargs.values()),0.)
    def test_source_inventory_extra_alias_and_mutation_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            here=Path(directory);payload=here/'payload';payload.write_text('x');(here/'source-index.json').write_text(json.dumps({'files':{'payload':{'bytes':1,'sha256':c.digest(payload)}}}))
            with patch.object(c,'HERE',here),patch.object(c,'EXPECTED',c.digest(here/'source-index.json')):
                c.verify_source();payload.write_text('y')
                with self.assertRaises(ValueError):c.verify_source()
                payload.unlink();payload.symlink_to(here/'source-index.json')
                with self.assertRaises(ValueError):c.verify_source()
if __name__=='__main__':unittest.main()
